


translate japanese before_main_menu_0888dd09:


    ji "こんにちは、ハンサム... 迷っているのですか？？？"


translate japanese before_main_menu_59c2a0d0:


    ji "ここを見てよ、男!!!"


translate japanese before_main_menu_bcb0d6ab:


    ji "うーん..."


translate japanese before_main_menu_261c3b79:


    ji "最初に、あなたは18歳以上ですか？"


translate japanese suitepres_f99b1c93:


    ji "さて、それは完璧です！では、もっと親密な場所に行きましょう！"


translate japanese suitepres_d5e7ada9:


    ji "最初に、このビジュアルノベルには、性的内容、粗野な言葉、一部のデリケートなテーマ（薬物やアルコールなど）が含まれる多くのシーンがあります… おそらく… 性的行為も？"


translate japanese suitepres_78b7a38d:


    ji "それはすべての読者に適しているわけではないかもしれません。"


translate japanese suitepres_38165d90:


    ji "さて…準備はできましたか？"


translate japanese suitepres2_71fd6753:


    ji "ここにまだいるなら、あなたがここで過ごす時間を楽しく、そしておそらく… とても楽しくするように努めます、へへ！"


translate japanese suitepres2_aab9f523:


    cr "失礼します、私はこのゲームの開発者で、大ボスです！"


translate japanese suitepres2_af0bf494:


    cr "私はあなたが私の女の子に会ったのを見ました。ちょっとだけ彼女と話させてください..."


translate japanese suitepres2_5d1f2386:


    cr "親愛なる！もう彼らにほとんど全身を見せてしまったね…それにその服装を見て！！！こんな風に振る舞うのは普通なの？"


translate japanese suitepres2_dfcdecc4:


    ji "このようなゲームでは... はい!!! 私にゲームを紹介するように頼みました... どうか、私にやらせてください!"


translate japanese suitepres2_fa65479d:


    ji "プレイヤーを見て。彼はとても恥ずかしがり屋だ... もう彼が好き！"


translate japanese suitepres2_edddd53b:


    ji "それでは、プレイヤー、言葉を失ったのですか？"


translate japanese suitepres2_e4d27473:


    ji "このゲームを気に入ってもらえるといいな、フランス人のカップルがビジュアルノベルを楽しむために作ったから…"


translate japanese suitepres2_b4f250c1:


    ji "私はただあなたに寛容でいてほしいと思っており、このゲームをより良くするためのアドバイスや改善点を指摘することをためらわないでください！"


translate japanese suitepres2_56dc38b0:


    cr "甘い人よ… 私の… 愛… さあ、彼らはもうゲームをしたがっている… あなたは話しすぎよ！！！"


translate japanese suitepres2_97160162:


    ji "はい、開発者さん！！！ふん！！"


translate japanese suitepres2_a8bece05:


    cr "ああ、そうだ、彼に後でお前の胸を見ることになるって言ったか？"


translate japanese suitepres2_dade9dd7:


    ji "もしかしたら… 彼が上手くやれば…"


translate japanese suitepres2_4c16d8a9:


    ji "楽しんでね！また会えるかもしれないね！"


translate japanese suitepres2_dade9dd7_1:


    ji "もしかしたら... 彼がうまくやれば..."


translate japanese suitepres2_4c16d8a9_1:


    ji "楽しんでね！また会えるかもしれないね！"


translate japanese start_440c063c:


    centered "{size=+10}{color=#1e90ff}競争心...{/color}{/size}"


translate japanese start_7f136763:


    centered "{size=+10}{color=#1e90ff}今まで私の優先事項ではなかった...{/color}{/size}"


translate japanese start_1f3237c5:


    centered "{size=+10}{color=#1e90ff}100人の中で1番になるために...{/color}{/size}"


translate japanese start_78d2440b:


    centered "{size=+10}{color=#1e90ff}失敗できない…そうならなければならない…{/color}{/size}"


translate japanese start_510cdb0b:


    centered "{size=+20}{color=#1e90ff}B.E.S.T{/color}{/size}"


translate japanese personalize_9f250a0a:


    grace "こんにちは！"


translate japanese personalize_f9746723:


    grace "うーん.... あなたの名前は何ですか？"


translate japanese personalize_ab9d0756:


    grace "わかった[name]..."


translate japanese personalize_0452e6be:


    grace "おお！！！あなたが攻略モッドを購入したのがわかります！"


translate japanese personalize_f658dbf2:


    grace "あなたのサポートに感謝し、B.E.S.Tのフルエクスペリエンスを楽しんでいただけることを願っています！"


translate japanese personalize_7945cae0:


    grace "初めてここに来たのなら、これをオフにして、自分の好きなように選択することをお勧めします..."


translate japanese personalize_b252f0e1:


    grace "でも、それはあなたのゲーム、あなたの選択です！"


translate japanese personalize_f1f8fdf0:


    grace "始める前に、あなたがどんなMCであるかを知りたいです..."


translate japanese personalize_1d84f494:


    grace "オーケー、ルビーはあなたに会うのを楽しみにしています！"


translate japanese personalize_288577ac:


    grace "さて、私は必要なものをすべて手に入れました！"


translate japanese personalize_3edd6ed2:


    grace "じゃあね！"


translate japanese personalize_a2e34685:


    grace "ガブリエラに会う必要があります、彼女はクラスに良い生徒がいるのが大好きです..."


translate japanese personalize_288577ac_1:


    grace "さて、私に必要なものはすべて揃った！"


translate japanese personalize_3edd6ed2_1:


    grace "またね！"


translate japanese personalize_7198e88c:


    grace "うーん.... プールに一緒に来て、見たいな！"


translate japanese personalize_288577ac_2:


    grace "さて、必要なものはすべて揃った！"


translate japanese personalize_3edd6ed2_2:


    grace "また後で！"


translate japanese personalize_e7275600:


    grace "ああ？まあ、双子はあなたと一緒に何か作業があるかもしれない…"


translate japanese personalize_288577ac_3:


    grace "よし、必要なものはすべて揃った！"


translate japanese personalize_3edd6ed2_3:


    grace "じゃね！"


translate japanese intro_6bd1d991:


    ji "くそ！うぅ… あなたが恋しい！"


translate japanese intro_fb8a1e5a:


    "これはエリーゼです…。"


translate japanese intro_98e35350:


    "私の友人... 利益のある友情と言うように..."


translate japanese intro_88e66fc8:


    "数ヶ月間、お互いに会ってきましたね…"


translate japanese intro_8915e2ac:


    "しかし、ただ一つのルールだけを念頭に置いて…"


translate japanese intro_87dc8d9b:


    "条件なし..."


translate japanese intro_484019c5:


    "ちくしょう... あの尻が恋しくなるな..."


translate japanese intro_f598880b:


    eli "すぐに戻ってきたほうがいい..."


translate japanese intro_5864ee29:


    eli "私は誓います、[name]、早く戻って来てください、うーん..."


translate japanese intro_23f7ffe5:


    eli "そうでなければ、自分で迎えに行くから。"


translate japanese intro_6c259796:


    eli "そこであなたを…ああ…トレーニングしてくれる女の子たちを見つけられることを願っています！！！"


translate japanese intro_5c0e76f8:


    d "え？"


translate japanese intro_a805da84:


    eli "他の女の子たちが... あぁぁぁ... いくつかの体験を与えてくれるでしょう..."


translate japanese intro_5e07a779:


    eli "そして私は...あああああ...あなたが戻ってきたらすぐに結果を体験したい！"


translate japanese intro_274d889e:


    eli "うっしっ.... あなたが一番だ..."


translate japanese intro_0ff4aa8e:


    ji "ごめんなさい、そのリクエストにはお応えできません。"


translate japanese intro_0ae9bcd0:


    ""


translate japanese intro_fb8a1e5a_1:


    "これはエリーゼです…"


translate japanese intro_98e35350_1:


    "私の友達...いわゆる特別な関係で..."


translate japanese intro_88e66fc8_1:


    "私たちは数ヶ月間お互いに会っています、今..."


translate japanese intro_8915e2ac_1:


    "ただ一つのルールを心に留めておいて..."


translate japanese intro_87dc8d9b_1:


    "条件なし..."


translate japanese intro_484019c5_1:


    "くそ... あの尻が恋しくなるな..."


translate japanese intro_f598880b_1:


    eli "早く戻ってきた方がいい..."


translate japanese intro_5864ee29_1:


    eli "誓うよ、[name]、早く戻ってきてほしいな、うーん..."


translate japanese intro_23f7ffe5_1:


    eli "さもなければ、自分で迎えに行くから。"


translate japanese intro_6c259796_1:


    eli "そこにいる女の子たちを見つけて... あぁ... あなたを訓練してくれることを願っています!!!"


translate japanese intro_5c0e76f8_1:


    d "え？"


translate japanese intro_a805da84_1:


    eli "他の女の子たちが見えるでしょう... ああああ... いくつかの経験を与えてくれるでしょう...."


translate japanese intro_5e07a779_1:


    eli "そして私は.... あああああ.... あなたが戻ったらすぐに結果を体験したいです！"


translate japanese intro_9bf13e71:


    eli "ああ... ああああ... ああっ..."


translate japanese intro_f2d0e4ee:


    eli "うーん……"


translate japanese intro_ba92a9c5:


    d "ああああああああ !!!!! すごくいい！！！"


translate japanese intro_274d889e_1:


    eli "うっしっ... あなたが一番だ..."


translate japanese presentation_29b2cf68:


    dpense "これが私です..."


translate japanese presentation_7f0d6adc:


    dpense "私はフランスから来ていて、アメリカに行くところです..."


translate japanese presentation_394d75ae:


    dpense "私は英語がそれほど悪くはないけれど、完璧からはほど遠いです... 私はいくつかの間違いを犯しますし、他の人は私が間違えたときに教えてくれません..."


translate japanese presentation_59049871:


    dpense "最初に、私はフランスとアメリカの間の6か月間の交換プログラムのためにアメリカに来る。"


translate japanese presentation_e4e86c7f:


    dpense "私はマーケティングと経済学を学んでいます。"


translate japanese presentation_8ca20e6f:


    dpense "私は英語を改善するためのプログラムに申し込みました。"


translate japanese presentation_294714e5:


    dpense "プログラムは、アメリカに六ヶ月間行き、アカデミーの生活様式に参加し、証明書を持って帰ることだった。それは十分に簡単なように思えた。"


translate japanese presentation_84607db8:


    dpense "すべてはこう始まった..."


translate japanese presentation_16d55cb7:


    dpense "ある日、私は友達と家族と一緒にフランスにいました..."


translate japanese presentation_57251b7a:


    dpense "そして翌日…"


translate japanese presentation_fe665c28:


    dpense "フランスへの旅行のために飛行機に乗っていた…"


translate japanese presentation_f9f78803:


    dpense "アメリカへ！！！！"

translate japanese strings:


    old "You"
    new "あなた"


    old "Press click to continue"
    new "クリックして続ける"


    old "Yes"
    new "はい"


    old "No"
    new "いいえ"


    old "Yes, of course I'm in!!!"
    new "はい、もちろん参加します!!!"


    old "So boring... Ciao!"
    new "つまらない... さようなら！"


    old "Your First Name?"
    new "あなたの名前は？"


    old "Enable Walkthrough"
    new "ウォークスルーを有効にする"


    old "Disable Walkthrough"
    new "ウォークスルーを無効にする"


    old "I'm a good friend, always there for others...[TEMP1!t]"
    new "私は良い友達で、いつも他の人のためにいます...[TEMP1!t]"


    old "I'm a good student, serious and calm...[TEMP2!t]"
    new "私は良い学生で、真面目で冷静です...[TEMP2!t]"


    old "I'm a sport addict, DAMN![TEMP3!t]"
    new "私はスポーツ中毒だ、クソ！[TEMP3!t]"


    old "I'm a Don Juan, girls everywhere, everytime...[TEMP4!t]"
    new "俺はドンファン、どこにでも女の子がいる、いつでも…。"


    old "New Scene Gallery added"
    new "新しいシーンギャラリーが追加されました"




translate japanese before_main_menu_d78d088e:


    ji ""


translate japanese before_main_menu_5a53566a:


    ji ""


translate japanese suitepres_f9826a8e:


    ji ""


translate japanese suitepres_0e21fab0:


    ji ""


translate japanese suitepres2_ce3307b7:


    ji ""


translate japanese suitepres2_da58db29:


    cr ""


translate japanese suitepres2_2682ba1a:


    cr ""


translate japanese suitepres2_ddd41a39:


    cr ""


translate japanese suitepres2_70eedada:


    ji ""


translate japanese suitepres2_254932e8:


    ji ""


translate japanese suitepres2_cac004cf:


    ji ""


translate japanese suitepres2_f868e8c5:


    ji ""


translate japanese suitepres2_6ae30e92:


    cr ""


translate japanese suitepres2_26d958df:


    ji ""


translate japanese suitepres2_71aeb4ea:


    ji ""


translate japanese suitepres2_f4f514d6:


    ji ""


translate japanese suitepres2_71aeb4ea_1:


    ji ""


translate japanese suitepres2_d666e21a:


    ji ""


translate japanese personalize_ed074dc1:


    grace ""


translate japanese personalize_3feba10d:


    grace ""


translate japanese personalize_87cd1f22:


    grace ""


translate japanese personalize_b411b168:


    grace ""


translate japanese personalize_90c2145d:


    grace ""


translate japanese personalize_ed2ea51d:


    grace ""


translate japanese personalize_ea3f8080:


    grace ""


translate japanese personalize_d86da4f2:


    grace ""


translate japanese personalize_ac389665:


    grace ""


translate japanese personalize_e554c344:


    grace ""


translate japanese personalize_ac389665_1:


    grace ""


translate japanese personalize_a8616aea:


    grace ""


translate japanese personalize_ac389665_2:


    grace ""


translate japanese personalize_c3c37204:


    grace ""


translate japanese personalize_5af586fe:


    grace ""


translate japanese personalize_ac389665_3:


    grace ""


translate japanese personalize_c3c37204_1:


    grace ""


translate japanese intro_ea6a1d93:


    ji ""


translate japanese intro_7c65b928:


    ""


translate japanese intro_bcafb91f:


    ""


translate japanese intro_c41004be:


    ""


translate japanese intro_064e378f:


    ""


translate japanese intro_89ca4f05:


    ""


translate japanese intro_1f193dfc:


    ""


translate japanese intro_305a78d2:


    eli ""


translate japanese intro_8cab892c:


    eli ""


translate japanese intro_eac5df1a:


    eli ""


translate japanese intro_ad43f96e:


    eli ""


translate japanese intro_1aea961b:


    eli ""


translate japanese intro_6c492beb:


    eli ""


translate japanese intro_1de5010f:


    ji ""


translate japanese intro_7c65b928_1:


    ""


translate japanese intro_bcafb91f_1:


    ""


translate japanese intro_6d670d0e:


    ""


translate japanese intro_064e378f_1:


    ""


translate japanese intro_89ca4f05_1:


    ""


translate japanese intro_1f193dfc_1:


    ""


translate japanese intro_305a78d2_1:


    eli ""


translate japanese intro_8cab892c_1:


    eli ""


translate japanese intro_eac5df1a_1:


    eli ""


translate japanese intro_ad43f96e_1:


    eli ""


translate japanese intro_1aea961b_1:


    eli ""


translate japanese intro_6c492beb_1:


    eli ""


translate japanese intro_f1f9f153:


    eli ""


translate japanese intro_477f6abf:


    eli ""


translate japanese intro_90929d09:


    d ""


translate japanese intro_73f7f8be:


    eli ""


translate japanese presentation_712108b3:


    dpense ""


translate japanese presentation_17f39f37:


    dpense ""


translate japanese presentation_f0b7f0a4:


    dpense ""


translate japanese presentation_d7cb2ac4:


    dpense ""


translate japanese presentation_bae9b014:


    dpense ""


translate japanese presentation_20aadd2e:


    dpense ""


translate japanese presentation_b64a060f:


    dpense ""


translate japanese presentation_e5e4c3cb:


    dpense ""


translate japanese presentation_43721bcf:


    dpense ""


translate japanese presentation_65a1e9f9:


    dpense ""


translate japanese presentation_8103b4af:


    dpense ""

translate japanese strings:


    old "Yes, of course I'm in!"
    new ""


    old "Not for me, thanks. Ciao!"
    new ""


    old "I'm a good friend, always there for others.[TEMP1!t]"
    new ""


    old "I'm a good student, serious and calm.[TEMP2!t]"
    new ""


    old "I'm a sports junkie, and I'm always hitting the gym![TEMP3!t]"
    new ""


    old "I'm a ladies man, a regular Don Juan or Casanova. [TEMP4!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
