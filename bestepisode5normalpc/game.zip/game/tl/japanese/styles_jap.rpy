translate japanese python:
    gui.text_font = "gui/GL-NovantiquaMinamoto.ttf"
    gui.choice_button_text_font = "gui/GL-NovantiquaMinamoto.ttf"
    gui.interface_text_font = "gui/GL-NovantiquaMinamoto.ttf"
    gui.button_text_font = "gui/GL-NovantiquaMinamoto.ttf"
    gui.name_text_font = "gui/GL-NovantiquaMinamoto.ttf"

translate japanese style _default:
    font "gui/GL-NovantiquaMinamoto.ttf"

translate japanese style phone_messages_text:
    font "gui/GL-NovantiquaMinamoto.ttf"

translate japanese style _phone_application_button_text:
    font "gui/GL-NovantiquaMinamoto.ttf"

translate japanese style phone_contacts_text:
    font "gui/GL-NovantiquaMinamoto.ttf"

translate japanese style phone_list_text:
    font "gui/GL-NovantiquaMinamoto.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
