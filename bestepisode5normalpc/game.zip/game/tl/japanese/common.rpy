

translate japanese strings:


    old "Self-voicing disabled."
    new "音声読み上げ無効。"


    old "Clipboard voicing enabled. "
    new "クリップボードの音声機能が有効になりました。"


    old "Self-voicing enabled. "
    new "音声読み上げが有効になりました。"


    old "bar"
    new "バー"


    old "selected"
    new "選択された"


    old "viewport"
    new "ビューポート"


    old "horizontal scroll"
    new "横方向のスクロール"


    old "vertical scroll"
    new "縦スクロール"


    old "activate"
    new "アクティブにする"


    old "deactivate"
    new "無効にする"


    old "increase"
    new "増加する"


    old "decrease"
    new "減少"


    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "アクセシビリティメニュー。上下の矢印を使ってナビゲートし、エンターでボタンやバーをアクティブにします。"


    old "Font Override"
    new "フォントオーバーライド"


    old "Default"
    new "デフォルト"


    old "DejaVu Sans"
    new "デジャヴ・サンズ"


    old "Opendyslexic"
    new "Opendyslexic"


    old "Text Size Scaling"
    new "テキストサイズのスケーリング"


    old "Reset"
    new "リセット"


    old "Line Spacing Scaling"
    new "行間スケーリング"


    old "High Contrast Text"
    new "ハイコントラストテキスト"


    old "Enable"
    new "有効にする"


    old "Disable"
    new "無効にする"


    old "Self-Voicing"
    new "自声"


    old "Off"
    new "オフ"


    old "Text-to-speech"
    new "テキスト・トゥー・スピーチ"


    old "Clipboard"
    new "クリップボード"


    old "Debug"
    new "デバッグ"


    old "Self-Voicing Volume Drop"
    new "自己音声ボリューム低下"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "このメニューのオプションはアクセシビリティを向上させることを目的としています。それらはすべてのゲームで機能するわけではなく、オプションの組み合わせによってはゲームがプレイできなくなる場合があります。これはゲームやエンジンの問題ではありません。フォントを変更する際は、元のテキストサイズをできるだけ同じに保つと、最良の結果が得られます。"


    old "{#weekday}Monday"
    new "{#weekday}月曜日"


    old "{#weekday}Tuesday"
    new "Tuesday"


    old "{#weekday}Wednesday"
    new "Wednesday"


    old "{#weekday}Thursday"
    new "Thursday"


    old "{#weekday}Friday"
    new "{#weekday}Friday"


    old "{#weekday}Saturday"
    new "{#weekday}土曜日"


    old "{#weekday}Sunday"
    new "{#weekday}日曜日"


    old "{#weekday_short}Mon"
    new "{#weekday_short}月"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Tue"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Wed"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Thu"


    old "{#weekday_short}Fri"
    new "{#weekday_short}金"


    old "{#weekday_short}Sat"
    new "{#weekday_short}土"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Sun"


    old "{#month}January"
    new "{#month}1月"


    old "{#month}February"
    new "{#month}2月"


    old "{#month}March"
    new "{#month}3月"


    old "{#month}April"
    new "{#month}4月"


    old "{#month}May"
    new "{#month}5月"


    old "{#month}June"
    new "{#month}6月"


    old "{#month}July"
    new "{#month}7月"


    old "{#month}August"
    new "{#month}8月"


    old "{#month}September"
    new "{#month}9月"


    old "{#month}October"
    new "{#month}10月"


    old "{#month}November"
    new "{#month}11月"


    old "{#month}December"
    new "{#month}12月"


    old "{#month_short}Jan"
    new "{#month_short}Jan"


    old "{#month_short}Feb"
    new "{#month_short}Feb"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Apr"


    old "{#month_short}May"
    new "{#month_short}May"


    old "{#month_short}Jun"
    new "{#month_short}Jun"


    old "{#month_short}Jul"
    new "{#month_short}Jul"


    old "{#month_short}Aug"
    new ""


    old "{#month_short}Sep"
    new "{#month_short}Sep"


    old "{#month_short}Oct"
    new "{#month_short}Oct"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dec"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "セーブスロット %s: [text]"


    old "Load slot %s: [text]"
    new "スロット %s をロード: [text]"


    old "Delete slot [text]"
    new "スロットを削除する [text]"


    old "File page auto"
    new "ファイルページ自動"


    old "File page quick"
    new "ファイルページのクイック"


    old "File page [text]"
    new "ファイル ページ [text]"


    old "Next file page."
    new "次のファイルページ。"


    old "Previous file page."
    new "前のファイルページ。"


    old "Quick save complete."
    new "クイックセーブが完了しました。"


    old "Quick save."
    new "クイックセーブ。"


    old "Quick load."
    new "クイックロード。"


    old "Language [text]"
    new "言語 [text]"


    old "Open [text] directory."
    new "[text] ディレクトリを開く。"


    old "The interactive director is not enabled here."
    new "インタラクティブディレクターはここでは有効になっていません。"


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "完了"


    old "(statement)"
    new "(statement)"


    old "(tag)"
    new "(tag)"


    old "(attributes)"
    new "(attributes)"


    old "(transform)"
    new "(transform)"


    old "(transition)"
    new "(transition)"


    old "(channel)"
    new "(channel)"


    old "(filename)"
    new "(filename)"


    old "Change"
    new "変更"


    old "Add"
    new "追加"


    old "Cancel"
    new "キャンセル"


    old "Remove"
    new "削除"


    old "Statement:"
    new "ステートメント："


    old "Tag:"
    new "タグ:"


    old "Attributes:"
    new "属性："


    old "Click to toggle attribute, right click to toggle negative attribute."
    new "属性を切り替えるにはクリックし、負の属性を切り替えるには右クリックしてください。"


    old "Transforms:"
    new "変形:"


    old "Click to set transform, right click to add to transform list."
    new "クリックして変換を設定し、右クリックして変換リストに追加します。"


    old "Customize director.transforms to add more transforms."
    new "より多くの変換を追加するには、director.transformsをカスタマイズしてください。"


    old "Behind:"
    new "後ろ："


    old "Click to set, right click to add to behind list."
    new "クリックして設定、右クリックして裏リストに追加。"


    old "Transition:"
    new "遷移:"


    old "Click to set."
    new "クリックして設定する。"


    old "Customize director.transitions to add more transitions."
    new "より多くの遷移を追加するには、director.transitionsをカスタマイズしてください。"


    old "Channel:"
    new "チャンネル："


    old "Customize director.audio_channels to add more channels."
    new "より多くのチャンネルを追加するには、director.audio_channelsをカスタマイズしてください。"


    old "Audio Filename:"
    new "オーディオファイル名:"


    old "Are you sure?"
    new "本当に大丈夫ですか？"


    old "Are you sure you want to delete this save?"
    new "このセーブデータを削除してもよろしいですか？"


    old "Are you sure you want to overwrite your save?"
    new "本当にセーブを上書きしますか？"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "読み込みを行うと、保存されていない進行状況が失われます。\nこれを行ってもよろしいですか？"


    old "Are you sure you want to quit?"
    new "本当にやめますか？"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "本当にメインメニューに戻りますか？\nこれにより、未保存の進行状況が失われます。"


    old "Are you sure you want to continue where you left off?"
    new "あなたは本当に前の続きから始めたくてしょうがないのですか？"


    old "Are you sure you want to end the replay?"
    new "リプレイを終了してもよろしいですか？"


    old "Are you sure you want to begin skipping?"
    new "スキップを始めてもいいですか？"


    old "Are you sure you want to skip to the next choice?"
    new "次の選択肢にスキップしてもいいですか？"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "見ていないダイアログを次の選択肢にスキップしてもよろしいですか？"


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "このセーブは異なるデバイスで作成されました。悪意のあるセーブファイルはあなたのコンピュータに危害を加える可能性があります。このセーブの作成者と、ファイルを変更した可能性のあるすべての人を信頼しますか？"


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "その保存が作成されたデバイスを信頼しますか？デバイスの唯一のユーザーである場合のみ「はい」を選択すべきです。"


    old "Failed to save screenshot as %s."
    new "%sとしてスクリーンショットを保存できませんでした。"


    old "Saved screenshot as %s."
    new "%sとしてスクリーンショットを保存しました。"


    old "Skip Mode"
    new "スキップモード"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "このプログラムには、MITライセンスやGNU LGPLを含む、いくつかのライセンスの下にあるフリーソフトウェアが含まれています。完全なソフトウェアのリストは、フルソースコードへのリンクを含めて{a=https://www.renpy.org/l/license}こちら{/a}で見ることができます。"


    old "display"
    new "表示"


    old "transitions"
    new "遷移"


    old "skip transitions"
    new "トランジションをスキップ"


    old "video sprites"
    new "ビデオスプライト"


    old "show empty window"
    new "空のウィンドウを表示"


    old "text speed"
    new "テキスト速度"


    old "joystick"
    new "ジョイスティック"


    old "joystick..."
    new "ジョイスティック..."


    old "skip"
    new "スキップ"


    old "skip unseen [text]"
    new "未確認をスキップ [text]"


    old "skip unseen text"
    new "未表示のテキストをスキップ"


    old "begin skipping"
    new "スキップを開始する"


    old "after choices"
    new "選択後"


    old "skip after choices"
    new "選択肢の後にスキップ"


    old "auto-forward time"
    new "自動進行時間"


    old "auto-forward"
    new "オートフォワード"


    old "Auto forward"
    new "自動進行"


    old "auto-forward after click"
    new "クリック後に自動フォワード"


    old "automatic move"
    new "自動移動"


    old "wait for voice"
    new "声を待ってください。"


    old "voice sustain"
    new "声の持続"


    old "self voicing"
    new "自己音声化"


    old "self voicing enable"
    new "自己音声を有効にする"


    old "self voicing disable"
    new "自動音声無効"


    old "self voicing volume drop"
    new "自己音声の音量低下"


    old "clipboard voicing"
    new "クリップボード音声"


    old "clipboard voicing enable"
    new "クリップボードの音声を有効にする"


    old "clipboard voicing disable"
    new "クリップボード音声無効"


    old "debug voicing"
    new "デバッグ ボイス"


    old "debug voicing enable"
    new "デバッグ ボイシング 有効"


    old "debug voicing disable"
    new "デバッグ 音声 無効"


    old "emphasize audio"
    new "音声を強調する"


    old "rollback side"
    new "ロールバックサイド"


    old "gl powersave"
    new "グラフィックスの省電力"


    old "gl framerate"
    new "グラフィックスのフレームレート"


    old "gl tearing"
    new "グラフィックのティアリング"


    old "font transform"
    new "フォント変換"


    old "font size"
    new "フォントサイズ"


    old "font line spacing"
    new "フォントの行間"


    old "system cursor"
    new "システム カーソル"


    old "renderer menu"
    new "レンダラーメニュー"


    old "accessibility menu"
    new "アクセシビリティメニュー"


    old "high contrast text"
    new "高コントラストテキスト"


    old "audio when minimized"
    new "最小化時の音声"


    old "audio when unfocused"
    new "フォーカスが外れたときの音"


    old "web cache preload"
    new "ウェブキャッシュのプリロード"


    old "voice after game menu"
    new "ゲームメニューの後の声"


    old "restore window position"
    new "ウィンドウの位置を復元する"


    old "reset"
    new "リセット"


    old "main volume"
    new "メインボリューム"


    old "music volume"
    new "音楽の音量"


    old "sound volume"
    new "サウンドボリューム"


    old "voice volume"
    new "ボイスボリューム"


    old "mute main"
    new "メインをミュートする"


    old "mute music"
    new "音楽を消す"


    old "mute sound"
    new "音を消す"


    old "mute voice"
    new "声をミュートにする"


    old "mute all"
    new "すべてミュート"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "クリップボードの音声化が有効になりました。 'shift+C'を押して無効にしてください。"


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "自己音声は「[renpy.display.tts.last]」と言います。 'alt+shift+V'を押して無効にしてください。"


    old "Self-voicing enabled. Press 'v' to disable."
    new "自声読み上げが有効になりました。 'v' を押して無効にします。"


    old "Speech Bubble Editor"
    new "スピーチバブルエディタ"


    old "(hide)"
    new "(hide)"


    old "(clear retained bubbles)"
    new "(clear retained bubbles)"


    old "Sync downloaded."
    new "同期が完了しました。"


    old "Could not connect to the Ren'Py Sync server."
    new "Ren'Py Syncサーバーに接続できませんでした。"


    old "The Ren'Py Sync server timed out."
    new "Ren'Pyの同期サーバーがタイムアウトしました。"


    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Ren'Py Syncサーバーへの接続中に不明なエラーが発生しました。"


    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "Ren'Py Syncサーバーにはこの同期のコピーがありません。同期IDが無効であるか、タイムアウトした可能性があります。"


    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "生成した同期IDを入力してください。\n自分で作成していない同期IDは絶対に入力しないでください。"


    old "The sync ID is not in the correct format."
    new "同期IDは正しい形式ではありません。"


    old "The sync could not be decrypted."
    new "同期を復号化できませんでした。"


    old "The sync belongs to a different game."
    new "その同期は別のゲームに属しています。"


    old "The sync contains a file with an invalid name."
    new "同期には無効な名前のファイルが含まれています。"


    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "これにより、あなたのセーブデータが{a=https://sync.renpy.org}Ren'Py Sync Server{/a}にアップロードされます。\n続けますか？"


    old "Enter Sync ID"
    new "同期IDを入力してください"


    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "これは{a=https://sync.renpy.org}Ren'Py Sync Server{/a}に接続します。"


    old "Sync Success"
    new "同期成功"


    old "The Sync ID is:"
    new "同期IDは："


    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "このIDを使用して、別のデバイスでセーブをダウンロードできます。\nこの同期は1時間で期限切れになります。\nRen'Py Syncは{a=https://www.renpy.org/sponsors.html}Ren'Pyのスポンサー{/a}によってサポートされています。"


    old "Continue"
    new "続ける"


    old "Sync Error"
    new "同期エラー"


    old "Contacting App Store\nPlease Wait..."
    new "App Storeに連絡しています\nお待ちください..."


    old "No update methods found."
    new "更新方法が見つかりませんでした。"


    old "Could not download file list: "
    new "ファイルリストをダウンロードできませんでした："


    old "File list digest does not match."
    new "ファイルリストのダイジェストが一致しません。"


    old "An error is being simulated."
    new "エラーがシミュレートされています。"


    old "Either this project does not support updating, or the update status file was deleted."
    new "このプロジェクトは更新をサポートしていないか、更新ステータスファイルが削除されました。"


    old "This account does not have permission to perform an update."
    new "このアカウントには更新を行う権限がありません。"


    old "This account does not have permission to write the update log."
    new "このアカウントにはアップデートログを書く権限がありません。"


    old "Could not verify update signature."
    new "更新署名を確認できませんでした。"


    old "The update file was not downloaded."
    new "アップデートファイルはダウンロードされませんでした。"


    old "The update file does not have the correct digest - it may have been corrupted."
    new "アップデートファイルのダイジェストが正しくありません - 破損している可能性があります。"


    old "While unpacking {}, unknown type {}."
    new "{}を解凍中、未知のタイプです{}。"


    old "Updater"
    new "アップデーター"


    old "An error has occured:"
    new "エラーが発生しました："


    old "Checking for updates."
    new "更新を確認しています。"


    old "This program is up to date."
    new "このプログラムは最新です。"


    old "[u.version] is available. Do you want to install it?"
    new "[u.version]が利用可能です。インストールしますか？"


    old "Preparing to download the updates."
    new "アップデートのダウンロードを準備中です。"


    old "Downloading the updates."
    new "更新をダウンロードしています。"


    old "Unpacking the updates."
    new "更新を解凍中。"


    old "Finishing up."
    new "終わろうとしている。"


    old "The updates have been installed. The program will restart."
    new "アップデートがインストールされました。プログラムは再起動します。"


    old "The updates have been installed."
    new "アップデートがインストールされました。"


    old "The updates were cancelled."
    new "アップデートはキャンセルされました。"


    old "Proceed"
    new "進む"


    old "Preparing to download the game data."
    new "ゲームデータのダウンロードを準備しています。"


    old "Downloading the game data."
    new "ゲームデータをダウンロードしています。"


    old "The game data has been downloaded."
    new "ゲームデータがダウンロードされました。"


    old "An error occured when trying to download game data:"
    new "ゲームデータのダウンロード中にエラーが発生しました："


    old "This game cannot be run until the game data has been downloaded."
    new "このゲームは、ゲームデータがダウンロードされるまで実行できません。"


    old "Retry"
    new "再試行"


    old "Image [index] of [count] locked."
    new "画像[index]は[count]でロックされています。"


    old "prev"
    new "前へ"


    old "next"
    new "次"


    old "slideshow"
    new "スライドショー"


    old "return"
    new "返す"


    old "Renderer"
    new "レンダラー"


    old "Automatically Choose"
    new "自動的に選択する"


    old "Force GL Renderer"
    new "GLレンダラーを強制する"


    old "Force ANGLE Renderer"
    new "強制 ANGLE レンダラー"


    old "Force GLES Renderer"
    new "GLESレンダラーを強制する"


    old "Force GL2 Renderer"
    new "GL2レンダラーを強制する"


    old "Force ANGLE2 Renderer"
    new "ANGLE2 レンダラーを強制する"


    old "Force GLES2 Renderer"
    new "GLES2レンダラーを強制する"


    old "Enable (No Blocklist)"
    new "無効にする（ブロックリストなし）"


    old "Powersave"
    new "パワーセーブ"


    old "Framerate"
    new "フレームレート"


    old "Screen"
    new "画面"


    old "60"
    new "60"


    old "30"
    new "３０"


    old "Tearing"
    new "ティアリング"


    old "Changes will take effect the next time this program is run."
    new "変更はこのプログラムが次に実行されるときに有効になります。"


    old "Performance Warning"
    new "パフォーマンス警告"


    old "This computer is using software rendering."
    new "このコンピュータはソフトウェアレンダリングを使用しています。"


    old "This game requires use of GL2 that can't be initialised."
    new "このゲームは初期化できないGL2の使用を必要とします。"


    old "This computer has a problem displaying graphics: [problem]."
    new "このコンピュータはグラフィックスを表示する際に問題があります: [problem]."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "グラフィックスドライバーが古いか、正しく動作していない可能性があります。これにより、グラフィックスの表示が遅くなったり、正しく表示されなかったりすることがあります。"


    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "{a=edit:1:log.txt}log.txt{/a}ファイルには、コンピュータに何が悪いのかを判断するのに役立つ情報が含まれている可能性があります。"


    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "この修正に関する詳細は{a=[url]}ドキュメンテーション{/a}で見つけることができます。"


    old "Continue, Show this warning again"
    new "続ける、もう一度この警告を表示する"


    old "Continue, Don't show warning again"
    new "続ける、警告を表示しない"


    old "Change render options"
    new "レンダリングオプションを変更する"


    old "Select Gamepad to Calibrate"
    new "ゲームパッドをキャリブレーションするために選択してください"


    old "No Gamepads Available"
    new "ゲームパッドが利用できません"


    old "Calibrating [name] ([i]/[total])"
    new "[name]のキャリブレーション中（[i]/[total]）"


    old "Press or move the '[control!s]' [kind]."
    new "'[control!s]' [kind]を押すか、移動してください。"


    old "Skip (A)"
    new "スキップ (A)"


    old "Back (B)"
    new "戻る (B)"


    old "Open"
    new "開く"


    old "Opens the traceback.txt file in a text editor."
    new "traceback.txtファイルをテキストエディタで開きます。"


    old "Copy BBCode"
    new "Copy BBCode"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "traceback.txtファイルをhttps://lemmasoft.renai.us/のようなフォーラム用のBBcodeとしてクリップボードにコピーします。"


    old "Copy Markdown"
    new "Copy Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "traceback.txtファイルをDiscord用のMarkdownとしてクリップボードにコピーします。"


    old "An exception has occurred."
    new "例外が発生しました。"


    old "Rollback"
    new "ロールバック"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "以前の時間にロールバックを試み、保存をしたり、異なる選択肢を選ぶことができます。"


    old "Ignore"
    new "無視"


    old "Ignores the exception, allowing you to continue."
    new "例外を無視し、続行できるようにします。"


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "例外を無視し、続行できるようにします。これにより、追加のエラーが発生することがよくあります。"


    old "Reload"
    new "リロード"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "ディスクからゲームをリロードし、可能であればゲームの状態を保存して復元します。"


    old "Console"
    new "コンソール"


    old "Opens a console to allow debugging the problem."
    new "問題のデバッグを可能にするコンソールを開きます。"


    old "Quits the game."
    new "ゲームを終了する。"


    old "Parsing the script failed."
    new "スクリプトの解析に失敗しました。"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
