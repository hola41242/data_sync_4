

translate japanese strings:


    old "Save"
    new "保存"


    old "Load"
    new "ロード"


    old "Achievements"
    new "実績"


    old "Gallery"
    new "ギャラリー"


    old "Preferences"
    new "好み"


    old "End Replay"
    new "リプレイ終了"


    old "Main Menu"
    new "メインメニュー"


    old "Help"
    new "助けて"


    old "Quit"
    new "辞める"


    old "About"
    new "情報"


    old "Return"
    new "戻る"


    old "Version [config.version!t]\n"
    new "バージョン [config.version!t]"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "作成は{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]によるものです。\n\n[renpy.license!t]"


    old "Page {}"
    new "ページ {}"


    old "Automatic saves"
    new "自動保存"


    old "Quick saves"
    new "クイックセーブ"


    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"


    old "empty slot"
    new "空のスロット"


    old "<"
    new "<"


    old "{#auto_page}A"
    new "{#auto_page}A"


    old "{#quick_page}Q"
    new "{#quick_page}Q"


    old ">"
    new ">"


    old "Save Name"
    new "セーブ名"


    old "{u}Save the Game{/u}"
    new "ゲームを保存する"


    old "Display"
    new "表示"


    old "Window"
    new "ウィンドウ"


    old "Fullscreen"
    new "フルスクリーン"


    old "Skip"
    new "スキップ"


    old "Unseen Text"
    new "見えないテキスト"


    old "After Choices"
    new "選択の後"


    old "Transitions"
    new "遷移"


    old "Language"
    new "言語"


    old "English"
    new "英語"


    old "Français"
    new "フランス語"


    old "Espanol"
    new "エスパニョール"


    old "Italian"
    new "イタリアの"


    old "Russian"
    new "ロシア語"


    old "S.Chinese"
    new "S.中国語"


    old "T.Chinese"
    new "T.中国語"


    old "Portuguese"
    new "ポルトガル語"


    old "Walkthrough"
    new "ウォークスルー"


    old "ON"
    new "オン"


    old "OFF"
    new "オフ"


    old "Text Speed"
    new "テキスト速度"


    old "Auto-Forward Time"
    new "自動進行時間"


    old "Textbox Transparency"
    new "テキストボックスの透明度"


    old "Music Volume"
    new "音楽の音量"


    old "Sound Volume"
    new "音量"


    old "Test"
    new "テスト"


    old "Voice Volume"
    new "声のボリューム"


    old "Mute All"
    new "すべてミュート"


    old "History"
    new "歴史"


    old "The dialogue history is empty."
    new "対話履歴は空です。"


    old "Keyboard"
    new "キーボード"


    old "Mouse"
    new "マウス"


    old "Gamepad"
    new "ゲームパッド"


    old "Enter"
    new "エンター"


    old "Advances dialogue and activates the interface."
    new "ダイアログを進めてインターフェースを起動します。"


    old "Space"
    new "スペース"


    old "Advances dialogue without selecting choices."
    new "選択肢を選ばずにダイアログを進める。"


    old "Arrow Keys"
    new "矢印キー"


    old "Navigate the interface."
    new "インターフェースをナビゲートする。"


    old "Escape"
    new "エスケープ"


    old "Accesses the game menu."
    new "ゲームメニューにアクセスします。"


    old "Ctrl"
    new "コントロール"


    old "Skips dialogue while held down."
    new "押し続けるとセリフをスキップします。"


    old "Tab"
    new "タブ"


    old "Toggles dialogue skipping."
    new "ダイアログのスキップを切り替えます。"


    old "Page Up"
    new "ページアップ"


    old "Rolls back to earlier dialogue."
    new "以前の対話に戻る。"


    old "Page Down"
    new "ページダウン"


    old "Rolls forward to later dialogue."
    new "後の対話に進みます。"


    old "Hides the user interface."
    new "ユーザーインターフェースを隠します。"


    old "Takes a screenshot."
    new "スクリーンショットを撮る。"


    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "支援機能を切り替えます {a=https://www.renpy.org/l/voicing}自己音声{/a}。"


    old "Opens the accessibility menu."
    new "アクセシビリティメニューを開きます。"


    old "Left Click"
    new "左クリック"


    old "Middle Click"
    new "ミドルクリック"


    old "Right Click"
    new "右クリック"


    old "Mouse Wheel Up\nClick Rollback Side"
    new "マウスホイールを上に回す\nクリックして巻き戻し側"


    old "Mouse Wheel Down"
    new "マウスホイールを下に回す"


    old "Right Trigger\nA/Bottom Button"
    new "右トリガー\nA/ボタン"


    old "Left Trigger\nLeft Shoulder"
    new "左トリガー\n左ショルダー"


    old "Right Shoulder"
    new "右肩"


    old "D-Pad, Sticks"
    new "Dパッド、スティック"


    old "Start, Guide"
    new "開始、ガイド"


    old "Y/Top Button"
    new "Y/トップボタン"


    old "Calibrate"
    new "キャリブレート"


    old "Skipping"
    new "スキップ"


    old "Back"
    new "戻る"


    old "Auto"
    new "自動"


    old "Menu"
    new "メニュー"



translate japanese strings:


    old "Japanese"
    new "日本語"



translate japanese strings:


    old "Name Save ?"
    new ""


    old "Save game names"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
