

translate japanese strings:


    old "Replayer"
    new "リプレイヤー"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
