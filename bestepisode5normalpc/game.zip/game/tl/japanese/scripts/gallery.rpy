

translate japanese strings:


    old "Rufus Found : [persistent.rufusgame] / 9"
    new "ルーファスが見つかりました : [persistent.rufusgame] / 9"



translate japanese strings:


    old "Rufus Found : [persistent.rufusgame] / 15"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
