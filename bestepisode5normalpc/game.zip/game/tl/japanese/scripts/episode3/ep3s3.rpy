


translate japanese ep3s3_2ddd95bb:


    dpense "また一日…また大学の授業…"


translate japanese ep3s3_dc432cdc:


    dpense "みんなここにいる。"


translate japanese ep3s3_4e7dabcc:


    dpense "ブルーは今日は少し...違うようだ。"


translate japanese ep3s3_e3e365da:


    dpense "彼女は私を待っていますか？"


translate japanese ep3s3_196077bc:


    dpense "彼女は青いメイクをしていない。"


translate japanese ep3s3_7d7d8bab:


    dpense "今日はみんな綺麗に見える。"


translate japanese ep3s3_051fbf9a:


    dpense "マディソンも、新しい髪型で。"


translate japanese ep3s3_eb478b29:


    dpense "最近の髪型はどうしたの？"


translate japanese ep3s3_78d0ae4a:


    dpense "レッドはスティーブンと一緒です..."


translate japanese ep3s3_dec237ba:


    dpense "誰かに対して陰謀を巡らせているかもしれない..."


translate japanese ep3s3_ae753f0b:


    dpense "その二人は一緒に..."


translate japanese ep3s3_9d146b53:


    dpense "それを避けるようにする..."


translate japanese ep3s3_948122a8:


    dpense "大学内でのトラブルは本当に必要ありません..."


translate japanese ep3s3_68ac6f64:


    beth "こんにちは、ハンサム！"


translate japanese ep3s3_5dda0f88:


    d "ん？"


translate japanese ep3s3_c9c1336f:


    beth "聞いてください、次のクラスでは挑戦があります。"


translate japanese ep3s3_c4dae10d:


    d "どうして知っているの？"


translate japanese ep3s3_87807a25:


    beth "気にしないでください。ただ覚えていてください、いくつかの質問が含まれることになります。"


translate japanese ep3s3_6b4b1159:


    beth "回答では、決してDを選ばないでください..."


translate japanese ep3s3_dd5d68f3:


    d "え？"


translate japanese ep3s3_2508ad6c:


    beth "A、B、C、D... 決してDではない！わかりますか？"


translate japanese ep3s3_b69cc98d:


    d "でも、どうしてそれを知っているの？"


translate japanese ep3s3_a5f7a2d0:


    beth "ただ信じて、これだけでいいの！"


translate japanese ep3s3_7bcc50f4:


    d "わかりました..."


translate japanese ep3s3_0b732a56:


    sofia "次のテストを手伝うことができる。"


translate japanese ep3s3_bec902dc:


    d "どうしてそうなの？"


translate japanese ep3s3_010257d7:


    sofia "そこでは、授業中に、最後にテストがあります。"


translate japanese ep3s3_01c7de32:


    d "テスト？"


translate japanese ep3s3_3d972ad4:


    sofia "はい。とにかく、画像の中でポイントを見つける必要がある質問があります。"


translate japanese ep3s3_44b10ff2:


    d "うーん...わかりました。"


translate japanese ep3s3_99269401:


    sofia "質問のドットをクリックしてください。"


translate japanese ep3s3_37c947b7:


    d "ドットをクリックするとはどういう意味ですか？"


translate japanese ep3s3_039ea5b7:


    sofia "ああ、あなたは遅い！"


translate japanese ep3s3_7e8a2cca:


    sofia "とにかく、ポイントに関する質問があるときは、画像を見ずに点を押すだけです、それだけ。"


translate japanese ep3s3_013db366:


    d "大丈夫、やってみるよ。"


translate japanese ep3s3_065c8531:


    sofia "あなたは成功する必要があります。そして、私は助けるために全てを尽くします。"


translate japanese ep3s3_bbaee512:


    d "あの... ありがとう？"


translate japanese ep3s3_e80e7368:


    sofia "またね。"


translate japanese ep3s3_5d27ba6f:


    gaby "おはようございます、皆さん。"


translate japanese ep3s3_53d46b9f:


    gaby "テーブルごとに一人ずつ座ってください！"


translate japanese ep3s3_43b49e4c:


    d "わかりました。"


translate japanese ep3s3_693e08b4:


    gaby "今日は商業について、特にその起源について少しお話しします。"


translate japanese ep3s3_672697a3:


    gaby "最も古い商業の形態の一つは何だと思いますか？"


translate japanese ep3s3_bb9e3929:


    d "お金の到着？"


translate japanese ep3s3_21d685ea:


    gaby "うーん、それは良い考えだけど、まだ最近すぎる。"


translate japanese ep3s3_f67ff181:


    gaby "お金とそれに関連する経済は、ローマ人によって彼らの市場で確立されました。"


translate japanese ep3s3_498ed84d:


    d "部族間の贈り物？"


translate japanese ep3s3_3001538f:


    gaby "まあ、それは悪くない答えですが、商業の概念は交換を意味します。"


translate japanese ep3s3_7244dc6f:


    gaby "儀式の際に、部族間で保護を得るために神聖または戦略的な贈り物がよく使用されたにもかかわらず。"


translate japanese ep3s3_9523ba64:


    gaby "それは商取引と呼ぶには少し違っていた。"


translate japanese ep3s3_799d5576:


    d "交換？"


translate japanese ep3s3_c9667fb0:


    gaby "それは素晴らしい答えです！"


translate japanese ep3s3_b1ef523b:


    gaby "バーターは、定住を始める多くの部族にとって、村での交換手段でした。"


translate japanese ep3s3_3abd7c0d:


    gaby "それは価値、数量、そして所有権の概念を確立しました。"


translate japanese ep3s3_c1748d43:


    gaby "これらの概念は今日でも依然として関連性があり、特に株式市場においては、株の価値、株式数、そしてこれらの株式の所有者に見られます。"


translate japanese ep3s3_c43fcdc4:


    d "売春？"


translate japanese ep3s3_1d22fb2c:


    gaby "何？"


translate japanese ep3s3_62da3e44:


    d "体を使ってお金を稼ぐなんて！"


translate japanese ep3s3_f9cc5397:


    gaby "おお！"


translate japanese ep3s3_7789f8f3:


    gaby "それについては全く考えていなかった。しかし、それが正しい可能性もあり得た。ただし、私たちが知っている売春はもっと後になってから現れた。"


translate japanese ep3s3_70cb96c7:


    gaby "お金の出現とともに、文明、そして共同生活が生まれました。"


translate japanese ep3s3_d699719c:


    gaby "以前、そのような関係はむしろ... 獣的で、本能や部族によって支配されていました。"


translate japanese suitecourseco0_ac74b583:


    gaby "いいえ、それは物々交換でした。"


translate japanese suitecourseco0_1f6d8475:


    gaby "バザーは、多くの部族が定住化の過程で村に定住し始める際の交易手段であった。"


translate japanese suitecourseco0_3abd7c0d:


    gaby "それは、価値、数量、所有権の概念を確立しました。"


translate japanese suitecourseco0_c1748d43:


    gaby "これらの概念は今日でも依然として関連性があり、特に株式市場では、株の価値、株式数、そしてこれらの株の所有者に見られます。"


translate japanese suitecourseco_eb10b496:


    gaby "そうですね、今日の私たちが持っているものの基盤は過去にあるのです。"


translate japanese suitecourseco_b7e5c992:


    gaby "何かの起源を知ることで、その働きや効果を理解することは、しばしば学びと進化の最良の方法です。"


translate japanese suitecourseco_6b8ee6cc:


    gaby "この件について、明日博物館でジュラ紀と新石器時代の生活に関する展示があります。"


translate japanese suitecourseco_5917ed0d:


    gaby "[name]、正しい答えをくれたので、この展示会に一緒に行きませんか？"


translate japanese suitecourseco_b9239156:


    d "私はとても嬉しいです！"


translate japanese suitecourseco_b21afd26:


    gaby "完璧です。授業の終わりに私のところに来てください。"


translate japanese suitecourseco_094116c0:


    d "はい、マダム。"


translate japanese suitecourseco_fe3248b2:


    d "ああ、ごめんなさい、でも明日はもう予定が入っています。"


translate japanese suitecourseco_d51f7177:


    gaby "あれ？他に誰かいる？"


translate japanese suitecourseco_c8be3742:


    ji "私です、おりょうさん！"


translate japanese suitecourseco_df0cb0e4:


    gaby "もちろん…"


translate japanese suitecourseco_a685ef35:


    gaby "誰か一緒に来てくれませんか？"


translate japanese suitecourseco_7e3f71e4:


    ji "" with hpunch


translate japanese suitecourseco_77e4be5c:


    ji "" with hpunch


translate japanese suitecourseco_ee90ce3a:


    ruby "マダム！フランスから来たばかりの学生が、知らない街の新しい場所を見るのは面白いと思いませんか？"


translate japanese suitecourseco_c4afb5bd:


    ruby "結局、起源を知らずに都市を知ることができるのだろうか、そしてそれを彼に示すのに博物館より良い場所はないだろうか。"


translate japanese suitecourseco_d6d0fc86:


    ruby "それがあなたが今言ったことですよね？"


translate japanese suitecourseco_988772c9:


    gaby "あなたが正しい！"


translate japanese suitecourseco_ff59d716:


    gaby "[name]、この展覧会に私と一緒に来てくれませんか？"


translate japanese suitecourseco_b9239156_1:


    d "私はとても喜びます！"


translate japanese suitecourseco_b21afd26_1:


    gaby "完璧です。授業の終わりに私に会いに来てください。"


translate japanese suitecourseco_094116c0_1:


    d "はい、マ'am。"


translate japanese suitecourseco_fe3248b2_1:


    d "ああ、いいえ、ごめんなさい。でも、明日はすでに予定があります。"


translate japanese suitecourseco_d51f7177_1:


    gaby "ああ？他に誰かいる？"


translate japanese suitecourseco_c8be3742_1:


    ji "私、マダム！"


translate japanese suitecourseco_df0cb0e4_1:


    gaby "とても良い..."


translate japanese suitecourseco_3302879f:


    gaby "授業の後、私に会いに来てください。"


translate japanese preepreuve_7c509ee7:


    gaby "だから私たちは見た..."


translate japanese preepreuve_f1b10217:


    drew "B.E.S.Tの全ての参加者へ！"


translate japanese preepreuve_f3581df3:


    drew "あなたは質問に答えるためのタブレットを受け取ることになります。"


translate japanese preepreuve_0e0e1ad0:


    drew "これらの質問は、あなたの論理、推論能力、一般的な知識を評価するのに役立ちます。"


translate japanese preepreuve_ea74468a:


    drew "B.E.S.Tであることは、私たちの周りの挑戦に対して鋭い思考を持つことを意味します。"


translate japanese preepreuve_b8b787a7:


    drew "テストの開始時には、出題される十問に答えるために3分間があります。"


translate japanese preepreuve_6c53b35c:


    drew "質問の答えがわからない場合は、スキップしても構いません。"


translate japanese preepreuve_32c8c257:


    drew "質問に答えないことは、排除を意味するわけではありません。"


translate japanese preepreuve_4a68b967:


    drew "しかし、あなたの総合得点は評価され、ランキングの最下位の十人の学生は脱落します。"


translate japanese preepreuve_48d61694:


    drew "繰り返しますが、あなたには十の質問に答えるために三分間あります。"


translate japanese preepreuve_64c124f1:


    drew "あなたは質問をスキップできますが、スコアは最後に評価され、最後の十問は除外されます。"


translate japanese preepreuve_7e2c012b:


    drew "みんなに幸運を。"


translate japanese postepreuve_4a800c5f:


    gaby "タブレットをしまっても大丈夫です。"


translate japanese postepreuve_0d6e0638:


    gaby "今日の授業はこれで終了です。"


translate japanese postepreuve_c5fbc9ab:


    gaby "[name]、数分間私と一緒にいてくれますか？"


translate japanese postepreuve_2d1667b9:


    d "もちろん！"


translate japanese postepreuve_b7e2f84a:


    gaby "皆さん、良い一日を！"


translate japanese gabimusee1_d993aed7:


    gaby "明日、午後2時頃に博物館であなたを待っています。それはあなたにとって都合がいいですか？"


translate japanese gabimusee1_32e2a5d2:


    gaby "今晩パーティーがあることはわかっているので、早く起きるとは期待していません。"


translate japanese gabimusee1_d52492ad:


    d "それは私にとっては大丈夫です！"


translate japanese gabimusee1_d89a5895:


    gaby "訪問を楽しんでいただけるといいですね。"


translate japanese gabimusee1_17580177:


    d "心配しないで、君と一緒にいる限り、世界のどこにいても幸せだよ。"


translate japanese gabimusee1_2dad25e0:


    gaby "それはちょっと臭いですね… 自信過剰にならないでください、若者よ。"


translate japanese gabimusee1_cd1d68c1:


    gaby "これはただの訪問で、デートではありません。"


translate japanese gabimusee1_9c209113:


    d "それが両方にならないのはなぜですか？"


translate japanese gabimusee1_54945a89:


    gaby "何？いや！"


translate japanese gabimusee1_40091c60:


    d "はは！明日お会いしましょう、私の貴婦人！"


translate japanese gabimusee1_6e90ecf8:


    gaby "お姉様？"


translate japanese gabimusee1_48876117:


    gaby "..."


translate japanese afterepreuve_49d76cd7:


    d "さて、皆さん、どうだった？"


translate japanese afterepreuve_9db1793b:


    mad "スムーズで、かなり簡単だった。"


translate japanese afterepreuve_94a379b9:


    ruby "うん、悪くない！"


translate japanese afterepreuve_df08b2d1:


    grace "いくつかの質問に苦労しました。"


translate japanese afterepreuve_5134a24b:


    mad "君たちはどのランクになったの？"


translate japanese afterepreuve_c3762510:


    ruby "13位を獲得した！"


translate japanese afterepreuve_6fb2ffbf:


    grace "私にとって31日..."


translate japanese afterepreuve_f4af23e0:


    mad "私は2番目です... 1番目は誰だと思いますか..."


translate japanese afterepreuve_62fb39a8:


    d "うん？"


translate japanese afterepreuve_5c9d97f5:


    emerick "誰がB.E.S.Tですか？"


translate japanese afterepreuve_8144b71e:


    "あなた！"


translate japanese afterepreuve_b89e940c:


    grace "エメリック..."


translate japanese afterepreuve_41884caf:


    grace "そして、[name]？"


translate japanese afterepreuve_b620d1f0:


    d "私は[Rank]にいます。"


translate japanese afterepreuve_2d7cab0e:


    grace "素晴らしい！"


translate japanese afterepreuve_1cdd7644:


    ruby "ジュリアは免除されたと思う、彼女は15位だと思う…。"


translate japanese afterepreuve_c0599f41:


    mad "免除された？"


translate japanese afterepreuve_a1a0d10a:


    mad "そうだね、彼女は今日はいなかった。"


translate japanese afterepreuve_7910c319:


    ruby "ああ、ドリューさんが以前何かの発砲について話しているのを聞きました。"


translate japanese afterepreuve_f8a6ff1c:


    d "昨夜、私はそこにいました..."


translate japanese afterepreuve_efd85f70:


    grace "何？"


translate japanese afterepreuve_75d8ffec:


    d "昨夜家に帰る途中、ヘクターと彼の仲間がジュリアを襲っているのを見かけた。"


translate japanese afterepreuve_c9393e49:


    grace "本当に？"


translate japanese afterepreuve_25ef201b:


    grace "あのクソ野郎！"


translate japanese afterepreuve_1094b572:


    d "私が入ったとき、彼らは逃げたが、彼女の背中には少し痛みがあった。"


translate japanese afterepreuve_1a886072:


    ruby "うーん... それで納得がいった。"


translate japanese afterepreuve_4067eee5:


    ruby "ブルルルルル... もし私がもっと強ければ、彼らを下に掴んでペーストにしてしまうのに。"


translate japanese afterepreuve_221a7213:


    ruby "彼らをペーストに潰すことから始めるだろう..."


translate japanese afterepreuve_cdfa9673:


    ruby "そしたら、彼らが弾けるまで粉砕するだろう..."


translate japanese afterepreuve_63bcf30e:


    ruby "彼らを切り刻んで、ブレンダーに投げ込むだろう…"


translate japanese afterepreuve_7523033d:


    ruby "私は..."


translate japanese afterepreuve_136f81dc:


    d "ルビー？"


translate japanese afterepreuve_b09db3c1:


    d "少し調子に乗りすぎていないか？"


translate japanese afterepreuve_585a72a2:


    ruby "あれ？うん...ごめん..."


translate japanese afterepreuve_fb656274:


    mad "心配しないで、私たちはフィールドで彼らを粉砕するつもりだ！"


translate japanese afterepreuve_2307991b:


    ruby "何？"


translate japanese afterepreuve_6be94e9a:


    mad "抽選が行われた... 彼らが次の相手だ..."


translate japanese afterepreuve_5f32c47f:


    ruby "あら？"


translate japanese afterepreuve_ea7bcd1b:


    ruby "はい！"


translate japanese afterepreuve_e13999ea:


    ruby "ええと… 今夜のためにやることがある！"


translate japanese afterepreuve_49591a81:


    ruby "出発する準備はできた、グレース？"


translate japanese afterepreuve_eb67e331:


    grace "あなたのすぐ後ろ。"


translate japanese afterepreuve_22a275e6:


    mad "今晩は娘を見ているので、夜にまた連絡します。"


translate japanese afterepreuve_e7e750c1:


    grace "心配いらない。"


translate japanese afterepreuve_47debeb0:


    ruby "じゃあ…今晩会いましょうか？"


translate japanese afterepreuve_030945bb:


    mad "じゃね！"


translate japanese afterepreuve_4cf42b7d:


    d "またね！"


translate japanese afterepreuve_c9415513:


    dpense "今晩までまだ少し時間がある。"


translate japanese afterepreuve_194a59d5:


    dpense "トレーニングを続けることもできるが…"


translate japanese afterepreuve_d9e0a872:


    dpense "今晩の前に少しリラックスしてもいいかも。今晩はかなり楽しい夜になりそうだ！"

translate japanese strings:


    old "10:30 AM"
    new "10:30 AM"


    old "The appearance of money?"
    new "お金の外見？"


    old "Gifts?"
    new "プレゼント？"


    old "Barter?[TEMP1!t]"
    new "物々交換？[TEMP1!t]"


    old "Prostitution?"
    new "売春？"


    old "Yes[TEMP1!t]"
    new "はい[TEMP1!t]"


    old "No[TEMP2!t]"
    new "いいえ[TEMP2!t]"




translate japanese preepreuve_6964222b:


    ""


translate japanese preepreuve_692de64d:


    ""

translate japanese strings:


    old "Do you want to skip the quiz?"
    new ""




translate japanese preepreuve_3eb12593:


    ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
