


translate japanese ep3s2c_fa64e7e4:


    d "おはようございます、ドリューさん。"


translate japanese ep3s2c_2f405874:


    drew "ああ！[name]！本当に驚かされた。"


translate japanese ep3s2c_e40f222b:


    drew "何があなたをここに連れてきましたか？"


translate japanese ep3s2c_30793e1a:


    d "グレースに会いに来ました。"


translate japanese ep3s2c_eb73b104:


    drew "彼女はちょうど終わりかけているので、すぐに下に来るでしょう。"


translate japanese ep3s2c_505dea50:


    drew "最近、あなたたち二人はかなり親しくなったようですね…"


translate japanese ep3s2c_c31186bc:


    d "はい、私たちは一緒に多くの時間を過ごしています。"


translate japanese ep3s2c_6dac8fb4:


    drew "心配しないで、私はそれをとても愛らしいと思っています。"


translate japanese ep3s2c_bf615426:


    drew "彼女を近くに保とう。この競技で彼女を遠くへ連れて行こう。"


translate japanese ep3s2c_019d7b3d:


    d "同意しますか？"


translate japanese ep3s2c_0697ca82:


    drew "私は見ていましたよ。正直言って、とても感心しています。"


translate japanese ep3s2c_3deed7ed:


    d "本当に？"


translate japanese ep3s2c_03f5de77:


    drew "はい、私は心からお二人が成功することを願っています。"


translate japanese ep3s2c_74782c19:


    drew "君のことを見守っているけれど。"


translate japanese ep3s2c_8407fa45:


    drew "今のところ、私はあなたが私の娘と付き合っていることに満足しています。"


translate japanese ep3s2c_eee464d8:


    drew "でも覚えておいて、彼女は勝たなければならない。"


translate japanese ep3s2c_ae5eb82d:


    d "私も？"


translate japanese ep3s2c_fe8d23fa:


    drew "一緒に勝つべきだ。"


translate japanese ep3s2c_169b9f75:


    drew "感謝の気持ちを示す方法を知っています。あなたが進めば進むほど、報酬は大きくなります。"


translate japanese ep3s2c_54957448:


    d "報酬？"


translate japanese ep3s2c_e014bf88:


    drew "今のところ、あなたの報酬はいつでも私の娘を見ることです。"


translate japanese ep3s2c_7eb0d926:


    drew "しかし、あなたは彼女だけでなく、他の人々の目も引いていることに気を付けてください…"


translate japanese ep3s2c_f1b55811:


    drew "さあ行って、彼女が待っているよ。そして遅れないで。"


translate japanese ep3s2c_06c2d188:


    d "理解している。"


translate japanese ep3s2c_2c7fb1a0:


    drew "ああ、行く前に… 最初の答えはギザ…"


translate japanese ep3s2c_94518b14:


    dpense "それは何を意味しているのか？"


translate japanese ep3s2c_d05736e9:


    drew "その時が来れば、あなたには分かるでしょう。"


translate japanese ep3s2c_30bbb352:


    drew "ちょっとしたボーナスと考えてください。"


translate japanese ep3s2c_06c2d188_1:


    d "理解している。"


translate japanese ep3s2c_8bd88703:


    dpense "彼女はそれで何を意味していたのか？"


translate japanese ep3s2c_d981fc7b:


    dpense "奇妙だ…"


translate japanese ep3s2c_50b572ee:


    dpense "では、グレースの部屋に行ってきます…"


translate japanese ep3s2c_b6805db4:


    grace "ああ、[name]。"


translate japanese ep3s2c_627b921c:


    d "お邪魔じゃなければいいけど？"


translate japanese ep3s2c_ca4039c3:


    grace "全くそうではない、私はちょうど準備を終えたところです。"


translate japanese ep3s2c_9b902222:


    d "あなたは素晴らしいです。"


translate japanese ep3s2c_8390f9cc:


    grace "やめて、私を赤面させるつもり？"


translate japanese ep3s2c_9a8a1bb6:


    d "キスしてもいいですか？"


translate japanese ep3s2c_a9bed95f:


    grace "5月ですか？ほぼ必須ですよ！"


translate japanese ep3s2c_495bb525:


    d "あなたの母は私たちに祝福を与えたようです。"


translate japanese ep3s2c_98ebbfd9:


    grace "本当に？彼女は何を言ったの？"


translate japanese ep3s2c_a70b9367:


    d "彼女は私たちが一緒に過ごす時間が多いことに気づいた…"


translate japanese ep3s2c_4f14570b:


    grace "実はそれについて話したかった。"


translate japanese ep3s2c_01edd90d:


    grace "聞いて、私たちがこの競技にいる間は、これを私たちの小さな秘密にしておこう。"


translate japanese ep3s2c_e3b20b7b:


    d "なぜ？"


translate japanese ep3s2c_dffb0ec1:


    grace "ここにあるすべてが私たちに対して使われる可能性があります。"


translate japanese ep3s2c_5703408b:


    grace "そして今晩… パーティーの後、私たちはたくさんの時間があるから…"


translate japanese ep3s2c_4dd2a10c:


    grace "ああ！あなたの手が私に触れるとき、私はそれが大好きです。"


translate japanese ep3s2c_eb3879c2:


    d "あなたの肌の感触が大好きです。"


translate japanese ep3s2c_31c40958:


    grace "あ..."


translate japanese ep3s2c_5c868772:


    grace "うーん..."


translate japanese ep3s2c_7126ab4d:


    grace "止めてくれ、さもないと自分を止められなくなる。"


translate japanese ep3s2c_27faf88b:


    grace "今夜…"


translate japanese ep3s2c_433869b9:


    d "今晩の準備はできていますか？"


translate japanese ep3s2c_499297e6:


    grace "実は、今大学の授業に向かっていて、その後ルビーと会います。午後はすべての準備をする予定です。"


translate japanese ep3s2c_7dd8afa4:


    grace "彼女はたくさん計画を立てた！"


translate japanese ep3s2c_60371a03:


    d "本当に？それなら、私は来て邪魔しないよ！"


translate japanese ep3s2c_4082c591:


    grace "やめたほうがいい。"


translate japanese ep3s2c_97610549:


    grace "特にルビーに対しては。彼女の邪魔をすると、大変なことになる。"


translate japanese ep3s2c_2c0572e7:


    d "それに参加する？ ルビーから？"


translate japanese ep3s2c_44e82c85:


    grace "ああ、そうですね、彼女が集中しているときは、邪魔しない方がいいです。"


translate japanese ep3s2c_eee5a2a8:


    d "何時に到着すればいいですか？"


translate japanese ep3s2c_36b419b1:


    grace "パーティーは午後9時から始まりますが、準備のために午後8時に来てもいいですよ。"


translate japanese ep3s2c_26b2a481:


    d "それは私にとって問題ありません。"


translate japanese ep3s2c_c349746e:


    grace "そして、お忘れなく、今夜のテーマはシックとショックです。"


translate japanese ep3s2c_ed1501d9:


    d "はい、まだ何を着るべきか迷っています。どうやって着るつもりなのかもわかりません。"


translate japanese ep3s2c_ba22db80:


    grace "私の理解する限り、ルビーはあなたがスーツを持っていると言っていました... それはレッドが持ってくることになっています。"


translate japanese ep3s2c_ec5e29a1:


    grace "そうでないなら、もう一つある。父のものだから、心配しないで、すべては整っている。"


translate japanese ep3s2c_1d7c521b:


    grace "とにかく、ルビーは何かがうまくいかない場合に備えてバックアップリストを持っています。"


translate japanese ep3s2c_935db071:


    grace "彼女はバックアップリストのためのバックアップまで持っている…。"


translate japanese ep3s2c_06c2d188_2:


    d "理解している。"


translate japanese ep3s2c_c5790358:


    grace "下に降りて... 二分で準備するから。"


translate japanese ep3s2c_bfde5076:


    d "わあ…あなたは美しいです。"


translate japanese ep3s2c_4f3d4452:


    grace "君もなかなかやるじゃないか！"


translate japanese ep3s2c_4e193a9e:


    grace "さあ、遅れないようにしましょう。"


translate japanese ep3s2c_ffe847fc:


    grace "行こう！"


translate japanese ep3s2c_b4b50c32:


    d "行こう！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
