


translate japanese ep3s1_4b26bc0b:


    dpense "うーん... なんて爽やかな夜の眠りなんだろう。今日は忙しそうだけど、私は準備万端だ。"


translate japanese ep3s1_be8d8a59:


    dpense "今夜、大きなパーティーがある。良い印象を与えなければならない。会ったことがない人たちがいて、もちろん、女の子たちも来る。"


translate japanese ep3s1_ab10fc20:


    dpense "それは記録に残るものになるだろう。"


translate japanese ep3s1_251d6609:


    dpense "ジュリアの様子を見に行こうと思う。彼女が大丈夫であることを願っている。"


translate japanese ep3s1_cbf61221:


    dpense "昨日の彼女が経験したことを考えると、今日はあまり気分が良くないに違いありません。"


translate japanese ep3s1_83d877ff:


    dpense "彼女が少し家にいるのは驚くことではない。"


translate japanese ep3s1_1ec5d604:


    dpense "さあ、これからの一日に集中しよう！"


translate japanese ep3s1_e9a08faa:


    dpense "ルビーがすべての手配をしている。授業の前に彼女の家に朝食を食べに行くべきかな？彼女にはエネルギーが必要だ！"


translate japanese ep3s1_d1c4015e:


    dpense "月曜日にトーナメントがあります。まだ自分の望む場所には達していません... 授業が始まる前にジムに行くべきかもしれませんか？"


translate japanese ep3s1_58decb74:


    dpense "グレースを迎えに行くべきかな？昨日のことがあったから…私たちは話す必要があると思う。"


translate japanese ep3s1_23383d89:


    dpense "よし、何が来ても私は準備ができている。"

translate japanese strings:


    old "8:30 AM"
    new "午前8時30分"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
