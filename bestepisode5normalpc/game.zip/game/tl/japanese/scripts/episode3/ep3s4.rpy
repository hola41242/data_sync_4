


translate japanese Training2_2314b734:


    dpense "地面に足を植え込む..."


translate japanese Training2_6a4e888c:


    dpense "得点を取りたいなら、もっと力を入れる必要がある…"


translate japanese Training2_dbd94726:


    ji "" with vpunch


translate japanese Training2_62e760ef:


    ji "勝つつもりなら、もっと努力しないとダメだよね！"


translate japanese Training2_f7499b79:


    ji "ボールを渡して！"


translate japanese Training2_cba91d2b:


    ji "あれを見て！"


translate japanese Training2_43398bf1:


    d "なんだと…"


translate japanese Training2_0144d7f9:


    d "ん？"


translate japanese Training2_d83c8599:


    d "でも..."


translate japanese Training2_62ecd993:


    d "あなたは誰ですか？"


translate japanese Training2_c2e66dfd:


    ji "私が誰かを知っても、あなたには全く役に立ちません。"


translate japanese Training2_5e4b894c:


    ji "私と対面するのを本当に楽しみにしているので、トレーニングを続けてください。"


translate japanese Training2_8926922d:


    ji "決勝戦で会いましょう..."


translate japanese Training2_9d7f15ed:


    ji "その地点まで行ければ。"


translate japanese Training2_e8e8e63a:


    d "お...けい..."


translate japanese Training2_7994d614:


    dpense "本当にレベルアップしなければならない..."


translate japanese Training2_08535ece:


    dpense "その女の子は少しshotがある..."


translate japanese Training2_ce2cd1a5:


    dpense "ボールの周りで風が回るのをほとんど感じた..."


translate japanese Training2_86048621:


    dpense "さあ... 戻りましょう！"


translate japanese Chambreep3_7d909d2f:


    dpense "うーん…今何時ですか？"


translate japanese Chambreep3_cb1c8beb:


    dpense "午後5時30分"


translate japanese Chambreep3_2aa2e6be:


    dpense "もうすぐ出かけるべきだ。"


translate japanese Chambreep3_ed39d6a5:


    dpense "エリーゼが寝る前にメッセージを送るべきかもしれない…"


translate japanese Chambreep3_37e64b70:


    dpense "..."


translate japanese Chambreep3_6f5ea18e:


    dpense "返事がありませんか？"


translate japanese Chambreep3_5284f567:


    dpense "それは奇妙だ...彼女は通常、3秒以内に返信するのに..."


translate japanese Chambreep3_9c2712db:


    dpense "他に誰か必要なものはありますか？"


translate japanese Chambreep3_68c57ca6:


    dpense "ルビーは忙しいに違いない…私は彼女を煩わせない…"


translate japanese Chambreep3_0d47971e:


    dpense "誰にメッセージを送るべきですか？"


translate japanese Chambreep3_3a83ddfa:


    dpense "おお！私の電話のアップデートがあります！"


translate japanese Chambreep3_5e298433:


    dpense "新しい機能：'連絡先'アプリケーションを使ってメッセージを送信！"


translate japanese Chambreep3_ec2c1d7a:


    dpense "わかりました、やってみます..."


translate japanese gracephoneep3s4_7cd0dad9:


    dpense "その唇…"


translate japanese gracephoneep3s4_40bf0c88:


    dpense "うまくやっているようだね..."


translate japanese juliaphoneep3s4_bffc964b:


    dpense "今晩彼女が無事でいることを願っています…。"


translate japanese madphoneep3s4_4c58dcba:


    dpense "私は馬鹿だ、彼女は娘と一緒だと言った…"


translate japanese madphoneep3s4_fda3813c:


    dpense "彼女はしばしば忙しいに違いない..."


translate japanese madphoneep3s4_99f61674:


    dpense "彼女に接する方法を変える必要があると思う..."


translate japanese bluephoneep3s4_28c2d9c9:


    dpense "彼女は本当に変わったなあ..."


translate japanese bluephoneep3s4_02a7ab74:


    dpense "何かが起こった..."


translate japanese gabyphoneep3s4_d5bafb7c:


    dpense "まあ…少なくとも確認できた！"


translate japanese gabyphoneep3s4_6ba6c89d:


    dpense "明日彼女との約束を忘れてはいけないけれど…"


translate japanese gabyphoneep3s4_f008a47b:


    dpense "そうでなければ、彼女は私を殺す！"


translate japanese departsoiree_bd5a3951:


    dpense "はい、行きましょう！"


translate japanese departsoiree_2a7b2a88:


    dpense "シャーロットはパーティーの前に店に行くように頼んでいた..."


translate japanese ArriveeFete_d10b0838:


    d "今は… パーティー！"


translate japanese ArriveeFete_af385284:


    d "始めましょう..."


translate japanese Charlottetime_44050cec:


    dpense "閉まっている..."


translate japanese Charlottetime_f423db45:


    dpense "でも、明かりはついている..."


translate japanese Charlottetime_37b557c2:


    dpense "彼女は数えなければならないものがいくつかあると言った、と思う..."


translate japanese Charlottetime_5df73d10:


    dpense "裏口にドアがあるかもしれない？"


translate japanese Charlottetime_8b1242bd:


    dpense "裏口..."


translate japanese Charlottetime_a3d61da9:


    dpense "開いています。"


translate japanese Charlottetime_017bee57:


    d "ここに隠れていたのか？"


translate japanese Charlottetime_c3e5e858:


    cha "え？"


translate japanese Charlottetime_641b24ec:


    cha "ああっ！"


translate japanese Charlottetime_b31d7873:


    d "心配しないで！私はこれを手に入れたんだから!...えっと、つまり君を助けるよ!!"


translate japanese Charlottetime_bfd3fd79:


    cha "おお？"


translate japanese Charlottetime_99c90c60:


    cha "あなたは私を驚かせた！"


translate japanese Charlottetime_c8863a0d:


    d "ごめんなさい！それは私の意図ではありませんでした。"


translate japanese Charlottetime_fca708e0:


    cha "そこは快適ですか？"


translate japanese Charlottetime_2c3a63c7:


    d "何を意味していますか？"


translate japanese Charlottetime_0ebfde79:


    cha "私の胸を離してもいいんだよ…"


translate japanese Charlottetime_a2a9798e:


    d "ああ！ はい、ごめんなさい！"


translate japanese Charlottetime_2e1075ac:


    cha "待って、ここにいる間、私を抱きしめて。棚の裏を数えなきゃいけない。"


translate japanese Charlottetime_d93e0955:


    d "ああ... はい、わかりました。"


translate japanese Charlottetime_cfa70a59:


    cha "しっかり抱きしめてね！"


translate japanese Charlottetime_b82983f4:


    d "はい、はい！"


translate japanese Charlottetime_46359b02:


    dpense "なんてお尻なんだ…"


translate japanese Charlottetime_3957d45a:


    dpense "待って..."


translate japanese Charlottetime_b4475d8b:


    dpense "彼女はパンツを履いていなかったのですか？" with hpunch


translate japanese Charlottetime_e11f72be:


    dpense "彼女はわざとやった、まさか..."


translate japanese Charlottetime_eafe9e61:


    cha "待って、背中を見るためにもう少し近づかなければならない。"


translate japanese Charlottetime_e9fcb1fb:


    dpense "彼女は本気なのか？"


translate japanese Charlottetime_9b0004ac:


    dpense "彼女は遊びたい..."


translate japanese Charlottetime_53e24e7b:


    dpense "それでは、遊びましょう！"


translate japanese Charlottetime_bfd3fd79_1:


    cha "あら？"


translate japanese Charlottetime_e7fc63f0:


    cha "なんだって…？"


translate japanese Charlottetime_385ef974:


    cha "あ！"


translate japanese Charlottetime_98998053:


    cha "うーん..."


translate japanese Charlottetime_38e5071e:


    cha "はい... 続けて..."


translate japanese Charlottetime_a1818eb0:


    cha "あなたがその景色を楽しむだろうと知っていました。"


translate japanese Charlottetime_215da4ac:


    cha "あなたがそう思ったとは… ハムフッ…"


translate japanese Charlottetime_a6aeabed:


    cha "あなたのチャンスをどうやって掴むか知っているでしょうか... Haaa..."


translate japanese Charlottetime_38954f7f:


    cha "あなたは本当に得意ですね… おおっ！"


translate japanese Charlottetime_11bbaae7:


    cha "はい！ちょうどそこ！"


translate japanese Charlottetime_64c167b7:


    cha "それをやれ！あの女の子のことを食べろ！"


translate japanese Charlottetime_4cd519e2:


    cha "おお、なんて素晴らしいんだ..."


translate japanese Charlottetime_c4c6380f:


    dpense "彼女はびしょびしょだ..."


translate japanese Charlottetime_e5d1a0b8:


    dpense "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese Charlottetime_30c9594f:


    dpense "彼女はとても美味しい味がする..."


translate japanese Charlottetime_5bd1f2d3:


    dpense "私は人生でそんな女性を持ったことがありません..."


translate japanese Charlottetime_38a2c2e0:


    dpense "彼女はとても興奮している…"


translate japanese Charlottetime_ace19207:


    cha "はい、大きな男。"


translate japanese Charlottetime_bf324701:


    cha "何ができるか見せて。"


translate japanese Charlottetime_f7e912e8:


    cha "その服を脱いで、あなたの魅力的な体を見せて！"


translate japanese Charlottetime_d40c7883:


    cha "やあ...そう思っていたよ..."


translate japanese Charlottetime_f83572f2:


    cha "そんなに筋肉質..."


translate japanese Charlottetime_f40ea147:


    cha "あなたは強い匂いさえする。"


translate japanese Charlottetime_602fd819:


    cha "私は…"


translate japanese Charlottetime_6b46261d:


    d "話はもう十分だ..."


translate japanese Charlottetime_139f3ef4:


    cha "わああ！"


translate japanese Charlottetime_d0858423:


    cha "あなたは主導権を握るのが好きですか？"


translate japanese Charlottetime_df64e08e:


    d "おしゃべりをするためにここにいるわけではない..."


translate japanese Charlottetime_7627c9c7:


    d "美しい者たちを彼女たちの牢獄から解放する時だと思う。"


translate japanese Charlottetime_b04ed3cd:


    d "おお、これは素晴らしいおっぱいだ！"


translate japanese Charlottetime_c085c6c5:


    cha "うん... さわってみて... いじってみて..."


translate japanese Charlottetime_6d716f8d:


    d "遊ぶ時間がない..."


translate japanese Charlottetime_15b5a1b0:


    d "若いスタッドが欲しかったのに..."


translate japanese Charlottetime_eb5c5535:


    d "来るぞ…"


translate japanese Charlottetime_fc3eeae2:


    cha "あああああああああ！君はそこにいる男の子以上の存在だ！"


translate japanese Charlottetime_8ee6bc76:


    cha "あああ..."


translate japanese Charlottetime_a5dfa887:


    cha "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese Charlottetime_80e8641c:


    dpense "確かにそれは驚くほどきつい..."


translate japanese Charlottetime_44684764:


    cha "続けて[name]! 伸ばして!"


translate japanese Charlottetime_1f3544ea:


    cha "もっと激しくして！"


translate japanese Charlottetime_7eb1ed65:


    d "これを受け取れ！"


translate japanese Charlottetime_be561219:


    cha "ああ、なんてことだ！ああ、なんてことだ！ああ、なんてことだ！"


translate japanese Charlottetime_f18aa612:


    d "あなたがそれを欲しがっていた！"


translate japanese Charlottetime_09fa1492:


    cha "はい！はい！もっと！もっと！"


translate japanese Charlottetime_3951848a:


    d "私は行くよ！"


translate japanese Charlottetime_fac14cdd:


    cha "私も行くよ！！！"


translate japanese Charlottetime_fd6d20bb:


    d "背中に出すから振り向いて！"


translate japanese Charlottetime_f8d931fa:


    cha "熱い精液を私に出して！"


translate japanese Charlottetime_85a345ef:


    cha "肌で感じたい！"


translate japanese Charlottetime_b4461efb:


    d "あああああ！！！"


translate japanese Charlottetime_85f0a600:


    d "それは良かった！"


translate japanese Charlottetime_87137957:


    cha "うん..."


translate japanese Charlottetime_d91aadfa:


    cha "今、空虚な気持ち..."


translate japanese Charlottetime_6e5b9427:


    d "良い！終わっていないから！"


translate japanese Charlottetime_9b93c49a:


    cha "" with hpunch


translate japanese Charlottetime_36f25c9c:


    cha "私のお尻！"


translate japanese Charlottetime_18b75d90:


    cha "気をつけて、私は..."


translate japanese Charlottetime_4f482ae4:


    cha "ああああああ！"


translate japanese Charlottetime_f9f78226:


    cha "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese Charlottetime_3271d50d:


    cha "その尻をくたばれ[name]！くそ！くそおおおおおおおおおおお！"


translate japanese Charlottetime_93db56f7:


    cha "まだたくさん残っている..."


translate japanese Charlottetime_258c8329:


    cha "あなたはまだ石のように硬い！"


translate japanese Charlottetime_7ab6f1b2:


    d "私は長く持たない！君はとてもきつい！"


translate japanese Charlottetime_3414f046:


    cha "私の中にだして！"


translate japanese Charlottetime_b78a309b:


    cha "俺のケツを満たしてくれ！"


translate japanese Charlottetime_8c9fa616:


    d "ああああああああああああ！"


translate japanese Charlottetime_bf1e921f:


    cha "すごいぃぃぃぃぃぃ！"


translate japanese Charlottetime_933cc1f7:


    cha "もう行くよ！！！！"


translate japanese Charlottetime_31a9b907:


    d "それが私が呼ぶ良いギャッピングだ！"


translate japanese Charlottetime_f8e2e91c:


    cha "今日は座れそうにない..."


translate japanese Charlottetime_6bba4eab:


    d "私は留まれない、私は…"


translate japanese Charlottetime_dd5f6d96:


    cha "うんうん..."


translate japanese Charlottetime_17dba0b7:


    cha "パーティーに行ってください..."


translate japanese Charlottetime_aee3450e:


    cha "またね！"


translate japanese Charlottetime_f1c77c07:


    d "じゃあ、またね！"


translate japanese Charlottetime_f272ff3b:


    cha "あまり早くは..."

translate japanese strings:


    old "14:30"
    new "14:30"


    old "17:30"
    new "17:30"


    old "Hey! Are you awake?"
    new "ねえ！起きてる？"


    old "Pass"
    new "パス"


    old "You guys doing okay?"
    new "みんな大丈夫？"


    old "Yeah, we're good! We're almost done :)"
    new "うん、いい感じだね！もうすぐ終わるよ :)"


    old "You need anything?"
    new "何か必要ですか？"


    old "Nope!"
    new "いいえ!"


    old "Ruby thought of everything as usual!"
    new "ルビーはいつものようにすべてを考えました！"


    old "Okay... Well, see you later then!"
    new "じゃあ、また後で！"


    old "Yes! See you later!"
    new "はい！また後で！"


    old "I can't wait to see you already!"
    new "もうあなたに会えるのが待ちきれない！"


    old "A wallpaper has been added"
    new "壁紙が追加されました。"


    old "Feeling better?"
    new "気分は良くなった？"


    old "Still a bit of back pain, but I'm okay..."
    new "まだ少し腰が痛いけど、大丈夫..."


    old "If you need massages, I'm here!"
    new "マッサージが必要なら、私はここにいます！"


    old "Haha! No, it's okay!"
    new "ハハ！大丈夫だよ！"


    old "I'm getting ready for tonight..."
    new "今夜の準備をしています..."


    old "Well, don't hesitate if you need anything!"
    new "何か必要なことがあれば、遠慮しないでください！"


    old "I'll remember that!"
    new "それを覚えておくよ！"


    old "See you tonight!"
    new "今夜会いましょう！"


    old "Are you ready for tonight?"
    new "今夜の準備はできていますか？"


    old "I'm not even dressed yet..."
    new "まだ服を着ていないんです..."


    old "Seriously?"
    new "本当に？"


    old "Stay like that, it works for me!"
    new "そのままでいてください、私はそれがうまくいきます！"


    old "If only I could..."
    new "もし私ができるなら..."


    old "I won't bother you any longer then!"
    new "もうこれ以上は邪魔しないよ！"


    old "Oh, you're not bothering me!"
    new "ああ、あなたは私を困らせていません！"


    old "Tease!"
    new "からかう！"


    old "You have no idea how much!"
    new "どれほどか分からないでしょう！"


    old "Alright, see you later!"
    new "じゃあね！"


    old "See you later!"
    new "じゃね！"


    old "Join her[TEMP1!t]"
    new "彼女に参加して[TEMP1!t]"


    old "Or not[TEMP2!t]"
    new "またはそうでない[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
