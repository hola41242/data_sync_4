

translate japanese strings:


    old "What is the only Wonder of the ancient world still visible?"
    new "古代世界の七不思議のうち、現在も見ることができる唯一のものは何ですか？"


    old "In a traditional deck of cards,\nwhich queen holds her scepter with both hands?"
    new "伝統的なトランプのデッキでは、どの女王が両手で王笏を持っていますか？"


    old "Who wrote '1984'?"
    new "'1984'を書いたのは誰ですか？"


    old "What is the missing number?\n16 06 68 88 ?? 98"
    new "欠けている数字は何ですか？\n16 06 68 88 ?? 98"


    old "What was the name of the first widely available web browser?"
    new "最初に広く利用可能になったウェブブラウザの名前は何でしたか？"


    old "What is the capital of Australia?"
    new "オーストラリアの首都はどこですか？"


    old "Who is hidden behind this image?"
    new "この画像の背後に隠れているのは誰ですか？"


    old "If you mix red and blue,\nwhat color do you get?"
    new "赤と青を混ぜると、どんな色になりますか？"


    old "Press the POINT"
    new "ポイントを押してください"


    old "The answer is obvious"
    new "答えは明白だ"


    old "The Colossus of Rhodes"
    new "ロドスの巨像"


    old "The Great Pyramid of Giza[TEMP1!t]"
    new "ギザの大ピラミッド[TEMP1!t]"


    old "The Lighthouse of Alexandria"
    new "アレクサンドリアの大灯台"


    old "The Temple of Artemis"
    new "アルテミスの神殿"


    old "The Queen of Clubs[TEMP1!t]"
    new "クラブの女王[TEMP1!t]"


    old "The Queen of Spades"
    new "スペードのクイーン"


    old "The Queen of Hearts"
    new "ハートの女王"


    old "The Queen of Diamonds"
    new "ダイヤモンドの女王"


    old "J. R. R. Tolkien"
    new "J. R. R. トールキン"


    old "George R. R. Martin"
    new "ジョージ・R・R・マーティン"


    old "George Orwell[TEMP1!t]"
    new "ジョージ・オーウェル[TEMP1!t]"


    old "Stephen King"
    new "スティーブン・キング"


    old "Internet Explorer"
    new "インターネットエクスプローラー"


    old "Mosaic[TEMP1!t]"
    new "Mosaic[TEMP1!t]"


    old "Netscape Navigator"
    new "ネットスケープナビゲーター"


    old "Google Chrome"
    new "グーグルクローム"


    old "Canberra[TEMP1!t]"
    new "キャンベラ[TEMP1!t]"


    old "Sydney"
    new "シドニー"


    old "Melbourne"
    new "メルボルン"


    old "Perth"
    new "パース"


    old "Mona Lisa"
    new "モナリザ"


    old "Aya Brea"
    new "アヤ・ブレア"


    old "Lara Croft[TEMP1!t]"
    new "ラー・クロフト[TEMP1!t]"


    old "Katniss Everdeen"
    new "カットニス・エヴァディーン"


    old "Violet[TEMP1!t]"
    new "バイオレット[TEMP1!t]"


    old "Orange"
    new "オレンジ"


    old "Green"
    new "緑"


    old "Pink"
    new "ピンク"


    old "You finished on time! Your score is [score] / 10."
    new "時間通りに終わりました！あなたのスコアは [score] / 10 です。"


    old "You did not finish on time. Your score is [score] / 10."
    new "時間内に終了しませんでした。あなたのスコアは [score] / 10 です。"


    old "Your new rank is :"
    new "あなたの新しいランクは："
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
