


translate japanese ep3s2a_11692d1a:


    ruby "どこにあるのだろう？私はここに置いたはずなのに…"


translate japanese ep3s2a_f45efed9:


    ruby "ああ、どこにも見つからない！お願い、私がそれを使ったわけじゃないのに...いいえ、それは違うはずだ..."


translate japanese ep3s2a_c8e09e9f:


    d "何か特別なものを探していますか？手伝いが必要ですか？"


translate japanese ep3s2a_4d5c3078:


    ruby "ああ、ええと... いや、まあはい... ただ、知っての通り、計画があって... それが消えてしまったんです。"


translate japanese ep3s2a_82e7f578:


    d "彼らを探すのを手伝おうか？"


translate japanese ep3s2a_b47d4f38:


    ruby "いいえ、やめましょう。探し続けると遅れてしまいます。私たちは日を待たせるわけにはいきません。"


translate japanese ep3s2a_94cefeaa:


    ruby "まだ朝食を食べていない… 今日は大変な一日になりそうだ。"


translate japanese ep3s2a_9e16ac9f:


    ruby "特に今夜のために準備しなければならないことを考えると。何も準備できていない、全く何も！"


translate japanese ep3s2a_cc397e3f:


    d "一体何を計画しているのですか？"


translate japanese ep3s2a_7186988a:


    ruby "それはサプライズです！"


translate japanese ep3s2a_c63a6995:


    d "わかった、わかった！じゃあ今夜会おう！"


translate japanese ep3s2a_bd6a0342:


    ruby "そうですね！では、行きましょうか？"


translate japanese ep3s2a_d8d1b09d:


    d "何も忘れていない？"


translate japanese ep3s2a_6b0b0af2:


    ruby "え？"


translate japanese ep3s2a_3339f33a:


    ruby "ああ... ああ!"


translate japanese ep3s2a_60cfb41d:


    ruby "服を着るのを忘れてしまった！"


translate japanese ep3s2a_9f5cc69e:


    ruby "ちょっと待って、2分だけちょうだい、カフェテリアに寄って朝食をサッと取ろう！"


translate japanese ep3s2a_ca8a4f56:


    d "私には良さそうです。"


translate japanese ep3s2a_27b44026:


    dpense "彼女は二分と言わなかったか？"


translate japanese ep3s2a_074aea1e:


    ruby "わかりました！"


translate japanese ep3s2a_bf017898:


    ruby "行こう！"


translate japanese ep3s2a_0d33e6e7:


    ruby "ああ、それは快感だ！"


translate japanese ep3s2a_bec598f0:


    d "そうですね、朝に良いフルーツジュースがあれば、素晴らしい一日が待っています！"


translate japanese ep3s2a_f8bc6076:


    ruby "素晴らしい日、素晴らしい日... 数分後に大学の授業があって、その後、パーティーの準備を全部持って帰らなければならない。"


translate japanese ep3s2a_6dfa40f3:


    ruby "それから、今日の午後、今夜のためにゲームを設定して、服を着る必要があります！"


translate japanese ep3s2a_5032c97b:


    d "あなたはどのドレスを着るつもりですか？"


translate japanese ep3s2a_e84c5d39:


    ruby "見てごらん！言っただろう、選ぶべきだったんだ！"


translate japanese ep3s2a_033f2e7d:


    d "今後のゲームについて何かヒントはありますか？"


translate japanese ep3s2a_53d03f1a:


    ruby "ああ… それはズルになる！"


translate japanese ep3s2a_886fed77:


    ruby "でも心配しないで、退屈することはないよ！"


translate japanese ep3s2a_7a67eec2:


    d "それを見るのが待ちきれない！"


translate japanese ep3s2a_979e7529:


    ruby "じゃあ、授業に行くべきだね。"


translate japanese ep3s2a_116b0c41:


    ruby "ガブリエラがいい気分であることを願っています！"


translate japanese ep3s2a_a735b1d5:


    d "ああ、言うのを忘れてた！"


translate japanese ep3s2a_2307991b:


    ruby "何？"


translate japanese ep3s2a_f3ddd5e4:


    d "昨晩、彼女のバイクで彼女に出くわした！"


translate japanese ep3s2a_351fd21f:


    ruby "彼女はバイクを持っているの？"


translate japanese ep3s2a_ae03bbda:


    d "そうだね！彼女は私が注意を払っていなかったから、ほとんど轢かれそうになった..."


translate japanese ep3s2a_430c9b2b:


    ruby "それから？"


translate japanese ep3s2a_3193c1a9:


    d "まあ、彼女の電話番号を手に入れちゃった！"


translate japanese ep3s2a_d9ee4a01:


    ruby "あり得ない！"


translate japanese ep3s2a_16e5da27:


    d "私は誓います！"


translate japanese ep3s2a_d2894bee:


    ruby "言ったでしょ！運命さえも君を彼女と引き合わせようとしているんだから！"


translate japanese ep3s2a_6c1aa172:


    d "ああ、冗談だろ、それは馬鹿げてる！"


translate japanese ep3s2a_e1d4fa0d:


    ruby "まあ、今はただの連絡ですが、進展です！"


translate japanese ep3s2a_4e839775:


    ruby "私はキューピッドになるべきだと思う。向いている気がする！"


translate japanese ep3s2a_f5eeefc8:


    d "先走りだね。"


translate japanese ep3s2a_e62774af:


    ruby "ああ... そうですね、見てみましょう！"


translate japanese ep3s2a_c739e98c:


    ruby "それでも、彼女と次に何が起こるのか待ちきれない！"


translate japanese ep3s2a_7ccab813:


    d "あなたは容赦ないね、それが分かる？次のステップはないし、最初のステップすらない。"


translate japanese ep3s2a_517c3e0c:


    ruby "うん、うん、それがあなたの言うことだね..."


translate japanese ep3s2a_e862964b:


    ruby "しかし、あなたはミルフの電話番号を持っています！"


translate japanese ep3s2a_474f9baa:


    d "ルビー..."

translate japanese strings:


    old "9:00 AM"
    new "午前9時"


    old "Ten minutes later..."
    new "十分後..."


    old "9:30 AM"
    new "午前9時30分"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
