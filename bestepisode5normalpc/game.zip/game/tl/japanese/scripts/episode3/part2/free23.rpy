


translate japanese poker23_3e30ce77:


    mac "" with vpunch


translate japanese poker23_f8e333c6:


    emerick "ハハ！"


translate japanese poker23_1f8b3bf4:


    mac "またエースをぶっ壊した！"


translate japanese poker23_5b43b033:


    mac "もうプレイするのをやめる！"


translate japanese poker23_46928cb5:


    emerick "それがゲームです！"


translate japanese poker23_1f88ae2d:


    mac "うんうん… それはクソだ！"


translate japanese poker23_1bd62c92:


    emerick "今は私たち二人だけだよ、フレンチー！"


translate japanese poker23_ff6a1930:


    dpense "私はプレイした数回の手で2000ドルまで貯めることができました..."


translate japanese poker23_253a69ef:


    emerick "それでは、頭を上げて！"


translate japanese poker23_3acfb082:


    beth "あなたの番です [name]。"


translate japanese poker23_96927053:


    d "私は呼びます。"


translate japanese poker23_d89911e1:


    emerick "うーん…"


translate japanese poker23_1594e8a3:


    emerick "私は上がる。"


translate japanese poker23_dc181045:


    d "呼ぶ。"


translate japanese poker23_cbfb1f43:


    beth "ボード..."


translate japanese poker23_e394760b:


    beth "ハートのエース、スペードの10、スペードのキング。"


translate japanese poker23_61e98f59:


    d "100を賭ける。"


translate japanese poker23_1594e8a3_1:


    emerick "私は育てる。"


translate japanese poker23_e48c9cb0:


    d "うーん..."


translate japanese poker23_dc181045_1:


    d "呼ぶ。"


translate japanese poker23_1ca60585:


    beth "ターン..."


translate japanese poker23_4e0f3456:


    beth "スペードのエース。"


translate japanese poker23_e48c9cb0_1:


    d "うーん..."


translate japanese poker23_0c16dfff:


    dpense "キラは私に彼の自信を利用するように言った..."


translate japanese poker23_7266d996:


    dpense "どうやってすればいいの？"


translate japanese poker23_907fdef1:


    emerick "さあ、決めましたか？"


translate japanese poker23_1fc32aee:


    emerick "折れないつもりだよね？"


translate japanese poker23_cddf2c53:


    dpense "彼はとても自信があるようだ..."


translate japanese poker23_5e4910c9:


    d "思い出せない…"


translate japanese poker23_0ce9fdf0:


    d "フラッシュはストレートよりも優れているよね？"


translate japanese poker23_f8e333c6_1:


    emerick "はは！"


translate japanese poker23_1592616c:


    emerick "はい！"


translate japanese poker23_242b94d5:


    emerick "どちらか一方を持っていますか？"


translate japanese poker23_d5ee268c:


    d "いいえ、いいえ、ただ知りたかっただけです..."


translate japanese poker23_d89911e1_1:


    emerick "うーん..."


translate japanese poker23_6e8a688e:


    emerick "聞いて、フレンチ。私たちはここで一晩中過ごすつもりはない。"


translate japanese poker23_7426abd6:


    emerick "何か提案があります！"


translate japanese poker23_c31b56fc:


    emerick "全力で行って、誰が勝つか見てみよう！"


translate japanese poker23_ec7e4047:


    emerick "何を言いますか？"


translate japanese poker23_13bcf77c:


    emerick "どのくらい持っていますか？ 2000？"


translate japanese poker23_fc6dea88:


    d "うん..."


translate japanese poker23_5bd579fe:


    emerick "分かった、2000を入れただけだ。"


translate japanese poker23_f338cc08:


    d "えっと..."


translate japanese poker23_7bcc50f4:


    d "わかりました..."


translate japanese poker23_d4af3017:


    d "私は呼びます..."


translate japanese poker23_1b8051aa:


    emerick "なぜ私がこれを提案しているのか分かりますか？"


translate japanese poker23_76a68131:


    d "勝つ自信があるから？"


translate japanese poker23_e39b1be7:


    emerick "もちろん！"


translate japanese poker23_ba32e80a:


    d "自分自身と自分のゲームを信じているからですか？"


translate japanese poker23_e8143a9b:


    emerick "はは！いつも！"


translate japanese poker23_4e56fdd8:


    d "あなたが狂っているからですか？"


translate japanese poker23_610444ad:


    emerick "少しだけでいいよね？"


translate japanese poker23_dbb2bc0c:


    emerick "でも、違う... 勝つって分かっているからだ！"


translate japanese poker23_0a541187:


    emerick "川だ、ベス！"


translate japanese poker23_5b38b6ff:


    beth "川..."


translate japanese poker23_af61be04:


    beth "ハートの二つ…"


translate japanese poker23_6faa39e5:


    beth "カードを見せてください、紳士たち！"


translate japanese poker23_f9d65ba9:


    emerick "" with vpunch


translate japanese poker23_7e7fc3d4:


    d "わぁ！！！フォー・オブ・ア・カインド...."


translate japanese poker23_765965dc:


    d "フォー・オブ・ア・カインドは珍しい..."


translate japanese poker23_e5f13971:


    emerick "そうだよ、男！"


translate japanese poker23_03c37d01:


    emerick "まあ、いい試みだね！"


translate japanese poker23_fb6205e3:


    d "わぁ、すごい..."


translate japanese poker23_c154fd55:


    d "あなたはただエースを持っていると思っていました..."


translate japanese poker23_a5265cf0:


    d "フルハウスかもしれない..."


translate japanese poker23_78ff97d6:


    emerick "はは、私は遊び方を知っています！"


translate japanese poker23_b2842d1b:


    d "はい..."


translate japanese poker23_96d96279:


    d "いい手だね…。"


translate japanese poker23_01a6c5e7:


    d "なぜフラッシュがストレートより強いのか尋ねたのか分かりますか？"


translate japanese poker23_88c2931a:


    emerick "ああ...いいえ！"


translate japanese poker23_8b0f7c01:


    d "まあ... 私が..."


translate japanese poker23_8e217ed9:


    d "両方..."


translate japanese poker23_bcfc41d9:


    d "" with vpunch


translate japanese poker23_d3a632b6:


    emerick "" with hpunch


translate japanese poker23_a5e63099:


    emerick "冗談でしょうか？"


translate japanese filles23_e63d14a0:


    hec "来てよ。それはただのジョークだったんだ！"


translate japanese filles23_6e377ba4:


    julia "私を一人にして、ヘクター。"


translate japanese filles23_13caae44:


    hec "堅物を演じないで。あのドレスの下に楽しみがたくさんあるに違いない！"


translate japanese filles23_99f1a7c0:


    julia "私に構わないでくれと言っただろう！"


translate japanese filles23_6b599e1a:


    hec "あなたはすっかりおめかしをして、誰も利用しなかったら勿体ないです！"


translate japanese filles23_31b3aea6:


    hec "さあ、もう少しプライベートな場所に行こう！"


translate japanese filles23_99ce83cb:


    d "彼女はあなたに彼女を放っておくように言ったと思います。"


translate japanese filles23_1a134164:


    hec "" with hpunch


translate japanese filles23_848785e8:


    hec "まるで蚊のようだ、男！"


translate japanese filles23_97292c7a:


    hec "まあ、あなたにお姫様を任せるわ... 彼女は冷たい感じがするし。"


translate japanese filles23_f9c7f0b0:


    d "大丈夫ですか？"


translate japanese filles23_9da28c53:


    julia "はい、はい... それに慣れています。心配しないでください。"


translate japanese filles23_398d0cff:


    julia "でも、それはあなたの親切です。ありがとう。"


translate japanese filles23_27970b90:


    julia "再び私のためにいてくれて..."


translate japanese filles23_098db63e:


    d "ああ、何でもないよ。どうせ彼には我慢できないから。"


translate japanese filles23_b44e6db9:


    julia "あはは！私もそうだよ。"


translate japanese filles23_4af33191:


    julia "やあ…"


translate japanese filles23_fad03ada:


    d "？"


translate japanese filles23_2817e51d:


    julia "これは変に聞こえるかもしれませんが..."


translate japanese filles23_73e08839:


    julia "明日、一緒に病院に行ってくれますか？"


translate japanese filles23_46f54ac1:


    d "何を意味しているの？風邪をひいたの？"


translate japanese filles23_b95b525d:


    julia "いいえ。私はただ母に会いたいだけです。"


translate japanese filles23_cb1ee412:


    julia "そして、テスト結果を考えれば、誰かと一緒にいて欲しいと思う。"


translate japanese filles23_73af0f04:


    d "彼らは良くないのですか？"


translate japanese filles23_8f9c6f6d:


    julia "いいえ。まったくそうではありません。"


translate japanese filles23_a90e9d4d:


    julia "彼女には残りわずか数日しかない..."


translate japanese filles23_6e7e6c4f:


    julia "私はそれを受け入れていたが、今ではそれが終わりだと思う。"


translate japanese filles23_bf456521:


    d "あなたのためにそこにいるよ。"


translate japanese filles23_8ffcb975:


    julia "ありがとう[name]。"


translate japanese filles23_4e67cd6a:


    julia "それは私にとって大切な意味があります。"


translate japanese filles23_643ee3b5:


    d "何か必要なことがあれば遠慮しないでください。"


translate japanese filles23_bd82f144:


    julia "私は押し付けたくありません..."


translate japanese filles23_0d2bd84b:


    d "友達とはそういうものだよね？"


translate japanese filles23_66c7136d:


    d "友達ってこと？"


translate japanese filles23_60d8c678:


    julia "私たちは友達です！"


translate japanese filles23_9f9dba11:


    julia "初めて会った日、友達が友達の尻を掴むなんて、確信が持てなくても…。"


translate japanese filles23_bfbf1c07:


    d "ああ！えっと…"


translate japanese filles23_260e8d1d:


    julia "あはは、からかっているだけよ..."


translate japanese filles23_0ea9962d:


    d "まぁ、公平に言うと、それは良いものです。"


translate japanese filles23_f14e0ae3:


    julia "ハハ、わかってるよ！見るだけで触ってはいけないんだ。"


translate japanese filles23_ff49f6fb:


    d "友達として、この夜の残りを楽しみましょう！"


translate japanese filles23_7eabd694:


    julia "あなたが正しい。私はあまり長くは留まらないつもりだ。"


translate japanese filles23_b4b50c32:


    d "行こう！"


translate japanese filles23_c1d6711f:


    ruby "私は一度も... えっと..."


translate japanese filles23_fcbdc5b7:


    ruby "エロティックなおもちゃを買った！"


translate japanese filles23_b4c311d4:


    kira "ディルドと言ってもいいんですよ！"


translate japanese filles23_6b94590f:


    ruby "うーん..."


translate japanese filles23_0352a573:


    mad "彼女が言いたいことを言わせてあげて、キラ！"


translate japanese filles23_05c46b86:


    mad "彼女には自分のかわいいものがすべてある世界があります！"


translate japanese filles23_be415281:


    kira "そして、あなたはすべてのぬいぐるみの中で、時々こすりつけるための小さなウサギがないと言うつもりですか？"


translate japanese filles23_a21ad27d:


    ruby "ああ... いいえ..."


translate japanese filles23_2705baee:


    kira "どうやって君たちがそれをやるのか分からないけれど、時々少しの快楽がないと攻撃的になっちゃう！"


translate japanese filles23_03785299:


    kira "ところで、私はそのおもちゃの一つを買ったんだ…そのものを見た方がいいよ…"


translate japanese filles23_d9ad2417:


    grace "それはどのように見えますか？"


translate japanese filles23_208dc12d:


    mad "" with hpunch


translate japanese filles23_0c9d4e4e:


    grace "何ですか？ただ興味があるだけです！"


translate japanese filles23_745587fa:


    kira "はは！長くて、大きくて、リブがある…。"


translate japanese filles23_cf7d2902:


    kira "まだテストしていませんが、いい評判を聞いたので... 見てみましょう..."


translate japanese filles23_0c6f12cb:


    kira "そして君は、マディソン？君の好きなものは何？"


translate japanese filles23_7fa17ae4:


    kira "あなたがバスの中で小さな振動するアヒルを持っているのが見える！"


translate japanese filles23_e57728f4:


    mad "娘が遊ぶために？いいえ、結構です！"


translate japanese filles23_c308f921:


    mad "あなたには関係ないことだ！"


translate japanese filles23_fe8120c9:


    kira "さあ行こう... マディソン・フォレスタが清楚ぶってる！"


translate japanese filles23_4bd272c9:


    mad "私は堅物ではない！"


translate japanese filles23_29ccd7f5:


    kira "うん、うん..."


translate japanese filles23_d721fb2f:


    d "ここで何を話しているのですか？"


translate japanese filles23_bcdd5352:


    ruby "おもちゃ！"


translate japanese filles23_19dc7043:


    mad "親密なこと..."


translate japanese filles23_0a7a132b:


    kira "ディルドと自分を触ること！"


translate japanese filles23_52720f61:


    d "痛い...わかった..."


translate japanese filles23_541a9a65:


    grace "男には簡単だと思う…"


translate japanese filles23_bec902dc:


    d "どういうこと？"


translate japanese filles23_81c99eed:


    grace "そうですね、気が向いた時には簡単に快楽を得ることができますよね？かなり早いです..."


translate japanese filles23_10ab5d15:


    d "うーん... 私は、女の子のように、人それぞれだと思う... そして、私たちはまだ刺激を受ける必要がある！"


translate japanese filles23_129b6de5:


    kira "ああ、確かに… そして、男女ともに状況に応じて視覚的、聴覚的、または触覚的であることができることを知っていましたか？"


translate japanese filles23_584173a2:


    ruby "何を意味していますか？"


translate japanese filles23_b4384300:


    kira "基本的に... 男性は視覚的な刺激、例えばあなたの体を見ることに対してすぐに反応することがよくあります。"


translate japanese filles23_72c860a3:


    kira "多くの女性にとって、音、言葉、さらには特定の種類の触れ合いがより刺激的であることがあります。"


translate japanese filles23_564c078d:


    ruby "ああ！それはどうやって機能するのですか？"


translate japanese filles23_07a91765:


    kira "それをあなたに発見させます！自分を興奮させるものを知り、それをパートナーとコミュニケーションすることが重要です。"


translate japanese filles23_104a8c12:


    grace "どうしてそんなことが分かるの、キラ？"


translate japanese filles23_fea58b2c:


    kira "そうですね... 私は実験をして研究を行います。私たちの体や性に関して学ぶことがたくさんあります。"


translate japanese filles23_a728e041:


    kira "人々はとても禁欲的になることがあります。彼らはセックスを非常にタブー視していて、自分の身体やセクシュアリティを受け入れることに恥じらいを感じます。"


translate japanese filles23_ffa5c37b:


    kira "それを探求することは完全に自然で健康的です。"


translate japanese filles23_66374259:


    grace "あなたが羨ましい..."


translate japanese filles23_8dc09e6e:


    kira "もしアドバイスができるなら..."


translate japanese filles23_0d3bc963:


    kira "自分の一部を誰かと探求する準備ができたら、最高のランジェリーを身に着けて、解放し、選んだ相手との瞬間を楽しんでください。"


translate japanese filles23_76869d69:


    kira "そうすれば、あなたは後悔しないでしょう！"


translate japanese filles23_0adef93a:


    grace "うーん... わかった..."

translate japanese strings:


    old "11:00 PM"
    new "11:00 PM"


    old "Because you're sure you'll win?"
    new "あなたが勝てると確信しているからですか？"


    old "Because you trust yourself?"
    new "自分自身を信じているからですか？"


    old "Because you're crazy?"
    new "あなたが狂っているから？"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
