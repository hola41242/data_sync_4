


translate japanese free20main_b9817b1b:


    dpense "彼女の言葉に心臓がドキッとした。ソフィアからこんなことを言われるとは思っていなかった。行くべきだろうか？"


translate japanese free20poker_e46e10c0:


    emerick "お前は招待されてないぞ、フレンチー！ハーレムに帰れ！"


translate japanese free20poker_166fb7af:


    d "エメリック、何か問題でもあるのか？"


translate japanese free20poker_e3a21349:


    emerick "私の問題？あなたは招待されていないから... 消え失せろ！"


translate japanese free20poker_09774e7f:


    d "私はただ皆と同じように楽しむためにここにいます。"


translate japanese free20poker_caffb51d:


    emerick "私は気にしない！"


translate japanese julia20_e9b667af:


    julia "こんにちは！"


translate japanese julia20_7b0543b1:


    d "こんにちは！背中の調子は良くなりましたか？"


translate japanese julia20_90f7916e:


    julia "まだ楽にやっているけれど、少し良くなった。"


translate japanese julia20_e01785b9:


    julia "女の子のために少し滞在しようと思っていますが、ルビーが計画していることをすべて行うことはできません..."


translate japanese julia20_d303c45f:


    d "はは！まだ何をするかわからない！"


translate japanese julia20_0a194220:


    julia "楽しんでください、それが一番大事です！"


translate japanese julia20_a676d5f9:


    d "頑張ってみましょう！"


translate japanese julia20_91ae47cb:


    d "何か飲んでいますか？"


translate japanese julia20_ebb81cf3:


    julia "いいえ、薬は使わない方がいい..."


translate japanese julia20_f36a5ff4:


    d "わかりました！"


translate japanese julia20_12d28bf4:


    d "あ、そういえば、あなたの新しい髪型が大好きです！"


translate japanese julia20_d5c0dba2:


    julia "おお？ありがとう！"


translate japanese julia20_c37e26a1:


    d "髪型を変えるのが好きなんだよね？ 会うたびに新しいのにしてる！"


translate japanese julia20_27255f05:


    julia "うーん... 実は今回はそのクソ野郎が僕をピンキーと呼んだから、ムカついたんだ..."


translate japanese julia20_ba9103a5:


    d "ああ…わかりました…"


translate japanese julia20_4811f618:


    julia "だから、彼は今私を一人にしておくでしょう。"


translate japanese julia20_f4bcc054:


    julia "正直なところ、私はこういう風が結構好きなので、今回はこのままにしておこうかなと思っています！"


translate japanese julia20_58878192:


    d "はは！あなた次第です！"


translate japanese julia20_8b665ac1:


    d "君が髪型を変えるのを見るのはちょっと面白いけど..."


translate japanese julia20_c4520b4a:


    d "あなたが次にどんな姿になるのか考えるのが好きです。いつも楽しいサプライズです！"


translate japanese julia20_c2c84d9a:


    julia "サプライズ？"


translate japanese julia20_d3bc2521:


    d "うん！君は少し予測不能だけど、心配しないで。私はそれが好きだよ！"


translate japanese julia20_c9b9f09a:


    julia "予測不可能な女の子が好きですか？"


translate japanese julia20_b4e7c55d:


    d "私は私を驚かせる女の子が好きです。"


translate japanese julia20_8deff805:


    julia "承知しました！"


translate japanese julia20_ddf64e4d:


    d "他の人たちが何をしているか見てくるね！また後でね？"


translate japanese julia20_122dc49a:


    julia "また後で！"


translate japanese ruby20_54e9eef5:


    ruby "今晩の準備はできている？"


translate japanese ruby20_2d1667b9:


    d "もちろん！"


translate japanese ruby20_47838d55:


    ruby "さて、私が計画した最初のアクティビティはTwistplayをプレイすることです！"


translate japanese ruby20_55bd9a0f:


    d "なんてこった... これをプレイするのは久しぶりだ..."


translate japanese ruby20_5624a2c3:


    ruby "自転車に乗るのと同じだよ！心配しないで、ただの楽しみだから！"


translate japanese ruby20_fb37dec8:


    ruby "賞品はありません、ただ楽しいだけです！"


translate japanese ruby20_ddd135eb:


    ruby "そう..."


translate japanese ruby20_a220d848:


    ruby "あなたはTwistplayをプレイしたいですか？"


translate japanese ruby20_2a344a80:


    d "はい、もちろん！"


translate japanese ruby20_c6e7417e:


    d "いいえ、ありがとう。"


translate japanese gracemadison20_22e7c1e7:


    mad "彼は、彼女の服の上の嘔吐について尋ねるまで、彼女が一日中病気であることさえ教えてくれないんだ！"


translate japanese gracemadison20_ec0774f0:


    mad "彼は彼女をそれらから出さなかった。誓うよ！"


translate japanese gracemadison20_929b3308:


    grace "彼を本当に信じられない…"


translate japanese gracemadison20_5fb85e30:


    mad "もう人生の中で男を信じることはできない！"


translate japanese gracemadison20_2e4b2f5d:


    mad "一人でいる方が悪い仲間と一緒にいるより良いと言ったでしょう！"


translate japanese gracemadison20_5813eb09:


    grace "でも全員がそうじゃないよ！"


translate japanese gracemadison20_0f959e66:


    mad "もしそんなのじゃないやつを見つけたら、しっかりとつかまえておくんだよ！"


translate japanese gracemadison20_bb8a7268:


    grace "もしかしたら、私たちを満たしてくれる誰かを見つけるかもしれない。"


translate japanese gracemadison20_aaae4443:


    mad "空から降ってくる完璧な男のよう？それは起こりません、あなた！"


translate japanese gracemadison20_dd6aca0e:


    grace "彼が倒れるのをなぜ待つのか？"


translate japanese gracemadison20_47e7ef71:


    grace "空で彼に会うことができる！"


translate japanese gracemadison20_2c8fb2dd:


    mad "え？？？"


translate japanese gracemadison20_9e3164dd:


    d "何を言っているのですか？"


translate japanese gracemadison20_e0fa34d0:


    mad "ああ、知ってるよ、責任、関係、子供たち。"


translate japanese gracemadison20_21c07e24:


    mad "ただの女の子の話！"


translate japanese gracemadison20_833b1ae7:


    grace "ねえ[name]！子供が欲しい？"


translate japanese gracemadison20_31236522:


    d "いつか、はい！でも急いでいないよ！"


translate japanese gracemadison20_7babe025:


    mad "そうだ、彼は若いし、時間はたくさんある！"


translate japanese gracemadison20_ab07cfa9:


    grace "はい、それは本当です。知っておいて良かった！"


translate japanese gracemadison20_cae75794:


    d "いいえ、正直に言うと、子供は私には向いていないと思う。"


translate japanese gracemadison20_ae441c39:


    mad "最低でも彼は正直だ..."


translate japanese gracemadison20_e1929ec1:


    grace "彼は後で気が変わるかもしれない。"


translate japanese gracemadison20_a68fb151:


    d "私はわからない… とにかく、今のところ、それは確実に私の計画にはない！"


translate japanese gracemadison20_00c8df40:


    mad "今は自分のことで手一杯だ！"


translate japanese gracemadison20_70f6dc22:


    grace "はは！想像できるよ！それに、君の兄は助けになるより仕事が多いね！"


translate japanese gracemadison20_4bf8646f:


    d "彼女の兄？"


translate japanese gracemadison20_e7caeca7:


    grace "うん、彼女の兄は、彼女が大学にいる時や試合のために旅行している時に、彼女の娘の世話をしているんだ..."


translate japanese gracemadison20_0179b026:


    mad "でも、うまくいっていない！"


translate japanese gracemadison20_3996a386:


    mad "その男は一日中ソファに沈み込んでいて、小さな子供の世話をする際には… 彼の姿はどこにも見当たらない。"


translate japanese gracemadison20_8c9ae968:


    grace "さあ、マディ！リラックスして飲み物を飲もう、きっと良くなるよ！"


translate japanese gracemadison20_9a1573c3:


    mad "そうだね！考えるのをやめて、今晩を楽しもう！"


translate japanese gracemadison20_ceddc600:


    grace "そうだ！...に乾杯しよう。"


translate japanese gracemadison20_66edb94c:


    grace "何に?"


translate japanese gracemadison20_996828a8:


    d "私たちの会議へ？"


translate japanese gracemadison20_281c814d:


    grace "そうだ、それだ！私たちの出会いに、この競技に、そしてきっと驚きに満ちたこの一年に！"


translate japanese gracemadison20_6860a799:


    "" with hpunch


translate japanese kira20_76978961:


    kira "やあ！[name]、だよね？"


translate japanese kira20_11b6e570:


    d "はい！"


translate japanese kira20_63270a58:


    kira "ファニーを紹介します！"


translate japanese kira20_c9f48e51:


    d "お会いできてうれしいです！"


translate japanese kira20_cbac991e:


    kira "ああ、心配しないで、彼女はあなたが言っていることを何も理解していない！"


translate japanese kira20_dd5d68f3:


    d "え？"


translate japanese kira20_090957fb:


    kira "うん、彼女は別の国から来ていて、私たちの言語を話せない。"


translate japanese kira20_b2fb687f:


    d "あの…じゃあ、彼女はここに何のためにいるの？"


translate japanese kira20_714495ac:


    kira "まあ、私たちの大学には言語のための外国交換プログラムがあります。国際貿易のためにね。"


translate japanese kira20_67a82fd5:


    kira "私は彼女のホストですが、彼女は私たちの言語を学ぶことに興味がないようです。"


translate japanese kira20_25b067eb:


    kira "彼女は完璧なスタイル、理想的な体型と美しい顔を持っています。"


translate japanese kira20_9fca5bb8:


    kira "それで、私は彼女のOSMになる機会を得ました。"


translate japanese kira20_23c22a5e:


    d "彼女のOSM？"


translate japanese kira20_822c4b60:


    kira "OnlyStan マネージャー!"


translate japanese kira20_2540386d:


    d "それは何ですか？"


translate japanese kira20_0d95348d:


    kira "あの... OnlyStanを知っていますか？"


translate japanese kira20_87fc9282:


    d "それについて聞いたことがあります。それはちょっと...なコンテンツクリエイタープラットフォームです。"


translate japanese kira20_7caab17d:


    kira "大人向けですね。いろいろなものが含まれていますね！"


translate japanese kira20_470a0ba6:


    kira "彼女は自分が何をしたいのかわからないので。"


translate japanese kira20_c9052c34:


    kira "私は彼女のためにそこでアカウントを開設して、少しお金を稼がせました！"


translate japanese kira20_bec902dc:


    d "どういうことですか？"


translate japanese kira20_f0c1cba5:


    kira "基本的に、彼女はそのアカウントに触れず、私が管理しています。"


translate japanese kira20_36c8d6dc:


    kira "彼女のために週刊スケジュールを準備します。月曜日はビーチに行ってビキニの写真を撮ります。"


translate japanese kira20_7a54482d:


    kira "火曜日はプールに行く... 水曜日はベッドで自分の写真を撮る..."


translate japanese kira20_a4a39f55:


    d "彼女はそれをするのですか？"


translate japanese kira20_f1dc0a9e:


    kira "そうだね！彼女はすでに電話で不満そうに過ごしていた。"


translate japanese kira20_9d72dc9f:


    kira "私たちは何も変えない... ただ彼女の写真でお金を稼いでいるだけだ！"


translate japanese kira20_1bda52ce:


    d "あの... もし彼らがより挑発的なことを求めてきたら？"


translate japanese kira20_d26751e5:


    kira "ああ、それは彼女次第だ！私はリクエストを渡すだけで、彼女がそれをやりたいかどうか決める。"


translate japanese kira20_4e452bbd:


    d "ああ..."


translate japanese kira20_4dba9ffa:


    kira "良いお金を稼ぎたいなら、そうするのが普通だと思う。サブスクリプションは良いけれど、もっと個人的なリクエストの写真が本当に稼げる方法だ。"


translate japanese kira20_8f92cc28:


    d "それは売春に近くないですか？"


translate japanese kira20_7afac9f9:


    kira "さて、これで私があなたが出会った中で一番ホットで美しいポン引きだと言えるわね！"


translate japanese kira20_d912e36d:


    d "私はそんなつもりじゃなかった。ただ、あなたは彼女の体でお金を稼いでいるだけだ。"


translate japanese kira20_bda08395:


    kira "ハハ！彼女は文句を言っていないよ！"


translate japanese kira20_a1cb4e30:


    d "まあ、彼女がその言語を話せなければ、彼女はできない…"


translate japanese kira20_db2aa7b3:


    kira "彼女が稼ぐ額の80パーセントを彼女が受け取り、私が管理、整理、そして彼女のメッセージに返信するために20パーセントを取ります。"


translate japanese kira20_85110e9c:


    d "ああ、彼女が返事をしているわけではないのですね？"


translate japanese kira20_778d6ef8:


    kira "だめ！彼女には無理だった！"


translate japanese kira20_9feafa6e:


    kira "私は彼女になりすまして、彼女に話しかける男たちに彼女の写真をいいねして、新しい写真もチェックするよう促します。"


translate japanese kira20_6d7a39b0:


    d "それはかなり良い環境のようですね。"


translate japanese kira20_bc15f278:


    kira "うん、これは他のプロジェクトのためにも私を鍛えてくれるんだ！これを一生続けるつもりはないよ！趣味のようなものだね。"


translate japanese kira20_cadb9a4f:


    d "変わった趣味だね！"


translate japanese kira20_f695fe29:


    kira "はは！今、彼女に写真を撮ってもらうように言うよ、見てて！"


translate japanese kira20_a6c2d4ec:


    kira "ファニー！部屋の真ん中に行って、あなたの写真を撮るつもりです。"


translate japanese kira20_f0657274:


    "はい。"


translate japanese kira20_d7331970:


    kira "ほら、彼女は私の言うことを聞いてる！"


translate japanese kira20_9a3fd59f:


    kira "もっとお尻を見せて！"


translate japanese kira20_e099747a:


    d "じゃあ... お二人に任せるね！また後で？"


translate japanese kira20_edceb7aa:


    kira "うん！興味があれば、彼女のOnlyStanをチェックしてみて！"


translate japanese kira20_65fdf5f6:


    d "うーん…考えてみます！"


translate japanese debiles20_ee280869:


    mac "それから彼は私を川まで呼び出すの！"


translate japanese debiles20_0b75be13:


    ben "くそ！"


translate japanese debiles20_8cf98d22:


    mac "そう、ポケットエースを持っていたんだ、わかる?"


translate japanese debiles20_0b75be13_1:


    ben "くそ！"


translate japanese debiles20_d3c96603:


    mac "彼はフラッシュを引いたから、大丈夫だよ！"


translate japanese debiles20_ea8b6fa1:


    mac "また私のエースが割れた！"


translate japanese debiles20_0b75be13_2:


    ben "くそ！"


translate japanese debiles20_1300bd7d:


    mac "うん！本当に、あいつらは遊び方を知らない！"


translate japanese debiles20_a01646a5:


    ben "うん、私も同じだったよ、先日..."


translate japanese debiles20_e9adca6b:


    "" with hpunch


translate japanese debiles20_dd5d68f3:


    d "えっ？"


translate japanese debiles20_983ef4f8:


    s "スティーブンを待っていないの？"


translate japanese debiles20_5ee1a6cf:


    "" with hpunch


translate japanese debiles20_27a3722f:


    s "パーティーの王がここにいる！"


translate japanese debiles20_5ee1a6cf_1:


    "" with hpunch


translate japanese debiles20_825642f5:


    d "パーティーの王様？"


translate japanese debiles20_84f4497b:


    sofia "ああ、あの男は自分がすごいと思っているみたいだ..."


translate japanese debiles20_dd5d68f3_1:


    d "え？"


translate japanese debiles20_7bdad836:


    sofia "基本的に、彼らは毎年パーティーを開いていて、それが彼らが参加できる最高のパーティーだと思っているのです…"


translate japanese debiles20_18000c7a:


    sofia "しかし結局、彼らはただお互いに行き着き、何も計画せず、飲んでソファで気絶してしまう..."


translate japanese debiles20_a99b3fad:


    sofia "パーティーの王たち。"


translate japanese debiles20_9e386227:


    d "まぁ…"


translate japanese debiles20_d6f6da9b:


    s "本物の男が何かをこの娘たちに見せてあげよう！"


translate japanese debiles20_5ee1a6cf_2:


    "" with hpunch


translate japanese blue20_5eee312c:


    d "ここで一人で何をしているのですか？"


translate japanese blue20_9d28e022:


    sofia "みんなが興奮し始める前に、新鮮な空気を吸っているところです！"


translate japanese blue20_baffc8cb:


    d "ワクワクしてる？"


translate japanese blue20_5e9e01cf:


    sofia "うん、わかってるよ。お酒、ゲーム…"


translate japanese blue20_efd9aaae:


    d "それがあまり好きではないのですか？"


translate japanese blue20_ef5e272b:


    sofia "私はそう思います、私はそう思いますが、時々、静かで穏やかな時間を持つことも好きです。"


translate japanese blue20_3655435f:


    d "何か気になることがあるの？"


translate japanese blue20_08958f33:


    sofia "ああ。うーん..."


translate japanese blue20_4876fdd7:


    dpense "彼女は明らかに何かに悩んでいる。"


translate japanese blue20_6fb8f6cb:


    dpense "彼女を元気づけるために何か言うべきかな。"


translate japanese blue20_4b57eba2:


    d "なぜ青いメイクをしないことにしたのかわからないけど、しなくても本当にいい感じに見えるよ。"


translate japanese blue20_36f6f4f8:


    sofia "本当に？"


translate japanese blue20_75efb952:


    d "はい... うまく言えないけれど、あなたの中の何かが変わったような気がします。"


translate japanese blue20_08809f48:


    sofia "はい… まだです。"


translate japanese blue20_b7ba2ada:


    d "そして、あなたも他の人たちのように髪型を変えるつもりですか？"


translate japanese blue20_165ba7f8:


    sofia "ああ... まだ考えていません。"


translate japanese blue20_0e1ed2f6:


    d "はは！冗談だよ！ただ、みんなの女の子たちが変わっているように見えて、君が目立ちたいと思うかもしれないと思ったんだ..."


translate japanese blue20_e69d927e:


    sofia "私の妹..."


translate japanese blue20_1ecede8d:


    d "ああ... いや、他の人たちから言おうと思ったんだけど。"


translate japanese blue20_4f768d0a:


    sofia "ああ。はい。わかりません。"


translate japanese blue20_fba1bb14:


    sofia "パーティーが本格的に始まる前に、トイレに行ってくるよ。ちょっと頭をスッキリさせるためにね。"


translate japanese blue20_1cda50cf:


    d "あ？わかった！"


translate japanese blue20_97785a33:


    d "じゃあ、またね？"


translate japanese blue20_231069d2:


    sofia "はい、それではまた後で！"


translate japanese blue20_2476d037:


    dpense "彼女は妹と問題を抱えているのか？"


translate japanese blue20_d6acb73c:


    dpense "変だ..."


translate japanese red20_b983e6dc:


    beth "プレイしたいですか？"


translate japanese red20_49f5c417:


    d "ボスの話を聞きましたか？"


translate japanese red20_55418a01:


    beth "うん、でもそれは大したことじゃない。彼は私に何も拒否できない。もちろん、テーブルに誰かがいて遊ぶことを拒否することもできない。"


translate japanese red20_b7783d6e:


    beth "それで、プレイしたいですか？"


translate japanese red20_48ae9e3d:


    d "うん、それはクールだね！"


translate japanese red20_655febea:


    beth "クール！聞いて、私はあなたのためにテーブルに1000ドルを入金します。"


translate japanese red20_5731001e:


    beth "もし勝ったら、私に$1000を返して、残りはあなたのものです。"


translate japanese red20_b836592c:


    beth "もし負けたら…別の方法で埋め合わせをしなければならない。"


translate japanese red20_f36a5ff4:


    d "はい！"


translate japanese red20_f26b2c0b:


    beth "完璧！"


translate japanese red20_c6b71068:


    d "いいえ、私は大丈夫です。"


translate japanese red20_1e03c0a4:


    d "そんな男たちと一緒にいたくない..."


translate japanese red20_9d3c5279:


    beth "本当に大丈夫？足りなければお金を貸すよ！"


translate japanese red20_f337b71d:


    d "いいえ、私は興味がありません。"


translate japanese red20_b811790e:


    beth "大丈夫！"


translate japanese emerick20_bdd5c9e4:


    emerick "誰かがあなたのために保証することを決めたようですね…。"


translate japanese emerick20_cd4e2af9:


    emerick "とにかく… もしよければ、私たちと遊んでいいよ。"


translate japanese emerick20_56454df3:


    emerick "私たちは2時間遊ぶので、終わるまであなたは出られません！"


translate japanese emerick20_6b777721:


    emerick "私たちと対戦したいですか？"


translate japanese emerick20_80bb8032:


    d "うん。あなたの実力を見るのが楽しみです。"


translate japanese emerick20_8cbc8217:


    emerick "あまり自信を持ちすぎないで..."


translate japanese emerick20_d86ce540:


    d "あ...あ...あ...いえ！"


translate japanese emerick20_d598134a:


    d "私は一晩中ここにいたくない。"


translate japanese emerick20_0093a926:


    emerick "では、なぜここに来て私たちの時間を無駄にしたのですか？"


translate japanese kira20poker_3feab173:


    d "キラ... あなたのいとこを手伝ってくれませんか？"


translate japanese kira20poker_271d1f62:


    kira "え？"


translate japanese kira20poker_148ff3e5:


    d "彼は私が彼と彼の仲間たちとポーカーをするのを望んでいない。"


translate japanese kira20poker_afa7eb49:


    kira "あら？"


translate japanese kira20poker_e0facd95:


    kira "心配しないで、あなたを招待することを彼に伝えるよ。"


translate japanese kira20poker_b7378a12:


    kira "彼は拒否できない。"


translate japanese kira20poker_227865d4:


    d "本当に確かですか？"


translate japanese kira20poker_9b0d0415:


    kira "はい、はい！続けて、言ったでしょ！"


translate japanese kira20poker_b01d0032:


    d "ああ、素晴らしい、ありがとう！"

translate japanese strings:


    old "Meet me in the bathroom up there"
    new "上のトイレで会いましょう。"


    old "Um... Why?"
    new "うーん… なんで？"


    old "Hurry up... We don't have much time..."
    new "急いで... あまり時間がない..."


    old "Accept[TEMP1!t]"
    new "受け入れる"


    old "Decline[TEMP2!t]"
    new "辞退"


    old "Okay... I'll be right there."
    new "わかった... すぐに行くよ。"


    old "I'm not sure if that's a good idea..."
    new "それが良い考えかどうか分からない..."


    old "I understand... Maybe some other time then."
    new "わかった…じゃあ、また今度。"


    old "Yes (Advance time and ends free-roam)"
    new "はい (時間を進めて自由な移動を終了します)"


    old "No, maybe later..."
    new "いいえ、たぶん後で..."




translate japanese kira20_42ec4458:


    kira ""


translate japanese kira20_552d5dfd:


    d ""


translate japanese emerick20_6f369099:


    emerick ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
