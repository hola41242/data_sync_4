


translate japanese afterpoker_26fc436e:


    emerick "" with hpunch


translate japanese afterpoker_e128b8b4:


    d "いいゲームだね、エメリック。"


translate japanese afterpoker_59e4a75a:


    emerick "" with hpunch


translate japanese afterpoker_3c955927:


    d "運が私の味方だったと思う。"


translate japanese afterpoker_dd4d55fe:


    emerick "運？冗談はやめて。私は負けない。これは終わりじゃない。"


translate japanese afterpoker_77e65e36:


    dpense "エメリックは怒っている。彼はこの敗北を受け入れられないようだ。"


translate japanese afterpoker_3745a13a:


    beth "素晴らしい、[name]。"


translate japanese afterpoker_dea409f1:


    dpense "ベスは夜通し私を見つめている。彼女が何を考えているのか気になる。"


translate japanese afterpoker_63c46105:


    beth "もう少し長くいてくれませんか？"


translate japanese stay_with_beth_12cbaf67:


    beth "良かった。君が正しい選択をすることを知っていた。"


translate japanese stay_with_beth_13637baa:


    dpense "彼女には何か特別なものがある... とても commandingで、とても irresistible。"


translate japanese stay_with_beth_5927b544:


    beth "座ってください。"


translate japanese stay_with_beth_2c4b2623:


    dpense "彼女の口調は反論の余地を残さない。"


translate japanese stay_with_beth_50a31f22:


    beth "いい子。"


translate japanese stay_with_beth_a6ab9cc9:


    beth "知ってるよ、[name]、ずっと君を見ていたんだ。"


translate japanese stay_with_beth_e9aab196:


    beth "私は見ているものが好きです。"


translate japanese stay_with_beth_7dd0a916:


    dpense "彼女はとても自信に満ちていて、非常に支配的です。それは脅威でもあり、同時に刺激的でもあります。"


translate japanese stay_with_beth_51848909:


    beth "こちらに来て。"


translate japanese stay_with_beth_270f026f:


    beth "今。"


translate japanese stay_with_beth_5d63b95b:


    dpense "彼女には抗えない。彼女の権威は魅力的だ。"


translate japanese stay_with_beth_df740f72:


    beth "ひざまずいてください。"


translate japanese stay_with_beth_4d0f74d6:


    d "はい、ベス。"


translate japanese stay_with_beth_00872fa6:


    dpense "私はこれほど命令的な人を見たことがありません。彼女の支配力は圧倒的です。"


translate japanese stay_with_beth_3b4a1fbe:


    beth "私を食べて。"


translate japanese stay_with_beth_79dc6287:


    dpense "彼女の言葉は私の背筋をぞくぞくさせる。"


translate japanese stay_with_beth_8a2ed47c:


    dpense "彼女の香りは魅惑的です。彼女の味は圧倒的です。"


translate japanese stay_with_beth_217d20bd:


    beth "はい、その通りです。止まらないでください。"


translate japanese stay_with_beth_8752824b:


    dpense "彼女は私の頭を自分に押し付け、主導権を握る。強烈だけど、私はそれが大好きだ。"


translate japanese stay_with_beth_03fc9228:


    beth "よくやっている。続けて。"


translate japanese stay_with_beth_5b7fdae8:


    dpense "彼女の支配は私をさらに興奮させている。彼女を喜ばせたい、彼女に素晴らしい気分を味わわせたい。"


translate japanese stay_with_beth_d9f34e3d:


    beth "私は近い... 今止まるなんて許さない！"


translate japanese stay_with_beth_ee2d4b4c:


    dpense "彼女の体が震えているのが感じられる。彼女はとても近い。"


translate japanese stay_with_beth_3a93f79f:


    beth "ああ… そうそう！"


translate japanese stay_with_beth_39e51c28:


    dpense "彼女のオーガズムは強力だ。彼女は私の頭をしっかりと掴み、私をその場に留めている。"


translate japanese stay_with_beth_f72b2ae0:


    beth "今、あなたの番です。"


translate japanese stay_with_beth_804a34c9:


    beth "テーブルに横たわってください。"


translate japanese stay_with_beth_1b4e9d65:


    dpense "彼女は完全に主導権を握っている。それは爽快だ。"


translate japanese stay_with_beth_824d66ce:


    beth "あなたを再び絶頂に達するまで乗り続けるつもりだ。"


translate japanese stay_with_beth_c59d4f05:


    dpense "彼女の自信は陶酔させる。彼女が私の上にいるのを感じるのが待ちきれない。"


translate japanese stay_with_beth_7da8c02e:


    dpense "彼女の動きは完璧だ。彼女は完全にコントロールしていて、すごく気持ちいい。"


translate japanese stay_with_beth_2836d3f7:


    beth "はい、その通りです。動かないでください。"


translate japanese stay_with_beth_dcc9adf8:


    dpense "私は自分が近づいているのを感じている。彼女の支配が私を限界に追い込んでいる。"


translate japanese stay_with_beth_4f7ab2b2:


    beth "私はまた来る。私が終わる前に絶対に終わらせないで！"


translate japanese stay_with_beth_96dca394:


    dpense "彼女の言葉、彼女の支配... それはあまりにも多すぎる。私は..."


translate japanese stay_with_beth_54eb3554:


    beth "今！"


translate japanese stay_with_beth_da6a63b9:


    dpense "もはや我慢できない。"


translate japanese stay_with_beth_6841e6fc:


    d "ああああああ!!!!"


translate japanese stay_with_beth_c10f8726:


    d "ああ、神様！"


translate japanese stay_with_beth_d35fe4c2:


    d "Fshhh..."


translate japanese stay_with_beth_8f3148fe:


    dpense "待って、彼女は何をしているの？"


translate japanese stay_with_beth_4a484680:


    beth "サプライズ！"


translate japanese stay_with_beth_23d91f6d:


    beth "観客がいます。笑ってください！"


translate japanese stay_with_beth_f2258407:


    d "" with hpunch


translate japanese stay_with_beth_0d5b52a6:


    ruby "ああ、神様！"


translate japanese stay_with_beth_64d9349d:


    grace "何だって...?"


translate japanese stay_with_beth_f37737eb:


    mad "嫌悪感！"


translate japanese stay_with_beth_46038782:


    sofia "やあ、女の子たち！何を..."


translate japanese stay_with_beth_81e7c462:


    sofia "[name]???"


translate japanese stay_with_beth_9521deef:


    sofia "どうしてこんなことができたの？！"


translate japanese stay_with_beth_53155274:


    dpense "ソフィア..."


translate japanese stay_with_beth_8690e0c0:


    dpense "いいえ..."


translate japanese stay_with_beth_21a32b9c:


    beth "あなた..."


translate japanese stay_with_beth_98249955:


    beth "それは..."


translate japanese stay_with_beth_5681410d:


    beth "私の！"


translate japanese stay_with_beth_119586b3:


    beth "あなたは今、家に帰ることができると思います。"


translate japanese stay_with_beth_9e386227:


    d "うーん..."

translate japanese strings:


    old "Sure, why not?[TEMP1!t]"
    new "もちろん、なぜダメですか？[TEMP1!t]"


    old "No, thanks.[TEMP2!t]"
    new "いいえ、結構です。[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
