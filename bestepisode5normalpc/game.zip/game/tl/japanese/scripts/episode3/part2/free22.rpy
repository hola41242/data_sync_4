


translate japanese free22_1be28055:


    kira "もう負けたの？"


translate japanese free22_77d71485:


    d "うん... 君のいとこはとても運がいいね..."


translate japanese free22_fc89a466:


    kira "ただプレイの仕方がわからないと認めて！"


translate japanese free22_f338cc08:


    d "うーん..."


translate japanese free22_272aa8c2:


    d "いいえいいえ、私たちはただ休憩を取っているだけだよ！"


translate japanese free22_9b3fe7b3:


    kira "ああ、わかった！"


translate japanese free22_f4034d91:


    kira "もしアドバイスを一つできるなら..."


translate japanese free22_88283594:


    kira "エメリックは自分が何をしているのか知っている。"


translate japanese free22_e11ee7fa:


    kira "しかし、あなたがある時点で優位性があると思うなら..."


translate japanese free22_ae5d5593:


    kira "彼にそれを持っていると信じさせて。"


translate japanese free22_d42fe897:


    kira "彼はあなたに全てを与える…"


translate japanese free22_2c3a63c7:


    d "何を意味しているのですか？"


translate japanese free22_f291fd44:


    kira "彼の誇りを利用する"


translate japanese free22_7eff095c:


    d "いいえ... 私は試してみる。"


translate japanese free22_0ba5d46b:


    ruby "" with hpunch


translate japanese free22_e3a83ad3:


    grace "はい、ここは静かすぎます！"


translate japanese free22_a3fb43b8:


    ruby "待って、踊れるようにこのテーブルを少し動かすね！"


translate japanese free22_468861f3:


    d "ダンス？"


translate japanese free22_b9488c59:


    ruby "はい！気に入らないですか？"


translate japanese free22_40cb86c2:


    d "はい、好きです！でも、あなたが踊るのが好きだとは知らなかった！"


translate japanese free22_01a43774:


    d "あぁ、いや… 私には向いていない… でも、あなたが踊るのが好きだとは知らなかった！"


translate japanese danse22_4f62b28b:


    ruby "" with vpunch


translate japanese danse22_980d278f:


    ruby "でも、グレース..."


translate japanese danse22_3deed7ed:


    d "本当に？"


translate japanese danse22_fb565796:


    ruby "待って、座って... そして見て！"


translate japanese danse22_dd5d68f3:


    d "え？"


translate japanese danse22_69c1622d:


    d "わあ！！！そんなことは予想していませんでした！"


translate japanese danse22_a955a3b7:


    ruby "言ったでしょう！"


translate japanese danse22_5f558a08:


    dpense "このリズム..."


translate japanese danse22_16f3e257:


    dpense "その動き..."


translate japanese danse22_6f3e5dad:


    dpense "彼女は本当に女神だ..."


translate japanese danse22_d769145c:


    dpense "彼女が音楽に合わせて流れる様子..."


translate japanese danse22_88ff6449:


    dpense "彼女は一歩ごとに物語を語っているようだ..."


translate japanese danse22_1a96938b:


    dpense "彼から目を離せない..."


translate japanese danse22_165575e4:


    dpense "その動きはすべて魅力的です..."


translate japanese danse22_df9bdb38:


    dpense "グレースは部屋の中の全員を魅了しています..."


translate japanese danse22_be93a8b1:


    grace "どう思いますか？"


translate japanese danse22_8b5925da:


    d "あなたは…"


translate japanese danse22_5ed46a7b:


    d "素晴らしい..."


translate japanese danse22_442f607d:


    grace "ありがとう！"


translate japanese danse22_092218ab:


    hec "ああ、確かにここには何か才能がありますね！"


translate japanese danse22_7c71854d:


    kira "ショーはまだ終わっていない！"


translate japanese danse22_dd5d68f3_1:


    d "え？"


translate japanese danse22_bd15cdba:


    dpense "あ･･･"


translate japanese danse22_7a82419b:


    dpense "私の…"


translate japanese danse22_1dfd470a:


    dpense "神様..."


translate japanese danse22_46359b02:


    dpense "なんて尻だ..."


translate japanese danse22_eadce89f:


    dpense "くそ..."


translate japanese danse22_58235d12:


    dpense "彼女に対して私がすること..."


translate japanese danse22_ef768a8f:


    d "うんうん... あなたもいいね！"


translate japanese danse22_52a1acec:


    kira "あはは！わかった！"


translate japanese danse22_655b2071:


    hec "メモを取れ、フレンチie！"


translate japanese danse22_e48c9cb0:


    d "うーん..."


translate japanese danse22_d4f312f9:


    d "マイナス？"


translate japanese danse22_b89db320:


    ruby "はい？"


translate japanese danse22_7b984d44:


    d "行ってくれ... 音量を上げてくれ！"


translate japanese danse22_335a5311:


    ruby "オー？わかった！"


translate japanese danse22_9e11135f:


    dpense "そして今…"


translate japanese danse22_2798004b:


    d "見せる時間だ！"


translate japanese danse22_a33e428d:


    ruby "見せてあげて [name]!"


translate japanese danse22_7caf9fa9:


    grace "うわあ！"


translate japanese danse22_5477c44c:


    ruby "[name]! [name]! [name]!"


translate japanese danse22_58203668:


    ruby "すごい！どこでそれを学んだの？"


translate japanese danse22_1994e955:


    d "ああ... 友達と外出して踊るのが好きなんだ、わかる？..."


translate japanese danse22_0a44a128:


    grace "とても良かった！"


translate japanese danse22_38e03a72:


    d "ハハ！ありがとう！"


translate japanese danse22_17420bbd:


    hec "むぅ……"


translate japanese danse22_c81eac44:


    d "ええ、ええ…"


translate japanese danse22_22d2064c:


    dpense "あなたは私が気にしているかのように話しています..."

translate japanese strings:


    old "10:00 PM"
    new "10:00 PM"


    old "Yes, I do![TEMP1!t]"
    new "はい、そうです！[TEMP1!t]"


    old "Uh, not really!"
    new "ああ、あまりそうでもない！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
