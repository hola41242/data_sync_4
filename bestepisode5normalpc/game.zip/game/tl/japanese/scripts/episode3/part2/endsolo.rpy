


translate japanese endsolo_514498de:


    dpense "さて、私は戻ってきました、私の部屋に…"


translate japanese endsolo_6ef229a3:


    dpense "こんな風に夕方が終わるとは思っていなかった..."


translate japanese endsolo_e38a6085:


    dpense "明日、私は多分もっとやることがあるだろう…"


translate japanese endsolo_33e62c6e:


    dpense "ジュリアを病院に同行する..."


translate japanese endsolo_7791dddf:


    dpense "美術館でガブリエラに会う..."


translate japanese endsolo_be37121e:


    dpense "マディソンとのその有名なディナーに参加する..."


translate japanese endsolo_fe3f28ed:


    dpense "とにかく、今晩は面白かった。"


translate japanese endsolo_49647293:


    dpense "あのキラは魅力的だ..."


translate japanese endsolo_1cfe3d36:


    dpense "でも、まだエリーゼからの知らせは聞いていない..."


translate japanese endsolo_1ea70810:


    dpense "彼女らしくない..."


translate japanese endsolo_517c34b4:


    dpense "次に何が起こるか見てみましょう..."


translate japanese endsolo_43441124:


    orushi "シモンズ！これがオルシです！"


translate japanese endsolo_29a690d4:


    orushi "あなたの方はどうですか？"


translate japanese endsolo_0ba913d0:


    "進展しています..."


translate japanese endsolo_6c05280d:


    "フェーズ二の準備がほぼ整いました。"


translate japanese endsolo_49eecb65:


    orushi "もう？"


translate japanese endsolo_334961ea:


    "うん... あなたの方はどう？"


translate japanese endsolo_ef8e4566:


    orushi "次のステップに備えて、少しスピードアップします。"


translate japanese endsolo_2474301e:


    "そして他の人たちは？"


translate japanese endsolo_54f4af4a:


    orushi "同じ。みんなほぼ同じレベルだ..."


translate japanese endsolo_88825eb1:


    "完璧！"


translate japanese endsolo_656c418e:


    orushi "では。次のフェーズでお会いしましょう。"


translate japanese endsolo_f19f8ae6:


    "だ！"




translate japanese endsolo_220827a5:


    dpense ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
