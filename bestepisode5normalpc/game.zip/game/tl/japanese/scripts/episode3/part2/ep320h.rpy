


translate japanese ep320h_2d397f37:


    emerick "だから、今夜一緒にパーティーする準備はできてる？"


translate japanese ep320h_32390969:


    "はい！"


translate japanese ep320h_5b232966:


    emerick "フレンチ！今はどうやって着るか知ってるの？"


translate japanese ep320h_328830e7:


    emerick "服は人を作るわけではないことを知っていますか？"


translate japanese ep320h_7e51d70c:


    hec "さて、白い騎士が…"


translate japanese ep320h_6a2dc343:


    hec "あなたのピンキーは一緒ではないのですか？"


translate japanese ep320h_b6fde834:


    mad "ヘクター、黙っておくべきだ。さもないと、口を開いたことを後悔させるから！"


translate japanese ep320h_ec2abea6:


    emerick "ふむ、ふむ... マディソンが oppressed を守っている..."


translate japanese ep320h_48df3ce2:


    julia "私たちはすべてを見てきた..."


translate japanese ep320h_4da915b8:


    julia "でもマディソン、ありがとう... サポートに感謝している。"


translate japanese ep320h_d8adca3a:


    d "わかった… 何かを教えてほしい…"


translate japanese ep320h_2307991b:


    ruby "何？"


translate japanese ep320h_cbbc64d1:


    d "あなたたちは本当に髪のことで何か問題がありますか？"


translate japanese ep320h_6b0b0af2:


    ruby "え？"


translate japanese ep320h_e513a108:


    d "あなた、マディソン、ジュリア... もうすぐグレースも青い髪になる..."


translate japanese ep320h_33793f20:


    ruby "女性はしばしば変わることを誰も言わなかったのですか？"


translate japanese ep320h_dd5d68f3:


    d "え？"


translate japanese ep320h_b8f092fd:


    ruby "そうだね... 何か... または誰かが女性に変化をもたらすと..."


translate japanese ep320h_eb0cdf0c:


    ruby "彼女は変わる..."


translate japanese ep320h_51dd6509:


    d "そして、あなたたちはどうしてこんな風に一人ずつ変わってしまうのですか？"


translate japanese ep320h_85e25575:


    ruby "バカなことを言わないで！"


translate japanese ep320h_ccf9fa2a:


    ruby "そして、グループ効果もあります！"


translate japanese ep320h_0e7c633f:


    ruby "生理周期の同期に似たようなもの..."


translate japanese ep320h_431c81ae:


    d "" with hpunch


translate japanese ep320h_2307991b_1:


    ruby "何？"


translate japanese ep320h_70104ecf:


    emerick "さあ、テーブルが私たちを待っていますよ、みんな！"


translate japanese ep320h_32390969_1:


    "はい！"


translate japanese ep320h_48ca22b2:


    emerick "もちろん、私はあなたについて話しているわけではなかったんだ、フレンチ。"


translate japanese ep320h_1523fe20:


    d "..."


translate japanese ep320h_0a3b9a9e:


    "" with vpunch


translate japanese ep320h_3283d5fb:


    d "誰が…"


translate japanese ep320h_bc430bec:


    "そのついでに、あまり騙さないようにしてね！"


translate japanese ep320h_65dd16d6:


    "かわいそうな彼らは、もう名誉がありません。もしあなたが彼らのお金を奪ったら、もっとひどいことになるでしょう…。"


translate japanese ep320h_21ef69aa:


    ruby "princessが到着しました..."


translate japanese ep320h_74d8ea2d:


    d "王女？"


translate japanese ep320h_db6ebde1:


    ruby "はい… あなたに紹介させてください…"


translate japanese ep320h_8a332571:


    ruby "キラ・オルシ。"


translate japanese ep320h_d52ff3a3:


    d "" with hpunch


translate japanese ep320h_88407b4c:


    ruby "うん... 彼の娘。"


translate japanese ep320h_8e04f38b:


    ruby "彼女はエメリックのいとこで、…なんて言えばいいかな…"


translate japanese ep320h_baf02865:


    ruby "彼は彼女の周りでは縮んでしまう。"


translate japanese ep320h_515638be:


    ruby "もしエメリックが自分の影響力で大物ぶった行動をしたら..."


translate japanese ep320h_b45b2506:


    ruby "キラは指を鳴らすだけで、どんな場所でも彼を追い出すことができる。"


translate japanese ep320h_3deed7ed:


    d "本当に？"


translate japanese ep320h_4bb3aaa2:


    ruby "はい... 彼らがうつむきながら歩いていくのを見て。"


translate japanese ep320h_afb43a4a:


    ruby "彼らは打ちひしがれた犬のように見える..."


translate japanese ep320h_4e9c7294:


    d "でも、なぜ..."


translate japanese ep320h_3d792aab:


    ruby "彼女は国で最も強力な女の子の一人です..."


translate japanese ep320h_a1e5b9c0:


    ruby "インフルエンサー、力、彼女が相続する父の会社..."


translate japanese ep320h_da574b0b:


    ruby "彼女が見事に運営している多くのビジネス。"


translate japanese ep320h_09de2a72:


    ruby "彼女は自分のイメージを完璧にコントロールしている..."


translate japanese ep320h_ea0a923f:


    ruby "そして…"


translate japanese ep320h_12e4da9d:


    kira "まだ自己紹介をしていません！"


translate japanese ep320h_9cfd5489:


    kira "私はキラです。そして、あなたを私たちの国へようこそ！"


translate japanese ep320h_2969bbf3:


    kira "先ほどのフィールドでのことは本当に申し訳ありませんでした..."


translate japanese ep320h_1567a5c4:


    kira "でも、少しあなたを揺さぶりたかったんです... あなたはもっと良いことができるはずです。"


translate japanese ep320h_c9ceb4e6:


    kira "さあ、今夜を楽しもうか？"


translate japanese ep320h_ee39177b:


    ruby "あ、はい…"


translate japanese ep320h_82e6f175:


    kira "心配しないで、ルビー、すべてうまくいくよ！そして私は君を信じている、きっと君は私たち全員のために素晴らしいことを用意してくれているんだ！"


translate japanese ep320h_b528cca1:


    ruby "はい、はい！実際に、毎時間、家のさまざまな場所でアクティビティが提供されます。"


translate japanese ep320h_8bbb0f7b:


    ruby "ただ歩き回るだけで、参加したい活動を選ぶことができます！"


translate japanese ep320h_fd9b1315:


    ruby "何をすればいいかわからなくなったり、迷ってしまった場合は…。"


translate japanese ep320h_52f91e69:


    ruby "聞きに来て！"


translate japanese ep320h_12346ed5:


    kira "素晴らしい！すべてを見るのが待ちきれない！"


translate japanese ep320h_93d865fe:


    grace "さて、今晩を始める時間だと思う！"


translate japanese ep320h_5ee1a6cf:


    "" with hpunch

translate japanese strings:


    old "8:00 PM"
    new "午後8時"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
