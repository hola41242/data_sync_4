


translate japanese ep319h_288e63cd:


    dpense "もうたくさんの人がいる..."


translate japanese ep319h_5afe9333:


    dpense "みんな着飾っている…"


translate japanese ep319h_13a9fa4a:


    dpense "あの女の子は誰だろう…"


translate japanese ep319h_98025551:


    d "ルビー？？？"


translate japanese ep319h_8ce58592:


    dpense "それは本当にルビーですか？彼女はとても違って見えます..."


translate japanese ep319h_29939e59:


    ruby "はい？ああ、もう来てくれたの？"


translate japanese ep319h_fefd1e11:


    d "わぁ！あなたは素晴らしく見える！"


translate japanese ep319h_0646292d:


    dpense "今夜の彼女がどれほど美しいか、信じられない。"


translate japanese ep319h_5f32c47f:


    ruby "あら？"


translate japanese ep319h_a526621d:


    ruby "ありがとう！"


translate japanese ep319h_ec88a91b:


    ruby "今夜のために、たくさんのことを用意しました。退屈しないことを願っています。"


translate japanese ep319h_ae9dbbe9:


    d "何を用意しましたか？"


translate japanese ep319h_49729cc2:


    dpense "恥ずかしい思いをしませんように…。"


translate japanese ep319h_0ca74eee:


    ruby "見ていなさい。"


translate japanese ep319h_d0c288ce:


    ruby "基本的に、夕方は時間ごとに分かれています。"


translate japanese ep319h_5c4a411a:


    ruby "そして毎時間、私はちょっとした違うゲームを企画しました。"


translate japanese ep319h_4bec68d4:


    ruby "参加するも、しないも、あなた次第です。"


translate japanese ep319h_fafccd1b:


    dpense "ゲーム？これは興味深いか、あるいは災害になるかもしれない…"


translate japanese ep319h_bb1569ab:


    ruby "私はあなたに何も強制しません。とにかく、あなたは家の中を自由に歩き回って構いません。"


translate japanese ep319h_1af2f630:


    ruby "このようなパーティーでは、さまざまな場所で人々と出会うことが多いです。"


translate japanese ep319h_255a7214:


    ruby "中にはガレージでポーカーをしている人もいるので、遠慮せずに周りを歩き回ってください！"


translate japanese ep319h_0a1f2fff:


    ruby "でも、私のゲームのどれかであなたに会えることを願っています。"


translate japanese ep319h_71621c21:


    dpense "彼女のゲームのうちの一つを試してみるべきだ、どんな感じなのかを見るために。"


translate japanese ep319h_dc5092d9:


    d "そうだね、私も準備をしないと…"


translate japanese ep319h_b2c71a98:


    dpense "ちゃんと見えるようにしないといけない..."


translate japanese ep319h_4a431b19:


    ruby "グレースは中であなたを待っているはずです。"


translate japanese ep319h_79e4de0e:


    ruby "彼女に会いに行って、どこで準備をすればいいか教えてくれるよ。"


translate japanese ep319h_15e6cd4c:


    d "じゃあ、またね？"


translate japanese ep319h_153d7992:


    ruby "またね！"


translate japanese ep319h_0cdc2a05:


    dpense "これを台無しにしないことを願っています…"


translate japanese ep319h_0d6e6088:


    d "あなたは美しいです…。"


translate japanese ep319h_fb1b5575:


    grace "ありがとう。"


translate japanese ep319h_62b19db8:


    dpense "彼女にキスをしたいけれど、見られるリスクがある..."


translate japanese ep319h_dd8da065:


    grace "皆がここにいるとき、これほどのことはできないだろう。"


translate japanese ep319h_9f52115e:


    grace "今、利用させてもらうつもりだ。"


translate japanese ep319h_8034db0c:


    d "はい、できるだけ控えめにしましょう。"


translate japanese ep319h_410930f8:


    dpense "彼女の唇はとても柔らかい... この瞬間は短すぎる。"


translate japanese ep319h_3dbd89d8:


    d "パーティー中にあなたに飛びつかないのは難しいだろうな！"


translate japanese ep319h_96c87c04:


    grace "はい..."


translate japanese ep319h_8d61d8e6:


    dpense "彼女がとても欲しいけど、私たちは気をつけなければならない..."


translate japanese ep319h_044e92c2:


    d "気をつけて、誰かに見られるかもしれない。"


translate japanese ep319h_2e68ce35:


    d "運命を誘惑しない方が良い。"


translate japanese ep319h_e2691be7:


    grace "はい、その通りです。"


translate japanese ep319h_429f8aa7:


    dpense "抑えなければならないのは嫌だけど、それは必要なんだ..."


translate japanese ep319h_228cc50b:


    grace "今晩は、あなたが望むことを何でもさせてあげます。"


translate japanese ep319h_ea019296:


    dpense "何でも私が欲しい？これは楽しいかもしれない..."


translate japanese ep319h_0765a666:


    grace "まあ、選択肢はあまりないだろう。"


translate japanese ep319h_cde65b21:


    d "私が欲しいものは何でも？"


translate japanese ep319h_da9605d7:


    grace "もちろん、範囲内で！"


translate japanese ep319h_4fef3683:


    grace "しかし、ルビーのゲームがどのようにデザインされているかを知っていて、もし女の子にキスをしなければならない場合..."


translate japanese ep319h_518dcdae:


    grace "他の人と密に踊る..."


translate japanese ep319h_a89eba91:


    grace "ルビーは挑戦を計画しているので、あなたを責めることはありません。"


translate japanese ep319h_4fa86eb0:


    grace "独身の男のように振る舞えば振る舞うほど..."


translate japanese ep319h_b97bc95a:


    grace "私たちについて疑念を抱く人は少なくなるだろう。"


translate japanese ep319h_d53904b1:


    d "私は同意します。"


translate japanese ep319h_b330e6ff:


    dpense "独り身でいるのは難しいかもしれないが、これが最善だ..."


translate japanese ep319h_cf274390:


    grace "しかし、パーティーの後は、あなたはすべて私のものだ！"


translate japanese ep319h_435babe9:


    dpense "それを待ちきれない..."


translate japanese ep319h_6181ffc8:


    d "レッドが私のために何かを残したか知っていますか？"


translate japanese ep319h_4b78ee47:


    grace "はい、彼女はあなたのコスチュームを上の部屋に置いていきました。"


translate japanese ep319h_39f0500c:


    grace "上に上がって、左のドアを開ければ、ウォードローブの中にあるはずです。"


translate japanese ep319h_659c76cf:


    d "わかった、わかった。ありがとう！"


translate japanese ep319h_fef54646:


    dpense "コスチュームが良く見えることを願っています..."


translate japanese ep319h_5704be0d:


    grace "いいえ、でも心配しないでください。"


translate japanese ep319h_685bd6f6:


    grace "階段を上って、左の部屋に行ってください。"


translate japanese ep319h_194ad930:


    grace "あなたが言った衣装をワードローブから取ることができる。"


translate japanese ep319h_d24354b3:


    grace "それは僕の父のものだった。君には完璧に合うと思う。"


translate japanese ep319h_73e5a328:


    d "どうもありがとう、グレース！"


translate japanese ep319h_f78eebb7:


    dpense "うまく合うことを願っています…"


translate japanese ep319h_86e4c7aa:


    grace "どういたしまして！さあ、行きましょう！"


translate japanese ep319h_e65cbcaf:


    dpense "今夜が何をもたらすのか、準備を整える時です..."


translate japanese ep319h_2928c85d:


    grace "マディソンについて彼に警告しておくべきだったかもしれない…"


translate japanese ep319hmadison_faeed9e5:


    dpense "その脚..."


translate japanese ep319hmadison_7b470d71:


    dpense "そしてその体... 彼女は自分のスタイルを維持するために非常に努力したに違いない。"


translate japanese ep319hmadison_2cceb6e2:


    d "マディソン？"


translate japanese ep319hmadison_95b89350:


    dpense "彼女はここで何をしているの？"


translate japanese ep319hmadison_e9d6e7e4:


    mad "はい？"


translate japanese ep319hmadison_4058aafc:


    mad "ああ！それはあなたですか？"


translate japanese ep319hmadison_005532b2:


    d "ごめんね… スーツを探していたけど、後で戻ってもいいよ、そして…"


translate japanese ep319hmadison_15923c5d:


    mad "いいえ、いいえ。今ここにいるから、私のネックレスをつけるのを手伝って。"


translate japanese ep319hmadison_4974962b:


    d "これ、ベッドの上？"


translate japanese ep319hmadison_548cfe7d:


    mad "うん... また一つ見える？"


translate japanese ep319hmadison_a67f284e:


    d "うーん…いいえ…"


translate japanese ep319hmadison_7bcc50f4:


    d "はい…"


translate japanese ep319hmadison_b338417f:


    d "あなたは本当に美しい。"


translate japanese ep319hmadison_80856c0f:


    dpense "彼女の美しさは否定できないが、私を最も魅了するのは彼女の強さだ。"


translate japanese ep319hmadison_9e40f1b6:


    mad "あなたは震えている。"


translate japanese ep319hmadison_2ce96c5a:


    d "そうだね…こんな素敵な女性に触れるのは慣れていないんだ…"


translate japanese ep319hmadison_c456a93d:


    dpense "彼女は私のことを他の人たちと同じだと思っているに違いない。私は彼女に私が違うことを示す必要がある。"


translate japanese ep319hmadison_83ae8453:


    mad "これは一度きりのことだと言っただろう..."


translate japanese ep319hmadison_5db0af98:


    d "知っています。"


translate japanese ep319hmadison_4e845f8a:


    dpense "しかし、彼女と過ごす一瞬一瞬が、私には不釣り合いな贈り物のように感じる。"


translate japanese ep319hmadison_8b44f43b:


    mad "もう一度やるべきではない..."


translate japanese ep319hmadison_d806887a:


    mad "たとえ私たちの欲望がここにあっても…"


translate japanese ep319hmadison_e99f6e2f:


    dpense "彼女はとても警戒している。彼女が経験したことを考えれば、誰が彼女を責められるだろうか？"


translate japanese ep319hmadison_d00f18cb:


    mad "私たちは..."


translate japanese ep319hmadison_592754b5:


    mad "自分を抑える。"


translate japanese ep319hmadison_bb9305c7:


    mad "でも..."


translate japanese ep319hmadison_48a192a6:


    mad "こんな風には続けられない…"


translate japanese ep319hmadison_1390acac:


    d "私は知っている..."


translate japanese ep319hmadison_a6762298:


    mad "私もできない。"


translate japanese ep319hmadison_916964a1:


    dpense "私は忍耐強くなる必要があります。彼女は再び信頼するための時間が必要です。"


translate japanese ep319hmadison_336548fb:


    mad "これは悪い、褒めるのをやめてください..."


translate japanese ep319hmadison_40a2f618:


    d "私はできない…"


translate japanese ep319hmadison_de49923d:


    mad "必要なことを言うのをやめてください..."


translate japanese ep319hmadison_dc3bdbc7:


    d "私はしない..."


translate japanese ep319hmadison_e6ceeb5a:


    mad "止まれ..."


translate japanese ep319hmadison_f0fd1cdb:


    dpense "彼女は誰にも入って来られるのを恐れている。私はその壁を乗り越える方法を見つけなければならない。"


translate japanese ep319hmadison_a75434a9:


    mad "私を待っている女の子たちがいる！"


translate japanese ep319hmadison_81f6fd8e:


    dpense "彼女がただ私を遠ざけようとしているのはわかっているが、私は彼女を諦めることはできない。"


translate japanese ep319hmadison_bbfbae37:


    dpense "今のところ、自分で頑張るしかないようだ。"


translate japanese ep319hsolo_bbfbae37:


    dpense "今のところ、自分一人でやることになりそうだ。"

translate japanese strings:


    old "7:30 PM"
    new "午後7時30分"


    old "Kiss her[TEMP1!t]"
    new "彼女にキスする[TEMP1!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
