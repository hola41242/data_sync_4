


translate japanese free00_6b4b0cf1:


    grace "さて、友達..."


translate japanese free00_679a2306:


    grace "ごめんなさい、でも母に真夜中までに夜を終わらせると約束したよ…"


translate japanese free00_98a03685:


    ruby "もう？"


translate japanese free00_fc5d43b7:


    grace "はい… 彼女は約1時間後に帰宅しますし、彼女が到着する前にここにいない方が良いです…"


translate japanese free00_34d48dad:


    ruby "問題ない！さあ、みんな！シンデレラをメイドに変える時が来た。"


translate japanese free00_45282a81:


    grace "私と一緒にいてくれる？"


translate japanese free00_aa7a6ace:


    d "もちろん！"


translate japanese free00_6ff5bfb7:


    ruby "さあ、出発しよう！"


translate japanese free00_9cab7c01:


    d "私はここにグレースと一緒にいて、彼女の片付けを手伝います！"


translate japanese free00_dc303eb0:


    ruby "うん、うん、わかった！掃除して…"


translate japanese free00_5fb753fe:


    ruby "また明日！"


translate japanese free00_a6a8874f:


    mad "また明日、みんな！"


translate japanese free00_0eaf48fc:


    d "また明日！"


translate japanese free00_c47afec2:


    grace "また明日！"


translate japanese free00_ac896290:


    d "いいえ、そうはしたくない..."


translate japanese free00_0dceca55:


    grace "ああ..."


translate japanese free00_13a7d26b:


    ruby "じゃあ、明日ね！"


translate japanese free00_a6a8874f_1:


    mad "皆さん、明日お会いしましょう！"


translate japanese free00_0eaf48fc_1:


    d "明日会いましょう！"


translate japanese free00_c47afec2_1:


    grace "また明日！"


translate japanese free00_6ff5bfb7_1:


    ruby "さあ、出発しよう！"


translate japanese free00_a6a8874f_2:


    mad "また明日、みんな！"


translate japanese free00_0eaf48fc_2:


    d "また明日！"


translate japanese free00_c47afec2_2:


    grace "また明日！"

translate japanese strings:


    old "00:00 AM"
    new "午前00:00"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
