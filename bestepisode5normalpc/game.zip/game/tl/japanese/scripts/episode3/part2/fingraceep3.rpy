


translate japanese fingraceep3_122be50a:


    grace "部屋まで送ってくれてありがとう、[name]。今夜はとても楽しかった。"


translate japanese fingraceep3_426cd657:


    d "私もだよ、グレース。素晴らしい夕方だった。"


translate japanese fingraceep3_4b3a0964:


    grace "えっと、これは私の部屋です。大したことはないけれど、居心地がいいです。"


translate japanese fingraceep3_0e9f56a6:


    dpense "グレースは少し緊張しているようだ。それがなんだか愛らしい。"


translate japanese fingraceep3_b0f25365:


    grace "少し楽な服に着替えてきます。くつろいでいてください。"


translate japanese fingraceep3_815640c8:


    d "ゆっくりしてください。"


translate japanese fingraceep3_9e3f7bee:


    dpense "グレースの部屋にいるなんて信じられない。今夜はこれまで素晴らしかった、そして今これが…冷静を保たなきゃ。"


translate japanese fingraceep3_197417a0:


    grace "" with vpunch


translate japanese fingraceep3_886abaf6:


    d "わあ！"


translate japanese fingraceep3_4586d679:


    d "グレース、あなたは... 素晴らしいです。"


translate japanese fingraceep3_5d0f5cab:


    dpense "彼女の下着は本当に息を呑むほど美しい。体にぴったりと寄り添う様子... 集中しなければ。"


translate japanese fingraceep3_ba62c79b:


    dpense "彼女の自信は魅力的だ。私は興奮していると同時に少し怖い。これを台無しにしたくない。"


translate japanese fingraceep3_a09e0834:


    grace "それが気に入ってくれて嬉しいです。少し多すぎるかもしれないと心配していました。"


translate japanese fingraceep3_52143285:


    d "完璧です。あなたは信じられないほど素晴らしいです。"


translate japanese fingraceep3_f1edd5b8:


    grace "あなたの上に座ってもいいですか？"


translate japanese fingraceep3_08c3c4ca:


    d "はい。"


translate japanese fingraceep3_d9d93097:


    dpense "私の心臓はドキドキしている。私は物事を落ち着ける必要がある。"


translate japanese fingraceep3_056e239a:


    dpense "彼女のベッドはとても魅力的だけど、急かして彼女を不快にさせたくない。"


translate japanese fingraceep3_93e3c736:


    grace "実は、男の子と一緒に自分の部屋で二人きりになるのは初めてなの。"


translate japanese fingraceep3_2813b2b2:


    d "私は最初であることを光栄に思います。"


translate japanese fingraceep3_32881572:


    dpense "彼女がとても近い... 彼女の香水の匂いがする。酔わせるようだ。"


translate japanese fingraceep3_549668d3:


    dpense "自分を抑えなければならない。彼女を怖がらせたくない。"


translate japanese fingraceep3_67c2a699:


    grace "あなた know... あなたが今夜一緒にいたかった唯一の人です。"


translate japanese fingraceep3_b59160c0:


    d "グレース..."


translate japanese fingraceep3_b397b53c:


    dpense "彼女がそう言うのを聞くと、心臓がドキッとする。彼女も本当にこれを望んでいる。"


translate japanese fingraceep3_75ad9296:


    grace "もう一度キスしてもいい？"


translate japanese fingraceep3_ec9ea850:


    d "それは素敵ですね。"


translate japanese fingraceep3_b76665a2:


    grace "うーん... あなたのキスはいつも私を心の中でとても温かく感じさせてくれる。"


translate japanese fingraceep3_e15e14e0:


    dpense "彼女の唇はとても柔らかく、彼女の反応の仕方は…まるで彼女はこれのために作られたかのようです。"


translate japanese fingraceep3_28a5e0bb:


    dpense "すべてのキスは、何かもっと深いものの約束のように感じる。"


translate japanese fingraceep3_820b5315:


    grace "あなたの触れ方は…まるで私が何を必要としているかを知っているかのようです。"


translate japanese fingraceep3_a35d76bb:


    grace "ああ、それはとても気持ちがいい..."


translate japanese fingraceep3_78709cf8:


    dpense "彼女の肌は信じられないほど柔らかい。彼女が私の触れ方に反応する様子は私を狂わせる。"


translate japanese fingraceep3_0dceca55:


    grace "おお..."


translate japanese fingraceep3_c86f948f:


    dpense "彼女のすべてを探求したいが、優しくしなければならない。これは彼女の初めての経験だ。"


translate japanese fingraceep3_a771222e:


    d "グレース、私が...?"


translate japanese fingraceep3_b449a8b0:


    grace "はい、お願いします。"


translate japanese fingraceep3_378a05b5:


    d "あなたを大切にさせてください。"


translate japanese fingraceep3_dc39bf28:


    dpense "彼女のために、時間をかけて、忘れられないものにしたい。"


translate japanese fingraceep3_0e6387d4:


    grace "うん...ちょっと緊張してる。"


translate japanese fingraceep3_b28a10e6:


    d "心配しないで、ただ感じることに集中して。"


translate japanese fingraceep3_db7c8734:


    d "これはどんな感じですか？"


translate japanese fingraceep3_af9d73bb:


    grace "ああ… それは素晴らしい感覚です。あなたの手はとても温かいです。"


translate japanese fingraceep3_e568dcd6:


    dpense "彼女の肌はとても柔らかい。私の触れ方で彼女がリラックスし始めるのを感じる。"


translate japanese fingraceep3_4f161a1c:


    grace "" with hpunch


translate japanese fingraceep3_5c868772:


    grace "うーん…"


translate japanese fingraceep3_d743f1b7:


    dpense "彼女は濡れてしまう..."


translate japanese fingraceep3_a4adae84:


    d "そして、これ？"


translate japanese fingraceep3_119475ec:


    grace "ゆっくりと...お願い..."


translate japanese fingraceep3_a66ca034:


    grace "" with hpunch


translate japanese fingraceep3_62f474cf:


    grace "あなたの指はとても優しい。まるで私の心を読んでいるみたい。"


translate japanese fingraceep3_26cbeda5:


    dpense "彼女にこれまで感じたことのない感情を感じさせたい。"


translate japanese fingraceep3_a41e6e7a:


    d "今、ただこれを楽しんでください..."


translate japanese fingraceep3_0dceca55_1:


    grace "ああ..."


translate japanese fingraceep3_59945c86:


    grace "ああ、神様…"


translate japanese fingraceep3_c7c1e31e:


    grace "[name]..."


translate japanese fingraceep3_76991c79:


    grace "それは…"


translate japanese fingraceep3_291ded06:


    grace "素晴らしい..."


translate japanese fingraceep3_05caf10b:


    dpense "彼女の味は陶酔的だ。彼女が私の舌に反応する様子... それは私を狂わせている。"


translate japanese fingraceep3_2782f4db:


    grace "こんな気持ちになるなんて知らなかった… まるで全身が生きているかのようだ。"


translate japanese fingraceep3_423e395a:


    dpense "彼女の喘ぎ声は私の耳に音楽のようだ。私は彼女にすべてを与えたい。"


translate japanese fingraceep3_2a70dac6:


    grace "やめないで... どうか、やめないで..."


translate japanese fingraceep3_a7e481d4:


    dpense "彼女の震えを感じることができる、彼女はとても反応がいい。私は彼女にすべての感覚、すべての瞬間を感じさせたい。"


translate japanese fingraceep3_3a697b05:


    grace "私は... 私は行こうとしている... あああ！"


translate japanese fingraceep3_e54511e0:


    dpense "彼女はとても甘い味がする。彼女のクライマックスが高まっているのを感じる。"


translate japanese fingraceep3_3fed4df0:


    grace "あああああああああ！"


translate japanese fingraceep3_e34e7f8a:


    grace "私のいいいいいいいいいいいいい！"


translate japanese fingraceep3_0ee90716:


    grace "ああ、もう…できない…それは…すごい…"


translate japanese fingraceep3_3db97e94:


    dpense "彼女がこんなに満足そうにしているのを見ると…素晴らしい。"


translate japanese fingraceep3_4272566a:


    dpense "今までの人生で誰かにこれほど近く感じたことはありません。"


translate japanese fingraceep3_2b6bfbea:


    grace "私は... さっき飲みすぎたかもしれない。気持ちが悪い..."


translate japanese fingraceep3_c3411169:


    d "大丈夫だよ、グレース。今夜は完璧だった。"


translate japanese fingraceep3_2fda0097:


    dpense "もっと欲しかったけれど、彼女が圧倒されているのがわかる。忍耐強くしなければならない。"


translate japanese fingraceep3_2292c0d6:


    grace "私はそれを本当に楽しんだが、そうしている必要があると思う。お腹が少し調子が悪い。"


translate japanese fingraceep3_078e1e76:


    d "もちろん、少し休もう。"


translate japanese fingraceep3_07f5d822:


    dpense "彼女をこんなふうに抱きしめていると…この瞬間が終わってほしくない。"


translate japanese fingraceep3_84a6230f:


    dpense "彼女の温もり、彼女の柔らかさ…彼女にとても近く感じる。"


translate japanese fingraceep3_c7bfadaa:


    grace "ありがとう、[name]。これは私の人生で最高の夜でした。"


translate japanese fingraceep3_06c6f93b:


    d "私もだよ、グレース。私もだよ。"


translate japanese fingraceep3_56ec7c6e:


    dpense "彼女の感謝は心に響く。彼女を守り、幸せにしてあげたい。"


translate japanese fingraceep3_a28a7494:


    grace "今行った方がいいよ、母がすぐに帰ってくるから、彼女と問題を起こしたくないんだ..."


translate japanese fingraceep3_0e1666ec:


    d "あなたが正しい..."


translate japanese fingraceep3_6049f48d:


    dpense "彼女が私の腕の中で眠りに落ちると、彼女の呼吸がゆっくりと聞こえてくる。完璧だ。"


translate japanese fingraceep3_d8d34b7d:


    dpense "この瞬間を大切にしたい、すべての詳細を覚えておきたい。"


translate japanese fingraceep3_8099769b:


    d "おやすみ、グレース。"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
