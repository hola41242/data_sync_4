


translate japanese bluebathsequence_bfc258f4:


    sofia "そこにいるのか..."


translate japanese bluebathsequence_640cb0b2:


    sofia "急いで、あまり時間がない…"


translate japanese bluebathsequence_39a0fffb:


    sofia "あっ！"


translate japanese bluebathsequence_eaf3c1ee:


    d "これはあなたが望むものですか？"


translate japanese bluebathsequence_5b2496bc:


    dpense "彼女はいつもとても熱心です..."


translate japanese bluebathsequence_e5f0d377:


    sofia "私が欲しいもの..."


translate japanese bluebathsequence_50fca145:


    sofia "男が欲しい…"


translate japanese bluebathsequence_99fba79e:


    sofia "誰が私を受け入れることができるのだろう…。"


translate japanese bluebathsequence_65a81c4a:


    sofia "誰が私を導いてくれて..."


translate japanese bluebathsequence_6ef36208:


    sofia "あ！"


translate japanese bluebathsequence_3b78e516:


    dpense "彼女は私を狂わせている..."


translate japanese bluebathsequence_c50c170c:


    d "始める前からもう興奮しているね…"


translate japanese bluebathsequence_d9512405:


    sofia "あなたが私を作ってくれた時から、講義室でずっとワクワクしています..."


translate japanese bluebathsequence_c48e54c4:


    sofia "あなたの指を感じてから..."


translate japanese bluebathsequence_5b26181d:


    d "この指？"


translate japanese bluebathsequence_5a262f9a:


    dpense "彼女の反応が大好き..."


translate japanese bluebathsequence_2f26ac84:


    sofia "うーん…"


translate japanese bluebathsequence_cf4f776b:


    d "ずぶ濡れだね！"


translate japanese bluebathsequence_0b8370ab:


    sofia "私は言ったでしょう！"


translate japanese bluebathsequence_74d543c4:


    sofia "今日はあなたの指を求めているわけではありません！"


translate japanese bluebathsequence_abc5915a:


    sofia "あなたが欲しい！"


translate japanese bluebathsequence_5707bfa6:


    sofia "急いで、あまり時間がない！"


translate japanese bluebathsequence_6c2ebf4b:


    d "これを脱がせてもいいですか..."


translate japanese bluebathsequence_b7c5a512:


    sofia "行こう！"


translate japanese bluebathsequence_56afc663:


    dpense "とても濡れていて、すぐに滑り落ちる..."


translate japanese bluebathsequence_2f26ac84_1:


    sofia "うーん..."


translate japanese bluebathsequence_79cf69e9:


    sofia "続けて..."


translate japanese bluebathsequence_ebb813c0:


    sofia "そのように！"


translate japanese bluebathsequence_47efd07c:


    sofia "ああ、神様、すごく気持ちいい…"


translate japanese bluebathsequence_0bd2f923:


    dpense "彼女は信じられないほど素晴らしい..."


translate japanese bluebathsequence_56849dc7:


    sofia "あなたが私の中に深く感じることができる..."


translate japanese bluebathsequence_a26bcf05:


    sofia "おおおおおお"


translate japanese bluebathsequence_fc4c4d59:


    sofia "もっと! もっと!"


translate japanese bluebathsequence_021156c2:


    sofia "速く！"


translate japanese bluebathsequence_33fabc63:


    sofia "もっと激しく！"


translate japanese bluebathsequence_eb8f7bf6:


    dpense "彼女はワイルドだ！"


translate japanese bluebathsequence_56d2001c:


    sofia "さあ、もうすぐそれが来るのを感じる！"


translate japanese bluebathsequence_312c0410:


    d "私も、それが高まっているのを感じる。"


translate japanese bluebathsequence_944ded0c:


    sofia "あなたを感じたい... 私の中に！そうして！"


translate japanese bluebathsequence_420528c9:


    sofia "満たして！"


translate japanese bluebathsequence_d75056be:


    sofia "はい！あなたが膨らんでいるのを感じることができます！！！"


translate japanese bluebathsequence_dad3c95e:


    d "ああああああああああああ！！！"


translate japanese bluebathsequence_6a936112:


    dpense "これは信じられない…"


translate japanese bluebathsequence_3eb7df3c:


    sofia "なんてことだ！！！"


translate japanese bluebathsequence_fb6a33b0:


    sofia "それは信じられないほど気持ちいい..."


translate japanese bluebathsequence_541b1006:


    sofia "私を好きにしてもいいよ..."


translate japanese bluebathsequence_925c17d4:


    sofia "私はあなたのものです..."


translate japanese bluebathsequence_4971b75a:


    sofia "わあ、それは激しかった..."


translate japanese bluebathsequence_24a08cec:


    dpense "それがどれほど素晴らしかったか信じられない..."


translate japanese bluebathsequence_1774c03c:


    sofia "他の人たちに参加してください..."


translate japanese bluebathsequence_2aa95cae:


    sofia "また後で会いましょう..."


translate japanese bluebathsequence_d5fa7ba5:


    dpense "次の時を待ちきれない..."


translate japanese freepokersequence_c2938bd3:


    emerick "ああ、ついに…"


translate japanese freepokersequence_cf8678ec:


    emerick "その男はゲームをクラッシュさせ、ゆっくりと時間をかける..."


translate japanese freepokersequence_24dcd6cc:


    emerick "少なくとも遊び方は知っているといいな…。"


translate japanese freepokersequence_32415610:


    emerick "私たちは1000ドルから始めます... そして、続けたいときは常に最低100ドルを賭けます。コールはありません。"


translate japanese freepokersequence_e8a73106:


    emerick "私たちは一度だけ上昇し、200を超えることはありません。"


translate japanese freepokersequence_04aa1bf5:


    emerick "テキサス・ホールデムをプレイしています: 2枚のカード、ボードに5枚。知っていますか、それとも復習が必要ですか？"


translate japanese freepokersequence_07fcd65a:


    d "あなたの記憶を呼び覚ませますか？しばらく遊んでいなかったので…。"


translate japanese freepokersequence_36279863:


    emerick "レッド、彼に説明してくれる？"


translate japanese freepokersequence_a9c4bc36:


    beth "ええ、君たちは最初のラウンドに進んで、私は進めながら説明するよ..."


translate japanese freepokersequence_ec5fc430:


    d "心配しないで、私は遊び方を知っています。"


translate japanese freepokersequence_54d07f02:


    emerick "まあ、それについては見てみましょう！"


translate japanese firsthand_e86a8a7a:


    dpense "7と2..."


translate japanese firsthand_ceb191ba:


    beth "100を賭けてプレイすることも、フォールドすることもできます..."


translate japanese firsthand_212cc397:


    beth "7と2は持っている中で最悪の手です... フォールド、簡単です。"


translate japanese firsthand_4d9cec0f:


    beth "より良い手を待ちましょう。"


translate japanese raisefirst_4af3fef4:


    d "うーん…"


translate japanese raisefirst_da6cdede:


    d "100を賭ける。"


translate japanese raisefirst_a8f7e65c:


    emerick "私は中にいる…"


translate japanese raisefirst_dee9a1f0:


    hec "折ります..."


translate japanese raisefirst_73612da1:


    ben "折ります..."


translate japanese raisefirst_e963ac4e:


    mac "私は中にいる..."


translate japanese raisefirst_cbfb1f43:


    beth "ボード..."


translate japanese raisefirst_360c9b51:


    beth "ハートの7。スペードのキング。クラブのクイーン。"


translate japanese raisefirst_ac0535ba:


    dpense "7のペアを持っている..."


translate japanese raisefirst_27738fbb:


    dpense "しかし、王と女王は..."


translate japanese raisefirst_cd216665:


    emerick "悪くない…"


translate japanese raisefirst_04e21e0e:


    mac "うーん…"


translate japanese raisefirst_bb544eb2:


    dpense "私の番が先に行動する。"


translate japanese foldfirst_86a9bfaa:


    d "フォールド。"


translate japanese foldfirst_42175e86:


    emerick "あ！もう折りたたんでる..."


translate japanese foldfirst_6ac4b55b:


    d "少し待ってからあなたを片付けるわ..."


translate japanese foldfirst_e75f4463:


    emerick "うん、もちろん…"


translate japanese betfirst_507e59b5:


    d "100を賭ける..."


translate japanese betfirst_a8f7e65c:


    emerick "私は入っている…"


translate japanese betfirst_e963ac4e:


    mac "私は中にいる..."


translate japanese betfirst_1ca60585:


    beth "そのターン..."


translate japanese betfirst_efb4200a:


    beth "ハートの二。"


translate japanese betfirst_85a67f5b:


    dpense "今、私は二組持っています..."


translate japanese betfirst_84464fb5:


    emerick "レンガ..."


translate japanese betfirst_d30b2f3d:


    mac "あなたは本当に話しすぎです！"


translate japanese betfirst_d6926074:


    emerick "ええ？どうして、それが気になるの？"


translate japanese betfirst_92675bce:


    mac "いいえ、いいえ…。"


translate japanese betfirstturn_507e59b5:


    d "100を賭ける..."


translate japanese betfirstturn_bf39ee43:


    emerick "私は上げる..."


translate japanese betfirstturn_01952dec:


    mac "呼んで..."


translate japanese callraiseturnfirst_d4af3017:


    d "私は呼ぶ..."


translate japanese callraiseturnfirst_7312aa2f:


    dpense "来てくれ... 川..."


translate japanese callraiseturnfirst_43774c19:


    beth "そして川。"


translate japanese callraiseturnfirst_86e388f5:


    beth "クラブの8"


translate japanese callraiseturnfirst_72054f19:


    dpense "8...はあまり役に立たない。"


translate japanese callraiseturnfirst_cf34f265:


    dpense "私はまだ二組持っています..."


translate japanese betfirstriver_507e59b5:


    d "100賭ける..."


translate japanese betfirstriver_bf39ee43:


    emerick "私は上げる…"


translate japanese betfirstriver_4857b6aa:


    mac "私は降参する..."


translate japanese betfirstriver_6aae5fac:


    emerick "ああ、始まりだ！プロのミスターが降参する！"


translate japanese betfirstriver_98b0aa51:


    mac "..."


translate japanese betfirstriver_3f18fd8f:


    emerick "そして君は、フランス人？"


translate japanese betfirstriver_5c342d8e:


    emerick "マックのように呼んでいますか、それとも折りたたんでいますか？"


translate japanese endfirst_585c495f:


    d "私は呼び出します！"


translate japanese endfirst_1ddc9ab4:


    emerick "わかった！"


translate japanese endfirst_0123b601:


    beth "みんな、手を見せて！"


translate japanese endfirst_9af984ce:


    emerick "二ペア、キングとクイーン！"


translate japanese endfirst_a9039faa:


    d "くそ..."


translate japanese endfirst_57a20cf5:


    hec "7 と 2..."


translate japanese endfirst_855e48ca:


    ben "プッ..."


translate japanese endfirst_29ac5843:


    d "何？"


translate japanese endfirst_a44c39cf:


    mac "何も、何も…"


translate japanese endfirst_d866667e:


    emerick "これは良い始まりです！"


translate japanese secondhand_a25952de:


    ben "" with hpunch


translate japanese secondhand_71235bca:


    emerick "それがゲームだよ、ベン！"


translate japanese secondhand_7bdb1b2e:


    ben "うん、うん... じゃあ、行くね、みんな..."


translate japanese secondhand_53648650:


    mac "おやすみ、ベン！"


translate japanese secondhand_f6ff6b04:


    hec "夜..."


translate japanese secondhand_5617520a:


    emerick "さてみんな、どれくらい残ってる？"


translate japanese secondhand_dcb8ab17:


    hec "400..."


translate japanese secondhand_7607269e:


    dpense "私は [moneypoker]$..."


translate japanese secondhand_723b2ccf:


    dpense "これを管理しなければならない…"


translate japanese secondhand_92d4ec21:


    d "[moneypoker]..."


translate japanese secondhand_bfb72c89:


    emerick "あなたは、マックはどうですか？"


translate japanese secondhand_7af6f01b:


    mac "最初からずっと1000のままだ..."


translate japanese secondhand_51a2c941:


    emerick "続けましょう！"


translate japanese secondhand_acb6662d:


    dpense "エース！"


translate japanese secondhand_309b2606:


    dpense "それは面白い！"


translate japanese secondhand_cfb4069e:


    beth "あなたはゲームで最高の手を持っています。"


translate japanese secondhand_d2c68232:


    beth "有利な時に賭ける必要があります。"


translate japanese secondhand_9ffa980a:


    beth "あなたが最後に行動します、他の人がどうするか見てみましょう…"


translate japanese secondhand_29aafa4e:


    emerick "私は100を賭けます！"


translate japanese secondhand_534589df:


    hec "呼びます…"


translate japanese secondhand_2abf8722:


    mac "私は呼ぶ..."


translate japanese secondhand_4a9c96af:


    beth "行って、上げて！"


translate japanese callsecond_d4af3017:


    d "私は呼ぶ..."


translate japanese callsecond_a0eff481:


    beth "まあ... 少なくとも彼らにはあなたが来るのが見えないでしょう..."


translate japanese foldsecond_5853f4b8:


    d "それを感じない…"


translate japanese foldsecond_8cd9bc60:


    beth "本気ですか？"


translate japanese foldsecond_29ac5843:


    d "何？"


translate japanese foldsecond_0d45e5bf:


    beth "知りません..."


translate japanese raisesecond_5449efcb:


    d "私は立ち上がります！"


translate japanese raisesecond_72f87a6e:


    beth "完璧。"


translate japanese raisesecond_b2b546ab:


    emerick "私は呼ぶ..."


translate japanese raisesecond_534589df:


    hec "私は呼ぶ..."


translate japanese raisesecond_2abf8722:


    mac "私は呼ぶ..."


translate japanese boardsecond_71d323cf:


    beth "ボードの男たち..."


translate japanese boardsecond_8c073ec8:


    beth "クラブの九。スペードのジャック。スペードのクイーン。"


translate japanese boardsecond_4eadc122:


    dpense "うーん…"


translate japanese boardsecond_5b5e5b81:


    beth "そうだね...このボードはあなたに有利ではないね... 九-ジャック-クイーン..."


translate japanese boardsecond_18a9af10:


    beth "あなたはすでにツーペア、トリップス、ストレートに負けています... 最後にはフラッシュの可能性もあります..."


translate japanese boardsecond_1a210212:


    beth "他の人が何をするか見るまで待つ..."


translate japanese boardsecond_29aafa4e:


    emerick "100かける！"


translate japanese boardsecond_d222b261:


    hec "私は全面的に賭けます！"


translate japanese boardsecond_f0146759:


    emerick "ああ、誰かが手を持ってる！"


translate japanese boardsecond_0b44c64a:


    mac "私は降参します。"


translate japanese boardsecond_a170c960:


    dpense "私は何をすればいいですか？"


translate japanese boardsecond_8a805c56:


    beth "折りたたむ... これは厄介な匂いがする..."


translate japanese boardsecond_f487f85b:


    beth "ポーカーでは、疑いがあるなら...疑いはない..."


translate japanese boardsecond_130fe238:


    beth "あなたは明らかに良い状況にはいません..."


translate japanese boardsecond_7bf7d14d:


    beth "残ったものを保存して、後で戻ることができます..."


translate japanese boardsecond_bdc68931:


    d "全部行くぞ！"


translate japanese boardsecond_585c495f:


    d "私は呼びます！"


translate japanese boardsecond_9cff1cb6:


    emerick "私は呼ぶ！"


translate japanese boardsecond_bdc68931_1:


    d "オールイン！"


translate japanese boardsecond_5449efcb:


    d "私は起き上がります！"


translate japanese boardsecond_9cff1cb6_1:


    emerick "呼ぶ！"


translate japanese boardsecond_7404b6d9:


    d "折れます..."


translate japanese boardsecond_f7de9063:


    emerick "ヘクターはすべてを賭けた… 手を見せて！"


translate japanese boardsecond_1d55aa40:


    hec "9のセット！"


translate japanese boardsecond_c2596d04:


    emerick "オーイェー！"


translate japanese boardsecond_8b385b22:


    emerick "悪くない…キングジャックを持ってる…"


translate japanese boardsecond_d95b091a:


    sofia "ここがターンです..."


translate japanese boardsecond_2e8a73d2:


    sofia "ハートの2..."


translate japanese boardsecond_9eeb175e:


    emerick "君はまだ良いよ、ヘクター！"


translate japanese boardsecond_ebe96f90:


    hec "悪いビートはない... 悪いビートはない..."


translate japanese boardsecond_65c54f8c:


    emerick "来い！私たちは川が欲しい！"


translate japanese boardsecond_25e4f758:


    sofia "こちらが川です..."


translate japanese boardsecond_70ddf0f2:


    sofia "スペードの10..."


translate japanese boardsecond_ff4ed839:


    emerick "" with vpunch


translate japanese boardsecond_58145255:


    emerick "" with hpunch


translate japanese boardsecond_cfed94d4:


    hec "くそ..."


translate japanese boardsecond_7426dcb3:


    emerick "おいおい、ヘクター、大したことじゃないよ！"


translate japanese boardsecond_9a3c3b3d:


    hec "地獄に行け！"


translate japanese boardsecond_a21e69bd:


    emerick "はは！続けよう！"


translate japanese turnsecond_5b45644b:


    emerick "さて、みんな、あなたたちはすべて賭けましたね... 手を見せてください！"


translate japanese turnsecond_1d55aa40:


    hec "9のセット！"


translate japanese turnsecond_09efb43f:


    d "ポケットエース！"


translate japanese turnsecond_c2596d04:


    emerick "おお、そうだ！"


translate japanese turnsecond_8b385b22:


    emerick "悪くない...キングジャックを手に入れた..."


translate japanese turnsecond_d95b091a:


    sofia "ここがターンです..."


translate japanese turnsecond_2e8a73d2:


    sofia "ハートの2..."


translate japanese turnsecond_9eeb175e:


    emerick "まだまだいいぞ、ヘクター！"


translate japanese turnsecond_ebe96f90:


    hec "悪いビートはない…悪いビートはない…"


translate japanese turnsecond_08723f2a:


    dpense "エースが必要だ..."


translate japanese turnsecond_65c54f8c:


    emerick "さあ！私たちは川が欲しい！"


translate japanese turnsecond_25e4f758:


    sofia "ここが川です..."


translate japanese turnsecond_9a610ffe:


    sofia "スペードの10..."


translate japanese turnsecond_ff4ed839:


    emerick "" with vpunch


translate japanese turnsecond_58145255:


    emerick "" with hpunch


translate japanese turnsecond_cfed94d4:


    hec "くそ..."


translate japanese turnsecond_7426dcb3:


    emerick "ああ、ヘクター、おおげさだよ！"


translate japanese turnsecond_9a3c3b3d:


    hec "地獄に行け！"


translate japanese turnsecond_78561908:


    emerick "来てくれてありがとう、フレンチー！君のお金に感謝！"


translate japanese turnsecond_d95b091a_1:


    sofia "ここがターンです..."


translate japanese turnsecond_2e8a73d2_1:


    sofia "2のハート..."


translate japanese turnsecond_29aafa4e:


    emerick "100を賭ける!"


translate japanese turnsecond_bdc68931:


    d "オールイン！"


translate japanese turnsecond_d4af3017:


    d "私は呼ぶ..."


translate japanese turnsecond_bdc68931_1:


    d "全員参加！"


translate japanese turnsecond_5449efcb:


    d "私は立ち上がる！"


translate japanese turnsecond_9cff1cb6:


    emerick "呼ぶ！"


translate japanese turnsecond_7404b6d9:


    d "私は降参します..."


translate japanese turnsecond_f7de9063:


    emerick "では、ヘクターは全力投球です... あなたの手を見せて！"


translate japanese turnsecond_1d55aa40_1:


    hec "9のセット！"


translate japanese turnsecond_c2596d04_1:


    emerick "おお、そうだね！"


translate japanese turnsecond_8b385b22_1:


    emerick "悪くない…キング・ジャックを手に入れた…"


translate japanese turnsecond_9eeb175e_1:


    emerick "まだまだいいよ、ヘクター！"


translate japanese turnsecond_ebe96f90_1:


    hec "悪いビートはない...悪いビートはない..."


translate japanese turnsecond_65c54f8c_1:


    emerick "さあ！私たちは川が欲しい！"


translate japanese turnsecond_25e4f758_1:


    sofia "川が見える..."


translate japanese turnsecond_9a610ffe_1:


    sofia "スペードの10..."


translate japanese turnsecond_ff4ed839_1:


    emerick "" with vpunch


translate japanese turnsecond_58145255_1:


    emerick "" with hpunch


translate japanese turnsecond_cfed94d4_1:


    hec "くそっ..."


translate japanese turnsecond_7426dcb3_1:


    emerick "ああ、お願いだからヘクター、それほど悪くないよ！"


translate japanese turnsecond_9a3c3b3d_1:


    hec "地獄に行け！"


translate japanese turnsecond_a21e69bd:


    emerick "はは！続けましょう！"


translate japanese riversecond_5b45644b:


    emerick "さて、皆さん、あなたたちは全員参加していますね... 手を見せて！"


translate japanese riversecond_1d55aa40:


    hec "9のセット！"


translate japanese riversecond_09efb43f:


    d "ポケットエース！"


translate japanese riversecond_c2596d04:


    emerick "おお、そうだ！"


translate japanese riversecond_8b385b22:


    emerick "悪くない... キングジャックを手に入れた..."


translate japanese riversecond_9eeb175e:


    emerick "君はまだ大丈夫だよ、ヘクター！"


translate japanese riversecond_ebe96f90:


    hec "悪いビートはない... 悪いビートはない..."


translate japanese riversecond_08723f2a:


    dpense "エースが必要だ..."


translate japanese riversecond_65c54f8c:


    emerick "さあ！私たちは川が欲しい！"


translate japanese riversecond_25e4f758:


    sofia "川があります..."


translate japanese riversecond_9a610ffe:


    sofia "スペードの10..."


translate japanese riversecond_ff4ed839:


    emerick "" with vpunch


translate japanese riversecond_58145255:


    emerick "" with hpunch


translate japanese riversecond_cfed94d4:


    hec "ちくしょう..."


translate japanese riversecond_7426dcb3:


    emerick "ああ、お願いだからヘクター、そんなに悪くないよ！"


translate japanese riversecond_9a3c3b3d:


    hec "地獄に行け！"


translate japanese riversecond_78561908:


    emerick "そして、来てくれてありがとう、フレンチー！お金をありがとう！"


translate japanese riversecond_25e4f758_1:


    sofia "ここが川です..."


translate japanese riversecond_9a610ffe_1:


    sofia "スペードの10..."


translate japanese riversecond_29aafa4e:


    emerick "100を賭ける！"


translate japanese riversecond_d4af3017:


    d "私は呼びます..."


translate japanese riversecond_bdc68931:


    d "全員で！"


translate japanese riversecond_bdc68931_1:


    d "オールイン！"


translate japanese riversecond_5449efcb:


    d "私は起きます！"


translate japanese riversecond_9cff1cb6:


    emerick "私は呼びます！"


translate japanese riversecond_7404b6d9:


    d "私は降参します..."


translate japanese riversecond_f7de9063:


    emerick "さて、ヘクターは全力投球です... 自分の手を見せて！"


translate japanese riversecond_1d55aa40_1:


    hec "9のセット！"


translate japanese riversecond_c2596d04_1:


    emerick "おお、そうだ！"


translate japanese riversecond_a405345e:


    emerick "悪くない... でも..."


translate japanese riversecond_ff4ed839_1:


    emerick "" with vpunch


translate japanese riversecond_58145255_1:


    emerick "" with hpunch


translate japanese riversecond_cfed94d4_1:


    hec "ちくしょう..."


translate japanese riversecond_7426dcb3_1:


    emerick "おいおい、ヘクター、そんなに悪くないだろう！"


translate japanese riversecond_9a3c3b3d_1:


    hec "地獄へ行け！"


translate japanese riversecond_a21e69bd:


    emerick "はは！続けよう！"


translate japanese finalsecond_f7de9063:


    emerick "さて、ヘクターは全力投球だ… あなたの手を見せて！"


translate japanese finalsecond_1d55aa40:


    hec "9のセット！"


translate japanese finalsecond_c2596d04:


    emerick "ああ、そうだね！"


translate japanese finalsecond_a405345e:


    emerick "悪くないけど…"


translate japanese finalsecond_ff4ed839:


    emerick "" with vpunch


translate japanese finalsecond_58145255:


    emerick "" with hpunch


translate japanese finalsecond_cfed94d4:


    hec "ちくしょう..."


translate japanese finalsecond_7426dcb3:


    emerick "ああ、ヘクター、そんなに悪くないよ！"


translate japanese finalsecond_9a3c3b3d:


    hec "地獄に行け！"


translate japanese finalsecond_78561908:


    emerick "そして、来てくれてありがとう、フレンチー！お金をありがとう！"


translate japanese finalsecond_a21e69bd:


    emerick "はは！続けましょう！"


translate japanese twistersequence_b12cdd7a:


    ruby "さあ、始めましょう！"


translate japanese twistersequence_a255f487:


    ruby "誰が遊びたいですか？"


translate japanese twistersequence_605daa46:


    kira "私も参加する！"


translate japanese twistersequence_207bcd32:


    s "私も！"


translate japanese twistersequence_70936eb4:


    ruby "わかった！スティーブン、キラ...."


translate japanese twistersequence_b5432fd9:


    ruby "[name] ?"


translate japanese twister1_854f7ed7:


    mad "ああ、お願いだから、私も参加させて！"


translate japanese twister1_dc165b3b:


    ruby "素晴らしい！"


translate japanese twister1_738560b4:


    ruby "じゃあ、私がホイールを回すことになる！"


translate japanese twister1_705961f2:


    ruby "誰かが倒れると、彼らは負けになり、罰ゲームを受ける！"


translate japanese twister1_58455e31:


    dpense "彼女がこれらの罰ゲームをあまりにも進めないことを願っている..."


translate japanese twister1_3afbfedb:


    dpense "マディソンの athletic body とその impressive breasts は確実に気を散らすことになるだろう…。"


translate japanese twister1_8867adec:


    dpense "そしてキラ…そんなスリムな体型で、完璧な丸いお尻。これは面白くなりそうだ。"


translate japanese twister1_b12cdd7a:


    ruby "さて、始めましょう！"


translate japanese twister1_1adf77ff:


    ruby "" with hpunch


translate japanese twister1_122f3e71:


    kira "簡単だ。"


translate japanese twister1_b8a9c191:


    s "わかった。"


translate japanese twister1_e3c1a095:


    d "# いいよ、行くよ。"


translate japanese twister1_6a6f3496:


    mad "楽勝！"


translate japanese twister1_aeac2c84:


    ruby "" with hpunch


translate japanese twister1_c1382146:


    kira "少しストレッチしています。"


translate japanese twister1_4201ad80:


    s "悪くない。"


translate japanese twister1_55b0f2bb:


    d "これを管理できます。"


translate japanese twister1_354fbd29:


    mad "今のところ気分は良い！"


translate japanese twister1_fd2ab163:


    dpense "マディソンのストレッチは彼女のアスレチックな体型を際立たせている。彼女は本当に体を鍛えている。"


translate japanese twister1_12ecdece:


    dpense "キラの動きは彼女の曲線を強調する。そのお尻は他とは違う。"


translate japanese twister1_16e4c677:


    ruby "" with hpunch


translate japanese twister1_759345ef:


    kira "難しくなってきた。"


translate japanese twister1_ba2f3a28:


    s "おっと、バランスを崩しそうになった！"


translate japanese twister1_9ac46c0a:


    d "気をつけて、スティーブン！"


translate japanese twister1_37961fdb:


    mad "私は元気です、私は元気です。"


translate japanese twister1_ff6edbf5:


    ruby "" with hpunch


translate japanese twister1_d8dca636:


    kira "まあ、これは難しいですね。"


translate japanese twister1_a0d6dc23:


    s "私は滑りかけている！"


translate japanese twister1_830b4098:


    d "待って、スティーブン!"


translate japanese twister1_310bd1e1:


    mad "集中して、スティーブン！"


translate japanese twister1_9dcbc0e8:


    ruby "スティーブン、あなたは出ていって！"


translate japanese twister1_dcd39989:


    s "くそっ！"


translate japanese twister1_6e17f083:


    ruby "負ける時間だ！パンツ一丁で家の周りを走らなければならない。"


translate japanese twister1_86063441:


    s "真面目に？"


translate japanese twister1_3239e163:


    s "さて、賭けは賭けだ。"


translate japanese twister1_0c843431:


    s "すぐに戻ります！"


translate japanese twister1_ee4baf21:


    "笑う"


translate japanese twister1_b7b6e9ac:


    ruby "さて、続けましょう！"


translate japanese twister1_65aec8b5:


    ruby "三人のプレイヤーが残りました！"


translate japanese twister1_d897c9d7:


    ruby "" with hpunch


translate japanese twister1_5986ca7c:


    kira "わかった。"


translate japanese twister1_5b657902:


    d "簡単だ。"


translate japanese twister1_76175d7e:


    mad "ゲームの中にまだいる。"


translate japanese twister1_f8247d44:


    dpense "マディソンの持久力は見事です。彼女は素晴らしく見えます。"


translate japanese twister1_d229fb74:


    dpense "キラの集中力は素晴らしく、彼女の姿は見事です。"


translate japanese twister1_43358402:


    ruby "" with hpunch


translate japanese twister1_bd6057c8:


    kira "もう少しで失うところだった！"


translate japanese twister1_5d3a4772:


    d "気をつけて！"


translate japanese twister1_3efe91a9:


    mad "まだ安定しています。"


translate japanese twister1_87f0e3b4:


    ruby "" with hpunch


translate japanese twister1_818e5609:


    kira "私は緊張を感じています。"


translate japanese twister1_4dd5f4c3:


    d "もう少し。"


translate japanese twister1_1b2e41c7:


    mad "私がこれを持っています。"


translate japanese twister1_8feb4af2:


    dpense "マディソンの決意は明確です。"


translate japanese twister1_2e19129d:


    ruby "キラ、あなたは外に出ている！"


translate japanese twister1_c4fb4f4c:


    kira "まあ、楽しめた間は良かった。"


translate japanese twister1_1a37fe6d:


    ruby "キラ、君の罰は…"


translate japanese twister1_d2a489e9:


    ruby "あなたがキスしたい人にキスしなければならない！"


translate japanese twister1_f9115114:


    kira "ふむ、興味深い..."


translate japanese twister1_7a77e836:


    kira "それでは、[name]を選びます！"


translate japanese twister1_d9649ae4:


    mad "本当に、キラ？"


translate japanese twister1_71db9840:


    mad "[name]を選ぶだけだったんでしょう？"


translate japanese twister1_99102486:


    kira "なぜ？嫉妬しているの？"


translate japanese twister1_d9d3c314:


    mad "私？ そんなことない！"


translate japanese twister1_b38549e6:


    mad "あなたが望むことをして..."


translate japanese twister1_42fe5f0e:


    dpense "このキスは何か特別なものだ…"


translate japanese twister1_5c6118f1:


    dpense "しかし、マディソンの反応はさらに興味深い。"


translate japanese twister1_26fbc773:


    ruby "さて、次に進みましょう！二人のプレイヤーが残りました…[name]とマディソン！"


translate japanese twister1_c95a5382:


    ruby "私たちは物事を難しくする！"


translate japanese twister1_f5469193:


    ruby "" with hpunch


translate japanese twister1_7959b43b:


    mad "ストレッチング..."


translate japanese twister1_610f5201:


    d "もう少しで..."


translate japanese twister1_3ff0b1af:


    dpense "マディソンのストレッチは彼女の見事な体を見せつけている。彼女はとても近く、彼女の体温を感じることができる。"


translate japanese twister1_59bb579b:


    ruby "" with hpunch


translate japanese twister1_0fbf0d2a:


    mad "危なかった！"


translate japanese twister1_2ea85ac8:


    d "もう少しだけ..."


translate japanese twister1_8e5eb314:


    dpense "私たちの体が近づいてきて、緊張感がひしひしと伝わってくる。"


translate japanese twister1_a0fb982d:


    ruby "" with hpunch


translate japanese twister1_a637c946:


    mad "安定を保っている..."


translate japanese twister1_b14c35cd:


    d "もう少しで失うところだった！"


translate japanese twister1_8d6b1f6e:


    dpense "マデイソンの体が私に押し付けられていて、彼女の曲線は無視できない。"


translate japanese twister1_17b1529b:


    ruby "大丈夫、もっと難しくなるよ！"


translate japanese twister1_8e509e5b:


    ruby "" with hpunch


translate japanese twister1_85c61c22:


    mad "これが激しくなってきた！"


translate japanese twister1_f153692d:


    d "それについて教えて..."


translate japanese twister1_7d81ee16:


    dpense "私たちはとても近い... 彼女の息が私の肌に感じられる..."


translate japanese twister1_61a8520a:


    dpense "彼女の体が私に押し付けられ、彼女の肌がどれだけ柔らかいか気づかずにはいられない。"


translate japanese twister1_462c5f1d:


    dpense "私たちの顔は数インチの距離にあり、彼女の目に輝きを見ることができる。このゲームは私が予想していたよりも激しくなっている。"


translate japanese twister1_dc8bad59:


    mad "私たち二人だけのようだ..."


translate japanese twister1_5b62eedd:


    d "うん... これは... 面白い。"


translate japanese twister1_8de7275b:


    dpense "彼女の体はほとんど私の体にぴったり合っていて、緊張感が電気のようだ。"


translate japanese twister1_74637e05:


    ruby "マディソン、あなたは負けです！ [name]、あなたの勝ちです！"


translate japanese twister1_26e90d0a:


    mad "くそ、危なかった。"


translate japanese twister1_36cd59a5:


    d "良いゲームだね、マディソン。"


translate japanese twister1_9021a01e:


    ruby "よし [name]、君がツイスターチャンピオンだ！"


translate japanese twister1_283935f2:


    mad "罰金を受け取ることにしよう。"


translate japanese twister1_9a10d66c:


    ruby "マディソン、あなたの罰は... うーん... 何にしましょうか？"


translate japanese twister1_16fcf0c7:


    dpense "彼女が何を思いつくのか見てみましょう..."


translate japanese twister1_562e58ec:


    ruby "[name]にもキスしなければならないの？"


translate japanese twister1_0b8cbe55:


    mad "ああ、それは簡単だ。"


translate japanese twister1_e9f9d80b:


    ruby "いいえ、ただの一口じゃない。本当のキス。"


translate japanese twister1_224206c9:


    mad "ああ、こういうことですか？"


translate japanese twister1_9be3f4e8:


    mad "こちらに来て、[name]。"


translate japanese twister1_ae94e9b1:


    dpense "わあ、彼女は本当にそれを求めている... 彼女の体が私の体に触れるのを感じる。これは強烈だ。"


translate japanese twister1_51930a95:


    mad "さて、それでは。"


translate japanese twister1_ca820d31:


    dpense "彼女の唇はとても柔らかい... これいい感じだけど、もっと良くなるのではないかと考えてしまう。"


translate japanese twister1_9b7b30a4:


    ruby "スティーブンは今すぐ戻ってくるはずです。"


translate japanese twister1_2fd3cfa8:


    dpense "マディソンの視線が私に留まり、彼女が何を考えているのか気になって仕方がない。"

translate japanese strings:


    old "9:00 PM"
    new "9:00 PM"


    old "Go play Poker"
    new "ポーカーをしに行こう"


    old "Go play Twister"
    new "ツイスターを遊びに行こう"


    old "I need a refresher"
    new "リフレッシャーが必要です。"


    old "No, I'm good"
    new "いいえ、大丈夫です。"


    old "Bet[TEMP1!t]"
    new "ベット[TEMP1!t]"


    old "Fold[TEMP2!t]"
    new "フォールド[TEMP2!t]"


    old "Bet"
    new "賭け"


    old "Call"
    new "呼ぶ"


    old "A few hands later..."
    new "数回の手の後..."


    old "Raise"
    new "上げる"


    old "Yeah, I'm in[TEMP1!t]"
    new "うん、私はいるよ[TEMP1!t]"


    old "No, thanks"
    new "いいえ、ありがとう。"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
