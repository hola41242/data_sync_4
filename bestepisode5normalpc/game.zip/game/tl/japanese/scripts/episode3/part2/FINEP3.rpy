


translate japanese FINEP3_285f8ea7:


    "ここでゲームを保存してください..."


translate japanese FINEP3_8636bfb0:


    gaby "あなたのような男が私のような女と何をするつもりなの？"


translate japanese FINEP3_aee41bbd:


    ji "ママ..."


translate japanese FINEP3_9b55d749:


    drew "あなたは今日の午後に新しい試練があります。"


translate japanese FINEP3_f8acb000:


    drew "この一回のためにパートナーを選ばなければなりません [name]。"


translate japanese FINEP3_c8f69174:


    mad "よし、みんな... この試合は負けられない！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
