


translate japanese ep3s2b_0ae9bcd0:


    ""


translate japanese ep3s2b_0ae9bcd0_1:


    ""


translate japanese ep3s2b_d56e0059:


    mad "うん？お父さん、何か用？"


translate japanese ep3s2b_32c1a608:


    "マディソン、そのコンペで一緒にチームを組んでいるフランスの男は誰？"


translate japanese ep3s2b_0091a552:


    mad "どうやってそれを見つけたの？それが君にとって何の関係があるの？"


translate japanese ep3s2b_185b9e19:


    "私はただ、娘が役に立たない男たちと遊んでほしくないだけです！"


translate japanese ep3s2b_522008c6:


    "あなたには娘がいることを忘れないでください。そして、彼女の「お父さん」、そう呼べるのなら、彼女を支えるためにここにいません。"


translate japanese ep3s2b_062d0790:


    mad "彼女は私の責任であって、あなたのものではありません。私の人生の生き方や誰と時間を過ごすかについて、あなたの承認を必要としません。"


translate japanese ep3s2b_5b68cb36:


    "明日の夜、このフランス人を夕食に呼んでほしい。それは、責任を示すチャンスかもしれない。"


translate japanese ep3s2b_07c235cf:


    "この機会を与えたことを後悔させないでください。"


translate japanese ep3s2b_d6d05e4d:


    mad "でも、なぜ彼に会いたいのですか？"


translate japanese ep3s2b_6ae5d577:


    "明日の夜、7時。"


translate japanese ep3s2b_315b4afb:


    mad "..."


translate japanese ep3s2b_0b0d85c6:


    mad "ここで何をしているのですか？"


translate japanese ep3s2b_4189c756:


    mad "実は、ちょうどいいタイミングだね。君と話をしたいんだ。"


translate japanese ep3s2b_552c4164:


    d "大丈夫ですか？お邪魔したくありません。"


translate japanese ep3s2b_63f41e3d:


    mad "私の父が明日の夜七時にディナーのためにあなたに会いたいそうです。行けそうですか？"


translate japanese ep3s2b_81bb9408:


    d "私？なぜ？"


translate japanese ep3s2b_02f9f09e:


    mad "聞かずに、ただ「はい」と言って..."


translate japanese ep3s2b_128ee54e:


    d "ああ、うん、大丈夫。君のところにどうやって行くかを考えないといけない。"


translate japanese ep3s2b_61c99aed:


    mad "心配しないで、それを僕が迎えに行くから。"


translate japanese ep3s2b_d627f5ff:


    mad "ここに、あなたの番号を教えてください。あなたに電話をかける時があれば、もっと簡単になります。"


translate japanese ep3s2b_08c3c4ca:


    d "もちろん。"


translate japanese ep3s2b_f0d4cb36:


    mad "ありがとう。あの…分かってるよね、そばにいてくれて。私たちはこのディナーをする。お父さんに私の人生をどう生きるか決めさせるつもりはない。"


translate japanese ep3s2b_865b61b3:


    mad "明日夜のことについてなんだけど… うちの父、私の選択に問題があるんだ、特に私の娘に関して。"


translate japanese ep3s2b_77086cd0:


    mad "彼は私の過去の関係を受け入れたことはなく、私がシングルマザーであるという事実もなおさら受け入れませんでした。"


translate japanese ep3s2b_74fbeb94:


    d "わかった。君にとって大変なことだろう。ただ、君は僕や他の誰かに自分を正当化する必要はないことを知っておいてほしい。"


translate japanese ep3s2b_c665b921:


    mad "ありがとう。それは...君にとって大切な意味があるんだ。"


translate japanese ep3s2b_432871ef:


    d "私を迎えに来てくれて本当に感謝しているよ。そして、君のお父さんが何を思っても、私はここにいるからね。"


translate japanese ep3s2b_68a4faa7:


    mad "私の父は...まぁ、彼はあなたとのこの会議に大きな期待を寄せています。"


translate japanese ep3s2b_4d78f3f9:


    mad "私たちのB.E.S.T.での成功の後、彼はあなたを破壊的な要素と見なしています。"


translate japanese ep3s2b_c2a05840:


    mad "少し気まずいけれど、彼は明日の夜に君に会いたがっている。"


translate japanese ep3s2b_de30ff18:


    d "あなたが来ると、私にとって気に障りますか？"


translate japanese ep3s2b_0409766e:


    mad "いいえ、逆に言えば。それは興味深いかもしれない。母はいつも通り夕食を担当するだろう。でも、お父さんは多分、仕切ろうとするだろう。ただ...冷静にしていて。"


translate japanese ep3s2b_ea49cf54:


    d "わかりました。"


translate japanese ep3s2b_c270fcf5:


    d "月曜日に対戦相手が誰なのか待ちきれない。"


translate japanese ep3s2b_a7d2d034:


    mad "ああ！まだ聞いていないの？"


translate japanese ep3s2b_30d72d9c:


    d "何についてですか？"


translate japanese ep3s2b_bf9328cc:


    mad "抽選が行われました。"


translate japanese ep3s2b_52e0f737:


    d "そして？"


translate japanese ep3s2b_e9ec6def:


    mad "推測してみて..."


translate japanese ep3s2b_aafe548a:


    mad "男の子たちのサッカーチーム... 彼らは強い。"


translate japanese ep3s2b_6d68cbc1:


    mad "スティーブン、彼らのキャプテンは、チームをどのように鼓舞するかを知っており、彼は強い。"


translate japanese ep3s2b_047aa479:


    mad "それからヘクターがいる、あいつはフィールドでは sneak で予測不可能だ。"


translate japanese ep3s2b_6706d7cc:


    d "うん、彼を知っている。昨日、ちょっとした... 接触があった。"


translate japanese ep3s2b_8f2bb8a5:


    mad "うーん… それはいいことでしょうね。"


translate japanese ep3s2b_bec902dc:


    d "どうして？"


translate japanese ep3s2b_80e30dba:


    mad "彼はおそらくあなたに焦点を合わせるでしょう。それが私たちに明確な場を与えます。"


translate japanese ep3s2b_bb20d578:


    d "うん、でも体に来ると思う！"


translate japanese ep3s2b_1940ca92:


    mad "ゲームの一部です。どんな不正な手口にも気をつけてください。"


translate japanese ep3s2b_e8fc89cc:


    d "やってみましょう。"


translate japanese ep3s2b_0b4e5289:


    mad "それから、スティーブンについて行くベンがいます。"


translate japanese ep3s2b_1683d1f4:


    mad "そして、マック、ゴールキーパー。まるで本物の壁のようだ。"


translate japanese ep3s2b_0ea43725:


    mad "しかし、彼らの五人目のプレーヤーは謎です。私たちはそれが誰なのかわかりません。"


translate japanese ep3s2b_112950f5:


    d "謎のプレイヤー？物事が複雑になる。"


translate japanese ep3s2b_b8846a29:


    mad "その通りです。私たちは警戒を維持する必要があります、特にスティーブンと彼のチームへの影響について。彼にはこの…カリスマ性があります、たとえ彼が私の好きなタイプのリーダーではなくても。"


translate japanese ep3s2b_27a52dc6:


    d "私たちは彼らの防御を突破する方法を見つけます。あなたから始めて、自分たちの力があります。"


translate japanese ep3s2b_e0621148:


    mad "楽観主義に感謝します。でもはい、あなたの言う通りです。私たちは彼らに私たちが何でできているかを見せます。"


translate japanese ep3s2b_91e758df:


    mad "今、私は本当にトレーニングに戻る必要があります。私たちは勝たなければならない試合があり、父やこれらのお調子者たちに目標から気をそらされるつもりはありません。"


translate japanese ep3s2b_b38d594c:


    d "私はあなたと一緒です、マディソン。私たちはこれを一緒に乗り越えます。"


translate japanese ep3s2b_f39ff206:


    mad "本当にありがとう。すべてに対して。"


translate japanese ep3s2b_9d72cfd2:


    d "そういえば、考えていたんだけど…"


translate japanese ep3s2b_cfa39340:


    d "エメリックが障害物コースで勝ったとき、誰も彼が障害物を克服するのを本当に見ていなかった。変だよね？"


translate japanese ep3s2b_d66a57ee:


    mad "そう言えば…彼は消えたかと思うと、誰にもわからないまま、最後に再び現れたようだった。"


translate japanese ep3s2b_ff0beae2:


    d "彼がスタジアムに向かう別の道から来るのを見ました。私たちがバッグを探している間に、彼はすでにいなくなっていました。試みさえしませんでした。"


translate japanese ep3s2b_ac184b92:


    mad "この競技のルールは非常に曖昧で、イライラする。"


translate japanese ep3s2b_11d7cc60:


    d "このルールのあいまいさを、私たちの利益に利用することはできるだろうか？エメリックに対抗するために、という意味で。"


translate japanese ep3s2b_72dc96cb:


    mad "それは良いアイデアです。ルールが不明確であるなら、探求すべきグレーゾーンがあるということです。"


translate japanese ep3s2b_ae06e0f4:


    mad "彼らを彼に対して向けさせる方法を見つけることができるかもしれません、特に彼が彼らを彼の陰謀に頼っているなら。"


translate japanese ep3s2b_b386fe59:


    d "その通りです。私たちは抜け穴、疑問を持つべきポイントや利用できるポイントを探し始めるべきです。"


translate japanese ep3s2b_5760655e:


    d "エメリックがルールで遊んでいるなら、私たちも正当な方法で同じことをしても何の問題もない。"


translate japanese ep3s2b_35b5c838:


    mad "同意です。他の人たちと話し合ってみて、彼らが何か異常に気づいているかどうか確かめるかもしれません。"


translate japanese ep3s2b_b6cd81e7:


    mad "しかし今は、試合の準備に集中しましょう。これには私たちのすべての力と戦略が必要です。"


translate japanese ep3s2b_4fdbb733:


    d "うん。"


translate japanese ep3s2b_cfe3c6a6:


    mad "ガブリエラとの大学の授業の時間だ。"


translate japanese ep3s2b_dc09f676:


    d "行こう。"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
