


translate japanese coming3_17342d50:


    "右手を緑のものに！"


translate japanese coming3_4c61430b:


    "私は全力投球だ！"


translate japanese coming3_7a16ee9c:


    grace "今夜、君だけが欲しい..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
