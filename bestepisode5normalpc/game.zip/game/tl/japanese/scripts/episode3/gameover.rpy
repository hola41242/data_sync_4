


translate japanese gameover_a733e2ee:


    orushi "残念ながら、あなたはすべての試練をクリアすることができませんでした、[name]..."


translate japanese gameover_84c6535c:


    orushi "残念だ..."


translate japanese gameover_3bdd13e5:


    orushi "次回は... もっと良い選択をしてみてください！"


translate japanese gameover_783ab545:


    "フシュッ！！！！"


translate japanese gameover_e233951b:


    "同じプレイヤーが再度シュート！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
