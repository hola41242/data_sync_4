


translate japanese save3_285f8ea7:


    "ここでセーブしてください..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
