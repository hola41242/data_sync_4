


translate japanese ep3intro_6a95f5af:


    "彼女たちが一緒にいる姿がどれほど美しいか見てください、まるで命が宿った二人の小さなプリンセスのようです。"


translate japanese ep3intro_d52a2d2f:


    "彼らは息を呑むほど美しい。しかし、私たちは彼らを何と呼ぶのだろう？双子は、私が期待していた奇跡の倍だ。"


translate japanese ep3intro_17e52c09:


    "この小さな女王をエリザベスと名付けるのはどうですか？ぴったりだと思いませんか？"


translate japanese ep3intro_5155ce6b:


    "エリザベス... はい、それは完璧です。そしてあなたの妹には... ソフィア、彼女のように気品のある名前はいかがですか？"


translate japanese ep3intro_d059f665:


    "ソフィア、あなたの妹が自転車に乗るのを見ている？ 彼女の真似をすれば簡単だとわかるよ。"


translate japanese ep3intro_db1f4100:


    "ソフィア、どうしていつも青なの？とても男っぽいよ！あなたの妹はせめて鮮やかな赤を選ぶのに！"


translate japanese ep3intro_63a49d35:


    "ソフィア、あなたの絵のためにまた青？あなたの姉が選ぶ活き活きとした色を見て、それらは生命に満ちています。"


translate japanese ep3intro_ae6a403c:


    sofia "なんで私はいつも彼女と比べられるの…"


translate japanese ep3intro_1abbf48a:


    "ソフィア、もっと馴染もうとする必要があるよ。エリザベスを見て、彼女はすべてを持っているんだから。"


translate japanese ep3intro_26f7887d:


    sofia "ただ放っておいて… 自分自身でありたい…"


translate japanese ep3intro_525bb56e:


    "ソフィア、ソフィア！！！"


translate japanese ep3intro_c5f6d561:


    "彼女はあなたよりも強い..."


translate japanese ep3intro_4433515c:


    "ソフィア！"


translate japanese ep3intro_4433515c_1:


    "ソフィア！"


translate japanese ep3intro_6b34e089:


    beth "ソフィア！早くして、遅れちゃうよ！"


translate japanese ep3intro_14fabf4a:


    sofia "よし！私は向かっています…"

translate japanese strings:


    old "EPISODE 3 {p} \n Let's get it started!"
    new "エピソード 3 {p} \n 始めましょう！"


    old "8:00 AM"
    new "午前8時"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
