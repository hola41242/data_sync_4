


translate japanese ep4p2s3_1b4b1a57:


    dpense ""


translate japanese ep4p2s3_f5497cd8:


    dpense ""


translate japanese ep4p2s3_a4145184:


    dpense ""


translate japanese ep4p2s3_fd950b31:


    dpense ""


translate japanese ep4p2s3_e009422d:


    dpense ""


translate japanese ep4p2s3_8d0d9a0a:


    dpense ""


translate japanese ep4p2s3_b2db8fea:


    dpense ""


translate japanese ep4p2s3_7de58b15:


    dpense ""


translate japanese ep4p2s3_8ecbb8fb:


    dpense ""


translate japanese ep4p2s3_e869a1ff:


    dpense ""


translate japanese ep4p2s3_18b96cc1:


    dpense ""


translate japanese roommcep42_9a227918:


    d ""


translate japanese roommcep42_1d8f8cec:


    dpense ""


translate japanese roommcep42_cd3b9b76:


    dpense ""


translate japanese roommcep42_68efe25b:


    d ""


translate japanese roommcep42_4ee878c5:


    ""


translate japanese roommcep42_f16cfd6d:


    ""


translate japanese roommcep42_29a3c486:


    d ""


translate japanese roommcep42_06b50b53:


    d ""


translate japanese roommcep42_cf36c76d:


    d ""


translate japanese roommcep42_e5eaf1ae:


    dpense ""


translate japanese reverobotchat_5074775d:


    dpense ""


translate japanese reverobotchat_b353e56c:


    d ""


translate japanese reverobotchat_1d9e1362:


    ""


translate japanese reverobotchat_61c079a3:


    dpense ""


translate japanese reverobotchat_a8e4f680:


    ""


translate japanese reverobotchat_e203e08c:


    dpense ""


translate japanese reverobotchat_90cc6b8b:


    dpense ""


translate japanese reverobotchat_172d9967:


    dpense ""


translate japanese reverobotchat_1d738374:


    dpense ""


translate japanese reverobotchat_ba346cd0:


    d ""


translate japanese reverobotchat_a4080e44:


    ""


translate japanese reverobotchat_77795da7:


    dpense ""


translate japanese reverobotchat_68c3eab0:


    ""


translate japanese reverobotchat_90926537:


    ""


translate japanese reverobotchat_c12d5bca:


    ""


translate japanese reverobotchat_ba7bb93c:


    d ""


translate japanese reverobotchat_445be304:


    ""


translate japanese reverobotchat_d1fb5488:


    d ""


translate japanese reverobotchat_dea02d29:


    ""


translate japanese reverobotchat_733ada87:


    ""


translate japanese reverobotchat_2ecd560f:


    dpense ""


translate japanese reverobotchat_e68135ad:


    "" with hpunch


translate japanese reverobotchat_11991fc8:


    d ""


translate japanese reverobotchat_91b9690d:


    d ""

translate japanese strings:


    old "A great night with good company!"
    new ""


    old "Look who we found tonight!"
    new ""


    old "Awesome night! Let's do this again anytime!😊"
    new ""


    old "A great night with my BF!"
    new ""


    old "Partying together!"
    new ""


    old "Oh! I missed this? Next time I will be there!"
    new ""


    old "You're doing great [name]."
    new ""


    old "What do you want from me?"
    new ""


    old "Just listen to me."
    new ""


    old "Play for you."
    new ""


    old "What does that mean?"
    new ""


    old "Time will come."
    new ""


    old "Come on! This is cryptic!"
    new ""


    old "Once we meet, remember this."
    new ""


    old "remember what?"
    new ""


    old "Hey, ready for tomorrow?"
    new ""


    old "Of course! You?"
    new ""


    old "I’m a little nervous. Steven’s team is tough, and I don’t want to let everyone down."
    new ""


    old "Don’t even think about that! They’re strong, sure, but so are we."
    new ""


    old "Plus, we’ve got Madison! And you! You’re our secret weapon."
    new ""


    old "Secret weapon, huh? No pressure there."
    new ""


    old "Hey, if anyone can handle it, it’s you. You’ve got this."
    new ""


    old "Thanks, Ruby. I’ll do my best."
    new ""


    old "I know you will. Just focus on the game, not the scoreboard. We’ll handle the rest."
    new ""


    old "Hum... Can I ask you something?"
    new ""


    old "Sure!"
    new ""


    old "Tomorrow, after the match..."
    new ""


    old "Would you like to come to the cinema with me?"
    new ""


    old "Yes! It would be a pleasure!"
    new ""


    old "Thank you so much!!!"
    new ""


    old "I promised to you."
    new ""


    old "Alright. I’ll try to get some sleep. See you tomorrow!"
    new ""


    old "You better bring your A-game tomorrow, because we’re taking them down. Good night!"
    new ""


    old "Hey, remember earlier at the hospital? I found something weird in my pocket: '1410'."
    new ""


    old "What? That’s random."
    new ""


    old "I have no idea where it came from. That’s why I’m asking you."
    new ""


    old "I… don’t think it rings a bell. Maybe it’s a date? 14/10? Or a time? 14:10?"
    new ""


    old "No, it’s just '1410'. Plain and simple."
    new ""


    old "Hmm… That’s strange. Do you think someone might have slipped it into your pocket?"
    new ""


    old "Honestly, I don’t know. Maybe. It’s weird though."
    new ""


    old "Yeah… With everything going on today, I didn’t even notice."
    new ""


    old "But this is kind of unsettling."
    new ""


    old "I’ll let you know if I figure it out."
    new ""


    old "Please do. Good night!"
    new ""


    old "Good night, Julia."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
