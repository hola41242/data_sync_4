


translate japanese introep4_d12fc746:


    ruby ""


translate japanese introep4_3f6be409:


    ruby ""


translate japanese introep4_b9184002:


    ruby ""


translate japanese introep4_2b333cd2:


    ruby ""


translate japanese introep4_b7440b24:


    ruby ""


translate japanese introep4_6507d017:


    ruby ""


translate japanese introep4_b8bd90d0:


    ruby ""


translate japanese introep4_51f6fdaa:


    ruby ""


translate japanese introep4_636ca528:


    ruby ""


translate japanese introep4_92f583ba:


    ruby ""


translate japanese introep4_ffdfed17:


    ruby ""


translate japanese introep4_1537c875:


    ruby ""


translate japanese introep4_fef9293c:


    ruby ""


translate japanese introep4_c88de34a:


    ruby ""


translate japanese introep4_daa6e0aa:


    ruby ""


translate japanese introep4_2ae225eb:


    ruby ""


translate japanese introep4_582b7e53:


    ruby ""


translate japanese introep4_fc654be2:


    ruby ""


translate japanese introep4_0ae9bcd0:


    ""


translate japanese introep4_0ae9bcd0_1:


    ""


translate japanese introep4_0ae9bcd0_2:


    ""


translate japanese introep4_0ae9bcd0_3:


    ""


translate japanese introep4_c788efec:


    d ""


translate japanese introep4_0a31269a:


    ruby ""

translate japanese strings:


    old "EPISODE 4"
    new ""


    old "ACCELERATION"
    new ""




translate japanese introep4_2bfaee56:


    ruby ""


translate japanese introep4_03936d73:


    ruby ""


translate japanese introep4_f771828c:


    ruby ""


translate japanese introep4_9a72089e:


    ruby ""


translate japanese introep4_8c224326:


    ruby ""


translate japanese introep4_6bd2a1f7:


    ruby ""


translate japanese introep4_95bc31e2:


    d "" with hpunch

translate japanese strings:


    old "72 hours before..."
    new ""




translate japanese introep4_520d55a2:


    ruby ""


translate japanese introep4_38d24d7d:


    ruby ""


translate japanese introep4_c17416f5:


    ""


translate japanese introep4_33f67964:


    ""


translate japanese introep4_616fdfab:


    ""


translate japanese introep4_8975978c:


    ""


translate japanese introep4_9a5f6a1c:


    ""


translate japanese introep4_05d09197:


    ""


translate japanese introep4_473a1d4a:


    d ""


translate japanese introep4_873c3127:


    ""


translate japanese introep4_6adface7:


    d ""


translate japanese introep4_2d8cef31:


    d ""

translate japanese strings:


    old "No[TEMP1!t]"
    new ""


    old "Your Username?"
    new ""


    old "Awake?"
    new ""


    old "Yeah, bit of a headache but I'm fine."
    new ""


    old "'I had fun at the party, thanks for bringing me."
    new ""


    old "I had fun too! It was over too soon."
    new ""


    old "You don't regret how it ended?"
    new ""


    old "Regret? Are you insane? It was marvelous."
    new ""


    old "It was the best night of my life!"
    new ""


    old "You actually make time for me, listen to what I say..."
    new ""


    old "I never felt so respected by a man..."
    new ""


    old "My man?"
    new ""


    old "Your man."
    new ""


    old "Have to go. See you later!"
    new ""


    old "See ya!"
    new ""


    old "Hey! Do you still want me to come with you to the hospital?"
    new ""


    old "If you don't mind..."
    new ""


    old "No, no, not at all."
    new ""


    old "Great! I'm heading there soon."
    new ""


    old "Should we meet out front?"
    new ""


    old "Alright! See you in a bit!"
    new ""


    old "See you soon!"
    new ""


    old "Awake and ready to meet up with you!"
    new ""


    old "What part of 'only in case of emergency' do you not understand?"
    new ""


    old "Hey, it was just so you wouldn’t worry."
    new ""


    old "I wasn't worried."
    new ""


    old "I'm not gonna miss our date either!"
    new ""


    old "It's not a date!"
    new ""


    old "Yeah, yeah!"
    new ""


    old "Just be on time."
    new ""


    old "Yes, ma'am!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
