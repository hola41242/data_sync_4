


translate japanese ep4s2_94fa98b5:


    dpense ""


translate japanese ep4s2_69ed6f54:


    dpense ""


translate japanese ep4s2_004519e6:


    dpense ""


translate japanese ep4s2_87ce1d2e:


    dpense ""


translate japanese ep4s2_4408d1f3:


    dpense ""


translate japanese ep4s2_c054dd5a:


    dpense ""


translate japanese ep4s2_ffc0b3a5:


    dpense ""


translate japanese roommcep4_5dda0f88:


    d ""


translate japanese bluephonep4inter_bffc964b:


    dpense ""

translate japanese strings:


    old "Hey, still awake?"
    new ""


    old "For you? Always. :)"
    new ""


    old "I couldn't end the day without talking to you."
    new ""


    old "You're such a sweetheart. I missed you today."
    new ""


    old "I missed you too. Feels like something was missing all day."
    new ""


    old "Same here. But hearing from you now makes up for it."
    new ""


    old "Good. I was worried I might’ve been the only one feeling like that."
    new ""


    old "Never. You’re stuck with me now, remember?"
    new ""


    old "Wouldn’t want it any other way."
    new ""


    old "Me neither."
    new ""


    old "Alright, I’ll let you get some rest now. Sweet dreams, my girl."
    new ""


    old "Sweet dreams, my guy. Sleep well. <3"
    new ""


    old "Hey, Sofia. Missed me today?"
    new ""


    old "Maybe... Or maybe I was just busy thinking about last night. ;) "
    new ""


    old "Oh? The part where you couldn’t keep your balance?"
    new ""


    old "Please. You’re the one who couldn’t resist. That bathroom got... steamy fast."
    new ""


    old "Can you blame me? You’re hard to resist."
    new ""


    old "Good answer. Let’s just say I’ve been replaying that moment in my head all day."
    new ""


    old "Now I’m replaying it too. Thanks for that."
    new ""


    old "You're welcome. But let’s switch gears before this conversation gets too hot."
    new ""


    old "I have a surprise for you!"
    new ""


    old "What? What kind of surprise?"
    new ""


    old "WoW! It fits you so well!"
    new ""


    old "Ahah! Thank you!"
    new ""


    old "My sister knows about us, you know."
    new ""


    old "Wait, Elisabeth? How?"
    new ""


    old "She has her ways. Plus, she knows there’s an event tomorrow."
    new ""


    old "She’s convinced it’ll be an elimination round."
    new ""


    old "Elisabeth always has the inside scoop, doesn’t she?"
    new ""


    old "Of course. She loves to be in control. Don’t let her intimidate you tomorrow, okay?"
    new ""


    old "You worried about me?"
    new ""


    old "Maybe. But I know you’ll handle it. Just don’t let her play her games with you."
    new ""


    old "Got it. Thanks for the heads-up, Sofia."
    new ""


    old "Don’t thank me yet. I might need another... Private moment to stay motivated. You know, like last night."
    new ""


    old "Careful, or I might call your bluff."
    new ""


    old "Bluff? Who said I was bluffing? Goodnight, [name]. Sweet dreams. ;) "
    new ""


    old "Goodnight, Sofia. Don’t dream too much about me."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
