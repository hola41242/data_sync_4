


translate japanese ep4s1b_509d2709:


    character ""


translate japanese ep4s1b_20db93c1:


    dpense ""


translate japanese ep4s1b_123981c4:


    gaby ""


translate japanese ep4s1b_6e5af138:


    gaby ""


translate japanese ep4s1b_64f8e3ca:


    d ""


translate japanese ep4s1b_8880cd63:


    gaby (laughs) ""


translate japanese ep4s1b_e1d3dfa0:


    dpense ""


translate japanese ep4s1b_4fe611b7:


    gaby ""


translate japanese ep4s1b_8d62c8c1:


    d ""


translate japanese ep4s1b_606c4ddd:


    gaby (with a smirk) ""


translate japanese ep4s1b_092c33aa:


    dpense ""


translate japanese ep4s1b_b3e28fd9:


    d ""


translate japanese ep4s1b_589d549f:


    gaby (a bit flustered) ""


translate japanese ep4s1b_5e97c79c:


    dpense ""


translate japanese ep4s1b_fa34fe61:


    gaby ""


translate japanese ep4s1b_9e4745a1:


    gaby ""


translate japanese ep4s1b_bb011912:


    d ""


translate japanese ep4s1b_df169d51:


    gaby (blushing slightly) ""


translate japanese ep4s1b_5c6a6ab0:


    dpense ""


translate japanese ep4s1b_bdcb343b:


    gaby ""


translate japanese ep4s1b_3487139a:


    d ""


translate japanese ep4s1b_bea4ddbe:


    gaby (slightly cautious) ""


translate japanese ep4s1b_bc725e9c:


    d ""


translate japanese ep4s1b_926ac736:


    gaby (visibly uneasy) ""


translate japanese ep4s1b_d265d969:


    dpense ""


translate japanese ep4s1b_aa06f3ea:


    gaby (trying to steer the conversation) ""


translate japanese ep4s1b_d25c0cb7:


    d ""


translate japanese ep4s1b_8f887962:


    gaby (defensive) ""


translate japanese ep4s1b_6629519d:


    dpense ""


translate japanese ep4s1b_d15890e0:


    gaby ""


translate japanese ep4s1b_869e1168:


    d ""


translate japanese ep4s1b_ea20ae3b:


    gaby ""


translate japanese ep4s1b_0d7758e5:


    dpense ""


translate japanese ep4s1b_175c9f5c:


    d ""


translate japanese ep4s1b_1467dd29:


    dpense ""


translate japanese ep4s1b_d26bb7e7:


    d ""


translate japanese ep4s1b_a81dc863:


    gaby ""


translate japanese ep4s1b_57b94c81:


    dpense ""


translate japanese ep4s1b_bcf8ece3:


    d ""


translate japanese ep4s1b_bbfd92a2:


    gaby ""


translate japanese ep4s1b_53eff1d8:


    dpense ""


translate japanese ep4s1b_305f0aa8:


    dpense ""


translate japanese ep4s1b_bdee29e8:


    d ""


translate japanese ep4s1b_bd4db720:


    gaby ""


translate japanese ep4s1b_15d7de72:


    dpense ""


translate japanese ep4s1b_d6e11cdb:


    gaby ""


translate japanese ep4elevator_5fed5dcb:


    gaby ""


translate japanese ep4elevator_c6eacd14:


    d ""


translate japanese ep4elevator_3f7ab310:


    dpense ""


translate japanese ep4elevator_77feb3f8:


    gaby ""


translate japanese ep4elevator_2ce331f6:


    d ""


translate japanese ep4elevator_7ddedd2d:


    d ""


translate japanese ep4elevator_722918a5:



    voice "We’ve already called the repairman... but he’s not answering. You might be stuck for a while."
    dpense ""


translate japanese ep4elevator_fba8c6cd:


    gaby ""


translate japanese ep4elevator_e0a25e43:



    voice "Hard to say. You’ll have to be patient."
    dpense ""


translate japanese ep4elevator_f505d2df:


    d ""


translate japanese ep4elevator_b658083d:


    dpense ""


translate japanese ep4elevator_3a4b1a0d:


    gaby ""


translate japanese ep4elevator_8c147f51:


    dpense ""


translate japanese ep4elevator_cff633d9:


    gaby ""


translate japanese ep4elevator_3da2c0ae:


    d ""


translate japanese ep4elevator_023e9cb9:


    d ""


translate japanese ep4elevator_ecec7333:


    gaby ""


translate japanese ep4elevator_966568ec:


    d ""


translate japanese ep4elevator_0c1f07ea:


    dpense ""


translate japanese ep4elevator_a9ecc7df:


    gaby ""


translate japanese ep4elevator_7b8b73cd:


    dpense ""


translate japanese ep4elevator_0ca38835:


    d ""


translate japanese ep4elevator_0f8a5694:


    dpense ""


translate japanese ep4elevator_4a59cada:


    gaby ""


translate japanese ep4elevator_8cf91e4e:


    dpense ""


translate japanese ep4elevator_25ae7cd9:


    dpense ""


translate japanese ep4elevator_3fec1f71:


    dpense ""


translate japanese ep4elevator_272a250b:


    gaby ""


translate japanese ep4elevator_45f8bbf6:


    d ""


translate japanese ep4elevator_b10cd94b:


    dpense ""


translate japanese ep4elevator_b2285a83:


    dpense ""


translate japanese ep4elevator_7aedf6ce:


    gaby ""


translate japanese ep4elevator_8d148ee1:


    dpense ""


translate japanese ep4elevator_41ddc48b:


    d ""


translate japanese ep4elevator_1d5ac979:


    dpense ""


translate japanese ep4elevator_2f1c71e4:


    gaby ""


translate japanese ep4elevator_9ed63dcd:


    dpense ""


translate japanese ep4elevator_910ce499:


    d ""


translate japanese ep4elevator_a7bb9057:


    dpense ""


translate japanese ep4elevator_2ab4f1ec:


    dpense ""


translate japanese ep4elevator_fcb96b1b:


    gaby ""


translate japanese ep4elevator_2c4142c9:


    d ""


translate japanese ep4elevator_bcb07473:


    dpense ""


translate japanese ep4elevator_309f120a:


    voice "The repairman’s here! Sorry for the delay."


translate japanese ep4elevator_7f8616d3:


    gaby ""


translate japanese ep4elevator_bca985ad:


    dpense ""


translate japanese ep4elevator_308d0f50:



    voice "You’re good to go now."
    d ""


translate japanese ep4elevator_7c710e9d:


    dpense ""


translate japanese ep4elevator_4d48905a:


    dpense ""


translate japanese ep4elevator_8cd916f1:


    d ""


translate japanese ep4elevator_951d926c:


    madison ""


translate japanese ep4elevator_529c6cbf:


    madison ""


translate japanese ep4elevator_581a16a2:


    madison ""


translate japanese ep4elevator_99345de3:


    madison ""


translate japanese ep4elevator_0e493d69:


    madison ""


translate japanese ep4elevator_7eea6d94:


    dpense ""


translate japanese ep4elevator_73791ccf:


    gaby ""


translate japanese ep4elevator_6a8db627:


    d ""


translate japanese ep4elevator_8c4ec58e:


    dpense ""


translate japanese ep4elevator_86714805:


    gaby ""


translate japanese ep4elevator_db9de2f5:


    dpense ""


translate japanese ep4elevator_31316f12:


    d ""


translate japanese ep4elevator_4bad11ec:


    gaby ""


translate japanese ep4elevator_51571585:


    dpense ""


translate japanese ep4elevator_5ffc9210:


    gaby ""


translate japanese ep4elevator_8cd50de3:


    d ""


translate japanese ep4elevator_3f353edb:


    dpense ""


translate japanese ep4elevator_6217de66:


    dpense ""

translate japanese strings:


    old "Go to the dinner with Madison"
    new ""


    old "Stay with Gabriella"
    new ""




translate japanese ep4s1b_2aef19a0:


    "" with hpunch


translate japanese ep4s1b_f023dd57:


    d ""


translate japanese ep4s1b_7e007843:


    gaby ""


translate japanese ep4s1b_237b830f:


    dpense ""


translate japanese ep4s1b_9e1cd86e:


    dpense ""


translate japanese ep4s1b_6ff3d2b0:


    gaby ""


translate japanese ep4s1b_774234f3:


    d ""


translate japanese ep4s1b_4cb68f51:


    d ""


translate japanese ep4s1b_3ad169b2:


    d ""


translate japanese ep4s1b_ed00c3fc:


    gaby ""


translate japanese ep4s1b_b51c5cb8:


    dpense ""


translate japanese ep4s1b_8c66ec4d:


    gaby ""


translate japanese ep4s1b_36eb79ab:


    gaby ""


translate japanese ep4s1b_46126506:


    d ""


translate japanese ep4s1b_82c0b67e:


    d ""


translate japanese ep4s1b_f047d55f:


    gaby ""


translate japanese ep4s1b_1628d00c:


    d ""


translate japanese ep4s1b_00a2dc22:


    d ""


translate japanese ep4s1b_443de289:


    gaby ""


translate japanese ep4s1b_22c093f7:


    dpense ""


translate japanese ep4s1b_1b0c331e:


    gaby ""


translate japanese ep4s1b_e5cc9718:


    gaby ""


translate japanese ep4s1b_22c6401f:


    gaby ""


translate japanese ep4s1b_aa28714c:


    d ""


translate japanese ep4s1b_f05d77db:


    gaby ""


translate japanese ep4s1b_f8fd408a:


    dpense ""


translate japanese ep4s1b_65731413:


    gaby ""


translate japanese ep4s1b_eb5c5da1:


    gaby ""


translate japanese ep4s1b_c28fbdee:


    d ""


translate japanese ep4s1b_50f19c6d:


    d ""


translate japanese ep4s1b_26954de7:


    gaby ""


translate japanese ep4s1b_d47c4d06:


    d ""


translate japanese ep4s1b_c654f226:


    d ""


translate japanese ep4s1b_e2038cd7:


    gaby ""


translate japanese ep4s1b_0c7848ff:


    gaby ""


translate japanese ep4s1b_a660b588:


    d ""


translate japanese ep4s1b_80d6b94e:


    gaby ""


translate japanese ep4elevator_7667e06b:


    gaby ""


translate japanese ep4elevator_01b3701d:


    gaby ""


translate japanese ep4elevator_52150cb5:


    ""


translate japanese ep4elevator_034ac3e3:


    dpense ""


translate japanese ep4elevator_738373b2:


    ""


translate japanese ep4elevator_0ab0a545:


    dpense ""


translate japanese ep4elevator_b982659c:


    dpense ""


translate japanese ep4elevator_312f63db:


    dpense ""


translate japanese ep4elevator_6b2fa339:


    d ""


translate japanese ep4elevator_0a9639bc:


    gaby ""


translate japanese ep4elevator_409c7c4d:


    dpense ""


translate japanese ep4elevator_c0b28a5d:


    dpense ""


translate japanese ep4elevator_c66e1d4d:


    gaby ""


translate japanese ep4elevator_f21b46f4:


    dpense ""


translate japanese ep4elevator_a2af452c:


    gaby ""


translate japanese ep4elevator_ce90d82c:


    dpense ""


translate japanese ep4elevator_1b378c31:


    dpense ""


translate japanese ep4elevator_53f21230:


    dpense ""


translate japanese ep4elevator_3bfd40bf:


    dpense ""


translate japanese ep4elevator_3cc651e4:


    dpense ""


translate japanese ep4elevator_a06eab4e:


    dpense ""


translate japanese ep4elevator_1d229afa:


    gaby ""


translate japanese ep4elevator_c03d21c1:


    dpense ""


translate japanese ep4elevator_0465ce21:


    dpense ""


translate japanese ep4elevator_d5e0f854:


    dpense ""


translate japanese ep4elevator_d5f13aa0:


    gaby ""


translate japanese ep4elevator_2ff5d7f3:


    d ""


translate japanese ep4elevator_e29be498:


    dpense ""


translate japanese ep4elevator_de3d9a7b:


    dpense ""


translate japanese ep4elevator_eceab2b3:


    gaby ""


translate japanese ep4elevator_c21e7875:


    dpense ""


translate japanese ep4elevator_6f6aa215:


    dpense ""


translate japanese ep4elevator_4ff38949:


    dpense ""


translate japanese ep4elevator_8dff537d:


    dpense ""


translate japanese ep4elevator_47b86c10:


    dpense ""


translate japanese ep4elevator_4468b7df:


    ""


translate japanese ep4elevator_1e0c076a:


    gaby ""


translate japanese ep4elevator_6f9314a4:


    dpense ""


translate japanese ep4elevator_05c6b624:


    ""


translate japanese ep4elevator_1a23e951:


    d ""


translate japanese ep4elevator_5796a093:


    dpense ""


translate japanese ep4elevator_b437b2be:


    dpense ""


translate japanese ep4elevator_df81e54d:


    mad "" with hpunch


translate japanese ep4elevator_fd83eba6:


    mad "" with hpunch


translate japanese ep4elevator_cb375f76:


    mad "" with hpunch


translate japanese ep4elevator_3ac6e9bf:


    mad "" with hpunch


translate japanese ep4elevator_34af879e:


    mad "" with hpunch


translate japanese ep4elevator_30eecdde:


    d ""


translate japanese ep4elevator_164e2365:


    dpense ""


translate japanese ep4elevator_2bc57af2:


    dpense ""


translate japanese ep4elevator_e1631a3d:


    dpense ""


translate japanese ep4elevator_8234f528:


    dpense ""


translate japanese ep4elevator_07cf2c01:


    dpense ""

translate japanese strings:


    old "Go to the dinner with Madison[TEMP1!t]"
    new ""


    old "Stay with Gabriella[TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
