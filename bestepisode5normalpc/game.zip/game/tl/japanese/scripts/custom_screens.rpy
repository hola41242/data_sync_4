

translate japanese strings:


    old "Look at the numbers backwards"
    new "数字を逆に見てください"


    old "Don't click on the image"
    new "画像をクリックしないでください。"


    old "The answer is in the question"
    new "答えは質問の中にある"



translate japanese strings:


    old "Please choose your teammate..."
    new ""


    old "    Bonus: Objects"
    new ""


    old "    Bonus: Speed"
    new ""


    old "    Bonus: Hint"
    new ""


    old "    Bonus: Brain"
    new ""


    old "    Bonus: Mother"
    new ""


    old "    Bonus: Places"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
