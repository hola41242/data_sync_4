


translate japanese e1s4_db02abfd:


    dpense "女の子たちはロッカールームで着替えに行った。"


translate japanese e1s4_3fa91343:


    dpense "装備は何も持っていないが、幸いにもスウェットパンツを履いている..."


translate japanese e1s4_98a88ee3:


    dpense "まあ... 彼らは私にスタジアムへ向かう小さな森への道を行くように言った..."


translate japanese e1s4_9a15f8ed:


    dpense "私はその方向に進んでいるように見える他の人たちについて行こうと思っています..."


translate japanese e1s4_2ead2b4e:


    dpense "うわー、これは別のものだ..."


translate japanese e1s4_1bab997e:


    dpense "さて、ジャンプして、ビームを渡り、超高い壁を登らなければならないようです…"


translate japanese e1s4_c9218e91:


    dpense "障害物競走のようだ..."


translate japanese e1s4_0ed28279:


    d "彼らは何をしていますか？"


translate japanese e1s4_1b095f4a:


    dpense "彼はレースがちょうど10分後に始まると言わなかったのか？"


translate japanese e1s4_9d966740:


    d "ああ、そうだね... そうだね..."


translate japanese e1s4_81359d8a:


    mad "準備しておいて、ベルが鳴ったらすぐに行くから…"


translate japanese e1s4_d08d7bd8:


    d "それを受ける準備ができている... いい服装だ..."


translate japanese e1s4_1cee3c7b:


    mad "そうだ、前を向いて目を離さないで！"


translate japanese e1s4_0277facd:


    ruby "私のことが恋しかった？"


translate japanese e1s4_db9355e4:


    d "あの、そうですね... 私は主にあなたが遅れることを心配していました。"


translate japanese e1s4_fdfcc728:


    ruby "実は、グレースは服装に苦労していたので...少し時間を無駄にしてしまいました..."


translate japanese e1s4_e1eac1fe:


    d "うーん...服装について話すと...これは何ですか？"


translate japanese e1s4_15b19890:


    ruby "おお！！！私の着物スタイルだ！"


translate japanese e1s4_58b90a37:


    d "着物スタイル？でも私たちは畳の上にはいない！"


translate japanese e1s4_62d07dbf:


    ruby "でも、私のランニングウェアは… なくしちゃったの…"


translate japanese e1s4_474f9baa:


    d "ルビー..."


translate japanese e1s4_af65d736:


    ruby "心配しないで！それは私の敏捷性を高めるでしょう！"


translate japanese e1s4_54658857:


    julia "では、準備はいいですか？"


translate japanese e1s4_5631dc25:


    d "うん、君が何ができるのか楽しみだ！"


translate japanese e1s4_3077b247:


    julia "あなたが何を達成できるかについての方が重要です！"


translate japanese e1s4_f85d2bb0:


    d "私のことは心配しないで。"


translate japanese e1s4_d07ece43:


    grace "ごめん、もう少しで遅れそうだった..."


translate japanese e1s4_df8f2fbb:


    d "レースが始まる前にここにいるなら、それで大丈夫だ！"


translate japanese e1s4_b0b96245:


    grace "私の衣装は着るのがあまり簡単ではなかった..."


translate japanese e1s4_ff44cb0f:


    d "素晴らしい！あなたはララ・クロフトのように見えます！"


translate japanese e1s4_5dba12c1:


    grace "うん、私は彼女のように敏捷じゃないんだから！"


translate japanese e1s4_3f58bfa9:


    d "そして、私たちの目の前にあるものを見てみてください！"


translate japanese e1s4_c41a91e8:


    grace "一歩ずつ進めていけば大丈夫でしょう。"


translate japanese e1s4_5470ffc5:


    d "ストレッチしてるの？"


translate japanese e1s4_40f16f49:


    ruby "うん！何をしなければならないのかわからないから…"


translate japanese e1s4_b2b5a412:


    ruby "レースの開始のために特定の音が鳴ると思いますか？"


translate japanese e1s4_4f399a57:


    d "それが本当に重要だとは思わない..."


translate japanese e1s4_5048dc99:


    ruby "いいえ、でも、つまり、それは「私はサバイバー」のような歌のようなものになるの？それとも大きなホーン？それとも何か他のもの..."


translate japanese e1s4_f097499a:


    ruby "それは私の質問に答えます。"


translate japanese e1s4_85a51d50:


    d "え？？？"


translate japanese e1s4_dacec8f6:


    dpense "わかった..."


translate japanese e1s4_5a7f4942:


    dpense "ジャンプしなければならない..."


translate japanese e1s4_e3de31ff:


    dpense "時間を無駄にしないで...."


translate japanese e1s4_e5d68ef1:


    dpense "今は落ちないで..."


translate japanese e1s4_3afc310b:


    dpense "マディソン..."


translate japanese e1s4_bef27060:


    dpense "彼女は速い！！！"


translate japanese e1s4_11722e7d:


    julia "あああああ！"


translate japanese e1s4_fb09c47b:


    julia "変態...でも紳士！"


translate japanese e1s4_1d8d941c:


    d "私は…"


translate japanese e1s4_ef7f41a7:


    julia "私はハンサムを知っています！"


translate japanese e1s4_392c0bca:


    julia "ありがとう！"


translate japanese e1s4_d1328c7d:


    d "問題ない..."


translate japanese e1s4_c45d2021:


    julia "あなたが紳士であることはわかっていました！"


translate japanese e1s4_3287f850:


    dpense "マディソンに参加しなければならない！"


translate japanese e1s4_fb09c47b_1:


    julia "変態... でも紳士！"


translate japanese e1s4_1d8d941c_1:


    d "私は…"


translate japanese e1s4_ef7f41a7_1:


    julia "ハンサムを知っている！"


translate japanese e1s4_392c0bca_1:


    julia "ありがとうございます！"


translate japanese e1s4_d1328c7d_1:


    d "問題ない..."


translate japanese e1s4_c45d2021_1:


    julia "あなたが紳士だとわかっていました！"


translate japanese e1s4_3287f850_1:


    dpense "マディソンに参加しなければならない！"


translate japanese e1s4_ec5f501a:


    d "手を貸して、女の子たち！"


translate japanese e1s4_d2ca9147:


    grace "ありがとう！"


translate japanese e1s4_861f2793:


    ruby "ありがとう！"


translate japanese trial2_55085e54:


    d "ジャンプ！お手伝いするよ！"


translate japanese trial3_d9e39fb2:


    d "マディソン！スタジアムはどこですか？"


translate japanese trial3_125278f2:


    mad "ちょうど丘の向こう！"


translate japanese trial3_5e6cd201:


    d "行こう、マディソン！私たちならできる！"


translate japanese trial3_4c002cd5:


    d "ジュリア！スタジアムはどこですか？"


translate japanese trial3_3427b926:


    julia "ちょうどその丘の後ろ！"


translate japanese trial3_c14b1157:


    julia "あなたは私を助けなかった... なぜ私はあなたを助けるべきですか？"


translate japanese trial3_b0c2fcfb:


    julia "今... 行って！"


translate japanese trial3_2a135b5e:


    dpense "彼女は私に怒っている…。"


translate japanese trial3_f400f290:


    d "さあ、女子たち！私たちならできるよ！"


translate japanese trial3_f400f290_1:


    d "行こう、女の子たち！私たちはできる！"


translate japanese trial4_d9f3189b:


    drew "ア amphitheater に着いたら、荷物を見つけてそれを持って出発しなければならない。"


translate japanese trial4_1e17d9fa:


    d "うーん…でも、こんな大きなスタジアムで荷物はどこにあるの？"


translate japanese trial4_fc9b9b9d:


    mad "目を開けて、天才よ…"


translate japanese trial4_93a57ae7:


    d "え？あ！！！"


translate japanese trial4_ef3a2b6b:


    mad "いいえ...！"


translate japanese trial4_c3051f60:


    mad "いいえ、いいえ、いいえ、いいえ！"


translate japanese trial4_29a24172:


    mad "" with hpunch


translate japanese trial4_01f455e7:


    emerick "マディソン！走らないで！いつも通り負けるよ！"


translate japanese trial4_3ff9bc88:


    mad "自信満々になりすぎるな、このクソ野郎！"


translate japanese trial4_0646d43a:


    dpense "わあ... 彼らは友達ではないようだ..."


translate japanese trial4_7c86948c:


    mad "でも、どれが私たちのものかどうやって分かるの？"


translate japanese trial4_84bf4ca9:


    d "わからない。"


translate japanese trial4_e46aa47d:


    mad "それぞれに番号があります。"


translate japanese trial4_731b6dfa:


    d "数字？"


translate japanese trial4_213cb8be:


    dpense "おいで [name]... 考えて！"


translate japanese trial4_cc180ec8:


    dpense "どこかに手がかりがあるはず…"


translate japanese trial4_b3db403f:


    drew "あなたはファイルの中のただの数字です。この場合、あなたは90番目です。"


translate japanese trial4_8b86fe0d:


    d "90番目？ 何の90番目？"


translate japanese trial4_ab1a0815:


    drew "もう言い過ぎた... 明日にはわかるだろう。"


translate japanese trial4_a2ee175d:


    d "待って、ドリュー先生が私に90番だと言った！"


translate japanese trial4_ad3c3345:


    mad "何の90ですか？"


translate japanese trial4_f0986419:


    d "わからないけど、彼女は今日それが何を意味するのか理解するだろうと言った！"


translate japanese trial4_b42bbe57:


    mad "もしあなたが90歳なら、私も数字を持っているはずです！"


translate japanese trial4_94831b94:


    d "84...67...90...これでいいの？はい！"


translate japanese trial4_2684ce6d:


    d "私のを見つけた！"


translate japanese trial4_4c50fb8d:


    mad "さあ、マディソン、考えて…"


translate japanese trial4_225df61f:


    d "彼女がそう言ったのなら、あなたにも手がかりを与えたに違いない…"


translate japanese trial4_169a4c34:


    mad "番号10！"


translate japanese trial4_eda8436c:


    mad "彼女はいつも私をスペードの10と呼ぶ！だって、私はチームの10番だから！"


translate japanese trial4_9879eab6:


    mad "わかった！"


translate japanese trial4_bdd2cfd3:


    d "女子たちが到着する...グレースはどうすればいいかわかるかもしれない！"


translate japanese trial4_d7ead446:


    grace "母が私たち全員に番号を与えてくれた！なぜそれが重要なのか理解できなかったけど、今はわかる！"


translate japanese trial4_c6beaf67:


    grace "すべてのバッグには番号がある... あなたのバッグを見つけなければなりません！"


translate japanese trial4_bf736dcc:


    d "数字ですか？"


translate japanese trial4_11db95ef:


    grace "はい！彼女を見た時、彼女は何か言ったに違いありません！思い出して！"


translate japanese trial4_213cb8be_1:


    dpense "考えて、[name]…。"


translate japanese trial4_82b91c50:


    dpense "どこかに手がかりがあるはずだ..."


translate japanese trial4_b3db403f_1:


    drew "あなたはファイルの中のただの数字です。この場合、あなたは90番目の数字です。"


translate japanese trial4_8b86fe0d_1:


    d "90番目？ 何の90番目？"


translate japanese trial4_ab1a0815_1:


    drew "これ以上多くを話すつもりはなかった… 明日、あなたは理解するでしょう。"


translate japanese trial4_20d845c7:


    d "90を手に入れた！"


translate japanese trial4_a206b243:


    d "荷物？どの荷物？"


translate japanese trial4_d0a982ec:


    ruby "あそこに何かがあると思う！"


translate japanese trial4_6e7ff7a1:


    grace "私の母は私たち全員に番号を与えました！なぜそれが重要なのか理解できなかったけれど、今はわかります！"


translate japanese trial4_0c4da74e:


    grace "私たちのチーム番号の女の子たち！"


translate japanese trial4_c6beaf67_1:


    grace "すべてのバッグには番号があります... あなたのバッグを見つけなければなりません！"


translate japanese trial4_bf736dcc_1:


    d "数字？"


translate japanese trial4_11db95ef_1:


    grace "はい！彼女を見たとき、何か言ったに違いない！思い出して！"


translate japanese trial4_213cb8be_2:


    dpense "さあ[name]… 考えて！"


translate japanese trial4_82b91c50_1:


    dpense "どこかに手がかりがあるはずだ..."


translate japanese trial4_b3db403f_2:


    drew "あなたはファイルの中の数字に過ぎません。この場合、あなたは90番目の数字です。"


translate japanese trial4_8b86fe0d_2:


    d "90番目？ 90番目は何の？"


translate japanese trial4_ab1a0815_2:


    drew "もう言い過ぎた... 明日には分かるでしょう。"


translate japanese trial4_20d845c7_1:


    d "90を手に入れた！"


translate japanese trial4_3df96114:


    grace "私も持ってるよ！"


translate japanese trial4_c17f7d6d:


    ruby "はい！私も！"


translate japanese trial4_58f59dc6:


    julia "私も同じです！"


translate japanese trial5_27b88c6d:


    mad "急いで！アンフィ！"


translate japanese trial5_78e34d14:


    d "戻るのは私たちが来た道を通る必要がありますか？"


translate japanese trial5_a1ac5cc2:


    mad "そうみたいだね！"


translate japanese trial5_0413c8be:


    d "他の人たちはどこにいますか？"


translate japanese trial5_66ae6200:


    mad "わからないけど… アンフィシアターに向かって走り続ければ、勝てる！"


translate japanese trial5_09de3f57:


    d "エメリックを見ましたか？"


translate japanese trial5_f2708063:


    mad "私たちがバッグを探して以来、そうではありません..."


translate japanese trial5_da52e09c:


    d "同じく..."


translate japanese trial5_6933428f:


    mad "勝ったの？"


translate japanese trial5_6bc83719:


    d "そうみたいだね！"


translate japanese trial5_94d0ff02:


    mad "ああ、それは素晴らしい！"


translate japanese trial5_ec79c7cd:


    d "わあ！やった！"


translate japanese trial5_30f5bf78:


    dpense "彼女は勝つととても明るい！"


translate japanese trial5_c1a3e6e6:


    d "マディソン... あなた..."


translate japanese trial5_42add1f3:


    dpense "これは別のマディソンです…"


translate japanese trial5_09f48158:


    mad "静かに…"


translate japanese trial5_9f153aac:


    dpense "この目と唇のためなら、何でもできる..."


translate japanese trial5_75ca9fd9:


    mad "あなた..."


translate japanese trial5_873f2806:


    mad "ごめんなさい... すべきではなかった..."


translate japanese trial5_1466bf93:


    emerick "マディソン... マディソン... マディソン..."


translate japanese trial5_5aa65267:


    emerick "おい、ラブバードたち！本当に勝ったと思っていたの？"


translate japanese trial5_d7bc0bc2:


    emerick "あはははは！"


translate japanese trial5_a796af6c:


    mad "ああ、くそ..."


translate japanese trial5_9e386227:


    d "うーん…"


translate japanese trial5_02c64f73:


    emerick "うまくいったね、マディ... でもいつものように、君はまだ私の後ろにいる。"


translate japanese trial5_2f2a683b:


    emerick "しかし、お前、フレンチ、私を感心させた。"


translate japanese trial5_a324b55d:


    mad "彼に気をつけて... 彼の舌は、褒めるときにはさらに危険なんだから..."


translate japanese trial5_dd115bf5:


    d "心配しないでください。彼のような人と友達になるつもりはありませんでした。"


translate japanese trial5_7b361f19:


    mad "あなたの評価が上がっているね！"


translate japanese trial5_67022165:


    mad "続けていれば、あなたを我慢できるかもしれません！"


translate japanese trial5_e3320973:


    d "うーん... 本当にそれが欲しいとは思えないな..."


translate japanese trial5_407e6732:


    sofia "じゃあね、グローパー..."


translate japanese trial5_3aa92f61:


    emerick "さて、マディソン？今回はかなり遅れていますね！いつも通り、実際に！"


translate japanese trial5_83d40bd8:


    mad "運をかけるな！"


translate japanese trial5_abb65a9e:


    emerick "その雌虎は爪を見せている、気を付けて！"


translate japanese trial5_0cc73e4b:


    grace "エメリック、どっか行って。"


translate japanese trial5_4702d6a8:


    emerick "大丈夫...でも、まだ終わってない...みんなに私がB.E.S.Tだってことを見せてあげる。"


translate japanese trial5_166c3d90:


    mad "うん、うん、どうでもいいけど…"


translate japanese trial5_94c5f187:


    grace "急げ！アンフィ！"


translate japanese trial5_f07c88c7:


    d "私たちは来た道を戻らなければならないのですか？？"


translate japanese trial5_0390dffa:


    grace "そうみたいですね！"


translate japanese trial5_3aa92f61_1:


    emerick "さて、マディソン？今回はかなり遅れていますね！いつも通り、実際に！"


translate japanese trial5_83d40bd8_1:


    mad "運を天に任せるな！"


translate japanese trial5_abb65a9e_1:


    emerick "雌トラが爪を見せている、気をつけて！"


translate japanese trial5_0cc73e4b_1:


    grace "エメリック、どこかへ行って。"


translate japanese trial5_4702d6a8_1:


    emerick "いいえ...でも、まだ終わっていません...私はみんなに私がB.E.S.Tであることを示すつもりです。"


translate japanese trial5_166c3d90_1:


    mad "うん、うん、なんでもいいよ…"


translate japanese trialfin_7361b1fc:


    "拍手... 拍手... 拍手"


translate japanese trialfin_a3f82246:


    orushi "親愛なる生徒たち！あなたたちは挑戦を終えました！皆さんおめでとうございます！"


translate japanese trialfin_6f496e2c:


    orushi "言わなければならないのは、あなたたちの中には万里の長城であきらめた者もいれば、どのスーツケースを持っていくか分からなかった者もいるということです！"


translate japanese trialfin_ce43e569:


    orushi "とにかく、こちらが挑戦の結果とあなたの新しい競技でのランクです！"


translate japanese trialfin_9dd369ee:


    cr "わあ！あなたがいつもゲームをしているのを見ている！そしてあなたはちょうど最初の試練を終えたばかりだ！！！"


translate japanese trialfin_c61cc570:


    cr "おめでとうございます！"


translate japanese trialfin_3bbf030e:


    cr "最後に統計ウィンドウを見てみましょう。競争相手によって新しい何かが導入されました！"


translate japanese trialfin_e5a61280:


    cr "統計ボタンをクリックしてください！"


translate japanese trialfin_25799538:


    cr "ご覧の通り、あなたのB.E.S.Tランクは現在[Rank]です。"


translate japanese trialfin_c793ee1f:


    cr "試練中のすべての行動は、このランクを上昇させることも、下降させることもできます。"


translate japanese trialfin_ccc055be:


    cr "最初の試練では悪い行動はありませんでしたが、次の出来事では現れるでしょう...気をつけて！"


translate japanese trialfin_331e6b8a:


    cr "さて、あなたのプレイを許可します！報酬を手に入れてください…"


translate japanese trialfin_1ca94d08:


    cr "特別なキャラクターと特別な道にいると、特別な報酬があります :)"


translate japanese trialfin_c6beee0f:


    orushi "ご覧の通り、この競技ではあなたの個々の行動と共同の行動の両方が考慮されています。"


translate japanese trialfin_1962243b:


    orushi "それゆえ、上位50名が次のステージに進む資格があります！"


translate japanese trialfin_0ad95992:


    orushi "改めて、皆さんおめでとうございます！"


translate japanese trialfin_12447cbb:


    orushi "午後の残りの時間を休暇にします。"


translate japanese trialfin_14f60090:


    orushi "またね..."


translate japanese trialfin_f4d45d06:


    rufus "ニャー..."


translate japanese trialfin_238811a2:


    grace "女の子たち！着替えに行こう。"


translate japanese trialfin_dd3be176:


    d "またね。"


translate japanese trialfin_17d82854:


    dpense "ロッカールームがどこにあるか見に行くべきだ..."


translate japanese reward_273dcdfc:


    julia "ねえ、イケメン！"


translate japanese reward_3f69cd63:


    d "うーん？"


translate japanese reward_3bcca2d1:


    julia "裁判中のご協力ありがとうございます！"


translate japanese reward_250f7ffa:


    grace "あなたの助けに報いるわ、私の白い騎士..."


translate japanese reward_7c4ebb9b:


    d "あれ？ …"


translate japanese reward_41d76fca:


    ruby "君を頼りにできるってわかっていたよ、ライト！"


translate japanese reward_16fd5bdd:


    d "いつもリューク... いつも！"


translate japanese final1_1c9356b0:


    dpense "なんて日だ..."


translate japanese final1_6cab8d90:


    dpense "試練、いくつかの敵、女の子たち..."


translate japanese final1_d050ec5e:


    dpense "このランキング… すべてが狂っている…"


translate japanese final1_8bfacc8f:


    cr "最初のものを終えていないし、ベスはあなたに興味がないので… 双子からのご褒美はありません！"


translate japanese final1_dbf8cd2e:


    cr "再挑戦してあなたの最高ランクを改善し、いくつかの別の選択をし、それらから報酬を受け取りましょう！"


translate japanese sofiabj_9c5ddf66:


    d "わぁあ！ここで何をしているの？"


translate japanese sofiabj_36c8ebe5:


    sofia "ええと…今日は素晴らしい印象を与えてくれましたね…"


translate japanese sofiabj_65c5b248:


    sofia "そして… そういう… 印象を持っているとき…"


translate japanese sofiabj_e57aa0b9:


    sofia "私の欲望を満たす必要がある..."


translate japanese sofiabj_c67bd742:


    sofia "好奇心..."


translate japanese sofiabj_0ace3fae:


    sofia "だから...ミスター・フレンチー、教えてください..."


translate japanese sofiabj_a44e81b1:


    sofia "私を満足させる何かがありますか？"


translate japanese sofiabj_2384fcb7:


    sofia "小さな処女の尻を触り続けるのか..."


translate japanese sofiabj_d2275832:


    sofia "全体で遊ぶことができる間に..."


translate japanese sofiabj_5cd1ddff:


    sofia "セクシーな体..."


translate japanese sofiabj_5ab2b6e7:


    d "女子がロッカールームに入ってくるのは習慣なの？"


translate japanese sofiabj_6413fc68:


    d "それとも、ただ新しい男の裸体を見る機会だったのか？"


translate japanese sofiabj_45991d45:


    sofia "フレンチが女の子に恥ずかしげもなく全てのパッケージを見せるのは彼の癖なのかな？"


translate japanese sofiabj_5b05403c:


    d "やあ！君がここに来た！私は君に何も頼んでいない！"


translate japanese sofiabj_ba6905d9:


    sofia "そして、パッケージは思ったほど大きくない..."


translate japanese sofiabj_25ed2fde:


    sofia "あなたが私をどうするかよくわからない... なんて言ったの？ つまり、スカート？"


translate japanese sofiabj_59892900:


    d "私は冷たいシャワーを浴びていた..."


translate japanese sofiabj_45991d45_1:


    sofia "フレンチーが女の子に包みを恥ずかしげもなく見せるのは癖なのだろうか？"


translate japanese sofiabj_5b05403c_1:


    d "ねえ！君はここに来たんだ！私は君に何も頼んでいない！"


translate japanese sofiabj_ba6905d9_1:


    sofia "そして、パッケージは私が期待していたほど大きくない…"


translate japanese sofiabj_25ed2fde_1:


    sofia "私をそうさせるつもりはないと思います...なんて言ったのかな？スカート？？？"


translate japanese sofiabj_59892900_1:


    d "冷たいシャワーを浴びていた…"


translate japanese bluejob_221e359c:


    d "そう... 何かできるかもしれない？"


translate japanese bluejob_b31d7ba7:


    d "この口はお喋りするためだけなの？"


translate japanese bluejob_9864ef2f:


    sofia "ああ... 誰かボールを持っていますか？"


translate japanese bluejob_dff221f1:


    sofia "負け犬と遊ぶ習慣はない。"


translate japanese bluejob_fe933c48:


    sofia "でも、私が先に見たものは..."


translate japanese bluejob_d7394d4d:


    sofia "あなたには慰めの賞がふさわしいと思います..."


translate japanese bluejob_2ad66fc4:


    sofia "そして、もし私がいくつかの...を追加したら？"


translate japanese bluejob_bbf61877:


    sofia "モチベーション..."


translate japanese bluejob_e4a37cb5:


    sofia "あの小さな男の子のために…"


translate japanese bluejob_8a63b182:


    d "もっとできると思う..."


translate japanese bluejob_caddeb77:


    sofia "大胆で貪欲な…なんて男だ！"


translate japanese bluejob_35e464ec:


    sofia "さて、フレンチ... 遊びたいですか？"


translate japanese bluejob_6839384e:


    sofia "私に対抗できるのがどれくらい持つか見てみましょう…"


translate japanese bluejob_8ce2bde3:


    sofia "少しでも私を感心させたら..."


translate japanese bluejob_8405f452:


    sofia "もしかしたら、あなたに私と遊ばせてあげるかもしれません..."


translate japanese bluejob_e75e0f01:


    sofia "そう... 取引は？"


translate japanese bluejob_01d20d04:


    d "私たちは取引をしました、ブルー..."


translate japanese bluejob_93f7f7d7:


    sofia "ソフィア... 私には名前がある小さなクソ野郎..."


translate japanese bluejob_1ac0edce:


    sofia "今は…もう話さないで…行動…"


translate japanese bluejob_2bb9fb81:


    mad "クソ野郎..."


translate japanese bluejob_7c871c87:


    mad "すべて同じ..."


translate japanese bluejob_bbf61877_1:


    sofia "モチベーション..."


translate japanese bluejob_e4a37cb5_1:


    sofia "あの小さな男の子のために…"


translate japanese bluejob_8a63b182_1:


    d "もっとできると思う..."


translate japanese bluejob_caddeb77_1:


    sofia "大胆で欲張りな… なんて男だ！"


translate japanese bluejob_35e464ec_1:


    sofia "さて、フレンチー…遊びたい？"


translate japanese bluejob_6839384e_1:


    sofia "あなたがどれだけ私に耐えられるか見てみましょう…"


translate japanese bluejob_8ce2bde3_1:


    sofia "そして、もし私を少しでも感心させることができたら…"


translate japanese bluejob_8405f452_1:


    sofia "もしかしたら、あなたと一緒に遊んであげるかもしれない..."


translate japanese bluejob_e75e0f01_1:


    sofia "そう... 揉め事？"


translate japanese bluejob_01d20d04_1:


    d "取引が成立した、ブルー..."


translate japanese bluejob_93f7f7d7_1:


    sofia "ソフィア… 私は名前を持つ小さなクソ野郎だ…"


translate japanese bluejob_a399e704:


    sofia "その間、私があなたの男根を手に持っているときに、それについて冗談を言わない方がいいと思います..."


translate japanese bluejob_1ac0edce_1:


    sofia "今は… もう話さない… 行動を…"


translate japanese bluejob_2bb9fb81_1:


    mad "クソ野郎..."


translate japanese bluejob_7c871c87_1:


    mad "すべて同じ..."


translate japanese bluejob_2b2db848:


    d "さあ、ソフィア、もっと頑張れるよ！"


translate japanese bluejob_4f004b7d:


    sofia "私も同じことを言えると思います！"


translate japanese bluejob_b49239f2:


    d "あなたがそれを求めた..."


translate japanese bluejob_71957600:


    sofia "ああ…"


translate japanese bluejob_e8006c39:


    sofia "何だって..."


translate japanese bluejob_4dbe7388:


    sofia "くそ？"


translate japanese bluejob_248c587d:


    sofia "そうだね…やっと話ができる！"


translate japanese bluejob_92442ef8:


    d "どう... 感心した？"


translate japanese bluejob_768930d5:


    sofia "いいえ..."


translate japanese bluejob_c30f547e:


    d "少しも？"


translate japanese bluejob_882be446:


    sofia "多分..."


translate japanese bluejob_cb3c584d:


    sofia "これがあなたがどのように対処するか見てみましょう..."


translate japanese bluejob_d088a656:


    d "わあ... あなたは舌の使い方が上手ですね！"


translate japanese bluejob_42db099b:


    sofia "私の舌だけではない！"


translate japanese bluejob_07d235c4:


    d "おお？"


translate japanese bluejob_1908f85f:


    sofia "どう？"


translate japanese bluejob_122c476a:


    d "悪くはないけど... でも、もう少し早くできるかもしれない？"


translate japanese bluejob_1abffde1:


    sofia "この立場で命令できると思いますか？"


translate japanese bluejob_f529413b:


    d "あなたの母は口に食べ物を入れたまま話すなと言わなかったの？"


translate japanese bluejob_483b7906:


    sofia "黙れ..."


translate japanese bluejob_b6797206:


    dpense "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese bluejob_c15f7194:


    dpense "これって掃除機なの？？？もう限界だ！"


translate japanese bluejob_38e37bbd:


    d "もうこれ以上耐えられない！"


translate japanese bluejob_320e7128:


    sofia "やめて！来てくれフレンチ！私にそれをちょうだい！"


translate japanese bluejob_fadae4f3:


    dpense "申し訳ありませんが、その内容は翻訳できません。"


translate japanese bluejob_dad3c95e:


    d "ああああああああああああ！！！"


translate japanese bluejob_d9e8a884:


    d "あああ……"


translate japanese bluejob_7fb3f60d:


    d "神様…あなたは私を疲れさせた…"


translate japanese bluejob_d3db81d2:


    sofia "うーん..."


translate japanese bluejob_7e015a72:


    sofia "{i}ゴクリ{/i}"


translate japanese bluejob_a2ca227f:


    sofia "悪くない！"


translate japanese finchoixblue_cbc2a050:


    sofia "まあ... 私たちの小さな取り決めが整ったので... 競技中は点数をつけ続けてください..."


translate japanese finchoixblue_2f2dd27a:


    d "私は..."


translate japanese finchoixblue_e68d49c9:


    sofia "私は望んでいます...だって、本当に本当に私たちの共通の友達ともう一度遊びたいから..."


translate japanese finchoixblue_876533ea:


    d "これは終わらせたくなくなるだろう..."


translate japanese finchoixblue_6ece4bdc:


    sofia "それは私の意図ではありません！"


translate japanese finchoixblue_0e4e8906:


    sofia "じゃあね、フレンチ！"


translate japanese finchoixblue_c81eac44:


    d "うんうん..."


translate japanese finchoixblue_637a238f:


    dpense "自分が何に巻き込まれたのか分からない..."


translate japanese finchoixblue_a9ef37dd:


    d "何もすることがなければ… 凧を飛ばしに行くのはどう？"


translate japanese finchoixblue_a81b1440:


    sofia "冗談でしょうか？"


translate japanese finchoixblue_41ab0038:


    d "いいえ…"


translate japanese finchoixblue_3b22e690:


    sofia "くたばれ！二度と私に話しかけるな、クソ野郎！！！"


translate japanese finchoixblue_93c9e4c4:


    d "心配しないで！私はしないよ！"


translate japanese finchoixblue_c81977b0:


    mad "{i}クスクス{/i}"


translate japanese finchoixblue_223a7be2:


    mad "多分彼はいい人かもしれない..."


translate japanese bethfk_22fa6fd0:


    dpense "オルシ..."


translate japanese bethfk_63f75c72:


    dpense "猫さえも変だ！！！！"


translate japanese bethfk_a4645742:


    dpense "女の子たちは私のことが好きだ..."


translate japanese bethfk_6ade56ff:


    dpense "でも、彼らのB.E.S.Tになれるかどうかわからない…。"


translate japanese bethfk_949548e4:


    dpense "このエメリックは厄介そうだ…"


translate japanese bethfk_e939f4bf:


    dpense "彼の周りでは警戒を保たなければならない…"


translate japanese bethfk_a98aac7a:


    dpense "そして双子は..."


translate japanese bethfk_3120a8c0:


    dpense "彼らはとても…"


translate japanese bethfk_9130a1ec:


    d "あああああ !!!!"


translate japanese bethfk_855006e5:


    beth "サプライズ！"


translate japanese bethfk_8d3edbc7:


    beth "私はあなたを見ていると言ったでしょう..."


translate japanese bethfk_b6632a8b:


    beth "今まで見たことに本当に満足しています..."


translate japanese bethfk_d543fc81:


    beth "あなたが自分の女の子たちの面倒をどう見るかを見てきました..."


translate japanese bethfk_fe2e0e36:


    d "私の... 女の子たち?"


translate japanese bethfk_2573a943:


    beth "うん... 小さなルビー... キャプテン... それにホーリー、マリー、ジュリア..."


translate japanese bethfk_bbcedabb:


    beth "あなたのような人に世話をしてもらえる人がいなくてとても悲しい..."


translate japanese bethfk_4a3e4292:


    beth "私の欲求…"


translate japanese bethfk_be75ee24:


    beth "私を扱える誰か..."


translate japanese bethfk_dc08f865:


    beth "誰がとても...を見ることができるのか。"


translate japanese bethfk_9f04486c:


    beth "深く..."


translate japanese bethfk_184c3e0d:


    beth "私の中へ..."


translate japanese bethfk_89669174:


    beth "目..."


translate japanese bethfk_04bad0c3:


    beth "でも、もし..."


translate japanese bethfk_fdba8dbe:


    beth "私は試してみたい..."


translate japanese bethfk_35864525:


    beth "そしてフランスの..."


translate japanese bethfk_e271c468:


    beth "キス..."


translate japanese redkiss_3800def7:


    dpense "わあぁぁぁ... 夢を見ているに違いない..."


translate japanese redkiss_ae82b41a:


    dpense "彼女の舌…その唇…その身体…"


translate japanese redkiss_60123473:


    dpense "ああ、私は…したい。"


translate japanese redkiss_08da671f:


    beth "おおぉ..."


translate japanese redkiss_39d96f0d:


    beth "ああ、誰かが欲深くなる..."


translate japanese redkiss_d62019b2:


    beth "キスと言ったと思う..."


translate japanese redkiss_16d05a4b:


    beth "失礼しますが..."


translate japanese redkiss_7b56213b:


    d "どこに行くつもりですか？"


translate japanese redkiss_9a65c14b:


    beth "用事がいくつかあるけれど…"


translate japanese redkiss_a695e7ba:


    beth "あなたがそれに値すると決めたとき..."


translate japanese redkiss_0786e21b:


    beth "準備しておいた方がいいよ..."


translate japanese redkiss_e96e2b0e:


    dpense "私は...今！"


translate japanese redkiss_da1a2c02:


    beth "でも、その時まで..."


translate japanese redkiss_2413472c:


    beth "ダウン、少年！"


translate japanese redkiss_26d97def:


    d "来い！！！"


translate japanese redkiss_637a238f:


    dpense "自分が何に巻き込まれたのか全くわからない…"


translate japanese redkiss_ef4b9cad:


    ruby "{i}馬鹿なライト...{/i}"


translate japanese redkiss_0581bacf:


    d "あなたに何が起こっているのかわからない..."


translate japanese redkiss_5e5295e8:


    d "でも、私の唇があなたの唇に近づくのは嫌なの…。"


translate japanese redkiss_1b0fd802:


    beth "どこでも？ 誰でもこの体に触れることができると思っているの？"


translate japanese redkiss_d2d7e74c:


    beth "私の声を聞いて、フレンチー・ワン。この機会が再び訪れるのは地獄の寒い日まで待たなければならないだろう..."


translate japanese redkiss_73b76202:


    d "私はわからない。地獄では地球温暖化が逆の効果をもたらしていると聞いた。だから、スノーシューを持ってきて、サラミ！滑るだろう！"


translate japanese redkiss_0a4b4b2c:


    ruby "彼は信じられないほど素晴らしい..."


translate japanese final_4a598229:


    "M? うん..."


translate japanese final_aec9e18d:


    "彼は制御下にある..."


translate japanese final_b10b320a:


    "彼はもうあなたにとって脅威ではなくなるでしょう..."


translate japanese final_8bda4787:


    "彼をこれらの女の子から遠ざけるために最善を尽くします..."


translate japanese final_894d2571:


    "うん、知ってるよ..."


translate japanese final_b2ae06ee:


    "トーナメントで会おう..."


translate japanese final_9669528e:


    "後で..."


translate japanese final_4a598229_1:


    "M？うん..."


translate japanese final_aec9e18d_1:


    "彼は制御下にある..."


translate japanese final_b10b320a_1:


    "彼はもうあなたにとって脅威ではなくなるだろう..."


translate japanese final_8bda4787_1:


    "彼をこれらの女の子たちから遠ざけるために最善を尽くします..."


translate japanese final_894d2571_1:


    "うん、わかってる..."


translate japanese final_b2ae06ee_1:


    "トーナメントで会いましょう..."


translate japanese final_9669528e_1:


    "後で..."

translate japanese strings:


    old "2 minutes before the race starts..."
    new "レースが始まる2分前…"


    old "1 minute before the race starts..."
    new "レースが始まる1分前..."


    old "Help Julia [TEMP1!t]"
    new "ジュリアを助けて [TEMP1!t]"


    old "Continue [TEMP2!t]"
    new "続ける [TEMP2!t]"


    old "Help the girls [TEMP1!t]"
    new "女の子たちを助けてください [TEMP1!t]"


    old "Do it like Madison [TEMP1!t]"
    new "マディソンのようにやってみて [TEMP1!t]"


    old "Help the girls [TEMP2!t]"
    new "女の子たちを助けてください [TEMP2!t]"


    old "Join Madison [TEMP1!t]"
    new "マディソンに参加する [TEMP1!t]"


    old "Encourage Madison [TEMP2!t]"
    new "マディソンを励ます [TEMP2!t]"


    old "Join Julia [TEMP1!t]"
    new "ジュリアに参加する [TEMP1!t]"


    old "Encourage Girls [TEMP2!t]"
    new "女の子を励ます"


    old "Remember [TEMP1!t]"
    new "覚えて [TEMP1!t]"


    old "Wait for girls [TEMP2!t]"
    new "女の子を待ってください [TEMP2!t]"


    old "YOUR NEW RANK IS [Rank] !"
    new "あなたの新しいランクは[Rank]です！"


    old "Provoke her [TEMP1!t]"
    new "彼女を挑発する [TEMP1!t]"


    old "Tell her to go away [TEMP2!t]"
    new "彼女に去るように言ってください [TEMP2!t]"


    old "Go for the kiss [TEMP1!t]"
    new "キスをしよう [TEMP1!t]"


    old "Refuse [TEMP2!t]"
    new "拒否する [TEMP2!t]"




translate japanese trial4_08132be7:


    drew ""


translate japanese trial5_21020def:


    mad ""


translate japanese trial5_fa81ccee:


    mad ""


translate japanese trial5_07f344d2:


    grace ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
