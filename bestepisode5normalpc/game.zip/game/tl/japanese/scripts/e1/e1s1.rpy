


translate japanese e1s1_e5c597fd:


    dpense "誰もがマディソン・フォレスターを知っている…私は知らない！"


translate japanese e1s1_a70be8a3:


    dpense "この女の子はどうしてこんなに意地悪なの？"


translate japanese e1s1_b545e893:


    dpense "彼女は信じられないほど美しいが、この彼女の姿を見るのは耐えられない…"


translate japanese e1s1_c92b4616:


    dpense "そして、私の荷物がどこにあるのかわからない..."


translate japanese e1s1_e121c6a0:


    d "運転手さん！大学までどれくらい遠いですか？"


translate japanese e1s1_8665f3d9:


    "" with vpunch


translate japanese e1s1_40668af7:


    d "それは大学ではない！それは壁だ！"


translate japanese e1s1_42198499:


    "彼女は私にここで君を下ろすように頼んだ、少年。"


translate japanese e1s1_79a98cf6:


    d "彼女？"


translate japanese e1s1_371dcb1d:


    d "彼女は誰ですか？"


translate japanese e1s1_e6a3617d:


    d "彼は去った！"


translate japanese e1s1_d8b3be19:


    dpense "ここはどこだろう？運転手に壁のそばに降ろすように頼んだ「彼女」は誰なんだろう？"


translate japanese e1s1_c5e69234:


    dpense "答えのない質問がたくさんある…"


translate japanese e1s1_9106fdeb:


    "アメリカへようこそ、[name]"


translate japanese e1s1_6f4899e6:


    d "誰...あなたは誰ですか？そして、どうして私の名前を知っているのですか？"


translate japanese e1s1_d6d5b2b2:


    "私はオルシ社のオルシ氏のアシスタント、ドリューです。大学の理事でもあります。"


translate japanese e1s1_295d0fd1:


    drew "私はあなたについて知っていることはすべて知っています、[name]。"


translate japanese e1s1_ec77f0b1:


    drew "あなたはフランス出身で、平均より少し上の学生であり、トレーニングと健康のおかげでいくつかの運動能力を持っています。"


translate japanese e1s1_d64d0926:


    d "何？私を盗み見していたの？"


translate japanese e1s1_ab50beb6:


    drew "彼らはあなたを監視しているのですか？そんなに重要なことだと思う？君を監視するためにフランスに人を送る価値があるのか？"


translate japanese e1s1_7eeb58f1:


    drew "いいえ...もちろん、そうではありません。"


translate japanese e1s1_b3db403f:


    drew "あなたはファイルの中のただの数です。この場合、あなたは90番目です。"


translate japanese e1s1_8b86fe0d:


    d "90番目？ 90番目の何？"


translate japanese e1s1_e1b74faa:


    drew "もう言いすぎた...明日、あなたは理解するでしょう。"


translate japanese e1s1_bc25ba71:


    drew "さて、失礼しますが、私の娘を紹介します。彼女があなたをキャンパスの寮と部屋に案内してくれます。"


translate japanese e1s1_8fd1e978:


    drew "どうぞお入りください。"


translate japanese e1s1_e714ec0e:


    drew "あなたは私の娘が優しくて..."


translate japanese e1s1_06bd448a:


    drew "" with hpunch


translate japanese e1s1_e8290730:


    drew "グレース！何をしているの？どうしてこんな時間に一人で飲んでいるの？明日の準備をするべきだよ！"


translate japanese e1s1_e350ad45:


    grace "お願い、そんなに大声で怒鳴るのをやめてくれない？すごく頭が痛いんだから！"


translate japanese e1s1_67eae1bf:


    drew "グレース！言葉に気をつけて！ゲストがいるので、少し控えて、ちゃんと自己紹介して！"


translate japanese e1s1_3dbeaa27:


    grace "おお、なんてことだ... わかった、やってみるよ。でも、このシャンパンを試してみて。すごいから！"


translate japanese e1s1_c1eff7a6:


    grace "ごめんなさい、私はグレースで、あなたは…"


translate japanese e1s1_d7ec0052:


    grace "これを触る者！！！"


translate japanese e1s1_8bb9bfa2:


    grace "お母さん、これが変態です！"


translate japanese e1s1_2f61cd1f:


    grace "レッドネック！！！"


translate japanese e1s1_7149415c:


    grace "お母さん、彼は本当にハンサムだ！彼はさっきジュリアに話しかけて、彼女も彼の魅力に対して免疫がないみたいだ！"


translate japanese drewsuite_c214990b:


    drew "グレース、そんないい方でゲストを迎えるのは良くないよ！"


translate japanese drewsuite_e1aae156:


    grace "でも…"


translate japanese drewsuite_f9ed221e:


    drew "言い訳はなし！"


translate japanese drewsuite_d584d61f:


    drew "申し訳ありません、誤解があったに違いありません..."


translate japanese drewsuite_3f3108a6:


    drew "[name] これはグレース、私の娘です。"


translate japanese drewsuite_51b54e3f:


    drew "そしてグレース、こちらは[name]、今学期私たちと共に大学に滞在するフランスの学生です。"


translate japanese drewsuite_0cb358b4:


    grace "はい...わかった、ママ..."


translate japanese drewsuite_db71b97f:


    grace "ごめんね[name]、ちょっと飲みすぎちゃって、お酒が入ると余計に喋っちゃうんだ..."


translate japanese drewsuite_4523b2d5:


    drew "それが片付いたので…"


translate japanese drewsuite_696a8742:


    drew "あなたは[name]に彼の部屋と寮を見せるのにふさわしい状態ではないと思う、グレース..."


translate japanese drewsuite_4f707c1b:


    grace "" with vpunch


translate japanese drewsuite_24e2b9f5:


    drew "あなたは少し休まなければならず、私はたくさんのことを抱えています。"


translate japanese drewsuite_981fef1c:


    drew "だから[name]、今夜はここにいて、グレースを見守っておいてほしい。彼女が飲み続けないように。"


translate japanese drewsuite_89842c29:


    drew "今夜はソファで寝てもいいよ、明日の8時に誰かが君の部屋まで案内するから。"


translate japanese drewangry_30cf94b3:


    drew "申し上げておきますが、そのように私に話しかけるのは良いスタートではありません。私は大学の学長であり、あなたは授業料を考慮する必要があります..."


translate japanese drewangry_bff2d64d:


    d "申し訳ありません、ドリューさん。"


translate japanese drewangry_f64c1619:


    drew "私はそれが好きです... 行かなければなりません！ 明日の9時に会いましょう、遅れないでください！！！"


translate japanese drewangry_6ed0d999:


    d "私がそこにいます..."


translate japanese drewok_e22ffbfe:


    drew "それが私が期待していたことです... 私はあなたに多くの信頼を寄せています[name]。決して私を失望させないでください... そうすれば報われるでしょう。"


translate japanese drewok_12b3f958:


    d "頑張ります、ドリューさん。"


translate japanese drewok_792664f7:


    drew "行かなければならない！明日の9時に会いましょう、遅れないでね！！！"


translate japanese drewok_6ed0d999:


    d "そこにいるよ…"


translate japanese gracetip_2181f854:


    cr "ちょっと待ってください... このゲームのルールを完全に理解しているか確認したいです！"


translate japanese gracetip_9674208e:


    cr "あなたが賢いと思っていますが、物語を進める前にあなたのステータスを確認したいです。"


translate japanese gracetip_216f0561:


    cr "さあ、見てみましょう！統計ウィンドウを開いてください。"


translate japanese gracetip_ac943f4c:


    cr "あなたはすでにキャラクターに影響を与えるいくつかの決定を下したようです。"


translate japanese gracetip_6a85a930:


    cr "今のところ、それほど重要ではない..."


translate japanese gracetip_e4bf9eaf:


    cr "... でも、飛行機でジュリアを触ろうとしなければ、他の女の子たちの印象が変わったかもしれない？"


translate japanese gracetip_666e6ece:


    cr "... でも、飛行機でジュリアを触ろうとすることで他の女の子たちの印象が変わるかもしれなかった？"


translate japanese gracetip_858181c8:


    cr "ご覧のとおり、すべての統計は比較的迅速に変わることがあります。"


translate japanese gracetip_737ef232:


    cr "さまざまな選択肢で複数のセーブを作ることをお勧めします。それがすぐに未来のイベントに影響を与えることになります。"


translate japanese gracetip_7d746e81:


    cr "では、ゲームに戻りましょう。楽しんでください!!!"


translate japanese gracetip_6c4282e7:


    d "それで、えー、グレースだよね？"


translate japanese gracetip_8a13d7b7:


    grace "はい…それは私です…"


translate japanese gracetip_2a9d73d8:


    d "何か手伝いが必要ですか？"


translate japanese gracetip_2e0cb4e0:


    grace "いいえ、大丈夫です... 自分の部屋に行って寝ます... 明日は大変な一日になりそうです..."


translate japanese gracetip_d298f5af:


    d "もちろん..."


translate japanese gracetip_9430e9e5:


    grace "" with vpunch


translate japanese gracetip_f09681f9:


    grace "あなたは私のヒーローです！"


translate japanese gracetip_ab50bccd:


    d "それについては確かではありませんが、あなたのお母さんにはあなたを世話するつもりだと伝えました..."


translate japanese gracetip_d692729b:


    grace "そう…もしかしたらもっとトレーニングして、プールでの夕方の水泳をスキップしなければならないかもしれない。"


translate japanese gracetip_6155d7c2:


    grace "もう私を解放してもいいよ…"


translate japanese gracetip_b91aafb4:


    cr "ここに、必要な統計に応じて隠されているかもしれないいくつかの選択肢があります..."


translate japanese gracetip_4b67e7da:


    cr "この場合、あなたは選択肢を持っているか、持っていないかのどちらかであり、彼女がどれだけあなたを信頼しているかによってボタンをクリックできるかどうかが決まります。"


translate japanese gracetip_79574a66:


    cr "彼女があなたを信じるためには、教育レベルが2以上でなければなりません。"


translate japanese gracetip_bdaabba9:


    grace "あなたは私を助けることができたのに！"


translate japanese gracetip_fde4e366:


    d "ごめんなさい、あなたはあまりにも早く落ちてしまいました！"


translate japanese gracetip_62ef3f60:


    grace "あなたは私が太っていると言っているのですか？"


translate japanese gracetip_d7d0f724:


    d "いいえ、いいえ！！！もちろん違うよ！あなたは素晴らしい！"


translate japanese sitcouch_2e864f0f:


    grace "まあ、じゃあここにいるね… 何も壊さないでね、さもないと母が激怒するから…"


translate japanese sitcouch_5e1e37ee:


    d "もちろん... おやすみ、グレース"


translate japanese sitcouch_9556c425:


    grace "おやすみなさい"


translate japanese roomgrace_bee99c83:


    grace "あなたは強い！"


translate japanese roomgrace_ef94450c:


    d "少し訓練したかもしれません..."


translate japanese roomgrace_c95d349c:


    grace "強くてハンサムな... ジュリアは良い趣味を持っている..."


translate japanese roomgrace_e9b720f7:


    d "ジュリア？"


translate japanese roomgrace_45538cff:


    grace "zzzz"


translate japanese roomgrace_1678ca47:


    dpense "彼女は寝ていますか？"


translate japanese roomgrace_d0c6195d:


    dpense "なんてこった..."


translate japanese roomgrace_14601ec4:


    dpense "彼女の部屋がどこにあるのかを探さなければならない..."


translate japanese roomgrace_5015de77:


    dpense "はい、これは彼女の部屋に違いない…"


translate japanese roomgrace_d4648271:


    dpense "居心地がいい！"


translate japanese roomgrace_19a6086b:


    dpense "彼女をベッドに置く..."


translate japanese roomgrace_3789c9b9:


    dpense "そこです…"


translate japanese roomgrace_44d8ac77:


    grace "ありがとう、私のヒーロー... !"


translate japanese roomgrace_15696b9a:


    dpense "何？？？"


translate japanese roomgrace_7e765a2f:


    grace "強くてハンサムな英雄…"


translate japanese roomgrace_20a391a1:


    dpense "彼女は私がいなくなったと思っているのだろうか？..."


translate japanese roomgrace_0e0b4bc1:


    dpense "彼女は美しい..."


translate japanese roomgrace_3f712c16:


    dpense "彼女の服を脱がせるべきかもしれない。"


translate japanese roomgrace_e9a7858f:


    dpense "いいえ、彼女は私を変態だと思うでしょう..."


translate japanese roomgrace_3e2f8822:


    dpense "よく眠ってね、赤毛の子…"


translate japanese couch_d5603e5f:


    dpense "さて…今は寝る時間だと思う。"


translate japanese couch_109f25a8:


    dpense "その日はかなりイベントフルだった・・・"


translate japanese couch_4003f62c:


    dpense "明日の九時だと言った... わかりました、ドリューさん..."

translate japanese strings:


    old "EPISODE 1 {p} \n Natural Selection"
    new "エピソード 1 {p} \n 自然選択"


    old "You think I'm a babysitter ? [TEMP1!t]"
    new "あなたは私がベビーシッターだと思っていますか？ [TEMP1!t]"


    old "Sure Mrs Drew ! I'll take care of her. [TEMP2!t]"
    new "わかりました、ドリューさん！彼女の面倒を見ます。[TEMP2!t]"


    old "Catch her [TEMP1!t]"
    new "彼女を捕まえて [TEMP1!t]"


    old "Don't [TEMP2!t]"
    new "しないで[TEMP2!t]"


    old "Do you want me to help you to your room ? [TEMP3!t]"
    new "あなたの部屋まで手伝いましょうか？ [TEMP3!t]"


    old "Oh ! Yes ! Sure ! [TEMP4!t]"
    new "ああ！はい！もちろん！ [TEMP4!t]"


    old "YOUR SPORT HAS INCREASED"
    new "あなたのスポーツは増加しました。"




translate japanese e1s1_432555d0:


    dpense ""


translate japanese e1s1_ac1be3dc:


    dpense ""


translate japanese e1s1_97d011b3:


    dpense ""


translate japanese e1s1_f60858d9:


    dpense ""


translate japanese e1s1_473f6b00:


    d ""


translate japanese e1s1_ecd642ad:


    "" with vpunch


translate japanese e1s1_9ea7faaf:


    d ""


translate japanese e1s1_e475c27b:


    ""


translate japanese e1s1_7481d909:


    d ""


translate japanese e1s1_4b13a5b2:


    d ""


translate japanese e1s1_88e451f1:


    dpense ""


translate japanese e1s1_7984c0cd:


    dpense ""


translate japanese e1s1_709d6e47:


    d ""


translate japanese e1s1_c1df6248:


    ""


translate japanese e1s1_0435afa2:


    drew ""


translate japanese e1s1_fbe90eca:


    d ""


translate japanese e1s1_2df3db58:


    drew ""


translate japanese e1s1_3f9e51b2:


    drew ""


translate japanese e1s1_ff2c6a79:


    d ""


translate japanese e1s1_9dfdb7ea:


    drew ""


translate japanese e1s1_f32fa33e:


    drew "" with hpunch


translate japanese e1s1_7cad2307:


    drew ""


translate japanese e1s1_edf991e2:


    grace ""


translate japanese e1s1_3c64e8bc:


    drew ""


translate japanese e1s1_6d964eef:


    grace ""


translate japanese e1s1_2b0b620b:


    grace ""


translate japanese e1s1_c989b760:


    grace ""


translate japanese e1s1_8c026b32:


    grace ""


translate japanese e1s1_a7185c32:


    grace ""


translate japanese e1s1_661d57e7:


    grace ""


translate japanese drewsuite_f4948315:


    drew ""


translate japanese drewsuite_61724c00:


    drew ""


translate japanese drewsuite_9435ba4d:


    drew ""


translate japanese drewsuite_d974a255:


    drew ""


translate japanese drewsuite_b775e404:


    grace ""


translate japanese drewsuite_e08c517d:


    grace ""


translate japanese drewsuite_862b2f2f:


    drew ""


translate japanese drewsuite_845674e8:


    drew ""


translate japanese drewsuite_eb162a64:


    grace "" with vpunch


translate japanese drewsuite_96f9ff5a:


    drew ""


translate japanese drewsuite_58bc0ab8:


    drew ""


translate japanese drewsuite_22d14705:


    drew ""


translate japanese drewangry_f8542dc5:


    drew ""


translate japanese drewangry_ecdd06d1:


    drew ""


translate japanese drewangry_c288903d:


    d ""


translate japanese drewok_05586da9:


    drew ""


translate japanese drewok_60e769c1:


    d ""


translate japanese drewok_e2d829c9:


    drew ""


translate japanese drewok_c288903d:


    d ""


translate japanese gracetip_33a7f69e:


    cr ""


translate japanese gracetip_05c5b6e7:


    cr ""


translate japanese gracetip_39949567:


    cr ""


translate japanese gracetip_b0177253:


    cr ""


translate japanese gracetip_faf676c5:


    d ""


translate japanese gracetip_a1ed8ae4:


    grace ""


translate japanese gracetip_8a81dd88:


    d ""


translate japanese gracetip_e67f97c2:


    grace ""


translate japanese gracetip_4d710522:


    d ""


translate japanese gracetip_eb17abbf:


    grace "" with vpunch


translate japanese gracetip_56de7896:


    grace ""


translate japanese gracetip_2c5bbbe4:


    d ""


translate japanese gracetip_ccb7a8bc:


    grace ""


translate japanese gracetip_6522caea:


    cr ""


translate japanese gracetip_de6b2efc:


    cr ""


translate japanese gracetip_b687572e:


    grace ""


translate japanese gracetip_66025636:


    d ""


translate japanese gracetip_16464349:


    grace ""


translate japanese gracetip_3cd51a3d:


    d ""


translate japanese sitcouch_63282405:


    grace ""


translate japanese sitcouch_507244c0:


    d ""


translate japanese sitcouch_8065de9f:


    grace ""


translate japanese roomgrace_a49d7fcc:


    grace ""


translate japanese roomgrace_c4cdd678:


    d ""


translate japanese roomgrace_54eeaa13:


    grace ""


translate japanese roomgrace_5a7b8daf:


    d ""


translate japanese roomgrace_7248392c:


    dpense ""


translate japanese roomgrace_fd6e80d1:


    dpense ""


translate japanese roomgrace_5ffba06b:


    dpense ""


translate japanese roomgrace_a203b104:


    dpense ""


translate japanese roomgrace_fdaa5493:


    dpense ""


translate japanese roomgrace_6e4512a7:


    grace ""


translate japanese roomgrace_2c73141e:


    dpense ""


translate japanese roomgrace_489910c7:


    dpense ""


translate japanese roomgrace_f16dac9a:


    dpense ""


translate japanese roomgrace_4bebf18a:


    dpense ""


translate japanese roomgrace_308174f2:


    dpense ""


translate japanese couch_af05b7c2:


    dpense ""


translate japanese couch_760535b6:


    dpense ""


translate japanese couch_fd086364:


    dpense ""

translate japanese strings:


    old "You think I'm a babysitter? [TEMP1!t]"
    new ""


    old "Sure Mrs. Drew. I'll take care of her. [TEMP2!t]"
    new ""


    old "Oh! Yes, I'll do that. [TEMP4!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
