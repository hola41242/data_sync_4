


translate japanese e1s3_c5ea222a:


    ruby "ジュリア！髪をどうしたの？"


translate japanese e1s3_7f35a1c9:


    julia "ああ、人々が私にロックスターになりたいかどうか尋ねるのに疲れたわ！"


translate japanese e1s3_0cfbc407:


    ruby "まあ、それはあなたに似合っていますね！そしてその色…わあ！"


translate japanese e1s3_fbaf289d:


    julia "ありがとう！それと、編み込みをなくしたの？"


translate japanese e1s3_3a174d23:


    ruby "はい！スポーツには適しているけど、それに疲れてしまった！毎回やり直さなければならなかった...今朝はあまり時間がなかった...ライトを彼の部屋に連れて行かなければならなかった！"


translate japanese e1s3_cb399fc3:


    julia "ライト？"


translate japanese e1s3_064cabec:


    d "彼女は私たちがライトとリュークだと決めた..."


translate japanese e1s3_c697cc23:


    julia "変態の帰還…ルビーといい子にしていたことを願っている！さもなくば、女に殴られる気持ちを味わうことになるぞ！"


translate japanese e1s3_8e0cfd62:


    julia "今日はいい気分だからラッキーだね！でも、私を試さないで… 私から離れていれば、すべてうまくいくよ！"


translate japanese e1s3_f2b26f55:


    ruby "彼は完璧だった、ジュリア！やめて！私は彼を彼の部屋に連れて行った、彼が着替えてどこで寝るかを見るために。"


translate japanese e1s3_758413b0:


    ruby "可哀そうな彼は、ここに誰も知り合いがいなくて、彼の荷物は彼がどこに行くかも知らないうちに取られてしまった..."


translate japanese e1s3_2113284b:


    julia "おお！分かった... さて、聞いて、私は努力するつもりです..."


translate japanese e1s3_1252b777:


    julia "そして…ライトとリューク???"


translate japanese e1s3_46523c1d:


    ruby "ところで、子供の頃のライトとリュークを覚えていますか？"


translate japanese e1s3_757fcd56:


    julia "漫画のキャラクター？"


translate japanese e1s3_33d2c520:


    ruby "そう、フランス語ではこう呼ぶんだ Light Yagami そして Ryuk！"


translate japanese e1s3_e476f539:


    julia "ああ... でも、どうしてわかるの？"


translate japanese e1s3_9697caca:


    ruby "昨年、我々は大場つぐみと小畑健の存在を知った。"


translate japanese e1s3_d6560304:


    julia "うんうんうん！あなたがどうやってそんなに多くの情報を小さな頭の中に保っているのかわからない..."


translate japanese e1s3_064cabec_1:


    d "彼女は私たちがライトとリュークだと決めた..."


translate japanese e1s3_3fdb3897:


    julia "ああ、飛行機の男だ！ルビーがあなたに優しくしてくれたことを願っています！ルビー、あなたの話で彼を退屈させすぎなかったよね？"


translate japanese e1s3_f465834e:


    julia "可哀想に、ちょうど到着したばかりで、映画や動物、あるいは南極の氷が溶ける話で押しつぶされているに違いない..."


translate japanese e1s3_3ce36968:


    d "ハハハ！いいえ、本当に、彼女は優しかった！彼女は私に寮と私の部屋を見せてくれた..."


translate japanese e1s3_9c209af9:


    ruby "私が自分を準備したんだ！"


translate japanese e1s3_33074fdd:


    d "はい、彼女が私のために準備した部屋..."


translate japanese e1s3_7c219f85:


    julia "よかったら、キャンパスを案内することができるので、授業の後に何ができるかを見てみてください。"


translate japanese e1s3_aa3d626c:


    d "それは完璧です！"


translate japanese e1s3_1252b777_1:


    julia "そして…ライトとリューク???"


translate japanese e1s3_46523c1d_1:


    ruby "ところで、子供の頃のライトとリュークを覚えていますか？"


translate japanese e1s3_757fcd56_1:


    julia "漫画のキャラクター？"


translate japanese e1s3_33d2c520_1:


    ruby "そう、フランス語ではこう呼ぶんだ Light Yagami そして Ryuk！"


translate japanese e1s3_e476f539_1:


    julia "ああ... でも、どうしてそれを知っているの？"


translate japanese e1s3_c0ebf8c0:


    ruby "昨年、我々は大場つぐみと小畑健の存在を知った。"


translate japanese e1s3_d6560304_1:


    julia "うんうんうん！どうやってあなたがそんなにたくさんの情報を小さな頭の中に保てるのか分からない…"


translate japanese e1s3_fce2fe54:


    ruby "彼と少し一緒にいて、彼に周りを見せてあげられますか？私はトイレに行く必要があります、授業が始まります！"


translate japanese e1s3_f5328420:


    julia "もちろん、どうぞ！"


translate japanese e1s3_9c687826:


    ruby "ありがとう！！！またね！"


translate japanese e1s3_6ffafcc2:


    julia "さて、私たちだけなので、大学の人々について簡単に説明させてください。"


translate japanese e1s3_6862ab50:


    julia "ここでは、あるものは「星」であり、他のものはちょっとした外部者のような存在であることがわかるでしょう..."


translate japanese e1s3_2c3a63c7:


    d "あなたは何を意味していますか？"


translate japanese e1s3_343aa2f3:


    julia "待って、見せてあげる！"


translate japanese e1s3_676dd9d3:


    julia "だから、見ての通り、彼はスティーブンだ、大学の男の一人で、常に女の子に口説きかけて、フックアップしようとしている、彼の言う通りに..."


translate japanese e1s3_1b31ae3c:


    julia "彼は男子サッカーチームでプレーしています。彼らはチームメイトを探しているので、興味があれば試してみてください。"


translate japanese e1s3_c873f017:


    julia "彼を誰かと一緒に見たことがなくて、チームの全ての女の子たちはもう彼をブラックリストに載せている..."


translate japanese e1s3_ba25435e:


    d "ああ、そうだ、君にはチームがいるんだね...調子はどう？"


translate japanese e1s3_00433e96:


    julia "私たちは国内のサッカーのトップアカデミーチームの一つです！そして私たちの中には、ナショナルチームに参加することが期待されている者もいます！私たちは皆、同じ夢を持っています…"


translate japanese e1s3_2bf8680d:


    julia "代表チームに選ばれて、アレックス・モーガンやメーガン・ラピノーのような女の子たちとプレイするために！"


translate japanese e1s3_dc1001c7:


    d "彼らがフランスでプレイしているのを見たことがあります！私たちにも良い女子チームがあります！"


translate japanese e1s3_6a905540:


    julia "はい、それは本当です。私たちはあなたのチームに対するすべての試合を見ました！まあ、あなたはまだカップを勝ち取っていませんが、時には近いこともありました！あなたには素晴らしい攻撃者もいますね...まあ、あなたにはいましたが..."


translate japanese e1s3_0544436e:


    d "ええ、正直言って、私はもう女性のサッカーのニュースを追っていないですね…。"


translate japanese e1s3_7fc1ec03:


    julia "とにかく！チームには私たちと同い年の女の子たちや、少し年上の子たちもいる…"


translate japanese e1s3_a2f9cbb1:


    julia "私たちのクラスには、ウィンガーを務めるルビーがいます。彼女はとても優れたテクニシャンで、非常に速いです！"


translate japanese e1s3_c6be00ee:


    d "ルビー？速い？"


translate japanese e1s3_5f857b41:


    julia "はい、彼女が話していないとき、私は彼女ができると確信しています!!!"


translate japanese e1s3_5d0c78ae:


    d "ハハハ！そして、あなたは速いですか？"


translate japanese e1s3_f2a292ff:


    julia "私はミッドフィールダーで、機会を生み出すためによりテクニカルにプレーします。背後にグレースがいて、..."


translate japanese e1s3_55b5e56c:


    d "グレース...赤毛の彼女？"


translate japanese e1s3_c16050f0:


    julia "はい、はい！彼女は私たちのキャプテンです！彼女はディフェンシブミッドフィールダーとしてプレーし、ゲームを組織します。"


translate japanese e1s3_3f570464:


    julia "彼女は私のすぐ後ろでプレイしていて、目標は攻撃者たちに最高のボールを送ることです。"


translate japanese e1s3_78d34c84:


    d "良い攻撃者はいますか？"


translate japanese e1s3_5c0f1f9d:


    julia "私たちは最高の... 残念ながら、彼女は非常に傲慢です。でも、はい、彼女は強いです。"


translate japanese e1s3_cbea19fa:


    julia "悪魔の話をするもんじゃない…"


translate japanese e1s3_28fe81f1:


    d "へぇ、彼女を知ってる！昨夜タクシーで会ったんだ！そう、彼女は本当に自信たっぷりだね！"


translate japanese e1s3_d57cf1ce:


    d "彼女が去るとき、「みんな知ってるよ...」と言った。"


translate japanese e1s3_1056edaa:


    julia "誰もがマディソン・フォレスターを知っている... うん、わかってる、彼女はよく言うから。とにかく、彼女は私たちのスター選手です。"


translate japanese e1s3_ccdb04ff:


    julia "正直に言うと、彼女とはあまりうまくやっていない。でも、彼女にはいくつかの問題や責任があって、時々防御的になることがある…"


translate japanese e1s3_f572ad70:


    julia "マディソンとルビーはよく一緒にいます。ルビーは小さい頃に両親を失い、マディソンの両親が彼女を迎え入れ、ほぼ養子のように育てました。"


translate japanese e1s3_af8699d8:


    julia "ルビーはマディソンに盲目的な信頼を寄せている… そしてマディソンはルビーをとても守っている…"


translate japanese e1s3_95cbd31a:


    julia "そこにいる男はエメリックです..."


translate japanese e1s3_578bed5e:


    d "彼の周りにはどうしてこんなに多くの人がいるの？"


translate japanese e1s3_a109e363:


    julia "彼は学校で人気者だと言っておきましょう... 彼は祖父からかなりの財産を相続しており、それを見せびらかすことを恐れていません...."


translate japanese e1s3_78c32aa1:


    julia "女の子たちは彼を嫌っている... 私は気にしない... でも彼の周りでは注意しなければならない。なぜなら、彼はやることすべてにおいて無慈悲だから。"


translate japanese e1s3_435be169:


    julia "彼は自分が欲しいものを手に入れるために、お金や人脈を使うことを恐れていない。"


translate japanese e1s3_2c3a63c7_1:


    d "あなたは何を意味していますか？"


translate japanese e1s3_90077d39:


    julia "彼は陸上競技のチャンピオンであり、ビジネスに関するあらゆることについての豊富な知識を持っています..."


translate japanese e1s3_96276d06:


    julia "そしてその上、彼には資金があり… そして人脈がある… 彼とは関わりたくない相手だ…"


translate japanese e1s3_ae8c5b38:


    julia "マディソンは特に彼が大嫌いで、彼はいつも彼女の一歩先を行っているように見えるからだ。"


translate japanese e1s3_1e0a6dea:


    d "うん… 彼を避けるようにしよう！"


translate japanese e1s3_ff45d902:


    julia "もしできるなら！さて、問題がやってきました..."


translate japanese e1s3_4593d887:


    julia "これは我々のゴールキーパー、エリザベス、彼女は厳しいだけでなく神秘的でもある。"


translate japanese e1s3_6012255c:


    julia "彼女は彼女の妹とエメリックと一緒に「勝利のトリオ」の一員です..."


translate japanese e1s3_7507cb6f:


    julia "基本的に、彼らは大学で一番の金持ちなんだ... そしてマディソンは彼らが大嫌いなんだ..."


translate japanese e1s3_a385248f:


    julia "彼女の双子の妹はソフィアで、私たちのセンターバックです。"


translate japanese e1s3_7038dddb:


    julia "彼女は妹よりもずっと話しかけやすいが、魅力的な態度に騙されてはいけない。彼女は魅力的でありながらも、強力でもあるのだ！"


translate japanese e1s3_a361dbe9:


    julia "私たちは彼らを赤と青と呼んでいます、彼らがどのように自分自身を区別するかによって…"


translate japanese e1s3_82263fdf:


    d "赤と青？ポケモンのように？"


translate japanese e1s3_d73aa6a3:


    julia "はは！ うん！"


translate japanese e1s3_061975f3:


    julia "とにかく、今あなたは私たちの周りの世界をよく理解していると思います！あなたが...の中で自分の居場所を見つけられることを願っています。"


translate japanese e1s3_48cb0ac4:


    d "私はそれをやる..."


translate japanese e1s3_b0281f40:


    drew "全ての学生は、講堂に進んでください！"


translate japanese e1s3_1ddcc86e:


    julia "うおお、ドラゴンが来た！行こう！"


translate japanese e1s3_09b45265:


    sofia "ええ、あなた！"


translate japanese e1s3_39f080a3:


    sofia "次回ジュリアのお尻を触りたいと思ったら、それを支えられる自信を持ってください！"


translate japanese e1s3_20cbf439:


    sofia "誰が知っているか？もしかしたら報酬がもらえるかもしれない！"


translate japanese e1s3_2dee059e:


    d "待ってて、ゼニガメ！私に対処できないと思うよ..."


translate japanese e1s3_0bd9218a:


    sofia "ゼニガメ？"


translate japanese e1s3_a06175a5:


    d "はい... そして、もし私があなたをスカートにしたらどうなるでしょうか？もしかしたら進化するかもしれません！"


translate japanese e1s3_b01e04e8:


    sofia "これはジョークですか？"


translate japanese e1s3_eeebd644:


    d "後でね、ブルー！追いつかなきゃいけない人がいるから！"


translate japanese e1s3_c247e1f9:


    beth "あなたは最近到着したフランス人ですか？"


translate japanese e1s3_af8b11bb:


    d "ああ...うーん...はい...なぜですか？"


translate japanese e1s3_885c5460:


    beth "フランス人は多くの分野で才能があると聞きました..."


translate japanese e1s3_e33f6790:


    beth "あなたの活躍を見るのが待ちきれません！"


translate japanese e1s3_e921fbd3:


    d "頑張ります…"


translate japanese e1s3_30b8e981:


    d "うーん… どこに行って座ろうかな？"


translate japanese rubyamphi_3f651d03:


    ruby "[name] ! こっちに来て！"


translate japanese rubyamphi_e0dee2f2:


    d "ライトとリュークは終わった？"


translate japanese rubyamphi_a14d33f1:


    ruby "はい！他の人はわからない…そして今、あなたの名前を思い出しました！"


translate japanese rubyamphi_5ed010e1:


    ruby "うわー！すごく楽しみ！何が起こっているのかわからないけど、みんなが同時にここに来るように頼まれたのは初めてだ！"


translate japanese rubyamphi_7ef11e91:


    d "すぐにわかるでしょう..."


translate japanese juliaamphi_96104f9b:


    julia "もしよければ、一緒に座ってもいいよ！"


translate japanese juliaamphi_f36a5ff4:


    d "了解！"


translate japanese juliaamphi_23835985:


    d "おお、ここにはたくさんの人がいる！"


translate japanese juliaamphi_85bbaf5a:


    julia "はい！なぜみんなをこんなふうに集めたのかはわからないけど、こんなふうに講義室に来るように頼まれたのは初めてだ！"


translate japanese juliaamphi_7f818c7c:


    d "すぐに何が起こっているのか教えてくれると思います…"


translate japanese graceamphi_346d228a:


    d "ここに座ってもいいですか？"


translate japanese graceamphi_45725a3f:


    grace "はい、もちろん！"


translate japanese graceamphi_4f482101:


    grace "昨夜の態度について、再度ごめんなさい... 飲まない方が良いですね..."


translate japanese graceamphi_ace85e09:


    d "心配しないで、それは忘れられたことだ！"


translate japanese graceamphi_9bf01bdc:


    d "私たちをここに連れてきた理由がわかりますか？"


translate japanese graceamphi_b12bd012:


    grace "いいえ、でもすぐにわかるでしょう！"


translate japanese madisonamphi_2b7db42d:


    mad "今は私を邪魔しに来ないで、時期ではない..."


translate japanese madisonamphi_9ea9e686:


    d "私はそれのためにここにいるわけではありません... あなたにもおはようございます..."


translate japanese madisonamphi_2d925ea2:


    mad "なぜみんなが同時にここにいるように言われているのか、理解できない..."


translate japanese madisonamphi_4874636b:


    mad "ジムでトレーニングをしなければなりません…。"


translate japanese madisonamphi_5d9c6a27:


    d "すぐにわかると思います。"


translate japanese amphi_93de61e7:


    drew "親愛なる学生の皆さん..."


translate japanese amphi_42e38028:


    drew "私はオルシ社の社長であり、B.E.S.Tプロジェクトのメインディレクターであるオルシ氏を紹介できることを誇りに思います！"


translate japanese amphi_f0f28a42:


    rufus "ニャー"


translate japanese amphi_b33469a9:


    orushi "あの…ルーファスさん、お願い！"


translate japanese amphi_b241a330:


    ruby "おお、しゃべる猫だ！それはトムですか？"


translate japanese amphi_b007ce34:


    "" with vpunch


translate japanese amphi_edd537f7:


    ruby "わかった、わかった…。"


translate japanese amphi_a79dd47c:


    rufus "フシュッッッッッッッッ"


translate japanese amphi_bd8ba672:


    orushi "良い一日を、親愛なる学生たち！私はオルシ、オルシ株式会社の者です。"


translate japanese amphi_99c49339:


    orushi "あなたは、初日の最初にどうしてアンフィシアターに連れて来られたのか不思議に思っているに違いありません。"


translate japanese amphi_7a42adda:


    orushi "あなたの驚きを理解しています。"


translate japanese amphi_8fadeb0a:


    orushi "あなたは今、特別なプログラムの一部となるために選ばれました。"


translate japanese amphi_c98428d2:


    "" with vpunch


translate japanese amphi_fd03bb4a:


    orushi "この評価プログラム、B.E.S.Tは、あなたを含む100人の参加者の中から、試験に合格し、他の参加者の中で際立つことができるたった一人の学生を決定します。"


translate japanese amphi_152c62ad:


    orushi "皆さんはお互いに競い合うことになります。最初の学期中にテストが行われ、誰が最も優れているかを決定します。"


translate japanese amphi_3e180d9d:


    orushi "それは昼間または夜間、一人またはチームで行われるかもしれず、集まる時間になるとアナウンスがされます..."


translate japanese amphi_d6132e39:


    orushi "この競技の最後に、選ばれた人はB.E.S.T学生の称号、500,000ドルの小切手、そしてオルシコーポ内でのディレクターの助手のポジションを受け取ります。"


translate japanese amphi_2b553e94:


    orushi "私はこれが非常に望ましいポジションであり、多くの皆さんがオルシ株式会社でインターンになるために応募していることを知っています。"


translate japanese amphi_843ce427:


    orushi "この機会を逃さず、何よりもまず試験中にあなたの才能を全て見せてください。"


translate japanese amphi_7a414ab7:


    orushi "あなたたちは100人いて、各テストの後に一部が排除される。"


translate japanese amphi_18d675f3:


    orushi "最初のテストでは、あなたたちの中から50人の学生が選ばれます。"


translate japanese amphi_6ff63c68:


    orushi "これはデュオチームのテストになります。この試練のために、コンピュータがあなたの仲間を決定します。"


translate japanese amphi_569ee4ce:


    orushi "試練を終わらせて、最初の25チームに入らなければ、あなたは排除されます。"


translate japanese amphi_0367d4b5:


    orushi "今、ドリュー先生がチームを発表します！頑張って、そしていつも最高の自分でいることを忘れないでください！"


translate japanese amphi_7b0099ba:


    drew "[name]とルビー！"


translate japanese amphi_17791e2a:


    ruby "素晴らしい！私たちはこれを一緒にやっています！"


translate japanese amphi_0b246b84:


    d "うん！うまくいくことを願っているよ！"


translate japanese amphi_739bdf64:


    ruby "心配しないで！私は速く走るから！君は行って追いかけてきて・・・できるなら！"


translate japanese amphi_882aa9f2:


    d "見てみましょう..."


translate japanese amphi_7ad0cb20:


    drew "ジュリアと[name]！"


translate japanese amphi_4378768a:


    julia "ああ！私たちは一緒だ！"


translate japanese amphi_f05c4e0f:


    d "はい！あなたを失望させないことを願っています！"


translate japanese amphi_4bccb5b2:


    julia "いや！良い心構えを保たなければならない！君は勝者だ！"


translate japanese amphi_f9311cf0:


    d "よし！私たちはこの試練を一緒に勝ち抜く！"


translate japanese amphi_238ae119:


    julia "それが聞きたいことだ！"


translate japanese amphi_b19db6ac:


    drew "[名前]とグレース！"


translate japanese amphi_ff39ce3d:


    grace "私たちはこれに関して同じチームのようですね！"


translate japanese amphi_64256f24:


    d "はい…がっかりしていませんか？"


translate japanese amphi_1142e283:


    grace "もちろんではありません！試験のためにこれ以上の仲間を望むことはできませんでした！あなたは強くて訓練されているように見えます！"


translate japanese amphi_a33da4f1:


    d "私の良い面を見せなければなりません！"


translate japanese amphi_5c729483:


    grace "よし！これを勝ち取ろう！"


translate japanese amphi_6ec0e013:


    drew "マディソンとの[name]！"


translate japanese amphi_3cbbdcb1:


    mad "ああ...私の...神様...."


translate japanese amphi_e5d8bebc:


    d "一緒にこの瞬間を過ごさなければならない..."


translate japanese amphi_04c5548f:


    mad "選択肢がない。だけど、もしかしたらそれは良いことかもしれない... 君は... 健康そうだ..."


translate japanese amphi_0d217974:


    d "あなたも..."


translate japanese amphi_4845a04a:


    mad "どうなるかわからないけど、ただついて来て、無駄な時間を使わないで！"


translate japanese amphi_0e114910:


    d "私はそうしません。"


translate japanese amphi_39df151c:


    orushi "とにかく、待たせることはもうありません..."


translate japanese amphi_d5a82ce4:


    orushi "ああ、忘れそうだった！これもスピードテストになります！コースの開始前に10分があります。"


translate japanese amphi_1abbe7bc:


    orushi "コースはスタジアムの近くで大きな音と共に始まります... あなたはそれを認識するでしょう..."


translate japanese amphi_a22e4927:


    orushi "言った通り、準備に十分かかり、カウントダウンが始まる…"


translate japanese amphi_6e8c0661:


    orushi "今！"




translate japanese e1s3_cf35a02d:


    julia ""


translate japanese e1s3_050733da:


    drew ""


translate japanese amphi_48029896:


    orushi ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
