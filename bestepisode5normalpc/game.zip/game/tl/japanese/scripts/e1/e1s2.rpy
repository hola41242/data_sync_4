


translate japanese e1s2_34ad7e5c:


    "…そして、あなたは一晩中彼と二人きりだったのですか？"


translate japanese e1s2_5db95835:


    "まあ、そうですね、なぜですか？"


translate japanese e1s2_41cf68f1:


    "まあ、わからない…変だよね？彼を知らないのに、あなたのお母さんは彼がここで寝ていると言って、突然男の人が一晩中ソファにいるなんて…"


translate japanese e1s2_24bb8b8a:


    "うん、でもわからないな、彼はちょっと私を感心させる…いい意味で…"


translate japanese e1s2_9237b6e9:


    "それは私のライトで、彼はそうは見えないが、そう、私も同じ印象を持っている！"


translate japanese e1s2_09695720:


    "あなたのライト？"


translate japanese e1s2_2f271829:


    "後で説明するね！そういえば、もう8時なんだ、彼を起こさなきゃ！えっと…ちくしょう、彼の名前は何だっけ？…まあいいや…"


translate japanese e1s2_c73588b3:


    "ライト!!!!!" with hpunch


translate japanese e1s2_67b0fbce:


    d "うわああああああああああ！"


translate japanese e1s2_8614e399:


    ruby "あはは、自分が超美人だってわかっているけど、その表現の文字通りの意味について考えたことはなかったわ！"


translate japanese e1s2_be15c680:


    d "ねぇ、ここで何をしているの？"


translate japanese e1s2_4ad557e3:


    ruby "ええと、ドリュー夫人があなたを部屋まで連れて行くように頼みましたので、すぐに彼女に従った方がいいでしょう、さもなくば... では、行きましょうか？"


translate japanese e1s2_a250c6af:


    d "待って、それとグレースは？"


translate japanese e1s2_1c28c67e:


    grace "はい？"


translate japanese e1s2_a76605d6:


    grace "私のことは心配しないで、支度をするためにまだ1時間あるから！何が起こっているのかわからないけど、大学には時間通りに行かなきゃいけないから急いで！さもないと母が文句を言うし、初日の授業の日に彼女を不機嫌にさせたくないから！"


translate japanese e1s2_0226421c:


    ruby "はい！行こう、行こう、行こう！"


translate japanese e1s2_c71a801b:


    d "私は来ている..."


translate japanese e1s2_72e488c4:


    d "あなたも大学にいるんですね。何を勉強していますか？"


translate japanese e1s2_b6638c06:


    ruby "私は映画を学んでいます、あらゆる形の映画を。とてもワクワクします！ジャックがローズと一緒にドアの上に留まれたかどうかを調べる実験が行われたことを知っていますか？"


translate japanese e1s2_be0b1d53:


    d "何を話しているのですか？タイタニックですか？本当に？"


translate japanese e1s2_53942f8e:


    ruby "うん！！！彼女はとても自己中心的だった… ああ、ジャック、私は凍えそう…"


translate japanese e1s2_74616e87:


    ruby "わかった、ローズ、4度の海で生き延びるように頑張るよ..."


translate japanese e1s2_5d969260:


    d "本気ですか？"


translate japanese e1s2_07929c8d:


    ruby "うんうん... でもそれは本当に興味深いよ！"


translate japanese e1s2_287a87b4:


    d "想像できます。そして、映画のどこが好きですか？"


translate japanese e1s2_6f407893:


    ruby "例えば、私はホラー映画が大好きです...見るのは好きだけど、怖いシーンがあるとすぐに目を覆います！ホラー映画のジャンプスケアみたいなね..."


translate japanese e1s2_414a8171:


    ruby "お腹の中に大きな玉があって、それが爆発するような感覚で、呼吸が止まり、回復するのが難しい…とにかく、私はそれが好きだけど…とても怖い！"


translate japanese propcineruby_3634a7f3:


    d "そうですね、もしよかったら、いつか一緒に映画館で映画を観ることができるかもしれません。それは本当に楽しいかもしれませんが…でも、あなたに無理強いしたくはないです…"


translate japanese propcineruby_99e540a3:


    ruby "はい！はい！はい！"


translate japanese propcineruby_6287fda8:


    d "うーん..."


translate japanese propcineruby_c43add9f:


    ruby "映画が大好きなのに、一度も映画館に誘われたことがない…だから、そう、ライト、あなたの招待を受け入れます"


translate japanese propcineruby_d8d89651:


    d "はは！じゃあ、一緒に映画館に行こう。そして、君に映画を選ばせてあげるよ！"


translate japanese propcineruby_41df4702:


    ruby "本物の映画体験のようにポップコーンをもらえますか？"


translate japanese propcineruby_37851153:


    d "うん、もちろん... もし欲しいなら、大きなポップコーンの tub を買ってあげるよ！"


translate japanese propcineruby_47d453f2:


    ruby "ライトとして君を選んだのは正しい選択だったと確信していたよ！"


translate japanese propcineruby_e0d30fc1:


    d "うん...たぶん..."


translate japanese fincineruby_c945114a:


    ruby "さあ、もうすぐです。あなたの部屋をお見せします！"


translate japanese discoverroom_1a237ef5:


    ruby "自分の部屋を見に行って！10分でそこに行くから、髪の三つ編みがぐちゃぐちゃでやり直さなきゃいけないの！"


translate japanese discoverroom_e7861de8:


    d "うわぁ！これは全部何ですか？"


translate japanese discoverroom_f963a737:


    d "何も触れない方がいいかもしれない... 彼女は約10分後に来るだろう... その間に何をすればいいのだろう？"


translate japanese discoverroom_a6338c52:


    d "吸って..."


translate japanese discoverroom_64e98b03:


    d "しーっ！吐いて..."


translate japanese discoverroom_a6338c52_1:


    d "吸う..."


translate japanese discoverroom_64e98b03_1:


    d "しーっ！吐いて…"


translate japanese discoverroom_64e98b03_2:


    d "シーッ！ 息を吐いて..."


translate japanese discoverroom_2bd4d989:


    d "あなたは私に話しかけていますか？"


translate japanese discoverroom_cd4fae71:


    d "あなたはどれだけ素晴らしいかを示さなければなりません！"


translate japanese discoverroom_6dbb1ebc:


    d "誰が一番ですか？"


translate japanese discoverroom_c656e65a:


    d "私は最高だ！"


translate japanese discoverroom_da8c427f:


    d "彼女が私たちがどうして一つの寝室にいるのか説明してくれることを願っています..."


translate japanese rubychambre_5b47cd33:


    d "もう十分だ！"


translate japanese rubychambre_138d5fe3:


    d "ここをたくさん掃除しなければならない... 自分のもののように感じるために..."


translate japanese rubychambre_af3ce623:


    d "なぜ自分専用の部屋があるのかわからないけれど、私のやり方でそれを使うつもりだ！"


translate japanese rubychambre_508037ac:


    ruby "まあ、先週フランス人の男が今週到着するために、できる限りのものを集めてスペースを作るように頼まれました..."


translate japanese rubychambre_a5e75010:


    ruby "だから、私は来たものの少しをすべて取ったの...でも、あなたが何を好きか全然わからない！だから、あなたに再装飾させる方がいいかな..."


translate japanese rubychambre_182f01ea:


    ruby "とにかく、時間があるときに、9時まであと15分しかないから！！だから、着替えて、行こう！"


translate japanese rubychambre_450849eb:


    d "変わった？でも、私のものすら持ってないのに！それに、あなたの三つ編みはどこにあるの？どうして変えたの？"


translate japanese rubychambre_7d7560a5:


    ruby "ああ、私の編みこみは良くなかった… そして、私はそれを早くしなければならなかった… あなたはそれが好きではないの？"


translate japanese rubychambre_bfcede80:


    d "うーん...それは好きだけど、見た目が大きく変わるね..."


translate japanese rubychambre_e4dc2b71:


    ruby "ちょっとしたおしゃべりは置いておきましょう… クローゼットを見てみて、心配しないで、きっとかっこいいものが見つかるよ！"


translate japanese rubychambre_ddbc3bea:


    ruby "とはいえ、忘れた服の中で私が救えたものはそれだけです・・・だから、さあ、着てみて、そして私に見せて！"


translate japanese rubychambre_dd5d68f3:


    d "え？"


translate japanese rubychambre_06b04368:


    ruby "さあ、急いで！"


translate japanese rubychambre_794a94d7:


    d "さて・・・ここには何がありますか？"


translate japanese rubychambre_04593aa2:


    d "本当にこれを着てほしいの？？"


translate japanese rubychambre_fa34f206:


    ruby "そうだ！子供のようになるな！！！"


translate japanese rubychambre_d83c8599:


    d "でも..."


translate japanese rubychambre_16f08f36:


    ruby "行こう、すでに遅れている！"


translate japanese rubychambre_7bcc50f4:


    d "分かりました..."


translate japanese tenuefier_d419757e:


    ruby "なんてこった、なんてこった、なんてこった！"


translate japanese tenuefier_da447aff:


    d "何が問題ですか？"


translate japanese tenuefier_0954f056:


    ruby "申し訳ありませんが、私は目を閉じずに私の前で服を脱いでいる男の人と一緒にいます！"


translate japanese tenuefier_474f9baa:


    d "ルビー..."


translate japanese tenuefier_4016e5f2:


    ruby "ああ、母さん、私のことをどう思っているのだろう？ 逃げるべきだったと分かっているけれど、私はそうしなかった、そして…"


translate japanese tenuefier_474f9baa_1:


    d "ルビー..."


translate japanese tenuefier_5d647fc8:


    ruby "あなたが魅力的でないわけではないけれど... いいえ！あなたは確実に魅力的だけれど、今ここにいて、女の子がそのような... 逞しい男性を見つめるのは適切ではないのよ..."


translate japanese tenuefier_dbf049bf:


    d "ルビー！" with vpunch


translate japanese tenuefier_8fe3ea01:


    ruby "ああ・・・はい？"


translate japanese tenuefier_ff81dc7d:


    d "振り向いてくれませんか？"


translate japanese tenuefier_aa02d9c8:


    ruby "ああ、はい！もちろん、もちろん…"


translate japanese tenuefier_cf05acac:


    ruby "えっ... ここは急に暑くなってきたの？"


translate japanese tenueshy_ff81dc7d:


    d "振り向いていただけますか？"


translate japanese tenueshy_aa02d9c8:


    ruby "ああ、はい！もちろん、もちろん..."


translate japanese tenueshy_b2766e52:


    ruby "うわぁ… ここが急に暑くなってきたの？"


translate japanese rubydepart_f3a9f496:


    d "オーケー！今、見ていいよ！無限の彼方へ！"


translate japanese rubydepart_74e895dc:


    ruby "ああ、素晴らしい！あなたが何か良いものを見つけると確信していました！そして、フランスでもトイ・ストーリーを知っていますか？"


translate japanese rubydepart_75fcdfb3:


    d "うーん… 映画がないと思っているの？"


translate japanese rubydepart_fb3f392c:


    ruby "いいえ！もちろん、違う... でも、私はそこに行ったことがないから..."


translate japanese rubydepart_ac6d9b74:


    ruby "トイ・ストーリーが初めてのフルアニメーションの3D映画だということを知っていましたか？"


translate japanese rubydepart_05244633:


    d "いいえ、でもそれは面白い！"


translate japanese rubydepart_0fdce267:


    ruby "うん、知ってるよ！昨年私たちはそれについてたくさんのことを学んだ！例えば、映画には110,000枚以上のフレームがあった..."


translate japanese rubydepart_8ec775d3:


    ruby "それぞれのフレームに2時間から15時間かかった… だから、これは500年のレンダリング時間を要する機械の農場だったんだ^^"


translate japanese rubydepart_992e6eaa:


    d "ルビー ?"


translate japanese rubydepart_0a4c4274:


    ruby "はい？"


translate japanese rubydepart_f74d81d3:


    d "遅れたくないと言ったのではありませんか？"


translate japanese rubydepart_e28cd635:


    ruby "さて…ライト、行く準備はできた？"


translate japanese rubydepart_44c0877a:


    ruby "それは質問ではなかった！私たちは行かなければならない！遅れたくない！"

translate japanese strings:


    old "Invite her someday to cinema [TEMP1!t]"
    new "いつか彼女を映画に招待する。"


    old "Not interested [TEMP2!t]"
    new "興味がない [TEMP2!t]"


    old "Do push-ups [TEMP1!t]"
    new "腕立て伏せをする [TEMP1!t]"


    old "Go to the bathroom [TEMP2!t]"
    new "バスルームに行く [TEMP2!t]"


    old "Wait for Ruby"
    new "ルビーを待っている"


    old "30 push-ups later..."
    new "30回の腕立て伏せの後…"


    old "Undress in front of her [TEMP1!t]"
    new "彼女の前で脱ぐ [TEMP1!t]"


    old "Ask her to turn [TEMP2!t]"
    new "彼女に[TEMP2!t]を回してもらって。"


    old "Yes Minus ! [TEMP1!t]"
    new "はい、リューク！ [TEMP1!t]"


    old "Nope [TEMP2!t]"
    new "いいえ [TEMP2!t]"




translate japanese e1s2_770af536:


    ""


translate japanese e1s2_80c276a3:


    ""


translate japanese e1s2_31e3cfa2:


    ""


translate japanese e1s2_501d5b80:


    ""


translate japanese e1s2_78364aef:


    ""


translate japanese e1s2_7df24e34:


    "" with hpunch


translate japanese e1s2_6b6758b7:


    ruby ""


translate japanese e1s2_45a5dd64:


    d ""


translate japanese e1s2_67c680bf:


    grace ""


translate japanese e1s2_bf9bfb15:


    d ""


translate japanese e1s2_1af9e6cb:


    ruby ""


translate japanese e1s2_55638aae:


    d ""


translate japanese e1s2_96cc0adf:


    ruby ""


translate japanese e1s2_f2d78baa:


    ruby ""


translate japanese e1s2_4d71f41f:


    d ""


translate japanese e1s2_b3ab0599:


    ruby ""


translate japanese e1s2_b62db3ff:


    ruby ""


translate japanese e1s2_9cf93c5d:


    ruby ""


translate japanese propcineruby_6e776a5e:


    d ""


translate japanese propcineruby_4ea2e005:


    ruby ""


translate japanese propcineruby_1f60adc7:


    ruby ""


translate japanese propcineruby_141e7c18:


    ruby ""


translate japanese propcineruby_849605a1:


    d ""


translate japanese discoverroom_85dbadc3:


    ruby ""


translate japanese discoverroom_1594124b:


    d ""


translate japanese discoverroom_16a1548f:


    d ""


translate japanese discoverroom_16a1548f_1:


    d ""


translate japanese discoverroom_16a1548f_2:


    d ""


translate japanese discoverroom_84ecfab6:


    d ""


translate japanese discoverroom_8a3f962d:


    d ""


translate japanese discoverroom_863e77a7:


    d ""


translate japanese discoverroom_a238a1d1:


    d ""


translate japanese rubychambre_5bef6195:


    d ""


translate japanese rubychambre_41072c92:


    d ""


translate japanese rubychambre_c06c20e5:


    d ""


translate japanese rubychambre_664ab157:


    ruby ""


translate japanese rubychambre_8806eefc:


    ruby ""


translate japanese rubychambre_2d6b02e1:


    ruby ""


translate japanese rubychambre_a794f044:


    d ""


translate japanese rubychambre_91fb8673:


    ruby ""


translate japanese rubychambre_a6f5264d:


    d ""


translate japanese rubychambre_7f6541d4:


    ruby ""


translate japanese rubychambre_bc471c95:


    ruby ""


translate japanese rubychambre_f4d512f9:


    d ""


translate japanese rubychambre_5a34b207:


    d ""


translate japanese rubychambre_44a8b55f:


    ruby ""


translate japanese tenuefier_893914d0:


    ruby ""


translate japanese tenuefier_2baafa95:


    d ""


translate japanese tenuefier_df0c0189:


    ruby ""


translate japanese tenuefier_42253061:


    ruby ""


translate japanese tenuefier_ec8a59ae:


    ruby ""


translate japanese tenuefier_0a90153a:


    d "" with vpunch


translate japanese tenuefier_ad8e36ef:


    ruby ""


translate japanese tenuefier_2f16cf06:


    d ""


translate japanese tenuefier_f744f755:


    ruby ""


translate japanese tenuefier_3be2d750:


    ruby ""


translate japanese tenueshy_2f16cf06:


    d ""


translate japanese tenueshy_f744f755:


    ruby ""


translate japanese tenueshy_3be2d750:


    ruby ""


translate japanese rubydepart_59094040:


    d ""


translate japanese rubydepart_9e16abcd:


    ruby ""


translate japanese rubydepart_2293fb7a:


    d ""


translate japanese rubydepart_0d55d8d0:


    ruby ""


translate japanese rubydepart_5efecdc4:


    ruby ""


translate japanese rubydepart_c2b42767:


    d ""


translate japanese rubydepart_88c4f110:


    ruby ""


translate japanese rubydepart_a8d12340:


    ruby ""


translate japanese rubydepart_136f81dc:


    d ""


translate japanese rubydepart_b89db320:


    ruby ""


translate japanese rubydepart_438eb630:


    d ""


translate japanese rubydepart_9dfd8c7e:


    ruby ""


translate japanese rubydepart_a95d95e2:


    ruby ""

translate japanese strings:


    old "Ask her to turn around [TEMP2!t]"
    new ""


    old "Yes Minus! [TEMP1!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
