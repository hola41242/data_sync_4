

translate japanese strings:


    old "{color=#ffffffff}Taxi Drive{/color}"
    new "{color=#ffffffff}タクシードライブ{/color}"


    old "{color=#ffffffff}Red is Dead{/color}"
    new "{color=#ffffffff}赤は死んでいる{/color}"


    old "{color=#ffffffff}Bed is Red{/color}"
    new "{color=#ffffffff}ベッドは赤い{/color}"


    old "{color=#ffffffff}Kitty{/color}"
    new "{color=#ffffffff}キティ{/color}"


    old "{color=#ffffffff}Dirty{/color}"
    new "{color=#ffffffff}汚い{/color}"


    old "{color=#ffffffff}Yummy{/color}"
    new "{color=#ffffffff}おいしい{/color}"


    old "{color=#ffffffff}Ice-Cream{/color}"
    new "{color=#ffffffff}アイスクリーム{/color}"


    old "{color=#ffffffff}MotorButt{/color}"
    new "{color=#ffffffff}モーターバット{/color}"


    old "{color=#ffffffff}Mystery{/color}"
    new "{color=#ffffffff}神秘{/color}"



translate japanese strings:


    old "{color=#ffffffff}Temple{/color}"
    new ""


    old "{color=#ffffffff}Bed is Blue{/color}"
    new ""


    old "{color=#ffffffff}Shooting{/color}"
    new ""


    old "{color=#ffffffff}Mother{/color}"
    new ""


    old "{color=#ffffffff}Peace{/color}"
    new ""


    old "{color=#ffffffff}Witch{/color}"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
