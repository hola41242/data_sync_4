


translate japanese e3s1a_913c1b8d:


    ruby "さあ！そんな風にならないで！すぐにわかるよ、楽しいから！"


translate japanese e3s1a_df808924:


    d "うーん、それについてはあまり自信がないな…"


translate japanese e3s1a_fe425094:


    ruby "そうなるよ！レッドはとてもプロフェッショナルだから！明日のパーティーのために、素晴らしいものを見つけてくれると確信しているよ！"


translate japanese e3s1a_2a6ac8ac:


    d "私たち？"


translate japanese e3s1a_5f3fc3b6:


    ruby "もちろん！明日はテーマパーティーです。誰かが教えてくれなかったの？"


translate japanese e3s1a_2940ea0e:


    d "うーん…違う？"


translate japanese e3s1a_979fa522:


    ruby "それはシックで挑発的なパーティーです！"


translate japanese e3s1a_41d1ae04:


    d "それはどういう意味ですか？"


translate japanese e3s1a_90556121:


    ruby "まあ、それはしばしば、ファンシーでセクシー、または目立つもので着飾ることについてです。"


translate japanese e3s1a_5cadcfe2:


    d "どうやって私にシックで挑発的であることを期待するの？"


translate japanese e3s1a_470e5aa3:


    beth "心配しないで、私は助けるためにここにいます。"


translate japanese e3s1a_29ac5843:


    d "何？"


translate japanese e3s1a_bfc79f9d:


    ruby "ありがとう、エリザベス！"


translate japanese e3s1a_20ab99ea:


    beth "どういたしまして。私の仕事ですからね。"


translate japanese e3s1a_a83292d0:


    beth "ルビー、どんなスタイルを探しているか知ってる？"


translate japanese e3s1a_25a5ce6d:


    ruby "本当に、今回は全く分からない。"


translate japanese e3s1a_4f1ceddc:


    beth "あなたのために何があるか見てみますので、その間自由に探ってください。"


translate japanese e3s1a_ea7bcd1b:


    ruby "わかった！"


translate japanese e3s1a_890030aa:


    ruby "ほら、言ったでしょう！彼女の店にいるとき、彼女はまったく変わるんだ！"


translate japanese e3s1a_e48c9cb0:


    d "うーん…"


translate japanese e3s1a_f890b9d6:


    ruby "まあ、まだ何かを見つける必要がありますね。アイデアはありますか？"


translate japanese e3s1a_3bf529d7:


    d "あなたが着るものは何でも似合うに違いない。私には確信がある！"


translate japanese e3s1a_859f0f2e:


    ruby "ああ！あなたはとても優しいですね！"


translate japanese e3s1a_3ee9764b:


    d "あなたの体を際立たせるような服を着てほしい。あなたは素晴らしいけれど、それをもっと見せていない！"


translate japanese e3s1a_8cc00336:


    ruby "あら？えっと、頑張ってみる..."


translate japanese e3s1a_7e930183:


    beth "こっちに来て、あなたに試してもらいたいものがいくつか見つけたよ！"


translate japanese e3s1a_c05087df:


    ruby "出発だ！"


translate japanese e3s1a_a1a21cfb:


    beth "ここが、ルビー。君はこの試着室を使っていいよ。"


translate japanese e3s1a_1efbcfae:


    ruby "オッケー！ありがとう、エリザベス！"


translate japanese e3s1a_53611aa8:


    d "今が楽しい部分です！"


translate japanese e3s1a_7248ffa2:


    beth "こっちに来て[name]、君に試してもらいたいものがいくつかあるよ！"


translate japanese rubyshop_ed1da845:


    ruby "見てもいいよ、私は気にしないから！"


translate japanese rubyshop_2c3a63c7:


    d "何を意味していますか？"


translate japanese rubyshop_952add76:


    ruby "あなたが部屋で私の目の前で変わったのに、私は目を閉じなかった... だから、それはただの公平だ！"


translate japanese rubyshop_f338cc08:


    d "あの…"


translate japanese rubyshop_cc0022e7:


    ruby "今、恥ずかしがっているのは誰かな..."


translate japanese rubyshop_9e0087a7:


    d "私は恥ずかしがっていない！"


translate japanese rubyshop_ec40631d:


    ruby "それから、私のドレスを脱がせるのを手伝って。"


translate japanese rubyshop_29ac5843:


    d "何？"


translate japanese rubyshop_1bb724e6:


    ruby "私のドレス。ファスナーが詰まっていて、開けることができない！"


translate japanese rubyshop_8d0a4a6e:


    d "ああ...わかった！"


translate japanese rubyshop_e2889d3c:


    ruby "ああ"


translate japanese rubyshop_ad43ddfc:


    ruby "うーん...."


translate japanese rubyshop_75127a40:


    ruby "おおぉ..."


translate japanese rubyshop_492766ce:


    ruby "うーん"


translate japanese rubyshop_a905bd37:


    ruby "Euh...."


translate japanese rubyshop_8ae3f02b:


    ruby "ありがとう。"


translate japanese rubyshop_23b2f656:


    ruby "座ってください。私のお気に入りを見せるので、どれが好きか教えてください！"


translate japanese rubyshop_40ab082c:


    d "私には良い音です！"


translate japanese rubyshop2_18748a7f:


    ruby "どう思う？"


translate japanese rubyshop2_6366f041:


    d "悪くはないけれど、シックで挑発的と言えるかどうかわからない。"


translate japanese rubyshop2_56516992:


    ruby "うん。あなたはおそらく正しい。"


translate japanese rubyshop2_c2881933:


    d "わぁ..."


translate japanese rubyshop2_f9611e40:


    d "素晴らしい！"


translate japanese rubyshop2_57fa5bbe:


    d "これはどういうことですか？あなたにすべてが似合っています！"


translate japanese rubyshop2_7034f0b6:


    ruby "どちらが好きですか？"


translate japanese rubyshop2_0bfcc6ba:


    d "正直に言うと…決められない。あなたはどれも素晴らしいです！"


translate japanese rubyshop2_53917e62:


    ruby "じゃあ、私が選ぶね。そして、明日の夜には驚かせることになるよ！"


translate japanese rubyshop2_e0a25cf5:


    d "それはいい音だね！"


translate japanese redshop_43398bf1:


    d "なんだって..."


translate japanese redshop_12681d03:


    beth "しゅっ..."


translate japanese redshop_146362be:


    ruby "何が起こったのですか？"


translate japanese redshop_7d28839c:


    d "何もないよ、ただいくつかの衣装に驚いただけなんだ！"


translate japanese redshop_60c4b680:


    ruby "ああ！大丈夫！変なものを着る必要はないよ。ただあなたらしく、でもシックで挑発的に！"


translate japanese redshop_2e748302:


    beth "あなたが早くなってほしいなら、私がそれを処理しなければならない。"


translate japanese redshop_9d9f175f:


    beth "そして、私のキャビンをめちゃくちゃにしてほしくない... だから..."


translate japanese redshop_c6f2cd3d:


    d "くそ、彼女は深く突っ込む！"


translate japanese redshop_2307991b:


    ruby "何ですか？"


translate japanese redshop_bcd68d7a:


    d "うーん... あなたの考えは深いと言った！"


translate japanese redshop_e6fa808c:


    ruby "ああ... そう思いますか？"


translate japanese redshop_731e5fce:


    d "私は... 私は... できない..."


translate japanese redshop_b4af70db:


    ruby "心配しないで。あなたの考えていることを私に話してもいいよ！"


translate japanese redshop_64f0d24d:


    d "共有する？気にしない？"


translate japanese redshop_1c0a8c41:


    beth "うーん…"


translate japanese redshop_94364417:


    ruby "もちろん！"


translate japanese redshop_8fc1ec88:


    d "ああああああ！とても気持ちいい！"


translate japanese redshop_8c5e2da6:


    ruby "そんな効果があるなんて気づかなかった。"


translate japanese redshop_c665f1b6:


    d "私は空虚に感じる！"


translate japanese redshop_e47ecb4c:


    ruby "それが原則です！リラックスするために自分を空にしてください！"


translate japanese redshop_8655210a:


    d "何も知らない、ジョン・スノウ。"


translate japanese redshop_af29a28e:


    ruby "こんにちは！それは私のフレーズです！"


translate japanese redshop_f5f0c740:


    d "うん... 何もかも満足している!"


translate japanese mcshop_92592ec0:


    ruby "あなたはどうですか？"


translate japanese mcshop_0beb0af8:


    beth "彼のことを心配しないで。私は彼の衣装を直接パーティーに持っていくから！彼が何が必要かは分かっている！"


translate japanese mcshop_dee5c425:


    d "ええと… 本当に大丈夫ですか？"


translate japanese mcshop_19e14c97:


    ruby "ああ、これが大好き！私たちは二人とも驚くことができる！"


translate japanese mcshop_e81f6775:


    d "私は自分が...どうか分からない。"


translate japanese mcshop_1d773b28:


    beth "はい、はい！私を信じて！明の夜、エメリックもあなたほど素敵には見えないよ！"


translate japanese mcshop_7662c915:


    d "でも、もし..."


translate japanese mcshop_fb897691:


    ruby "それは私にとって問題ない！ライトをちゃんと見せる必要がある。彼はみんなを魅了する必要がある！"


translate japanese mcshop_a774e662:


    beth "約束するよ、ルビー！"


translate japanese mcshop_84464bc4:


    ruby "素晴らしい！さて、私は行かなければなりません。遅くなってきて、明日のためにしっかり休みたいです！"


translate japanese mcshop_58cf6d6d:


    ruby "[name]、来る？"


translate japanese mcshop_0cde5eaa:


    d "うーん、帰る前にどこかで一口食べるつもりだった。"


translate japanese mcshop_055b97ca:


    ruby "ああ？じゃあ、ブロックを下ると、いくつかのレストランがあります。"


translate japanese mcshop_fbc4a3b1:


    d "完璧です！知らせてくれてありがとう。"


translate japanese mcshop_a40b363d:


    ruby "家に着いたら、メッセージを期待してもいいかな？"


translate japanese mcshop_320e0c8a:


    d "ああ…うん、もしあなたが望むなら…"


translate japanese mcshop_5ab4406d:


    ruby "私は少し過保護に聞こえるかもしれませんが、大切に思っている人たちを夜に一人にしておくのは嫌なんです。"


translate japanese mcshop_02721b20:


    d "あら？それは優しいですね！私のことは心配しなくて大丈夫、私は大丈夫です。"


translate japanese mcshop_beb57c11:


    ruby "では、明日会いましょう！"


translate japanese mcshop_0eaf48fc:


    d "また明日！"


translate japanese mcshop_c645839b:


    d "私のためのスーツはないよね？"


translate japanese mcshop_701a8840:


    beth "もちろん、そうします。明日持ってきますね！"


translate japanese mcshop_134c20f9:


    d "本気で？"


translate japanese mcshop_c313eee8:


    beth "絶対に！満足させれば、あなたには報酬があると言ったでしょう。"


translate japanese mcshop_291126b8:


    beth "あなたは確かにそうしました... 以前に私にすべてを与えてくれました。"


translate japanese mcshop_ce4e4abc:


    beth "だから、明日パーティの前に会って、その時に君に渡すよ。"


translate japanese mcshop_4b78c937:


    d "私にはうまくいくよ！明日ね、エリザベス！"


translate japanese mcshop_79e0c399:


    beth "また明日!"


translate japanese mcshop_c8810e50:


    beth "もちろん違います。自分で考えてみてください。"


translate japanese mcshop_b7ff5f06:


    d "本気ですか？"


translate japanese mcshop_82668fcd:


    beth "お前が誰と対峙しているのかわからないだろ、フランス人。すぐにわかるようになる。"


translate japanese mcshop_06e7f82f:


    d "ああ...じゃあ、明日会いましょう。"


translate japanese mcshop_054b635f:


    beth "明日会いましょう。"

translate japanese strings:


    old "Follow Red[TEMP1!t]"
    new "レッドに従え[TEMP1!t]"


    old "Stay with Ruby[TEMP2!t]"
    new "ルビーと一緒にいる"




translate japanese rubyshop_95230105:


    ruby ""


translate japanese mcshop_a829e67e:


    d ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
