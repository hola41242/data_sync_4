


translate japanese e3s2_1127c8b7:


    dpense "この街は実際にはかなり大きいです。"


translate japanese e3s2_921070ae:


    dpense "私は簡単に迷子になりそうです。"


translate japanese e3s2_af8cb32c:


    dpense "お腹が空いてきたなぁ..."


translate japanese e3s2_628dd100:


    d "くそぉ！！！"


translate japanese e3s2_8c797edf:


    ji "[name]!"


translate japanese e3s2_9a5a998a:


    ji "気をつけて！あなたを轢くところだったわ！"


translate japanese e3s2_141331e8:


    d "ガブリエラ？"


translate japanese e3s2_6ad75cf1:


    gaby "はい？"


translate japanese e3s2_e3f41e12:


    d "あなたの体を誇りに思うべきだと言ったとき..."


translate japanese e3s2_154ba855:


    gaby "何を暗示しているのですか？"


translate japanese e3s2_360b7017:


    d "ああ、何でもないよ..."


translate japanese e3s2_3b4d6953:


    gaby "何があなたを一人でここに連れてきたのですか？"


translate japanese e3s2_c9a1e7db:


    d "そうだ、家に帰るところだった..."


translate japanese e3s2_e1a3f444:


    d "しかし、私はかなりお腹が空いてきたので、食べ物を得る場所を探していました。"


translate japanese e3s2_bf70937f:


    gaby "あぁ... えっと、角を曲がったところに魅力的なアイスクリーム店があって、食事も提供しています。"


translate japanese e3s2_fd5a6c65:


    d "あなたは？"


translate japanese e3s2_7e55ce1d:


    gaby "あなたは、私をどういう意味で呼んでいるのですか？"


translate japanese e3s2_a948d4c0:


    d "こんな風にどこへ行くの？"


translate japanese e3s2_808c3229:


    gaby "おお！さて、私はもう少し先のパブで友達に会う予定です。"


translate japanese e3s2_a03f3ec8:


    gaby "新鮮な空気を吸っています。心をクリアにしようとしています。"


translate japanese e3s2_cfca72a0:


    d "そして楽しんでいますか？"


translate japanese e3s2_ea659a8f:


    gaby "何を提案しているのですか？"


translate japanese e3s2_e083016a:


    d "あなたはしばしばとても真剣に見えます。もっと楽しむべきです。"


translate japanese e3s2_0a9cfc2b:


    d "改めて申し上げますが、尊敬を込めて、あなたには全ての人生が待っています。"


translate japanese e3s2_40639949:


    d "それを大切にし、少しだけ生きることを許可すべきです。"


translate japanese e3s2_edb73cb4:


    gaby "言うは易く行うは難し。"


translate japanese e3s2_1dd96015:


    d "もしかしたら、私は助けになれるかもしれない。"


translate japanese e3s2_66b194e0:


    gaby "失礼しますか？"


translate japanese e3s2_db8727cf:


    d "いいえ、つまり…もし新しいことを体験したいと感じたら、出かけて、探検することを。"


translate japanese e3s2_09fdfeb6:


    d "教えてくれれば、喜んであなたに付き添います！"


translate japanese e3s2_854ec0fe:


    gaby "考えてみます。"


translate japanese e3s2_40e6a329:


    gaby "まあ、友達を待たせるわけにはいかないな…"


translate japanese e3s2_c5662bab:


    gaby "あなたは自分の道を見つけることができますか？"


translate japanese e3s2_17918988:


    d "この通りの端にあると言ったよね？角を曲がったところ？"


translate japanese e3s2_f9ad3300:


    gaby "はい、それが正しいです。"


translate japanese e3s2_b457e59a:


    d "それでは、あの方向に行ってアイスクリーム屋さんを見つけられるか見てみます。"


translate japanese e3s2_7fd3646a:


    gaby "うーん... あなたはその街に詳しくないのですね？"


translate japanese e3s2_33aadc58:


    gaby "これ、私の番号を受け取ってください。もし何か困ったことがあれば、遠慮なく電話してください。"


translate japanese e3s2_9ea04bdb:


    gaby "緊急の場合だけだ、わかった？"


translate japanese e3s2_a5966752:


    d "あぁ、はい... わかりました。"


translate japanese e3s2_9cd3569b:


    gaby "ああ、そういえば、誰にも共有しないでね..."


translate japanese e3s2_6fc56de8:


    gaby "私はあなたを信頼しています。"


translate japanese e3s2_a611fd9b:


    d "約束だ。"


translate japanese e3s2_2d1a777c:


    gaby "では、良い夕方をお過ごしください、[name]。"


translate japanese e3s2_fca7b125:


    dpense "あなたも、ガブリエラ。"


translate japanese e3s2_0b836494:


    dpense "すごい！先生の電話番号を手に入れた！！！"


translate japanese e3s2_a9dbaa79:


    dpense "あははは！"


translate japanese e3s2_0e9f075b:


    dpense "ルビーがこれを知っていたらいいのに。"


translate japanese e3s2_6f01d825:


    dpense "さて、通りの角に向かう..."


translate japanese e3s2_4d58dae6:


    hec "やあ、みんな！ボスはいないよ！"


translate japanese e3s2_fb38d61b:


    hec "食事をして逃げたい？あのバカに教訓を与えることになるよ..."


translate japanese e3s2_32390969:


    "うん！"


translate japanese e3s2_804023bd:


    "あははは！"


translate japanese e3s2_ff71161a:


    julia "やあ！！！"


translate japanese e3s2_3db33b00:


    julia "ここに戻ってきて！支払いが必要です！"


translate japanese e3s2_b235ac9e:


    julia "くそったれ！"


translate japanese e3s2_2302240e:


    julia "ふんっ…"


translate japanese e3s2_95b1505d:


    hec "どっか行け、汚いスラット！"


translate japanese e3s2_70d11f38:


    julia "止まれ！"


translate japanese e3s2_e2fbc6f9:


    julia "支払いが必要です！"


translate japanese e3s2_f24da56c:


    hec "ピンキー！私を放して！"


translate japanese e3s2_18c56c61:


    hec "あなたは自分が受けるべきものを手に入れるでしょう！"


translate japanese e3s2_769b2c2f:


    julia "痛っ！"


translate japanese e3s2_8f910df6:


    hec "ピンキー、私たちを行かせるように言ったでしょう！"


translate japanese e3s2_77d23ef5:


    hec "足りないの？"


translate japanese e3s2_101332d7:


    julia "え？"


translate japanese e3s2_a2431503:


    julia "いいえ！私は…"


translate japanese e3s2_12cbfb5a:


    hec "そのクソ女を受け取れ！"


translate japanese e3s2_d1d296af:


    julia "やっほー！"


translate japanese e3s2_101332d7_1:


    julia "え？"


translate japanese e3s2_b1807fea:


    julia "何だと..."


translate japanese e3s2_dc11a5bc:


    hec "あなたは何ですか？"


translate japanese e3s2_f67fdb4c:


    julia "[name]!"


translate japanese e3s2_3cacebcc:


    d "君はどうしたの？ そんな風に女性を攻撃するなんて？"


translate japanese e3s2_49e8c780:


    hec "私を行かせて！あなたには関係ないことよ！"


translate japanese e3s2_ed275116:


    d "彼女は私の友達だから、それは私の事だ。"


translate japanese e3s2_5f341222:


    hec "あなたは何をするつもりなの？僕は彼女に触れていない。もし君が僕を殴ったら、目撃者がいるよ。もし君が警察と問題になったら..."


translate japanese e3s2_3e77ba36:


    hec "アカデミーにさよならを言うことができる。フレンチー。"


translate japanese e3s2_fbe4d78d:


    julia "忘れてしまえ、[name]... 彼は面倒くさいだけだ。"


translate japanese e3s2_7896dad8:


    hec "そうだ。フィールドで会おう、田舎者たち。"


translate japanese e3s2_67b527e6:


    hec "それから誰が強く叩くか見てみよう。"


translate japanese e3s2_f9c7f0b0:


    d "大丈夫ですか？"


translate japanese e3s2_c63680a9:


    julia "ああ、そうだね... 君が関わる必要はなかった。"


translate japanese e3s2_e967c7b8:


    d "私も彼に君を殴らせるつもりはなかった。"


translate japanese e3s2_2d39ae6d:


    julia "まあ、ありがとう..."


translate japanese e3s2_73abd97c:


    cha "ジュリア？大丈夫？"


translate japanese e3s2_bc1784aa:


    cha "私はそのシーンを見ました。なんてことだ。"


translate japanese e3s2_5f7f804f:


    julia "はいはい、心配する必要はありません。"


translate japanese e3s2_1ba20f5d:


    cha "ありがとう、若者よ、彼女を助けてくれて... ミスター？？？"


translate japanese e3s2_1604c1be:


    d "[name]."


translate japanese e3s2_acca40b4:


    cha "再度ありがとう、[name]。彼女を一人で夜勤を任せるべきではなかった。"


translate japanese e3s2_33b7d50d:


    cha "店に戻りましょう。"


translate japanese e3s2_93e168f1:


    ji "面白い..."


translate japanese e3s2_e01c9248:


    d "あなたはここで働いていますか？"


translate japanese e3s2_4e619f92:


    julia "はい..."


translate japanese e3s2_48ce23ad:


    d "どうして教えてくれなかったの?!"


translate japanese e3s2_bd49eff6:


    cha "待って、内部に入ろう。ホットチョコレートを飲むのはみんなに良いことだろう..."


translate japanese e3s2_6f6f00e8:


    cha "ハンサムで、強く、勇敢だ！あなたが歌っていた理由がわかる。もしあなたが彼にすぐにアプローチしなければ、私が自分でやるから！"


translate japanese e3s2_15d9b8f0:


    julia "どうぞ、お気軽に。"


translate japanese e3s2_2387a6fc:


    cha "真面目に？"


translate japanese e3s2_cccd82e6:


    julia "ええ、彼はあなたのものです。"


translate japanese e3s2_ec0ae24c:


    julia "するべきだと思いますか？"


translate japanese e3s2_4bc03d25:


    cha "そんな男、信じてほしい、街全体で十人も見つからないよ。絶対に動いた方がいい。"


translate japanese e3s2_d1f70c04:


    julia "..."


translate japanese e3s2_36ccb686:


    cha "本当にごめん、ジュリア。会計が終わった後、できるだけ早く来たけど、時間がかかるんだ。"


translate japanese e3s2_d62322d6:


    julia "あなたのせいじゃない。"


translate japanese e3s2_22478a66:


    cha "もう一人で開けさせることはしないよ。"


translate japanese e3s2_6d3fade6:


    julia "それについては何もできない。私たちにお金を払わないか、私たちを困らせようとする迷惑な人はいつもいる...特にこの服を着ているときは。"


translate japanese e3s2_bccda825:


    julia "痛い！"


translate japanese e3s2_b4f06701:


    d "怪我をしましたか？"


translate japanese e3s2_f446ab7a:


    julia "私は腰を少し痛めたと思う。これはさっき転んだ時のせいだろう。"


translate japanese e3s2_4d7dd868:


    cha "聞いて、ジュリア。残りの夕方は休んでいいよ。心配しないで、シフト全体分の給料は払うから、月曜日にどうしているか知らせてね、わかった？"


translate japanese e3s2_dc1b71b4:


    julia "うん、本当に...?"


translate japanese e3s2_00d9f982:


    cha "はい、もちろん！続けてください！"


translate japanese e3s2_737c091e:


    julia "じゃあ、明日のアカデミーで会おう？"


translate japanese e3s2_4395d1e1:


    cha "待って、あんなことの後に一人で帰るつもりじゃないの？"


translate japanese e3s2_101332d7_2:


    julia "え？"


translate japanese e3s2_b07c4bd4:


    cha "[name]... 彼女を家まで送ってあげてもらえる？もしあの連中がまだ周りにいるかもしれないから。彼女も痛がってる、かわいそうに..."


translate japanese e3s2_c86d76cd:


    d "絶対に！"


translate japanese e3s2_98ee41e1:


    julia "ありがとう、シャーロット。そしてありがとう、[name]..."


translate japanese e3s2_3d6f8fcc:


    d "どういたしまして、こんな風にあなたを放っておくことはできなかった。"


translate japanese e3s2_cb310aad:


    cha "ああ、ジュリア！気をつけて！少なくとも私はあなたが良い手にいると確信しています！"


translate japanese e3s2_5f93d507:


    julia "ああ…そうだね。月曜日に会おう！"


translate japanese e3s2_c429c485:


    d "ごめん、ジュリア。今日は長い一日だったし、ただ食べに来ただけなんだ。ちょうど訓練を終えたところで、..."


translate japanese e3s2_64959bcf:


    julia "ああ... ええ、もちろん、問題ありません。"


translate japanese e3s2_737c091e_1:


    julia "じゃあ、明日アカデミーで会おうか？"


translate japanese e3s2_bdc6126b:


    d "うん！明日ね！"


translate japanese e3s2_28ec6028:


    julia "じゃね…"


translate japanese e3s2_c429f4fb:


    cha "よかった、あなたがそこにいて。"


translate japanese e3s2_dbed8808:


    cha "かわいそうなジュリア..."


translate japanese e3s2_4fdbb733:


    d "うん。"


translate japanese e3s2_7d3fd540:


    cha "それに加えて、ここであなたを見たことがありません！"


translate japanese e3s2_4e2cab3e:


    cha "あなたのような人を覚えているはずです！"


translate japanese e3s2_9764bddd:


    d "私はアメリカに到着したばかりです。私はフランスから来ました。"


translate japanese e3s2_12aafb8a:


    cha "ああ。アメリカに来るのは初めてですか？"


translate japanese e3s2_fc6dea88:


    d "うん..."


translate japanese e3s2_03dd73c2:


    d "どういたしまして！"


translate japanese e3s2_f06a7085:


    cha "恥ずかしがらないで！噛んだりしないよ！まぁ、優しく頼まれたら、もしかしたら…"


translate japanese e3s2_84242d48:


    d "ただ、ここで人と話すことにまだあまり慣れていないだけです。個人的なことではありません。"


translate japanese e3s2_e89828e2:


    cha "うん、わかるよ。たくさんの異なる人々に会って、自分を見失うこと。"


translate japanese e3s2_00c88aec:


    d "その通りです。そして、あなたの眼鏡に何が起こったのですか？時々かけていて、時々かけていない。"


translate japanese e3s2_1adcfb1a:


    cha "あら？私は仕事中に読むためだけに使って、もっと…大人っぽく見える！でも、他の人と話さない男の人には…"


translate japanese e3s2_b3d1e3a6:


    cha "それは、数日しか知らない女の子のために自分を危険にさらすのを止めることはできなかった。"


translate japanese e3s2_9ce586db:


    d "そうですね… そういうふうに言われると、ちょっと愚かに思えます。でも、私はただ本能的に行動しただけです。"


translate japanese e3s2_2085f4f1:


    cha "愚か者？多分。それは見事だったと言えるだろう。女性を守ろうと介入する勇気を持った人を毎日見るわけではない。"


translate japanese e3s2_853db437:


    cha "それは私の好奇心をそそります。"


translate japanese e3s2_aa5d264e:


    d "ああ、本当に？"


translate japanese e3s2_28ead7f2:


    cha "もちろん！あなたについてもっと知りたいと思う。あなたがどこから来たのか、どんな人生を歩んできたのか、あなたの旅は..."


translate japanese e3s2_28985498:


    d "それほど興味深くはないよ。"


translate japanese e3s2_a124aa82:


    cha "私にとって、それはそうだ！あなたはジュリアを助けたから、あなたはヒーローだ！私と一緒にリラックスできるよ！"


translate japanese e3s2_f338cc08:


    d "あの…"


translate japanese e3s2_8d96a0f5:


    cha "ねえ、私は六十じゃないんだからね！私が年寄りに見えると思っているの？"


translate japanese e3s2_22466bae:


    d "失礼ですが…あなたは私のタイプではありません。これ以上は言わないことにします。"


translate japanese e3s2_c3e5e858:


    cha "え？"


translate japanese e3s2_9df72a84:


    d "ホットチョコレートをありがとう。"


translate japanese e3s2_497f2de3:


    cha "ええと...わかりました。"


translate japanese e3s2_3a27a1c5:


    cha "なんて奇妙な男の子なんだ。"


translate japanese e3s2_1e387d97:


    d "古い？そんなことない！年齢は本当はあまり関係ないでしょう？"


translate japanese e3s2_174c156d:


    cha "もっと教えて..."


translate japanese e3s2_e8c8cd80:


    d "もし私が年上の女性とお出かけすることになったら、友達としてでも、もっと深い関係としてでも、あなたがそばにいてくれることを誇りに思うでしょう。だから、ここでは年齢は関係ないと思います。"


translate japanese e3s2_5e85b9f6:


    cha "誇り?"


translate japanese e3s2_3223290c:


    d "うん！自分のビジネスを持つアクティブな女性がいるって、"


translate japanese e3s2_7180550b:


    d "街を一緒に探索する魅力的な女性、"


translate japanese e3s2_d0ed1b72:


    d "多くの可能性を探求できる経験豊富な女性..."


translate japanese e3s2_d7e45884:


    cha "わかった、わかった、了解した..."


translate japanese e3s2_a55a49c7:


    cha "聞いて、遅くなってきた。やることがある。"


translate japanese e3s2_861c4633:


    cha "明日の夜のパーティーに行く予定ですか？"


translate japanese e3s2_60d6331e:


    d "はい。"


translate japanese e3s2_48972c73:


    cha "では、行く前に立ち寄ってください。私は午後ずっと在庫の確認をしています。"


translate japanese e3s2_3566bcd4:


    cha "完璧だね。じゃあ、明日会おうか？"


translate japanese e3s2_d20a6f4a:


    d "じゃあ、その時にね、シャーロット。"


translate japanese e3s2_c19b505a:


    cha "じゃね、[name]。"


translate japanese e3s2_973b12eb:


    d "失礼ですが…あなたは私のタイプではありません。これ以上は言わないことにします。"


translate japanese e3s2_c3e5e858_1:


    cha "えっ？"


translate japanese e3s2_4e34c614:


    d "ホットチョコレートをありがとう..."


translate japanese e3s2_ddc779e8:


    cha "ええと、わかりました。"


translate japanese e3s2_e9f5a102:


    cha "なんて奇妙な男の子なんだ..."

translate japanese strings:


    old "Yes, of course.[TEMP1!t]"
    new "はい、もちろん。"


    old "I'd rather not...[TEMP2!t]"
    new "私はむしろそうではない...[TEMP2!t]"


    old "Okay, I'll stop in.[TEMP1!t]"
    new "わかった、ここで止まるよ。[TEMP1!t]"


    old "Uh... no, thanks![TEMP2!t]"
    new "あ... いいえ、ありがとう！[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
