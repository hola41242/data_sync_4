


translate japanese coming2_2c7a6b72:


    mad "お父さん… なんで彼に会いたいの？"


translate japanese coming2_315b4afb:


    mad "..."


translate japanese coming2_9f07be60:


    mad "私は..."


translate japanese coming2_aee41bbd:


    ji "ママ..."


translate japanese coming2_7a16ee9c:


    grace "今夜、あなたが唯一欲しい人です..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
