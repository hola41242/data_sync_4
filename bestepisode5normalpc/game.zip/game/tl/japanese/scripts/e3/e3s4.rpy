


translate japanese e3s4_43b49e4c:


    d "わかりました。"


translate japanese e3s4_2764ca10:


    d "私は家に帰ったらルビーにメッセージを送ると約束した。"


translate japanese e3s4_9f40912c:


    d "" with hpunch


translate japanese e3s4_6eb69ed4:


    d "別のメッセージ？"


translate japanese e3s4_db4f6715:


    d "返事がない..."


translate japanese e3s4_fb7cad08:


    d "ついに…少し休むことができる。明日は普通の日ではない気がする。"


translate japanese e3s4_cecbb726:


    dpense "驚きが訪れるのを待とう。結局のところ、真の冒険は予想外の中にある。"

translate japanese strings:


    old "Minus... you awake?"
    new "リューク... 起きてる？"


    old "Of course! I was worried about you!"
    new "もちろん！あなたのことが心配だった！"


    old "You're so sweet!"
    new "あなたはとても優しい！"


    old "You think so?"
    new "そう思いますか？"


    old "Absolutely! I couldn't ask for a better friend!"
    new "絶対に！これより良い友達は望めない！"


    old "I know I'm the B.E.S.T !"
    new "私は最高だと知っています！"


    old "Ahah! For sure! So... I'm back in my room."
    new "あはは！確かに！さて…部屋に戻りました。"


    old "Great! I'm relieved!"
    new "よかった！私は安心しています！"


    old "Good night, my acolyte!"
    new "おやすみ、私の相棒！"


    old "Sweet dreams, my partner!"
    new "甘い夢を、私のパートナー！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
