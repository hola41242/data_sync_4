


translate japanese e3intro_0be561b1:


    ruby "ふんっ"


translate japanese e3intro_95eb778b:


    ruby "何を着るか本当にわからない。グレースのパーティーがあるし..."


translate japanese e3intro_35c89622:


    ruby "[name]との映画の夜…"


translate japanese e3intro_fc09bfd6:


    ruby "全力を尽くさなければならない。"


translate japanese e3intro_7156630f:


    ruby "もう少しセクシーな服を着るべきかな…"


translate japanese e3intro_b924fffa:


    ruby "それとも上品ですか？"


translate japanese e3intro_7fcb6cfe:


    ruby "あなたたちのことはどうですか？"


translate japanese e3intro_18748a7f:


    ruby "どう思いますか？"


translate japanese e3intro_d2eebdc0:


    ruby "何か..."


translate japanese e3intro_902e1a01:


    ruby "ちょっとサイバー？"


translate japanese e3intro_c4cb47c6:


    ruby "それとももっとエレガントなもの？"


translate japanese e3intro_41ca40a0:


    ruby "ああ…新しいドレスを買いに行かなきゃ！"


translate japanese e3intro_d0053bde:


    ruby "[name]が一緒に来るのはどうかな？"


translate japanese e3intro_79bde7bc:


    ruby "彼が私を選ぶのを手伝ってくれたら本当にうれしい。"


translate japanese e3intro_6d6299b3:


    ruby "彼は寝ていると思う。"




translate japanese e3intro_2d24ae24:


    ruby ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
