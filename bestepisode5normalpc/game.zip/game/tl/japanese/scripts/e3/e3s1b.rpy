


translate japanese e3s1b_3e99e6fe:


    d "他の人たちに追いつくために、もっと努力しなければならない。"


translate japanese e3s1b_e0b40846:


    d "成長する必要がある。"


translate japanese e3s1b_02909704:


    d "次の試合はもっと挑戦的になるでしょう。"


translate japanese e3s1b_4d6de57e:


    d "全力を尽くして、すべてを出し切らなければならない。"


translate japanese e3s1b_a2c0471f:


    ji "悪くない。"


translate japanese e3s1b_19e694e7:


    ji "檻の中にいた方が良かった。"


translate japanese e3s1b_675025bd:


    ji "足元の動きにもっと取り組む必要があります。"


translate japanese e3s1b_85a51d50:


    d "え？？？"


translate japanese e3s1b_ca5c561e:


    gaby "あなたの足の動き。足を動かす方法。"


translate japanese e3s1b_0bafbbe5:


    gaby "シュートするときは前足をしっかりと地面に植え、できるだけ前傾姿勢をとってボールに全ての力を移せるようにしましょう。"


translate japanese e3s1b_4539f447:


    d "すべての力を移す？"


translate japanese e3s1b_8fa50577:


    gaby "はい。後ろに体重をかけると、ボールが上に飛びます。前に体重をかけると、ボールがすべての力を受け取り、より多くのスピンをかけることができます。"


translate japanese e3s1b_be887b2f:


    d "ああ、それは知りませんでした。"


translate japanese e3s1b_54134b7b:


    gaby "どうぞ、試してみて！"


translate japanese e3s1b_1523fe20:


    d "..."


translate japanese e3s1b_fef6c142:


    d "ボールにうまく当たっていないようだ。"


translate japanese e3s1b_2ce8734d:


    gaby "あなたはそれを手に入れるでしょう。"


translate japanese e3s1b_01d6fdfd:


    d "どうしてそんなことを知っているのですか？"


translate japanese e3s1b_5939427c:


    gaby "私はコーチなんだ、知ってる？そして、私がたくさんプレイしていた時期もあったんだ…。"


translate japanese e3s1b_7441657c:


    gaby "その時、私は若かった。"


translate japanese e3s1b_192e17bc:


    d "あなたはまだ若いですけど。"


translate japanese e3s1b_e93a360f:


    gaby "まあ、私はそうだと思う。ただ、もう昔とは同じじゃない。"


translate japanese e3s1b_f22eeffc:


    gaby "前とは違う体を持っています。"


translate japanese e3s1b_17d5107e:


    gaby "時の流れ、そう言いますね..."


translate japanese e3s1b_8c82d0dd:


    d "もしよろしければ、自分を過小評価していると思います。"


translate japanese e3s1b_80e32e55:


    d "あなたは本当に美しい。時間もあなたの魅力に驚いて通り過ぎることができないでしょう。"


translate japanese e3s1b_5b7cd72d:


    d "どんな男も、あなたのような美しい女性を見逃すなんて狂っているでしょう。"


translate japanese e3s1b_525161b0:


    d "ごめんなさい、何も言わなければよかったです。"


translate japanese e3s1b_5ec68acb:


    gaby "私は、自分の生徒の一人からそんなことを期待していなかったと認めざるを得ません..."


translate japanese e3s1b_8bddce5e:


    gaby "それはとても嬉しいお言葉ですが、コーチに言うのはあまり適切ではないと思います。"


translate japanese e3s1b_024817af:


    gaby "あなたと同じ気持ちを皆が持ってくれたらいいのに。"


translate japanese e3s1b_ac0eb531:


    d "あなたをお世辞のつもりではなかった。ただ、私の考えを伝えているだけだ。"


translate japanese e3s1b_718af70d:


    gaby "それなら、自分の中に留めておいてください。誰かがあなたが先生にそんなことを言っているのを聞いたら、問題になるかもしれません。私たちのどちらもそんなことは望んでいないでしょう？"


translate japanese e3s1b_2c6e3916:


    d "あなたは以前はもっと健康的だったの？！この前水着であなたの姿を見かけたけど、本当に素晴らしい体をしているわね！"


translate japanese e3s1b_070198d1:


    gaby "何を話しているのですか？"


translate japanese e3s1b_cdbfaf2a:


    d "本当に！あなたは魅力的です！どう表現すればいいかわからない。"


translate japanese e3s1b_c7644af0:


    d "もし私があなたの男だという幸運を得たら、世界に知らせたい！そして、信じてください、私はあなたのその素晴らしい体を評価し、探求するチャンスを逃したりはしません。"


translate japanese e3s1b_db0ae612:


    gaby "この会話はあまり適切ではないと思います、ミスター [name]。"


translate japanese e3s1b_40493fb5:


    d "それが真実ではないとはわかっていますが、それが真実です！つまり、あなたを見てください！鏡を見て、絶対的な美しさが見えないなら、あなたは盲目です！以前に何があったのか、あなたがこう思う理由はわかりません。"


translate japanese e3s1b_7f87e2f2:


    d "でも、それはばかげています！"


translate japanese e3s1b_2071d2fd:


    d "過去にいくつかの馬鹿があなたを酷使したとしても、忘れなければなりません。自信を持って前へ進んでください、あなたは明らかに考えるには美しすぎるからです！"


translate japanese e3s1b_ca335262:


    gaby "うーん… 行くべきだと思う。"


translate japanese e3s1b_b02ad822:


    gaby "さて、トレーニングに戻りなさい。あなたは正しい道を歩んでいます。"


translate japanese e3s1b_d3c7b6ea:


    d "全力を尽くします。"


translate japanese e3s1b_4d2be1f1:


    d "試合に向けての最後のアドバイスはありますか？"


translate japanese e3s1b_31a27688:


    gaby "おお？うーん... バーで遊ぶ。"


translate japanese e3s1b_0db8c8d0:


    d "バー？"


translate japanese e3s1b_21784a96:


    gaby "じゃあね、若者。"


translate japanese e3s1b_bcf01860:


    d "ああ、うん... またね。"


translate japanese e3s1b_7c9441d9:


    d "彼女がバーで遊んでいるとはどういう意味ですか？"


translate japanese e3s1b_a132824f:


    d "まず、私の体をもっと前に持ってきてください..."


translate japanese e3s1b_2ad9be58:


    gaby "彼はかなり大胆だけど、その子は正しい。"


translate japanese e3s1b_154f3cbd:


    gaby "こんな風に考えるのをやめなければならない..."


translate japanese e3s1b_ea375fba:


    gaby "それでも、誰かがそんなふうに私に話しかけてくれたのは久しぶりです。"


translate japanese e3s1b_3ea324e1:


    gaby "頑張れ、ガビー。しっかりして。彼はただの学生..."

translate japanese strings:


    old "Education[TEMP1!t]"
    new "教育"


    old "Temperament[TEMP2!t]"
    new "気質[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
