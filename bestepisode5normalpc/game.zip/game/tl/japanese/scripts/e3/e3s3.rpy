


translate japanese e3s3_12ad8469:


    julia "さて、ここに来ました。これが私の場所です！"


translate japanese e3s3_0edccaa4:


    d "いいね！"


translate japanese e3s3_3700f2d6:


    julia "ああ、特別なものではないけど、私に必要なものは全部揃っていて、手頃な価格だ。"


translate japanese e3s3_6a1c010e:


    julia "しかし、あなたが気づいたかもしれませんが、一番豪華な地域にはありません..."


translate japanese e3s3_bf939523:


    d "まだ近所をよく知らないけれど、そうだね、通った小道は少し怪しかった。"


translate japanese e3s3_9ced4376:


    julia "まあ、毎日シフトの後にそこを通っていると思ってください！"


translate japanese e3s3_74e3136e:


    d "それはあまり安全じゃないように見える..."


translate japanese e3s3_6fa84a8a:


    d "どうして仕事があることを教えてくれなかったの？"


translate japanese e3s3_56073172:


    julia "他の人たちとは違って、私の財政状況はあまり良くないと言っておきましょう。"


translate japanese e3s3_a15dd700:


    julia "私はアカデミーでの勉強を続けることができる奨学金を持っています。"


translate japanese e3s3_df4731e9:


    julia "家賃と... それに対処しなければならない他の問題の間で、私はすべての費用を支払うために働かなくてはなりません。"


translate japanese e3s3_d5e1b526:


    julia "私はマディソンや双子たちのようではない。私には支えてくれる両親がいない。"


translate japanese e3s3_682e4e49:


    d "あなたの両親はどこですか？"


translate japanese e3s3_93efd31f:


    julia "えっと… 父がどこにいるかわからない。彼に会ったことは一度もない。"


translate japanese e3s3_9d3ce74c:


    julia "そして、私の母はとても病気です。"


translate japanese e3s3_cd177145:


    julia "彼女は骨癌で、あまり時間が残されていません…"


translate japanese e3s3_ad0f2283:


    d "申し訳ありません、お詫び申し上げます。"


translate japanese e3s3_e3457991:


    julia "彼女は本当に保険がないので、私は彼女のケアのためにお金を手伝わなければなりません。"


translate japanese e3s3_6ec795c1:


    d "それはあなたの肩に乗るには多すぎる。"


translate japanese e3s3_2c8ea51b:


    julia "はい、それが私が少し自分を守っている理由です。すべてのことに追われていて、十分な問題を抱えています。"


translate japanese e3s3_040c5935:


    julia "他の人が些細なことで不満を言っているのを聞くと…"


translate japanese e3s3_2bc4c54e:


    julia "マディソンが理由もなく私に怒鳴るとき、冷静さを保つのが難しいと認めざるを得ません。"


translate japanese e3s3_f9fbb463:


    d "わかりました。"


translate japanese e3s3_eb7a265c:


    julia "でも、それが私の生きることを妨げることはできないし..."


translate japanese e3s3_bccda825:


    julia "痛い！"


translate japanese e3s3_2baafa95:


    d "何が問題ですか？"


translate japanese e3s3_d8f13f9a:


    julia "背中の痛みがまだかなりひどい！転んだときに本当にやってしまったに違いない。"


translate japanese e3s3_b99a2b3b:


    d "待って、ベッドに横になって。"


translate japanese e3s3_101332d7:


    julia "え？"


translate japanese e3s3_7ae3d8a2:


    d "マッサージをしてあげる。助けになるよ。"


translate japanese e3s3_f1e67029:


    julia "それをする方法を知っていますか？"


translate japanese e3s3_9976359d:


    d "うん、スポーツセラピーのコースを受けたから、痛みを和らげることを約束するよ。"


translate japanese e3s3_b217ed72:


    julia "うーん、いいよ、試してみよう..."


translate japanese e3s3_641e6172:


    d "横たわる。"


translate japanese e3s3_a5c86f5a:


    julia "わかった。"


translate japanese e3s3_0551ca4c:


    d "正直に言って... その姿勢は死体のように見える!"


translate japanese e3s3_3d5f9e28:


    julia "" with hpunch


translate japanese e3s3_50424d17:


    julia "それは本当に痛いんです！"


translate japanese e3s3_77e66e95:


    d "あぁ、ごめんね。これをさせて、終わったら気分が良くなるから、分かるよね。"


translate japanese e3s3_89966ef2:


    julia "そう願っています…"


translate japanese e3s3_ab68d771:


    d "あなたは本当に緊張していますね！"


translate japanese e3s3_733bbbb6:


    julia "誰かを自分のベッドに寝かせることにはあまり慣れていない..."


translate japanese e3s3_29a8225a:


    julia "座っている方が気が楽だと思う。"


translate japanese e3s3_04a6c5de:


    d "好きなことをして。私はただあなたにリラックスしてほしい。"


translate japanese e3s3_9d672ec7:


    julia "これの方がずっと良い。"


translate japanese e3s3_2cbde8fa:


    d "そう言うなら。"


translate japanese e3s3_8dcc9644:


    julia "少し下..."


translate japanese e3s3_d6f16a8e:


    julia "うん..."


translate japanese e3s3_de861bdc:


    julia "その通り"


translate japanese e3s3_690aeb67:


    d "それを脱ぐと、もっと楽になるよ。"


translate japanese e3s3_69ad8ab5:


    julia "ああ... それは納得できます。"


translate japanese e3s3_aea36d69:


    d "心配しないで。筋肉をほぐしてリラックスするように頑張って。"


translate japanese e3s3_dc0f59ff:


    julia "やってみるよ。"


translate japanese e3s3_f790c5fe:


    julia "ああ、それは気持ちいい…"


translate japanese e3s3_61e25695:


    d "私は言った。"


translate japanese e3s3_2b836df5:


    d "リラックスして。"


translate japanese e3s3_561cd9b9:


    julia "あ、はい、そこに…。"


translate japanese e3s3_d1923521:


    julia "少し下... そこ..."


translate japanese e3s3_8eea2814:


    julia "それは完璧です。"


translate japanese e3s3_10487543:


    d "さらに続けますか？"


translate japanese e3s3_53c79c86:


    julia "私は飛行機であなたが私の下半身を十分にマッサージしたと思います。"


translate japanese e3s3_7875d62f:


    d "ああ...ごめんなさい。私の方が行き過ぎました。"


translate japanese e3s3_f479b588:


    julia "でも、ありがとう。"


translate japanese e3s3_3a32d93a:


    julia "私は...知らない。"


translate japanese e3s3_e6a490a3:


    julia "ああ、それは本当に気持ちいい..."


translate japanese e3s3_a3222942:


    d "あなたは、美しい体を持っていますね。"


translate japanese e3s3_9cb2fb4a:


    julia "あ、ありがとう？"


translate japanese e3s3_cb6df9e9:


    d "あなたは美しいカーブを持つ筋肉質で、肌は柔らかいです。"


translate japanese e3s3_5e76aabf:


    julia "ああ…"


translate japanese e3s3_93d6639c:


    d "あなたの世話をさせて、ジュリア。"


translate japanese e3s3_ebeb14c7:


    julia "うーん..."


translate japanese e3s3_990aa0aa:


    d "私に信頼してほしい、あなたが頼れる誰かになりたい。"


translate japanese e3s3_d11ffcb2:


    d "本当のジュリアを見つけさせて。咲くのを待っている花。"


translate japanese e3s3_28d95fb6:


    julia "ああ..."


translate japanese e3s3_5242d378:


    d "必要な時は、私はここにいるよ。"


translate japanese e3s3_5698db07:


    julia "私は..."


translate japanese e3s3_6584bc6c:


    julia "あ！"


translate japanese finjuliaep2_b8dc5ea9:


    julia "ありがとう。今夜はこれで十分だと思う。すでに気分がずっと良くなった。"


translate japanese finjuliaep2_486de3ba:


    d "私の専門的な手が必要なときは、遠慮なく言ってください！"


translate japanese finjuliaep2_23dd4e9a:


    julia "はい、ありがとう。本当に。"


translate japanese finjuliaep2_36ff4f70:


    d "じゃあ、行ってくるね。まだ家に戻らなきゃいけないし、ルビーに戻ったらメッセージを送るって約束したんだ。心配させたくないからね！"


translate japanese finjuliaep2_c2b6bb98:


    julia "ああ、そう！彼女があなたからの連絡を受けるまで眠らないことは確実です。"


translate japanese finjuliaep2_4ce986cd:


    julia "彼女は、自分が大切に思っている人々に対してそうです。"


translate japanese finjuliaep2_0a780817:


    d "それでは急いで家に帰るべきだ。"


translate japanese finjuliaep2_95fa21dd:


    julia "はい、そうです。"


translate japanese finjuliaep2_841b0d8a:


    d "明日会いましょう、ジュリア。"


translate japanese finjuliaep2_79f08374:


    julia "また明日... [name]."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
