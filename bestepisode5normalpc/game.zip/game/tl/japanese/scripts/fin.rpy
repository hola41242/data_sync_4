


translate japanese fin_254dd07d:


    grace "ねえ、あなた！これまでのゲームはどうだった？"


translate japanese fin_df49880d:


    grace "もしそうなら、これはただの始まりですから、これからの刺激的で広がりのある物語に備えてください。"


translate japanese fingrace_64116e44:


    grace "このゲームを選んでいただきありがとうございます。私たちと一緒に楽しい時間を過ごせたことを願っています。"


translate japanese fingrace_b7de489c:


    ji "気を付けて [name]..."


translate japanese fingrace_2c7a6b72:


    mad "お父さん... どうして彼に会いたいの？"


translate japanese fingrace_315b4afb:


    mad "..."


translate japanese fingrace_9f07be60:


    mad "私は…"


translate japanese fingrace_7a29416a:


    ji "今夜大学のパーティーに行くの？"


translate japanese fingrace_aee41bbd:


    ji "お母さん..."


translate japanese fingrace_d681a17c:


    ruby "ドレスを探さなければならない..."


translate japanese fingrace_3d8592ac:


    ruby "そして私たちの劇場の夜のためにもう一つ！"


translate japanese fingrace_7a16ee9c:


    grace "今夜はあなただけが欲しい…"


translate japanese fingrace_d13211cd:


    julia "こんにちは！このアップデートの最後に到達したようですね！気に入っていただけたら嬉しいです！"


translate japanese fingrace_38aab629:


    julia "更新がリリースされると、クリエイターたちはそれを異なるウェブサイトに追加します..."


translate japanese fingrace_b9df2fb5:


    cr "はい、これが全てどう機能するのか理解したときにそうします..."


translate japanese fingrace_7c77b00a:


    julia "もしゲームや少女、あるいはクリエイターたちが好きなら、ぜひあなたのサポートを示してみてください！"


translate japanese fingrace_f803f865:


    julia "ゲームで見たいもの、好きなこと、好きなキャラクターについて彼らに伝えてください..."


translate japanese fingrace_241336b2:


    julia "お金を寄付することで支援を示すと、クリエイターたちは私に服を買ってくれることができ、私は本当に服が大好きです！！！"


translate japanese fingrace_4a83dbf2:


    cr "マセラティや召使いが欲しくないの？"


translate japanese fingrace_c2ddfb8d:


    julia "まあ、もしあなたが提供するなら... 冗談です！彼らは新しいハードウェアを購入して、制作プロセスを加速させることもできます... お金が多いほど、コンテンツも増えます..."


translate japanese fingrace_d1f2e7be:


    cr "そうですね... 一つのレンダリングやアニメーションには時間がかかりますし、私たちにはNASAのような作業用ステーションはありません..."


translate japanese fingrace_8556d080:


    julia "それについて考えてみてください！"


translate japanese fingrace_47f68eca:


    julia "もうこれ以上あなたを引き留めるつもりはありません..."


translate japanese fingrace_28c14350:


    julia "新しいアップデートがリリースされたら、戻ってきてくれることを本当に願っています！"


translate japanese fingrace_5c8aa31e:


    julia "またね！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
