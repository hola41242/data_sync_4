


translate japanese aeroport_f4a872b8:


    dpense "ああ、新鮮な空気...。新しい国、新しい文化、新しい人々...。"


translate japanese aeroport_b07237c8:


    dpense "私は最後の一人です...。みんなはもういません...。"


translate japanese aeroport_808acf6d:


    dpense "アメリカへようこそ！"


translate japanese aeroport_555b6725:


    "僕がいない間、彼女の面倒を見てくれと頼んだだけなんだ！"


translate japanese aeroport_e4ca3e2d:


    mad "彼女がおしゃぶりに苦労しているのに気づいていないと言うのですか？？？"


translate japanese aeroport_b983271d:


    mad "私の愚かな兄弟、私の話を聞いて！数分でそちらに行くから...彼女を落ち着かせておいて..."


translate japanese aeroport_196a6471:


    d "タクシー ！" with hpunch


translate japanese aeroport_60fb3963:


    mad "それは私のもの！"


translate japanese aeroport_80be1ed7:


    d "そうは思いません。"


translate japanese aeroport_ed1ba37f:


    mad "ああ、そうだ、これは私のものだ！"


translate japanese aeroport_33058132:


    mad "私は、私のチームメイトを触ったようなあなたのような変態が、私の前にこのタクシーを取ることを許すと思っているのですか！"


translate japanese aeroport_f0452d08:


    d "彼女は何を言ったの？"


translate japanese aeroport_25e103b1:


    mad "あなたに構っている暇はないわ。私は行くから、別の子を見つけてよ！"


translate japanese aeroport_6723e0fa:


    dpense "彼女にそんな風にタクシーを奪わせるつもりはない！"


translate japanese aeroport_dc7b7945:


    d "私も行くわ！運転手さん、アカデミーまで運んで！"


translate japanese aeroport_40bc89bc:


    mad "これは冗談ですか？ 本当に私と一緒に乗るつもりですか？"


translate japanese aeroport_1bf3f63c:


    d "私は思っているのではなく、知っているのです。あなたを知らないし、あなたを恐れていないので、今すぐあなたの態度をやめるか、このタクシーから降りてください！ それとも、私たちはこのタクシーを共有して、すぐに終わります。"


translate japanese aeroport_de3c83e7:


    mad "おぉ..."


translate japanese aeroport_b63493c8:


    d "私たちは一緒に乗っているんだ！あなたにお願いしているわけじゃない！"


translate japanese aeroport_fd8e2ede:


    mad "紳士ですね..."


translate japanese aeroport_64483950:


    "これが最後のものですか、ドリューさん？"


translate japanese aeroport_4352eddb:


    drew "はい、オルシさん。フランスから来た男だ。リクエスト通りです。"


translate japanese aeroport_7116406b:


    orushi "それは完璧です、ドリュー夫人！ 彼はすでに私が見る限り、虎の爪にかかっています。"


translate japanese aeroport_7844bdbe:


    orushi "他の人たちはどうですか？"


translate japanese aeroport_6e3b1b13:


    drew "彼らは家に帰ったり、夜のキャンパスに戻ったりしています。 あなたのリクエスト通りに、彼らの荷物は保管されています。"


translate japanese aeroport_d5ab5b44:


    orushi "ついに、100人の競技者が揃った。"


translate japanese aeroport_41d0c460:


    orushi "明日、B.E.S.Tゲームがオープンします！"


translate japanese aeroport_5ddfbed5:


    orushi "ルーファスさんのことを聞いていますか？"


translate japanese aeroport_533d812c:


    "RrrrrrrrrrrrrrrrrrRRRrrrrr..."


translate japanese aeroport_14d7b0f5:


    orushi "ショーを始めよう！"


translate japanese aeroport_897eabbe:


    mad "いいか...いい人形になって、別のタクシーを呼んでこい。"


translate japanese aeroport_c27801fc:


    d "でも...私はそれを呼んだ！"


translate japanese aeroport_159a23f2:


    mad "でも... 私はそれを！"


translate japanese aeroport_b8b1a077:


    d "そして..."


translate japanese aeroport_f4b1a052:


    dpense "このような場合、どうすればいいのでしょうか？"


translate japanese aeroport_e19a32cd:


    d "ちょっと聞いて、タクシーを呼んだんだけど、あなたが大変な時期で急いでいるのが見えるから、乗り合いにしない？"


translate japanese aeroport_92c1c803:


    mad "何？"


translate japanese aeroport_e9d9321a:


    d "乗るのを... 分け合おう..."


translate japanese aeroport_f351df9d:


    mad "私は共有しない..."


translate japanese aeroport_ed92ac6c:


    d "私の乗り物代を払う必要があるので、待ちたくないから、私も払うよ。"


translate japanese aeroport_21823f25:


    mad "まあ、そうですね...ありがとう。"


translate japanese aeroport_fe0cba53:


    d "今はリラックスして、深呼吸をしてください。そんなふうに誰かを怒鳴ってはいけません…"


translate japanese aeroport_64483950_1:


    "これが最後のドリュー夫人ですか？"


translate japanese aeroport_4352eddb_1:


    drew "はい、オルシさん。フランスから来た男だ。リクエスト通りです。"


translate japanese aeroport_7116406b_1:


    orushi "それは完璧です、ドリュー夫人！ 彼はすでに私が見る限り、虎の爪にかかっています。"


translate japanese aeroport_7844bdbe_1:


    orushi "他の人たちはどうですか？"


translate japanese aeroport_6e3b1b13_1:


    drew "彼らは家に帰ったり、夜のキャンパスに戻ったりしています。 あなたのリクエスト通りに、彼らの荷物は保管されています。"


translate japanese aeroport_d5ab5b44_1:


    orushi "ついに、100人の競技者が揃った。"


translate japanese aeroport_41d0c460_1:


    orushi "明日、B.E.S.Tゲームがオープンします！"


translate japanese aeroport_bb4cf1c0:


    orushi "ルーファスさん、これを聞きましたか？"


translate japanese aeroport_533d812c_1:


    "RrrrrrrrrrrrrrrrrrRRRrrrrr..."


translate japanese aeroport_14d7b0f5_1:


    orushi "ショーを始めよう！"

translate japanese strings:


    old "A NEW LIFE...."
    new "新しい人生...."


    old "Rrrrrrrrrrrrrrrrr..."
    new "Rrrrrrrrrrrrrrrrr..."


    old "You've found a RUFUS !"
    new "ルーファスを見つけました！"




translate japanese aeroport_5398bcd5:


    dpense ""


translate japanese aeroport_e9a0d30e:


    dpense ""


translate japanese aeroport_211e98a9:


    dpense ""


translate japanese aeroport_5179d2f2:


    ""


translate japanese aeroport_709901dd:


    mad ""


translate japanese aeroport_43b0627a:


    mad ""


translate japanese aeroport_249cf055:


    mad ""


translate japanese aeroport_83e05748:


    mad ""


translate japanese aeroport_77d696c7:


    mad ""


translate japanese aeroport_d34bda64:


    d ""


translate japanese aeroport_899e50ff:


    mad ""


translate japanese aeroport_d2ce5a28:


    mad ""


translate japanese aeroport_3c3457a8:


    d ""


translate japanese aeroport_f51580c2:


    d ""


translate japanese aeroport_fa152289:


    ""


translate japanese aeroport_79ea6de1:


    orushi ""


translate japanese aeroport_331801eb:


    orushi ""


translate japanese aeroport_adddebb1:


    orushi ""


translate japanese aeroport_103b7468:


    orushi ""


translate japanese aeroport_c13cf216:


    orushi ""


translate japanese aeroport_4e324a7e:


    mad ""


translate japanese aeroport_a5b917da:


    d ""


translate japanese aeroport_984881d1:


    mad ""


translate japanese aeroport_d6920383:


    d ""


translate japanese aeroport_ce157163:


    dpense ""


translate japanese aeroport_dc68927a:


    mad ""


translate japanese aeroport_895c541d:


    d ""


translate japanese aeroport_997010f1:


    mad ""


translate japanese aeroport_e03560e5:


    mad ""


translate japanese aeroport_36596b81:


    d ""


translate japanese aeroport_b1d8ddd1:


    ""


translate japanese aeroport_f29d7abc:


    drew ""


translate japanese aeroport_e4a116f7:


    orushi ""


translate japanese aeroport_7711cc3b:


    orushi ""


translate japanese aeroport_adddebb1_1:


    orushi ""


translate japanese aeroport_29f32552:


    orushi ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
