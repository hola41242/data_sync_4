


translate japanese avion_0e0160fd:


    ji "こんにちは？"


translate japanese avion_e95421cf:


    d "こんにちは"


translate japanese avion_59864c14:


    ji "お手伝いしましょうか？"


translate japanese avion_e9697244:


    d "ああ....うーん... いいえ...ごめんなさい...！"


translate japanese avion_59c8bef9:


    d "ここに座ってもいいですか？"


translate japanese avion_929cf346:


    ji "はい、もちろん！取られていませんよ；座ってリラックスしてください。長旅ですから。"


translate japanese avion_dd2965bd:


    ji "私はここに座って息を整え、窓の近くにいるだけです..."


translate japanese avion_b0802ea2:


    d "息を整えて？"


translate japanese avion_d59574f1:


    ji "うん、大学のクラスでは女の子たちのパーティーがあるけど、ちょっと...うるさいんだ！"


translate japanese avion_da42aa4a:


    d "うーん...わかった..."


translate japanese avion_ebbadba5:


    "このゲームでは選択が重要で、主人公には4つの属性があります：B.E.S.T"


translate japanese avion_862ea8b3:


    "BUDDYはMCの態度に関するもので、他のキャラクターとの関係に影響を与えます。"


translate japanese avion_8c05e44e:


    "EDUCATIONは主人公の一般的な知識に関するもので、テストやダイアログに影響を与えます。"


translate japanese avion_c2327bd8:


    "SPORTは主人公の運動能力に関するもので、ゲーム内の特定の目標を達成するために必要です。"


translate japanese avion_0daa0f65:


    "TEMPERAMENTはMCの行動に関するものであり、ゲームで最高の結果を得るためには不可欠です。"


translate japanese avion_37fd5c70:


    "いくつかの選択肢はアップグレードにつながります..."


translate japanese avion_e248561e:


    "必要な最低条件を満たさない場合、いくつかの選択肢は利用できなくなります。"


translate japanese matte_d3e6cc48:


    "ここではあなたの気質が向上しました。"


translate japanese matte_3b3626f9:


    "ステータスウィンドウを見ると、気質が+1になっているのがわかります。"


translate japanese matte_55fa1820:


    "もしあなたがある選択をすると、異なるステータスに影響を与えます。"


translate japanese matte_91b5e938:


    "さあ、物語に戻ろう..."


translate japanese matte_20b35922:


    ji "何かお手伝いできることはありますか？"


translate japanese matte_ccaf5fec:


    d "あ！ええと....いいえ、いいえ、ありがとう....ごめんなさい、あなたを見ている間に考え事にふけっていました..."


translate japanese matte_6c7fff83:


    ji "私のことを見ていましたか？"


translate japanese matte_875b38d8:


    d "ごめんなさい、そんなつもりじゃなかった..."


translate japanese matte_886e6305:


    ji "アハハ… そんな心配しなくても、あんな目で私を見た変態はあなたが初めてじゃないから！"


translate japanese matte_bff3ad4b:


    d "私は変態ではありません..."


translate japanese matte_7ebe0117:


    d "ねえ、でももし、そしてそれは大きな「もし」だけど、私が君を見ていたとしたら、実際にそうだったわけではないけど、私を責めることができる？結局、私はただの人間だから。"


translate japanese matte_ce684cf0:


    d "私は[name]... 英語が上手じゃなくてごめんなさい、でも私はフランス人で、アメリカに行って改善しようと思っています。"


translate japanese matte_cf80a00d:


    ji "ああ、そうなの？つまり、私があなたの目に魅力的ではないと言っているのですか？"


translate japanese matte_ab7b2ae1:


    julia "ところで、私はジュリアです、変態さん。"


translate japanese matte_a03052c8:


    d "ああ、まだ一緒じゃないのにもうあだ名があるの？でも、このあだ名はあまり好きじゃないかも。"


translate japanese matte_eb29e630:


    julia "まだですか？私たちは自信がないのですか。"


translate japanese matte_7667148e:


    d "私は試してみる！こんなジェット機で女の子は何をするの？"


translate japanese matte_cb69a6fa:


    julia "ああ、君は知らないの？最初、このジェットは私たちのためだけだったんだ..."


translate japanese matte_919e3327:


    julia "しかし、会社は予算の節約を試みています..."


translate japanese matte_a8f70784:


    julia "それでは、私たちは予算が少ない学生や家族とこの飛行機を共有しなければなりません..."


translate japanese matte_f31d507b:


    julia "私には問題ありませんが、他の人たちは私ほどフレンドリーではありません..."


translate japanese matte_5d546338:


    d "あなたたちは何人いるのですか？"


translate japanese matte_af7767aa:


    julia "ガブリエラを私たちのガイドとして数えるなら、私たちは...."


translate japanese matte_acc2b90e:


    "前方のキャビンから大きな音が聞こえる..."


translate japanese matte_ff6594cd:


    ji "そして、これらの奴らが何をしようとしたか知ってる？？？"


translate japanese matte_7c8a480f:


    d "彼らは誰ですか... ???"


translate japanese matte_a3b6f8a2:


    julia "それは私の女の子たちだ... 彼女たちが何をしているのか見たい... じゃね、変態！"


translate japanese matte_ce392a47:


    d "私は変態じゃない！"


translate japanese matte_15487c24:


    julia "失礼します..."


translate japanese grope_4f934acb:


    dpense "私はなぜかわからないけど、触れなければならない...."


translate japanese grope_38cf1df9:


    dpense "悪いって分かってるけど..."


translate japanese grope_6cb9f1a5:


    dpense "私はできない..."


translate japanese grope_93427ddd:


    julia "ああ、そうだ！！！"


translate japanese grope_3783fa80:


    julia "変態..."


translate japanese grope_f505e264:


    dpense "彼女が私を殴った！信じられない！"


translate japanese timide_66e6c047:


    "ここであなたの教育が向上しました"


translate japanese timide_67d96a22:


    "スタットウィンドウを見ると、教育が+1になったのがわかります。"


translate japanese timide_55fa1820:


    "一方の選択をすると、異なるステータスが影響を受けます。"


translate japanese timide_91b5e938:


    "物語に戻りましょう..."


translate japanese timide_f0da4fbd:


    dpense "彼女は自信があるように見える... 彼女に少し圧倒されている。もっと自信を持つ必要がある。さらに、彼女はアメリカ人だから... それもある..."


translate japanese timide_b9ae6907:


    dpense "もしかして… こんにちは！私はフランス出身です！あなたは？"


translate japanese timide_1d396d27:


    dpense "いいえ、それは良い方法ではありません。こんにちは、私の名前は[name]です。あなたの名前は何ですか？"


translate japanese timide_ef598f94:


    dpense "多分、少し堅苦しいですね。こんにちは、私の名前はブライアンです。ブライアンはどこですか？ブライアンは台所にいます。"


translate japanese timide_375e8c32:


    dpense "自分の名前を言って彼女の名前を聞くべきか、それともファーストクラスのパーティーについて尋ねるべきか？"


translate japanese timide_298d44ce:


    dpense "そうだね、うまくいくと思うし、少なくともそれが良いアイスブレーカーになるから、そこから進めることができるよ。"


translate japanese timide_2c3c8e7d:


    d "そう... あなたは..."


translate japanese timide_ff6594cd:


    ji "そして、これらの奴らが何をしようとしたか知ってる？？？"


translate japanese timide_3157f6c5:


    d "誰が…？？？"


translate japanese timide_7618e110:


    julia "それが私の女の子たち..."


translate japanese timide_83ccf072:


    julia "すみません..."


translate japanese timide_bba6d66a:


    julia "ごめん、彼らが何をしているか見てくるね！バイ！"


translate japanese timide_320c3073:


    d "さようなら..."


translate japanese timide_6689b535:


    d "彼女の名前がわからない…"


translate japanese steven_cec17e94:


    dpense "彼女はかわいかった..."


translate japanese steven_37e64b70:


    dpense "..."


translate japanese steven_6f1ae60c:


    "お前はクソったれだ！"


translate japanese steven_172f6531:


    "ヘイ、男、お前は運のいいクソ野郎だな！"


translate japanese suitesteven_5c0e76f8:


    d "何？"


translate japanese suitesteven_9c017fbf:


    "ここにいる、そしてあなたはすでに大学で最も人気のある女の子の一人と話したんだ。"


translate japanese suitesteven_928c2998:


    d "人気？どうやって？"


translate japanese suitesteven_a44e5c43:


    "知らないの？君がとてもかっこいいと思ってたのに… 飛行機に乗ってジュリア、チームの最高のミドルプレイヤーに会った男。"


translate japanese suitesteven_76324af9:


    d "私 ..."


translate japanese suitesteven_0fc22f54:


    "お前は何も知らない、ジョン・スノウ..."


translate japanese suitesteven_263cb021:


    d "私は..."


translate japanese suitesteven_29c04876:


    "ゲーム・オブ・スローンズの男！頼む、知らないのか？！ダエネリス・ターガリエン、ジェイミー、近親相姦..."


translate japanese suitesteven_d161cfe2:


    d "ゲーム・オブ・スローンズが何かは知っています..."


translate japanese suitesteven_7ddaf8de:


    "まあ、それは良かったですね！私はルビーですが、あなたは？"


translate japanese suitesteven_adba3d07:


    d "[name]..."


translate japanese suitesteven_486ce07e:


    ruby "ああ、好きだな、ちょっと可愛い... 何人かの人のように子供をクリトリンって呼ぶ人とは違うよね、そうでしょ？"


translate japanese suitesteven_cbdaca76:


    ruby "何人かの人々は、子供のために奇妙な名前をつけるけれど、あなたの名前はそうじゃない！あなたの名前は好きだよ！ごめん、話が長くなってしまったね。それで、どこに行くの？"


translate japanese suitesteven_c1ff616e:


    d "明日は大学の初日だから…"


translate japanese suitesteven_aa318b6f:


    ruby "本当に？私もだ！聞いて！中に入る前に会いましょう…そこに着いたとき、一緒にいてくれる人が本当に必要だよ！"


translate japanese suitesteven_f1cac575:


    d "なぜ？"


translate japanese suitesteven_46acb989:


    ruby "ジャングルだ！さあ、暗闇で勝利と名声のために戦う準備をした爪を持った女の子たちが至る所に待っているぞ！"


translate japanese suitesteven_7cb8c249:


    ruby "そして、有名になることが何をもたらすか知っていますか？"


translate japanese suitesteven_263cb021_1:


    d "私は…"


translate japanese suitesteven_051f879a:


    ruby "知ってる…知ってるよ！名声は女の子を意味する！成功すれば、君は選ばれし者になる！足元に女の子を想像してみて！そして、もっと名声があれば？？？"


translate japanese suitesteven_3a792386:


    d "もっと女の子？"


translate japanese suitesteven_6d15a124:


    ruby "あなたは賢いですね？私はあなたのパートナーになります！いいえ…私はあなたのキューピッドになります！私はライトで、君はリュークだ、いい？それじゃあ、この世界を征服する準備はできてるか？"


translate japanese suitesteven_9c57e89e:


    ruby "まだだよ、リューク... それを直すよ！ さて、君と話せてとても楽しかったけど、いくつか用事があるんだ... 他の女の子たちが私のアドバイスを待っているから... また明日会おう..."


translate japanese suitesteven_b95efa92:


    d "私は…"


translate japanese suitesteven_9064b9b7:


    ruby "アリーナに入る前に私を待っていて！！！"


translate japanese suitesteven_1523fe20:


    d "..."


translate japanese suitesteven_9fd6da5c:


    dpense "彼女のようにみんなクレイジーなの？"


translate japanese suitesteven_1523fe20_1:


    d "..."


translate japanese suitesteven_86c73062:


    d "疲れた..."


translate japanese suitesteven_dbdac134:


    "これは我々の小さなジュリアが田舎者のところから帰ってきたのですか？"


translate japanese suitesteven_ab6debc8:


    "彼女は男と話していた... あなたについて何か考えを持っていないことを願っている..."


translate japanese suitesteven_9610c720:


    julia "ああ、この変態が私の前を通り過ぎるときに私を触ってきた！"


translate japanese suitesteven_0773b254:


    "" with hpunch


translate japanese suitesteven_cf866db8:


    "さあジュリア、ついに誰かが一口を手に入れた！貞操帯をつけて、修道院に戻ってくることができるよ…"


translate japanese suitesteven_8b314319:


    julia "ハハ、とても面白いね、マディソン！もちろん、僕の体に対して君のように自由ではないし…人生の選択肢においてもね！"


translate japanese suitesteven_d8a71b92:


    mad "あなたは何を意味していますか？？？"


translate japanese suitesteven_58956991:


    julia "何もない、誰もがあなたが確かに美徳の女王であることを知っている... ただあなたの彼氏に聞くだけでいい..."


translate japanese suitesteven_534b4206:


    julia "ああ、私たちはできない…彼はあなたを子供の世話をするために残して消えた！良い選択だね、マディソン！"


translate japanese suitesteven_1f27d426:


    mad "私の子供について話さないで！あなたの喉に私の拳を突っ込むつもりだから、その後、私がどれだけ素晴らしい女王であるかを学ぶことになるでしょう..."


translate japanese suitesteven_0951d6fb:


    "女の子、女の子、女の子... 今すぐ止まって！"


translate japanese suitesteven_686615df:


    mad "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese suitesteven_99a38228:


    mad "" with vpunch


translate japanese suitesteven_7c3b1f00:


    ruby "マディ... 落ち着いて！"


translate japanese suitesteven_0207512d:


    julia "あなたが言うように、いわゆるレッドネックたちは、マディソンのそばにいるよりもずっと優しいです…。"


translate japanese suitesteven_4a92e9bb:


    mad "うん、もちろん… そして、もしあなたがもっと口を開けば、彼らがどれほど素敵かを見せる準備ができている…"


translate japanese suitesteven_06ebd413:


    julia "あなたは気持ち悪い..."


translate japanese suitesteven_0944faa3:


    mad "おい、ジュリア、僕にいい子ぶるのはやめて、貞操帯をつけないでよ！"


translate japanese suitesteven_9be940f7:


    julia "はは、面白いねマディソン！確かに僕の体は君ほど自由じゃないし…人生の選択肢もね！"


translate japanese suitesteven_d8a71b92_1:


    mad "何を意味していますか？？？"


translate japanese suitesteven_b2377a6e:


    julia "何もない、誰もがあなたが確かに美徳の女王であることを知っている... ただあなたの彼氏に尋ねるだけでいい..."


translate japanese suitesteven_6834550e:


    julia "ああ、私たちはできない...彼はあなたを子供と一緒に残して姿を消した！良い選択だ、マディソン！"


translate japanese suitesteven_956f0d4b:


    mad "私の子供について話さないで！あなたの喉に拳を突っ込むつもりです。そうすれば、私がどれほど徳のある人間かわかるでしょう..."


translate japanese suitesteven_0951d6fb_1:


    "女の子、女の子、女の子... すぐにやめて！"


translate japanese suitesteven_686615df_1:


    mad "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese suitesteven_99a38228_1:


    mad "" with vpunch


translate japanese suitesteven_7c3b1f00_1:


    ruby "マディ... 落ち着いて！"


translate japanese filles_36dfd72e:


    grace "さあ、みんな、私たちはこのフライトで8時間過ごすことになるから、仲良くする努力をしましょう。"


translate japanese filles_5dafe21b:


    ruby "マディソンに話しかけてみるよ、彼女は朝からずっと緊張していて、理由がわからないんだ。"


translate japanese filles_f0a26782:


    grace "ごめんね、ルビー。その間にジュリアと話しておくよ。"


translate japanese filles_6bd44eb9:


    grace "ジュリア…彼女の小さな心理戦に惑わされないで、彼女がどういう人か知ってるでしょう！"


translate japanese filles_73643294:


    julia "彼女はとても下品で、非常に不快だ…。"


translate japanese filles_a5b7a657:


    grace "彼女のコメントには反応しないで、すべてうまくいくよ... 幼稚園から彼女のことを知ってる。"


translate japanese filles_481de8d6:


    grace "彼女がたくさんのことを乗り越えてきたのは知っている... そして私たちはここでチームなんだ、女の子たち！"


translate japanese filles_6cb619bc:


    grace "昨日ヨーロッパでのエキシビジョンゲームに勝ったばかりなのに、今日は一緒に祝うのではなく敵のように振る舞っている！"


translate japanese filles_963cc653:


    julia "知ってるよ、キャプテン！でも彼女は私に対してこの力を持っているんだ…彼女は私のツボを押すことができるし、私はすぐにカッとなる！"


translate japanese filles_97d18b70:


    julia "冷静を保っているのは、チームのため、皆のためです。君たち全員が私にとってとても大切だからです…"


translate japanese filles_43472939:


    grace "その態度を維持してくれれば、私たちは良い感じだ..."


translate japanese filles_35bcedfb:


    grace "まあ、シャンパンを飲むことにするよ... フランスにいた時にあのボトルを買わなかったわけじゃないから... 試さなきゃ！"


translate japanese filles_fb3145c4:


    julia "ではまた後で..."


translate japanese dream_b8e5bfe6:


    julia "それが私をどう想像しているの？"


translate japanese dream_7b19b0bd:


    julia "少しがっかりしています..."


translate japanese dream_67c1772c:


    julia "もっと期待していたのに..."


translate japanese dream_ef072154:


    julia "私が先導しなければならない..."


translate japanese dream_0234bf95:


    julia "触れたいと思っていることは知っています..."


translate japanese dream_16bce50e:


    julia "もうすぐこれらすべてを楽しむことができる..."


translate japanese dream_e7985afa:


    julia "しかしまずは..."


translate japanese dream_18805abb:


    julia "" with hpunch


translate japanese dream_ef072154_1:


    julia "私が事を進める必要がある..."


translate japanese dream_0234bf95_1:


    julia "あなたが触れたいと思っているのは知っています…"


translate japanese dream_16bce50e_1:


    julia "もうすぐ、これらすべてを楽しむことができるようになります..."


translate japanese dream_e7985afa_1:


    julia "でもまずは..."


translate japanese dream_18805abb_1:


    julia "" with hpunch


translate japanese suiteavion_5c0e76f8:


    d "何？"


translate japanese suiteavion_54f6be08:


    ji "起きて！"


translate japanese suiteavion_960aeedf:


    d "" with vpunch


translate japanese suiteavion_926f9119:


    ruby "" with vpunch


translate japanese suiteavion_35678e56:


    d "あなたは私を驚かせました！！！"


translate japanese suiteavion_fd67742c:


    ruby "あなたは狂っているの？怖がらせたのはあなたです！"


translate japanese suiteavion_1523fe20:


    d "..."


translate japanese suiteavion_e83ddfad:


    ruby "着陸した！さあ、コルテックス、行く時間だ！"


translate japanese suiteavion_a75ec2bd:


    ruby "忘れないで！明日の朝、入口で待ってて！私たちは世界を征服する！それとも、今のところ大学で十分かもしれない…考えておくよ…"

translate japanese strings:


    old "Look at her [TEMP1!t]"
    new "彼女を見てください [TEMP1!t]"


    old "Stay quiet [TEMP2!t]"
    new "静かにしていてください [TEMP2!t]"


    old "Grope her [TEMP1!t]"
    new "彼女を触る [TEMP1!t]"


    old "I'm not a pervert ! [TEMP2!t]"
    new "私は変態ではありません！ [TEMP2!t]"


    old "YOUR TEMPERAMENT HAS INCREASED"
    new "あなたの気性が高まりました。"


    old "YOUR EDUCATION HAS INCREASED"
    new "あなたの教育が向上しました。"


    old "MEANWHILE"
    new "その間に"


    old "HOURS LATER"
    new "数時間後"


    old "Yes sure ! [TEMP1!t]"
    new "はい、もちろん！ [TEMP1!t]"


    old "I don't need you, thanks ! [TEMP2!t]"
    new "私はあなたを必要としません、ありがとう！[TEMP2!t]"


    old "YOUR BUDDY HAS INCREASED"
    new "お友達が増えました。"




translate japanese avion_a77ac93c:


    ji ""


translate japanese avion_6a17aa40:


    d ""


translate japanese avion_8adf166c:


    ji ""


translate japanese avion_098df146:


    d ""


translate japanese avion_28d35901:


    d ""


translate japanese avion_ce4cc110:


    ji ""


translate japanese avion_2e54462d:


    ji ""


translate japanese avion_b1b5a06e:


    d ""


translate japanese avion_394fe6c3:


    ji ""


translate japanese avion_7c12217f:


    ""


translate japanese avion_6e67c913:


    ""


translate japanese avion_fe1c61dc:


    ""


translate japanese avion_71bf6ca1:


    ""


translate japanese avion_5aef870f:


    ""


translate japanese avion_fd4e33a9:


    ""


translate japanese matte_50d78a9e:


    ""


translate japanese matte_c2ff206b:


    ""


translate japanese matte_a204a91e:


    ""


translate japanese matte_04c22d84:


    d ""


translate japanese matte_161819b3:


    ji ""


translate japanese matte_33290fa1:


    ji ""


translate japanese matte_109f239c:


    d ""


translate japanese matte_64dae949:


    d ""


translate japanese matte_974197f5:


    ji ""


translate japanese matte_521b9be8:


    d ""


translate japanese matte_f6d9c954:


    julia ""


translate japanese matte_ef64d92c:


    d ""


translate japanese matte_e14ee53b:


    julia ""


translate japanese matte_b482344d:


    julia ""


translate japanese matte_1c3b9124:


    julia ""


translate japanese matte_76905a7b:


    julia ""


translate japanese matte_71c63e4f:


    d ""


translate japanese matte_00032fb4:


    julia ""


translate japanese matte_76aa842e:


    ""


translate japanese matte_70a4593d:


    ji ""


translate japanese matte_3ddcfdcb:


    d ""


translate japanese matte_a1cea24a:


    julia ""


translate japanese matte_be32e64a:


    d ""


translate japanese matte_83ccf072:


    julia ""


translate japanese grope_f3ad0544:


    dpense ""


translate japanese grope_4069971b:


    dpense ""


translate japanese grope_25b49ff5:


    julia ""


translate japanese grope_e5740a5c:


    dpense ""


translate japanese timide_b27c8e81:


    ""


translate japanese timide_a204a91e:


    ""


translate japanese timide_b6723f7d:


    dpense ""


translate japanese timide_b7e759f8:


    dpense ""


translate japanese timide_8212f678:


    dpense ""


translate japanese timide_961931c2:


    dpense ""


translate japanese timide_ca382aeb:


    dpense ""


translate japanese timide_806583b6:


    dpense ""


translate japanese timide_e7cb9db9:


    d ""


translate japanese timide_70a4593d:


    ji ""


translate japanese timide_6ed3c163:


    d ""


translate japanese timide_adcda054:


    julia ""


translate japanese timide_0a12bd65:


    julia ""


translate japanese timide_7fe1a0a3:


    d ""


translate japanese timide_98834053:


    d ""


translate japanese steven_f0a46d58:


    dpense ""


translate japanese steven_2b5cc8ea:


    ""


translate japanese steven_79c7d4f9:


    ""


translate japanese suitesteven_29ac5843:


    d ""


translate japanese suitesteven_c74818a4:


    ""


translate japanese suitesteven_445516a0:


    d ""


translate japanese suitesteven_2e214d17:


    ""


translate japanese suitesteven_a818720e:


    ""


translate japanese suitesteven_12f41864:


    d ""


translate japanese suitesteven_14baaefe:


    ""


translate japanese suitesteven_e8068e8a:


    d ""


translate japanese suitesteven_b61caa41:


    ""


translate japanese suitesteven_1604c1be:


    d ""


translate japanese suitesteven_e1f07e97:


    ruby ""


translate japanese suitesteven_30c66acb:


    ruby ""


translate japanese suitesteven_8d82ba13:


    d ""


translate japanese suitesteven_94f6ab85:


    ruby ""


translate japanese suitesteven_e3b20b7b:


    d ""


translate japanese suitesteven_e93176d9:


    ruby ""


translate japanese suitesteven_b4c5be94:


    ruby ""


translate japanese suitesteven_c6f1becc:


    ruby ""


translate japanese suitesteven_07bd820b:


    d ""


translate japanese suitesteven_60fa4a54:


    ruby ""


translate japanese suitesteven_1e83bfb6:


    ruby ""


translate japanese suitesteven_b95efa92_1:


    d ""


translate japanese suitesteven_b53beaf3:


    ruby ""


translate japanese suitesteven_dbdea2d2:


    dpense ""


translate japanese suitesteven_1f5828f4:


    d ""


translate japanese suitesteven_c0b26c1f:


    ""


translate japanese suitesteven_ece3d305:


    ""


translate japanese suitesteven_1781b603:


    julia ""


translate japanese suitesteven_d5c9de16:


    "" with hpunch


translate japanese suitesteven_dad3e066:


    ""


translate japanese suitesteven_ec0ad1d8:


    julia ""


translate japanese suitesteven_060f387e:


    mad ""


translate japanese suitesteven_b9a169a9:


    julia ""


translate japanese suitesteven_c6e5105b:


    julia ""


translate japanese suitesteven_018ba193:


    mad ""


translate japanese suitesteven_b468c864:


    ""


translate japanese suitesteven_80adbe6d:


    mad ""


translate japanese suitesteven_6e1984a1:


    mad "" with vpunch


translate japanese suitesteven_da1598b9:


    ruby ""


translate japanese suitesteven_903e5d8e:


    julia ""


translate japanese suitesteven_a1560e5c:


    mad ""


translate japanese suitesteven_b3c31478:


    mad ""


translate japanese suitesteven_ec0ad1d8_1:


    julia ""


translate japanese suitesteven_060f387e_1:


    mad ""


translate japanese suitesteven_b9a169a9_1:


    julia ""


translate japanese suitesteven_c6e5105b_1:


    julia ""


translate japanese suitesteven_018ba193_1:


    mad ""


translate japanese suitesteven_b468c864_1:


    ""


translate japanese suitesteven_80adbe6d_1:


    mad ""


translate japanese suitesteven_6e1984a1_1:


    mad "" with vpunch


translate japanese suitesteven_da1598b9_1:


    ruby ""


translate japanese filles_1d7d4d72:


    grace ""


translate japanese filles_c1b1f90f:


    grace ""


translate japanese filles_9af21f39:


    grace ""


translate japanese filles_f4d64a4a:


    julia ""


translate japanese filles_2022fcdc:


    grace ""


translate japanese filles_9328fe6e:


    grace ""


translate japanese filles_da9df0ba:


    grace ""


translate japanese filles_6f2a6535:


    julia ""


translate japanese filles_6b09a32f:


    julia ""


translate japanese filles_5f52d6a5:


    grace ""


translate japanese filles_1e3fbdab:


    grace ""


translate japanese filles_239ecae8:


    julia ""


translate japanese dream_7853e24a:


    julia ""


translate japanese dream_374d0074:


    julia ""


translate japanese dream_bc9425a5:


    julia ""


translate japanese dream_f4bdb854:


    julia ""


translate japanese dream_19554152:


    julia "" with hpunch


translate japanese dream_374d0074_1:


    julia ""


translate japanese dream_bc9425a5_1:


    julia ""


translate japanese dream_f4bdb854_1:


    julia ""


translate japanese dream_19554152_1:


    julia "" with hpunch


translate japanese suiteavion_29ac5843:


    d ""


translate japanese suiteavion_332c64eb:


    ji ""


translate japanese suiteavion_d98b07ec:


    d ""


translate japanese suiteavion_58043dd2:


    ruby ""


translate japanese suiteavion_82a4a47b:


    ruby ""


translate japanese suiteavion_22f7922c:


    ruby ""

translate japanese strings:


    old "I'm not a pervert! [TEMP2!t]"
    new ""


    old "Yeah, sure! [TEMP1!t]"
    new ""


    old "I don't need your help, thanks anyways! [TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
