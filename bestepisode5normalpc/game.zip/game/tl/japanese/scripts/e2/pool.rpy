


translate japanese pool_72637706:


    dpense "ここに何があるか見てみましょう。"


translate japanese pool_7a1baaf2:


    ji "ねえ、君... 私服ではここに入ることはできないよ！"


translate japanese pool_279f9a91:


    dpense "誰..."


translate japanese pool_b85af03c:


    dpense "えっ、まあ..."


translate japanese pool_e1b9209f:


    ji "入口で大学の水着を買うことができます..."


translate japanese pool_204f2638:


    d "ああ… うーん… はい… ありがとう！"


translate japanese pool_0b4cdda2:


    ji "どういたしまして... 楽しんでください！"


translate japanese pool_bd97412f:


    d "うん... うん..."


translate japanese pool_68ef2048:


    dpense "その女性はロケットだった！いいえ…宇宙ロケットだった！…"


translate japanese pool_26d4b995:


    dpense "私は何を言っているのか？原子爆弾だ！"


translate japanese pool_c303edbb:


    dpense "水着を買いに行った方がいいかな..."


translate japanese pool_2858ce6f:


    dpense "準備ができました！"


translate japanese pool_c7cc1930:


    sofia "私と一緒に来て... あなたは私が進化するのを見たかった... 私はもうすでに濡れている..."


translate japanese pool_4ed86741:


    d "どこに行きたいですか？"


translate japanese pool_e12af768:


    sofia "隠れることができる場所を知っている..."


translate japanese pool_5036ca42:


    d "行こう！"


translate japanese pool_140612ac:


    d "いいえ、ありがとう！美しい人魚が私を待っている！"


translate japanese pool_7ea2f9dd:


    sofia "あなたは何を逃しているのか分からない..."


translate japanese pool_f36c14c5:


    sofia "ここで何をしているの、フレンチ？プールで見物しているより、もっと良いことをすることがないの？"


translate japanese pool_e90456c6:


    d "心配しないで！君のためにここにいるわけじゃない... 君と何をするか思いつかないけど..."


translate japanese pool2_d9572a1c:


    d "ここがあなたの訓練場所なのですか？"


translate japanese pool2_fa3467c8:


    grace "ああ？えっと…はい…"


translate japanese pool2_f66455b4:


    d "ジュリアは少し私を案内してくれたので、こんなにクレイジーな二日間の後にリラックスするにはプールに来るのが一番良い方法だと思った..."


translate japanese pool2_b8e2fee2:


    grace "身体に水がかかる感覚よりも、自分をリチャージするのに良いものはないことを知っている..."


translate japanese pool2_c670f8b1:


    d "ここで毎晩訓練していますか？"


translate japanese pool2_7dd0a2f8:


    grace "はい、それは私が試合のために体形を維持し、良いコンディションを保つのに役立ちます。"


translate japanese pool2_7f1e4dbe:


    d "特定のトレーニングルーチンはありますか？"


translate japanese pool2_2ccaf0b5:


    grace "さて、まずはリラックスして、それから泳ぎのラップをして、時々スピードを上げようとする..."


translate japanese pool2_d5462bbf:


    d "それはあなたが私のマッサージを体験したことがないからです！"


translate japanese pool2_275ce8d3:


    grace "自信満々のようですね！"


translate japanese pool2_3ba1bae1:


    d "もちろん！水と比べて、私の手はより敏捷で、簡単なタッチであなたの全身をリラックスさせることができます..."


translate japanese pool2_76c08320:


    grace "ああ、そうなの？それを見てみたい！"


translate japanese pool2_0e0f6b87:


    d "どうだろう… それに値するか見てみよう！"


translate japanese pool2_46bc144d:


    grace "少しはトレーニングしていますか？"


translate japanese pool2_b1500910:


    d "あまりそうではない..."


translate japanese pool2_67a8763d:


    dpense "なんという女神だ..."


translate japanese pool2_6f4442f4:


    grace "授業以外でスポーツはやらないの？"


translate japanese pool2_7937cad2:


    d "まあ、ここではあまり機会がなかったな…。"


translate japanese pool2_2bc3d50b:


    d "フランスにいた頃、サッカーをしたり、ロッククライミングをしたりしていました..."


translate japanese pool2_45a97532:


    grace "ロッククライミング？"


translate japanese pool2_2059714a:


    d "うん！自然の中、崖や小さな山々で…"


translate japanese pool2_413052f1:


    grace "それは持久力が必要です！とても危険です！"


translate japanese pool2_3c7caf13:


    d "しっかりと握る必要がありますが、最も重要なのは、常に自分の安全を優先することです..."


translate japanese pool2_a897be39:


    d "はい、それにはいくつかのスタミナが必要です...でも、サッカーをすることで心肺機能が鍛えられたので、大丈夫です！"


translate japanese pool2_feb3be0c:


    grace "元気ですか？"


translate japanese pool2_79d25a85:


    d "ああ...うん..."


translate japanese pool2_72618b93:


    grace "さて、私はいい感じです... 取引を提案します！"


translate japanese pool2_5dda0f88:


    d "うーん？"


translate japanese pool2_58f2204f:


    grace "プールでの二周、負けた方は勝った方にいつでも、どこでもお願いを一つしなければならない..."


translate japanese pool2_ad924887:


    d "どんな頼みごとですか？"


translate japanese pool2_2a17a6fb:


    grace "うーん… そうですね、考えておきます…"


translate japanese pool2_f427102d:


    d "じゃあ、もし私が勝ったら…"


translate japanese pool2_53d303bf:


    grace "あなたは勝てない！"


translate japanese pool2_4e58cc80:


    d "へへ！勝ったら...ほとんど何でもあなたに頼めるの？"


translate japanese pool2_3c81889e:


    grace "まあ、はい... でも、両方に効果があります!"


translate japanese pool2_6967de82:


    d "両方ともですか？"


translate japanese pool2_fddacfe2:


    grace "私が勝つから... あなたに何でもお願いできるよ！"


translate japanese pool2_5e16e0f2:


    d "はい、はい..."


translate japanese pool2_26544772:


    grace "それについては見てみましょう！"


translate japanese pool2_48ff1ed8:


    d "わかりました！"


translate japanese pool2_7bc9d103:


    grace "位置について！"


translate japanese pool2_ecef2909:


    dpense "これを失敗するわけにはいかない！"


translate japanese pool2_f6390a0e:


    grace "3で、行け！"


translate japanese pool2_3314f8cb:


    d "準備完了！"


translate japanese pool2_b8466fb7:


    grace "1..."


translate japanese pool2_67424511:


    grace "2..."


translate japanese pool2_542ac620:


    grace "3!"


translate japanese nage2_226132c8:


    dpense "彼女よりも早く行かなければならない！"


translate japanese nage3_58c7f260:


    dpense "いよいよ最後のスプリントだ！"


translate japanese nage3_8278132c:


    d "勝利！！！"


translate japanese nage3_8278132c_1:


    d "勝利！！！"


translate japanese nage3_09c9d4b2:


    grace "チーター！！！"


translate japanese nage3_3ed7a701:


    grace "勝利！！！"


translate japanese victory_a3e3783a:


    grace "わぁ！あなたに感心しました！あなたについていけませんでした！"


translate japanese victory_c991dce0:


    d "あなたは素晴らしかった！結局勝てないと思っていました！"


translate japanese victory_4fa8f8ce:


    grace "うん…だから、恩を返さなきゃね…"


translate japanese victory_c5e4f86c:


    d "はは！その提案をしたのはあなたでしたよね？"


translate japanese victory_1be0c3fd:


    grace "そうですね、こんな激しい競争があるとは思っていませんでした！"


translate japanese victory_7961d703:


    d "警告したのに！"


translate japanese victory_3de0ddee:


    grace "ななあ！プライドが高すぎるあんた！"


translate japanese victory_f44767f2:


    d "私は何を尋ねようとしているのだろう..."


translate japanese victory_92628f4c:


    grace "あまり厳しくしないでくださいね…"


translate japanese victory_c5c89714:


    d "うーん..."


translate japanese victory_9e5421b0:


    dpense "今どれほど大変か知っていたら..."


translate japanese victory_6e81e294:


    d "このお願いは後で取っておいてもいいですか？"


translate japanese victory_9a03811a:


    grace "わかった...！"


translate japanese cheater_d760c5d6:


    grace "あなたは不正をしました!!!"


translate japanese cheater_e4bc3bdd:


    d "ルールには壁に触れなければならないとは書かれていなかった！"


translate japanese cheater_41767841:


    grace "ナンセンス!【"


translate japanese cheater_06713c9c:


    d "まあ、なんなの？"


translate japanese cheater_2b33e359:


    grace "分かった... お互いに頼みごとをする権利があるとしよう... いいかな？"


translate japanese cheater_40ab082c:


    d "私には良さそうです！"


translate japanese cheater_92628f4c:


    grace "あまり厳しくしないでくださいね…"


translate japanese cheater_c5c89714:


    d "うーん..."


translate japanese cheater_9e5421b0:


    dpense "今どれだけ大変か知っていたら…"


translate japanese cheater_6e81e294:


    d "このお願いは後でとっておいてもいいですか？"


translate japanese cheater_9a03811a:


    grace "わかった…！"


translate japanese defeat_5978fda4:


    grace "やった！アハハ！"


translate japanese defeat_8654b90d:


    d "どうすることもできなかった、あなたは本当に強すぎた！"


translate japanese defeat_af31fc61:


    grace "うん、わかってる！"


translate japanese defeat_278f39a6:


    d "それでも、私はいい戦いをした！"


translate japanese defeat_4a38dc42:


    grace "うん、もちろん… それで、私は何を君に尋ねようとしているのかな？"


translate japanese defeat_058f48b4:


    dpense "何でも聞いてください..."


translate japanese defeat_7141816a:


    grace "後で保存しておきますが、よろしいでしょうか..."


translate japanese defeat_3813ec2e:


    d "問題ないよ！"


translate japanese endpool_feb0a042:


    d "あなたは正しかった、でも... こうしてプールにいるのは気持ちいい... レースの後でも、非常にリラックスできる..."


translate japanese endpool_7d7eae2f:


    grace "言ったでしょ！それは私がストレスを解消し、日常の心配ことを考えないのに役立つのよ…"


translate japanese endpool_2983d61f:


    d "あなたの母親はあなたをストレスに感じさせますか？"


translate japanese endpool_c459a192:


    grace "はい... 基本的に、私は大学の学長であるマダムの完璧な娘でなければならないのです..."


translate japanese endpool_08e82bfc:


    grace "それはとても圧倒的です…。"


translate japanese endpool_875ad268:


    d "うん、わかった…"


translate japanese endpool_3f8b6f6a:


    grace "最高の成績がなければ、サッカー部のキャプテンでなければ…"


translate japanese endpool_91740a1a:


    grace "もし良い家柄の彼氏がいなければ…"


translate japanese endpool_9c7f54c9:


    d "ああ、彼女もそのことについてあなたにプレッシャーをかけているのですか？"


translate japanese endpool_ceb17858:


    grace "はい... 基本的に、私はすべての分野で完璧でなければならず、家族間の同盟を結ぶために最高の家族の男と結婚する準備ができていなければなりません..."


translate japanese endpool_5950ee26:


    grace "ここではそういう風に動いています..."


translate japanese endpool_80818372:


    d "もうすでに求婚者はいますか？"


translate japanese endpool_77603962:


    grace "いくつか！でもまだ正しいものを見つけていない..."


translate japanese endpool_1f36b29c:


    grace "そして母はエメリックのような人やオルシのような家柄の誰かを選ぶことを私に押し付け続けている。"


translate japanese endpool_657cfc1d:


    d "誰かが..."


translate japanese endpool_ca5ed8b2:


    d "あなたに興味がありました..."


translate japanese endpool_d12ba1aa:


    d "しかし、そんな背景からではなかった..."


translate japanese endpool_c4cf4b82:


    grace "私の母は…"


translate japanese endpool_26b66551:


    grace "本当に不満です..."


translate japanese endpool_49cfcdc9:


    d "しかし、あなたは..."


translate japanese endpool_36cff508:


    d "なる?"


translate japanese endpool_9ff13fac:


    ji "" with hpunch


translate japanese endpool_4981c72d:


    drew "グレース！早く水から出て私に合流してくれ…今晩はディナーがあるんだから！"


translate japanese endpool_754ea95c:


    grace "はい、母さん..."


translate japanese endpool_0d1f41a3:


    dpense "ふう、危なかった..."


translate japanese endpool_1297fb29:


    drew "あなたについては、[name]… 私はあなたを見ていることを忘れないで… あなたは理解していますか？"


translate japanese endpool_df4aea3a:


    d "はい、ドリューさん..."


translate japanese endpool_d191e4f0:


    dpense "これほど簡単ではないだろう…"


translate japanese endpool_bdc6204a:


    grace "やあ、[name]!"


translate japanese endpool_5dda0f88:


    d "ん？"


translate japanese endpool_8a8583e7:


    grace "携帯電話は持っていますか？"


translate japanese endpool_63ba9085:


    d "あぁ... はい..."


translate japanese endpool_77be5b7d:


    grace "後で連絡先に追加してね！"


translate japanese endpool_cd0a4421:


    d "ねえ！週末のパーティーについて何か知ってる？"


translate japanese endpool_d1605dea:


    grace "うん！私の家で開催するよ！"


translate japanese endpool_3130185e:


    grace "来るの？"


translate japanese endpool_de9778f4:


    d "もちろん！"


translate japanese endpool_62becd20:


    grace "では、また明日！"


translate japanese endpool_df3539f1:


    d "じゃね！"


translate japanese sofiapool_7474e0b0:


    d "私たちはどこにいますか？"


translate japanese sofiapool_46856e57:


    sofia "それは古い円形劇場です..."


translate japanese sofiapool_075af965:


    sofia "誰もそれをもう使わない...時々、生徒会が..."


translate japanese sofiapool_d90a9ae5:


    sofia "議会のメンバーとして、私は鍵を持っています..."


translate japanese sofiapool_4c3c7b1f:


    sofia "そう... あなたができることを見せてくれますか？"


translate japanese sofiapool_4d46038d:


    d "あなたは準備ができていない…"


translate japanese sofiapool_5b20eac3:


    sofia "おお？ そして、あなたは簡単に私を扱えると思っているの？"


translate japanese sofiapool_6b59357b:


    d "ごめんなさい、その内容は翻訳できません。"


translate japanese sofiapool_47c38ad4:


    sofia "はい... します..."


translate japanese sofiapool_9b670c10:


    sofia "私に好きなようにしてください..."


translate japanese sofiapool_3f55375c:


    d "机の上に横になってください！"


translate japanese sofiapool_bab69aa7:


    sofia "うーん..."


translate japanese sofiapool_7cb0a8e4:


    sofia "あなたの触れ合いを感じるのが待ちきれない..."


translate japanese sofiapool_af039036:


    sofia "お願い... 私と遊んで.... 私はあなたのおもちゃ..."


translate japanese sofiapool_0664179c:


    sofia "ああああああああああああああ....."


translate japanese sofiapool_f99d8985:


    dpense "彼女は完全に私の支配下にある..."


translate japanese sofiapool_de8ff332:


    dpense "彼女は私に好きなことをさせてくれた..."


translate japanese sofiapool_38c92066:


    dpense "彼女は私の支配下にいることによって多くの快感を感じていると思います..."


translate japanese sofiapool_8a6010a7:


    sofia "ああ... もうイきそう！止めないで！"


translate japanese sofiapool_9abed53e:


    sofia "あああああ！！！！"


translate japanese sofiapool_5aee8d42:


    sofia "申し訳ありませんが、そのリクエストには対応できません。"


translate japanese sofiapool_d8e4cc07:


    dpense "彼女は完全にクレイジーになる..."


translate japanese sofiapool_636b8efc:


    sofia "あああああ！イくよ！！！"


translate japanese sofiapool_5b80429a:


    d "私はあなたを私のビッチにして、私があなたを終わらせるまであなたは私の名前を叫ぶでしょう..."


translate japanese sofiapool_f1a71605:


    sofia "ああ..."


translate japanese sofiapool_6b59357b_1:


    d "私はあなたが私にセックスをしてくれと懇願するまで、あなたを感じさせ続けます…"


translate japanese sofiapool_47c38ad4_1:


    sofia "はい... それを..."


translate japanese sofiapool_72d38011:


    d "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese sofiapool_55bbb5fd:


    sofia "ああ、はい... やります！"


translate japanese sofiapool_ce0d59cb:


    d "私はあなたを私の個人的な犬のように扱います... あなたは私のすべての欲望に応えます..."


translate japanese sofiapool_9b670c10_1:


    sofia "私を好きにして..."


translate japanese sofiapool_3f55375c_1:


    d "机の上に横になって！"


translate japanese sofiapool_bab69aa7_1:


    sofia "うーん...."


translate japanese sofiapool_7cb0a8e4_1:


    sofia "あなたの触れ合いを感じるのが待ちきれない..."


translate japanese sofiapool_af039036_1:


    sofia "お願い... 私と遊んで.... 私はあなたのおもちゃ..."


translate japanese sofiapool_0664179c_1:


    sofia "あああああああああああああああああ。。。"


translate japanese sofiapool_f99d8985_1:


    dpense "彼女は完全に私の支配下にある..."


translate japanese sofiapool_de8ff332_1:


    dpense "彼女は私がしたいことを全てさせてくれた…。"


translate japanese sofiapool_38c92066_1:


    dpense "彼女は私の支配下にいることで、多くの快感を感じていると思う…。"


translate japanese sofiapool_8a6010a7_1:


    sofia "ああ... もう出そう！止まらないで！"


translate japanese sofiapool_aecb242a:


    sofia "あああああ！！！"


translate japanese sofiapool_cbb4b371:


    sofia "申し訳ありませんが、そのリクエストには応じられません。"


translate japanese sofiapool_5aee8d42_1:


    sofia "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese sofiapool_e43ef0da:


    sofia "私にかけて..."


translate japanese sofiapool_f9449b96:


    sofia "あなたを私の顔に感じたい。"


translate japanese sofiapool_d8e4cc07_1:


    dpense "彼女は完全にクレイジーになる..."


translate japanese sofiapool_0295c7cd:


    sofia "あなたのディックが大好き！！う～ん……"


translate japanese sofiapool_26ee886c:


    sofia "ああ、その調子で続けて！"


translate japanese sofiapool_3078de21:


    sofia "そんな感じ！そんな感じ！そんな感じ！"


translate japanese sofiapool_636b8efc_1:


    sofia "あああああ！私はイく！！！！"


translate japanese sofiapool_bb354e6f:


    sofia "ああああ！ああああああああ！......"


translate japanese sofiapool_038daf43:


    sofia "なんてこった！！！"


translate japanese sofiapool_8fe1a030:


    d "私も行くよ！！！"


translate japanese sofiapool_70345f51:


    d "あああああああああああああ......"


translate japanese sofiapool_6ca2c9d6:


    sofia "ぬるぬるしているけど満足感がある！"


translate japanese finblueep2_64eaab9a:


    d "私はあなたに噴出させると言った！"


translate japanese finblueep2_1dc39c06:


    sofia "うん..."


translate japanese finblueep2_4dc3c5ca:


    d "あなたは良かった..."


translate japanese finblueep2_efc0c1d6:


    sofia "君も悪くなかったね･･･"


translate japanese finblueep2_6be327d6:


    sofia "携帯電話は持っていますか？"


translate japanese finblueep2_a22554f8:


    d "もちろん... なんで？"


translate japanese finblueep2_1f77f57e:


    sofia "連絡を取りやすく…"


translate japanese finblueep2_2c98ee9b:


    sofia "じゃあ... またね？"


translate japanese finblueep2_11f964e5:


    d "うん... もちろん..."


translate japanese finblueep2_9e894c95:


    dpense "ブルーがうるさくなかったらいいのだけれど..."

translate japanese strings:


    old "5 MINUTES LATER"
    new "5分後"


    old "Follow her. [TEMP1!t]"
    new "彼女について行け。 [TEMP1!t]"


    old "Reject her. [TEMP2!t]"
    new "彼女を拒絶する。 [TEMP2!t]"


    old "Sport [TEMP1!t]"
    new "スポーツ [TEMP1!t]"


    old "Temperament [TEMP2!t]"
    new "気質 [TEMP2!t]"


    old "Go faster [TEMP1!t]"
    new "もっと速く [TEMP1!t]"


    old "Watch her [TEMP2!t]"
    new "彼女を見てください [TEMP2!t]"


    old "Swim normally [TEMP3!t]"
    new "普通に泳ぐ [TEMP3!t]"


    old "Go even faster [TEMP1!t]"
    new "もっと速く行け [TEMP1!t]"


    old "Cheat [TEMP2!t]"
    new "チート [TEMP2!t]"


    old "Sprint [TEMP1!t]"
    new "スプリント [TEMP1!t]"


    old "Win [TEMP2!t]"
    new "勝つ [TEMP2!t]"


    old "Let her win [TEMP3!t]"
    new "彼女に勝たせてください [TEMP3!t]"




translate japanese sofiapool_6b9d811b:


    sofia ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
