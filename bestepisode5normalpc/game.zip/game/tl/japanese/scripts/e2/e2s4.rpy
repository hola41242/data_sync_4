


translate japanese e2s4_5b6b04d6:


    ji "テッドおじさん！パウ・パトロールを見たい！"


translate japanese e2s4_c2c97b56:


    ted "いいえ、キャシー、今はアニメの時間ではありません。"


translate japanese e2s4_6d11133e:


    cassie "でも本当に見たい！"


translate japanese e2s4_a42216b5:


    ted "いいえ、いいえ…。"


translate japanese e2s4_692a2f61:


    cassie "お願い、お願い、お願い！！！"


translate japanese e2s4_98a1471a:


    ted "私は言った、カッシー！もう午前8時30分で、..."


translate japanese e2s4_441c0783:


    mad "8:30 ???"


translate japanese e2s4_d3ea60d5:


    mad "ちくしょう、遅れそうだ！"


translate japanese e2s4_32fabfce:


    mad "何を着るべきかな？"


translate japanese e2s4_34413095:


    mad "ああ、これでいい！"


translate japanese e2s4_15fa04e3:


    mad "テッド！キャシーは着る準備ができていますか？"


translate japanese e2s4_0db593f2:


    ted "うん、うん…。"


translate japanese e2s4_d1c52f83:


    mad "アカデミーに送るのをお忘れなく！"


translate japanese e2s4_0db593f2_1:


    ted "うん、うん..."


translate japanese e2s4_a7500e50:


    mad "彼女がスナックを持っていることを確認して！"


translate japanese e2s4_0db593f2_2:


    ted "うん、うん..."


translate japanese e2s4_c7abb2c6:


    mad "うん、うん... うん、うん... 彼は他に何か言うことを知っているのだろうか？"


translate japanese e2s4_699afde9:


    mad "キャッシー、私は出発するよ！今夜会おうね、愛しい人！"


translate japanese e2s4_2f399ecc:


    cassie "今夜会おうね、お母さん！そして今夜はおやすみの物語を読んでもらえるんだよね？約束したよね！"


translate japanese e2s4_6ea8c9bd:


    mad "もちろん！約束！"


translate japanese e2s4_e03d9c57:


    cassie "やった！"


translate japanese e2s4_3511f9dc:


    mad "さて、新しい日だ…"


translate japanese e2s4_0c084aee:


    mad "また始まった..."


translate japanese e2s4_a512fbd7:


    mad "経済学の授業..."


translate japanese e2s4_cb7c44c2:


    mad "トレーニング..."


translate japanese e2s4_8cca5e36:


    mad "アカデミーでキャシーをピックアップ..."


translate japanese e2s4_bc9e9ad6:


    mad "そして、私はこの二人に対処しなければならない…"


translate japanese e2s4_90d878c6:


    beth "ええと、マディソン、今朝服を着るのを忘れたの？"


translate japanese e2s4_04f3053e:


    sofia "それとも、ママとパパがあなたにドレスを買うのをやめたの？"


translate japanese e2s4_4a9669cc:


    mad "これ、見えますか？"


translate japanese e2s4_26f6c27a:


    mad "太陽の当たらないところに押し込んでやれ。"


translate japanese e2s4_5cbb791c:


    ruby "こんにちは！"


translate japanese e2s4_d215ddd0:


    mad "こんにちは、ルビー..."


translate japanese e2s4_b10d9f66:


    ruby "厳しい朝だった？"


translate japanese e2s4_9ec6269c:


    mad "うん、私は遅く起きたから、準備する時間もカッシーにキスする時間もなかったまま出発しなければならなかった…"


translate japanese e2s4_3edbc739:


    mad "だから、私は見つけた最初のものをすぐに掴んだ..."


translate japanese e2s4_62205d67:


    ruby "ああ、知ってるでしょう、毎日ディーバのように着飾る必要はないんだよね？"


translate japanese e2s4_efde3ab7:


    mad "うん、わかってるけど、それでも..."


translate japanese e2s4_24bb991b:


    mad "そして、私の兄には、すべてを百回繰り返さなければならない…"


translate japanese e2s4_595c80ce:


    mad "疲れる..."


translate japanese e2s4_31b16005:


    ruby "少し休憩した方がいい…"


translate japanese e2s4_8cbe499c:


    ruby "そして、新しい誰かに出会うかもしれません！"


translate japanese e2s4_94518faf:


    mad "そんなことに時間はない！"


translate japanese e2s4_7dc72278:


    mad "そして、役に立たない兄や、狂ったスケジュール、完全に混沌とした生活を持つシングルマザーを誰が欲しがるだろうか..."


translate japanese e2s4_62e0c03b:


    ruby "ちょっとしたアイデアがあるかもしれない..."


translate japanese e2s4_d19ecb96:


    mad "あれ？"


translate japanese e2s4_77ba680b:


    ruby "ああ、気にしないで..."


translate japanese e2s4_37f47a0b:


    d "さて、ここが正しい教室だ..."


translate japanese e2s4_abda508c:


    d "でも、どこに座るべきですか？"


translate japanese madiruby_cb5052fe:


    d "ここに座ってもいいですか、皆さん？"


translate japanese madiruby_94364417:


    ruby "もちろん！"


translate japanese madiruby_93f7fde9:


    mad "はい、はい、もちろん..."


translate japanese madiruby_230cca25:


    d "ここにいるのは変な気分だ... 教室で..."


translate japanese madiruby_280960ba:


    ruby "女の子に囲まれている…"


translate japanese madiruby_d22bf5e3:


    d "えっ？あ、うん、それも！"


translate japanese madiruby_b4f07fd2:


    mad "あなたは気にしていないようですね…"


translate japanese madiruby_fbef33c9:


    d "いいえ、全く..."


translate japanese madiruby_28d87aa3:


    ruby "なるほど！あの男は美人の隣に座っているのね…"


translate japanese madiruby_bf8a9c0a:


    ruby "彼は文句を言わないよね？"


translate japanese madiruby_3efb7af7:


    mad "ルビー...やめて！"


translate japanese madiruby_dbf9b320:


    d "彼女は間違っていない！"


translate japanese madiruby_af9136f3:


    mad "ああ、本当に？"


translate japanese madiruby_e55d32ad:


    d "私はあなたが魅力的だとは言っていません！"


translate japanese madiruby_40e66c37:


    mad "あ！"


translate japanese madiruby_5f32c47f:


    ruby "あれ？"


translate japanese gracejulia_cb5052fe:


    d "ここに座ってもいいですか、皆さん？"


translate japanese gracejulia_02600786:


    grace "もちろん！"


translate japanese gracejulia_e9b99907:


    julia "はい、はい、もちろん..."


translate japanese gracejulia_230cca25:


    d "ここにいるのは奇妙な気分だ…教室の中で…"


translate japanese gracejulia_1f1d00ef:


    julia "これがあなたの初めてのクラスですか？"


translate japanese gracejulia_dbed4522:


    d "はい… 先生が優しいことを願っています！"


translate japanese gracejulia_1ba870f0:


    julia "心配しないで... 彼女はクールだよ..."


translate japanese gracejulia_5e3e5401:


    julia "彼女の授業を妨げなければ！"


translate japanese gracejulia_7bcc50f4:


    d "分かりました..."


translate japanese gracejulia_5b680b5d:


    grace "昨日の母のことで、まだ申し訳なく思っています..."


translate japanese gracejulia_67acc6de:


    d "心配しないで... それは起こることだから..."


translate japanese gracejulia_cef63d47:


    grace "あなたとの時間は本当に楽しかった..."


translate japanese gracejulia_f07527e5:


    d "もっとあることを願っています..."


translate japanese gracejulia_d10a5469:


    grace "私も..."


translate japanese sittwins_bfce7842:


    d "ここに座ってもいいですか、レディたち？"


translate japanese sittwins_49293452:


    beth "もちろん、喜んで！"


translate japanese sittwins_f9455265:


    sofia "ああ…はい、もちろん！"


translate japanese sittwins_2686ee98:


    sofia "これがあなたの初めての授業ですか？"


translate japanese sittwins_dd8c52d3:


    d "はい… 何を持っていけばいいのかもわからない…"


translate japanese sittwins_8b052222:


    beth "初めての時はいつもそんな感じだ..."


translate japanese sittwins_56e443ac:


    beth "ちょっと痛いけど... 一旦始まれば..."


translate japanese sittwins_b660916b:


    beth "もっと欲しくなるだろう..."


translate japanese sittwins_e78947be:


    sofia "妹のことを心配しないで... 彼女は噛まないから... まあ、たぶん噛まないけど..."


translate japanese sittwins_013dbb2f:


    d "ああ、私は怖くない！彼女の口で私に近づくことはできない..."


translate japanese sittwins_7d2ee7e5:


    beth "ああ、そうなの？本当に大丈夫なの？"


translate japanese sittwins_ace3b8d4:


    beth "彼らは私の口が悪くないと言っているけど…"


translate japanese sittwins_10760d33:


    beth "あなたが好まない限り..."


translate japanese sittwins_99c38ec9:


    beth "近づいて、..."


translate japanese sittwins_ab131cde:


    beth "もっと荒く..."


translate japanese sittwins_6710910f:


    sofia "それともあなたのすべての欲望を満たすことができるでしょうか…"


translate japanese sittwins_9ca925ff:


    sofia "最も無口な者でさえも..."


translate japanese sittwins_9ea58198:


    sofia "さらに進むことで..."


translate japanese sittwins_03cc4247:


    sofia "より深く..."


translate japanese sittwins_590ce44c:


    sofia "物..."


translate japanese sittwins_f338cc08:


    d "あの..."


translate japanese suitecours_46fb28ab:


    gaby "こんにちは、みんな！"


translate japanese suitecours_883d9886:


    gaby "私はガブリエラ、あなたの経済学の教師です..."


translate japanese suitecours_fa87f52f:


    gaby "私のことを女子サッカーチームのコーチとして知っている方もいるかもしれません…"


translate japanese suitecours_ac5e6d6c:


    gaby "他の人々が私にとって完全な他人である間に..."


translate japanese suitecours_58ff09da:


    gaby "遠回しなことはやめましょう... 私は人々が私に対して直接的で率直であることが好きです... もしあなたがここで働くつもりがないのなら、または興味がないのなら..."


translate japanese suitecours_c9d37095:


    gaby "今すぐ出発してもいいよ…"


translate japanese suitecours_34d67876:


    gaby "残りの皆さんは..."


translate japanese suitecours_6f2a997a:


    gaby "まあ、私はいつでもあなたの質問に答える準備ができていて、喜んでお手伝いします！"


translate japanese suitecours_85fcfaee:


    gaby "フランスの学生が私たちの中にいるようですね… [name]、そうですか？"


translate japanese suitecours_2d1f1461:


    d "はい、かしこまりました..."


translate japanese suitecours_5532afff:


    gaby "とても良いですね、あなたが自分の道を見つけ始めて、今回は迷子になっていないようですね..."


translate japanese suitecours_11a49d80:


    gaby "そして、今回は適切に服を着ています！"


translate japanese suitecours_b2842d1b:


    d "はい..."


translate japanese suitecours_daf08564:


    gaby "これらの最初の日々はどうですか？"


translate japanese suitecours_4f3652ea:


    d "到着してから素晴らしい人たちに出会い、彼らのもてなしに感謝する方法がまだ分からないことを認めざるを得ません。"


translate japanese suitecours_4debf90f:


    ruby "あぁ！それはとても甘い！！！"


translate japanese suitecours_27de816f:


    gaby "君たち... いつも優しすぎる！"


translate japanese suitecours_df0cb0e4:


    gaby "なるほど…"


translate japanese suitecours_d88d27c1:


    d "そんなに、良い状況や悪い状況なんて存在しないと思うよ..."


translate japanese suitecours_bf5156e3:


    gaby "面白い！"


translate japanese suitecours_a1418d15:


    gaby "この世界は白と黒だけだと思いますか？すべてが黒か白ではないと思いますか？"


translate japanese suitecours_596be531:


    d "わからない... ただ、私たちはいつもグラスを半分空だと考えるべきではないと思う..."


translate japanese suitecours_df0cb0e4_1:


    gaby "非常に良い..."


translate japanese suitecours_4367836d:


    d "競争のことが頭にある... 残りは、今のところ私には少し手に負えない..."


translate japanese suitecours_6c000199:


    gaby "そのB.E.S.Tですか？あなたもその一部なのですか？"


translate japanese suitecours_531910ca:


    d "私もあなたと同じくらい驚いています…でも、はい…"


translate japanese suitecours_df0cb0e4_2:


    gaby "非常に良い..."


translate japanese suitecours_2df75f35:


    d "さて、聞いてくれ、今私は最高の人生を送っているんだ！世界中の女の子と出会っていて、私はB.E.S.Tの中にいる…そして本当に、美しい先生がいるのは素晴らしいことだ…それが私に授業に来たくさせるんだ！"


translate japanese suitecours_a1699582:


    gaby "ああ…それは予想外だった…"


translate japanese suitecours_a9642ea4:


    d "ハハ！私は驚きでいっぱいだ！"


translate japanese suitecours_9504acb6:


    gaby "そしてお茶目でもある..."


translate japanese suitecours_df0cb0e4_3:


    gaby "とても良い..."


translate japanese suitecours_63b979ab:


    gaby "そうですね、あなたはフランコ・アメリカンの関係を築き始めたようですね…"


translate japanese suitecours_099834b3:


    gaby "フランスがアメリカの独立を祝うためにアメリカ合衆国に贈った贈り物は、[name]を除いて誰が教えてくれるのだろうか？"


translate japanese suitecours_ae64f34d:


    d "私を信じますか？"


translate japanese suitecours_a7a44cf1:


    mad "特に..."


translate japanese suitecours_3f883698:


    d "自由の女神像。"


translate japanese suitecours_91da6cea:


    mad "あなたは確信していますか？"


translate japanese suitecours_d38968bc:


    d "はい、はい..."


translate japanese suitecours_57cbaadd:


    emerick "" with hpunch


translate japanese suitecours_3df4aaa1:


    d "ああ、くそ..."


translate japanese suitecours_2d6dad60:


    gaby "はい、それは正しいです、エメリック..."


translate japanese suitecours_ca813997:


    mad "ごめんなさい..."


translate japanese suitecours_edf1868e:


    mad "ああ... はい..."


translate japanese suitecours_3f883698_1:


    d "自由の女神。"


translate japanese suitecours_0a6ece95:


    mad "わかりました。"


translate japanese suitecours_244ef33c:


    mad "自由の女神像？"


translate japanese suitecours_36794003:


    gaby "はい！"


translate japanese suitecours_dc636991:


    emerick "くそ、分かってた！"


translate japanese suitecours_7e3ae4e5:


    gaby "言葉遣いに気を付けて、エメリック！"


translate japanese suitecours_1bb5a634:


    emerick "申し訳ありません、お嬢様！"


translate japanese suitecours_781a1cd8:


    mad "ありがとう！"


translate japanese suitecours_26af0923:


    dpense "自由の女神"


translate japanese suitecours_57cbaadd_1:


    emerick "" with hpunch


translate japanese suitecours_3df4aaa1_1:


    d "ああ、くそ..."


translate japanese suitecours_2d6dad60_1:


    gaby "はい、その通りです、エメリック..."


translate japanese suitecours_087fee55:


    gaby "さて、今日の授業は経済学の一般原則に焦点を当てます..."


translate japanese suitecours_af59083d:


    gaby "そして、すべては供給と需要についてです..."


translate japanese suitecours_916d515d:


    drew "" with hpunch


translate japanese suitecours_6820b807:


    drew "10分以内にスタジアムの中心に集まるようにお願いします..."


translate japanese suitecours_938fcc14:


    drew "私は繰り返します..."


translate japanese suitecours_e6f31e6b:


    drew "全てのB.E.S.T.参加者は、10分以内にスタジアムの中央に集まらなければなりません…"


translate japanese suitecours_d7c1bae8:


    gaby "さて、授業は終わったようですね..."


translate japanese suitecours_aab8223d:


    gaby "みんなに幸運を祈ります！"


translate japanese suitecours_cb6abcd7:


    orushi "ようこそ、B.E.S.Tの参加者の皆さん..."


translate japanese suitecours_04c60917:


    orushi "この競争には、あなたたちの中で最も優れた者に報酬が与えられるのに、今は残り50人だけです..."


translate japanese suitecours_7d3c0eb2:


    orushi "まず第一に、最初のチャレンジを成功裏に終えたことをお祝いしたいです..."


translate japanese suitecours_2ac1c2b2:


    orushi "今日は、あなたにちょっと特別な挑戦があります..."


translate japanese suitecours_0d63aeed:


    orushi "確かに、選考プロセスにボーナスチャレンジを追加することに決めました..."


translate japanese suitecours_118c8a2c:


    orushi "この挑戦は淘汰制ではありません..."


translate japanese suitecours_fae9f837:


    orushi "サッカーにおける男女チームのパフォーマンスを考慮すると…"


translate japanese suitecours_fac953e3:


    orushi "あなたのチームスピリットを引き出すのは面白いと思いました…。"


translate japanese suitecours_d57d8af8:


    orushi "あなたの運動能力を評価している間..."


translate japanese suitecours_29f0eedd:


    orushi "大会を企画しました..."


translate japanese suitecours_7377b77c:


    orushi "いくつかの直接 elimination マッチで構成される..."


translate japanese suitecours_13d3ec80:


    orushi "最終的には、最も優れたチームを決定することになります..."


translate japanese suitecours_dea55d2d:


    orushi "もちろん、排除がなければ、何か賭けが必要です..."


translate japanese suitecours_2bc2747c:


    orushi "それでは、このトーナメントに勝つチームに特別なボーナスを与えることに決めました..."


translate japanese suitecours_88d75d0b:


    orushi "自分たちで見てください..."


translate japanese suitecours_c42abb16:


    orushi "勝利したチームは、B.E.S.T.の期間中、キャンパスからそれほど遠くない場所にあるこの家を楽しむことができます..."


translate japanese suitecours_72a3d47a:


    orushi "その家には五つの個別の寝室があり、最高の条件下でのB.E.S.Tチャレンジに備えるための訓練、休息、準備に必要なすべての快適さが備わっています..."


translate japanese suitecours_c87ce251:


    orushi "もちろん、すべてのこれには代償が伴います..."


translate japanese suitecours_d32d8b03:


    orushi "そして、あなたが理解したように、この特権を得るために5人のチームで競い合うことになります…。"


translate japanese suitecours_0a5480e5:


    orushi "これはあなたのモチベーション、パフォーマンス、そして他者とのつながりのレベルを評価するためのものです..."


translate japanese suitecours_736785cb:


    orushi "あなた自身のチームを編成します..."


translate japanese suitecours_040186bf:


    orushi "プレイヤーの最適化について考えてみてください..."


translate japanese suitecours_1e8bfa8c:


    orushi "負け犬には何もない..."


translate japanese suitecours_12414ce8:


    orushi "あなたのチームを作るために、コンピュータがキャプテンを選び、このチャレンジのために彼らのチームメイトを選ぶことになります..."


translate japanese suitecours_48785378:


    orushi "以下は、キャプテンとして選ばれたプレイヤーのリストです："


translate japanese suitecours_d09ce434:


    orushi "学生スティーブン..."


translate japanese suitecours_11afa90a:


    s "はい、先生..."


translate japanese suitecours_b2136f6a:


    orushi "あなたはチームAのキャプテンになります…"


translate japanese suitecours_1a6f6865:


    s "とてもよろしいです、先生..."


translate japanese suitecours_c282e467:


    orushi "学生エメリック…"


translate japanese suitecours_905cbf84:


    emerick "はい、わかりました…。"


translate japanese suitecours_59809014:


    orushi "あなたはチームBのキャプテンになります..."


translate japanese suitecours_19945eb9:


    orushi "学生のマディソン…"


translate japanese suitecours_90670405:


    mad "はい、サー..."


translate japanese suitecours_acf02fcb:


    orushi "あなたはチームHのキャプテンになります..."


translate japanese suitecours_c9f2c988:


    mad "さて..."


translate japanese suitecours_b31bba35:


    orushi "キャプテンが決まったので、先ほどの順番で、一人ずつ、チームメイトを選んでください…"


translate japanese suitecours_cbab976a:


    s "じゃあ、マックを選びます！"


translate japanese suitecours_e8b0f8fe:


    emerick "私はエリザベスを選びます！"


translate japanese suitecours_ebdc68c4:


    emerick "それを達成できましたか？"


translate japanese suitecours_2cfb5c45:


    beth "はい、通常はすべてのボールが順番に置かれています…最後のものを除いて…"


translate japanese suitecours_cfc2ff6b:


    ji "私はマークを選びます！"


translate japanese suitecours_90146bcc:


    ji "エデンを選びます！"


translate japanese suitecours_daeb8dcf:


    ji "ルイスを選びます！"


translate japanese suitecours_0f400b9e:


    ji "ブランダンを選びます！"


translate japanese suitecours_b9695e43:


    ji "エミリアを選ぶ！"


translate japanese suitecours_37e3f6ae:


    mad "[name]を選びます！"


translate japanese suitecours_355fdbbd:


    d "わあ！あなたが私を選ぶなんて思わなかった！"


translate japanese suitecours_eeebc711:


    mad "私たちは最初の挑戦でうまくいきました…二つ目の挑戦でも成功することを願っています…"


translate japanese suitecours_ed398876:


    s "ヘクター！"


translate japanese suitecours_75c8baf1:


    emerick "ソフィア！"


translate japanese suitecours_ba6a93d7:


    mad "グレース！"


translate japanese suitecours_a5120c1c:


    s "ベン！"


translate japanese suitecours_c9eabda7:


    mad "ルビー！"


translate japanese suitecours_b6c17e44:


    mad "ジュリア！"


translate japanese suitecours_42b56b32:


    mad "グレースを選びます！"


translate japanese suitecours_ed398876_1:


    s "ヘクター！"


translate japanese suitecours_75c8baf1_1:


    emerick "ソフィア！"


translate japanese suitecours_c9eabda7_1:


    mad "ルビー！"


translate japanese suitecours_a5120c1c_1:


    s "ベン！"


translate japanese suitecours_b6c17e44_1:


    mad "ジュリア！"


translate japanese suitecours_b736ea3c:


    ruby "マディソン、[name]を取れ！"


translate japanese suitecours_636a4cae:


    mad "本当ですか？"


translate japanese suitecours_8bb0774f:


    ruby "もちろん！"


translate japanese suitecours_77f04cb3:


    mad "わかった… [name] を選びます！"


translate japanese suitecours_5d37a177:


    d "ありがとう..."


translate japanese suitecours_1c7f72b8:


    mad "ルビーに挨拶することができます..."


translate japanese suitecours_4db55881:


    orushi "非常に良い！さて、あなたたちのチームが形成されたので... くじ引きを進めなければなりません..."


translate japanese suitecours_4bb9c3da:


    orushi "あなたは10チームですが、このトーナメントには参加できるのは8チームだけです..."


translate japanese suitecours_035d09f5:


    orushi "あなたの後ろには、下にボールがあるカップがあります..."


translate japanese suitecours_3cb93f68:


    orushi "8個の黒い玉と2個の白い玉..."


translate japanese suitecours_6ef0da47:


    orushi "それでは、皆さんは順番にカップを選び、引いたボールを見せることになります..."


translate japanese suitecours_9c47e601:


    orushi "あなたのチームの誰かが行ってボールを描くことができます..."


translate japanese suitecours_ec0627c7:


    orushi "黒いボールを引いたら、参加資格が得られます！白いボールを引いたら、このトーナメントには参加できません…"


translate japanese suitecours_f16f89f9:


    mad "ああ、くそ、私はこれが得意じゃない…"


translate japanese suitecours_584173a2:


    ruby "何を意味しているのですか？"


translate japanese suitecours_494323f8:


    mad "まあ、運が私の味方になることはあまりないとだけ言っておきましょう..."


translate japanese suitecours_1dbf4149:


    ruby "ああ…同じく！"


translate japanese suitecours_a647ab43:


    d "あれ？"


translate japanese suitecours_c2c87464:


    d "あなたが望むなら、私はそれができます..."


translate japanese suitecours_18ae2ed2:


    mad "あなたは？"


translate japanese suitecours_1856c7d4:


    d "はい... 最悪の場合、プレイできなければ、それは私のせいにしてもいいですよ！"


translate japanese suitecours_e0d5187b:


    mad "まあ... わかった..."


translate japanese suitecours_f5e55f54:


    ruby "待って… 思いついた…"


translate japanese suitecours_c8aa12cf:


    julia "何ですか？"


translate japanese suitecours_1f45ebf6:


    ruby "もし私が順序を正しく理解しているなら、最終的にはあなたたちの中で三人だけが残るでしょう..."


translate japanese suitecours_52b03409:


    julia "ええと… はい… 私たちはチームH、8番目のチームです…"


translate japanese suitecours_5c99e476:


    ruby "さて... 結果がどうなるか見てみましょう..."


translate japanese suitecours_c320f17e:


    emerick "私が先に行くね！"


translate japanese suitecours_4f781c37:


    emerick "黒いボール！"


translate japanese suitecours_d42d80c6:


    orushi "資格のあるチーム！"


translate japanese suitecours_b416f0d3:


    s "黒いボール！"


translate japanese suitecours_d42d80c6_1:


    orushi "資格のあるチーム！"


translate japanese suitecours_3988fd6d:


    ji "黒さ！"


translate japanese suitecours_d42d80c6_2:


    orushi "資格のあるチーム！"


translate japanese suitecours_3988fd6d_1:


    ji "黒！"


translate japanese suitecours_d42d80c6_3:


    orushi "有資格のチーム！"


translate japanese suitecours_3988fd6d_2:


    ji "黒！"


translate japanese suitecours_d42d80c6_4:


    orushi "資格のあるチーム！"


translate japanese suitecours_3988fd6d_3:


    ji "黒!"


translate japanese suitecours_d42d80c6_5:


    orushi "資格のあるチーム！"


translate japanese suitecours_3988fd6d_4:


    ji "黒！"


translate japanese suitecours_d42d80c6_6:


    orushi "資格のあるチーム！"


translate japanese suitecours_a1d614f0:


    orushi "さて、七つのチームが今や予選を通過しました..."


translate japanese suitecours_5e014e97:


    orushi "最後の三つの袋の中に黒いボールは一つだけ残っています..."


translate japanese suitecours_11df4754:


    orushi "チームH、続けてください…"


translate japanese suitecours_09dd397c:


    dpense "私はブルーを信じるつもりです..."


translate japanese suitecours_dac16296:


    d "最後のものを選びます..."


translate japanese suitecours_0b442ff1:


    mad "おお、神様！[name] 何をしているの？"


translate japanese suitecours_58018565:


    d "わからない！"


translate japanese suitecours_4fa6cf9d:


    mad "彼は本気ですか？"


translate japanese suitecours_cf27c58a:


    dpense "罠かもしれない..."


translate japanese rusolve_d3e412b3:


    ruby "オルシ氏？"


translate japanese rusolve_e494fdfd:


    orushi "はい？"


translate japanese rusolve_a932588e:


    ruby "次のプレイヤーに私たちの代わりにプレイさせることができますか？私たちは次のプレイヤーに私たちの代わりにボールを引くチャンスを与え、その後に自分のボールを引きたいと思っています..."


translate japanese rusolve_28cfd01c:


    orushi "うーん… エメリックがスティーブンの前に行った時… 私はそれに問題はないと思う…"


translate japanese rusolve_6a1566d3:


    emerick "彼女は何をしているの？"


translate japanese rusolve_fe395a9a:


    d "なぜ彼にそれを尋ねているのですか？"


translate japanese rusolve_142f5df4:


    ruby "信じて！"


translate japanese rusolve_59837f76:


    ruby "教えて... どのボールを引くつもりだった？"


translate japanese rusolve_51808edd:


    d "どうかわからないけど、正しいものを選ぶ確率は三分の一だ！"


translate japanese rusolve_3a450a96:


    ruby "それが原則です... 33パーセント..."


translate japanese rusolve_72987282:


    d "左の方..."


translate japanese rusolve_30508101:


    d "真ん中の..."


translate japanese rusolve_578f2da0:


    d "右のやつ..."


translate japanese rusolve_8c4cb72b:


    ji "中央のものを選びます！"


translate japanese rusolve_7bcc50f4:


    d "わかりました..."


translate japanese rusolve_170fc44d:


    ruby "待って..."


translate japanese rusolve_5f484a7a:


    ji "白..."


translate japanese rusolve_8fdce6a4:


    orushi "チームが排除されました！"


translate japanese rusolve_f8af79d9:


    ji "左の方を選びます！"


translate japanese rusolve_7bcc50f4_1:


    d "はい…"


translate japanese rusolve_170fc44d_1:


    ruby "待って..."


translate japanese rusolve_5f484a7a_1:


    ji "白..."


translate japanese rusolve_8fdce6a4_1:


    orushi "チームが排除されました！"


translate japanese rusolve_f8af79d9_1:


    ji "左の方を選びます！"


translate japanese rusolve_7bcc50f4_2:


    d "わかりました..."


translate japanese rusolve_170fc44d_2:


    ruby "待って..."


translate japanese rusolve_5f484a7a_2:


    ji "白..."


translate japanese rusolve_8fdce6a4_2:


    orushi "チームが排除されました！"


translate japanese centerright_ee586e7e:


    mad "なんてこった... 私は皆と同じように私たちのボールを順番に描いていただろうに..."


translate japanese centerright_158bc8fd:


    grace "はい、私も同じことをしたでしょう…"


translate japanese centerright_7e9b8995:


    julia "でも、どうしてそんなことをしたの、ルビー？"


translate japanese centerright_ef6e87dc:


    ruby "直感..."


translate japanese centerright_a3f17df4:


    d "でも、今はどうするの？負ける確率は五分五分だよ！"


translate japanese centerright_072df15c:


    ruby "いいえ…そこがあなたの間違いです！"


translate japanese centerright_dd5d68f3:


    d "え？"


translate japanese centerright_c13ab685:


    ruby "あなたが始めたとき、あなたが選んだのが黒いボールである確率は3分の1だった、そうでしょう？"


translate japanese centerright_d1523116:


    d "ええ、そうですね..."


translate japanese centerright_46b44aa9:


    ruby "さて、今、あなたは選ばなかった方にそれがある確率が3分の2です！"


translate japanese centerright_dd5d68f3_1:


    d "え？"


translate japanese centerright_5625102b:


    ruby "私を信じて、もう一つのボールを取って..."


translate japanese centerright_f4379931:


    d "この狂気は何だ？"


translate japanese centerright_bf9a1fbc:


    d "彼女は完全に狂っている…"


translate japanese centerright_59e62df4:


    d "よし... 行こう..."


translate japanese centerright_81959ae4:


    dpense "見たくない…"


translate japanese centerright_02be2d4e:


    orushi "黒いボール！選ばれたチーム！"


translate japanese centerright_85a51d50:


    d "Huh???"


translate japanese centerright_871f33af:


    ruby "ほら、言ったでしょう！"


translate japanese centerright_f542d5d6:


    mad "あなたは狂っている！"


translate japanese centerright_a508db31:


    ruby "私はそんな予感がしていました！信じてくれてありがとう！"


translate japanese lefttable_f31fcf7b:


    d "今はどうする？負ける確率は五分五分だ！"


translate japanese lefttable_072df15c:


    ruby "いいえ…そこがあなたの間違いです！"


translate japanese lefttable_dd5d68f3:


    d "え？"


translate japanese lefttable_c13ab685:


    ruby "あなたが始めたとき、黒い玉があなたが選んだものである確率は1/3でしたよね？"


translate japanese lefttable_d1523116:


    d "ええ、そうですね..."


translate japanese lefttable_46b44aa9:


    ruby "まあ、あなたが選ばなかった方にそれがある確率は、今や三分の二です！"


translate japanese lefttable_dd5d68f3_1:


    d "え？"


translate japanese lefttable_5625102b:


    ruby "私を信じて、もう一つのボールを取って…。"


translate japanese lefttable_f4379931:


    d "この狂気は何ですか？"


translate japanese lefttable_bf9a1fbc:


    d "彼女は完全に狂っている..."


translate japanese lefttable_59e62df4:


    d "よし… 行こう…"


translate japanese lefttable_81959ae4:


    dpense "見たくない..."


translate japanese lefttable_02be2d4e:


    orushi "黒いボール！選ばれたチーム！"


translate japanese lefttable_85a51d50:


    d "え？"


translate japanese lefttable_871f33af:


    ruby "ほら、言ったでしょ！"


translate japanese lefttable_f542d5d6:


    mad "あなたは狂ってる！"


translate japanese lefttable_a508db31:


    ruby "予感があった！信じてくれてありがとう！"


translate japanese bluesolve_3b040379:


    d "彼女が間違っていたらどうなるの？"


translate japanese bluesolve_bf9a1fbc:


    d "彼女は完全に狂っている…"


translate japanese bluesolve_59e62df4:


    d "よし... 行こう..."


translate japanese bluesolve_81959ae4:


    dpense "見たくない..."


translate japanese bluesolve_02be2d4e:


    orushi "黒いボール！予選チーム！"


translate japanese bluesolve_85a51d50:


    d "え？"


translate japanese bluesolve_f542d5d6:


    mad "あなたは狂っている！"


translate japanese resulttable_28601e80:


    orushi "すべてのトーナメントチームが決定したので、最初の試合を始めます..."


translate japanese resulttable_af173a75:


    orushi "マッチはこのようになります："


translate japanese resulttable_ae065467:


    orushi "A 対 C"


translate japanese resulttable_6f7c934f:


    orushi "B対E"


translate japanese resulttable_d0f1a017:


    orushi "D対H"


translate japanese resulttable_da9dba80:


    orushi "F対G"


translate japanese resulttable_04d36dc5:


    orushi "ロッカールームに行って、ユニフォームを取り出し、試合の準備をしてください..."


translate japanese resulttable_ac7ab3c8:


    mad "よし！みんな、行こう！"

translate japanese strings:


    old "Sit with Madison and Ruby [TEMP1!t]"
    new "マディソンとルビーと一緒に座る [TEMP1!t]"


    old "Sit with Grace and Julia [TEMP2!t]"
    new "グレースとジュリアと一緒に座る[TEMP2!t]"


    old "Sit with the twins [TEMP3!t]"
    new "双子と一緒に座る [TEMP3!t]"


    old "Take the last one !!!"
    new "最後の一つを取って！！！"


    old "What ?"
    new "何？"


    old "Do as I say if you want to continue !!!"
    new "続けたいなら、私の言うとおりにしてくれ！」！"


    old "Trust Blue [TEMP1!t]"
    new "ブルーを信頼する"


    old "Do not trust Blue [TEMP2!t]"
    new "ブルーを信用しないでください [TEMP2!t]"


    old "Left"
    new "左"


    old "Center"
    new "センター"


    old "Right"
    new "右"


    old "Thank you!!!"
    new "ありがとう！！！"


    old "You owe me one..."
    new "あなたは私に借りがある..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
