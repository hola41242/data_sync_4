


translate japanese e2s2_699705df:


    d "なぜニットキャップをかぶっているのですか？"


translate japanese e2s2_2651da73:


    julia "まあ…実は、自分の髪の色が好きだけど、遠くから私を見かけるかもしれない人には会いたくない…だから、私はこっそりしていたいの。"


translate japanese e2s2_a09a9275:


    d "問題がありますか？"


translate japanese e2s2_747f24b1:


    julia "えっと…あまりそうではない…"


translate japanese e2s2_81710995:


    julia "ここでの生活に慣れてきた？"


translate japanese e2s2_a69974f7:


    d "ああ、そうですね、私はここに来てまだ2日しか経っていません... 実際、何も見る時間があまりありませんでした！"


translate japanese e2s2_f013355a:


    d "しかし、少し探検したいし、状況を把握するために時間があるということを利用したいです..."


translate japanese e2s2_649f8856:


    d "競争が激しく、授業が始まるところで、出会う人々がたくさんいて…自分がどこにいるのかさえ、ほとんどわからない！"


translate japanese e2s2_0ddb529d:


    julia "想像できますよ！あなたにとってはかなりのショックに違いありません…"


translate japanese e2s2_4194debf:


    d "うん、まあ... 実は、勉強しに来ただけなんだ..."


translate japanese e2s2_2e7a7210:


    d "そして今、私はB.E.S.T.プログラムに参加し、アカデミーの寮にいる。校長先生やその娘さん、あなたや他の人たちとはもう会いました。"


translate japanese e2s2_2d9dc3c5:


    d "どこから始めればいいのかわからないし、授業もまだ始まっていない！"


translate japanese e2s2_60da1eec:


    julia "あはは！まだ終わっていないよ！週の終わりには、統合パーティーがあるんだ。"


translate japanese e2s2_1b8d5ee7:


    julia "まるでゲームと人々が everywhere の大きな祝いのようです... しばしば激しいパーティーに終わります... 言葉のすべての意味で... あなたが強い胃を持っていることを願っています！"


translate japanese e2s2_ec991449:


    d "人がいればそれでいい！そして、私ははしゃぎすぎるタイプではない！"


translate japanese e2s2_4e3f7e5b:


    d "基本的に、私たちが楽しんでいるとき、こういうパーティーが好きです！"


translate japanese e2s2_170cdd76:


    julia "まったく同感です！これは私の好きなタイプのパーティーではありません...私は少し孤独なタイプです..."


translate japanese e2s2_fdd47e50:


    julia "でも、私は努力していて、毎年様子を見に来て、新しい人たちがどう馴染んでいるかを確認しています…"


translate japanese e2s2_1bae9f5e:


    d "ああ、そうだね、こういうパーティーでは、暴走しないように気をつけないといけないんだ…そうしないと、次の日にはひどい二日酔いになって、悪習慣がすぐに形成されてしまうから…"


translate japanese e2s2_1c7dbdcc:


    d "それがあなたの成績に影響を与えます..."


translate japanese e2s2_a42f6436:


    julia "授業をとても真剣に受けているね、そうだね？"


translate japanese e2s2_ef6e3ce0:


    d "まあ、そうだね…選択肢はないし…それに、もし成績が良くなかったら、私はここにいられなくなるし、今まで頑張ってきたことが無駄になってしまうから…"


translate japanese e2s2_a4b21c2c:


    julia "わかりました…"


translate japanese e2s2_ddeb79fb:


    d "私は良好な体調を維持するために、アルコールをほとんど飲みません... スポーツが最優先です！くそ！"


translate japanese e2s2_528a694f:


    julia "おお、すごい！では、彼はもう高レベルのアスリートなのですか？"


translate japanese e2s2_2abccca6:


    d "いいえ、でも最高のパフォーマンスを達成するために、体を良い状態に保つことを非常に重視しています。"


translate japanese e2s2_f5bfadf3:


    d "もしできるなら、毎日ターキーライスとオリーブオイルの良い脂肪だけを食べたい... でもここでは、ブラストバイズからマグに変わるかもしれないと心配している..."


translate japanese e2s2_04da4eb4:


    julia "ハハ！今のところ、君はマチョップに似ていると言えるね！"


translate japanese e2s2_2f84c3bb:


    d "やあ！"


translate japanese e2s2_0ff2a046:


    d "飲み物と美しい女の子？それが私が必要なすべてだ！素晴らしい夜になることが約束されている！"


translate japanese e2s2_2a1cca83:


    julia "調子に乗るな、ドン・ファン！君が現れたからって、すべての女の子が君の足元にいるわけじゃないんだから！"


translate japanese e2s2_210ff254:


    julia "そして、まだお酒を飲まなくてはいけない… そして、翌日には授業があることを忘れないで！"


translate japanese e2s2_e1c58ffa:


    d "それぐらいでは私を怖がらせることはできない！私は彼らにダンスフロアの王が誰かを見せてやる！彼らは皆、私のフレンチタッチに圧倒されるだろう！"


translate japanese e2s2_ac2e69c2:


    julia "うん、そうだね..."


translate japanese e2s2_f6cfd155:


    julia "とにかく、ほとんど全員がこのパーティーに来るよ！いつもはマディソンがイベントを企画しているけど、今年は私には何も言わなかった..."


translate japanese e2s2_e4720c4a:


    julia "彼女にとって、今は娘がいるのでより難しいと思います...だから、その場所がどこになるのかも分かりません...他の人からもっと情報を得られるかもしれません！"


translate japanese e2s2_ad3f6506:


    d "でも、あなたはまだ来るよね？"


translate japanese e2s2_a34dcd03:


    julia "はい！少なくとも顔を出すのはほぼ義務みたいなもので、そうしないと非社交的だと思われるから...でも、私はおそらく長くはいないだろう..."


translate japanese e2s2_9d401a52:


    d "どうなるか見てみよう... ルビーは再び完全に夢中になるに違いない！"


translate japanese e2s2_b389601e:


    julia "ああ、もちろん！彼女は毎年女の子たちと小さなゲームを企画している... 彼女は通常、これらのパーティーを楽しくする人です..."


translate japanese e2s2_a97e81c6:


    julia "そうでなければ、君に声をかけてくるうざい奴らに対処しなければならない…"


translate japanese e2s2_f1b6f7a1:


    d "うざい男たち？"


translate japanese e2s2_73733c8a:


    julia "うん、スティーブンのギャングがいる... フットボールの連中が... どのパーティーでも、彼らはやって来て、誰がアルファオス男かを証明するために馬鹿な挑戦をして、お互いを超えようとする..."


translate japanese e2s2_2c2249c6:


    julia "そして、もちろん、私たちは彼らの標的になる... しかし、毎年彼らは試みる... そして、毎年彼らは拒絶される！"


translate japanese e2s2_198ee8a3:


    d "でも、さっき公園で、誰ともキスしたことがないって言ってたよね…"


translate japanese e2s2_4e619f92:


    julia "はい..."


translate japanese e2s2_ff8f5d14:


    d "それで、彼氏がいたことはないの？"


translate japanese e2s2_a59c2be9:


    julia "実際のところ、男に対して特別な感情を抱いたことはないんだ… そうだな… 自信がないけど…"


translate japanese e2s2_f96d060b:


    d "女の子が好きですか？"


translate japanese e2s2_cbc0a567:


    julia "何？いいえ！ただ、私を本当に興味を引くような人にまだ出会っていないだけなんです... まあ、まだですが！でも、それはそのうち来るでしょう、正直なところ、それは本当に問題ではありません。"


translate japanese e2s2_2154c2d6:


    julia "結局、私は信頼できる誰かと共に、この自分の一面を探求したいし、最良の方法でそれを発見する手助けをしてほしい…。"


translate japanese e2s2_f515507e:


    d "他の女の子たちはどうですか？近づかれるのに抵抗がありますか？"


translate japanese e2s2_5609f7b7:


    julia "うーん… グレースは、あまり深く行かずに近づかれるのが好きなんだ… 彼女は優しい女の子だ…"


translate japanese e2s2_17d1ebbd:


    julia "彼女はダンスを頼まれたり話しかけられたりしても、直接「いいえ」とは言わない… けれど、事が盛り上がり始めると、彼女は逃げてしまう…"


translate japanese e2s2_063a254d:


    d "彼女は逃げるの？"


translate japanese e2s2_2f7bba62:


    julia "はい！彼女は友達に電話をかけてその男を引き留めさせるか、何の説明もなく直接去るかのどちらかです... だから、そう... 彼女は狡猾です！"


translate japanese e2s2_1ef78c01:


    d "あはは！じゃあ、ルビーはどうですか？"


translate japanese e2s2_31bb772d:


    julia "ああ、ルビーは違う！彼女はすべてを片付けたいから、男の子と遊ぶ時間がないんだ..."


translate japanese e2s2_76e1c2af:


    julia "彼女は私たちと一緒に遊んで、キッチンに何も欠けていないか確認してくれる。そして時々、パーティー参加者のためにコンドームや他の小物を詰めたバッグを用意してくれることもある…。"


translate japanese e2s2_a0507f21:


    julia "しかし、それが原因で、彼女は本来楽しむべきことをあまり楽しんでいない..."


translate japanese e2s2_cd5b7cef:


    d "なるほど！"


translate japanese e2s2_4b92c7e2:


    julia "そして、逆に言えば、あまり... こだわりのない女の子もいるだろう... でも、あなたが自分自身で見つける機会を与えるよ... もし望むなら！"


translate japanese e2s2_5c581896:


    d "どうなるか見てみる..."


translate japanese e2s2_7c2f365c:


    julia "公園では、女の子たちが何かを話していた...双子について...彼女たちは何について話していたのだろう？"


translate japanese e2s2_f37455ff:


    d "私は青が本当に好きです..."


translate japanese e2s2_101332d7:


    julia "え？"


translate japanese e2s2_c5609e2e:


    d "うん！彼女は特別で、何と言えばいいのかわからない..."


translate japanese e2s2_8d85d16f:


    julia "ふむ... それならマディソンがそう言った理由がわかる... 今はマディに受け入れられるのが難しくなるだろうね！"


translate japanese e2s2_5bc0ea87:


    d "どうなるか見てみましょう…"


translate japanese e2s2_40ea1b9b:


    d "青い服の双子が私に近づいてきたが...彼女には興味がない..."


translate japanese e2s2_1ee38eaf:


    julia "ああ、本当に？"


translate japanese e2s2_bdb8233e:


    d "うん… 彼女は私のタイプじゃない、その手の女の子は… サッカーの連中やうるさいやつらと行かせておきなよ！"


translate japanese e2s2_da81affe:


    julia "はは！マディにポイントを稼いでいるね！双子と一緒じゃない方が彼女に受け入れられやすいよ！特に彼女たちを無視すればね！"


translate japanese e2s2_5bc0ea87_1:


    d "どうなるか見てみましょう…"


translate japanese e2s2_045838c2:


    d "私は本当に赤が好きです..."


translate japanese e2s2_101332d7_1:


    julia "え？"


translate japanese e2s2_c5609e2e_1:


    d "うん！彼女は特別だ、何を言えばいいのかわからない..."


translate japanese e2s2_8ae374e1:


    julia "うーん... だからルビーがそう言った理由が分かるよ... これでマディに受け入れてもらうのがもっと難しくなるね！"


translate japanese e2s2_5bc0ea87_2:


    d "どうなるか見てみましょう…"


translate japanese e2s2_6b7da03e:


    d "赤い服を着た双子が近づいてきたけれど、私は彼女に興味がない。"


translate japanese e2s2_1ee38eaf_1:


    julia "そうなの？"


translate japanese e2s2_bdb8233e_1:


    d "うん... 彼女は私のタイプじゃない、そういう種類の女の子は... サッカー部の連中やうるさい奴らと一緒に行かせておけばいいんだ、君が言ったように！"


translate japanese e2s2_da81affe_1:


    julia "はは！それじゃあ、マディーとのポイントが稼げてるね！双子と一緒じゃない方が、彼女に受け入れてもらいやすいよ！もっと言うと、彼女たちを無視すればなおさら！"


translate japanese e2s2_5bc0ea87_3:


    d "どうなるか見てみましょう..."


translate japanese e2s2_97eb4ac6:


    julia "とにかく、キャンパスのプールがあります！グレースは午後のほとんどをそこでトレーニングに費やしています。"


translate japanese e2s2_2c11e212:


    julia "彼女がどこにいるかわからないなら… まあ、そこに行くだけで、たぶん彼女を見つけることができるよ！"


translate japanese e2s2_f36a5ff4:


    d "わかった！"


translate japanese e2s2_597f2c85:


    julia "その隣にはジムがあります... 私たちは着替えるためにそこを通りました。そこで主にマディソンを見つけることができます..."


translate japanese e2s2_39b61a84:


    julia "彼女はそこで定期的にトレーニングしています。おそらくスティーブンや他の人たちとも会うでしょう…でもまあ…"


translate japanese e2s2_16c75a70:


    d "そして、あなたはそこに行かないのですか？"


translate japanese e2s2_a4696a89:


    julia "実際に... 授業の合間に... まあ、いいえ、あまり時間はないんです..."


translate japanese e2s2_43b49e4c:


    d "わかりました。"


translate japanese e2s2_58a7c153:


    julia "あそこに大劇場とお店があります... もし洋服が必要なら、近くのパブに行きたいと思っているなら、必要なものはすべて見つかるでしょう。"


translate japanese e2s2_360c3a8e:


    d "わあ、まるでミニ都市のようですね？"


translate japanese e2s2_aeb44433:


    julia "そうですね、そのように見ることができます！でも、あなたに警告しなければなりません...ほとんどのビジネスはエメリック家や双子たちに所有されています..."


translate japanese e2s2_c5e72fc1:


    d "それほどのお金を持っているのだろうか？"


translate japanese e2s2_a55c01fd:


    julia "うーん… ええ、あなたが想像する以上に… でも、彼らの親はお金の価値を学ぶために働かせるんだ、私が理解する限りでは…"


translate japanese e2s2_69793ab9:


    julia "レッドは彼女が管理する衣料品店をきちんと管理し、良いアドバイスを与えます... エメリックについては... 彼の小さな策略はすぐにわかるでしょう..."


translate japanese e2s2_b651150d:


    d "そして青はどうですか？"


translate japanese e2s2_ccd58cdf:


    julia "ああ、彼女はお金にはあまり興味がなく、もっと…そうですね、人間関係に興味があると言えます！"


translate japanese e2s2_df522c84:


    julia "でも、彼女はよく映画館やボウリング場にいます！ それに、チームのためにトレーニングもしているし... 少なくとも、それについて誰も彼女を責めることはできないでしょうね..."


translate japanese e2s2_0aae168a:


    d "あなたはこのすべての中で何をしますか？"


translate japanese e2s2_08822955:


    julia "私？えっと…"


translate japanese e2s2_f526b9a7:


    julia "ああ、さて、図書館に着いたけれど、もう遅くなってきた！"


translate japanese e2s2_ebd88aab:


    julia "ここであなたを置いていかなくてはいけません！もし質問があれば、気軽にメッセージを送ってください！"


translate japanese e2s2_02fcf1f9:


    julia "それに、明日の経済学の授業で会いましょう！"


translate japanese e2s2_c372f1a0:


    d "うん... はい... わかった！"


translate japanese e2s2_09f84ac2:


    julia "じゃあ、また明日ね！"


translate japanese e2s2_df3539f1:


    d "じゃね！"


translate japanese e2s2_f49e8424:


    dpense "奇妙なことに、彼女は自分が何をしているのかについての私の質問に答えなかった..."

translate japanese strings:


    old "Ask about her love life [TEMP1!t]"
    new "彼女の恋愛生活について尋ねる"


    old "Ask about the others [TEMP2!t]"
    new "他の人について尋ねる"


    old "I like Blue [TEMP1!t]"
    new "私は青が好きです [TEMP1!t]"


    old "I don't like Blue [TEMP2!t]"
    new "私は青が好きではない [TEMP2!t]"


    old "I like Red [TEMP1!t]"
    new "私は赤が好きです [TEMP1!t]"


    old "I don't like Red [TEMP2!t]"
    new "私は赤が好きではありません。 [TEMP2!t]"


    old "Visit the swimming pool [TEMP1!t]"
    new "スイミングプールに行く [TEMP1!t]"


    old "Return to my room [TEMP2!t]"
    new "私の部屋に戻る [TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
