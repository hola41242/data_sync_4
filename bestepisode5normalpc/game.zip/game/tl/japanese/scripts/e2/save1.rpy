


translate japanese save1_285f8ea7:


    "ここでゲームを保存してください..."

translate japanese strings:


    old "SAVE NOW"
    new "今すぐ保存"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
