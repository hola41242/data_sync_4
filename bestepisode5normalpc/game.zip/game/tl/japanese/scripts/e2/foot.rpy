


translate japanese foot_edf3fa74:


    dpense "ロッカールームでは、いつも同じルーティンだ..."


translate japanese foot_77a4fd1a:


    dpense "まず左の脚... いつも..."


translate japanese foot_92ec1830:


    dpense "右足は…いつも…"


translate japanese foot_f25f54f9:


    dpense "その後は、目標に集中する時間です。"


translate japanese foot_55095236:


    mad "" with hpunch


translate japanese foot_dd5d68f3:


    d "え？"


translate japanese foot_1c4a0bf9:


    d "ここで何をしているのですか？"


translate japanese foot_43d53e49:


    mad "そうですね、双子が女子更衣室に現れたので、静かな場所が必要です... そして、どうやらあなたは自分だけの更衣室を見つけたようですね..."


translate japanese foot_b782ec56:


    mad "とにかく..."


translate japanese foot_0b9463d0:


    dpense "彼女は本当にここで、私の前で着替えるつもりなのか？"


translate japanese foot_8b891988:


    mad "何？女性を見たことがないのか？"


translate japanese foot_79d25a85:


    d "ええと...はい..."


translate japanese madivestfin_ca733686:


    mad "景色を楽しんでいるのですか？"


translate japanese madivestfin_19e56d79:


    d "さて、あなたはここに入ってきて、私の前でいきなり着替え始めた..."


translate japanese madivestfin_86840f36:


    mad "私たちは同じチームです..."


translate japanese madivestfin_3d0ab973:


    mad "だから、あなたに隠すことは何もない..."


translate japanese madivestfin_9e7fc475:


    dpense "彼女は今、何も隠していないようだ..."


translate japanese madivestfin_e98c80dd:


    dpense "彼女は本当に美しい..."


translate japanese madivestfin_97bbdea9:


    dpense "そして彼女はとても運動神経がいい... 彼女と対戦したくないな..."


translate japanese madivestfin_8ebf33b9:


    mad "さあ、始めましょう..."


translate japanese madivestfin_b1351d09:


    mad "ところで、今の魅力的な子は誰？"


translate japanese madivestfin_dd5d68f3:


    d "え？"


translate japanese madivestfin_315b4afb:


    mad "..."


translate japanese madivestfin_cc1af243:


    dpense "ああ、わかった！彼女を以前のルビーと比較したことが、彼女を私のところに来させたんだ... 彼女は競争心が強くて、それが彼女に影響を与えている..."


translate japanese madivestfin_f64c111a:


    dpense "心配しないで、マディソン…君は美人だ…それは間違いない…"


translate japanese madivestfin_49c50de8:


    d "行こう..."


translate japanese madivestfin_b7bc84a3:


    d "勝つための試合がある..."


translate japanese madivestfin_d5ab1f7c:


    mad "はい、女の子たち！準備はできていますか！"


translate japanese madivestfin_ed845cf0:


    ruby "もちろん！！！"


translate japanese madivestfin_b7fd8669:


    mad "最初の試合が終わったようです..."


translate japanese madivestfin_a571c092:


    julia "うん、スティーブンは最初の試合に勝った。"


translate japanese madivestfin_591e2cd8:


    grace "エメリックも勝ったようだ。"


translate japanese madivestfin_acf1a1cf:


    d "対戦相手のチームを知っていますか？"


translate japanese madivestfin_06aad2a0:


    mad "いいえ... 誰が気にするの？"


translate japanese madivestfin_193370d4:


    mad "一つの目標：勝つこと！"


translate japanese madivestfin_248a945d:


    mad "言うことを聞けば、楽になるよ。"


translate japanese madivestfin_2ea87172:


    mad "ボールを手に入れたらすぐに前に出てきて。"


translate japanese madivestfin_7bcc50f4:


    d "わかりました..."


translate japanese madivestfin_9a0db5cc:


    orushi "" with hpunch


translate japanese madivestfin_7a5e14ed:


    orushi "3ポイントを先に獲得したチームが勝ち..."


translate japanese madivestfin_95a00a65:


    orushi "ゴールキーパーがいない…"


translate japanese madivestfin_69b2f6c3:


    orushi "あなたはサッカーのフィールドの半分でプレイすることになります。"


translate japanese madivestfin_0d205797:


    orushi "アルファベット順で最初のチームがキックオフします。"


translate japanese madivestfin_b2a4838f:


    orushi "最良いチームが勝ちますように。"


translate japanese madivestfin_af49f050:


    d "行こう..."


translate japanese madivestfin_84270059:


    dpense "ジュリアは彼女に突進する..."


translate japanese madivestfin_7889bc98:


    dpense "何？？？"


translate japanese madivestfin_8c16a232:


    dpense "彼女は遠慮しなかった..."


translate japanese madivestfin_2d685b93:


    dpense "マディソンが言った：ボールを持ったら、前に進む..."


translate japanese madivestfin_eee1b7c6:


    dpense "そう..."


translate japanese madivestfin_271b982b:


    dpense "前に進む..."


translate japanese madivestfin_9e7f43f3:


    dpense "彼女はルビーにボールを渡す..."


translate japanese madivestfin_0eb8144f:


    dpense "いいコントロール..."


translate japanese madivestfin_51704437:


    dpense "彼女はそれを私に渡している…"


translate japanese madivestfin_b23ca261:


    dpense "私の番だ..."


translate japanese solofoot1_0582ace2:


    dpense "そうですね…"


translate japanese solofoot1_91496986:


    dpense "左..."


translate japanese solofoot1_0582ace2_1:


    dpense "そうだ..."


translate japanese solofoot1_3730c4c4:


    dpense "そして左！！！"


translate japanese solofoot1_de6164a3:


    dpense "さあ、最初の得点を取らなければならない！"


translate japanese solofoot1_b3487855:


    d "" with hpunch


translate japanese solofoot1_753e42ba:


    d "はい！"


translate japanese solofoot1_e67fad0e:


    ruby "よくやった[name]！"


translate japanese solofoot1_974b328e:


    orushi "0 - 1 チームHのために..."


translate japanese solofoot1_a6cdb1f6:


    orushi "チームH、あなたの出番です…。"


translate japanese solofoot1_717cf009:


    d "くそ..."


translate japanese solofoot1_c13d8579:


    d "Huh ???"


translate japanese solofoot1_b2eece69:


    mad "ひゃあああああああ…"


translate japanese solofoot1_761a446b:


    mad "はい！"


translate japanese solofoot1_16f3fcc2:


    mad "そしてそれは1です！"


translate japanese solofoot1_974b328e_1:


    orushi "0 - 1 チームHのために..."


translate japanese solofoot1_a6cdb1f6_1:


    orushi "チームH、あなたの出番です..."


translate japanese juliafoot1_47bd8943:


    d "ジュリア！あなたのために！"


translate japanese juliafoot1_f832f206:


    dpense "彼女はジャグリングしている???"


translate japanese juliafoot1_66f71455:


    julia "ホップ！"


translate japanese juliafoot1_66f71455_1:


    julia "ホップ！"


translate japanese juliafoot1_ce3a9306:


    dpense "それは高いです！"


translate japanese juliafoot1_74847b12:


    dpense "バイシクルキックを試してみるよ！"


translate japanese juliafoot1_a636450b:


    d "" with hpunch


translate japanese juliafoot1_753e42ba:


    d "はい！"


translate japanese juliafoot1_e67fad0e:


    ruby "よくやった[name]！"


translate japanese juliafoot1_974b328e:


    orushi "0 - 1 はチームHにとって…"


translate japanese juliafoot1_a6cdb1f6:


    orushi "チームH、君たちの出番だ..."


translate japanese juliafoot1_6706606d:


    d "高すぎる！！！"


translate japanese juliafoot1_9d037827:


    ruby "ハン !!!!"


translate japanese juliafoot1_753e42ba_1:


    d "はい！"


translate japanese juliafoot1_ec038a82:


    d "よくできたね、ルビー！"


translate japanese juliafoot1_fe9c6c78:


    ruby "それを見た？"


translate japanese juliafoot1_974b328e_1:


    orushi "0 - 1 チームH..."


translate japanese juliafoot1_a6cdb1f6_1:


    orushi "チームH、あなたの出番です..."


translate japanese juliafoot1_c710da6e:


    mad "そして、これが最初の一つです !!!"


translate japanese juliafoot1_753e42ba_2:


    d "はい！"


translate japanese juliafoot1_4f3fd317:


    d "よくやった、マディソン！"


translate japanese juliafoot1_e84315d6:


    ruby "君は強すぎるよ、マディ！"


translate japanese juliafoot1_974b328e_2:


    orushi "0 - 1 はチーム H のために..."


translate japanese juliafoot1_a6cdb1f6_2:


    orushi "チームH、あなたの出番です..."


translate japanese madisonfoot1_c710da6e:


    mad "そして、これが最初のものです！！！"


translate japanese madisonfoot1_753e42ba:


    d "はい！"


translate japanese madisonfoot1_4f3fd317:


    d "よくやった、マディソン！"


translate japanese madisonfoot1_e84315d6:


    ruby "マディ、君は強すぎる！"


translate japanese madisonfoot1_974b328e:


    orushi "チームHに対して0 - 1..."


translate japanese madisonfoot1_a6cdb1f6:


    orushi "チームH、あなたの出番です..."


translate japanese footpart2_8c14bc76:


    mad "私たちの番だから… 全部賭けるよ！"


translate japanese footpart2_8dde1283:


    grace "わかりました！"


translate japanese footpart2_7840c8ac:


    mad "二つ目の目標に向かって行こう !!!"


translate japanese footpart2_a3adb02b:


    dpense "それはフィールドに進む津波だ..."


translate japanese solofoot2_0582ace2:


    dpense "右..."


translate japanese solofoot2_91496986:


    dpense "左に..."


translate japanese solofoot2_0582ace2_1:


    dpense "そうですね..."


translate japanese solofoot2_3730c4c4:


    dpense "そして、左に！！！"


translate japanese solofoot2_27457a03:


    dpense "さあ、もう一度得点しなければなりません！"


translate japanese solofoot2_b3487855:


    d "" with hpunch


translate japanese solofoot2_753e42ba:


    d "はい！"


translate japanese solofoot2_e67fad0e:


    ruby "よくやった[name]！"


translate japanese solofoot2_3d5b715b:


    orushi "0 - 2 チームHのために..."


translate japanese solofoot2_3dca3269:


    orushi "チームD、あなたたちの出番です..."


translate japanese solofoot2_717cf009:


    d "くそ..."


translate japanese solofoot2_c13d8579:


    d "Huh ???"


translate japanese solofoot2_b2eece69:


    mad "ひゃあああああああ..."


translate japanese solofoot2_761a446b:


    mad "はい！"


translate japanese solofoot2_8a0891ca:


    mad "そして、それは2です！"


translate japanese solofoot2_3d5b715b_1:


    orushi "0 - 2 チーム H のために..."


translate japanese solofoot2_3dca3269_1:


    orushi "チームD、あなたたちの出番です..."


translate japanese juliafoot2_47bd8943:


    d "ジュリア！あなたのために！"


translate japanese juliafoot2_f832f206:


    dpense "彼女はジャグリングをしている？？？"


translate japanese juliafoot2_66f71455:


    julia "ホップ！"


translate japanese juliafoot2_66f71455_1:


    julia "ホップ！"


translate japanese juliafoot2_ce3a9306:


    dpense "それは高い！"


translate japanese juliafoot2_74847b12:


    dpense "自転車キックを試してみるよ！"


translate japanese juliafoot2_a636450b:


    d "" with hpunch


translate japanese juliafoot2_753e42ba:


    d "はい！"


translate japanese juliafoot2_e67fad0e:


    ruby "よくやった[name]！"


translate japanese juliafoot2_3d5b715b:


    orushi "0 - 2 チームHに対して..."


translate japanese juliafoot2_3dca3269:


    orushi "チームD、あなたの出番です..."


translate japanese juliafoot2_6706606d:


    d "高すぎる！！！」"


translate japanese juliafoot2_9d037827:


    ruby "ハン！！！！！"


translate japanese juliafoot2_753e42ba_1:


    d "はい！"


translate japanese juliafoot2_ec038a82:


    d "よくやった、ルビー！"


translate japanese juliafoot2_fe9c6c78:


    ruby "それ見た？"


translate japanese juliafoot2_3d5b715b_1:


    orushi "0 - 2、チームHのために..."


translate japanese juliafoot2_3dca3269_1:


    orushi "チームD、あなたたちのターンです…"


translate japanese juliafoot2_4fffecae:


    mad "そして、これは二番目のものです!!!"


translate japanese juliafoot2_753e42ba_2:


    d "はい！"


translate japanese juliafoot2_4f3fd317:


    d "よくやった、マディソン！"


translate japanese juliafoot2_e84315d6:


    ruby "君はあまりにも強すぎる、マディ！"


translate japanese juliafoot2_3d5b715b_2:


    orushi "0 - 2 チームHに..."


translate japanese juliafoot2_3dca3269_2:


    orushi "チームD、あなたの番です..."


translate japanese madisonfoot2_a6e1b431:


    mad "これは第二です!!!"


translate japanese madisonfoot2_753e42ba:


    d "はい！"


translate japanese madisonfoot2_4f3fd317:


    d "よくやった、マディソン！"


translate japanese madisonfoot2_e84315d6:


    ruby "あなたは強すぎる、マディ！"


translate japanese madisonfoot2_3d5b715b:


    orushi "0 - 2 チームHのために..."


translate japanese madisonfoot2_3dca3269:


    orushi "チームD、あなたの出番です…"


translate japanese footpart3_d03c73aa:


    mad "最後の一つだ..."


translate japanese footpart3_8cbe0101:


    d "はい！"


translate japanese footpart3_a5e72e2d:


    mad "[name]?"


translate japanese footpart3_9e4ecabd:


    d "はい？"


translate japanese footpart3_bc560022:


    mad "ボールを持っているとき..."


translate japanese footpart3_fb8a0316:


    mad "私に渡して！"


translate japanese footpart3_7bcc50f4:


    d "わかりました..."


translate japanese footpart3_bcb5c60f:


    mad "勝利を目指そう！！！"


translate japanese footpart3_431e2f0e:


    ruby "やった！！！"


translate japanese footpart3_d85731c5:


    d "いい仕事だ、グレース！"


translate japanese footpart3_5218b90d:


    dpense "トンネル！"


translate japanese footpart3_7bba1598:


    d "スーパースグレース！"


translate japanese Supermad_633b9d24:


    mad "彼らが私をタイガレスと呼ぶ理由を見せてあげる！"


translate japanese Supermad_b707d65c:


    mad "ひゃあああああああああああ！！！！"


translate japanese Supermad_b0b7239e:


    mad "勝利！"


translate japanese Supermad_013aaa82:


    orushi "0 - 3 のチーム H..."


translate japanese Supermad_94a591b5:


    orushi "チームD、あなたたちは失格です..."


translate japanese juliafoot3_47bd8943:


    d "ジュリア！あなたのために！"


translate japanese juliafoot3_f832f206:


    dpense "彼女はジャグリングをしている？？？"


translate japanese juliafoot3_66f71455:


    julia "ホップ！"


translate japanese juliafoot3_66f71455_1:


    julia "ホップ！"


translate japanese juliafoot3_ce3a9306:


    dpense "高いです！"


translate japanese juliafoot3_74847b12:


    dpense "バイシクルキックに挑戦するぞ！"


translate japanese juliafoot3_a636450b:


    d "" with hpunch


translate japanese juliafoot3_753e42ba:


    d "はい！"


translate japanese juliafoot3_e67fad0e:


    ruby "よくやった[name]！"


translate japanese juliafoot3_013aaa82:


    orushi "0 - 3 はチーム H のために..."


translate japanese juliafoot3_94a591b5:


    orushi "チームD、あなたたちは失格です..."


translate japanese juliafoot3_6706606d:


    d "高すぎる！！！"


translate japanese juliafoot3_9d037827:


    ruby "ハン !!!!"


translate japanese juliafoot3_753e42ba_1:


    d "はい！"


translate japanese juliafoot3_ec038a82:


    d "よくやった、ルビー！"


translate japanese juliafoot3_fe9c6c78:


    ruby "それを見ましたか？"


translate japanese juliafoot3_013aaa82_1:


    orushi "0 - 3 チームHのために..."


translate japanese juliafoot3_94a591b5_1:


    orushi "チームD、あなたたちは脱落しました..."


translate japanese juliafoot3_558b89c4:


    mad "そして、これは三番目です！！！"


translate japanese juliafoot3_753e42ba_2:


    d "はい！"


translate japanese juliafoot3_4f3fd317:


    d "よくやった、マディソン！"


translate japanese juliafoot3_e84315d6:


    ruby "マディ、君は強すぎる！"


translate japanese juliafoot3_013aaa82_2:


    orushi "0 - 3 チーム H のために..."


translate japanese juliafoot3_94a591b5_2:


    orushi "チームD、あなたは脱落しました..."


translate japanese solofoot3_0582ace2:


    dpense "うん..."


translate japanese solofoot3_91496986:


    dpense "左..."


translate japanese solofoot3_0582ace2_1:


    dpense "ええと…"


translate japanese solofoot3_3730c4c4:


    dpense "そして、左に！！！！！"


translate japanese solofoot3_27457a03:


    dpense "さあ、もう一度得点しなければならない！"


translate japanese solofoot3_b3487855:


    d "" with hpunch


translate japanese solofoot3_753e42ba:


    d "はい！"


translate japanese solofoot3_e67fad0e:


    ruby "よくやった[name]！"


translate japanese solofoot3_013aaa82:


    orushi "0 - 3のチームH..."


translate japanese solofoot3_94a591b5:


    orushi "チームD、あなたは脱落しました..."


translate japanese solofoot3_717cf009:


    d "くそ..."


translate japanese solofoot3_c13d8579:


    d "Huh ???"


translate japanese solofoot3_b2eece69:


    mad "ひゃああああああああ..."


translate japanese solofoot3_761a446b:


    mad "はい！"


translate japanese solofoot3_c114d736:


    mad "そして、それが3です！"


translate japanese solofoot3_013aaa82_1:


    orushi "0 - 3 チームHのために..."


translate japanese solofoot3_94a591b5_1:


    orushi "チームDは失格です…。"


translate japanese rubyfoot3_0eb8144f:


    dpense "いいコントロール..."


translate japanese rubyfoot3_51704437:


    dpense "彼女はそれを私に渡しています..."


translate japanese rubyfoot3_671485ee:


    d "" with hpunch


translate japanese rubyfoot3_013aaa82:


    orushi "0 - 3 チームHのために..."


translate japanese rubyfoot3_94a591b5:


    orushi "チームD、あなたたちは失格です…。"


translate japanese finfoot1_6ad6f3b2:


    ruby "私たちは勝者です！！！"


translate japanese finfoot1_2ab5c4c9:


    ruby "あはははは！"


translate japanese finfoot1_44bcfc57:


    ruby "私はあなたをとても誇りに思っています..."


translate japanese finfoot1_c4e84b13:


    ruby "ゴールを決めなくても！"


translate japanese finfoot1_b7adf193:


    grace "あなたはゴールを決めた！"


translate japanese finfoot1_7e3496d9:


    julia "そしてもっと..."


translate japanese finfoot1_6468fcae:


    orushi "さて、これでこの試合は終わりです..."


translate japanese finfoot1_e26c5fd2:


    orushi "最高得点者は："


translate japanese finfoot1_58254362:


    orushi "生徒[name]!"


translate japanese finfoot1_ecde1b4d:


    orushi "生徒マディソン！"


translate japanese finfoot1_6f88b953:


    orushi "次の試合は月曜日に行われます..."


translate japanese finfoot1_ec91a1bf:


    orushi "それまで... あなたは自由です..."


translate japanese finfoot1_3d52e4e0:


    orushi "伝送終了..."


translate japanese finfoot1_602db608:


    dpense "良いことが行われた..."


translate japanese finfoot1_5b12d403:


    dpense "簡単な試合で、女の子たちは素晴らしかった..."


translate japanese finfoot1_4e366d50:


    dpense "グレースのパス、ジュリアのフットワーク、マディソンのストライク…私はほとんど何もすることがなかった。"


translate japanese finfoot1_9fea8065:


    dpense "次の試合はきっともっと挑戦的なものになるだろう..."


translate japanese finfoot1_f6727475:


    dpense "その間、ロッカールームに戻って..."


translate japanese finfoot1_04e96e05:


    grace "[name] !!!"


translate japanese finfoot1_7a2450db:


    grace "[name] 待って！！！"


translate japanese finfoot1_66d23871:


    d "うーん？"


translate japanese finfoot1_b4ae2579:


    grace "今日は素晴らしかった。。。"


translate japanese finfoot1_6066fac0:


    grace "選択の挑戦の間に..."


translate japanese finfoot1_c8e72772:


    d "私はあまり多くをしなかった；ほとんどブルーが私を助けてくれた...彼女は最後のボールの場所を知っていた..."


translate japanese finfoot1_e74e7001:


    d "どういうわけか分からないけれど、彼女の妹はこれらすべてに不慣れではないような気がする..."


translate japanese finfoot1_0dceca55:


    grace "ああ..."


translate japanese finfoot1_b6e71a4b:


    grace "あなたはブルーに近い..."


translate japanese finfoot1_4d01480f:


    grace "プール、そして今これ..."


translate japanese finfoot1_7407154a:


    d "私はあまり何もしていませんでした。主にルビーが私を助けてくれました。"


translate japanese gracekiss_3852d8e4:


    grace "目を閉じてください！"


translate japanese gracekiss_dd5d68f3:


    d "え？"


translate japanese gracekiss_c6e0575b:


    grace "目を閉じて..."


translate japanese gracekiss_7bcc50f4:


    d "わかりました..."


translate japanese gracekiss_92b2ae06:


    grace "やりたいことがあるけれど、勇気がない…"


translate japanese gracekiss_92268307:


    d "そのまま、やってみて！"


translate japanese gracekiss_c1f4c969:


    d "私たちはしてはいけない..."


translate japanese gracekiss2_47a2537c:


    grace "目を閉じていると、もっと簡単になるよ…"


translate japanese gracekiss2_7c99e43d:


    d "そう言うなら..."


translate japanese gracekiss2_f091ef9d:


    grace "あなたが来てから、ルビーは幸せそうです..."


translate japanese gracekiss2_6260bdfe:


    grace "ジュリアはすでに髪型を三回変えました..."


translate japanese gracekiss2_a0646cad:


    grace "マディソンでさえも、もっと... 心地よい..."


translate japanese gracekiss2_f338cc08:


    d "あ..."


translate japanese gracekiss2_546e33a9:


    grace "シー..."


translate japanese gracekiss2_bdf56354:


    grace "あなたが私のところで紳士でいてくれた..."


translate japanese gracekiss2_b96a1cba:


    grace "お会いできて嬉しいです..."


translate japanese gracekiss2_bd4d4f9e:


    grace "そして、その結果..."


translate japanese gracekiss2_13938477:


    d "あなたは私にキスしたばかりだ..."


translate japanese gracekiss2_1c603af5:


    grace "うん… そしてそれは素晴らしかった…"


translate japanese gracekiss2_1f9ac873:


    grace "私はとても幸せです！！！自分ができるとは思っていませんでした..."


translate japanese gracekiss2_6413d69a:


    d "あなたを見てから、そうしたいと思っていたことは知っているでしょう？"


translate japanese gracekiss2_e287c813:


    grace "おお？"


translate japanese gracekiss2_6bb9c921:


    grace "今、あなたは望むときにそれをすることができます..."


translate japanese gracekiss2_95aeacb1:


    d "その場合は..."


translate japanese gracekiss2_cd952255:


    dpense "彼女の心臓がこんなにも強く鼓動しているのを感じる…"


translate japanese gracekiss2_59e2f283:


    dpense "心配しないで、グレース。私はあなたの面倒を見るから..."


translate japanese gracekiss2_50c94879:


    dpense "あなたは私が今まで出会った中で最も美しい女性です…。"


translate japanese gracekiss2_e81a6af4:


    dpense "そして、あなたは他の人のことを考えすぎて、自分のことを忘れてしまう…"


translate japanese gracekiss2_eaf4b947:


    dpense "あなたのためにそこにいるよ..."


translate japanese gracekiss2_aa15d993:


    grace "それは...予想外だった..."


translate japanese gracekiss2_06891b96:


    grace "でもとても心地よいです！"


translate japanese gracekiss2_ac69ed09:


    grace "行かなければならない... また明日？ 授業で？"


translate japanese gracekiss2_729e449c:


    d "うん！もちろん！"


translate japanese gracekiss2_75e8238f:


    grace "ああ！明日のパーティーを忘れないでね！"


translate japanese gracekiss2_93c9e4c4:


    d "心配しないで！私はしないよ！"


translate japanese gracekiss2_27aa1aac:


    dpense "この女神と一緒だなんて信じられない..."


translate japanese gracekiss2_3161a1f9:


    dpense "私はなんて運がいいんだろう..."


translate japanese gracekiss2_b1ca8c29:


    dpense "さて… 更衣室に戻る…"


translate japanese gracekiss2_f738d3eb:


    beth "くそ..."


translate japanese graceleave_42f3466f:


    grace "あああ... ふむ... 私は出かけるべきだ、明日のパーティーのためにやることがいくつかある…"


translate japanese graceleave_f0404ad6:


    grace "朝の授業で会いましょう！"


translate japanese graceleave_32a25851:


    d "ああ…わかった！明日会いましょう！"


translate japanese graceleave_9ab62b43:


    beth "いい仕事だ、妹よ..."


translate japanese vestiairesfinep21_78c32f4b:


    d "くそっ、私たちは本当に彼らを見せつけた！"


translate japanese vestiairesfinep21_50a8bffb:


    d "そして、君たち、本当に素晴らしかった！"


translate japanese vestiairesfinep21_9686d4b0:


    mad "まぁ..."


translate japanese vestiairesfinep21_92a2ff53:


    d "でも本当に… あなたがこんなに上手だとは教えてくれなかった！"


translate japanese vestiairesfinep21_c8be3d53:


    mad "それはゲームだった... まあ、実際にはゲームとも呼べないだろう..."


translate japanese vestiairesfinep21_8fb1935d:


    mad "次は、全く違ったものになるだろう..."


translate japanese vestiairesfinep21_4775cd63:


    d "うん、でもそれでもお祝いできないの？"


translate japanese vestiairesfinep21_e7a937db:


    mad "どうぞ、ご自由に！"


translate japanese madinocalin_60533d2e:


    mad "え？あなたはここで何をしているの？"


translate japanese madinocalin_ce1c3eb9:


    d "さて、祝賀です！"


translate japanese madinocalin_8a203556:


    mad "うん、うん... またね..."


translate japanese madinocalin_8b684304:


    d "やあ！！！"


translate japanese madinocalin_20da34d0:


    d "彼女と一緒にいるのは簡単ではない..."


translate japanese madicalin_60533d2e:


    mad "え？あなたはここで何をしているのですか？"


translate japanese madicalin_c4470e54:


    d "チームの祝賀会ですか？"


translate japanese madicalin_750fd072:


    mad "そんな風に私にくっついていなければいけないの？"


translate japanese madicalin_465fafd7:


    d "一度手を放して... マディソン..."


translate japanese madicalin_5e6bf0de:


    mad "いいえ、ごめんなさい…双子の一人が現れて、もっと人が関わる何かを提案する前に離れたいです…"


translate japanese madicalin_29ac5843:


    d "何？"


translate japanese madicalin_ab00b208:


    mad "うん、うん…また後で…"


translate japanese madicalin_20da34d0:


    d "彼女と一緒にいるのは簡単ではない..."


translate japanese madicalin_c181cb06:


    mad "手放したくないんだ、[name]..."


translate japanese madicalin_de693696:


    mad "私の人生はこんなにぐちゃぐちゃで、今は何も誰も入れることができない…"


translate japanese madicalin_5bc827e8:


    mad "私は娘がいて、勉強があって、競争があって…何も私の…を妨げることはできない。"


translate japanese madicalin_b8eee199:


    d "あなたは一人じゃない..."


translate japanese madicalin_f741ec0e:


    d "あなたの生活を壊すつもりはありません..."


translate japanese madicalin_94ca423a:


    d "でも、もっと良くすることができる…。"


translate japanese madicalin_c17d8f33:


    mad "はい..."


translate japanese madicalin_fdaf3f91:


    mad "いいえ..."


translate japanese madicalin_c5fd0efd:


    mad "私は..."


translate japanese madicalin_c03bb58e:


    mad "できない..."


translate japanese madicalin_7bcf0972:


    d "心配しないで..."


translate japanese madicalin_090f161d:


    d "時間があります..."


translate japanese madicalin_81715ab7:


    mad "ごめんなさい..."


translate japanese madicalin_19ce0e7d:


    d "さて、お風呂に行ってきます... また後で会いましょうか？"


translate japanese madicalin_81d27177:


    mad "うん？ああ、もちろん･･･。"


translate japanese madicalin_11ca4429:


    mad "ああ、もうたまらない！"


translate japanese finmadi1_c822e579:


    d "いいえ... これは冗談ですか？"


translate japanese finmadi1_6ff07c76:


    mad "シッ！聞いて、私は朝からストレスがたまっていて、これを全部終えた後、私は…"


translate japanese finmadi1_6693d960:


    mad "緊張を解消する必要がある..."


translate japanese finmadi1_0d3b5304:


    mad "あなたが何を言っているかわかる？"


translate japanese finmadi1_b615c5d1:


    mad "だから、選択肢がある。私が去るか、それともここで終わるか…。"


translate japanese finmadi1_2673ba73:


    mad "一緒に少し楽しもう… あなたと私で…"


translate japanese finmadi1_810f749f:


    mad "もちろん… 誰にもこのことを知られてはいけません… そして、これは二度と起こりません…"


translate japanese finmadi2_9f8bc5ee:


    mad "それで？"


translate japanese madifin3_b270a0dd:


    mad "なんて失望だ..."


translate japanese madifinep2_2f645723:


    mad "時間を無駄にするな..."


translate japanese madifinep2_078053e8:


    mad "うーん？もう準備ができているんだね、いいね！"


translate japanese madifinep2_b95efa92:


    d "私は..."


translate japanese madifinep2_f4645ac0:


    mad "シーッ..."


translate japanese madifin4_d89d51b4:


    mad "そのまま [name] ! 何ができるか見せてみて!"


translate japanese madifin4_32d6db02:


    dpense "この女の子..."


translate japanese madifin4_6c713e31:


    mad "行け！私は砂糖でできているわけじゃない！"


translate japanese madifin4_927f3cd3:


    dpense "わあ… 彼女はきつい！"


translate japanese madifin4_49060b46:


    dpense "そして、めちゃくちゃ濡れてる！"


translate japanese madifin4_3d93f24b:


    mad "いけ！[name]！もっと強く！"


translate japanese madifin4_c17d8f33:


    mad "はい..."


translate japanese madifin4_416ec5fe:


    mad "深く..."


translate japanese madifin4_acad3ae3:


    mad "ふむ…"


translate japanese madifin4_9e1bdebf:


    mad "そのように... 続けて..."


translate japanese madifin4_f1befcce:


    mad "うーん… あなたは本当に悪くないね…"


translate japanese madifin4_17fb853f:


    mad "あなたの運動能力を見せてくれたらどうなる？"


translate japanese madifin4_3e6ca67f:


    d "どうやって？"


translate japanese madifin4_422353fa:


    mad "抱きしめて！"


translate japanese madifin4_bab45b3d:


    mad "ああ、くそ... そうだ!!!"


translate japanese madifin4_1777b9bc:


    dpense "そのおまんこ… ますます私を吸い込んでいく…"


translate japanese madifin4_83b4bb13:


    mad "また[name]… それはとてもいい!!!"


translate japanese madifin4_1684842c:


    dpense "彼女は震えている・・・"


translate japanese madifin4_2c3d8a59:


    mad "ああ、神様... 私は非常に近い..."


translate japanese madifin4_25f65b46:


    dpense "私はあまり遅れていません..."


translate japanese madifin4_4a3e4891:


    mad "ハンプフ… 続けて [name]！"


translate japanese madifin4_acb8f6a1:


    mad "今すぐ止まらないで！"


translate japanese madifin4_245419c3:


    mad "もう一度！はい！もう一度！"


translate japanese madifin4_79ea7920:


    mad "もっと欲しい！私は…"


translate japanese madifin4_f56eba72:


    mad "ああああああああ！"


translate japanese madifin4_01a01d80:


    mad "はい！"


translate japanese madifin4_4a3f086d:


    mad "ああ、くそ... [name]!"


translate japanese madifin4_b1bb593b:


    mad "あなた... ハンプフ..."


translate japanese madifin4_ebf39002:


    mad "私は... フシュッ..."


translate japanese madifin4_00957e17:


    d "言葉を失った？"


translate japanese madifin4_afde25b0:


    mad "シー！！！"


translate japanese madifin4_ebaedda5:


    mad "終わってないの？"


translate japanese madifin4_30073e1f:


    d "いいえ..."


translate japanese madifin4_e95eef45:


    mad "はい..."


translate japanese madifin4_65a9f185:


    mad "私の胸にやってくれ..."


translate japanese madifin4_2461ad76:


    mad "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese madifin4_2c536cc9:


    d "くそ..."


translate japanese madifin4_a0f73616:


    mad "わぁ... なんてことだ..."


translate japanese madifin4_1789fa85:


    mad "エルク…"


translate japanese madifin4_9f65972f:


    mad "洗いに行くべきだ..."


translate japanese madifin4_4d84113c:


    d "私のシャワーを使ってもいいよ... 私は終わった..."


translate japanese madifin4_c7ec2d67:


    mad "いいえ... 匂う... セックス..."


translate japanese madifin5_2c0f470e:


    mad "[name]、ありがとう..."


translate japanese madifin5_eec57c4e:


    d "うーん… どういたしまして？"


translate japanese madifin5_d3fe6a33:


    mad "ああ、そして..."


translate japanese madifin5_08958e67:


    mad "もちろん… これは一度きりのことです！"


translate japanese madifin5_bb54c687:


    mad "考えを起こさないで..."


translate japanese madifin5_595996da:


    d "もちろん..."


translate japanese chambrefinep2_98fa4014:


    d "メッセージ？"


translate japanese chambrefinep2_084c58a1:


    d "ただ待つだけ..."


translate japanese chambrefinep2_9ddb6277:


    eli "見えますか？"


translate japanese chambrefinep2_753e42ba:


    d "はい！"


translate japanese chambrefinep2_d3d73219:


    eli "良い！"


translate japanese chambrefinep2_d4678439:


    eli "お会いできて嬉しいです！"


translate japanese chambrefinep2_887162e1:


    d "あはは… 私も一週間変わってないよ、知ってる！"


translate japanese chambrefinep2_92bc22ab:


    eli "でも、私は私たちの電話が恋しい！"


translate japanese chambrefinep2_76cbae2d:


    d "まあ、そうだね..."


translate japanese chambrefinep2_fa662e80:


    eli "アメリカはどうですか？"


translate japanese chambrefinep2_c28f2eeb:


    dpense "私は彼女にアカデミーやB.E.S.Tについてすべて話します。最初から起こったすべてのこと。"


translate japanese chambrefinep2_7f489c26:


    eli "わあああ.... なんて物語なんだ！"


translate japanese chambrefinep2_2c010a8b:


    eli "ちょっと待って、ベッドに入ってるところだ！"


translate japanese chambrefinep2_1c33c8d8:


    eli "女の子と会った？"


translate japanese chambrefinep2_19b0c6a9:


    d "飛行機で何人かの女の子に出会った..."


translate japanese chambrefinep2_84caaeb8:


    d "私は一人を触りました... ジュリア... なぜかわからないけど、彼女が私の前にいたとき... 私の手は彼女のお尻に引き寄せられました..."


translate japanese chambrefinep2_7be37bab:


    d "双子の一日目、私に話しかけてきた... 一人は青く、もう一人は赤い..."


translate japanese chambrefinep2_7f66895f:


    d "青い子は私を感心させようとした..."


translate japanese chambrefinep2_37ba556f:


    d "赤い奴が俺に挑戦しようとした..."


translate japanese chambrefinep2_f25609de:


    d "それから、私はB.E.S.Tの最初の試験を行いました："


translate japanese chambrefinep2_474f9baa:


    d "ルビー..."


translate japanese chambrefinep2_dd120e78:


    d "ジュリア..."


translate japanese chambrefinep2_b59160c0:


    d "グレース..."


translate japanese chambrefinep2_362c6bb7:


    d "マディソン..."


translate japanese chambrefinep2_1e1a4d94:


    d "それはチームワークにおける障害物コースだった..."


translate japanese chambrefinep2_05518b79:


    d "もう少しで挑戦に勝てそうだった..."


translate japanese chambrefinep2_d5d4cd8f:


    d "シャワー中のロッカールームで... 青い双子が来て、私にご褒美としてフェラチオをしてくれた..."


translate japanese elisechoix1_3f8b2dfe:


    eli "いいえ！！！本気ですか？？"


translate japanese elisechoix1_fb0ebc6a:


    d "うん！彼女が到着したとき、ちょうどシャワーを終えたところだった！"


translate japanese elisechoix1_4cf39263:


    eli "なんて淫乱な女なんだ！"


translate japanese elisechoix1_1be7b02e:


    d "うーん... はいといいえ..."


translate japanese elisechoix1_9e7b4d66:


    eli "あれ？"


translate japanese elisechoix1_d109ff97:


    d "うん… 彼女は競技中に私を助けたいと思っているみたいだ…"


translate japanese elisechoix1_338d1bf8:


    d "なぜか分からないけど..."


translate japanese elisechoix1_dd3f6e7e:


    d "ロッカールームでシャワーを浴びている時に…。赤い双子が来て、フレンチキスを試みるのはめちゃくちゃ熱かった…。"


translate japanese elisechoix1_f80dcac7:


    eli "いいえ !!!! 冗談でしょうか？？"


translate japanese elisechoix1_fb0ebc6a_1:


    d "うん！彼女が到着したとき、ちょうどシャワーを終えたところだった！"


translate japanese elisechoix1_4cf39263_1:


    eli "なんてやつだ！"


translate japanese elisechoix1_1be7b02e_1:


    d "うーん… はいといいえ…"


translate japanese elisechoix1_9e7b4d66_1:


    eli "ああ？"


translate japanese elisechoix1_800edf68:


    d "うん… 彼女は競争中に私を支配したいと思っているようだ…"


translate japanese elisechoix1_495acc95:


    d "有利にするために何か..."


translate japanese elisechoix1_5d359f5f:


    d "それから、女の子たちと公園に行った..."


translate japanese elisechoix1_91070114:


    d "彼らは私に、どちらが私のお気に入りか尋ねてきた..."


translate japanese elisechoix1_42f94226:


    d "いつものように女の子の会話を知ってるね..."


translate japanese elisechoix1_f55bccd2:


    d "だから、[chosen]が私の好きなものだと言った..."


translate japanese elisechoix1_3bcb4400:


    eli "ああ！彼女は何と言ったの？"


translate japanese elisechoix1_fbda1389:


    d "彼女は幸せだった..."


translate japanese elisechoix1_4f9791c5:


    d "私はミルフに対するフェティッシュがあると彼らに言った..."


translate japanese elisechoix1_c4db2015:


    eli "すごい、すごい、すごい... どうしてこんな議論に至ったの？"


translate japanese elisechoix1_2e3da88b:


    d "さて、ルビーが私たちにビジュアルノベルについてのカンファレンスを開いてくれました…"


translate japanese elisechoix1_79eea45f:


    eli "何？"


translate japanese elisechoix1_54910736:


    d "うん… いいえ… まあ… 主題はプレイヤーの kink についてで、彼女はミルフについて何か言っていました…"


translate japanese elisechoix1_3ffd0020:


    eli "うーん... いいよ..."


translate japanese elisechoix1_ecd08031:


    d "それから彼らは、とても美しい女性である彼らの先生について話しましたが、彼女は一人でいるようです...それか何かそんな感じの..."


translate japanese elisechoix1_49a107c8:


    d "そして、彼らは彼女が私のミルフになることを決めた..."


translate japanese elisechoix1_8ea2ff1f:


    eli "彼らは狂っているのか？"


translate japanese elisechoix1_22f739b2:


    d "うん、少し…"


translate japanese elisechoix1_2c7d82fe:


    d "それから、プールでガブリエラに会った・・・先生・・・"


translate japanese elisechoix1_8098008c:


    d "そして、青い双子に出会い、彼女に何らかの支配的な紹介をしました..."


translate japanese elisechoix2_1bcb5e64:


    eli "冗談でしょう？"


translate japanese elisechoix2_aa10cf4e:


    d "いいえ！私は誓った！彼女に噴き出させると約束したんだ、そして…"


translate japanese elisechoix2_33642f58:


    eli "本当に？？？"


translate japanese elisechoix2_f7ccf4f5:


    d "はい！指だけで！"


translate japanese elisechoix2_21ea0582:


    eli "おおお...."


translate japanese elisechoix2_f3ed2fab:


    d "彼女はそれが好きで、だから彼女は今私のことを好きだと思う。最後の試練の時、彼女は私を助けようとしたから..."


translate japanese elisechoix2_fb014fc8:


    eli "わかりました..."


translate japanese elisechoix2_709280ee:


    d "私はグレースとのプールでのレースに勝った…今、彼女は私に恩をつかうことになった…"


translate japanese elisechoix2_a1807d52:


    d "私はグレースとのプールでのレースに負けました・・・今、彼女に一つの恩義を返さなければなりません・・・"


translate japanese elisechoix2_0facb3c9:


    d "ルビーは私にジュリアが好きかどうか尋ねたので、私は彼女が面白い女の子だと答えた…"


translate japanese elisechoix2_deca89d1:


    d "昨日の夜、ジュリアからいくつかのメッセージをもらって、私たちは本当に仲良くやっていると思う..."


translate japanese elisechoix2_9b985cdd:


    d "今日はもう大変だったな..."


translate japanese elisechoix2_5ae3d40d:


    d "私はルビー、マディソン、ジュリア、そしてグレースのチームにいました…"


translate japanese elisechoix2_2dfaa29b:


    d "そして、私たちはサッカーの試合をしなければならなかった…。"


translate japanese elisechoix2_a5b05574:


    d "しかし、その前にはどのチームが参加し、どのチームが参加しないかを決めるゲームがあった…"


translate japanese elisechoix2_703a2543:


    d "ブルーのアドバイスを聞いて、ゲームに勝った…彼女に恩がある…"


translate japanese elisechoix2_18693a93:


    d "私はルビーの助言を聞いて、ゲームに勝ちました..."


translate japanese elisechoix2_9dbeee40:


    d "それから私たちは試合をしました..."


translate japanese elisechoix2_2554cdce:


    d "私たちは3-0で勝ちました..."


translate japanese elisechoix2_f23ee1c6:


    eli "おめでとうございます！"


translate japanese elisechoix2_11e5e078:


    d "それは簡単な試合だった..."


translate japanese elisechoix2_dae60f7e:


    d "次の相手が誰になるのかわからない…"


translate japanese elisechoix2_70a656e9:


    d "試合の後、グレースが私のところに来てキスをした..."


translate japanese elisechoix2_3dfc3e36:


    d "それは素晴らしかった…"


translate japanese elisechoix2_5c8d2710:


    eli "誰かはすでに恋に落ちていますか？"


translate japanese elisechoix2_0f25a809:


    d "いや…でも…彼女は素晴らしい…"


translate japanese elisechoix2_7d68cce8:


    d "シャワーの中でマディソンは試合の後に興奮し、...そして、ストレスを和らげるために..."


translate japanese elisechoix4_23afa93c:


    d "彼女は私にセックスをするよう頼んできた…"


translate japanese elisechoix4_1fb9e0ec:


    eli "いやあああああ！"


translate japanese elisechoix4_30f1c327:


    d "はい... それは素晴らしかったけど、彼女はそれが一度きりのことだと言ったので..."


translate japanese elisechoix4_b4755b6b:


    eli "うーん… 彼女は私と同じくらい素晴らしかったの？"


translate japanese elisechoix4_cec9ca0d:


    d "それは…違った…心配しないで、君のことを忘れてはいないよ！"


translate japanese elisechoix4_11fe92e0:


    eli "なんてこった... あなたはそこに4日もいるのに、もうたくさんの女の子と遊んでいるのね..."


translate japanese elisechoix4_fc6dea88:


    d "うん..."


translate japanese elisechoix4_3b9f9c32:


    eli "気をつけて、カサノヴァ… さもなければ、悪い結末になるよ…"


translate japanese elisechoix4_a04fa141:


    d "心配しないで！私に任せて！"


translate japanese elisechoix4_8f00470f:


    eli "そうそう... いつもそう言うけど... 最悪だった..."


translate japanese elisechoix4_dc91fc7c:


    eli "まあ... ここは午後11時だから、少し寝なきゃ..."


translate japanese elisechoix4_8f59a387:


    eli "友よ、あなたが恋しいです…"


translate japanese elisechoix4_ecbb90b9:


    d "私もあなたが恋しい…"


translate japanese elisechoix4_a5d0bb79:


    eli "すぐに電話します！"


translate japanese elisechoix4_07f26224:


    d "あなたの電話を待っています！"


translate japanese elisechoix4_1f9b6d8c:


    eli "じゃね！キス！"


translate japanese elisechoix4_1680b1bf:


    d "おやすみ、エリーゼ..."


translate japanese finep2_4c9fc634:


    emerick "彼を大切にしてほしい..."


translate japanese finep2_a202e2f9:


    ji "心配するな... 彼は担架でそのフィールドを去ることになるだろう..."


translate japanese finep2_27c03ada:


    sofia "ああ、いけない..."


translate japanese finep2_1cfb8569:


    sofia "[name]..."

translate japanese strings:


    old "Play solo [TEMP1!t]"
    new "ソロでプレイする [TEMP1!t]"


    old "Pass it to Julia [TEMP2!t]"
    new "ジュリアに渡して [TEMP2!t]"


    old "Pass it to Madison [TEMP3!t]"
    new "マディソンに渡してくれ [TEMP3!t]"


    old "Play with Madison [TEMP1!t]"
    new "マディソンと遊ぶ [TEMP1!t]"


    old "Play with Julia [TEMP2!t]"
    new "ジュリアと遊ぶ [TEMP2!t]"


    old "Play solo [TEMP3!t]"
    new "ソロでプレイする [TEMP3!t]"


    old "Play with Ruby [TEMP4!t]"
    new "ルビーと遊ぶ [TEMP4!t]"


    old "You mean more to me [TEMP1!t]"
    new "あなたは私にとってもっと大切です [TEMP1!t]"


    old "I like her, yes... [TEMP2!t]"
    new "彼女が好きです、はい... [TEMP2!t]"


    old "Let her continue [TEMP1!t]"
    new "彼女に続けさせて [TEMP1!t]"


    old "Give her a hug [TEMP1!t]"
    new "彼女を抱きしめてください [TEMP1!t]"


    old "Leave her alone [TEMP2!t]"
    new "彼女を一人にしておけ [TEMP2!t]"


    old "Accept [TEMP1!t]"
    new "受け入れる [TEMP1!t]"


    old "Ahah ! So funny !"
    new "あはは！面白い！"


    old ":) So how are you ?"
    new ":) えっと、元気ですか？"


    old "Oh wait I will call you !"
    new "あ、待って！呼ぶね！"


    old "?"
    new "？"




translate japanese elisechoix1_7f7c490c:


    d ""


translate japanese elisechoix1_6e07921b:


    d ""


translate japanese elisechoix2_4985cd2f:


    d ""


translate japanese elisechoix4_5cd3c30f:


    eli ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
