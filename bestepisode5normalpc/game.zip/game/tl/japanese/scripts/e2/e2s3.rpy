


translate japanese e2s3_8cbd665b:


    d "これは誰だろう？"


translate japanese e2s3_86bd34e7:


    d "ああ？ もう一つのメッセージ！"


translate japanese e2s3_a25d3f67:


    d "明日までフレッシュでいなきゃ..."


translate japanese e2s3_90146086:


    d "もう一度？"


translate japanese e2s3_4768f182:


    d "今は…休んで！"


translate japanese e2s3_5b2d794b:


    julia "{i}やあ、私はちょうどあなたに会ったばかりだ...{/i}"


translate japanese e2s3_d255241c:


    julia "{i}これはクレイジーだ...{/i}"


translate japanese e2s3_d7f51766:


    julia "{i}でも、私の番号はこれです...{/i}"


translate japanese e2s3_fb89d37b:


    julia "{i}だから、私に電話して、もしかして？{/i}"


translate japanese e2s3_f2f3c377:


    ji "あなたがそんな風に歌っているのを聞くのは初めてだ！"


translate japanese e2s3_d314bb4d:


    julia "え？あの...うん..."


translate japanese e2s3_180aa646:


    ji "その背後には男がいるんだろう？"


translate japanese e2s3_4d6deba1:


    julia "何ですって？… いいえ、全然違います… 何を想像しているのですか？"


translate japanese e2s3_8aa0c3dd:


    ji "さあ、やめてくれ... あなたがこんなに明るくて元気そうなのは見たことがない！"


translate japanese e2s3_af5b50d7:


    ji "友達がある男のことで興奮しているのがわかります！"


translate japanese e2s3_d6003cdf:


    julia "まあ、何でもないよ……ただ会った男の人なんだ……"


translate japanese e2s3_b00a0896:


    ji "彼はどんな人なの？"


translate japanese e2s3_74703c30:


    julia "シャーロット！！！"


translate japanese e2s3_66671b48:


    cha "何が問題なの？？？ 彼はあなたの目を引くほど本当にかっこいいに違いない！"


translate japanese e2s3_1f425e96:


    julia "うーん... そうでもないかな... わからない... ただ彼が好きなだけなんだ..."


translate japanese e2s3_dcdc0b5a:


    cha "彼があなたをどう思っているか、わかりますか？"


translate japanese e2s3_a02e67e4:


    julia "彼は私のことが好きだと思うけれど、確信はない..."


translate japanese e2s3_22afcde9:


    cha "素晴らしい！さあ、これで…ミスは大舞台に足を踏み入れています！"


translate japanese e2s3_68ae02f5:


    julia "何を意味していますか？"


translate japanese e2s3_4f013c56:


    cha "それをはっきり言ってほしいの？"


translate japanese e2s3_dfd7962c:


    cha "男... 女... 恋をしている..."


translate japanese e2s3_23330d4b:


    julia "ああ、やめて... まだそこには行ってない..."


translate japanese e2s3_67660424:


    cha "彼に会うのが本当に楽しみなんだ、わかる？"


translate japanese e2s3_81c2222a:


    cha "あなたがこの状態にいるためには、それだけの価値があるはずだ..."


translate japanese e2s3_c66bfef3:


    julia "あなたはおそらく彼にどこかの時点で会うでしょう..."


translate japanese e2s3_0c163247:


    cha "うん…じゃあ、あそこにいる男たちのテーブルのことをお願いね。私はお金を数えてくるから！"


translate japanese e2s3_6fd36bef:


    julia "そうですね..."


translate japanese e2s3_6c28afa2:


    julia "彼は私を友達としてしか見ていないと思う..."


translate japanese e2s3_a5f1e4b2:


    cha "おお、ちょっと待って... それは良いスタートじゃないね..."


translate japanese e2s3_8e8b945d:


    julia "正直に言うと、これはあまり始まりではないんですよね…。"


translate japanese e2s3_d76c7bb5:


    cha "それでも、彼があなたが言うほど素晴らしいなら、彼に会いたいです！"


translate japanese e2s3_81c2222a_1:


    cha "この状態にいるということは、それだけの価値があるに違いない…。"


translate japanese e2s3_c66bfef3_1:


    julia "おそらく、どこかのタイミングで彼に会うことになるでしょう…"


translate japanese e2s3_0c163247_1:


    cha "うん… じゃあ、あちらの男たちのテーブルを見てくるよ。私はお金を数えてくるから！"


translate japanese e2s3_6fd36bef_1:


    julia "さて…"


translate japanese e2s3_87bd76d0:


    julia "申し訳ありませんが、紳士たち、閉店します..."


translate japanese e2s3_7fc2e979:


    ji "顧客は常に正しい、そう言われてるじゃないか？"


translate japanese e2s3_68ae02f5_1:


    julia "どういう意味ですか？"


translate japanese e2s3_13e15321:


    ji "ここに留まると決めたら、みんなもそのつもりだよね？"


translate japanese e2s3_7cf02106:


    ji "うん！！！"


translate japanese e2s3_97b1d9f0:


    julia "聞いて、私はただあなたに去ってもらって、家に帰りたいだけなの..."


translate japanese e2s3_ca5bec71:


    ji "私たちはあなたが何を望んでいるかなんて気にしない！"


translate japanese e2s3_d67f447b:


    ji "申し訳ありませんが、そのリクエストにはお応えできません。"


translate japanese e2s3_7cf02106_1:


    ji "やった！！！"


translate japanese e2s3_ffae4ead:


    s "みんな、出て行け... 女の方の言ったことを聞いたか..."


translate japanese e2s3_8d0a4594:


    ji "でも、あのさ！彼女が私たちにフラートしてるのは彼女なんだ..."


translate japanese e2s3_8be1c017:


    s "出て行け！"


translate japanese e2s3_f5928430:


    ji "わかった、キャプテン！私たちに叫ぶ必要はない！！！"


translate japanese e2s3_87ed5711:


    ji "そしてお前も、これで終わりじゃないぞ..."


translate japanese e2s3_70b956e4:


    s "ごめん、ジュリア… 彼らは緊張している…"


translate japanese e2s3_4e619f92:


    julia "はい..."


translate japanese e2s3_d5176ae5:


    s "彼らを責めないでください... もし彼らがさらに問題を起こすなら、私に教えてください..."


translate japanese e2s3_d1f70c04:


    julia "..."


translate japanese e2s3_35115fe7:


    cha "彼はここで何をしているのですか？"


translate japanese e2s3_9f36931f:


    julia "彼は彼のギャングを集めるために来た...おそらく彼らは練習するつもりだ..."


translate japanese e2s3_4344ba5b:


    cha "この時間に？"


translate japanese e2s3_683a7314:


    julia "そうですね... 彼らはシーズンの終わりに悪い結果を出したので、それを挽回したいと思っているんです..."


translate japanese e2s3_7bdd87db:


    cha "彼らの中には奨学金を失うかもしれない者もいる！"


translate japanese e2s3_ff51750b:


    julia "それは可能です..."


translate japanese e2s3_52b4eed6:


    cha "その新しい衣装はとても多くを露出している..."


translate japanese e2s3_6a2ae747:


    julia "古いものは使えないの？"


translate japanese e2s3_fc9ea268:


    cha "ボスの言う通りだ... 新しいお客様を惹きつけるために、これを着なければならない..."


translate japanese e2s3_81e60c5f:


    julia "うん... でも..."


translate japanese e2s3_b092efff:


    cha "行こう、さあ..."


translate japanese e2s3_51e8bb06:


    julia "はい..."


translate japanese e2s3_1b483561:


    cha "その謎の stranger について、私に知らせてくれるよね？"


translate japanese e2s3_d2da4b5a:


    julia "うん…心配しないで…"


translate japanese e2s3_0c4885c6:


    cha "明日、あなたはシフトの始まりに一人になるでしょう！私は夕方の中頃にそこにいるつもりです。"


translate japanese e2s3_aa414997:


    cha "明日の夜までに会計を終わらせる必要がある..."


translate japanese e2s3_5713d02d:


    julia "大丈夫... 私はここにいる..."


translate japanese e2s3_d1651a03:


    cha "また明日！"


translate japanese e2s3_6dcbeedd:


    julia "じゃね。"


translate japanese e2s3_8c94c5fe:


    julia "もう寒くなっているに違いない..."


translate japanese e2s3_a116ebc2:


    julia "そして私のコーヒー..."


translate japanese e2s3_ef9f765d:


    julia "くそっ、高いヒール..."


translate japanese e2s3_0e1e2253:


    julia "明日、私は juggling しなければならない… 授業、レストラン…"


translate japanese suitejuliatel_20ab69a7:


    julia "彼は私にメッセージを送っていない..."


translate japanese suitejuliatel_2a8582c3:


    julia "彼にメッセージを送るべきかな？"


translate japanese suitejuliatel_5a09cb73:


    julia "くそ、今回はどうすればいいのかもわからない…"


translate japanese suitejuliatel_63632687:


    julia "私は本当に無知です..."


translate japanese suitejuliatel_aa8e4281:


    julia "じゃあ、挑戦してみよう..."


translate japanese suitejuliatel_5dcbb5c3:


    julia "こんにちは！"


translate japanese suitejuliatel_d247e240:


    julia "こんにちは... もっと間抜けな始まり方はないのかな..."


translate japanese suitejuliatel_593e1a4d:


    julia "くそ、彼が返事をした！"


translate japanese suitejuliatel_6e99c3a2:


    julia "私は何をすればいいの？私は何をすればいいの？私は何をすればいいの？"


translate japanese suitejuliatel_14b367ef:


    d "やあ、こんにちは！"


translate japanese suitejuliatel_c57e2904:


    julia "そうですね... 彼もクリシェを使っていますね..."


translate japanese suitejuliatel_edd120a3:


    julia "彼に何と言えばいいのだろう？...「元気？」ああ、それはつまらないな..."


translate japanese suitejuliatel_3d5456ee:


    julia "良い一日でしたか？"


translate japanese suitejuliatel_2c0993bb:


    julia "いや、それは良くない... まるで彼の母親が話しているみたいだ..."


translate japanese suitejuliatel_3f4f3e80:


    julia "なんてこった..."


translate japanese suitejuliatel_3e3f740c:


    julia "あああ！もう一つのメッセージ！"


translate japanese suitejuliatel_dbb0af3a:


    d "今日は疲れましたが… それでもツアーをありがとう！"


translate japanese suitejuliatel_bbf54d60:


    julia "どういたしまして。"


translate japanese suitejuliatel_fa6876e2:


    julia "何も忘れなかったことを願っています。"


translate japanese suitejuliatel_cca72ab6:


    d "心配しないで、あなたは完璧でした！もし情報が必要なら、誰に聞けばいいか分かります！"


translate japanese suitejuliatel_d6f16a8e:


    julia "うん..."


translate japanese suitejuliatel_f8f06dc3:


    d "わかった、君を寝かせてあげるよ！図書館で過ごすのに疲れたでしょう…"


translate japanese suitejuliatel_40340f5e:


    julia "あなたは想像すらできない..."


translate japanese suitejuliatel_5769e4a9:


    d "おやすみ、ジュリア。"


translate japanese suitejuliatel_5dfa7b90:


    julia "おやすみ、[name]。"


translate japanese suitejuliatel_358c7e0e:


    julia "いいえ、彼は気にしていない..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
