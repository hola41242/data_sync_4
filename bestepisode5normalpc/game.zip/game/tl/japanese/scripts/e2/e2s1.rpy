


translate japanese e2s1_03ecf3cb:


    dpense "わあああ... 今日はなんて日だ！"


translate japanese e2s1_e3368f91:


    dpense "信じられない... 突然現れたこの競争、これらの女の子たち、今日は私の初日で、授業すらなかったのに..."


translate japanese e2s1_981aa673:


    dpense "でも、本当に疲れた... まだこの散らかったものを片付ける必要がある！"


translate japanese e2s1_a576b045:


    dpense "私の電話！ここには連絡先がないな…女の子たちに番号を聞かなきゃ…"


translate japanese e2s1_d23f0865:


    dpense "オーケー... 行こう！"


translate japanese e2s1_96a9da0e:


    d "ここにいます。王になるために生まれた。"


translate japanese e2s1_055fcf24:


    d "私たちは宇宙の王子です。"


translate japanese e2s1_c247cc91:


    d "私は不死です。私の中には王の血が流れています。"


translate japanese e2s1_e19559ea:


    d "{i} 私にはライバルがいない。誰も私と同等になれない。{/i}"


translate japanese e2s1_d16b1e74:


    d "私の世界の未来に連れて行って。"


translate japanese e2s1_ab629bc0:


    ruby "じゃあ、君をライトと呼ばなきゃいけないのか？"


translate japanese e2s1_2f797be5:


    d "な..."


translate japanese e2s1_553923c3:


    ruby "見てみましょう！さあ、荷物を持って、他の人たちが私たちを待っていますよ…"


translate japanese e2s1_b2842d1b:


    d "はい…"


translate japanese e2s1_5949d107:


    ruby "あれ？電話持ってるの？"


translate japanese e2s1_b3a81635:


    d "ああ、そうですね... ここに知り合いがいないので、連絡先は持っていませんが、はい... 電話は持っています..."


translate japanese e2s1_d2c08699:


    ruby "かっこいい！！！待って、スキャンで連絡先を送らせて！"


translate japanese e2s1_44b10ff2:


    d "あ、そうですね。"


translate japanese e2s1_054790de:


    ruby "そうですね… 後でテストして、うまくいくか見てみましょう！"


translate japanese e2s1_da01005d:


    ruby "さあ、他の人たちに参加しましょう！"


translate japanese e2s1_c71a801b:


    d "私は来る..."


translate japanese e2s1_7abb44d8:


    emerick "お会いしたいと言いましたか、おじさん？"


translate japanese e2s1_bec82cb9:


    orushi "はい... 第一回のテストの結果を見ました..."


translate japanese e2s1_474b3cf8:


    orushi "よくやった..."


translate japanese e2s1_0de5a8e8:


    emerick "もちろん！あんな負け犬たちには負けるつもりなんてなかった！"


translate japanese e2s1_fa66421e:


    orushi "十分だ！"


translate japanese e2s1_b14aabed:


    rufus "フシュッッッッッッッッ"


translate japanese e2s1_d933fc72:


    orushi "あなたのバイパーの一匹がバッグを準備するためにこっそり抜け出したのを知っているので、探さずにそれを手に入れればいいだけだ！"


translate japanese e2s1_24ab3896:


    orushi "君は幸運だね、雌トラが彼女のを探している間に！"


translate japanese e2s1_2aaf9bb0:


    orushi "次は、許さないからね！"


translate japanese e2s1_cf4435e1:


    emerick "はい、おじさん..."


translate japanese e2s1_35a7916f:


    orushi "あのフランス人は？まったく悪くなかったな…。"


translate japanese e2s1_9512b329:


    emerick "彼は私に比べてただの弱虫だ..."


translate japanese e2s1_76552bd6:


    orushi "弱者であろうと無かろうと、彼には警戒すべきだ..."


translate japanese e2s1_cd9cde25:


    emerick "私は彼の面倒を見ます..."


translate japanese e2s1_e51d9fe2:


    orushi "次のトーナメントで勝つべきだ..."


translate japanese e2s1_6d3040d9:


    emerick "終わったも同然だ..."


translate japanese e2s1_af86760f:


    ruby "さて、私たちはマディソンが欠けているだけです... 彼女はすぐにここに来るでしょう..."


translate japanese e2s1_7cc5e482:


    julia "彼女が来なくても大丈夫だよ..."


translate japanese e2s1_f02b1c50:


    grace "ジュリア！ちょっと、彼女に優しくしてあげて！彼女は娘の世話で忙しいんだ！彼女がすべてをうまく管理するのが大変なことはわかっているだろう！"


translate japanese e2s1_7ee5c516:


    grace "さらに、彼女の兄は何をしているのか分からない..."


translate japanese e2s1_f12f82c3:


    grace "彼女の両親はいつも彼女に何かを要求している... 私も母と同じ問題を抱えている..."


translate japanese e2s1_d579fcfd:


    grace "いつも言ってる、「グレース、それをするな！グレース、あなたはキャプテンだから、模範を示さなきゃ！」"


translate japanese e2s1_19e030da:


    grace "「グレース、最高の成績を取らなきゃ！」グレース、グレース、グレース…"


translate japanese e2s1_69d97443:


    julia "あなたにとって、それに対処するのは大変でしょうね…。"


translate japanese e2s1_c35ce243:


    grace "いや！！！チームと君たちがいて、少し逃げるための何かがあれば、大丈夫だよ！"


translate japanese e2s1_9f2c3adf:


    grace "ところで、フランスから良いワインを買ったよ…あなたはそれを気に入るはず！！！"


translate japanese e2s1_b47d10ff:


    ruby "何を考えているの？私たちはキャンパスにいるのに！！！"


translate japanese e2s1_e8410113:


    grace "ああ、お願いだよ、ルビー、そんなに冷たいこと言わないで！"


translate japanese e2s1_93b521a5:


    ruby "本当に、グレース、飲みたいならどうぞ…でもここではダメ…"


translate japanese e2s1_7ef21552:


    grace "[name]についてどう思いますか？"


translate japanese e2s1_669f4ba0:


    d "ここで飲んではいけません... 問題を引き起こす可能性があります。"


translate japanese e2s1_6eba75e1:


    grace "はい、片付けます..."


translate japanese e2s1_a933aa2c:


    d "正直に言うと、飲む女性はあまり好きではない..."


translate japanese e2s1_5e9c212e:


    grace "うん、あまりセクシーじゃないね…さて、今夜会いましょう、愛しいボトル…"


translate japanese e2s1_639b4fca:


    d "あなたはそれがあなたの身体的なパフォーマンスに良くないことを知っていますよね？"


translate japanese e2s1_83df6de2:


    grace "ハハ、あなたは私のコーチのように聞こえます！さようなら、ブドウ園からのワイン... こんにちは、プロテイン飲料！"


translate japanese e2s1_ed8c99c0:


    d "私は何をすべきか教えないつもりです... でも時々、プレッシャーを解消するのは気持ちいいです！"


translate japanese e2s1_2d9406be:


    grace "今、この世界がどう動いているか理解している人がいる！でもルビーの言う通り…このボトルをここに置いておくべきじゃない…"


translate japanese e2s1_5a82890d:


    d "誰が... ?"


translate japanese e2s1_1bb364fc:


    dpense "うーん… ポニーテールがないと同じ女性じゃない… わああ！"


translate japanese e2s1_deca88bf:


    mad "なんでみんなそんな風に私を見てるの？私の服に何か付いてるの？"


translate japanese e2s1_db67b519:


    grace "いや!!! 君は素晴らしく見えるよ、マディ…まだ独り身なのが理解できない…"


translate japanese e2s1_d4a4d528:


    mad "自分たちのことを話してくれ、女の子たち！私は面倒を見る子供がいて、避けるべき家族がいて、勝ち取るべき競技会がある..."


translate japanese e2s1_21e11beb:


    mad "他の誰かのための余地はない... それに、この年齢では男たちはこういった問題に関わりたくない... そうだよね[name]?"


translate japanese e2s1_b6cd12ff:


    d "助けが必要な場合、私たちもこれらを管理するのを手伝います... あなたは一人ではありません！"


translate japanese e2s1_53066af2:


    mad "それは優しいですね..."


translate japanese e2s1_694d95bd:


    ruby "彼は明らかに優しいよ！どう思ったの？"


translate japanese e2s1_9d81cd20:


    mad "私は分からない..."


translate japanese e2s1_a114d9b6:


    d "何かアドバイスが必要なら、私はいつでも利用可能です..."


translate japanese e2s1_378658d6:


    mad "子供の教育について知っているからですか？"


translate japanese e2s1_340fa348:


    mad "権力と富を渇望する親たちのための1940年代の危機管理とは？"


translate japanese e2s1_7bc8a915:


    ruby "ねえ！彼は君を襲わなかった!!!"


translate japanese e2s1_dbd14366:


    mad "はい、知っています... 許して [name]..."


translate japanese e2s1_71f3cdde:


    d "我々は競争に集中する必要があり、他のことは我々に影響を与えるべきではない。"


translate japanese e2s1_9bb66f10:


    mad "あなたが正しい... B.E.S.T... チーム... それが大切なんだ..."


translate japanese e2s1_5865f53d:


    ruby "もし最悪の事態が起きても、必要があれば私たちがいるよ！私が君のためにここにいることを知っているだろう！"


translate japanese e2s1_30bbab5f:


    mad "小さな... 君が必要な時にそばにいてくれることは知っている..."


translate japanese e2s1_f1baba71:


    d "こんな不便には全く困らないだろう。"


translate japanese e2s1_f5eabbd4:


    d "結局のところ、誰かと一緒にいたいなら、その人を形作る全てを受け入れることになる！"


translate japanese e2s1_b0cb56e3:


    mad "うーん… 自信があるように聞こえるね… これにどう対処するつもりなのか気になるな…"


translate japanese e2s1_9aba7878:


    d "試してみるまでわからない。"


translate japanese e2s1_c7579901:


    mad "それは本当だ..."


translate japanese e2s1_dc5b375f:


    ruby "私たちに起こっていることはすごいことだ！"


translate japanese e2s1_68ae02f5:


    julia "どういう意味ですか？"


translate japanese e2s1_4acc53b4:


    ruby "さて、みんなのことはわからないけど、私たちは特別な何かを体験している気がする..."


translate japanese e2s1_73fda96c:


    ruby "まるで私たちが何か大きなものの一部であるかのように... 物語、対立... テスト..."


translate japanese e2s1_9e26ec3f:


    ruby "私たちの[name]との出会いも特別だ！彼と飛行機で出会い、彼は私のルームメイトになる。最初の夜はグレースのところで寝る..."


translate japanese e2s1_61df0e42:


    ruby "彼は[chosen]と一緒に最初のB.E.S.Tテストを行い、最後にはほとんど勝利に近づいています！まるで彼はビジュアルノベルのヒーローのようです！"


translate japanese e2s1_d3bb40de:


    julia "それは何ですか？"


translate japanese e2s1_6541b6d1:


    ruby "ビジュアルノベルの英雄！"


translate japanese e2s1_85ec0c6b:


    grace "え？"


translate japanese e2s1_9b5f314f:


    ruby "ビジュアルノベルのヒーロー！"


translate japanese e2s1_6e7805f2:


    mad "A ?"


translate japanese e2s1_8805bde7:


    ruby "ビジュアルノベル！ あなた自身で選ぶ冒険小説！"


translate japanese e2s1_c1835389:


    d "あ！ビジュアルノベルだ！"


translate japanese e2s1_e9754cba:


    ruby "..."


translate japanese e2s1_2fef4c63:


    ruby "そうですね、実際にはアダルトのビジュアルノベルかもしれませんね…"


translate japanese e2s1_2736e21d:


    d "アダルトのビジュアルノベルとは具体的に何ですか？"


translate japanese e2s1_262a0855:


    ruby "ああ、神様、あなたは本当に何も知らないのですか？"


translate japanese e2s1_6443aa2f:


    mad "さて、続けて説明してください！"


translate japanese e2s1_5f285438:


    ruby "わかりました！！！"


translate japanese e2s1_cfb4ca65:


    ruby "ビジュアルノベルは、ストーリーに影響を与える選択をするゲームです..."


translate japanese e2s1_60191ee4:


    ruby "左に行くべきかどうか..."


translate japanese e2s1_d15659ac:


    ruby "そうだね…そしてそれぞれの選択が物語を一つの方向に進める分岐を作るんだ…"


translate japanese e2s1_da182dc0:


    ruby "また別の！"


translate japanese e2s1_f491c4c0:


    ruby "動的ノベルと混同してはいけません。動的ノベルでは、出来事が直線的に進行します。基本的に、動的ノベルでは冒険を体験します..."


translate japanese e2s1_ff85cb50:


    ruby "ビジュアルノベルでは、提示された各選択肢で自分が何をしたいかを決めるので、あなたは立派な俳優です！"


translate japanese e2s1_bec58da1:


    ruby "そして、成人向けビジュアルノベルでは、いくつかのことはより..."


translate japanese e2s1_ce194798:


    ruby "セクシー…"


translate japanese e2s1_4f9373b1:


    ruby "アルコール依存症のような少し難しいトピックや... 中毒... 性に関する質問..."


translate japanese e2s1_8222f50e:


    ruby "時にはさらにねじれたテーマもあります… でも、これ以上の詳細には踏み込まないでおきましょう!!!"


translate japanese e2s1_311c7ed2:


    ruby "大人のビジュアルノベルには従うべき7つのルールがあります！"


translate japanese e2s1_81b67b85:


    d "7つのルールとは何を意味しますか？"


translate japanese e2s1_1a6dede1:


    ruby "まあ、実際にはもっとあるけれど、私は7という数字が好きだから… とにかく！私が説明しているので、私は決めた！"


translate japanese e2s1_012699c5:


    ruby "ルール #1: ヒーローはカリスマがあるべきだ！彼は個性を持っているべきだ！彼は出会うすべての人に足元を見られたり、何にでも「はい」と言ったりしてはいけない..."


translate japanese e2s1_69f1461a:


    ruby "それは[name]に似合っていると思いませんか？"


translate japanese e2s1_c679b986:


    mad "" with hpunch


translate japanese e2s1_b9868f46:


    julia "なぜヒーローはいつも男であることが多いのだろうか？"


translate japanese e2s1_2942cb63:


    ruby "それはいつもそうではありません！英雄が実際にはヒロインであるゲームをたくさん知っています..."


translate japanese e2s1_8cadab8e:


    ruby "しかし、私たちはアダルトセクターにいるので、プレイヤーの大多数は...男...です..."


translate japanese e2s1_9d1ff317:


    mad "それはなぜ[name]があなたの物語の英雄なのかを説明していません..."


translate japanese e2s1_567e0472:


    ruby "マディ..."


translate japanese e2s1_9ea61dc5:


    mad "いいでしょう、続けて！"


translate japanese e2s1_b8d61786:


    ruby "ルール #2: ヒーローは、プレイヤーが彼らに愛着を持つように、しがみつくリスを持たなければならない。"


translate japanese e2s1_f2334755:


    julia "リス？"


translate japanese e2s1_5850cbe3:


    ruby "リ… 恋愛対象！！！！基本的には征服です！"


translate japanese e2s1_041b7546:


    grace "彼らはどうやって自分たちがリスだと知っているのでしょうか？"


translate japanese e2s1_5eab819b:


    ruby "彼らはそうじゃない！彼らは自然に英雄に出会うんだ！まるで私たちが飛行機で[name]に会ったように！"


translate japanese e2s1_386f66a6:


    grace "では、ヒーローが出会うすべての女の子はLiになるのですか？"


translate japanese e2s1_004af490:


    ruby "いいえ！そして私は彼らが女の子である必要があるとは言っていません！ヒーローがゲイであるゲームやその他のゲームもあります..."


translate japanese e2s1_d772cdb6:


    ruby "しかしここでは、例えば[name]はここに来てからかなり多くの女の子に出会っています！"


translate japanese e2s1_e2297a88:


    ruby "もしかしたら、彼はすでに彼らの一部とつながりがあるかもしれません！ そして、英雄の知人の中には「カジュアル」や「サイドチック」になることができる人もいるかもしれません..."


translate japanese e2s1_5a63cb46:


    ruby "更衣室の双子の一人のように…"


translate japanese e2s1_505f342d:


    julia "ハァ？"


translate japanese e2s1_e1cf0ec0:


    mad "うん...シャワーの下にいる双子の一人のように..."


translate japanese e2s1_505f342d_1:


    julia "ふう？"


translate japanese e2s1_a4ae5c62:


    grace "[name]、ここに来てたった一日で誰かに目を奪われたとしたら、誰になる？"


translate japanese e2s1_b1dc201a:


    d "うーん..."


translate japanese chosenkiss_c0c7ea31:


    chosen "ああ、それはかわいい !!!"


translate japanese chosenkiss_80e6294b:


    mad "でも私はブルーじゃないから… あなたのバイパーに戻って！"


translate japanese chosenkiss_29561989:


    ruby "さて、すべてうまくいっていますが、ルール3に進みましょう！"


translate japanese chosenkiss_8b5643a9:


    ruby "恋愛対象には過去があることもありますが、彼らが処女であればなお良いです！"


translate japanese chosenkiss_fb631fdc:


    mad "何？？？"


translate japanese chosenkiss_370788c5:


    ruby "はい... 明らかに、あなたがそうだとは言えません... あなたには娘がいるので..."


translate japanese chosenkiss_134961cf:


    mad "だから、私は恋愛対象にはなれないの？"


translate japanese chosenkiss_7e7e2e62:


    ruby "なるつもりだったの？"


translate japanese chosenkiss_bc824b1a:


    mad "いいえ、でも私を見たことがありますか？もし私がそんなゲームにいたら、絶対そうなってほしいです！私はただの「サイドチック」にはならないでしょう！"


translate japanese chosenkiss_f653a44a:


    grace "ハハハ！"


translate japanese chosenkiss_8af8bebb:


    ruby "いいえ、でも処女でなくても恋愛対象になれないわけではないよ！ただ、プレイヤーは経験のある女の子よりも「純粋」な女の子を好むってことなんだ…。"


translate japanese chosenkiss_c7db646b:


    mad "それは馬鹿げている... あなたのゲームが好きではない..."


translate japanese chosenkiss_99cbf7ae:


    ruby "例えば、ここはそんなに悪くないですね！[name]は四人の女の子を持っていて、そのうち三人は処女です！"


translate japanese chosenkiss_42486048:


    julia "わかった、そのことを思い出させる必要はないよ、ルビー..."


translate japanese chosenkiss_36cccf90:


    grace "うん…時々、もう少し「心を開く」べきか考えることがある…。"


translate japanese chosenkiss_aede0390:


    ruby "大したことではないよ、女の子たち！プレイヤーにはもっと良いことだし…少なくとも私たちは第4のルールのせいにされることはないよ！！！"


translate japanese chosenkiss_bdfd47df:


    mad "そして、4番目のルールは何ですか？ 子供を持つことはできないのですか？"


translate japanese chosenkiss_894769a1:


    ruby "いいえ！！！"


translate japanese chosenkiss_835b305a:


    ruby "第四のルールは：過剰な情報はダメ！！！"


translate japanese chosenkiss_29ac5843:


    d "何？"


translate japanese chosenkiss_ce2d5e47:


    ruby "余計な情報だ！情報が多すぎる！！！過去が多すぎると現在を壊す！"


translate japanese chosenkiss_6d3dab99:


    grace "私はあまり理解できません..."


translate japanese chosenkiss_24160dd1:


    ruby "基本的に、このゲームをプレイするプレイヤーは...あなたが何人の男とキスしたか知りたくない..."


translate japanese chosenkiss_c5257780:


    ruby "彼に会う前にもっと... 彼には興味がない！それはまるで言うようなものだ：ああ、すごい、あなたのはエドワードのより大きい。"


translate japanese chosenkiss_8258fe0c:


    ruby "それは面白くない！それとも聞くこと... 100人の男性がいたけど、あなたが一番良かった..."


translate japanese chosenkiss_ce93967e:


    ruby "女の子に対する特定の感情を除いて、奴隷のように見える以外にプレイヤーに何も与えません！"


translate japanese chosenkiss_392c2d22:


    ruby "時には、プレイヤーが絶対にそれについて聞きたくないために、ゲームをやめてしまうことさえあります！だから、過剰な情報は不要、問題なし！"


translate japanese chosenkiss_5ce70a32:


    mad "でも、私は結局、人生を持つ権利があったのだろうか？"


translate japanese chosenkiss_4b1161c1:


    ruby "もちろん！しかし、あなたのヒーローとの恋愛は、以前存在したかもしれない恋愛と対立してはいけません！"


translate japanese chosenkiss_58c738d5:


    ruby "結局、現実の生活では、誰も自分の関係や性的行為の最中に他の誰かと比較されたくはない… ゲームの中ではなおさら…"


translate japanese chosenkiss_16d76ed1:


    julia "ええ、処女のときは簡単です！"


translate japanese chosenkiss_f48f8f08:


    ruby "はい、でも「他の男ともキスしたことがあるけど、あなたとは違う」といったことは言わない方がいいよ。"


translate japanese chosenkiss_a9acb29d:


    julia "うーん… そうだね、私もそれはやってないよ！！"


translate japanese chosenkiss_188cc25b:


    ruby "とにかく、5番目のルール！！！"


translate japanese chosenkiss_939fccd4:


    d "グレムリンを出産するような感じだね… 真夜中に食べさせられない… 水に入れられない… 日光にさらせられない…"


translate japanese chosenkiss_a29cc547:


    ruby "ああ！！！ グレムリンを知ってるの？？？ スティーブン・スピルバーグの映画だよ！！！ そして知っているかしら…"


translate japanese chosenkiss_e38298e5:


    d "Ruby!!!" with hpunch


translate japanese chosenkiss_c1826e34:


    ruby "ああ、ごめんね... さて、5つ目のルール：ミルフを持っていなければならない！"


translate japanese chosenkiss_5eefb60e:


    grace "あははははは！マディ、それは君のためだよ！"


translate japanese chosenkiss_91afb2d6:


    mad "" with hpunch


translate japanese chosenkiss_a393b1dd:


    julia "技術的には…あなたもそうなれるかもしれません！"


translate japanese chosenkiss_e593a657:


    mad "でもやめて、私は22歳で、ミルフじゃないわ... ガブリエラはそうなれるかもしれないけど、あなたが望むなら！"


translate japanese chosenkiss_a6936512:


    grace "先生？"


translate japanese chosenkiss_b01b9536:


    mad "うん！"


translate japanese chosenkiss_e453b0a8:


    d "彼女を知らない！"


translate japanese chosenkiss_3377260b:


    ruby "ああ、心配しないで、明日彼女に会えるよ！！！"


translate japanese chosenkiss_4035bba9:


    mad "あなたのミルフはどのような感じですか？"


translate japanese chosenkiss_d6b663b2:


    ruby "彼女が夫に無視されている方がいい...しばらく触れられていないのなら..."


translate japanese chosenkiss_afde39b0:


    ruby "もし彼女が少し迷っている魂であり、英雄が救うのであれば..."


translate japanese chosenkiss_30d62a1a:


    grace "そして[name]はガブリエラを救出するつもりなの？つまり、彼女はそのカテゴリーに入るかもしれないけど、私は[name]が35歳の女性と一緒にいるのは想像できない！"


translate japanese chosenkiss_1df83774:


    grace "だから言ったじゃない！"


translate japanese chosenkiss_8ca883d5:


    julia "それは素敵に言われましたね...ロマンチックです！"


translate japanese chosenkiss_4dcee382:


    mad "私にそれを言うときは私を見ないでください！！！！"


translate japanese chosenkiss_daafaac8:


    ruby "とにかく、ミルフが必要です…なぜなら、それはプレイヤーとの他のダイナミクスを生み出し、しばしばタブーや想像を刺激する他の要素と関連しているからです…"


translate japanese chosenkiss_2a5dc559:


    mad "ああ...同時に、男の想像力は主に腰の高さに位置していて...それ以上はあまりない..."


translate japanese chosenkiss_93e11265:


    ruby "これが私たちを最後から二番目のルールに導きます：全てのフェティッシュが全ての人に合うわけではありません！"


translate japanese chosenkiss_18ee35c4:


    grace "フェティシズ?"


translate japanese chosenkiss_c1d261d7:


    ruby "うん..."


translate japanese chosenkiss_c8aa12cf:


    julia "それは何ですか？"


translate japanese chosenkiss_d9cecfb7:


    ruby "あの…例えば、一部のプレイヤーは足フェティシストです…彼らは足やストッキング、または他の体の部分をフィーチャーしたシーンが大好きです…"


translate japanese chosenkiss_c735661d:


    ruby "他の人はBDSMが好きで･･･ 他の人はレズシーンが耐えられない･･･ そしてNTRについて話し始めることさえできない･･･"


translate japanese chosenkiss_305242eb:


    d "NTR?"


translate japanese chosenkiss_29470446:


    ruby "うん、NTR... それは「寝取られ」から来てる... 基本的には、ゲーム内での浮気や浮気されるという原則だ..."


translate japanese chosenkiss_4f6772e8:


    ruby "それを好きな人もいれば... 嫌いな人もいる... そして、それは自分たちにとって最良だと議論する二つのチームの間で対立を生む..."


translate japanese chosenkiss_334f2a21:


    ruby "そのため、フェティシズムに関連することや、プレイヤーの個性により個人的または特定の意見は、オプションであるべきです！"


translate japanese chosenkiss_a548b7ad:


    grace "どうやってそれをするのか、よく分からないな…。"


translate japanese chosenkiss_2bc88dcb:


    ruby "グレース、立って！"


translate japanese chosenkiss_a3493863:


    grace "わかった！"


translate japanese chosenkiss_ecde9d6a:


    ruby "今キスして！"


translate japanese chosenkiss_0dafd5f9:


    grace "え？？？"


translate japanese chosenkiss_01eb2f6a:


    ruby "ちょっと、キスして！少しだけキスして！"


translate japanese chosenkiss_ef85cac4:


    grace "まあ、もしあなたが望むなら、でもそれがどのように例を示すのかは見えません！"


translate japanese chosenkiss_ef037255:


    ruby "止まれ！"


translate japanese chosenkiss_38c5cdf2:


    ruby "[name]、私たちがキスするところを見たいですか？"


translate japanese chosenkiss_e80a0892:


    mad "もちろん、彼は「はい」と言った... 二人の女の子がキスをして、彼は数秒で勃起している！"


translate japanese chosenkiss_def43184:


    ruby "それは悪くなかった..."


translate japanese chosenkiss_6a4f23ef:


    grace "うん..."


translate japanese chosenkiss_d60a073d:


    ruby "ほら、私たちは彼に選択肢を与えたの！それが原則よ。彼が私たちのキスを見たくなかったら、ノーと言えばそれで終わったのに。"


translate japanese chosenkiss_b79a1c45:


    ruby "ほら、私たちは彼に選択肢を与えたの！それが原則なのよ。もし彼が私たちがキスをするのを見たいと言っていたら、彼は「はい」と言えたし、私たちはそうしたでしょう。"


translate japanese chosenkiss_841cf19e:


    ruby "しかし、彼がプレイするときに好きで見たいものを尊重しているはずです！"


translate japanese chosenkiss_b6788b9d:


    grace "より理解できました！"


translate japanese chosenkiss_b4359a05:


    ruby "そして最後のルール：すべての中で最も重要なルール！"


translate japanese chosenkiss_45f140c1:


    mad "どこでも、常に、誰とでも、すべてがセックスになるに違いない！"


translate japanese chosenkiss_e1aa72bf:


    grace "いいえ、私はキャラクターは大きな胸、とても丸いお尻、そしてふっくらした唇を持つべきだと言います..."


translate japanese chosenkiss_cd7a880b:


    julia "ドラマが必要だ！恐ろしいもの、泣かせるものが..."


translate japanese chosenkiss_9f40f626:


    ruby "プオオオオオオオオオオオオオオオオオオ… あなたは最も弱いリンクです… さようなら！"


translate japanese chosenkiss_dd5d68f3:


    d "え？"


translate japanese chosenkiss_d5ab8d28:


    ruby "セックスは物語をサポートし、統合されるべきであり、その逆ではない！"


translate japanese chosenkiss_2c3a63c7:


    d "あなたは何を意味していますか？"


translate japanese chosenkiss_1a514c11:


    ruby "基本的に、ストーリーが最優先です。セックスはゲームの一つの側面に過ぎず、メインの要素にはならないべきです。"


translate japanese chosenkiss_476ab487:


    ruby "そうでなければ、他のすべてが無意味になります。"


translate japanese chosenkiss_600af04a:


    ruby "その場合、主人公が記憶喪失のまま叔母/隣人/大家（どれかを選んでください）の家に入って、2人、3人、4人の女の子が中にいるゲームを作るのがいいかもしれません..."


translate japanese chosenkiss_e8625ea9:


    ruby "家を出ることなくハーレムがあり、5秒ごとにセックスシーンがあり、ストーリーは全くない…"


translate japanese chosenkiss_a9cca5de:


    ruby "確かに、ファーストフードのプレイヤーにはクールかもしれないが、物語に関わるプレイヤーにとっては、嫌悪感を感じる。"


translate japanese chosenkiss_705eeb93:


    ruby "英雄は感情のない機械になり、少女たちは肉になってしまう..."


translate japanese chosenkiss_9d7730bf:


    ruby "要するに、このルールは次のように要約できます：プレイヤーはリアリズムを求めてはいない...彼らは魔法を求めているのです！"


translate japanese chosenkiss_28d95fb6:


    julia "ああ..."


translate japanese chosenkiss_a8699778:


    d "まあ…"


translate japanese chosenkiss_d3559afb:


    ruby "しかし、これらすべては私たちが成人向けビジュアルノベルにいる場合の仮定のシナリオにすぎません！"


translate japanese chosenkiss_1e5dfb0e:


    mad "うん、[name]がヒーローで、私がミルフってことだね…。"


translate japanese chosenkiss_44699cd8:


    grace "彼女はこのミルフのことを忘れられない！！！"


translate japanese chosenkiss_c02f63b0:


    julia "さて、女の子たち、こんなに話をしていたいけれど、まだ教科書を取りに図書館に行かなければならないんだ..."


translate japanese chosenkiss_b8c86f42:


    grace "そして、プールに行かなければならない..."


translate japanese chosenkiss_dd120e78:


    d "ジュリア..."


translate japanese chosenkiss_3fb1de81:


    julia "はい？"


translate japanese chosenkiss_df802e86:


    d "午後にキャンパスの案内をしてくれると言ったよね…まだ時間はある？"


translate japanese chosenkiss_3989a49b:


    julia "さあ、一緒に行こう！図書館に行く途中、大学のいろいろなところを案内するよ！"


translate japanese chosenkiss_34c55b1f:


    d "どうもありがとうございました..."


translate japanese chosenkiss_3fcacb3d:


    julia "じゃね、女の子たち！"


translate japanese chosenkiss_8f1df40c:


    grace "じゃあね！楽しんで、そして[name]、彼女をあまり利用しないでね！"


translate japanese chosenkiss_c4897051:


    grace "あなたが英雄で、彼女が処女だからと言って、彼女に飛びついてはいけません！"


translate japanese chosenkiss_ef579692:


    julia "グレース..."


translate japanese chosenkiss_38715887:


    grace "私はここを出る！！！"


translate japanese chosenkiss_3896858a:


    julia "うーん… 携帯電話は持っていますか？"


translate japanese chosenkiss_21922934:


    d "はい、ちょうどバッグから取り出しました..."


translate japanese chosenkiss_8121b812:


    julia "あなたを追加させてください！"


translate japanese chosenkiss_ce7133ef:


    julia "いいでしょう… 行きましょう…"

translate japanese strings:


    old "EPISODE 2 {p} \n Double Trouble"
    new "エピソード 2 {p} \n ダブルトラブル"


    old "NEW CONTACT ADDED"
    new "新しい連絡先が追加されました"


    old "Buddy [TEMP1!t]"
    new "バディ [TEMP1!t]"


    old "Education [TEMP2!t]"
    new "教育 [TEMP2!t]"


    old "Sport [TEMP3!t]"
    new "スポーツ [TEMP3!t]"


    old "Temperament [TEMP4!t]"
    new "気質 [TEMP4!t]"


    old "I'm not a fan of older women."
    new "私は年上の女性が好きではありません。"


    old "Age has nothing to do with feelings. [TEMP1!t]"
    new "年齢は感情とは関係がない。 [TEMP1!t]"


    old "Milfs are life! [TEMP2!t]"
    new "ミルフは人生！[TEMP2!t]"


    old "Yes, definitely! [TEMP1!t]"
    new "はい、もちろん！ [TEMP1!t]"


    old "No, I don't like it. [TEMP2!t]"
    new "いいえ、それは好きではありません。[TEMP2!t]"




translate japanese e2s1_fe0698a3:


    cr ""


translate japanese e2s1_9630385f:


    cr ""


translate japanese e2s1_05f0b011:


    cr ""


translate japanese finrubyvn_c02f63b0:


    julia ""


translate japanese finrubyvn_b8c86f42:


    grace ""


translate japanese finrubyvn_dd120e78:


    d ""


translate japanese finrubyvn_3fb1de81:


    julia ""


translate japanese finrubyvn_df802e86:


    d ""


translate japanese finrubyvn_3989a49b:


    julia ""


translate japanese finrubyvn_34c55b1f:


    d ""


translate japanese finrubyvn_3fcacb3d:


    julia ""


translate japanese finrubyvn_8f1df40c:


    grace ""


translate japanese finrubyvn_c4897051:


    grace ""


translate japanese finrubyvn_ef579692:


    julia ""


translate japanese finrubyvn_38715887:


    grace ""


translate japanese finrubyvn_3896858a:


    julia ""


translate japanese finrubyvn_21922934:


    d ""


translate japanese finrubyvn_8121b812:


    julia ""


translate japanese finrubyvn_ce7133ef:


    julia ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
