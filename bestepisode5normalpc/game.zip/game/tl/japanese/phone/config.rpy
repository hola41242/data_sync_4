

translate japanese strings:


    old "%H:%M"
    new "%H:%M"


    old "%m/%d/%Y"
    new "%Y/%m/%d"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
