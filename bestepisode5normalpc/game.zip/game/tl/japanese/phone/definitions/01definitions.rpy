

translate japanese strings:


    old "Ruby"
    new "ルビー"


    old "Minus"
    new "リューク"


    old "Grace"
    new "グレース"


    old "Sofia"
    new "ソフィア"


    old "Elise"
    new "エリーゼ"


    old "???"
    new "???"


    old "Julia"
    new "ジュリア"


    old "Madison"
    new "マディソン"


    old "Gabriella"
    new "ガブリエラ"


    old "Can you hear me, now ?"
    new "今、私の声が聞こえますか？"


    old "Yes ! You know this is only text, right ?"
    new "はい！これはただのテキストだということを知っていますか？"


    old "Good ! Of course , mister serious, haha !"
    new "いいね！もちろん、真剣な男よ、はは！"


    old "Are you ready for tomorrow ?"
    new "明日の準備はできていますか？"


    old "For what ?"
    new "何のために？"


    old "Economics class !"
    new "経済学の授業！"


    old "Oh ! Yeah ! Sure..."
    new "おお！うん！もちろん…"


    old "Don't worry... Gabriella is an angel..."
    new "心配しないで... ガブリエラは天使だよ..."


    old "Gabriella... The Milf ?"
    new "ガブリエラ… ミルフ？"


    old "Ahah ! Yeah... But don't tell her that please..."
    new "あはは！ うん… でも、彼女にはそれを言わないでください…"


    old "I'm not sure she would be pleased by that..."
    new "彼女がそれに喜ぶとは思えない..."


    old "No I won't ! I'm not stupid !"
    new "私はいいえ、やらない！私は愚かじゃない！"


    old "And with Julia ???"
    new "ジュリアと一緒に？？？"


    old "What's about Julia ?"
    new "ジュリアについてはどうですか？"


    old "Come on !!! You two were all around the campus together this afternoon !"
    new "さあ！！！あなたたちは今日の午後、キャンパス中を一緒に回っていたじゃない！"


    old "How do you know that ?"
    new "なぜそれを知っている？"


    old "I've got my eyes everywhere"
    new "私はあちこちに目を配っている。"


    old "You are crazy !"
    new "あなたは狂っている！"


    old "I know !"
    new "私は知っています！"


    old "So ???"
    new "それで？？？"


    old "So... what ?"
    new "それで… 何？"


    old "Julia !!!"
    new "ジュリア !!!"


    old "I'm not interested by her..."
    new "彼女には興味がない..."


    old "I'm not interested in her..."
    new "彼女には興味がない…。"


    old "Oh..."
    new "ああ..."


    old "She's cute..."
    new "彼女は可愛い..."


    old "Great ! I think she likes you too !"
    new "素晴らしい！彼女もあなたのことが好きだと思います！"


    old "Told you... I'm everywhere !"
    new "言ったでしょう... 私はどこにでもいるのです！"


    old "Okay... time to sleep !"
    new "さて…眠る時間だ！"


    old "See ya Cortex !"
    new "じゃあね、ライト！"


    old "See you... Minus..."
    new "さようなら... リューク..."


    old "Hey !"
    new "こんにちは！"


    old "Hey... ! "
    new "やあ... !"


    old "Sorry for my mom..."
    new "ごめんね、私のお母さん…。"


    old "Don't worry ! there's really no problem..."
    new "心配しないで！本当に問題はないよ..."


    old "May I ask you a question ?"
    new "質問してもいいですか？"


    old "Sure you can !"
    new "もちろんできます！"


    old "Okay..."
    new "はい..."


    old "Were you trying to kiss me ?"
    new "私にキスしようとしていましたか？"


    old "Yes..."
    new "はい..."


    old "I couldn't resist..."
    new "我慢できなかった…"


    old "Even if you just spent time with Blue ?"
    new "たとえあなたがブルーと時間を過ごしただけでも？"


    old "Oh you heard that ?"
    new "ああ、それを聞いたの？"


    old "How could I miss it... I could hear her moans all around the pool !"
    new "どうして気づかなかったんだろう…プールの周りで彼女のうめき声が聞こえてきたのに！"


    old "Sorry..."
    new "ごめんなさい..."


    old "Sorry if it was too pushy..."
    new "押し付けがましかったらごめんなさい..."


    old "NO ! I mean..."
    new "いいえ！私が言いたいのは…"


    old "No..."
    new "いいえ..."


    old "Oh ?"
    new "おお？"


    old "I should sleep... It's late..."
    new "眠らなければならない...遅い..."


    old "Yeah me too..."
    new "うん、私も..."


    old "See you tomorrow !"
    new "また明日！"


    old "Sure ! See you tomorrow !"
    new "はい！また明日！"


    old "Good night Grace..."
    new "おやすみ、グレース..."


    old "Good night [name]"
    new "おやすみ [name]"


    old "Hey my lord !"
    new "おお、私の領主！"


    old "I didn't think you would text me tonight ! "
    new "今夜、あなたが私にメッセージをくれるとは思わなかった！"


    old "Yeah I know..."
    new "うん、わかってる..."


    old "I can't forget what you did to me earlier..."
    new "あなたが私にしたことを忘れられない…"


    old "My pussy is so sore..."
    new "アソコが痛くて..."


    old "I told you ! "
    new "言ったでしょう！"


    old "I know... I know..."
    new "知ってる... 知ってる..."


    old "But I need more..."
    new "しかし、もっと必要なんだ..."


    old "Well, I think I need rest..."
    new "そうですね、休息が必要だと思います..."


    old "Will you come to the party Friday ?"
    new "金曜日のパーティーに来る？"


    old "Of course ! You ?"
    new "もちろん！あなたは？"


    old "Sure !"
    new "もちろん！"


    old "Seems we might spend some time together..."
    new "私たちが一緒に過ごす時間があるかもしれない..."


    old "Can't wait..."
    new "待ちきれない..."


    old "Can't wait !"
    new "待ちきれない！"


    old "Me neither..."
    new "私も..."


    old "Take this for your waiting time !"
    new "これをあなたの待ち時間のためにどうぞ！"


    old "I don't care..."
    new "気にしない..."


    old "I don't care... "
    new "気にしない..."


    old "Oh ? Okay..."
    new "あれ？ わかった..."


    old "..."
    new "..."


    old "See you ! Handsome..."
    new "またね！ハンサム..."


    old "See you, my slutty one..."
    new "さようなら、私の淫乱なあなた..."


    old "Hey the american ! Tell me when you're here !"
    new "ねえ、アメリカ人！ここに来たら教えて！"


    old "Yes ? Leonardo speaking ?"
    new "はい？レオナルドが話していますか？"


    old "Hey! Are you asleep?"
    new "ねぇ！寝てる？"


    old "Nah, I was about to go do a little training at the stadium."
    new "ううん、私はスタジアムで少しトレーニングをしに行こうとしていたところだった。"


    old "Oh...."
    new "ああ...."


    old "Why? What's up?"
    new "なぜ？どうしたの？"


    old "Well, I don't have anything to wear to the party."
    new "うーん、パーティーに着ていく服が何もない。"


    old "I was thinking of going to Red's Store to try on some nice dresses."
    new "私はレッドの店に行って、素敵なドレスを試着しようと思っていました。"


    old "Uh, yeah... and?"
    new "ああ、そう…で？"


    old "Well, I wanted your opinion on what you think looks good on me!"
    new "あなたの意見を聞きたいのですが、私に似合うと思うものは何ですか！"


    old "Oh, okay. Well..."
    new "ああ、わかった。さて…"


    old "Sure. I'll come with.[TEMP1!t]"
    new "もちろん。行くよ。[TEMP1!t]"


    old "I would happy to help"
    new "お手伝いできて嬉しいです"


    old "Really? You're coming for real?"
    new "本当に？本当に来るの？"


    old "Yeah. I said I was. I'll be there."
    new "うん。そう言ったよ。行くよ。"


    old "Ohhh, that's awesome!!!"
    new "おお、すごい！！！"


    old "Give me ten minutes and I'll meet you in front of the store?"
    new "10分待ってくれれば、店の前で会おう。"


    old "Sounds good, see you in a bit."
    new "いいね、後で会おう。"


    old "I have to workout first.[TEMP2!t]"
    new "まずはワークアウトしなければなりません。[TEMP2!t]"


    old "I'm sorry, I really need to focus on my training. Maybe next time?"
    new "申し訳ありませんが、今は本当に訓練に集中する必要があります。次の機会に？"


    old "No? Pretty please with a cherry on top? "
    new "いいえ？お願いだから、チェリーの上に。"


    old "Okay, okay. You win. We can go when I am done training."
    new "わかった、わかった。君の勝ちだ。私が訓練を終えたら、行けるよ。"


    old "Ohhh, that's awesome! Thank you!"
    new "ああ、素晴らしい！ありがとう！"


    old "We'll meet in front of the store, okay?"
    new "店の前で会いましょうね？"


    old "Okay, see ya!"
    new "じゃあね！"


    old "I'll be waiting!"
    new "待っています！"


    old "Continue like that [name], you're doing great."
    new "その調子で続けて [name]、素晴らしいよ。"


    old "Who are you?"
    new "あなたは誰ですか？"


    old "Someone that can help you... or not..."
    new "あなたを助けることができる誰か…あるいはそうでない誰か…"


    old "All will depend on you."
    new "すべてはあなたにかかっています。"


    old "where did you get my phone number?"
    new "あなたは私の電話番号をどこで手に入れましたか？"


    old "This question isn't relevant..."
    new "この質問は関係ありません..."


    old "Do as I say and you will win this contest."
    new "私の言う通りにすれば、このコンテストに勝てる。"


    old "Don't and..."
    new "しないで..."


    old "You won't... And your girls neither"
    new "あなたは… そして、あなたの女の子たちもそうではありません。"


    old "What? My girls?"
    new "何だ？私の女の子たち？"


    old "You will have some fresh news soon."
    new "あなたはすぐに新しいニュースを受け取るでしょう。"


    old "Keep the good work [name]"
    new "良い仕事を続けてください[name]"


    old "But what's your name?"
    new "でも、あなたの名前は何ですか？"


    old "Hey! How's it going?"
    new "やあ！調子はどう？"


    old "Hi! My back's still a bit sore..."
    new "こんにちは！まだ少し背中が痛いです…。"


    old "Oh... Hope you're up for the next game!"
    new "ああ… 次のゲームに挑む準備ができていることを願ってるよ！"


    old "Yeah... I'm gonna stay in today."
    new "うん…今日は家にいるつもりだ。"


    old "I already called the academy to let them know I got hurt yesterday."
    new "私はすでに大学に電話して、昨日怪我をしたことを知らせました。"


    old "Oh... okay."
    new "ああ...わかった。"


    old "What about Grace's party?"
    new "グレースのパーティーはどうなっていますか？"


    old "I'll be there, but I won't stay late."
    new "私はそこに行きますが、遅くは残りません。"


    old "Ah..."
    new "ああ..."


    old "So... see you there?"
    new "じゃあ…そこで会いましょうか？"


    old "Definitely! See ya!"
    new "絶対に！じゃあね！"


    old "Hi Madison, it's [name]!"
    new "やあ、マディソン、[name]だよ！"


    old "Just a quick message to check if this is the right number..."
    new "この番号が正しいか確認するための簡単なメッセージです..."


    old "It is."
    new "それはそうです。"


    old "How was your afternoon?"
    new "あなたの午後はいかがでしたか？"


    old "Apart from the kilo of modeling clay on my fingers..."
    new "私の指にある一キロのモデリングクレイを除けば..."


    old "It's fine!"
    new "大丈夫！"


    old "I'm running late though..."
    new "遅れてしまうけど…"


    old "Okay, I won't bother you any longer! See you later!"
    new "わかりました、もうお邪魔しません！また後で！"


    old "++"
    new "++"


    old "Hi Gabriella, it's [name]!"
    new "やあ、ガブリエラ、[name]だよ！"


    old "I told you only in case of emergency!"
    new "非常時のためだけだと言ったでしょう！"


    old "Uh... Yes, but how do I know if it's the right number?"
    new "ええと... でも、それが正しい番号かどうかはどうすればわかりますか？"


    old "In an emergency, I might not have time to check!"
    new "緊急時には、確認する時間がないかもしれません！"


    old "Fair point..."
    new "公平な意見だ..."


    old "Enjoy your evening!"
    new "良い夜をお過ごしください！"


    old "And be on time tomorrow!"
    new "明日は時間通りに来てください！"


    old "No worries!"
    new "心配しないで！"


    old "Steven"
    new "スティーブン"


    old "Creators"
    new "クリエイター"


    old "Mrs Drew"
    new "ドリュー夫人"


    old "Mr. Orushi"
    new "オルシ氏"


    old "Mr. Rufus"
    new "ルーファス氏"


    old "Elizabeth"
    new "エリザベス"


    old "Emerick"
    new "エメリック"


    old "Erin"
    new "エリン"


    old "Charlotte"
    new "シャーロット"


    old "Cassie"
    new "キャシー"


    old "Ted"
    new "テッド"


    old "Hector"
    new "ヘクター"


    old "Do you want to activate the Streamer mode ? Streamer mode will hide explicit content to let you stream or watch the game without problems..."
    new "ストリーマーモードを有効にしますか？ストリーマーモードを有効にすると、ストリーミング中やゲーム鑑賞中に問題のないよう、露骨なコンテンツが非表示になります..."


    old "Yes, activate the streaming mode"
    new "はい、ストリーマーモードを有効にします"


    old "No, I want the full-experience !"
    new "いいえ、フル体験をしたいです！"


    old "[name]"
    new "[name!t]"


    old "Kira"
    new "キラ"


    old "Mac"
    new "マック"


    old "Ben"
    new "ベン"


translate japanese strings:


    old "Red"
    new ""


    old "Hey! Just got your contact info from OS!"
    new ""


    old "Oh okay!"
    new ""


    old "We're heading to Palazio tomorrow."
    new ""


    old "Wanna come with us?"
    new ""


    old "Sure. I'll come along!"
    new ""


    old "That'd be awesome, yeah!"
    new ""


    old "I'll send you the address if you want."
    new ""


    old "Great!"
    new ""


    old "No, thank you!"
    new ""


    old "Oh? Alright."
    new ""


    old "I'd rather rest up for the competition."
    new ""


    old "No worries. I get it!"
    new ""


    old "Hummm... Totally out of place but..."
    new ""


    old "Do you have had an affair with Red at the party? "
    new ""


    old "Yeah. Why?"
    new ""


    old "Oh, just to know. I was curious if it was true!"
    new ""


    old "No. Why?"
    new ""


    old "Oh, just to know. I was just curious!"
    new ""


    old "Well, see you!"
    new ""


    old "See you!"
    new ""


    old "Here’s the message you asked for!"
    new ""


    old "Perfect."
    new ""


    old "That’s it?"
    new ""


    old "What were you expecting?"
    new ""


    old "This way I don’t have to enter your info manually. It does everything by itself."
    new ""


    old "I mean, we could have used this as an excuse to talk... get to know each other..."
    new ""


    old "Right?"
    new ""


    old "No."
    new ""


    old "Well, I guess tonight’s not the night I’ll get a photo of you then?"
    new ""


    old "A photo? Why would I send you a photo?"
    new ""


    old "I don’t know. So I can have something of yours."
    new ""


    old "Something of mine."
    new ""


    old "Let me think about it."
    new ""


    old "Take your time, I’m patient."
    new ""


    old "Yeah, sure. Keep dreaming..."
    new ""


    old "This is all you will have from me."
    new ""


    old "Wait, seriously? A cleavage shot... and a toilet in the background?"
    new ""


    old "You’re truly one of a kind, Beth."
    new ""


    old "Take it or leave it."
    new ""


    old "Oh, I’m keeping it. It’ll be the highlight of my collection."
    new ""


    old "Good night, [name]. Enjoy staring at your phone."
    new ""


    old "Good night, Beth."
    new ""


    old "Hey, you!"
    new ""


    old "Yeah?"
    new ""


    old "You think I didn't see you spying on us at the Palazio earlier?"
    new ""


    old "That's nonsense!"
    new ""


    old "Yeah, yeah..."
    new ""


    old "I totally figured out that Gabriella was talking about you, you know!"
    new ""


    old "I have no idea what you're talking about."
    new ""


    old "Of course you don’t."
    new ""


    old "I'm gonna set something up. You'll thank me later!"
    new ""


    old "What are you gonna do?"
    new ""


    old "I have my little idea. Anyway, good night!"
    new ""


    old "Good night!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
