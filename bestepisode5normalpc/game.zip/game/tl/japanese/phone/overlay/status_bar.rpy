

translate japanese strings:


    old "LTE"
    new "LTE"


    old "Screen\nMirroring"
    new "画面\nミラーリング"


    old "Music"
    new "音楽"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
