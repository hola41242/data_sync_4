

translate japanese strings:


    old "B.E.S.T RANK"
    new "B.E.S.T ランク"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
