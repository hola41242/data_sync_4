

translate japanese strings:


    old "Affair"
    new ""


    old "Bowling"
    new ""


    old "Dance"
    new ""


    old "Library"
    new ""


    old "Auditorium"
    new ""


    old "Museum"
    new ""


    old "Port"
    new ""


    old "Gym"
    new ""


    old "Park"
    new ""


    old "A maze of glass and steel where dreams are priced and ambitions are signed."
    new ""


    old "A place where every move strives to turn the unfinished into a spare."
    new ""


    old "A space where every step composes a melody and every movement brings the rhythm to life."
    new ""


    old "A sanctuary where words whisper secrets and pages keep time in memory."
    new ""


    old "Tes connaissances s'accumulent ici"
    new ""


    old "A vault where time stands still and every artifact whispers echoes of an immortal past."
    new ""


    old "A theater where ropes sing in the wind and every departure promises an adventure to tell."
    new ""


    old "A temple where every effort shapes determination and every drop of sweat writes perseverance."
    new ""


    old "A haven where nature paints living pictures and the wind tells forgotten tales."
    new ""


    old "Minimap"
    new ""


    old "Hints"
    new ""


    old "Mastermind"
    new ""


    old "{b}Hint "
    new ""


    old "{/b}: "
    new ""


    old "{s}{b}Hint "
    new ""


    old "Found number: {b}"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
