

translate japanese strings:


    old "[name]:\n\nJust a regular guy trying to navigate through life and make sense of everything. Sometimes lucky, sometimes clumsy, but always trying to do the right thing... most of the time."
    new ""


    old "Ruby Suyin:\n\nPlayful and funny, Ruby charms everyone with her spontaneity and natural charisma. A bit scatterbrained but genuine, she lives in the moment and brightens the story with her joyful spirit."
    new ""


    old "Madison Forrester:\n\nHeiress of the powerful Forrester family, Madison juggles family duties, studies, and motherhood. Strong yet conflicted, she hides her doubts behind a polished facade."
    new ""


    old "Grace Drew:\n\nGrace is kind and selfless, always striving to meet her mother’s high expectations. Her warmth hides the pressure she feels to balance duty and her own desires."
    new ""


    old "Julia Carter:\n\nReserved and enigmatic, Julia carries a quiet strength that hints at untold stories. Her thoughtful gaze and calm demeanor conceal a world of emotions and secrets, making her both captivating and elusive."
    new ""


    old "Elise Moreau:\n\nElise is the hero's steadfast friend, always ready with sharp wit and sound advice. Loyal and resourceful, she’s a reliable ally who values honesty and isn’t afraid to speak her mind."
    new ""


    old "Gabriella Fernandez:\n\nGabriella is a reserved and solitary professor, torn between her strict principles and her growing feelings for the protagonist. Her loneliness fuels her inner turmoil."
    new ""


    old "Charlotte Sinclair:\n\nCharlotte is a free spirit with a rebellious streak, unafraid to challenge norms and live life on her own terms. Her boldness hides a deep desire for connection."
    new ""


    old "Elizabeth ‘Beth’ Da Fonseca:\n\nElisabeth, known as Red, is confident and assertive, always taking charge of any situation. Her dominant personality masks a softer side she rarely shows."
    new ""


    old "Sofia Da Fonseca:\n\nOutgoing and carefree, Sofia embraces life with a lighthearted charm. She’s known for her quick wit and an open mind, often breaking the tension with her humor and spontaneity."
    new ""


    old "Kira Orushi:\n\nAdventurous and headstrong, Kira thrives on independence and freedom. As an Orushi, she balances high expectations with her rebellious charm."
    new ""


    old "Emerick Orushi:\n\nEmerick is cunning and arrogant, always scheming to maintain his status. As a member of the Orushi family, he wields influence but often underestimates those around him."
    new ""


    old "Steven Johnson:\n\nThe captain of the men’s football team, Steven commands respect with his natural authority and calm demeanor. His leadership skills and steady presence make him a cornerstone for his team, both on and off the field."
    new ""


    old "Mac Harper:\n\nFriendly and easygoing, Mac is the type of guy who can get along with anyone. His laid-back attitude often hides his competitive spirit, which shines through when it comes to sports or a challenge he can’t resist."
    new ""


    old "Ben Baker:\n\nLoyal and hardworking, Ben is the kind of person who puts others before himself. Though he often downplays his own achievements, his determination and dedication make him a dependable friend and teammate."
    new ""


    old "Hector Alvarez:\n\nRuthlessly ambitious, Hector is willing to do whatever it takes to get ahead. As Emerick’s loyal follower, he often finds himself executing questionable plans, putting his own morals aside to stay in his good graces."
    new ""


    old "Ted Forrester:\n\nTed is Madison's brother, loyal to the Forrester legacy but often clashing with her over family expectations. His sense of duty masks a more calculating side."
    new ""


    old "Cassie Forrester:\n\nCassie is Madison’s young daughter, full of energy and curiosity. Her cheerful spirit brings light to Madison’s demanding life, even as she navigates the complexities of her family."
    new ""


    old "Mrs. Drew:\n\nMrs. Drew is Grace’s demanding mother, holding her daughter to the highest standards. Behind her strictness lies a deep desire to see Grace succeed, even at the cost of personal warmth."
    new ""


    old "Mr. Orushi:\n\nMr. Orushi is the patriarch of the Orushi family, a calculating and authoritative figure who demands loyalty and excellence from everyone around him. His ambition and influence shape both his family and the city."
    new ""


    old "Charles Forrester:\n\nCharles Forrester is the proud patriarch of the Forrester family. Ambitious and commanding, he strives to maintain his family’s dominance in the city, often at the expense of personal relationships"
    new ""


    old "Carmen Forrester:\n\nCarmen Forrester is the graceful matriarch of the Forrester family. Often acting as a peacemaker, she balances her loyalty to her husband with her compassion for her children."
    new ""


    old "She barely knows you..."
    new ""


    old "You're becoming friends."
    new ""


    old "You're starting to mean something to her."
    new ""


    old "You shared a kiss."
    new ""


    old "A deep bond is forming between you."
    new ""


    old "Madly in love."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
