

translate japanese strings:


    old "message"
    new "メッセージ"


    old "calendar"
    new "カレンダー"


    old "call"
    new "呼ぶ"


    old "Discussions"
    new "議論"


    old "Stats"
    new "ステータス"


    old "Settings"
    new "設定"


    old "Wallpaper"
    new "壁紙"



translate japanese strings:


    old "Bios"
    new ""


    old "OnlyStan"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
