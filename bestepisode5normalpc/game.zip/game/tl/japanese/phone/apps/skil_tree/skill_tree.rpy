

translate japanese strings:


    old "Welcome to the B.E.S.T profile"
    new ""


    old "Once you reach 10 points in a stat, you can activate it"
    new ""


    old "Your specialization will have effects during the B.E.S.T contest"
    new ""


    old "{i}Click to continue{/i}"
    new ""


    old "You have unlocked the {color=#d90000}Buddy{/color} specialization! You can now enable it!"
    new ""


    old "Click to continue"
    new ""


    old "You have unlocked the {color=#d90000}Temperament{/color} specialization! You can now enable it!"
    new ""


    old "You have unlocked the {color=#d90000}Sport{/color} specialization! You can now enable it!"
    new ""


    old "You have unlocked the {color=#d90000}Education{/color} specialization! You can now enable it!"
    new ""


    old "Buddy specialization enabled!"
    new ""


    old "Buddy"
    new ""


    old "Temperament specialization enabled!"
    new ""


    old "Temp."
    new ""


    old "Education specialization enabled!"
    new ""


    old "Educ."
    new ""


    old "Sport specialization enabled!"
    new ""


    old "Sport"
    new ""


    old "Get at least {color=#d90000}10 points{/color} of a {color=#d90000}stat{/color} to unlock its {color=#d90000}specialization{/color}!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
