

translate japanese strings:


    old "Phone Theme"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
