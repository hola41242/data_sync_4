

translate japanese strings:


    old "Replays"
    new ""


    old "Extras"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
