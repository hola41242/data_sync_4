

translate japanese strings:


    old "Type a message."
    new "メッセージを入力する"


    old "Send"
    new "送信"


    old "Load More"
    new "もっと読み込む"


    old "{u}{i}Loading Image...{i}{/u}"
    new "{u}{i}画像を読み込む...{i}{/u}"


    old "{u}{i}Loading Audio...{i}{/u}"
    new "{u}{i}オーディオの読み込み...{i}{/u}"


    old "{u}{i}Loading Video...{i}{/u}"
    new "{u}{i}ビデオを読み込む...{i}{/u}"


    old "Go Back"
    new "戻る"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
