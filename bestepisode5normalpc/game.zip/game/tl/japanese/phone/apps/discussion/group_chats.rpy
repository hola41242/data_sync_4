

translate japanese strings:


    old "Empty group chat"
    new "空のグループチャット"


    old "Image sent"
    new "画像が送信された"


    old "Audio sent"
    new "音声が送信されました"


    old "Video sent"
    new "動画が送信されました"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
