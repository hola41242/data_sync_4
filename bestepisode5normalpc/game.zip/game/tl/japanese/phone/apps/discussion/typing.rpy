

translate japanese strings:


    old "[sender.short_name!t] is typing..."
    new "[sender.short_name!t] がタイプしている..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
