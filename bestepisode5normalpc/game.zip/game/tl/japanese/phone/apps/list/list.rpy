

translate japanese strings:


    old "Contacts"
    new "連絡先"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
