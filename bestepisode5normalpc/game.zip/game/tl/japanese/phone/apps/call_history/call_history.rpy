

translate japanese strings:


    old "Calls"
    new "通話リスト"


    old "No recent calls"
    new "最近の通話なし"


    old "The {date} at {time}"
    new "{date} の {time}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
