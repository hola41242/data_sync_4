

translate japanese strings:


    old "Your wallpaper was changed!"
    new "壁紙が変更されました！"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
