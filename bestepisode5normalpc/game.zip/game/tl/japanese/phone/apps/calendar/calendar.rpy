

translate japanese strings:


    old "Monday"
    new "月曜日"


    old "Tuesday"
    new "火曜日"


    old "Wednesday"
    new "水曜日"


    old "Thursday"
    new "木曜日"


    old "Friday"
    new "金曜日"


    old "Saturday"
    new "土曜日"


    old "Sunday"
    new "日曜日"


    old "January"
    new "一月"


    old "February"
    new "2月"


    old "March"
    new "3月"


    old "April"
    new "4月"


    old "May"
    new "5月"


    old "June"
    new "6月"


    old "July"
    new "7月"


    old "August"
    new "8月"


    old "September"
    new "9月"


    old "October"
    new "10月"


    old "November"
    new "11月"


    old "December"
    new "12月"


    old "Calendar"
    new "カレンダー"


    old "[calendar.month_name]-[calendar.year]"
    new "[calendar.month_name]-[calendar.year]"


    old "Notes:"
    new "備考："


    old "No description provided."
    new "説明はない。"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
