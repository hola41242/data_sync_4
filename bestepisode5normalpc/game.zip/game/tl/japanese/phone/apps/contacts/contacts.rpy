

translate japanese strings:


    old "Messages"
    new "メッセージ"


    old "No group chats"
    new "グループチャットなし"


    old "The [group_chat._date_text] at [group_chat._hour_text]"
    new "[group_chat._date_text] に [group_chat._hour_text]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
