

translate japanese strings:


    old "A simple boy who just want to meet friends here :)"
    new ""


    old "A simple girl who likes simple things"
    new ""


    old "Pretty girls out there!"
    new ""


    old "Here to meet beautiful young girls 🤤!"
    new ""


    old "Just a flexible guy looking for fun!"
    new ""


    old "Feeling lonely, let's chat and share good vibes ❤️!"
    new ""


    old "Big dreams, small beginnings. Let's connect!"
    new ""


    old "I bring the sass to OnlyStan 😎."
    new ""


    old "Always here to support you 😉."
    new ""


    old "Busy and bubbly, ready for fun! 💦"
    new ""


    old "Just a guy with a big heart (and maybe more...) 😏."
    new ""


    old "What can I say? I'm a cheeky kind of guy 😜!"
    new ""


    old "Hello! My name is Fanny and I am new here. Tell me what you like in the comments ;)"
    new ""


    old "Hi everyone :)!"
    new ""


    old "Very beautiful! I'm very happy to meet you there 😊"
    new ""


    old "Beach day! 🌴🏖️"
    new ""


    old "Take me with you next time 😂! I love your outfit btw"
    new ""


    old "Preparing for a party with my best friend 💕"
    new ""


    old "A party? Count me in! Just tell me where and when, I’ll bring the good vibes 🎉!"
    new ""


    old "Pretty girl 🤤"
    new ""


    old "Hey ! I love your body... Would you like to get to know each other 😉?"
    new ""


    old "My D is still so hard seeing you 🥵🥵"
    new ""


    old "I am so honoured to breath the same air as you 🥵😍"
    new ""


    old "I'm bending over backwards just to comment here 😉"
    new ""


    old "You look like someone who needs a hug 🥰"
    new ""


    old "Ben, you're always bending over for attention 🤦‍♀️"
    new ""


    old "Anita, don’t be so mean! Everyone deserves a little flexibility 😏"
    new ""


    old "Wow, this is small talk at its finest 😏"
    new ""


    old "This beach photo is making waves 🌊!"
    new ""


    old "Hugh, you're just fishing for compliments again 🎣"
    new ""


    old "Seymour, let him enjoy the tide, it's not every day we get such views 😎"
    new ""


    old "Party with friends? Save me a spot next time! 🎉"
    new ""


    old "Willie, you weren't invited last time for a reason... 😒"
    new ""


    old "Ivana, don't be salty, we all know Willie likes to party hard 😉"
    new ""


    old "Anita, you're the life of the party, admit it ❤️!"
    new ""


    old "Hard to resist such beauty 😏🔥"
    new ""


    old "Always here to have your back ❤️"
    new ""


    old "Cheeky post! Keep them coming 😜"
    new ""


    old "This made me tinkle with laughter 💦"
    new ""


    old "Welcome back, "
    new ""


    old "See comments"
    new ""


    old "Comments"
    new ""


    old "No comments"
    new ""


    old "+ Add comment"
    new ""


    old "No posts"
    new ""


    old "Posts"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
