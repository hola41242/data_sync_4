

translate japanese strings:


    old "B.E.S.T"
    new "B.E.S.T"


    old "Credits for music : (Source: https://soundcloud.com //Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nCredits for Scripts :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio // Italian Translation : Eagle1900 // Russian Translation : Pretender // Chinese Translation : V // Portuguese Translation : Heathens\n\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
    new "音楽のクレジット : (出典: https://soundcloud.com //ライセンス: https://creativecommons.org/licenses/by/3.0/deed.fr //ダウンロード: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nスクリプトのクレジット :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\n英語翻訳 : SaintBlackMoor // スペイン語翻訳 : Mustadio // イタリア語翻訳 : Eagle1900 // ロシア語翻訳 : Pretender // 中国語翻訳 : V // ポルトガル語翻訳 : Heathens\n\nDrooskati, UncleNanard, と SecretGame の貴重なアドバイスに感謝します。"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
