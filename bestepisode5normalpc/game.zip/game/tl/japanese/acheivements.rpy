

translate japanese strings:


    old "You have entered the B.E.S.T Game"
    new "あなたはB.E.S.Tゲームに参加しました"


    old "Start the game"
    new "ゲームを始める"


    old "What an ass!"
    new "なんて尻だ！"


    old "Grope Julia"
    new "ジュリアを触る"


    old "Cotton Eye Joe !"
    new "コットン・アイ・ジョー！"


    old "Don't touch Julia"
    new "ジュリアに触れないでください"


    old "Catch them all!"
    new "全部捕まえろ！"


    old "Catch Grace"
    new "グレースを捕まえろ"


    old "Life in redhead !"
    new "赤毛の生活！"


    old "You've put Grace on her bed"
    new "グレースを彼女のベッドに寝かせた。"


    old "Show must go on !"
    new "ショーは続くべきだ！"


    old "Finish the Prologue"
    new "プロローグを終える"


    old "Pinky and the Braid!"
    new "ピンキーとブレイド！"


    old "Play the Minus and Cortex game"
    new "マイナスとコルテックスのゲームをプレイする"


    old "You are the winner!"
    new "あなたが勝者です！"


    old "Finish First with Madison ?"
    new "マディソンと一緒に最初を終える？"


    old "You deserve it!"
    new "あなたはそれに値する！"


    old "Accept the reward"
    new "報酬を受け取る"


    old "You're not first meh!"
    new "あなたは最初じゃないんだよ！"


    old "Accept the Special Reward"
    new "特別な報酬を受け取る"


    old "First !!!"
    new "最初！！！"


    old "Finish the First Episode"
    new "第一話を終わらせる"


    old "Outstanding!"
    new "素晴らしい！"


    old "Get all achievements."
    new "すべての実績を取得する。"


    old "Victory !!!"
    new "勝利！！！"


    old "Win versus Grace"
    new "グレースに勝つ"


    old "Cheater !!!"
    new "チーター！！！"


    old "Cheat versus Grace"
    new "チート 対 グレース"


    old "Day of Defeat !!!"
    new "敗北の日 !!!"


    old "You let Grace win... Right ?"
    new "あなたはグレースを勝たせましたね... そうですか？"


    old "Evolution !!!"
    new "進化 !!!"


    old "From Squirtle to Squirter"
    new "ゼニガメからスカートを"


    old "Her hero!!!"
    new "彼女のヒーロー!!!"


    old "You're Ruby's Hero..."
    new "あなたはルビーのヒーローです..."


    old "Hat Trick !!!"
    new "ハットトリック！！！"


    old "All for Madison !"
    new "マディソンのために！"


    old "Harem Vibes!!!"
    new "ハーレムの雰囲気！！！"


    old "Women likes you..."
    new "女性はあなたが好きだ..."


    old "First Kiss!!!"
    new "初めてのキス!!!"


    old "Grace for ever !"
    new "グレースよ、永遠に！"


    old "Of course!!!"
    new "もちろん！！！"


    old "Madison..."
    new "マディソン..."


    old "Just the Beginning!"
    new "始まりに過ぎない！"


    old "Finish the Second Episode"
    new "第2話を終わらせる"


    old "You tried..."
    new "あなたは試みました..."


    old "Meh..."
    new "まあ..."


    old "You're a genius!!!"
    new "あなたは天才です！！！"


    old "But unknown..."
    new "しかし、不明..."


    old "Milfs are life!!!"
    new "ミルフが人生！！！"


    old "Better with experience..."
    new "経験を重ねることでより良くなる..."


    old "Like a virgin!"
    new "まるで処女のように！"


    old "Touch for the very first time..."
    new "初めての触れ合い..."


    old "You switched!"
    new "あなたが切り替えた！"


    old "From Blue to Red..."
    new "青から赤へ..."


    old "Road to Victory!"
    new "勝利への道！"


    old "Finish the Third Episode"
    new "第三話を終わらせる。"



translate japanese strings:


    old "Pet's Friend"
    new ""


    old "Mewww..."
    new ""


    old "Opportunity Missed"
    new ""


    old "You were on the right track..."
    new ""


    old "You're the BEST!"
    new ""


    old "A Star is born..."
    new ""


    old "Madison is the BEST!"
    new ""


    old "Ally or enemy???"
    new ""


    old "Man of the match!"
    new ""


    old "Play it like Beckham!"
    new ""


    old "You finished Episode 4!"
    new ""


    old "RUBYYYYYYYY!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
