

translate japanese strings:


    old "Achievements | {:01d}/{}"
    new "実績 | {:01d}/{}"


    old "Hidden Achievement"
    new "隠された実績"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
