
translate italian strings:


    old "%H:%M"
    new "%H:%M"


    old "%m/%d/%Y"
    new "%m/%d/%Y"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
