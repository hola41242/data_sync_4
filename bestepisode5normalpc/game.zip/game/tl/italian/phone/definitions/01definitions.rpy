

translate italian phone_call_test_f8ac15c7:


    phone_ruby "Ohayouuu!!!!!!!!!!!!!!!!"


translate italian phone_call_test_8a706c1c:


    phone_d "EHI!"


translate italian phone_call_test_3c118f0d:


    "Perché è sempre così energica?"


translate italian phone_call_test_a20cefa7:


    "..."

translate italian strings:


    old "Ruby"
    new "Ruby"


    old "Grace"
    new "Grace"


    old "Sofia"
    new "Sofia"


    old "Elise"
    new "Elisa"


    old "Can you hear me, now ?"
    new "Mi senti ora ?"


    old "Yes ! You know this is only text, right ?"
    new "SÌ ! Sai che questo è solo testo, vero?"


    old "Good ! Of course , mister serious, haha !"
    new "Bene ! Certo, signor serio, ahah!"


    old "Are you ready for tomorrow ?"
    new "Sei pronto per domani ?"


    old "For what ?"
    new "Per cosa ?"


    old "Economics class !"
    new "Lezione di economia!"


    old "Oh ! Yeah ! Sure..."
    new "OH ! Sì ! Sicuro..."


    old "Don't worry... Gabriella is an angel..."
    new "Non preoccuparti... Gabriella è un angelo..."


    old "Gabriella... The Milf ?"
    new "Gabriella... La Domestica?"


    old "Ahah ! Yeah... But don't tell her that please..."
    new "Ah ah ! Sì... ma non dirglielo, per favore..."


    old "I'm not sure she would be pleased by that..."
    new "Non sono sicura che ne sarebbe contenta..."


    old "No I won't ! I'm not stupid !"
    new "No, non lo farò! Io non sono stupido !"


    old "And with Julia ???"
    new "E con Julia???"


    old "What's about Julia ?"
    new "Cosa c'entra Julia?"


    old "Come on !!! You two were all around the campus together this afternoon !"
    new "Dai !!! Voi due eravate insieme in giro per il campus questo pomeriggio!"


    old "How do you know that ?"
    new "Come fai a saperlo ?"


    old "I've got my eyes everywhere"
    new "Ho gli occhi ovunque"


    old "You are crazy !"
    new "Sei pazza !"


    old "I know !"
    new "Lo so !"


    old "So ???"
    new "COSÌ ???"


    old "So... what ?"
    new "E allora ?"


    old "Julia !!!"
    new "Julia !!!"


    old "I'm not interested by her..."
    new "Non mi interessa lei..."


    old "I'm not interested in her..."
    new "Non sono interessato a lei..."


    old "Oh..."
    new "OH..."


    old "She's cute..."
    new "Lei è carina..."


    old "Great ! I think she likes you too !"
    new "Grande ! Penso che le piaci anche tu!"


    old "Told you... I'm everywhere !"
    new "Te l'avevo detto... sono ovunque!"


    old "Okay... time to sleep !"
    new "Ok... è ora di dormire!"


    old "See ya Cortex !"
    new "Ci vediamo Cortex!"


    old "See you... Minus..."
    new "Ci vediamo... Minus..."


    old "Hey !"
    new "EHI !"


    old "Hey... ! "
    new "EHI... !"


    old "Sorry for my mom..."
    new "Mi dispiace per mia mamma..."


    old "Don't worry ! there's really no problem..."
    new "Non preoccuparti ! non c'è davvero nessun problema..."


    old "May I ask you a question ?"
    new "Posso farti una domanda ?"


    old "Sure you can !"
    new "Certo che puoi !"


    old "Okay..."
    new "Va bene..."


    old "Were you trying to kiss me ?"
    new "Stavi cercando di baciarmi?"


    old "Yes..."
    new "SÌ..."


    old "I couldn't resist..."
    new "Non ho potuto resistere..."


    old "Even if you just spent time with Blue ?"
    new "Anche se hai appena passato del tempo con Blue?"


    old "Oh you heard that ?"
    new "Oh, l'hai sentito?"


    old "How could I miss it... I could hear her moans all around the pool !"
    new "Come potevo perderlo... potevo sentirla gemere in tutta la piscina!"


    old "Sorry..."
    new "Scusa..."


    old "Sorry if it was too pushy..."
    new "Scusate se sono stato troppo invadente..."


    old "NO ! I mean..."
    new "NO ! Intendo..."


    old "No..."
    new "NO..."


    old "Oh ?"
    new "OH ?"


    old "I should sleep... It's late..."
    new "Dovrei dormire... È tardi..."


    old "Yeah me too..."
    new "Si, anch'io..."


    old "See you tomorrow !"
    new "Ci vediamo domani !"


    old "Sure ! See you tomorrow !"
    new "Sicuro ! Ci vediamo domani !"


    old "Good night Grace..."
    new "Buonanotte Grace..."


    old "Good night [name]"
    new "Buonanotte [name]"


    old "Hey my lord !"
    new "Ehi mio signore!"


    old "I didn't think you would text me tonight ! "
    new "Non pensavo che mi avresti mandato un messaggio stasera!"


    old "Yeah I know..."
    new "Si lo so..."


    old "I can't forget what you did to me earlier..."
    new "Non posso dimenticare quello che mi hai fatto prima..."


    old "My pussy is so sore..."
    new "La mia figa è così dolorante..."


    old "I told you ! "
    new "Te l'avevo detto !"


    old "I know... I know..."
    new "Lo so, lo so..."


    old "But I need more..."
    new "Ma mi serve di più..."


    old "Well, I think I need rest..."
    new "Beh, penso di aver bisogno di riposo..."


    old "Will you come to the party Friday ?"
    new "Verrai alla festa venerdì?"


    old "Of course ! You ?"
    new "Ovviamente ! Tu ?"


    old "Sure !"
    new "Sicuro !"


    old "Seems we might spend some time together..."
    new "Sembra che potremmo passare un po' di tempo insieme..."


    old "Can't wait..."
    new "Non vedo l'ora..."


    old "Can't wait !"
    new "Non vedo l'ora!"


    old "Me neither..."
    new "Neanche io..."


    old "Take this for your waiting time !"
    new "Prendi questo per il tuo tempo di attesa!"


    old "I don't care..."
    new "Non mi interessa..."


    old "I don't care... "
    new "Non mi interessa..."


    old "Oh ? Okay..."
    new "OH ? Va bene..."


    old "..."
    new "..."


    old "See you ! Handsome..."
    new "Ci vediamo ! Bello..."


    old "See you, my slutty one..."
    new "Ci vediamo, mia troia..."


    old "Hey the american ! Tell me when you're here !"
    new "Ehi americano! Dimmi quando sei qui!"


    old "Yes ? Leonardo speaking ?"
    new "SÌ ? Leonardo parla?"





translate italian strings:


    old "Minus"
    new "Minus"


    old "Hey! Are you asleep?"
    new "EHI! Stai dormendo?"


    old "Nah, I was about to go do a little training at the stadium."
    new "No, stavo per andare ad allenarmi un po' allo stadio."


    old "Oh...."
    new "OH...."


    old "Why? What's up?"
    new "Perché? Che cosa succede?"


    old "Well, I don't have anything to wear to the party."
    new "Beh, non ho niente da indossare per la festa."


    old "I was thinking of going to Red's Store to try on some nice dresses."
    new "Stavo pensando di andare al Red's Store per provare dei bei vestiti."


    old "Uh, yeah... and?"
    new "Uh, sì... e?"


    old "Well, I wanted your opinion on what you think looks good on me!"
    new "Beh, volevo la tua opinione su cosa pensi che mi stia bene!"


    old "Oh, okay. Well..."
    new "Oh ok. BENE..."


    old "Sure. I'll come with."
    new "Sicuro. Verrò con te."


    old "I would happy to help"
    new "Sarei felice di aiutarti"


    old "Really? You're coming for real?"
    new "Veramente? Verrai davvero?"


    old "Yeah. I said I was. I'll be there."
    new "Sì. Ho detto che verrò. E ci sarò."


    old "Ohhh, that's awesome!!!"
    new "Ohhh, è fantastico!!!"


    old "Give me ten minutes and I'll meet you in front of the store?"
    new "Dammi dieci minuti e ci vediamo davanti al negozio?"


    old "Sounds good, see you in a bit."
    new "Suona bene, ci vediamo tra un po'."


    old "I have to workout first."
    new "Prima devo allenarmi."


    old "I'm sorry, I really need to focus on my training. Maybe next time?"
    new "Mi dispiace, devo davvero concentrarmi sul mio allenamento. Magari la prossima volta?"


    old "No? Pretty please with a cherry on top? "
    new "No? Per favore, con una ciliegina sulla torta?"


    old "Okay, okay. You win. We can go when I am done training."
    new "Ok ok. Hai vinto. Possiamo andare quando avrò finito l'allenamento."


    old "Ohhh, that's awesome! Thank you!"
    new "Ohhh, è fantastico! Grazie!"


    old "We'll meet in front of the store, okay?"
    new "Ci incontreremo davanti al negozio, ok?"


    old "Okay, see ya!"
    new "Ok, ci vediamo!"


    old "I'll be waiting!"
    new "Ti aspetto!"



translate italian strings:


    old "???"
    new "???"


    old "Continue like that [name], you're doing great."
    new "Continua così [name], stai andando alla grande."


    old "Who are you?"
    new "Chi sei?"


    old "Someone that can help you... or not..."
    new "Qualcuno che può aiutarti... oppure no..."


    old "All will depend on you."
    new "Tutto dipenderà da te."


    old "where did you get my phone number?"
    new "dove hai preso il mio numero di telefono?"


    old "This question isn't relevant..."
    new "Questa domanda non è pertinente..."


    old "Do as I say and you will win this contest."
    new "Fai come ti dico e vincerai questo concorso."


    old "Don't and..."
    new "Non farlo e..."


    old "You won't... And your girls neither"
    new "Non lo farai... E nemmeno le tue ragazze"


    old "What? My girls?"
    new "Che cosa? Le mie ragazze?"


    old "You will have some fresh news soon."
    new "Presto avrai nuove informazioni."


    old "Keep the good work [name]"
    new "Continua a fare un buon lavoro [name]"


    old "But what's your name?"
    new "Ma come ti chiami?"





translate italian strings:


    old "Sure. I'll come with.[TEMP1!t]"
    new "Sicuro. Verrò con.[TEMP1!t]"


    old "I have to workout first.[TEMP2!t]"
    new "Prima devo allenarmi.[TEMP2!t]"



translate italian strings:


    old "Julia"
    new "Julia"


    old "Madison"
    new "Madison"


    old "Gabriella"
    new "Gabriella"


    old "Hey! How's it going?"
    new "EHI! Come va?"


    old "Hi! My back's still a bit sore..."
    new "CIAO! La mia schiena è ancora un po' dolorante..."


    old "Oh... Hope you're up for the next game!"
    new "Oh... Spero che tu sia pronta per la prossima partita!"


    old "Yeah... I'm gonna stay in today."
    new "Sì... resterò a casa oggi."


    old "I already called the academy to let them know I got hurt yesterday."
    new "Ho già chiamato l'accademia per far sapere che mi sono fatta male ieri."


    old "Oh... okay."
    new "Oh ok."


    old "What about Grace's party?"
    new "E la festa di Grace?"


    old "I'll be there, but I won't stay late."
    new "Ci sarò, ma non resterò fino a tardi."


    old "Ah..."
    new "Ah..."


    old "So... see you there?"
    new "Allora... ci vediamo lì?"


    old "Definitely! See ya!"
    new "Decisamente! Ci vediamo!"


    old "Hi Madison, it's [name]!"
    new "Ciao Madison, sono [name]!"


    old "Just a quick message to check if this is the right number..."
    new "Solo un breve messaggio per verificare se questo è il numero giusto..."


    old "It is."
    new "È."


    old "How was your afternoon?"
    new "Com'è andato il pomeriggio?"


    old "Apart from the kilo of modeling clay on my fingers..."
    new "A parte il chilo di pasta da modellare che ho sulle dita..."


    old "It's fine!"
    new "Va bene!"


    old "I'm running late though..."
    new "Sono in ritardo però..."


    old "Okay, I won't bother you any longer! See you later!"
    new "Ok, non ti disturbo più! Arrivederci!"


    old "++"
    new "++"


    old "Hi Gabriella, it's [name]!"
    new "Ciao Gabriella, sono [name]!"


    old "I told you only in case of emergency!"
    new "Te l'avevo detto solo in caso di emergenza!"


    old "Uh... Yes, but how do I know if it's the right number?"
    new "Uh... Sì, ma come faccio a sapere se è il numero giusto?"


    old "In an emergency, I might not have time to check!"
    new "In caso di emergenza, potrei non avere il tempo di controllare!"


    old "Fair point..."
    new "Giusta osservazione..."


    old "Enjoy your evening!"
    new "Goditi la serata!"


    old "And be on time tomorrow!"
    new "E sii puntuale domani!"


    old "No worries!"
    new "Nessun problema!"











translate italian strings:


    old "Kira"
    new "Kira"


    old "Red"
    new "Rosso"


    old "Charlotte"
    new "Carlotta"


    old "Hey! Just got your contact info from OS!"
    new "Ciao! Ho appena ricevuto le tue informazioni di contatto da OS!"


    old "Oh okay!"
    new "Va bene!"


    old "We're heading to Palazio tomorrow."
    new "Domani andremo a Palazio."


    old "Wanna come with us?"
    new "Vuoi venire con noi?"


    old "Sure. I'll come along!"
    new "Certo. Verrò anch'io!"


    old "That'd be awesome, yeah!"
    new "Sarebbe fantastico, sì!"


    old "I'll send you the address if you want."
    new "Se vuoi, ti mando l'indirizzo."


    old "Great!"
    new "Grande!"


    old "No, thank you!"
    new "No, grazie!"


    old "Oh? Alright."
    new "Ah, va bene."


    old "I'd rather rest up for the competition."
    new "Preferisco riposarmi per la gara."


    old "No worries. I get it!"
    new "Non preoccuparti. Ho capito!"


    old "Hummm... Totally out of place but..."
    new "Hummm... Completamente fuori luogo ma..."


    old "Do you have had an affair with Red at the party? "
    new "Hai avuto una relazione con Red alla festa?"


    old "Yeah. Why?"
    new "Sì. Perché?"


    old "Oh, just to know. I was curious if it was true!"
    new "Oh, giusto per saperlo. Ero curioso di sapere se era vero!"


    old "No. Why?"
    new "No. Perché?"


    old "Oh, just to know. I was just curious!"
    new "Oh, giusto per saperlo. Ero solo curioso!"


    old "Well, see you!"
    new "Bene, ci vediamo!"


    old "See you!"
    new "Ci vediamo!"


    old "Here’s the message you asked for!"
    new "Ecco il messaggio che hai chiesto!"


    old "Perfect."
    new "Perfetto."


    old "That’s it?"
    new "Questo è tutto?"


    old "What were you expecting?"
    new "Cosa ti aspettavi?"


    old "This way I don’t have to enter your info manually. It does everything by itself."
    new "In questo modo non devo inserire manualmente le tue informazioni. Fa tutto da solo."


    old "I mean, we could have used this as an excuse to talk... get to know each other..."
    new "Voglio dire, avremmo potuto usare questa come scusa per parlare... per conoscerci..."


    old "Right?"
    new "Giusto?"


    old "No."
    new "NO."


    old "Well, I guess tonight’s not the night I’ll get a photo of you then?"
    new "Beh, immagino che stasera non sia la sera giusta per farti una foto, vero?"


    old "A photo? Why would I send you a photo?"
    new "Una foto? Perché dovrei inviarti una foto?"


    old "I don’t know. So I can have something of yours."
    new "Non lo so. Quindi posso avere qualcosa di tuo."


    old "Something of mine."
    new "Qualcosa di mio."


    old "Let me think about it."
    new "Lasciami pensarci."


    old "Take your time, I’m patient."
    new "Prenditi il ​​tuo tempo, sono paziente."


    old "Yeah, sure. Keep dreaming..."
    new "Sì, certo. Continua a sognare..."


    old "This is all you will have from me."
    new "Questo è tutto ciò che avrai da me."


    old "Wait, seriously? A cleavage shot... and a toilet in the background?"
    new "Aspetta, sul serio? Uno scatto della scollatura... e un water sullo sfondo?"


    old "You’re truly one of a kind, Beth."
    new "Sei davvero unica nel tuo genere, Beth."


    old "Take it or leave it."
    new "Prendere o lasciare."


    old "Oh, I’m keeping it. It’ll be the highlight of my collection."
    new "Oh, lo tengo. Sarà il pezzo forte della mia collezione."


    old "Good night, [name]. Enjoy staring at your phone."
    new "Buonanotte, [name]. Goditi lo sguardo fisso sul tuo telefono."


    old "Good night, Beth."
    new "Buonanotte, Beth."


    old "Hey, you!"
    new "Ei, tu!"


    old "Yeah?"
    new "Sì?"


    old "You think I didn't see you spying on us at the Palazio earlier?"
    new "Credi che non ti abbia visto spiarci prima al Palazzo?"


    old "That's nonsense!"
    new "Questa è una sciocchezza!"


    old "Yeah, yeah..."
    new "Yeah Yeah..."


    old "I totally figured out that Gabriella was talking about you, you know!"
    new "Ho capito subito che Gabriella stava parlando di te, lo sai!"


    old "I have no idea what you're talking about."
    new "Non ho idea di cosa tu stia parlando."


    old "Of course you don’t."
    new "Certo che no."


    old "I'm gonna set something up. You'll thank me later!"
    new "Sto per organizzare qualcosa. Mi ringrazierai più tardi!"


    old "What are you gonna do?"
    new "Cosa farai?"


    old "I have my little idea. Anyway, good night!"
    new "Ho la mia piccola idea. Comunque, buonanotte!"


    old "Good night!"
    new "Buona notte!"







translate italian strings:


    old "Evelyn"
    new "Evelyn"


    old "Hi Evelyn, it's me from the Palazio. I just wanted to say you really caught my attention last night."
    new "Ciao Evelyn, sono io del Palazio. Volevo solo dirti che ieri sera hai davvero catturato la mia attenzione."


    old "Well, well. I wasn’t sure if you’d actually message me."
    new "Bene, bene. Non ero sicuro che mi avresti mandato un messaggio."


    old "I almost didn’t, but then I thought, what’s life without a little risk?"
    new "Stavo per dire di no, ma poi ho pensato: che vita sarebbe senza un po' di rischio?"


    old "A bold move. I like that."
    new "Una mossa audace. Mi piace."


    old "And here I thought you might enjoy a little intrigue in your day."
    new "E qui ho pensato che avreste potuto divertirvi un po' durante la giornata."


    old "Intrigue… and confidence. You might be onto something."
    new "Intrigo... e sicurezza. Potresti essere sulla buona strada."


    old "Why don’t we see if you’re as bold in person as you are over text?"
    new "Perché non vediamo se sei audace anche di persona come lo sei nei messaggi?"


    old "Sounds like a challenge. What do you have in mind?"
    new "Sembra una sfida. Cosa hai in mente?"


    old "There’s a cozy café on River Street. Meet me there tomorrow night. 7 PM."
    new "C'è un bar accogliente in River Street. Ci vediamo lì domani sera, alle 19:00."


    old "I’ll be there."
    new "Io ci sarò."


    old "Good. I’ll see you then."
    new "Bene. Ci vediamo allora."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
