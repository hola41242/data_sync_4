
translate italian strings:


    old "Calls"
    new "Chiamate"


    old "No recent calls"
    new "Nessuna chiamata recente"


    old "The {date} at {time}"
    new "Il {date} in {time}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
