

translate italian strings:


    old "Facetime - [phone.calls._current_caller.name!t]"
    new "FaceTime - [phone.calls._current_caller.name!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
