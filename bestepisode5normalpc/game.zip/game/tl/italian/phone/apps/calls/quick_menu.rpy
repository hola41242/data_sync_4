
translate italian strings:


    old "Settings"
    new "Impostazioni"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
