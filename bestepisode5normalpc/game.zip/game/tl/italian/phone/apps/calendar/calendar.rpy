
translate italian strings:


    old "Monday"
    new "Lunedi"


    old "Tuesday"
    new "Martedì"


    old "Wednesday"
    new "Mercoledì"


    old "Thursday"
    new "Giovedì"


    old "Friday"
    new "Venerdì"


    old "Saturday"
    new "Sabato"


    old "Sunday"
    new "Domenica"


    old "January"
    new "Gennaio"


    old "February"
    new "Febbraio"


    old "March"
    new "Marzo"


    old "April"
    new "aprile"


    old "May"
    new "Maggio"


    old "June"
    new "Giugno"


    old "July"
    new "Luglio"


    old "August"
    new "agosto"


    old "September"
    new "settembre"


    old "October"
    new "ottobre"


    old "November"
    new "novembre"


    old "December"
    new "Dicembre"


    old "Calendar"
    new "Calendario"


    old "[calendar.month_name]-[calendar.year]"
    new "[calendar.month_name]-[calendar.year]"


    old "Notes:"
    new "Appunti:"


    old "No description provided."
    new "Nessuna descrizione fornita."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
