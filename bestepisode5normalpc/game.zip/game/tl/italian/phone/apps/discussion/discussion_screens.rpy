
translate italian strings:


    old "Type a message."
    new "Scrivi un messaggio."


    old "Send"
    new "Inviare"


    old "Load More"
    new "Carica altro"


    old "{u}{i}Loading Image...{i}{/u}"
    new "{u} {i} Caricamento immagine... {i} {/u}"


    old "{u}{i}Loading Audio...{i}{/u}"
    new "{u} {i} Caricamento audio... {i} {/u}"


    old "{u}{i}Loading Video...{i}{/u}"
    new "{u} {i} Caricamento video... {i} {/u}"


    old "Go Back"
    new "Torna indietro"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
