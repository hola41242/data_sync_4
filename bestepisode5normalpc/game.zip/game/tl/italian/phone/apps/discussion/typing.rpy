
translate italian strings:


    old "[sender.short_name!t] is typing..."
    new "[sender.short_name!t] sta scrivendo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
