
translate italian strings:


    old "Empty group chat"
    new "Chat di gruppo vuota"


    old "Image sent"
    new "Immagine inviata"


    old "Audio sent"
    new "Audio inviato"


    old "Video sent"
    new "Video inviato"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
