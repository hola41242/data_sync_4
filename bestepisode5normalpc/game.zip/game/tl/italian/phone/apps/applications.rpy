
translate italian strings:


    old "message"
    new "Messaggio"


    old "calendar"
    new "calendario"


    old "call"
    new "chiamata"













translate italian strings:


    old "Discussions"
    new "Discussioni"


    old "Stats"
    new "Statistiche"


    old "Wallpaper"
    new "Sfondo"







translate italian strings:


    old "Bios"
    new "Biografie"


    old "OnlyStan"
    new "SoloStan"







translate italian strings:


    old "Skills"
    new "Competenze"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
