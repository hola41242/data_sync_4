
translate italian strings:


    old "Messages"
    new "Messaggi"


    old "No group chats"
    new "Nessuna chat di gruppo"


    old "The [group_chat._date_text] at [group_chat._hour_text]"
    new "Il [group_chat._date_text] in [group_chat._hour_text]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
