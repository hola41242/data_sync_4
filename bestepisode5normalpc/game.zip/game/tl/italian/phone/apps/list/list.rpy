

translate italian strings:


    old "Contacts"
    new "Contatti"











translate italian strings:


    old "Elizabeth"
    new "Elizabeth"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
