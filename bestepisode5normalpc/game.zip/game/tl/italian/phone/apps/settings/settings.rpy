

translate italian strings:


    old "Phone Theme"
    new "Tema del telefono"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
