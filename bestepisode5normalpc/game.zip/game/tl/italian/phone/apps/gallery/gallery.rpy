

translate italian strings:


    old "Replays"
    new "Ripetizioni"


    old "Extras"
    new "Extra"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
