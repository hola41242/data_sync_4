

translate italian strings:


    old "Your wallpaper was changed!"
    new "Il tuo sfondo è stato cambiato!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
