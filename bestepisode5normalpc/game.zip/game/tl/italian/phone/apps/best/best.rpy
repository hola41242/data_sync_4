

translate italian strings:


    old "Affair"
    new "Affare"


    old "Bowling"
    new "Bowling"


    old "Dance"
    new "Ballare"


    old "Library"
    new "Biblioteca"


    old "Auditorium"
    new "Auditorium"


    old "Museum"
    new "Museo"


    old "Port"
    new "Porta"


    old "Gym"
    new "Palestra"


    old "Park"
    new "Parco"


    old "A maze of glass and steel where dreams are priced and ambitions are signed."
    new "Un labirinto di vetro e acciaio dove i sogni hanno un prezzo e le ambizioni vengono firmate."


    old "A place where every move strives to turn the unfinished into a spare."
    new "Un luogo in cui ogni mossa mira a trasformare l'incompiuto in qualcosa di nuovo."


    old "A space where every step composes a melody and every movement brings the rhythm to life."
    new "Uno spazio dove ogni passo compone una melodia e ogni movimento dà vita al ritmo."


    old "A sanctuary where words whisper secrets and pages keep time in memory."
    new "Un santuario dove le parole sussurrano segreti e le pagine conservano il tempo nella memoria."


    old "Tes connaissances s'accumulent ici"
    new "Le tue conoscenze si accumulano qui"


    old "A vault where time stands still and every artifact whispers echoes of an immortal past."
    new "Un caveau dove il tempo si ferma e ogni manufatto sussurra echi di un passato immortale."


    old "A theater where ropes sing in the wind and every departure promises an adventure to tell."
    new "Un teatro dove le corde cantano nel vento e ogni partenza promette un'avventura da raccontare."


    old "A temple where every effort shapes determination and every drop of sweat writes perseverance."
    new "Un tempio dove ogni sforzo plasma la determinazione e ogni goccia di sudore scrive perseveranza."


    old "A haven where nature paints living pictures and the wind tells forgotten tales."
    new "Un rifugio dove la natura dipinge quadri viventi e il vento racconta storie dimenticate."


    old "Minimap"
    new "Minimappa"


    old "Hints"
    new "Suggerimenti"


    old "Mastermind"
    new "Mente"


    old "{b}Hint "
    new "{b}Suggerimento"


    old "{/b}: "
    new "{/b}:"


    old "{s}{b}Hint "
    new "{s}{b}Suggerimento"


    old "Found number: {b}"
    new "Numero trovato: {b}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
