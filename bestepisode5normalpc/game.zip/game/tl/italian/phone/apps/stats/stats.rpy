

translate italian strings:


    old "B.E.S.T RANK"
    new "MIGLIOR CLASSIFICA"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
