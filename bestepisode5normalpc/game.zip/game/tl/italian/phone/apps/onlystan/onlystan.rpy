

translate italian strings:


    old "A simple boy who just want to meet friends here :)"
    new "Un ragazzo semplice che vuole solo incontrare degli amici qui :)"


    old "A simple girl who likes simple things"
    new "Una ragazza semplice a cui piacciono le cose semplici"


    old "Pretty girls out there!"
    new "Ci sono belle ragazze là fuori!"


    old "Here to meet beautiful young girls 🤤!"
    new "Qui per incontrare bellissime ragazze 🤤!"


    old "Just a flexible guy looking for fun!"
    new "Solo un ragazzo flessibile in cerca di divertimento!"


    old "Feeling lonely, let's chat and share good vibes ❤️!"
    new "Se ti senti solo, chiacchieriamo e condividiamo buone vibrazioni ❤️!"


    old "Big dreams, small beginnings. Let's connect!"
    new "Grandi sogni, piccoli inizi. Connettiamoci!"


    old "I bring the sass to OnlyStan 😎."
    new "Porto la mia sfacciataggine su OnlyStan 😎."


    old "Always here to support you 😉."
    new "Sempre qui per supportarti 😉."


    old "Busy and bubbly, ready for fun! 💦"
    new "Indaffarati e frizzanti, pronti per il divertimento! 💦"


    old "Just a guy with a big heart (and maybe more...) 😏."
    new "Solo un ragazzo con un grande cuore (e forse di più...) 😏."


    old "What can I say? I'm a cheeky kind of guy 😜!"
    new "Cosa posso dire? Sono un tipo sfacciato 😜!"


    old "Hello! My name is Fanny and I am new here. Tell me what you like in the comments ;)"
    new "Ciao! Mi chiamo Fanny e sono nuova qui. Raccontami cosa ti piace nei commenti ;)"


    old "Hi everyone :)!"
    new "Ciao a tutti :)!"


    old "Very beautiful! I'm very happy to meet you there 😊"
    new "Molto bello! Sono molto felice di incontrarti lì 😊"


    old "Beach day! 🌴🏖️"
    new "Giornata in spiaggia! 🌴🏖️"


    old "Take me with you next time 😂! I love your outfit btw"
    new "Portami con te la prossima volta 😂! A proposito, adoro il tuo vestito"


    old "Preparing for a party with my best friend 💕"
    new "Mi sto preparando per una festa con la mia migliore amica 💕"


    old "A party? Count me in! Just tell me where and when, I’ll bring the good vibes 🎉!"
    new "Una festa? Conta su di me! Dimmi solo dove e quando, porterò le buone vibrazioni 🎉!"


    old "Pretty girl 🤤"
    new "Bella ragazza 🤤"


    old "Hey ! I love your body... Would you like to get to know each other 😉?"
    new "Ciao! Adoro il tuo corpo... Ti piacerebbe conoscerci meglio 😉?"


    old "My D is still so hard seeing you 🥵🥵"
    new "La mia D è ancora così dura nel vederti 🥵🥵"


    old "I am so honoured to breath the same air as you 🥵😍"
    new "Sono così onorato di respirare la tua stessa aria 🥵😍"


    old "I'm bending over backwards just to comment here 😉"
    new "Mi sto piegando all'indietro solo per commentare qui 😉"


    old "You look like someone who needs a hug 🥰"
    new "Sembri qualcuno che ha bisogno di un abbraccio 🥰"


    old "Ben, you're always bending over for attention 🤦‍♀️"
    new "Ben, ti pieghi sempre per attirare l'attenzione 🤦‍♀️"


    old "Anita, don’t be so mean! Everyone deserves a little flexibility 😏"
    new "Anita, non essere così cattiva! Tutti meritano un po' di flessibilità 😏"


    old "Wow, this is small talk at its finest 😏"
    new "Wow, questa è la chiacchierata più bella del mondo 😏"


    old "This beach photo is making waves 🌊!"
    new "Questa foto della spiaggia sta facendo scalpore 🌊!"


    old "Hugh, you're just fishing for compliments again 🎣"
    new "Hugh, stai di nuovo cercando solo complimenti 🎣"


    old "Seymour, let him enjoy the tide, it's not every day we get such views 😎"
    new "Seymour, lascialo godere della marea, non capita tutti i giorni di vedere queste viste 😎"


    old "Party with friends? Save me a spot next time! 🎉"
    new "Vuoi festeggiare con gli amici? Tienimi un posto la prossima volta! 🎉"


    old "Willie, you weren't invited last time for a reason... 😒"
    new "Willie, l'ultima volta non ti hanno invitato per un motivo... 😒"


    old "Ivana, don't be salty, we all know Willie likes to party hard 😉"
    new "Ivana, non essere irritata, sappiamo tutti che a Willie piace fare festa alla grande 😉"


    old "Anita, you're the life of the party, admit it ❤️!"
    new "Anita, sei l'anima della festa, ammettilo ❤️!"


    old "Hard to resist such beauty 😏🔥"
    new "Difficile resistere a tanta bellezza 😏🔥"


    old "Always here to have your back ❤️"
    new "Sempre qui per sostenerti ❤️"


    old "Cheeky post! Keep them coming 😜"
    new "Post sfacciato! Continua così 😜"


    old "This made me tinkle with laughter 💦"
    new "Questo mi ha fatto morire dal ridere 💦"


    old "Welcome back, "
    new "Bentornato,"


    old "See comments"
    new "Vedi commenti"


    old "Comments"
    new "Commenti"


    old "No comments"
    new "Non ci sono commenti"


    old "+ Add comment"
    new "+ Aggiungi commento"


    old "No posts"
    new "Nessun post"


    old "Posts"
    new "Messaggi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
