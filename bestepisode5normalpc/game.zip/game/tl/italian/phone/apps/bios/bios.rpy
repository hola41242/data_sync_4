

translate italian strings:


    old "[name]:\n\nJust a regular guy trying to navigate through life and make sense of everything. Sometimes lucky, sometimes clumsy, but always trying to do the right thing... most of the time."
    new "[name]:\n\nSolo un ragazzo normale che cerca di orientarsi nella vita e dare un senso a tutto. A volte fortunato, a volte goffo, ma cerca sempre di fare la cosa giusta... la maggior parte delle volte."


    old "Ruby Suyin:\n\nPlayful and funny, Ruby charms everyone with her spontaneity and natural charisma. A bit scatterbrained but genuine, she lives in the moment and brightens the story with her joyful spirit."
    new "Ruby Suyin:\n\nGiocosa e divertente, Ruby affascina tutti con la sua spontaneità e il suo carisma naturale. Un po' sbadata ma genuina, vive il momento e illumina la storia con il suo spirito gioioso."


    old "Madison Forrester:\n\nHeiress of the powerful Forrester family, Madison juggles family duties, studies, and motherhood. Strong yet conflicted, she hides her doubts behind a polished facade."
    new "Madison Forrester:\n\nErede della potente famiglia Forrester, Madison si destreggia tra doveri familiari, studi e maternità. Forte ma in conflitto, nasconde i suoi dubbi dietro una facciata raffinata."


    old "Grace Drew:\n\nGrace is kind and selfless, always striving to meet her mother’s high expectations. Her warmth hides the pressure she feels to balance duty and her own desires."
    new "Grace Drew:\n\nGrace è gentile e altruista, si sforza sempre di soddisfare le grandi aspettative della madre. Il suo calore nasconde la pressione che sente nel dover bilanciare dovere e desideri personali."


    old "Julia Carter:\n\nReserved and enigmatic, Julia carries a quiet strength that hints at untold stories. Her thoughtful gaze and calm demeanor conceal a world of emotions and secrets, making her both captivating and elusive."
    new "Julia Carter:\n\nRiservata ed enigmatica, Julia porta con sé una forza silenziosa che allude a storie mai raccontate. Il suo sguardo pensieroso e il suo atteggiamento calmo nascondono un mondo di emozioni e segreti, rendendola allo stesso tempo accattivante e sfuggente."


    old "Elise Moreau:\n\nElise is the hero's steadfast friend, always ready with sharp wit and sound advice. Loyal and resourceful, she’s a reliable ally who values honesty and isn’t afraid to speak her mind."
    new "Elise Moreau:\n\nElise è l'amica fedele dell'eroe, sempre pronta a dare consigli sensati e arguti. Leale e intraprendente, è un'alleata affidabile che apprezza l'onestà e non ha paura di dire quello che pensa."


    old "Gabriella Fernandez:\n\nGabriella is a reserved and solitary professor, torn between her strict principles and her growing feelings for the protagonist. Her loneliness fuels her inner turmoil."
    new "Gabriella Fernandez:\n\nGabriella è una professoressa riservata e solitaria, combattuta tra i suoi rigidi principi e i suoi crescenti sentimenti per la protagonista. La sua solitudine alimenta il suo tumulto interiore."


    old "Charlotte Sinclair:\n\nCharlotte is a free spirit with a rebellious streak, unafraid to challenge norms and live life on her own terms. Her boldness hides a deep desire for connection."
    new "Charlotte Sinclair:\n\nCharlotte è uno spirito libero con una vena ribelle, che non ha paura di sfidare le norme e vivere la vita alle sue condizioni. La sua audacia nasconde un profondo desiderio di connessione."


    old "Elizabeth ‘Beth’ Da Fonseca:\n\nElisabeth, known as Red, is confident and assertive, always taking charge of any situation. Her dominant personality masks a softer side she rarely shows."
    new "Elizabeth 'Beth' Da Fonseca:\n\nElisabeth, conosciuta come Red, è sicura di sé e assertiva, prende sempre in mano la situazione. La sua personalità dominante maschera un lato più dolce che raramente mostra."


    old "Sofia Da Fonseca:\n\nOutgoing and carefree, Sofia embraces life with a lighthearted charm. She’s known for her quick wit and an open mind, often breaking the tension with her humor and spontaneity."
    new "Sofia Da Fonseca:\n\nEstroversa e spensierata, Sofia abbraccia la vita con un fascino spensierato. È nota per la sua arguzia e la sua mente aperta, spesso spezzando la tensione con il suo umorismo e la sua spontaneità."


    old "Kira Orushi:\n\nAdventurous and headstrong, Kira thrives on independence and freedom. As an Orushi, she balances high expectations with her rebellious charm."
    new "Kira Orushi:\n\nAvventurosa e testarda, Kira prospera grazie all'indipendenza e alla libertà. Come Orushi, bilancia grandi aspettative con il suo fascino ribelle."


    old "Emerick Orushi:\n\nEmerick is cunning and arrogant, always scheming to maintain his status. As a member of the Orushi family, he wields influence but often underestimates those around him."
    new "Emerick Orushi:\n\nEmerick è astuto e arrogante, sempre a complottare per mantenere il suo status. Come membro della famiglia Orushi, esercita influenza ma spesso sottovaluta chi lo circonda."


    old "Steven Johnson:\n\nThe captain of the men’s football team, Steven commands respect with his natural authority and calm demeanor. His leadership skills and steady presence make him a cornerstone for his team, both on and off the field."
    new "Steven Johnson:\n\nCapitano della squadra di football maschile, Steven incute rispetto con la sua naturale autorità e il suo atteggiamento calmo. Le sue capacità di leadership e la sua presenza costante lo rendono un pilastro della squadra, sia dentro che fuori dal campo."


    old "Mac Harper:\n\nFriendly and easygoing, Mac is the type of guy who can get along with anyone. His laid-back attitude often hides his competitive spirit, which shines through when it comes to sports or a challenge he can’t resist."
    new "Mac Harper:\n\nAmichevole e accomodante, Mac è il tipo di ragazzo che può andare d'accordo con chiunque. Il suo atteggiamento rilassato nasconde spesso il suo spirito competitivo, che traspare quando si tratta di sport o di una sfida a cui non sa resistere."


    old "Ben Baker:\n\nLoyal and hardworking, Ben is the kind of person who puts others before himself. Though he often downplays his own achievements, his determination and dedication make him a dependable friend and teammate."
    new "Ben Baker:\n\nLeale e laborioso, Ben è il tipo di persona che mette gli altri prima di sé. Sebbene spesso minimizzi i suoi successi, la sua determinazione e dedizione lo rendono un amico e un compagno di squadra affidabile."


    old "Hector Alvarez:\n\nRuthlessly ambitious, Hector is willing to do whatever it takes to get ahead. As Emerick’s loyal follower, he often finds himself executing questionable plans, putting his own morals aside to stay in his good graces."
    new "Hector Alvarez:\n\nSpietatamente ambizioso, Hector è disposto a fare qualsiasi cosa per andare avanti. Come fedele seguace di Emerick, spesso si ritrova a mettere in atto piani discutibili, mettendo da parte la propria morale per restare nelle sue grazie."


    old "Ted Forrester:\n\nTed is Madison's brother, loyal to the Forrester legacy but often clashing with her over family expectations. His sense of duty masks a more calculating side."
    new "Ted Forrester:\n\nTed è il fratello di Madison, fedele all'eredità dei Forrester ma spesso in conflitto con lei per le aspettative familiari. Il suo senso del dovere maschera un lato più calcolatore."


    old "Cassie Forrester:\n\nCassie is Madison’s young daughter, full of energy and curiosity. Her cheerful spirit brings light to Madison’s demanding life, even as she navigates the complexities of her family."
    new "Cassie Forrester:\n\nCassie è la giovane figlia di Madison, piena di energia e curiosità. Il suo spirito allegro porta luce nella vita impegnativa di Madison, anche mentre affronta le complessità della sua famiglia."


    old "Mrs. Drew:\n\nMrs. Drew is Grace’s demanding mother, holding her daughter to the highest standards. Behind her strictness lies a deep desire to see Grace succeed, even at the cost of personal warmth."
    new "Mrs. Drew:\n\nLa signora Drew è la madre esigente di Grace, che pretende dalla figlia standard elevatissimi. Dietro la sua severità si nasconde un profondo desiderio di vedere Grace avere successo, anche a costo di perdere il calore personale."


    old "Mr. Orushi:\n\nMr. Orushi is the patriarch of the Orushi family, a calculating and authoritative figure who demands loyalty and excellence from everyone around him. His ambition and influence shape both his family and the city."
    new "Sig. Orushi:\n\nIl Sig. Orushi è il patriarca della famiglia Orushi, una figura autorevole e calcolatrice che esige lealtà ed eccellenza da tutti coloro che lo circondano. La sua ambizione e influenza plasmano sia la sua famiglia che la città."


    old "Charles Forrester:\n\nCharles Forrester is the proud patriarch of the Forrester family. Ambitious and commanding, he strives to maintain his family’s dominance in the city, often at the expense of personal relationships"
    new "Charles Forrester:\n\nCharles Forrester è l'orgoglioso patriarca della famiglia Forrester. Ambizioso e autoritario, si sforza di mantenere il predominio della sua famiglia in città, spesso a scapito delle relazioni personali"


    old "Carmen Forrester:\n\nCarmen Forrester is the graceful matriarch of the Forrester family. Often acting as a peacemaker, she balances her loyalty to her husband with her compassion for her children."
    new "Carmen Forrester:\n\nCarmen Forrester è la graziosa matriarca della famiglia Forrester. Spesso agendo da paciera, bilancia la sua lealtà verso il marito con la sua compassione per i figli."


    old "She barely knows you..."
    new "Ti conosce appena..."


    old "You're becoming friends."
    new "State diventando amici."


    old "You're starting to mean something to her."
    new "Stai iniziando a significare qualcosa per lei."


    old "You shared a kiss."
    new "Vi siete scambiati un bacio."


    old "A deep bond is forming between you."
    new "Tra voi si sta formando un legame profondo."


    old "Madly in love."
    new "Follemente innamorato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
