
translate italian strings:


    old "< Back"
    new "< Indietro"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
