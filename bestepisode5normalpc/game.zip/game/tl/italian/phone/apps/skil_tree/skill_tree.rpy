

translate italian strings:


    old "Welcome to the B.E.S.T profile"
    new "Benvenuti nel profilo BEST"


    old "Once you reach 10 points in a stat, you can activate it"
    new "Una volta raggiunti 10 punti in una statistica, puoi attivarla"


    old "Your specialization will have effects during the B.E.S.T contest"
    new "{size=-5}La tua specializzazione avrà effetti durante il concorso BEST"


    old "{i}Click to continue{/i}"
    new "{i}Clicca per continuare{/i}"


    old "You have unlocked the {color=#d90000}Buddy{/color} specialization! You can now enable it!"
    new "Hai sbloccato la specializzazione {color=#d90000}Buddy{/color}! Ora puoi abilitarla!"


    old "Click to continue"
    new "Clicca per continuare"


    old "You have unlocked the {color=#d90000}Temperament{/color} specialization! You can now enable it!"
    new "Hai sbloccato la specializzazione {color=#d90000}Temperamento{/color}! Ora puoi abilitarla!"


    old "You have unlocked the {color=#d90000}Sport{/color} specialization! You can now enable it!"
    new "Hai sbloccato la specializzazione {color=#d90000}Sport{/color}! Ora puoi abilitarla!"


    old "You have unlocked the {color=#d90000}Education{/color} specialization! You can now enable it!"
    new "Hai sbloccato la specializzazione {color=#d90000}Istruzione{/color}! Ora puoi abilitarla!"


    old "Buddy specialization enabled!"
    new "Abilitata la specializzazione Buddy!"


    old "Temperament specialization enabled!"
    new "Abilitata la specializzazione del temperamento!"


    old "Temp."
    new "Temp."


    old "Education specialization enabled!"
    new "Abilitata la specializzazione in ambito formativo!"


    old "Educ."
    new "Istr."


    old "Sport specialization enabled!"
    new "Abilitata la specializzazione sportiva!"


    old "Sport"
    new "Sport"


    old "Get at least {color=#d90000}10 points{/color} of a {color=#d90000}stat{/color} to unlock its {color=#d90000}specialization{/color}!"
    new "Ottieni almeno {color=#d90000}10 punti{/color} di una {color=#d90000}statistica{/color} per sbloccare la sua {color=#d90000}specializzazione{/color}!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
