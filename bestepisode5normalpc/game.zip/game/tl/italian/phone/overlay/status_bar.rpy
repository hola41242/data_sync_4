
translate italian strings:


    old "LTE"
    new "LTE"


    old "Screen\nMirroring"
    new "Schermo\nMirroring"


    old "Music"
    new "Musica"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
