
translate italian strings:


    old "You have entered the B.E.S.T Game"
    new "Sei entrato nel gioco B.E.S.T"


    old "Start the game"
    new "Inizia il gioco"


    old "What an ass!"
    new "Che culo!"


    old "Grope Julia"
    new "Tentare Julia"


    old "Cotton Eye Joe !"
    new "Cotton Eye Joe !"


    old "Don't touch Julia"
    new "Non toccare Julia"


    old "Catch them all!"
    new "Catturali tutti!"


    old "Catch Grace"
    new "Cattura Grace"


    old "Life in redhead !"
    new "La vita in rosso !"


    old "You've put Grace on her bed"
    new "Hai messo Grace sul suo letto"


    old "Show must go on !"
    new "Lo spettacolo deve continuare !"


    old "Finish the Prologue"
    new "Termina il prologo"


    old "Pinky and the Braid!"
    new "Mignolo e la treccia!"


    old "Play the Minus and Cortex game"
    new "Gioca al gioco Minus e Cortex"


    old "You are the winner!"
    new "Sei il vincitore!"


    old "Finish First with Madison ?"
    new "Finire prima con Madison ?"


    old "You deserve it!"
    new "Te lo meriti!"


    old "Accept the reward"
    new "Accetta la ricompensa"


    old "You're not first meh!"
    new "Non sei il primo meh!"


    old "Accept the Special Reward"
    new "Accetta la ricompensa speciale"


    old "First !!!"
    new "Primo !!!"


    old "Finish the First Episode"
    new "Completa il primo episodio"


    old "Outstanding!"
    new "Eccezionale!"


    old "Get all achievements."
    new "Ottieni tutti gli obiettivi."


    old "Victory !!!"
    new "Vittoria !!!"


    old "Win versus Grace"
    new "Vinci contro Grace"


    old "Cheater !!!"
    new "Imbroglione!!!"


    old "Cheat versus Grace"
    new "Imbroglio contro Grace"


    old "Day of Defeat !!!"
    new "Giorno della sconfitta !!!"


    old "You let Grace win... Right ?"
    new "Hai lasciato vincere Grace... Giusto?"


    old "Evolution !!!"
    new "Evoluzione !!!"


    old "From Squirtle to Squirter"
    new "Da Squirtle a Squirter"


    old "Her hero!!!"
    new "Il suo eroe!!!"


    old "You're Ruby's Hero..."
    new "Sei l'eroe di Ruby..."


    old "Hat Trick !!!"
    new "Tripletta !!!"


    old "All for Madison !"
    new "Tutto per Madison!"


    old "Harem Vibes!!!"
    new "Vibrazioni dell'Harem!!!"


    old "Women likes you..."
    new "Piaci alle donne..."


    old "First Kiss!!!"
    new "Primo bacio!!!"


    old "Grace for ever !"
    new "Grace per sempre!"


    old "Of course!!!"
    new "Ovviamente!!!"


    old "Madison..."
    new "Madison..."


    old "Just the Beginning!"
    new "Solo l'inizio!"


    old "Finish the Second Episode"
    new "Completa il secondo episodio"



translate italian strings:


    old "You tried..."
    new "Hai provato..."


    old "Meh..."
    new "Mah..."


    old "You're a genius!!!"
    new "Sei un genio!!!"


    old "But unknown..."
    new "Ma sconosciuto..."


    old "Milfs are life!!!"
    new "Le MILF sono la vita!!!"


    old "Better with experience..."
    new "Meglio con l'esperienza..."




translate italian strings:


    old "Like a virgin!"
    new "Come una vergine!"


    old "Touch for the very first time..."
    new "Tocca per la prima volta..."


    old "You switched!"
    new "Hai cambiato!"


    old "From Blue to Red..."
    new "Dal Blu al Rosso..."


    old "Road to Victory!"
    new "Strada verso la vittoria!"


    old "Finish the Third Episode"
    new "Completa il terzo episodio"



translate italian strings:


    old "Pet's Friend"
    new "Amico dell'animale domestico"


    old "Mewww..."
    new "Miaooo..."


    old "Opportunity Missed"
    new "Opportunità persa"


    old "You were on the right track..."
    new "Eri sulla strada giusta..."


    old "You're the BEST!"
    new "Sei il MIGLIORE!"


    old "A Star is born..."
    new "È nata una stella..."


    old "Madison is the BEST!"
    new "Madison è la MIGLIORE!"


    old "Ally or enemy???"
    new "Alleato o nemico???"


    old "Man of the match!"
    new "L'uomo della partita!"


    old "Play it like Beckham!"
    new "Gioca come Beckham!"



translate italian strings:


    old "You finished Episode 4!"
    new "Hai terminato l'episodio 4!"


    old "RUBYYYYYYYY!"
    new "RUBYOOOOOOOOO!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
