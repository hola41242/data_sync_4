translate italian strings:

    old "#8cb5ef"
    new "#8cb5ef"

    old "hide"
    new "nascondere"

    old "K_ESCAPE"
    new "K_ESCAPE"

    old "t b"
    new "tubercolosi"

    old "#ffffffcc"
    new "#ffffffcc"

    old "{/s}"
    new "{/s}"

    old "{/b}"
    new "{/b}"

    old "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball"
    new "telefono/assets/mastermind_best/mastermindballs/mastermindwhiteball"

    old "[relationship_status!t]"
    new "[relationship_status!t]"

    old "t c"
    new "TC"

    old "l c r"
    new "lcr"

    old "#302D29"
    new "#302D29"

    old "t b c"
    new "da confermare"

    old "l r"
    new "sinistra"

    old "phone_textbox_text"
    new "casella di testo del telefono"

    old "mouseup_1"
    new "mouseup_1"

    old "mouseup_3"
    new "mouseup_3"

    old "gallery0"
    new "galleria0"

    old "[elt.text!t]"
    new "[elt.text!t]"

    old "#ffffff"
    new "#ffffff"

    old "[post.title!t]"
    new "[post.title!t]"

    old "[post.text!t]"
    new "[post.text!t]"

    old "{b}@"
    new "{b}@"

    old "[profile.bio!t]"
    new "[profile.bio!t]"

    old "[elt.title!t]"
    new "[elt.title!t]"

    old "#EA3680"
    new "#EA3680"

    old "#b7b7b7"
    new "#b7b7b7"

    old "[Buddy]"
    new "[Buddy]"

    old "[Temperament]"
    new "[Temperament]"

    old "[Education]"
    new "[Education]"

    old "[Sport]"
    new "[Sport]"

    old "#fff"
    new "#fff"

    old "[Rank]"
    new "[Rank]"

    old "ruby"
    new "Ruby"

    old "ruby1"
    new "ruby1"

    old "ruby2"
    new "ruby2"

    old "grace"
    new "Grace"

    old "grace1"
    new "grazia1"

    old "sofia"
    new "Sofia"

    old "sofia1"
    new "sofia1"

    old "elise"
    new "elisa"

    old "eli1"
    new "eli1"

    old "ji"
    new "ji"

    old "ji1"
    new "ji1"

    old "julia"
    new "Julia"

    old "julia1"
    new "Julia1"

    old "mad1"
    new "pazzo1"

    old "gaby1"
    new "gaby1"

    old "kira2"
    new "kira2"

    old "red"
    new "rosso"

    old "cha1"
    new "cha1"

    old "evelyn1"
    new "evelyn1"

    old "mad"
    new "pazzo"

    old "gaby"
    new "gaby"

    old "kira"
    new "Kira"

    old "beth"
    new "Beth"

    old "cha"
    new "cha"

    old "evelyn"
    new "Evelyn"

    old "World Time : "
    new "Ora mondiale: "

    old "_phone_status_bar_text"
    new "_testo_barra_di_stato_del_telefono"

    old "show"
    new "spettacolo"

    old "#c4c4c438"
    new "#c4c4c438"

    old "▸▸"
    new "▸▸"

    old "phone"
    new "telefono"

    old "[config.version]"
    new "[config.version]"

    old "game_menu"
    new "menu_gioco"

    old "[config.name!t]"
    new "[config.name!t]"

    old "[gui.about!t]\n"
    new "[gui.about!t]\\N"

    old "save_delete"
    new "salva_elimina"

    old "[page]"
    new "[page]"

    old "black"
    new "nero"

    old "Shift+A"
    new "Maiusc+A"

    old "[message!tq]"
    new "[message!tq]"

    old "Espanol (LATAM )"
    new "Spagnolo (America Latina)"

    old "Italiano"
    new "Italiano"

    old "Simp. Chinese"
    new "Cinese semplice"

    old "Trad. Chinese"
    new "Cinese tradizionale"

    old "Portuguese (Brasil)"
    new "portoghese (Brasile)"

    old "In a traditional deck of cards,"
    new "In un mazzo di carte tradizionale,"

    old "What is the missing number?"
    new "Qual è il numero mancante?"

    old "If you mix red and blue,"
    new "Se mescoli il rosso e il blu,"

    old "{color=#2735b4ff}Previous{/color}"
    new "{color=#2735b4ff}Precedente{/color}"

    old "{color=#2735b4ff}Next{/color}"
    new "{color=#2735b4ff}Prossimo{/color}"

    old "{color=#fff}Previous{/color}"
    new "{color=#fff}Precedente{/color}"

    old "{color=#fff}Next{/color}"
    new "{color=#fff}Prossimo{/color}"

    old "LATAM "
    new "America Latina "

    old "Brasil"
    new "Brasile"




    old "Hey you!"
    new "Ei, tu!"

    old "Hey, babe."
    new "Ehi, tesoro."

    old "What are you doing tomorrow morning?"
    new "Cosa farai domani mattina?"

    old "Not sure yet. Why? You planning something?"
    new "Non ne sono ancora sicuro. Perché? Stai progettando qualcosa?"

    old "I remember you saying you’d done some climbing before, right?"
    new "Ricordo che dicevi che avevi già fatto un po' di arrampicata, vero?"

    old "Yeah, I have. Thinking of trying it too?"
    new "Sì, l'ho fatto. Stai pensando di provarlo anche tu?"

    old "Mmhmm. I found this amazing climbing spot. I thought it might be fun for us to go together."
    new "Mmmhmm. Ho trovato questo posto fantastico per arrampicare. Ho pensato che sarebbe stato divertente andarci insieme."

    old "Climbing with you? That sounds pretty good."
    new "Arrampicarsi con te? Sembra proprio una bella idea."

    old "So, what do you say?"
    new "Allora, cosa ne dici?"

    old "Sure, let’s do it."
    new "Certo, facciamolo."

    old "Alright, I’m in. What time?"
    new "Bene, ci sono. A che ora?"

    old "How about 7 a.m.? I’ll have everything ready for us."
    new "Che ne dici delle 7 del mattino? Ho già tutto pronto per noi."

    old "Sounds perfect. Looking forward to spending the morning with you."
    new "Sembra perfetto. Non vedo l'ora di passare la mattinata con te."

    old "Same here. Miss you."
    new "Anche io. Mi manchi."

    old "Miss you too, Grace."
    new "Anche tu mi manchi, Grace."

    old "Sorry, I’m not free."
    new "Mi dispiace, non sono libero."

    old "Sorry, babe, I’ve got something tomorrow morning."
    new "Scusa tesoro, ho qualcosa da fare domani mattina."

    old "Oh… okay. Another time then?"
    new "Oh... okay. Un'altra volta allora?"

    old "Of course. Let’s plan it soon."
    new "Certo. Pianifichiamolo presto."

    old "Hey there!"
    new "Ehilà!"

    old "Hey Grace."
    new "Ciao Grace."

    old "I was wondering if you’d like to come climbing with me tomorrow morning."
    new "Mi chiedevo se ti piacerebbe venire ad arrampicare con me domani mattina."

    old "Climbing? I haven’t done that in a while."
    new "Arrampicata? Non lo faccio da un po'."

    old "Didn’t you mention you’ve done some climbing before?"
    new "Non hai detto che hai già fatto un po' di arrampicata in passato?"

    old "Yeah, I’ve gone a few times. What’s up?"
    new "Sì, ci sono andato un paio di volte. Come va?"

    old "There’s a great spot I’ve been wanting to check out, and I thought we could give it a try together."
    new "C'è un posto fantastico che volevo visitare e ho pensato che potremmo provarci insieme."

    old "Sounds interesting. Where is it?"
    new "Sembra interessante. Dov'è?"

    old "It’ll be a nice change of pace, and I could use the company."
    new "Sarà un bel cambiamento di ritmo e mi farebbe piacere la sua compagnia."

    old "What do you think?"
    new "Cosa ne pensi?"

    old "Sure, I’m in."
    new "Certo, ci sto."

    old "Sure, I’d like that. When should we meet?"
    new "Certo, mi piacerebbe. Quando ci vediamo?"

    old "7 a.m. I’ll have everything ready."
    new "Alle 7 del mattino avrò tutto pronto."

    old "Got it, see you then."
    new "Fatto, ci vediamo allora."

    old "I don’t think I can."
    new "Non credo di poterlo fare."

    old "I’m not available tomorrow, sorry."
    new "Mi dispiace, non sono disponibile domani."

    old "No worries. Maybe next time."
    new "Non preoccuparti. Forse la prossima volta."

    old "Sounds good."
    new "Suona bene."

    old "Good evening, [name]."
    new "Buonasera, [name]."

    old "Good evening, Gabriella."
    new "Buonasera, Gabriella."

    old "I’ve been reviewing your performance on the field, and I believe there are areas we could refine before the final match."
    new "Ho esaminato la tua prestazione in campo e credo che ci siano aspetti su cui possiamo lavorare prima della partita finale."

    old "Ah, so you’re saying I need more practice?"
    new "Ah, quindi stai dicendo che ho bisogno di più pratica?"

    old "I’m saying you have potential, and I’d like to help you make the most of it."
    new "Voglio dire che hai del potenziale e vorrei aiutarti a sfruttarlo al meglio."

    old "So, you want to give me a private training session?"
    new "Quindi, vuoi offrirmi una sessione di allenamento privata?"

    old "If you’re available tomorrow afternoon, I can show you a few techniques that might give you an edge."
    new "Se sei disponibile domani pomeriggio, posso mostrarti alcune tecniche che potrebbero darti un vantaggio."

    old "Just the two of us? That sounds… intense."
    new "Solo noi due? Sembra... intenso."

    old "It’s strictly for your development as a player, [name]."
    new "È strettamente per il tuo sviluppo come giocatore, [name]."

    old "Oh, I wouldn’t dream of it being anything else."
    new "Oh, non mi sognerei mai che potesse essere qualcos'altro."

    old "I’m glad we’re on the same page. So, what do you say?"
    new "Sono contento che siamo sulla stessa lunghezza d'onda. Allora, cosa ne dici?"

    old "Sounds good, I’ll be there."
    new "Mi sembra una buona idea, ci sarò."

    old "Sure, I’ll come by. What time should I meet you?"
    new "Certo, passo. A che ora ci vediamo?"

    old "Let’s start at 2 p.m. sharp. Don’t be late."
    new "Iniziamo alle 14 in punto. Non fare tardi."

    old "Wouldn’t miss it for the world."
    new "Non me lo perderei per niente al mondo."

    old "Sorry, I’m busy tomorrow."
    new "Mi dispiace, domani sono impegnato."

    old "Sorry, I have other plans tomorrow evening."
    new "Mi dispiace, ho altri programmi domani sera."

    old "That’s unfortunate. I suppose we’ll have to work with what we have."
    new "È un peccato. Immagino che dovremo arrangiarci con quello che abbiamo."

    old "Next time, professor."
    new "La prossima volta, professore."

    old "Damn, dude, you hit the jackpot! 🎉"
    new "Cavolo, amico, hai fatto centro! 🎉"

    old "Seriously, this is like every guy’s dream. Well played! 😉"
    new "Davvero, questo è il sogno di ogni ragazzo. Ben fatto! 😉"

    old "How do you even get this lucky? I need some tips. 😏"
    new "Come fai ad essere così fortunato? Ho bisogno di qualche consiglio. 😏"

    old "Bro, I’d trade my left shoe to be in your place. 🥲"
    new "Fratello, al tuo posto cambierei la mia scarpa sinistra. 🥲"

    old "Lucky guy… some guys have all the luck! 👏"
    new "Ragazzo fortunato... alcuni ragazzi hanno tutta la fortuna! 👏"

    old "Just finished an intense core workout! Can’t wait to hear what you think. 💪🔥"
    new "Ho appena finito un allenamento intenso per il core! Non vedo l'ora di sapere cosa ne pensi. 💪🔥"

    old "Core Power! 💥"
    new "Potenza del nucleo! 💥"

    old "Looking strong, Fanny! I might need a few tips to keep up. 💪"
    new "Stai benissimo, Fanny! Potrei aver bisogno di qualche consiglio per stare al passo. 💪"

    old "I tried this workout, and now I can’t walk up the stairs. 😅"
    new "Ho provato questo allenamento e ora non riesco più a salire le scale. 😅"

    old "Maybe you should start with sitting on a couch first. 🤷"
    new "Forse dovresti iniziare sedendoti prima sul divano. 🤷"

    old "Oh, so now you’re a fitness expert, Ben? Let’s see you touch your toes. 😏"
    new "Ah, quindi ora sei un esperto di fitness, Ben? Vediamo se riesci a toccarti le punte dei piedi. 😏"

    old "Guys, it’s not about touching toes, it’s about reaching for the snacks on the top shelf. 🥨"
    new "Ragazzi, non si tratta di toccarsi le dita dei piedi, si tratta di raggiungere gli snack sullo scaffale più in alto. 🥨"

    old "Pat’s got a point. The real workout starts when the bag of chips is just out of reach. 💪"
    new "Pat ha ragione. Il vero allenamento inizia quando il sacchetto di patatine è appena fuori dalla tua portata. 💪"

    old "Fanny, I need a video on the snack-reach drill. That’s my fitness level. 😂"
    new "Fanny, mi serve un video sull'esercizio \"spuntino-reach\". Quello è il mio livello di forma fisica. 😂"

    old "Let's take a look at my phone before the night..."
    new "Diamo un'occhiata al mio telefono prima che finisca la notte..."

    old "I could send a message to Julia and invite her to go drink something..."
    new "Potrei mandare un messaggio a Julia e invitarla ad andare a bere qualcosa..."

    old "Red is maybe available..."
    new "Forse è disponibile il rosso..."

    old "Hey! What are you doing tonight?"
    new "Ehi! Cosa fai stasera?"

    old "I finish work in an hour."
    new "Finisco il lavoro tra un'ora."

    old "Oh? Still working?"
    new "Ah? Ancora in funzione?"

    old "Yep! But I'm available after."
    new "Sì! Ma sono disponibile dopo."

    old "What do you have in mind?"
    new "Cosa hai in mente?"

    old "You could show me a pub you like?"
    new "Potresti indicarmi un pub che ti piace?"

    old "Okay! Got one not far from my work!"
    new "Ok! Ne ho trovato uno non lontano dal lavoro!"

    old "I’ll text you the address. 21:30 ok?"
    new "Ti mando l'indirizzo via SMS alle 21:30, ok?"

    old "Cool, see you there."
    new "Fantastico, ci vediamo lì."

    old "Nothing. Why?"
    new "Niente. Perché?"

    old "Wanna come to my room?"
    new "Vuoi venire nella mia stanza?"

    old "What for?"
    new "Per che cosa?"

    old "Play Scrabble with me?"
    new "Gioca a Scrabble con me?"

    old "Are you serious?"
    new "Dici sul serio?"

    old "Come on! Having a hard time with Emerick and I could use some advice..."
    new "Dai! Ho avuto difficoltà con Emerick e avrei bisogno di qualche consiglio..."

    old "You should have opened with that!"
    new "Avresti dovuto iniziare così!"

    old "I'll be there in 10 minutes."
    new "Arriverò tra 10 minuti."

    old "Oh okay. Perfect."
    new "Va bene. Perfetto."

    old "I come from a military family.[TEMP1!t]"
    new "Provengo da una famiglia di militari. [TEMP1!t]"

    old "I come from a family of teachers.[TEMP2!t]"
    new "Vengo da una famiglia di insegnanti. [TEMP2!t]"

    old "My family has always been my friends.[TEMP3!t]"
    new "La mia famiglia è sempre stata la mia amica. [TEMP3!t]"

    old "I’m self-made. My family never helped me much.[TEMP4!t]"
    new "Mi sono fatto da solo. La mia famiglia non mi ha mai aiutato molto. [TEMP4!t]"

    old "We’ll adjust and make it work.[TEMP1!t]"
    new "Ci adatteremo e faremo in modo che funzioni. [TEMP1!t]"

    old "It’ll be a chance to grow.[TEMP2!t]"
    new "Sarà un'opportunità per crescere. [TEMP2!t]"

    old "We’ll have a dedicated training base.[TEMP3!t]"
    new "Avremo una base di addestramento dedicata. [TEMP3!t]"

    old "Living together will bring us closer.[TEMP4!t]"
    new "Vivere insieme ci avvicinerà. [TEMP4!t]"

    old "My first post made with a new friend ;)"
    new "Il mio primo post con un nuovo amico ;)"

    old "A good evening in good company:)!"
    new "Una bella serata in buona compagnia:)!"

    old "It was great spending time with you.[TEMP1!t]"
    new "È stato fantastico passare del tempo con te. [TEMP1!t]"

    old "I feel like I know you better now.[TEMP2!t]"
    new "Ora ho la sensazione di conoscerti meglio. [TEMP2!t]"

    old "I’m looking forward to the next match.[TEMP3!t]"
    new "Non vedo l'ora che arrivi la prossima partita. [TEMP3!t]"

    old "It’s nice to feel at ease with you.[TEMP4!t]"
    new "È bello sentirsi a proprio agio con te. [TEMP4!t]"

    old "My family’s mostly military. Discipline, training, and never backing down. Those were the lessons growing up."
    new "La mia famiglia è prevalentemente militare. Disciplina, addestramento e il non arrendersi mai. Queste sono state le lezioni che ho imparato crescendo."

    old "That must have been tough. Always living up to those expectations."
    new "Dev'essere stata dura. Essere sempre all'altezza delle aspettative."

    old "It wasn’t always easy, but it definitely taught me how to handle challenges."
    new "Non è stato sempre facile, ma mi ha sicuramente insegnato come affrontare le sfide."

    old "Teachers. Education was everything in my house. They valued learning and always encouraged me to ask questions."
    new "Insegnanti. L'istruzione era tutto a casa mia. Davano valore all'apprendimento e mi incoraggiavano sempre a fare domande."

    old "That’s impressive. It must have been nice having people who believed in your potential."
    new "È impressionante. Dev'essere stato bello avere persone che credevano nel tuo potenziale."

    old "It had its moments, but the pressure to perform was real."
    new "Ci sono stati momenti in cui è stato bello, ma la pressione per esibirsi era reale."

    old "I don’t really think of family in the traditional sense. My friends have always been my real family."
    new "Non penso alla famiglia in senso tradizionale. I miei amici sono sempre stati la mia vera famiglia."

    old "I get that. Sometimes the people you choose are the ones who matter most."
    new "Lo capisco. A volte le persone che scegli sono quelle che contano di più."

    old "Exactly. They’ve always had my back."
    new "Esatto. Mi hanno sempre sostenuto."

    old "I’ve had to figure out things on my own. My family didn’t give me much of a head start, so I’ve had to rely on myself."
    new "Ho dovuto risolvere le cose da sola. La mia famiglia non mi ha dato un grande vantaggio, quindi ho dovuto contare solo su me stessa."

    old "That must have been hard, but it sounds like it made you strong."
    new "Dev'essere stato difficile, ma sembra che ti abbia reso forte."

    old "It did. I’m grateful for the lessons I’ve learned along the way."
    new "Lo ha fatto. Sono grato per le lezioni che ho imparato lungo il cammino."

    old "It’s interesting learning more about you. I feel like I’m starting to understand you better."
    new "È interessante saperne di più su di te. Sento che sto iniziando a capirti meglio."

    old "Well, I guess I’m not such a mystery anymore."
    new "Beh, credo di non essere più un mistero."

    old "Maybe not, but you’re still pretty intriguing."
    new "Forse no, ma sei comunque molto intrigante."

    old "I could say the same about you."
    new "Potrei dire lo stesso di te."

    old "I guess we’ll just have to keep learning about each other, one conversation at a time."
    new "Immagino che dovremo continuare a conoscerci a vicenda, una conversazione alla volta."

    old "You really think we can win it all? The tournament, the house… everything?"
    new "Pensi davvero che possiamo vincere tutto? Il torneo, la casa... tutto?"

    old "It’s possible. Winning isn’t just about skill. It’s about how we grow together as a team."
    new "È possibile. Vincere non è solo una questione di abilità. È una questione di come cresciamo insieme come squadra."

    old "And I feel like every match we’ve played has brought us closer."
    new "E ho la sensazione che ogni partita che abbiamo giocato ci abbia avvicinati."

    old "I guess that’s true. You can really see how much everyone’s improved over time."
    new "Immagino sia vero. Si vede davvero quanto tutti siano migliorati nel tempo."

    old "That house… it sounds almost too good to be true, doesn’t it? Like a dream we can’t quite reach."
    new "Quella casa... sembra quasi troppo bella per essere vera, vero? Come un sogno che non possiamo realizzare."

    old "Maybe. But it’s the kind of dream that pushes us to be better. Sometimes it’s not just about the prize."
    new "Forse. Ma è il tipo di sogno che ci spinge a migliorare. A volte non si tratta solo del premio."

    old "It’s about how it shapes us along the way."
    new "Riguarda il modo in cui ci plasma lungo il cammino."

    old "And if we do win, living together in a place like that… it’d be strange at first, wouldn’t it?"
    new "E se dovessimo vincere, vivere insieme in un posto come quello... all'inizio sarebbe strano, non è vero?"

    old "At first, it might be an adjustment. But I think it’ll teach us how to handle challenges and work through them together."
    new "All'inizio potrebbe essere un adattamento. Ma credo che ci insegnerà come affrontare le sfide e superarle insieme."

    old "It’s comforting to hear that. It makes me feel more confident about the whole idea."
    new "È confortante sentirlo. Mi fa sentire più sicuro dell'intera idea."

    old "It’ll be an opportunity to learn from each other. We’ll be living under the same roof, sharing ideas and experiences."
    new "Sarà un'opportunità per imparare gli uni dagli altri. Vivremo sotto lo stesso tetto, condividendo idee ed esperienze."

    old "I like the sound of that. We could all grow in ways we didn’t expect."
    new "Mi piace come suona. Potremmo tutti crescere in modi inaspettati."

    old "It’ll be like having a personal training facility. We’ll have everything we need to stay sharp and prepared."
    new "Sarà come avere una palestra di personal training. Avremo tutto il necessario per rimanere allenati e preparati."

    old "You’re always thinking about performance, huh? But you’re right. It’d be a huge advantage."
    new "Pensi sempre alle prestazioni, eh? Ma hai ragione. Sarebbe un enorme vantaggio."

    old "It’ll be fun. We’ll have our ups and downs, but I think it’ll bring us closer than ever."
    new "Sarà divertente. Avremo i nostri alti e bassi, ma credo che ci renderà più uniti che mai."

    old "Yeah, I can see that. It might be chaotic at times, but also really special."
    new "Sì, lo capisco. A volte può essere caotico, ma anche davvero speciale."

    old "Hey, Julia, can I ask you something a bit random?"
    new "Ciao Julia, posso chiederti una cosa un po' a caso?"

    old "Sure. What’s on your mind?"
    new "Certo. Cosa ti passa per la testa?"

    old "I, uh… just started an OnlyStan page. And since you’re here, I thought it’d be cool if we took a quick photo together. You know, to kick things off."
    new "Io, ehm... ho appena aperto una pagina OnlyStan. E visto che sei qui, ho pensato che sarebbe stato bello se ci facessimo una foto veloce insieme. Sai, per iniziare."

    old "Your first photo? Didn’t expect you to be the OnlyStan type. What’s your page even about?"
    new "La tua prima foto? Non mi aspettavo fossi il tipo da OnlyStan. Di cosa parla la tua pagina?"

    old "Honestly, I made it mostly out of curiosity. Fanny and Kira are on it, and I thought I’d see what it’s all about."
    new "Onestamente, l'ho fatto più che altro per curiosità. Ci sono Fanny e Kira, e ho pensato di vedere di cosa si tratta."

    old "But I figured, why not use it for my own stuff? Something more casual."
    new "Ma ho pensato: perché non usarlo per le mie cose? Qualcosa di più informale."

    old "So, no content yet? This would be your very first post?"
    new "Quindi, ancora nessun contenuto? Questo sarebbe il tuo primo post in assoluto?"

    old "Yeah. I mean, I’m still figuring it out, but a photo with you would be a great start. Something simple, no pressure."
    new "Sì. Voglio dire, ci sto ancora pensando, ma una foto con te sarebbe un ottimo inizio. Qualcosa di semplice, senza pressione."

    old "Sure, why not?"
    new "Certo, perché no?"

    old "Let’s make it a good one."
    new "Facciamo in modo che sia una bella giornata."

    old "Wow!"
    new "Oh!"

    old "Perfect. That’s going to look great on my page."
    new "Perfetto. Farà un figurone sulla mia pagina."

    old "Well, you’re off to a strong start. Think you’ll keep it going?"
    new "Bene, hai iniziato alla grande. Pensi di continuare così?"

    old "We’ll see. Who knows? Maybe you’ll start one too."
    new "Vedremo. Chissà? Magari ne inizierai uno anche tu."

    old "Not so fast. Let’s see if yours is even worth following first."
    new "Non così in fretta. Vediamo se il tuo vale la pena di essere seguito."

    old "It's already late. I have to go."
    new "È già tardi. Devo andare."

    old "Let me come with you. I don't want you running into any trouble."
    new "Lasciami venire con te. Non voglio che tu ti metta nei guai."

    old "Okay. Thank you."
    new "Va bene. Grazie."

    old "Thanks for walking me home. It’s been a long time since I had a night like this."
    new "Grazie per avermi accompagnato a casa. Era da tanto che non trascorrevo una serata così."

    old "It was great spending time with you. I hope we can do this again soon."
    new "È stato fantastico passare del tempo con te. Spero che potremo rifarlo presto."

    old "Me too. I feel more relaxed now, thanks to you."
    new "Anch'io. Ora mi sento più rilassato, grazie a te."

    old "It was great talking. I feel like I understand you better now."
    new "È stato bello parlare con te. Ora sento di capirti meglio."

    old "That’s sweet. I learned a lot about you tonight, too."
    new "Che dolce! Ho imparato molto anche su di te stasera."

    old "I’m looking forward to the next match. It’ll be great knowing we’re working toward something this big together."
    new "Non vedo l'ora della prossima partita. Sarà fantastico sapere che stiamo lavorando insieme per qualcosa di così grande."

    old "It’s reassuring knowing you’re so focused. I’ll try to keep up!"
    new "È rassicurante sapere che sei così concentrato. Cercherò di tenere il passo!"

    old "It’s been a while since I’ve felt this at ease. I’m really glad we did this."
    new "Era da un po' che non mi sentivo così a mio agio. Sono davvero contento che ci siamo riusciti."

    old "Me too. I feel the same."
    new "Anch'io. Provo la stessa cosa."

    old "This feels right..."
    new "Mi sembra giusto..."

    old "Yeah... Not a stolen one this time."
    new "Sì... Questa volta non è stato rubato."

    old "Goodnight, Julia."
    new "Buonanotte, Julia."

    old "Goodnight, [name]."
    new "Buona notte, [name]."




    old "Come to 21st Upper Street in an hour."
    new "Tra un'ora sarai al 21st Upper Street."

    old "Huh? Why?"
    new "Eh? Perché?"

    old "Stop asking questions and just do it."
    new "Smettete di fare domande e fatelo e basta."

    old "And if I don’t want to?"
    new "E se non volessi?"

    old "It’s a competition"
    new "È una competizione"

    old "It’s a lottery"
    new "È una lotteria"

    old "It’s entertainment"
    new "È intrattenimento"

    old "Grace?"
    new "Grace?"

    old "Madison?"
    new "Madison?"

    old "Ruby?"
    new "Ruby?"

    old "More..."
    new "Di più..."

    old "Julia?"
    new "Julia?"

    old "The Twins?"
    new "I gemelli?"

    old "Why Kira?"
    new "Perché Kira?"

    old "Enough. I don’t want to hear more."
    new "Basta. Non voglio sentire altro."




    old "{size=-5}{color=#2b33b5}BUDDY"
    new "{size=-5}{color=#2b33b5}COMPAGNO"

    old "{size=-5}{color=#2b33b5}EDUC BEST CHOICE"
    new "{size=-5}{color=#2b33b5}EDUC MIGLIORE SCELTA"

    old "{size=-5}{color=#2b33b5}SPORT"
    new "{size=-5}{color=#2b33b5}SPORT"

    old "{size=-5}{color=#2b33b5}TEMP ELISE"
    new "{size=-5}{color=#2b33b5}ELISE TEMPESTIVA"

    old "{size=-5}{color=#2b33b5}\nTEMP BEST CHOICE"
    new "{size=-5}{color=#2b33b5}\nTEMP MIGLIORE SCELTA"

    old "{size=-5}{color=#2b33b5}\nEDUC RED"
    new "{size=-5}{color=#2b33b5}\nEDUC ROSSO"

    old "{size=-5}{color=#2b33b5}\nMADISON BLUE"
    new "{size=-5}{color=#2b33b5}\nMADISON BLUE"

    old "{size=-5}{color=#2b33b5}\nRED"
    new "{size=-5}{color=#2b33b5}\nROSSO"

    old "{size=-5}{color=#2b33b5}\nBUDDY"
    new "{size=-5}{color=#2b33b5}\nAMICO"

    old "{size=-5}{color=#2b33b5}TEMP"
    new "{size=-5}{color=#2b33b5}TEMPORANEO"

    old "{size=-5}{color=#2b33b5}\nTEMP"
    new "{size=-5}{color=#2b33b5}\nTEMP"

    old "{size=-5}{color=#2b33b5}\nSPORT GRACE"
    new "{size=-5}{color=#2b33b5}\nSPORT GRACE"

    old "{size=-5}{color=#2b33b5}SPORT BEST CHOICE"
    new "{size=-5}{color=#2b33b5}LA MIGLIORE SCELTA SPORTIVA"

    old "{size=-5}{color=#2b33b5}\nBEST CHOICE RUBY"
    new "{size=-5}{color=#2b33b5}\nLA SCELTA MIGLIORE È Ruby"

    old "{size=-5}{color=#2b33b5}\nSPORT BEST CHOICE"
    new "{size=-5}{color=#2b33b5}\nSPORT LA SCELTA MIGLIORE"

    old "{size=-5}{color=#2b33b5}\nEDUC"
    new "{size=-5}{color=#2b33b5}\nEDUC"

    old "{size=-5}{color=#2b33b5}\nBUDDY BEST CHOICE"
    new "{size=-5}{color=#2b33b5}\nBUDDY LA SCELTA MIGLIORE"

    old "{size=-5}{color=#2b33b5}\nSPORT"
    new "{size=-5}{color=#2b33b5}\nSPORT"

    old "{size=-5}{color=#2b33b5}\nSPORT MADISON"
    new "{size=-5}{color=#2b33b5}\nSPORT MADISON"

    old "{size=-5}{color=#2b33b5}\nEDUC BEST CHOICE"
    new "{size=-5}{color=#2b33b5}\nEDUC MIGLIORE SCELTA"

    old "{size=-5}{color=#2b33b5}\nBLUE"
    new "{size=-5}{color=#2b33b5}\nBLU"

    old "{size=-5}{color=#2b33b5}GABY"
    new "{size=-5}{color=#2b33b5}GABY"

    old "{size=-5}{color=#2b33b5}\nGABY"
    new "{size=-5}{color=#2b33b5}\nGABY"

    old "{size=-5}{color=#2b33b5}\nGRACE BLUE"
    new "{size=-5}{color=#2b33b5}\nGRACE BLUE"

    old "{size=-5}{color=#2b33b5}\nVICTORY ! BEST CHOICE"
    new "{size=-5}{color=#2b33b5}\nVITTORIA! LA SCELTA MIGLIORE"

    old "{size=-5}{color=#2b33b5}\nMADISON"
    new "{size=-5}{color=#2b33b5}MADISON"

    old "{size=-5}{color=#2b33b5}\nBLUE RED"
    new "{size=-5}{color=#2b33b5}\nBLU ROSSO"

    old "{size=-5}{color=#2b33b5}\nRUBY BEST CHOICE"
    new "{size=-5}{color=#2b33b5}\nRUBY LA SCELTA MIGLIORE"

    old "{size=-5}{color=#2b33b5}\nGRACE"
    new "{size=-5}{color=#2b33b5}\nGRAZIA"

    old "{size=-5}{color=#2b33b5}\nBEST CHOICE MADISON"
    new "{size=-5}{color=#2b33b5}\nLA SCELTA MIGLIORE MADISON"

    old "{size=-5}{color=#2b33b5}\nBUDDY COMMON DRESS"
    new "{size=-5}{color=#2b33b5}\nABITO COMUNE DA BUDDY"

    old "{size=-5}{color=#2b33b5}\nTEMP SEXY DRESS"
    new "{size=-5}{color=#2b33b5}\nABITO SEXY TEMP"

    old "{size=-5}{color=#2b33b5}\nBUDDY JULIA"
    new "{size=-5}{color=#2b33b5}\nCOMPAGNA JULIA"

    old "{size=-5}{color=#2b33b5}\nTEMP CHARLOTTE"
    new "{size=-5}{color=#2b33b5}\nTEMP CHARLOTTE"

    old "{size=-5}{color=#2b33b5}\nCHARLOTTE"
    new "{size=-5}{color=#2b33b5}\nCHARLOTTE"

    old "{size=-5}{color=#2b33b5}\nRED CLOSE ALL OTHER PATHS"
    new "{size=-5}{color=#2b33b5}\nROSSO CHIUDI TUTTI GLI ALTRI PERCORSI"

    old "{size=-5}{color=#2b33b5}\n BUDDY"
    new "{size=-5}{color=#2b33b5}\n AMICO"

    old "{size=-5}{color=#2b33b5}\n TEMP MADISON"
    new "{size=-5}{color=#2b33b5}\n MADISON TEMPORANEA"

    old "{size=-5}{color=#2b33b5}\n GRACE"
    new "{size=-5}{color=#2b33b5}\n GRAZIA"

    old "{size=-5}{color=#2b33b5}\n BLUE"
    new "{size=-5}{color=#2b33b5}\n BLU"

    old "{size=-5}{color=#2b33b5}\nKIRA"
    new "{size=-5}{color=#2b33b5}\nKIRA"

    old "{size=-5}{color=#2b33b5}EDUC"
    new "{size=-5}{color=#2b33b5}EDUC"

    old "{size=-5}{color=#2b33b5}BUDDY RUBY BEST CHOICE"
    new "{size=-5}{color=#2b33b5}BUDDY RUBY LA SCELTA MIGLIORE"

    old "Milfy City!"
    new "Milfy City!"

    old "You like it with experience"
    new "Ti piace con esperienza"

    old "You finished Episode 5!"
    new "Hai finito l'episodio 5!"

    old "Elise?"
    new "Elisa?"

    old "logobest"
    new "logobest"

    old "gui/hudbest/[icon]"
    new "gui/hudbest/[icon]"

    old "[value]"
    new "[value]"

    old "B.E.S.T RANK : [Rank]"
    new "MIGLIOR CLASSIFICA: [Rank]"

    old "[message]"
    new "[message]"

    old "Follow ELISE and OUR HERO in the next level of the competition!"
    new "Segui ELISE e il NOSTRO EROE nel prossimo livello della competizione!"

    old "[icon] [name]"
    new "[icon] [name]"

    old "🌳 Garden"
    new "🌳 Giardino"

    old "🎲 Poker Room"
    new "🎲 Sala da poker"

    old "⬆️ Upstairs"
    new "⬆️ Al piano di sopra"

    old "🏠 Back to Living Room"
    new "🏠 Torna al soggiorno"

    old "Yeah, come over.[TEMP1!t]"
    new "Sì, vieni qui. [TEMP1!t]"

    old "I don’t think that would be right..."
    new "Non credo che sarebbe giusto..."

    old "Hey... Just wanted to say good night :)"
    new "Ciao... Volevo solo darti la buonanotte :)"

    old "Today was amazing. I'm still smiling from that climb. 💕"
    new "Oggi è stata una giornata fantastica. Sorrido ancora dopo quella salita. 💕"

    old "Here’s my favorite photo of us from earlier!"
    new "Ecco la mia foto preferita di prima!"

    old "Yeah, she looks amazing. Let people see that."
    new "Sì, è stupenda. Fatela vedere a tutti."

    old "Climbing Morning ;)"
    new "Mattina di arrampicata ;)"

    old "Best view with best girl!"
    new "La vista migliore con la ragazza migliore!"

    old "No, I’ll keep it for myself."
    new "No, lo terrò per me."

    old "Oh, and this one..."
    new "Oh, e questo..."

    old "Don't you dare post it 😉"
    new "Non osare pubblicarlo 😉"

    old "Good night, [name]. Sleep tight. 💤💗"
    new "Buona notte, [name] Dormi bene. 💤💗"

    old "Hey, handsome. Got any plans at 9 a.m. tomorrow?"
    new "Ciao, bello. Hai impegni per domani mattina alle 9?"

    old "Hmm...No, why?"
    new "Hmm...No, perché?"

    old "Because you should come by the massage parlor."
    new "Perché dovresti passare dal centro massaggi."

    old "No questions. Just trust me 😏"
    new "Nessuna domanda. Fidati di me 😏"

    old "Let’s just say... you won’t be disappointed."
    new "Diciamo solo che... non rimarrete delusi."

    old "Alright, I’ll be there."
    new "Va bene, ci sarò."

    old "Good boy 😘"
    new "Bravo ragazzo 😘"

    old "Sleep tight. You’re gonna need your energy."
    new "Dormi bene. Avrai bisogno di energia."

    old "Hello [name]. I booked a recovery massage for you tomorrow at 9:30."
    new "Ciao [name] Ho prenotato un massaggio rigenerante per te domani alle 9:30."

    old "A proper massage will ease the tension you've built up."
    new "Un massaggio adeguato allevierà la tensione accumulata."

    old "A professional will take care of it. Just show up rested."
    new "Se ne occuperà un professionista. Presentatevi riposati."

    old "Wait… not you?"
    new "Aspetta... non sei tu?"

    old "I thought you’d prefer someone with qualified hands."
    new "Ho pensato che avresti preferito qualcuno con competenze specifiche."

    old "Not sure anyone’s hands would beat yours..."
    new "Non sono sicuro che le mani di qualcuno batterebbero le tue..."

    old "Flattering... and dangerous."
    new "Lusinghiero... e pericoloso."

    old "Now rest. Tomorrow will be... instructive."
    new "Ora riposati. Domani sarà... istruttivo."

    old "You’re not making it easy to sleep, you know."
    new "Non mi stai rendendo facile dormire, lo sai."

    old "Good night, [name]."
    new "Buona notte, [name]."

    old "Good night, Gabriella..."
    new "Buonanotte, Gabriella..."

    old "Long day of squats, sweat, and stretches... Time to give these legs a break. Good night, team. 💤🍑"
    new "Una lunga giornata di squat, sudore e stretching... È ora di dare un po' di tregua alle gambe. Buonanotte, squadra. 💤🍑"

    old "Rest mode: activated 😴"
    new "Modalità di riposo: attivata 😴"

    old "Nighty night, muscle queen. May your dreams be less sore than your glutes."
    new "Buona notte, regina dei muscoli. Che i tuoi sogni siano meno doloranti dei tuoi glutei."

    old "Wait, you did legs today *and* you’re still standing? Teach me your ways. 😩"
    new "Aspetta, oggi hai fatto le gambe *e* sei ancora in piedi? Insegnami i tuoi trucchi. 😩"

    old "Pretty sure your legs just bench-pressed my willpower."
    new "Sono abbastanza sicuro che le tue gambe abbiano appena messo a dura prova la mia forza di volontà."

    old "Sweet dreams, Fanny. Hope tomorrow’s workout is just lifting spoons to your mouth. 🥣😅"
    new "Sogni d'oro, Fanny. Spero che l'allenamento di domani sia solo sollevare cucchiai e portarli alla bocca. 🥣😅"

    old "You work hard AND say good night like a goddess? That’s just unfair."
    new "Lavori duro E dici la buonanotte come una dea? È semplicemente ingiusto."

    old "Brb going to the gym so I can sleep like Fanny tonight."
    new "Presto andrò in palestra così potrò dormire come Fanny stanotte."

    old "You inspire me... but my couch says no."
    new "Mi ispiri... ma il mio divano dice di no."

    old "She looks so happy with you! Glad she had you by her side today.."
    new "Sembra così felice con te! Sono felice che ti abbia avuto al suo fianco oggi."

    old "Nice climb. Thought you’d need Grace to carry you up."
    new "Bella salita. Pensavo che avresti avuto bisogno di Grace per portarti su."

    old "Sofia..."
    new "Sofia..."

    old "Just wanted to check in on you."
    new "Volevo solo sapere come stavi."

    old "It’s been a wild day. You okay?"
    new "È stata una giornata folle. Tutto bene?"

    old "Mmm... you thinking about me in bed, or just being sweet? 😉"
    new "Mmm... stai pensando a me a letto o stai solo facendo il dolce? 😉"

    old "Can’t it be both?"
    new "Non potrebbero essere entrambe le cose?"

    old "Flirt."
    new "Flirtare."

    old "I’m okay. Tired... but I'm glad you messaged me."
    new "Sto bene. Sono stanco... ma sono contento che tu mi abbia scritto."

    old "I wish I could be with you right now."
    new "Vorrei poter essere con te adesso."

    old "Maybe next time I won’t let you leave so easily."
    new "Forse la prossima volta non ti lascerò andare via così facilmente."

    old "Looking forward to it."
    new "Non vedo l'ora."

    old "Sweet dreams, [name]. Don’t do anything I wouldn’t dream about."
    new "Sogni d'oro, [name] Non fare nulla che non mi sognerei mai di fare."

    old "Good night, Sofia."
    new "Buonanotte, Sofia."

    old "Gently pull her gown back into place.[TEMP1!t]"
    new "Rimetti delicatamente a posto la veste. [TEMP1!t]"

    old "Leave it as it is...[TEMP2!t]"
    new "Lascialo così com'è... [TEMP2!t]"

    old "Morning, troublemaker. 😘"
    new "Buongiorno, piantagrane. 😘"

    old "Wanna help me pick out a new bag today?"
    new "Vuoi aiutarmi a scegliere una nuova borsa oggi?"

    old "Meet me at 11? You’ll get bonus kisses."
    new "Ci vediamo alle 11? Avrai dei baci bonus."

    old "You drive a hard bargain."
    new "Fai un duro affare."

    old "Only fair. You drive me crazy."
    new "Giusto. Mi fai impazzire."

    old "I reach out and gently fix her gown."
    new "Allungo la mano e le sistemo delicatamente l'abito."

    old "She stirs a little, but doesn’t wake up."
    new "Si muove un po', ma non si sveglia."

    old "She deserves that dignity. That comfort."
    new "Merita quella dignità. Quel conforto."

    old "I won’t be another source of pressure in her life."
    new "Non sarò un'altra fonte di pressione nella sua vita."

    old "I let it be."
    new "Ho lasciato che fosse così."

    old "She’s beautiful like this... but more than that, she trusts me."
    new "È bella così... ma più di questo, si fida di me."

    old "And that means something."
    new "E questo significa qualcosa."

    old "This moment is hers."
    new "Questo momento è suo."

    old "Time to get moving."
    new "È ora di muoversi."

    old "Morning already..."
    new "Già buongiorno..."

    old "Hard to believe everything that happened yesterday was real."
    new "È difficile credere che tutto ciò che è successo ieri sia reale."

    old "Marc, Julia, Ruby... it’s all spinning in my head."
    new "Marc, Julia, Ruby... tutto mi gira in testa."

    old "A message from Sofia?"
    new "Un messaggio da Sofia?"

    old "Let's see what Charlotte was planning..."
    new "Vediamo cosa aveva in mente Charlotte..."

    old "Let’s see what kind of ‘recovery massage’ Gabriella booked for me..."
    new "Vediamo che tipo di \"massaggio di recupero\" mi ha prenotato Gabriella..."

    old "Blue’s waiting for me at the mall..."
    new "Blue mi aspetta al centro commerciale..."

    old "I guess I’ve got the morning to myself."
    new "Credo di avere la mattinata tutta per me."

    old "Post the selfie on OnlyStan"
    new "Pubblica il selfie su OnlyStan"

    old "My new universe ;)"
    new "Il mio nuovo universo ;)"

    old "Discovering each other!"
    new "Scopriamoci a vicenda!"

    old "Don’t post it"
    new "Non pubblicarlo"

    old "Where are you?! It's time!!"
    new "Dove sei?! È ora!!"

    old "Everyone needs to be at the stadium!"
    new "Tutti devono essere allo stadio!"

    old "Observe Madison’s box"
    new "Osserva la scatola di Madison"

    old "Observe Steven’s box"
    new "Osserva la scatola di Steven"

    old "Observe Hector’s box"
    new "Osserva la scatola di Hector"

    old "Observe Julia’s box"
    new "Osserva la scatola di Julia"

    old "Observe Grace’s box"
    new "Osserva la scatola di Grace"

    old "Observe Ben’s box"
    new "Osserva la scatola di Ben"

    old "Observe Mac’s box"
    new "Osserva la scatola di Mac"

    old "Observe Sofia (Blue)’s box"
    new "Osserva la scatola di Sofia (Blu)"

    old "Observe Elisabeth (Red)’s box"
    new "Osserva la scatola di Elisabeth (Red)"

    old "Observe Kira’s box"
    new "Osserva la scatola di Kira"

    old "Observe Emerick’s box"
    new "Osserva la scatola di Emerick"

    old "Observe Ruby’s box"
    new "Osserva la scatola di Ruby"

    old "Keep my box[TEMP1!t]"
    new "Tieni la mia scatola[TEMP1!t]"

    old "Trade with Ruby"
    new "Fai trading con Ruby"

    old "Trade with Kira"
    new "Commercia con Kira"

    old "Trade with Julia"
    new "Commercia con Julia"

    old "Trade with Grace"
    new "Commercia con grazia"

    old "Trade with Elizabeth (Red)"
    new "Commercia con Elizabeth (Rosso)"

    old "Trade with Sofia (Blue)"
    new "Commercio con Sofia (Blu)"

    old "Trade with Ben"
    new "Commercia con Ben"

    old "Trade with Mac"
    new "Fai trading con Mac"

    old "Trade with Emerick"
    new "Commercia con Emerick"

    old "Trade with Elizabeth"
    new "Commercia con Elizabeth"

    old "Trade with Sofia"
    new "Commercio con Sofia"




    old "Sacrifice!"
    new "Sacrificio!"

    old "She won't let you go..."
    new "Non ti lascerà andare..."

    old "You're everyone's best friend!"
    new "Sei il migliore amico di tutti!"

    old "Knowledge is your power!"
    new "La conoscenza è il tuo potere!"

    old "You’re a true champion!"
    new "Sei un vero campione!"

    old "You lead the way!"
    new "Tu sei la guida!"

    old "Exchange"
    new "Scambio"

    old "She will remember that."
    new "Se ne ricorderà."

    old "QUALIFIED TOKEN..."
    new "TOKEN QUALIFICATO..."

    old "TO BE CONTINUED..."
    new "CONTINUA..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
