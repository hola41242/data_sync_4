

translate italian strings:


    old "EPISODE 5"
    new "Episodio 5"


    old "ORIGINS"
    new "ORIGINI"





translate italian e5intro_7a6dbcfd:


    ji "Grazie ancora per aver guardato Ruby stasera, Carmen. È un vero sollievo sapere che è qui con te."





translate italian e5intro_edb6d03d:


    carmen "Certo! Non preoccuparti di niente. Ci divertiremo."





translate italian e5intro_929c4d69:


    ji "Grazie mille. A dopo!"





translate italian e5intro_9e5be354:


    ruby "Cosa vuoi fare da grande?"





translate italian e5intro_87095544:


    mad "Io? Diventerò una regina! Avrò un castello enorme e tutti faranno quello che dico io."





translate italian e5intro_905b78ff:


    ruby "Wow! E io? Cosa farei nel tuo castello?"





translate italian e5intro_12303531:


    mad "Saresti la mia guardia del corpo! Come nei film! Saresti super duro e mi terresti al sicuro."





translate italian e5intro_577e458b:


    ruby "Sì! Sarò così forte che nessuno ti oserà!"





translate italian e5intro_9c810aea:


    mad "Giusto. E così saremo sempre insieme."





translate italian e5intro_12fa9d5f:


    ruby "Ok! Ti proteggerò sempre."





translate italian e5intro_5b31b56d:


    carmen "Ufficiale?"





translate italian e5intro_48c88889:


    ji "Signora Forrester, mi dispiace davvero di essere arrivato così tardi, ma ho delle brutte notizie."





translate italian e5intro_2eb678a8:


    ji "Riguarda il signor e la signora Suyin. Hanno avuto un incidente d'auto."





translate italian e5intro_f19a3649:


    ji "Un camion è spuntato dal nulla e ha colpito la loro auto. I soccorsi sono arrivati ​​rapidamente, ma... era troppo tardi. Non sono sopravvissuti."





translate italian e5intro_4845026b:


    carmen "Entrambi? Sei sicuro che non ci siano possibilità?"





translate italian e5intro_507c9a75:


    ji "Mi dispiace tanto. No, non ci sono sopravvissuti."





translate italian e5intro_00836242:


    carmen "E Ruby? Cosa le succede adesso? È solo una bambina..."





translate italian e5intro_1a9d63a8:


    ji "I servizi sociali saranno avvisati e contatteranno i familiari più vicini per organizzare le cure."





translate italian e5intro_4f4626eb:


    carmen "Capisco. Ma nel frattempo, lei è qui. Conosce questo posto, si sente al sicuro qui."





translate italian e5intro_a7266098:


    carmen "Potrei tenerla con me finché tutto non si sarà sistemato? Voglio solo essere sicuro che stia bene."





translate italian e5intro_6d6764e8:


    ji "Sembra ragionevole. Ma dovrai coordinarti presto con le autorità per renderlo ufficiale."





translate italian e5intro_35108db2:


    carmen "Certo. Farò tutto come si deve. Voglio solo che si senta al sicuro e protetta."





translate italian e5intro_ecb697e9:


    ji "Va bene. Ti farò sapere appena avrò maggiori informazioni."





translate italian e5intro_a554831c:


    mad "Ricordi cosa ho detto? Sarò sempre qui per te. Andrà tutto bene."





translate italian e5intro_b7de6fef:


    mad "Più avanti, quando saremo tutti grandi, le cose andranno meglio. Vedrai."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
