



translate italian e5s1_c3641176:


    d "Stavi per essere investito da quella macchina. Dovevo fare qualcosa."


translate italian e5s1_b58b165f:


    d "Non potevo restare lì a guardare mentre ti facevi male."


translate italian e5s1_55a5a4af:


    ruby "Non capisco... sei spuntato dal nulla. È stato come se il tempo si fosse fermato."


translate italian e5s1_7fd570da:


    d "Non avrei permesso che ti accadesse niente."


translate italian e5s1_8899f6e3:


    ruby "Ma... avresti potuto farti male. Perché correre un rischio del genere?"


translate italian e5s1_f5688640:


    d "Perché ci tengo a te, Ruby."


translate italian e5s1_f8bebc6f:


    ruby "…"


translate italian e5s1_b63f180b:


    d "Forza, ti accompagno in camera tua. Mi assicurerò che tu sia al sicuro."


translate italian e5s1_8ae3f02b:


    ruby "Grazie."


translate italian e5s1_f11fc35f:


    d "Ehi, ehi... respira. Ora sei al sicuro. È tutto ciò che conta."


translate italian e5s1_432a0fd3:


    ruby "Ma se non ci fossi stato? Se non fossi arrivato in tempo..."


translate italian e5s1_d4906513:


    d "Non pensarci. Io ero lì. Ho visto cosa stava succedendo e non volevo che ti facessi male."


translate italian e5s1_e1af90f3:


    ruby "Sembra che tu sappia sempre esattamente quando ho bisogno di te. Come fai... come fai?"


translate italian e5s1_a2169b7c:


    ruby "Non sai cosa significhi per me. Davvero. Io..."


translate italian e5s1_907147a6:


    ruby "Madison!"


translate italian e5s1_0fb8a98c:


    mad "Che diavolo hai fatto? Che le è successo?!"


translate italian e5s1_eabb95e2:


    ruby "Basta! Non mi ha fatto niente."


translate italian e5s1_1728ff72:


    ruby "Era Emerick. Mi ha spinto sulla strada... e [name] mi ha salvato."


translate italian e5s1_3cab6c49:


    ruby "Se non ci fosse stato lui…"


translate italian e5s1_2570fab1:


    mad "Non ci posso credere. Ogni dannata volta trova il modo di intromettersi, di ferire le persone a cui tengo."


translate italian e5s1_bad2ad5b:


    mad "No. Troverò un modo. Andrò alla Torre Orushi se necessario. Troverò qualcosa su di lui, qualsiasi cosa pur di fargliela pagare."


translate italian e5s1_66cfc5ef:


    mad "Sono solo... sono così felice che tu stia bene. Quando ho visto il tuo messaggio, ho pensato..."


translate italian e5s1_c405af79:


    mad "Non posso perderti, Ruby. Non posso proprio."


translate italian e5s1_ed939cdf:


    ruby "Non mi perderai. Sono qui. Sto bene, grazie a lui."


translate italian e5s1_be37c700:


    d "Vi lascio un po' di spazio. Fatemi sapere se avete bisogno di qualcosa."


translate italian e5s1_9ccfef56:


    ruby "Grazie ancora. Per tutto."


translate italian e5s1_55428f52:


    mad "Sì. Grazie."


translate italian e5s1_65f68525:


    d "Che diavolo è successo lì dietro?"


translate italian e5s1_f22927de:


    d "Emerick... Stavolta ha esagerato. Ha spinto Ruby sulla strada..."


translate italian e5s1_dc85aaa9:


    d "Mi fa male solo a pensarci."


translate italian e5s1_6c0648a2:


    d "E Madison... era furiosa, e lo capisco."


translate italian e5s1_d52744de:


    d "Lei tiene a Ruby tanto quanto me. Devo aiutarla a gestire la situazione."


translate italian e5s1_bc37c3ae:


    d "Emerick non può farla franca."


translate italian e5s1_67fd8c9a:


    d "Ma quel… quel momento…"


translate italian e5s1_63201803:


    d "Quando ho visto Ruby in pericolo, mi è successo qualcosa. Ho sentito un'ondata..."


translate italian e5s1_319f03eb:


    d "Era come se ogni parte di me si fosse illuminata, muovendosi più velocemente di quanto avrei mai pensato."


translate italian e5s1_ab6a92fc:


    d "La mia mente era completamente lucida, senza esitazioni, senza dubbi."


translate italian e5s1_60d891a3:


    d "Mi sentivo... come se non fossi completamente me stesso. Come se avessi scoperto qualcosa che non sapevo nemmeno esistesse."


translate italian e5s1_5c347b7d:


    d "Ma qualunque cosa fosse, mi ha aiutato a salvarla."


translate italian e5s1_865436fc:


    d "Ed è questo che conta adesso."


translate italian e5s1_51325e82:


    d "Ruby... Non credo di aver mai realizzato quanto tengo a lei."


translate italian e5s1_45049fa3:


    d "Prima era solo una persona che conoscevo, una persona sempre presente. Ma ora... è diverso."


translate italian e5s1_cf2a24fa:


    d "Come se stessi davvero iniziando a vederla per quella che è."


translate italian e5s1_f9e11963:


    d "Forte, gentile, una persona di cui mi posso fidare. Sta diventando più di un semplice volto familiare."


translate italian e5s1_e5f54a54:


    d "Sta diventando…"


translate italian e5s1_62fb39a8:


    d "Ronzio?"


translate italian e5s1_1f1620be:


    d "Sarà divertente!"


translate italian e5s1_7984b7ea:


    d "Ancora?"


translate italian e5s1_866e135e:


    d "Devo contattare quella misteriosa donna del Palazzo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
