


translate italian gameover_a733e2ee:


    orushi "Sfortunatamente non sei riuscito a superare tutte le prove, [name]..."


translate italian gameover_84c6535c:


    orushi "È deludente..."


translate italian gameover_3bdd13e5:


    orushi "Bene, la prossima volta... Prova a fare delle scelte migliori!"


translate italian gameover_783ab545:


    "Fshhhhhhhhh!!!!"








translate italian gameover_e233951b:


    "Lo stesso giocatore spara ancora!"













translate italian gameovere5_a733e2ee:


    orushi "Sfortunatamente, non sei riuscito a superare tutte le prove, [name]..."





translate italian gameovere5_84c6535c:


    orushi "È deludente..."





translate italian gameovere5_3bdd13e5:


    orushi "Bene, la prossima volta... prova a fare scelte migliori!"





translate italian gameovere5_783ab545:


    "Fshhhhhhhhhh!!!!"





translate italian gameovere5_a733e2ee:


    orushi "Sfortunatamente, non sei riuscito a superare tutte le prove, [name]..."





translate italian gameovere5_84c6535c:


    orushi "È deludente..."





translate italian gameovere5_3bdd13e5:


    orushi "Bene, la prossima volta... prova a fare scelte migliori!"





translate italian gameovere5_783ab545:


    "Fshhhhhhhhhh!!!!"





translate italian gameovere5_e233951b:


    "Lo stesso giocatore tira di nuovo!"





translate italian gameovere5_e233951b:


    "Lo stesso giocatore tira di nuovo!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
