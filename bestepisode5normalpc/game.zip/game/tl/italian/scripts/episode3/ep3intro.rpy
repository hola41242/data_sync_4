


translate italian ep3intro_6a95f5af:


    "Guarda quanto sono belli insieme, come se due piccole principesse prendessero vita."


translate italian ep3intro_d52a2d2f:


    "Sono mozzafiato. Ma come li chiamiamo? Le gemelle sono il doppio del miracolo che speravo."


translate italian ep3intro_17e52c09:


    "Che ne dici di chiamare questa piccola regina Elizabeth? Sembra appropriato, vero?"


translate italian ep3intro_5155ce6b:


    "Elizabeth... sì, è perfetto. E per tua sorella... Che ne dici di Sofia, un nome regale come il suo?"


translate italian ep3intro_d059f665:


    "Sofia, vedi come tua sorella va in bicicletta? Segui il suo esempio e scoprirai che è semplice."


translate italian ep3intro_db1f4100:


    "Sofia, perché sempre blu? È così infantile! Tua sorella almeno sceglie il rosso vivace!"


translate italian ep3intro_63a49d35:


    "Sofia, ancora blu per il tuo disegno? Guarda i colori vivaci che sceglie tua sorella, sono pieni di vita."


translate italian ep3intro_ae6a403c:


    sofia "Perché sono sempre paragonata a lei..."


translate italian ep3intro_1abbf48a:


    "Sofia, devi provare ad integrarti di più. Guarda Elizabeth, ha tutto."


translate italian ep3intro_26f7887d:


    sofia "Lasciami stare... voglio essere me stessa..."


translate italian ep3intro_525bb56e:


    "Sofia, Sofia!!!"


translate italian ep3intro_c5f6d561:


    "Lei è più forte di te..."


translate italian ep3intro_4433515c:


    "Sofia!"


translate italian ep3intro_4433515c_1:


    "Sofia!"


translate italian ep3intro_6b34e089:


    beth "Sofia! Dai, faremo tardi!"


translate italian ep3intro_14fabf4a:


    sofia "Bene! Sto arrivando…"

translate italian strings:


    old "EPISODE 3 {p} \n Let's get it started!"
    new "EPISODIO 3 {p} \n Cominciamo!"


    old "8:00 AM"
    new "8:00 DI MATTINA"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
