

translate italian strings:


    old "What is the only Wonder of the ancient world still visible?"
    new "Qual è l'unica Meraviglia del mondo antico ancora visibile?"


    old "In a traditional deck of cards,\nwhich queen holds her scepter with both hands?"
    new "In un mazzo di carte tradizionale,\nquale regina tiene il suo scettro con entrambe le mani?"


    old "Who wrote '1984'?"
    new "Chi ha scritto '1984'?"


    old "What is the missing number?\n16 06 68 88 ?? 98"
    new "Qual è il numero mancante?\n16 06 68 88 ?? 98"


    old "What was the name of the first widely available web browser?"
    new "Qual era il nome del primo browser web ampiamente disponibile?"


    old "What is the capital of Australia?"
    new "Qual è la capitale dell'Australia?"


    old "Who is hidden behind this image?"
    new "Chi si nasconde dietro questa immagine?"


    old "If you mix red and blue,\nwhat color do you get?"
    new "Se mescoli rosso e blu,\nche colore ottieni?"


    old "Press the POINT"
    new "Premere il PUNTO"


    old "The answer is obvious"
    new "La risposta è ovvia"


    old "The Colossus of Rhodes"
    new "Il Colosso di Rodi"


    old "The Great Pyramid of Giza[TEMP1!t]"
    new "La Grande Piramide di Giza[TEMP1!t]"


    old "The Lighthouse of Alexandria"
    new "Il Faro di Alessandria"


    old "The Temple of Artemis"
    new "Il Tempio di Artemide"


    old "The Queen of Clubs[TEMP1!t]"
    new "La regina di fiori[TEMP1!t]"


    old "The Queen of Spades"
    new "La regina di picche"


    old "The Queen of Hearts"
    new "La Regina di Cuori"


    old "The Queen of Diamonds"
    new "La regina di quadri"


    old "J. R. R. Tolkien"
    new "JRR Tolkien"


    old "George R. R. Martin"
    new "George RR Martin"


    old "George Orwell[TEMP1!t]"
    new "George Orwell[TEMP1!t]"


    old "Stephen King"
    new "Stephen King"


    old "Internet Explorer"
    new "Internet Explorer"


    old "Mosaic[TEMP1!t]"
    new "Mosaico[TEMP1!t]"


    old "Netscape Navigator"
    new "Netscape Navigator"


    old "Google Chrome"
    new "Google Chrome"


    old "Canberra[TEMP1!t]"
    new "Canberra[TEMP1!t]"


    old "Sydney"
    new "Sydney"


    old "Melbourne"
    new "Melbourne"


    old "Perth"
    new "Perth"


    old "Mona Lisa"
    new "Monna Lisa"


    old "Aya Brea"
    new "Aya Brea"


    old "Lara Croft[TEMP1!t]"
    new "Lara Croft[TEMP1!t]"


    old "Katniss Everdeen"
    new "Katniss Everdeen"


    old "Violet[TEMP1!t]"
    new "Viola[TEMP1!t]"


    old "Orange"
    new "Arancia"


    old "Green"
    new "Verde"


    old "Pink"
    new "Rosa"


    old "You finished on time! Your score is [score] / 10."
    new "Hai finito in tempo! Il tuo punteggio è [score] / 10."


    old "You did not finish on time. Your score is [score] / 10."
    new "Non hai finito in tempo. Il tuo punteggio è [score] / 10."


    old "Your new rank is :"
    new "Il tuo nuovo grado è:"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
