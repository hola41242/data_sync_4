


translate italian free00_6b4b0cf1:


    grace "Ebbene, amici..."


translate italian free00_679a2306:


    grace "Mi dispiace, ma ho promesso a mia mamma che avrei finito la serata entro mezzanotte..."


translate italian free00_98a03685:


    ruby "Oh, già?"


translate italian free00_fc5d43b7:


    grace "Sì... tornerà a casa tra un'ora circa, ed è meglio se non siamo ancora qui quando arriva..."


translate italian free00_34d48dad:


    ruby "Nessun problema! Forza ragazzi! È tempo che Cenerentola si trasformi in cameriera"


translate italian free00_45282a81:


    grace "Starai con me?"


translate italian free00_aa7a6ace:


    d "Ovviamente!"


translate italian free00_6ff5bfb7:


    ruby "Va bene, andiamo fuori!"


translate italian free00_9cab7c01:


    d "Starò qui con Grace per aiutarla a pulire!"


translate italian free00_dc303eb0:


    ruby "Sì, sì, certo! Ripulire..."


translate italian free00_5fb753fe:


    ruby "Ci vediamo domani!"


translate italian free00_a6a8874f:


    mad "Ci vediamo domani, tutti quanti!"


translate italian free00_0eaf48fc:


    d "Ci vediamo domani!"


translate italian free00_c47afec2:


    grace "Ci vediamo domani!"


translate italian free00_ac896290:


    d "No, preferirei di no..."


translate italian free00_0dceca55:


    grace "OH..."


translate italian free00_13a7d26b:


    ruby "Va bene, ci vediamo domani!"


translate italian free00_a6a8874f_1:


    mad "Ci vediamo domani, tutti quanti!"


translate italian free00_0eaf48fc_1:


    d "Ci vediamo domani!"


translate italian free00_c47afec2_1:


    grace "Ci vediamo domani!"


translate italian free00_6ff5bfb7_1:


    ruby "Va bene, andiamo fuori!"


translate italian free00_a6a8874f_2:


    mad "Ci vediamo domani, tutti quanti!"


translate italian free00_0eaf48fc_2:


    d "Ci vediamo domani!"


translate italian free00_c47afec2_2:


    grace "Ci vediamo domani!"

translate italian strings:


    old "00:00 AM"
    new "00:00"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
