


translate italian FINEP3_285f8ea7:


    "Per favore salva il gioco qui..."


translate italian FINEP3_8636bfb0:


    gaby "E cosa farebbe un ragazzo come te con una donna come me?"


translate italian FINEP3_aee41bbd:


    ji "Mamma..."


translate italian FINEP3_9b55d749:


    drew "Avrai un nuovo processo questo pomeriggio"


translate italian FINEP3_f8acb000:


    drew "Devi scegliere il tuo partner per questo [name]."


translate italian FINEP3_c8f69174:


    mad "Ok ragazzi... Non possiamo perdere questa partita!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
