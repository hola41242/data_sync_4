


translate italian free22_1be28055:


    kira "Hai già perso?"


translate italian free22_77d71485:


    d "Già... Tuo cugino è troppo fortunato..."


translate italian free22_fc89a466:


    kira "Ammetti semplicemente che non sai giocare!"


translate italian free22_f338cc08:


    d "Ehm..."


translate italian free22_272aa8c2:


    d "No no, ci stiamo solo prendendo una pausa!"


translate italian free22_9b3fe7b3:


    kira "Oh ok!"


translate italian free22_f4034d91:


    kira "Se posso darti un consiglio..."


translate italian free22_88283594:


    kira "Emerick sa cosa sta facendo."


translate italian free22_e11ee7fa:


    kira "Ma se pensi di avere un vantaggio ad un certo punto..."


translate italian free22_ae5d5593:


    kira "Fagli credere che ce l'ha..."


translate italian free22_d42fe897:


    kira "Ti darà tutto..."


translate italian free22_2c3a63c7:


    d "Cosa intendi?"


translate italian free22_f291fd44:


    kira "Gioca sul suo orgoglio"


translate italian free22_7eff095c:


    d "Ok... ci proverò."


translate italian free22_0ba5d46b:


    ruby "Mettiamo un po' di musica?" with hpunch


translate italian free22_e3a83ad3:


    grace "Sì, è troppo tranquillo qui!"


translate italian free22_a3fb43b8:


    ruby "Aspetta, sposto un po' questo tavolo così possiamo ballare!"


translate italian free22_468861f3:


    d "Ballare?"


translate italian free22_b9488c59:


    ruby "SÌ! Non ti piace?"


translate italian free22_40cb86c2:


    d "Sì, certamente! Ma non sapevo che ti piacesse ballare!"


translate italian free22_01a43774:


    d "Uh, no... Non fa per me... Ma non sapevo che ti piacesse ballare!"


translate italian danse22_4f62b28b:


    ruby "Io ? NO !!!" with vpunch


translate italian danse22_980d278f:


    ruby "Ma Grace..."


translate italian danse22_3deed7ed:


    d "Veramente?"


translate italian danse22_fb565796:


    ruby "Aspetta, siediti... e guarda!"


translate italian danse22_dd5d68f3:


    d "Eh?"


translate italian danse22_69c1622d:


    d "Oh!!! Non me lo aspettavo!"


translate italian danse22_a955a3b7:


    ruby "Te l'avevo detto!"


translate italian danse22_5f558a08:


    dpense "Questo ritmo..."


translate italian danse22_16f3e257:


    dpense "Quelle mosse..."


translate italian danse22_6f3e5dad:


    dpense "E' davvero una dea..."


translate italian danse22_d769145c:


    dpense "Il modo in cui fluisce con la musica..."


translate italian danse22_88ff6449:


    dpense "È come se raccontasse una storia ad ogni passo..."


translate italian danse22_1a96938b:


    dpense "Non riesco a staccare gli occhi da lei..."


translate italian danse22_165575e4:


    dpense "Ogni movimento è affascinante..."


translate italian danse22_df9bdb38:


    dpense "Grace sta affascinando tutti nella stanza..."


translate italian danse22_be93a8b1:


    grace "Cosa ne pensi?"


translate italian danse22_8b5925da:


    d "Tu eri..."


translate italian danse22_5ed46a7b:


    d "Magnifica..."


translate italian danse22_442f607d:


    grace "Grazie!"


translate italian danse22_092218ab:


    hec "Oh beh, c'è sicuramente del talento qui!"


translate italian danse22_7c71854d:


    kira "Lo spettacolo non è ancora finito!"


translate italian danse22_dd5d68f3_1:


    d "Eh?"


translate italian danse22_bd15cdba:


    dpense "OH..."


translate italian danse22_7a82419b:


    dpense "Mio..."


translate italian danse22_1dfd470a:


    dpense "Dio..."


translate italian danse22_46359b02:


    dpense "Che culo..."


translate italian danse22_eadce89f:


    dpense "Fanculo..."


translate italian danse22_58235d12:


    dpense "Le cose che le farei..."


translate italian danse22_ef768a8f:


    d "Ok ok... Anche tu sei brava!"


translate italian danse22_52a1acec:


    kira "Ah ah! Lo so!"


translate italian danse22_655b2071:


    hec "Prendi appunti, francese!"


translate italian danse22_e48c9cb0:


    d "Hmm..."


translate italian danse22_d4f312f9:


    d "Minus?"


translate italian danse22_b89db320:


    ruby "SÌ?"


translate italian danse22_7b984d44:


    d "Vai avanti... Alza il volume!"


translate italian danse22_335a5311:


    ruby "OH? Va bene!"


translate italian danse22_9e11135f:


    dpense "E adesso..."


translate italian danse22_2798004b:


    d "Orario dello spettacolo!"


translate italian danse22_a33e428d:


    ruby "Mostraglielo [name]!"


translate italian danse22_7caf9fa9:


    grace "Wooooh!"


translate italian danse22_5477c44c:


    ruby "[name]! [name]! [name]!"


translate italian danse22_58203668:


    ruby "Così impressionante! Dove hai imparato a farlo?"


translate italian danse22_1994e955:


    d "Oh... mi piace uscire e ballare con i miei amici, sai..."


translate italian danse22_0a44a128:


    grace "Era così bello!"


translate italian danse22_38e03a72:


    d "Ahah! Grazie!"


translate italian danse22_17420bbd:


    hec "Hmpffff..."


translate italian danse22_c81eac44:


    d "Yeah Yeah..."


translate italian danse22_22d2064c:


    dpense "Mi stai parlando come se mi importasse..."

translate italian strings:


    old "10:00 PM"
    new "22:00"


    old "Yes, I do![TEMP1!t]"
    new "Sì, lo faccio![TEMP1!t]"


    old "Uh, not really!"
    new "Ehm, non proprio!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
