


translate italian afterpoker_26fc436e:


    emerick "Dannazione, una scala reale contro il mio poker!" with hpunch


translate italian afterpoker_e128b8b4:


    d "Bella partita, Emerick."


translate italian afterpoker_59e4a75a:


    emerick "Bel gioco? Pensi che sia solo un gioco? Avrei dovuto vincere!" with hpunch


translate italian afterpoker_3c955927:


    d "La fortuna è stata dalla mia parte, immagino."


translate italian afterpoker_dd4d55fe:


    emerick "Fortuna? Non illuderti. Non perdo. Non è finita qui."


translate italian afterpoker_77e65e36:


    dpense "Emerick sembra furioso. Non sta prendendo bene questa perdita."


translate italian afterpoker_3745a13a:


    beth "Impressionante, [name]."


translate italian afterpoker_dea409f1:


    dpense "Beth mi ha tenuto d'occhio tutta la notte. Mi chiedo cosa stia facendo."


translate italian afterpoker_63c46105:


    beth "Vuoi restare un po' più a lungo?"


translate italian stay_with_beth_12cbaf67:


    beth "Bene. Sapevo che avresti fatto la scelta giusta."


translate italian stay_with_beth_13637baa:


    dpense "C'è qualcosa in lei... Così imponente, così irresistibile."


translate italian stay_with_beth_5927b544:


    beth "Siediti."


translate italian stay_with_beth_2c4b2623:


    dpense "Il suo tono non lascia spazio a discussioni."


translate italian stay_with_beth_50a31f22:


    beth "Bravo ragazzo."


translate italian stay_with_beth_a6ab9cc9:


    beth "Sai, [name], ti stavo osservando."


translate italian stay_with_beth_e9aab196:


    beth "Mi piace ciò che vedo."


translate italian stay_with_beth_7dd0a916:


    dpense "È così sicura di sé, così dominante. È allo stesso tempo intimidatorio ed elettrizzante."


translate italian stay_with_beth_51848909:


    beth "Vieni qui."


translate italian stay_with_beth_270f026f:


    beth "Ora."


translate italian stay_with_beth_5d63b95b:


    dpense "Non posso resisterle. La sua autorità è magnetica."


translate italian stay_with_beth_df740f72:


    beth "Mettiti in ginocchio."


translate italian stay_with_beth_4d0f74d6:


    d "Sì, Beth."


translate italian stay_with_beth_00872fa6:


    dpense "Non ho mai visto nessuno così autoritario. Il suo dominio è travolgente."


translate italian stay_with_beth_3b4a1fbe:


    beth "Mangiami."


translate italian stay_with_beth_79dc6287:


    dpense "Le sue parole mi fanno venire un brivido lungo la schiena."


translate italian stay_with_beth_8a2ed47c:


    dpense "Il suo profumo è inebriante. Il suo sapore è travolgente."


translate italian stay_with_beth_217d20bd:


    beth "Sì, proprio così. Non fermarti."


translate italian stay_with_beth_8752824b:


    dpense "Preme la mia testa contro di lei, prendendo il controllo. È intenso, ma mi piace."


translate italian stay_with_beth_03fc9228:


    beth "Stai andando bene. Continua."


translate italian stay_with_beth_5b7fdae8:


    dpense "Il suo dominio mi sta eccitando ancora di più. Voglio compiacerla, farla sentire incredibile."


translate italian stay_with_beth_d9f34e3d:


    beth "Sono vicina... Non osare fermarti adesso!"


translate italian stay_with_beth_ee2d4b4c:


    dpense "Posso sentire il suo corpo tremare. E' così vicina."


translate italian stay_with_beth_3a93f79f:


    beth "Ahh... Sì! Proprio così!"


translate italian stay_with_beth_39e51c28:


    dpense "Il suo orgasmo è potente. Mi afferra la testa, tenendomi fermo."


translate italian stay_with_beth_f72b2ae0:


    beth "Ora è il tuo turno."


translate italian stay_with_beth_804a34c9:


    beth "Sdraiati sul tavolo."


translate italian stay_with_beth_1b4e9d65:


    dpense "Sta prendendo il pieno controllo. È eccitante."


translate italian stay_with_beth_824d66ce:


    beth "Ti cavalcherò fino a venire di nuovo."


translate italian stay_with_beth_c59d4f05:


    dpense "La sua fiducia è inebriante. Non vedo l'ora di sentirla sopra di me."


translate italian stay_with_beth_7da8c02e:


    dpense "I suoi movimenti sono perfetti. Ha il controllo totale ed è fantastico."


translate italian stay_with_beth_2836d3f7:


    beth "Sì, proprio così. Non muoverti."


translate italian stay_with_beth_dcc9adf8:


    dpense "Sento che mi sto avvicinando. Il suo dominio mi sta spingendo al limite."


translate italian stay_with_beth_4f7ab2b2:


    beth "Vengo di nuovo. Non osare finire prima di me!"


translate italian stay_with_beth_96dca394:


    dpense "Le sue parole, il suo controllo... è troppo. Sto per venire..."


translate italian stay_with_beth_54eb3554:


    beth "Ora!"


translate italian stay_with_beth_da6a63b9:


    dpense "Non posso più trattenermi."


translate italian stay_with_beth_6841e6fc:


    d "Ahhhhh!!!!"


translate italian stay_with_beth_c10f8726:


    d "Dio mio!"


translate italian stay_with_beth_d35fe4c2:


    d "Fshhh..."


translate italian stay_with_beth_8f3148fe:


    dpense "Aspetta, cosa sta facendo?"


translate italian stay_with_beth_4a484680:


    beth "Sorpresa!"


translate italian stay_with_beth_23d91f6d:


    beth "Abbiamo pubblico. Sorridi e basta!"


translate italian stay_with_beth_f2258407:


    d "Cosa?" with hpunch


translate italian stay_with_beth_0d5b52a6:


    ruby "Dio mio!"


translate italian stay_with_beth_64d9349d:


    grace "Che diavolo...?"


translate italian stay_with_beth_f37737eb:


    mad "Disgustoso!"


translate italian stay_with_beth_46038782:


    sofia "Hey ragazze! Che cosa siete..."


translate italian stay_with_beth_81e7c462:


    sofia "[name]???"


translate italian stay_with_beth_9521deef:


    sofia "Come hai potuto?!"


translate italian stay_with_beth_53155274:


    dpense "Sofia..."


translate italian stay_with_beth_8690e0c0:


    dpense "NO..."


translate italian stay_with_beth_21a32b9c:


    beth "Tu..."


translate italian stay_with_beth_98249955:


    beth "Sei..."


translate italian stay_with_beth_5681410d:


    beth "Mio!"


translate italian stay_with_beth_119586b3:


    beth "Penso che tu possa andare a casa adesso."


translate italian stay_with_beth_9e386227:


    d "Mah..."

translate italian strings:


    old "Sure, why not?[TEMP1!t]"
    new "Certo, perché no?[TEMP1!t]"


    old "No, thanks.[TEMP2!t]"
    new "No, grazie.[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
