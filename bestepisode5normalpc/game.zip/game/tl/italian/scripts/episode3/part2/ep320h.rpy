


translate italian ep320h_2d397f37:


    emerick "Allora, siete pronti a festeggiare con me stasera, ragazzi?"


translate italian ep320h_32390969:


    "Sì!"


translate italian ep320h_5b232966:


    emerick "Francese! Sai come vestirti adesso?"


translate italian ep320h_328830e7:


    emerick "I vestiti non fanno l'uomo che conosci?"


translate italian ep320h_7e51d70c:


    hec "Ebbene, il Cavaliere Bianco..."


translate italian ep320h_6a2dc343:


    hec "Non hai il tuo Pinkie con te?"


translate italian ep320h_b6fde834:


    mad "Dovresti stare zitto Hector, o mi assicurerò che tu ti penti di aver aperto la bocca!"


translate italian ep320h_ec2abea6:


    emerick "Bene, bene... Madison difende gli oppressi..."


translate italian ep320h_48df3ce2:


    julia "Abbiamo visto tutto..."


translate italian ep320h_4da915b8:


    julia "Ma grazie Madison... apprezzo il supporto."


translate italian ep320h_d8adca3a:


    d "Va bene... devi dirmi una cosa..."


translate italian ep320h_2307991b:


    ruby "Che cosa?"


translate italian ep320h_cbbc64d1:


    d "Avete tutti davvero un problema con i capelli o qualcosa del genere?"


translate italian ep320h_6b0b0af2:


    ruby "Eh?"


translate italian ep320h_e513a108:


    d "Beh tu, Madison, Julia... presto anche Grace avrà i capelli blu..."


translate italian ep320h_33793f20:


    ruby "Nessuno ti ha detto che le donne cambiano spesso?"


translate italian ep320h_dd5d68f3:


    d "Eh?"


translate italian ep320h_b8f092fd:


    ruby "Ebbene sì... Se qualcosa... O qualcuno provoca un cambiamento in una donna..."


translate italian ep320h_eb0cdf0c:


    ruby "Lei cambia..."


translate italian ep320h_51dd6509:


    d "E cosa vi fa cambiare così, uno dopo l'altro?"


translate italian ep320h_85e25575:


    ruby "Indovina, grande idiota!"


translate italian ep320h_ccf9fa2a:


    ruby "E c'è anche un effetto di gruppo!"


translate italian ep320h_0e7c633f:


    ruby "Un po' come la sincronizzazione del ciclo mestruale..."


translate italian ep320h_431c81ae:


    d "Ruby..." with hpunch


translate italian ep320h_2307991b_1:


    ruby "Cosa?"


translate italian ep320h_70104ecf:


    emerick "Va bene, c'è un tavolo che ci aspetta ragazzi!"


translate italian ep320h_32390969_1:


    "Sì!"


translate italian ep320h_48ca22b2:


    emerick "Ovviamente non stavo parlando di te, Francese."


translate italian ep320h_1523fe20:


    d "..."


translate italian ep320h_0a3b9a9e:


    "Hai ragione, caro cugino, vai a chiuderti e vai a giocare con i tuoi cazzi mosci!" with vpunch


translate italian ep320h_3283d5fb:


    d "Chi..."


translate italian ep320h_bc430bec:


    "E già che ci sei, cerca di non truffarli troppo!"


translate italian ep320h_65dd16d6:


    "Poveri ragazzi, già non hanno onore, sarebbe peggio se prendeste i loro soldi..."


translate italian ep320h_21ef69aa:


    ruby "La principessa è arrivata..."


translate italian ep320h_74d8ea2d:


    d "La principessa?"


translate italian ep320h_db6ebde1:


    ruby "Sì... Lascia che ti presenti..."


translate italian ep320h_8a332571:


    ruby "Kira Orushi."


translate italian ep320h_d52ff3a3:


    d "Orushi?" with hpunch


translate italian ep320h_88407b4c:


    ruby "Sì... Sua figlia."


translate italian ep320h_8e04f38b:


    ruby "È la cugina di Emerick e... Come dire..."


translate italian ep320h_baf02865:


    ruby "Lui si rimpicciolisce quando lei è nei paraggi."


translate italian ep320h_515638be:


    ruby "Se Emerick si comporta come un pezzo grosso con la sua influenza..."


translate italian ep320h_b45b2506:


    ruby "Kira può cacciarlo da qualsiasi posto con un semplice schiocco delle dita."


translate italian ep320h_3deed7ed:


    d "Veramente?"


translate italian ep320h_4bb3aaa2:


    ruby "Sì... Guardali andare via a testa bassa."


translate italian ep320h_afb43a4a:


    ruby "Sembrano cani bastonati..."


translate italian ep320h_4e9c7294:


    d "Ma perché..."


translate italian ep320h_3d792aab:


    ruby "È una delle ragazze più potenti del paese..."


translate italian ep320h_a1e5b9c0:


    ruby "Influencer, potere, l'azienda di suo padre che eredita..."


translate italian ep320h_da574b0b:


    ruby "E molte attività le gestisce magistralmente."


translate italian ep320h_09de2a72:


    ruby "Controlla perfettamente la sua immagine..."


translate italian ep320h_ea0a923f:


    ruby "E..."


translate italian ep320h_12e4da9d:


    kira "E non mi sono ancora presentata!"


translate italian ep320h_9cfd5489:


    kira "Sono Kira. E ti do il benvenuto nel nostro Paese!"


translate italian ep320h_2969bbf3:


    kira "Scusa ancora per prima sul campo..."


translate italian ep320h_1567a5c4:


    kira "Ma volevo scuoterti un po'... sono sicura che puoi fare di meglio."


translate italian ep320h_c9ceb4e6:


    kira "Va bene, godiamoci questa serata?"


translate italian ep320h_ee39177b:


    ruby "Eh sì..."


translate italian ep320h_82e6f175:


    kira "Non preoccuparti Ruby, andrà tutto bene! E confido in te, sono sicura che hai preparato delle grandi cose per tutti noi!"


translate italian ep320h_b528cca1:


    ruby "Si si! Quindi, infatti, ogni ora ci saranno attività proposte in vari luoghi della casa"


translate italian ep320h_8bbb0f7b:


    ruby "Devi solo passeggiare e puoi scegliere a quale attività vuoi partecipare!"


translate italian ep320h_fd9b1315:


    ruby "E se non sai cosa fare o se ti perdi..."


translate italian ep320h_52f91e69:


    ruby "Vieni a chiedermelo!"


translate italian ep320h_12346ed5:


    kira "Grande! Non vedo l'ora di vederlo tutto!"


translate italian ep320h_93d865fe:


    grace "Quindi penso che sia ora di iniziare questa serata!"


translate italian ep320h_5ee1a6cf:


    "Sì!" with hpunch

translate italian strings:


    old "8:00 PM"
    new "20:00"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
