

translate italian strings:


    old "Progress: [done]/[total] scenes"
    new "Avanzamento: scene [done]/[total]"


    old "Quick Travel:"
    new "Viaggio veloce:"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
