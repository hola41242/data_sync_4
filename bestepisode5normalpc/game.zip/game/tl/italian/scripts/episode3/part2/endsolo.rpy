


translate italian endsolo_514498de:


    dpense "Bene, eccomi di nuovo nella mia stanza..."


translate italian endsolo_6ef229a3:


    dpense "Non è così che pensavo finisse la serata..."


translate italian endsolo_e38a6085:


    dpense "Domani probabilmente avrò altro da fare..."


translate italian endsolo_33e62c6e:


    dpense "Accompagna Julia all'ospedale..."


translate italian endsolo_7791dddf:


    dpense "Incontriamo Gabriella al museo..."


translate italian endsolo_be37121e:


    dpense "Partecipa a quella famosa cena con Madison..."


translate italian endsolo_fe3f28ed:


    dpense "In ogni caso la serata è stata interessante."


translate italian endsolo_49647293:


    dpense "Quella Kira è intrigante..."


translate italian endsolo_1cfe3d36:


    dpense "Ma non ho ancora avuto notizie da Elise..."


translate italian endsolo_1ea70810:


    dpense "Non è da lei..."


translate italian endsolo_517c34b4:


    dpense "Vediamo cosa succede dopo..."


translate italian endsolo_43441124:


    orushi "Simmons! Ecco Orushi!"


translate italian endsolo_29a690d4:


    orushi "Come vanno le cose con i tuoi?"


translate italian endsolo_0ba913d0:


    "Stiamo facendo progressi..."


translate italian endsolo_6c05280d:


    "Quasi pronti per la fase due."


translate italian endsolo_49eecb65:


    orushi "Già?"


translate italian endsolo_334961ea:


    "Già... E dalla tua parte?"


translate italian endsolo_ef8e4566:


    orushi "Accelereremo un po' le cose per essere pronti per il passaggio successivo."


translate italian endsolo_2474301e:


    "E gli altri?"


translate italian endsolo_54f4af4a:


    orushi "Stesso. Tutti più o meno allo stesso livello..."


translate italian endsolo_88825eb1:


    "Perfetto!"


translate italian endsolo_656c418e:


    orushi "Va bene. Alla prossima fase."


translate italian endsolo_f19f8ae6:


    "Da!"





translate italian endsolo_220827a5:


    dpense "La rara occasione di cenare con la famiglia di Madison."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
