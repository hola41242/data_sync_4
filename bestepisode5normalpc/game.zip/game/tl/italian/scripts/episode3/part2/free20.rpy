


translate italian free20main_b9817b1b:


    dpense "Il mio cuore perse un battito alle sue parole. Non mi aspettavo questo da Sofia. Dovrei andare?"


translate italian free20poker_e46e10c0:


    emerick "Non sei invitato, francese! Puoi tornare al tuo harem!"


translate italian free20poker_166fb7af:


    d "Qual è il tuo problema, Emerick?"


translate italian free20poker_e3a21349:


    emerick "Il mio problema? Non sei invitato quindi... Vaffanculo!"


translate italian free20poker_09774e7f:


    d "Sono qui solo per divertirmi, come tutti gli altri."


translate italian free20poker_caffb51d:


    emerick "Non mi interessa!"


translate italian julia20_e9b667af:


    julia "CIAO!"


translate italian julia20_7b0543b1:


    d "CIAO! La tua schiena si sente meglio?"


translate italian julia20_90f7916e:


    julia "Va meglio, ma me la sto comunque prendendo con calma."


translate italian julia20_e01785b9:


    julia "Penso che rimarrò un po' per le ragazze, ma non potrò fare tutto quello che Ruby ha pianificato..."


translate italian julia20_d303c45f:


    d "Ahah! Non so ancora cosa farò!"


translate italian julia20_0a194220:


    julia "Divertitevi, questa è la cosa principale!"


translate italian julia20_a676d5f9:


    d "Cercheremo!"


translate italian julia20_91ae47cb:


    d "Stai bevendo qualcosa?"


translate italian julia20_ebb81cf3:


    julia "No, meglio non con i farmaci..."


translate italian julia20_f36a5ff4:


    d "Va bene!"


translate italian julia20_12d28bf4:


    d "Oh, a proposito, adoro il tuo nuovo taglio di capelli!"


translate italian julia20_d5c0dba2:


    julia "OH? Grazie!"


translate italian julia20_c37e26a1:


    d "Ti piace cambiare pettinatura, vero? Ogni volta che ti vedo, ne hai uno nuovo!"


translate italian julia20_27255f05:


    julia "Hmm... Beh, in realtà questa volta è perché quello stronzo mi ha chiamato Pinkie e la cosa mi ha fatto incazzare..."


translate italian julia20_ba9103a5:


    d "Oh capisco..."


translate italian julia20_4811f618:


    julia "Quindi probabilmente mi lascerà in pace adesso."


translate italian julia20_f4bcc054:


    julia "E onestamente, mi piace così, quindi forse lo terrò questa volta!"


translate italian julia20_58878192:


    d "Ahah! Tocca a voi!"


translate italian julia20_8b665ac1:


    d "Anche se è piuttosto divertente vederti cambiare pettinatura..."


translate italian julia20_c4520b4a:


    d "Mi piace pensare a come sarai dopo. È sempre una sorpresa divertente!"


translate italian julia20_c2c84d9a:


    julia "Una sorpresa?"


translate italian julia20_d3bc2521:


    d "SÌ! Sei un po' imprevedibile, ma non preoccuparti. Mi piace che!"


translate italian julia20_c9b9f09a:


    julia "Ti piacciono le ragazze imprevedibili?"


translate italian julia20_b4e7c55d:


    d "Mi piacciono le ragazze che mi sorprendono."


translate italian julia20_8deff805:


    julia "Notato!"


translate italian julia20_ddf64e4d:


    d "Vado a vedere cosa fanno gli altri! Arrivederci?"


translate italian julia20_122dc49a:


    julia "Arrivederci!"


translate italian ruby20_54e9eef5:


    ruby "EHI! Allora, sei pronto per stasera?"


translate italian ruby20_2d1667b9:


    d "Sicuro!"


translate italian ruby20_47838d55:


    ruby "Bene, la prima attività che ho in programma è giocare a Twistplay!"


translate italian ruby20_55bd9a0f:


    d "Oh mio Dio... è passato molto tempo dall'ultima volta che ci ho giocato..."


translate italian ruby20_5624a2c3:


    ruby "È come andare in bicicletta! Non preoccuparti, è solo per divertimento!"


translate italian ruby20_fb37dec8:


    ruby "Non ci sono premi da vincere, solo divertimento!"


translate italian ruby20_ddd135eb:


    ruby "COSÌ..."


translate italian ruby20_a220d848:


    ruby "Vuoi giocare a Twistplay?"


translate italian ruby20_2a344a80:


    d "Sì, naturalmente!"


translate italian ruby20_c6e7417e:


    d "No grazie"


translate italian gracemadison20_22e7c1e7:


    mad "E non mi ha nemmeno detto che è stata male tutto il giorno finché non le ho chiesto del vomito sui suoi vestiti!"


translate italian gracemadison20_ec0774f0:


    mad "Non l'ha nemmeno cambiata. Lo giuro!"


translate italian gracemadison20_929b3308:


    grace "Non puoi davvero fidarti di lui..."


translate italian gracemadison20_5fb85e30:


    mad "Non mi fido più di nessun uomo nella mia vita!"


translate italian gracemadison20_2e4b2f5d:


    mad "Te l'ho detto! Meglio soli che in cattiva compagnia!"


translate italian gracemadison20_5813eb09:


    grace "Non sono tutti così però!"


translate italian gracemadison20_0f959e66:


    mad "Se riesci a trovarne uno che non sia così, è meglio che te lo tenga stretto!"


translate italian gracemadison20_bb8a7268:


    grace "Non si sa mai, potremmo trovare qualcuno che possa soddisfarci."


translate italian gracemadison20_aaae4443:


    mad "Come un ragazzo perfetto che cade dal cielo? Non succederà, tesoro!"


translate italian gracemadison20_dd6aca0e:


    grace "Perché aspettare che cada?"


translate italian gracemadison20_47e7ef71:


    grace "Potrei semplicemente incontrarlo nel cielo!"


translate italian gracemadison20_2c8fb2dd:


    mad "Eh???"


translate italian gracemadison20_9e3164dd:


    d "Di cosa stai parlando?"


translate italian gracemadison20_e0fa34d0:


    mad "Oh sai, responsabilità, relazioni, figli."


translate italian gracemadison20_21c07e24:


    mad "Solo qualche chiacchierata tra ragazze!"


translate italian gracemadison20_833b1ae7:


    grace "Ehi [name]! Ti piacerebbe avere figli?"


translate italian gracemadison20_31236522:


    d "Un giorno sì! Ma non ho fretta!"


translate italian gracemadison20_7babe025:


    mad "Sì, è giovane, ha tutto il tempo!"


translate italian gracemadison20_ab07cfa9:


    grace "Sì è vero. È bello saperlo però!"


translate italian gracemadison20_cae75794:


    d "No, onestamente, non penso che i bambini facciano per me."


translate italian gracemadison20_ae441c39:


    mad "Almeno è onesto..."


translate italian gracemadison20_e1929ec1:


    grace "Non si sa mai, potrebbe cambiare idea più tardi."


translate italian gracemadison20_a68fb151:


    d "Non lo so... Comunque per ora non è sicuramente nei miei piani!"


translate italian gracemadison20_00c8df40:


    mad "Per ora ho le mani occupate!"


translate italian gracemadison20_68b29370:


    grace "Ahah! Posso immaginare! Inoltre, tuo fratello potrebbe fare più lavoro di quello che risparmia!"


translate italian gracemadison20_4bf8646f:


    d "Suo fratello?"


translate italian gracemadison20_e7caeca7:


    grace "Sì, suo fratello si prende cura di sua figlia quando è all'Accademia o è in viaggio per le partite..."


translate italian gracemadison20_0179b026:


    mad "Ma non sta andando bene!"


translate italian gracemadison20_3996a386:


    mad "Il ragazzo resta accasciato sul divano tutto il giorno, e quando si tratta di prendersi cura di un piccolo... non lo si trova da nessuna parte."


translate italian gracemadison20_8c9ae968:


    grace "Andiamo, Maddie! Rilassati e bevi qualcosa, sarà meglio!"


translate italian gracemadison20_9a1573c3:


    mad "Si hai ragione! Smettiamola di pensarci e godiamoci la serata!"


translate italian gracemadison20_ceddc600:


    grace "Giusto! Brindiamo a..."


translate italian gracemadison20_66edb94c:


    grace "A cosa?"


translate italian gracemadison20_996828a8:


    d "Al nostro incontro?"


translate italian gracemadison20_281c814d:


    grace "Si è così! Al nostro incontro, a questo concorso e a quest'anno che sarà sicuramente ricco di sorprese!"


translate italian gracemadison20_6860a799:


    "Saluti!" with hpunch


translate italian kira20_76978961:


    kira "EHI! [name], giusto?"


translate italian kira20_11b6e570:


    d "SÌ!"


translate italian kira20_63270a58:


    kira "Lascia che ti presenti Fanny!"


translate italian kira20_c9f48e51:


    d "Piacere di conoscerti!"


translate italian kira20_cbac991e:


    kira "Oh, non preoccuparti, non capisce niente di quello che dici!"


translate italian kira20_dd5d68f3:


    d "Eh?"


translate italian kira20_090957fb:


    kira "Sì, viene da un altro paese e non parla la nostra lingua."


translate italian kira20_b2fb687f:


    d "Uh... Allora perché è qui allora?"


translate italian kira20_714495ac:


    kira "Bene, la nostra scuola ha programmi di scambio di lingue. Sai, per il commercio internazionale."


translate italian kira20_67a82fd5:


    kira "Quindi sono la sua ospite ma non sembra interessata ad imparare la nostra lingua"


translate italian kira20_25b067eb:


    kira "Tuttavia ha una figura perfetta, un corpo ideale e un bel viso."


translate italian kira20_9fca5bb8:


    kira "Quindi, ho colto l'opportunità di diventare il suo OSM."


translate italian kira20_23c22a5e:


    d "Il suo OSM?"


translate italian kira20_822c4b60:


    kira "Solo Stan Manager!"


translate italian kira20_2540386d:


    d "Che cos'è?"


translate italian kira20_0d95348d:


    kira "Uhm... Conosci OnlyStan?"


translate italian kira20_87fc9282:


    d "Ne ho sentito parlare. È quella piattaforma per la creazione di contenuti che è una specie di..."


translate italian kira20_7caab17d:


    kira "Adulto, sì. Ospita un po' di tutto però!"


translate italian kira20_470a0ba6:


    kira "E dal momento che non sa cosa vuole fare."


translate italian kira20_c9052c34:


    kira "Le ho aperto un conto lì per farle guadagnare un po' di soldi!"


translate italian kira20_bec902dc:


    d "Come mai?"


translate italian kira20_f0c1cba5:


    kira "Fondamentalmente lei non tocca il conto, lo gestisco io."


translate italian kira20_36c8d6dc:


    kira "Preparo un programma settimanale per lei simile. Lunedì vai in spiaggia e fai foto in bikini."


translate italian kira20_7a54482d:


    kira "Martedì vai in piscina... Mercoledì ti scatti delle foto a letto..."


translate italian kira20_a4a39f55:


    d "E lei lo fa?"


translate italian kira20_f1dc0a9e:


    kira "Beh si! Comunque stava già passando il tempo al telefono imbronciata."


translate italian kira20_9d72dc9f:


    kira "Non stiamo cambiando nulla... stiamo solo guadagnando soldi con le sue foto!"


translate italian kira20_1bda52ce:


    d "Uhm... E se chiedessero cose più rischiose?"


translate italian kira20_d26751e5:


    kira "Oh, dipende da lei! Trasmetto le richieste e lei decide se vuole farle o no."


translate italian kira20_4e452bbd:


    d "OH..."


translate italian kira20_4dba9ffa:


    kira "Voglio dire, è quello che fai se vuoi fare bei soldi. Gli abbonamenti sono buoni, ma le foto con una richiesta più personale sono il modo in cui guadagni davvero."


translate italian kira20_8f92cc28:


    d "Non è vicino alla prostituzione?"


translate italian kira20_7afac9f9:


    kira "Beh, immagino che questo faccia di me il magnaccia più figo e carino che tu abbia mai incontrato!"


translate italian kira20_d912e36d:


    d "Non intendevo questo. È solo che stai facendo soldi con il suo corpo"


translate italian kira20_bda08395:


    kira "Ahah! Beh, non si lamenta!"


translate italian kira20_a1cb4e30:


    d "Beh, se non parla la lingua, non può..."


translate italian kira20_db2aa7b3:


    kira "E lei ottiene l'80%% di quello che guadagna, io prendo solo il 20%% per gestire, organizzare e rispondere ai messaggi per lei."


translate italian kira20_85110e9c:


    d "Oh, quindi non è lei che risponde?"


translate italian kira20_778d6ef8:


    kira "No! Non poteva!"


translate italian kira20_9feafa6e:


    kira "Quindi fingo di essere lei e incoraggio i ragazzi che parlano con lei a mettere mi piace alle sue foto e a dare un'occhiata a quelle nuove."


translate italian kira20_6d7a39b0:


    d "Sembra un'ottima impostazione."


translate italian kira20_bc15f278:


    kira "Sì, mi forma anche per altri progetti! Non lo farò per tutta la vita! È più un hobby."


translate italian kira20_cadb9a4f:


    d "Strano hobby però!"


translate italian kira20_f695fe29:


    kira "Ahah! Ok, adesso le dico di farsi una foto, vedrai!"


translate italian kira20_a6c2d4ec:


    kira "Fanny! Vai al centro della stanza, ti farò una foto."


translate italian kira20_f0657274:


    "Va bene."


translate italian kira20_d7331970:


    kira "Vedi, fa quello che dico!"


translate italian kira20_9a3fd59f:


    kira "Ora mostra di più del tuo sedere!"


translate italian kira20_e099747a:


    d "Ok... vi lascio fare! A dopo?"


translate italian kira20_edceb7aa:


    kira "Sì! E dai un'occhiata al suo OnlyStan se sei interessato!"


translate italian kira20_65fdf5f6:


    d "Uh... ci penserò!"


translate italian debiles20_ee280869:


    mac "E poi il ragazzo mi chiama fino al fiume!"


translate italian debiles20_0b75be13:


    ben "Dannazione!"


translate italian debiles20_8cf98d22:


    mac "Sì, e avevo una coppia d'assi, vedi!"


translate italian debiles20_0b75be13_1:


    ben "Dannazione!"


translate italian debiles20_d3c96603:


    mac "Beh, ha centrato il suo colore, non preoccuparti!"


translate italian debiles20_ea8b6fa1:


    mac "E i miei assi sono stati battuti di nuovo!"


translate italian debiles20_0b75be13_2:


    ben "Dannazione!"


translate italian debiles20_1300bd7d:


    mac "Sì! Lo giuro, questi ragazzi non sanno giocare!"


translate italian debiles20_a01646a5:


    ben "Sì, lo stesso qui l'altro giorno..."


translate italian debiles20_e9adca6b:


    "Bene allora?" with hpunch


translate italian debiles20_dd5d68f3:


    d "Eh?"


translate italian debiles20_983ef4f8:


    s "Non stai aspettando Steven?"


translate italian debiles20_5ee1a6cf:


    "Sì!" with hpunch


translate italian debiles20_27a3722f:


    s "Il re della festa è qui!"


translate italian debiles20_5ee1a6cf_1:


    "Sì!" with hpunch


translate italian debiles20_825642f5:


    d "Il re della festa?"


translate italian debiles20_84f4497b:


    sofia "Sì, il ragazzo pensa di essere una persona attraente..."


translate italian debiles20_dd5d68f3_1:


    d "Eh?"


translate italian debiles20_7bdad836:


    sofia "Fondamentalmente, questi ragazzi organizzano una festa ogni anno e pensano che sia la migliore festa a cui possono partecipare..."


translate italian debiles20_18000c7a:


    sofia "Ma alla fine, finiscono insieme, non pianificano nulla, bevono e svengono sul divano..."


translate italian debiles20_a99b3fad:


    sofia "I re della festa."


translate italian debiles20_9e386227:


    d "Mah..."


translate italian debiles20_d6f6da9b:


    s "Mostriamo a queste ragazze cos'è un vero uomo!"


translate italian debiles20_5ee1a6cf_2:


    "Sì!" with hpunch


translate italian blue20_5eee312c:


    d "Cosa ci fai qui tutto solo?"


translate italian blue20_9d28e022:


    sofia "Prendo una boccata d'aria fresca prima che tutti inizino a entusiasmarsi!"


translate italian blue20_baffc8cb:


    d "Entusiasmarsi?"


translate italian blue20_5e9e01cf:


    sofia "Sì, lo sai. L'alcol, i giochi..."


translate italian blue20_efd9aaae:


    d "Non ti piace troppo?"


translate italian blue20_ef5e272b:


    sofia "Sì, sì... Ma mi piace anche quando posso avere un po' di pace e tranquillità a volte."


translate italian blue20_3655435f:


    d "Qualcosa ti preoccupa?"


translate italian blue20_08958f33:


    sofia "Ah. Ehm..."


translate italian blue20_4876fdd7:


    dpense "È chiaramente turbata da qualcosa."


translate italian blue20_6fb8f6cb:


    dpense "Forse dovrei dire qualcosa per farla sentire meglio."


translate italian blue20_4b57eba2:


    d "Non so perché hai deciso di non truccarti blu, ma stai davvero bene senza."


translate italian blue20_36f6f4f8:


    sofia "Veramente?"


translate italian blue20_75efb952:


    d "Sì... non so come dirlo, ma è come se qualcosa in te fosse cambiato."


translate italian blue20_08809f48:


    sofia "Sì... beh, non ancora."


translate italian blue20_b7ba2ada:


    d "E cambierai pettinatura come le altre?"


translate italian blue20_165ba7f8:


    sofia "Uh... non ci ho ancora pensato."


translate italian blue20_0e1ed2f6:


    d "Ahah! Sto scherzando! È solo che tutte le ragazze sembrano cambiare, e ho pensato che avresti voluto distinguerti da..."


translate italian blue20_e69d927e:


    sofia "Mia sorella..."


translate italian blue20_1ecede8d:


    d "Uh... No, stavo per dire dalle altre, ma."


translate italian blue20_4f768d0a:


    sofia "OH. SÌ. Non lo so."


translate italian blue20_fba1bb14:


    sofia "Vado alla toilette prima che la festa abbia inizio. Mi prendo un minuto per schiarirmi le idee, capisci?"


translate italian blue20_1cda50cf:


    d "Ah? Va bene!"


translate italian blue20_97785a33:


    d "Allora a dopo?"


translate italian blue20_231069d2:


    sofia "Sì, ci vediamo più tardi!"


translate italian blue20_2476d037:


    dpense "Ha un problema con sua sorella?"


translate italian blue20_d6acb73c:


    dpense "Strano..."


translate italian red20_b983e6dc:


    beth "Vuoi giocare?"


translate italian red20_49f5c417:


    d "Hai sentito il capo?"


translate italian red20_55418a01:


    beth "Sì, ma non è un grosso problema. Non può rifiutarmi nulla. E certamente non avere qualcuno al tavolo con cui giocare."


translate italian red20_b7783d6e:


    beth "Allora, vuoi giocare?"


translate italian red20_48ae9e3d:


    d "Sì, sarebbe fantastico!"


translate italian red20_655febea:


    beth "Fantastico! Ascolta, ti metto sul tavolo 1.000 dollari come buio iniziale."


translate italian red20_5731001e:


    beth "Se vinci, mi restituisci i 1000 dollari e tieni il resto."


translate italian red20_b836592c:


    beth "Se perdi... dovrai rimediare in un altro modo."


translate italian red20_f36a5ff4:


    d "Va bene!"


translate italian red20_f26b2c0b:


    beth "Perfetto!"


translate italian red20_c6b71068:


    d "No, sto bene."


translate italian red20_1e03c0a4:


    d "Non voglio uscire con ragazzi così..."


translate italian red20_9d3c5279:


    beth "Sei sicuro? Posso prestarti i soldi se sei a corto!"


translate italian red20_f337b71d:


    d "No, non mi interessa."


translate italian red20_b811790e:


    beth "Va bene!"


translate italian emerick20_bdd5c9e4:


    emerick "Sembra che qualcuno abbia deciso di garantire per te..."


translate italian emerick20_cd4e2af9:


    emerick "Comunque... Puoi giocare con noi se vuoi."


translate italian emerick20_56454df3:


    emerick "Giochiamo per 2 ore, quindi non puoi andartene finché non avremo finito!"


translate italian emerick20_6b777721:


    emerick "Sei sicuro di voler giocare contro di noi?"


translate italian emerick20_80bb8032:


    d "Sì. Sono eccitato nel vedere quanto sei bravo."


translate italian emerick20_8cbc8217:


    emerick "Non essere troppo fiducioso..."


translate italian emerick20_d86ce540:


    d "Uh... Uh... Uh... No!"


translate italian emerick20_d598134a:


    d "Non voglio passare tutta la serata qui."


translate italian emerick20_0093a926:


    emerick "Allora perché sei venuto qui per farci perdere tempo?"


translate italian kira20poker_3feab173:


    d "Kira... potresti aiutarmi con tuo cugino?"


translate italian kira20poker_271d1f62:


    kira "Eh?"


translate italian kira20poker_148ff3e5:


    d "Non vuole che giochi a poker con lui e i suoi ragazzi."


translate italian kira20poker_afa7eb49:


    kira "OH?"


translate italian kira20poker_e0facd95:


    kira "Non preoccuparti, gli dirò che ti invito."


translate italian kira20poker_b7378a12:


    kira "Non può rifiutare."


translate italian kira20poker_227865d4:


    d "Sei sicura?"


translate italian kira20poker_9b0d0415:


    kira "Si si! Vai avanti, te l'avevo detto!"


translate italian kira20poker_b01d0032:


    d "Oh, fantastico, grazie!"

translate italian strings:


    old "Meet me in the bathroom up there"
    new "Ci vediamo nel bagno lassù"


    old "Um... Why?"
    new "Ehm... Perché?"


    old "Hurry up... We don't have much time..."
    new "Sbrigati... non abbiamo molto tempo..."


    old "Accept[TEMP1!t]"
    new "Accetta[TEMP1!t]"


    old "Decline[TEMP2!t]"
    new "Rifiuta[TEMP2!t]"


    old "Okay... I'll be right there."
    new "Ok... arrivo subito."


    old "I'm not sure if that's a good idea..."
    new "Non sono sicuro che sia una buona idea..."


    old "I understand... Maybe some other time then."
    new "Capisco... Magari un'altra volta allora."


    old "Yes (Advance time and ends free-roam)"
    new "Sì (tempo avanzato e fine del free-roam)"


    old "No, maybe later..."
    new "No, forse più tardi..."






translate italian gracemadison20_70f6dc22:


    grace "Haha! Posso immaginarlo! In più, tuo fratello è più un lavoro che un aiuto!"




translate italian kira20_42ec4458:


    kira "Ha una figura perfetta, un corpo ideale e un bel viso."


translate italian kira20_552d5dfd:


    d "Sembra una configurazione davvero buona."


translate italian emerick20_6f369099:


    emerick "Sembra che qualcuno abbia deciso di garantire per te..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
