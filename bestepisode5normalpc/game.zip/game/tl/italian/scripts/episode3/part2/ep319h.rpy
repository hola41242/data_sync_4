


translate italian ep319h_288e63cd:


    dpense "C'è già tanta gente..."


translate italian ep319h_5afe9333:


    dpense "E sono tutti vestiti bene..."


translate italian ep319h_13a9fa4a:


    dpense "Chi è quella ragazza che..."


translate italian ep319h_98025551:


    d "Ruby???"


translate italian ep319h_8ce58592:


    dpense "E' davvero Ruby? Sembra così diversa..."


translate italian ep319h_29939e59:


    ruby "SÌ? Oh, sei già qui?"


translate italian ep319h_fefd1e11:


    d "Oh! Sei stupenda!"


translate italian ep319h_0646292d:


    dpense "Non posso credere quanto sia bella stasera."


translate italian ep319h_5f32c47f:


    ruby "OH?"


translate italian ep319h_a526621d:


    ruby "Grazie!"


translate italian ep319h_ec88a91b:


    ruby "Dunque, per stasera, abbiamo preparato un sacco di cose. Spero che non ti annoierai."


translate italian ep319h_ae9dbbe9:


    d "Cosa hai preparato esattamente?"


translate italian ep319h_49729cc2:


    dpense "Per favore, non lasciare che sia troppo imbarazzante..."


translate italian ep319h_0ca74eee:


    ruby "Vedrai."


translate italian ep319h_d0c288ce:


    ruby "Fondamentalmente l'intera serata è divisa in ore."


translate italian ep319h_5c4a411a:


    ruby "E ogni ora ho organizzato giochini diversi."


translate italian ep319h_4bec68d4:


    ruby "Puoi partecipare oppure no, dipende da te."


translate italian ep319h_fafccd1b:


    dpense "Giochi? Potrebbe essere interessante o un disastro..."


translate italian ep319h_bb1569ab:


    ruby "Non ti obbligherò a fare nulla. Comunque sei libero di girare per casa."


translate italian ep319h_1af2f630:


    ruby "Come al solito a queste feste, è probabile che incontrerai persone in posti diversi."


translate italian ep319h_255a7214:


    ruby "Alcuni saranno addirittura in garage a giocare a poker, quindi non esitate a girovagare!"


translate italian ep319h_0a1f2fff:


    ruby "Ma spero di vederti ad una delle mie partite."


translate italian ep319h_71621c21:


    dpense "Dovrei almeno provare uno dei suoi giochi, solo per vedere com'è."


translate italian ep319h_dc5092d9:


    d "Beh, immagino che sia meglio che anch'io vada a prepararmi..."


translate italian ep319h_b2c71a98:


    dpense "Devo assicurarmi di avere un aspetto decente..."


translate italian ep319h_4a431b19:


    ruby "Grace dovrebbe aspettarti dentro."


translate italian ep319h_79e4de0e:


    ruby "Vai a trovarla, ti dirà dove prepararti."


translate italian ep319h_15e6cd4c:


    d "Va bene. Bene ci vediamo dopo?"


translate italian ep319h_153d7992:


    ruby "A dopo!"


translate italian ep319h_0cdc2a05:


    dpense "Spero di non fare confusione..."


translate italian ep319h_0d6e6088:


    d "Sei bellissima..."


translate italian ep319h_fb1b5575:


    grace "Grazie."


translate italian ep319h_62b19db8:


    dpense "Vorrei baciarla così tanto, ma non possiamo rischiare di essere visti..."


translate italian ep319h_dd8da065:


    grace "Non saremo in grado di fare così tanto quando tutti saranno qui."


translate italian ep319h_9f52115e:


    grace "Ne approfitterò adesso."


translate italian ep319h_8034db0c:


    d "Sì, cerchiamo di essere discreti."


translate italian ep319h_410930f8:


    dpense "Le sue labbra sono così morbide... Questo momento è troppo breve."


translate italian ep319h_3dbd89d8:


    d "Sarà difficile non saltarti addosso durante la festa!"


translate italian ep319h_96c87c04:


    grace "SÌ..."


translate italian ep319h_8d61d8e6:


    dpense "La desidero così tanto, ma dobbiamo stare attenti..."


translate italian ep319h_044e92c2:


    d "Stai attento, qualcuno potrebbe vederci."


translate italian ep319h_2e68ce35:


    d "Meglio non sfidare il destino."


translate italian ep319h_e2691be7:


    grace "Sì hai ragione."


translate italian ep319h_429f8aa7:


    dpense "Odio dovermi trattenere, ma è necessario..."


translate italian ep319h_228cc50b:


    grace "Per tutta la serata ti lascerò fare quello che vuoi."


translate italian ep319h_ea019296:


    dpense "Tutto quello che voglio? Potrebbe essere divertente..."


translate italian ep319h_0765a666:


    grace "Ad ogni modo, non avrò molta scelta."


translate italian ep319h_cde65b21:


    d "Tutto quello che voglio?"


translate italian ep319h_da9605d7:


    grace "Entro limiti ragionevoli, ovviamente!"


translate italian ep319h_4fef3683:


    grace "Ma so come sono progettati i giochi di Ruby e se devi baciare una ragazza..."


translate italian ep319h_518dcdae:


    grace "Oppure ballare a stretto contatto con un' altra..."


translate italian ep319h_a89eba91:


    grace "Ruby ha pianificato delle sfide, quindi non ce l'ho con te."


translate italian ep319h_4fa86eb0:


    grace "Più ti comporti come un single..."


translate italian ep319h_b97bc95a:


    grace "Meno persone avranno dubbi su di noi."


translate italian ep319h_d53904b1:


    d "Sono d'accordo."


translate italian ep319h_b330e6ff:


    dpense "Interpretare il ruolo del single potrebbe essere complicato, ma è meglio così..."


translate italian ep319h_cf274390:


    grace "Ma dopo la festa, sei tutto mio!"


translate italian ep319h_435babe9:


    dpense "Non vedo l'ora..."


translate italian ep319h_6181ffc8:


    d "Sai se Red mi ha lasciato qualcosa?"


translate italian ep319h_4b78ee47:


    grace "Sì, ha lasciato il tuo vestito nella stanza di sopra."


translate italian ep319h_39f0500c:


    grace "Vai di sopra, prendi la porta a sinistra e dovrebbe essere nell'armadio."


translate italian ep319h_659c76cf:


    d "Va bene, va bene. Grazie!"


translate italian ep319h_fef54646:


    dpense "Spero che il vestito sia bello..."


translate italian ep319h_5704be0d:


    grace "No, ma non preoccuparti."


translate italian ep319h_685bd6f6:


    grace "Vai di sopra, nella stanza alla tua sinistra."


translate italian ep319h_194ad930:


    grace "Puoi prendere il vestito che ho scelto dall'armadio."


translate italian ep319h_d24354b3:


    grace "Era di mio padre. Penso che ti starà perfettamente."


translate italian ep319h_73e5a328:


    d "Grazie mille, Grace!"


translate italian ep319h_f78eebb7:


    dpense "Spero che si adatti bene..."


translate italian ep319h_86e4c7aa:


    grace "Non c'è di che! Ora vai!"


translate italian ep319h_e65cbcaf:


    dpense "È ora di prepararsi per qualunque cosa porti questa notte..."


translate italian ep319h_2928c85d:


    grace "Forse avrei dovuto avvertirlo di Madison..."


translate italian ep319hmadison_faeed9e5:


    dpense "Quelle gambe..."


translate italian ep319hmadison_7b470d71:


    dpense "E quel corpo... Deve aver lavorato così duramente per mantenere la sua figura."


translate italian ep319hmadison_2cceb6e2:


    d "Madison?"


translate italian ep319hmadison_95b89350:


    dpense "Cosa ci fa qui?"


translate italian ep319hmadison_e9d6e7e4:


    mad "SÌ?"


translate italian ep319hmadison_4058aafc:


    mad "OH! Sei tu?"


translate italian ep319hmadison_005532b2:


    d "Scusa... stavo cercando il mio abito ma posso tornare più tardi e..."


translate italian ep319hmadison_15923c5d:


    mad "No, no. Adesso che sei qui, aiutami a mettere la collana."


translate italian ep319hmadison_4974962b:


    d "Questa sul letto?"


translate italian ep319hmadison_548cfe7d:


    mad "Già... Ne vedi altre?"


translate italian ep319hmadison_a67f284e:


    d "Uhm...no..."


translate italian ep319hmadison_7bcc50f4:


    d "Va bene..."


translate italian ep319hmadison_b338417f:


    d "Sei veramente bella."


translate italian ep319hmadison_80856c0f:


    dpense "La sua bellezza è innegabile, ma è la sua forza che mi affascina di più."


translate italian ep319hmadison_9e40f1b6:


    mad "Stai tremando."


translate italian ep319hmadison_2ce96c5a:


    d "Sì... non sono abituato a toccare una donna così meravigliosa..."


translate italian ep319hmadison_c456a93d:


    dpense "Deve pensare che sono proprio come gli altri. Devo dimostrarle che sono diverso."


translate italian ep319hmadison_83ae8453:


    mad "Te l'avevo detto che era una cosa che avveniva una sola volta..."


translate italian ep319hmadison_5db0af98:


    d "Lo so."


translate italian ep319hmadison_4e845f8a:


    dpense "Ma ogni momento con lei sembra un dono che non merito."


translate italian ep319hmadison_8b44f43b:


    mad "E non dovremmo farlo di nuovo..."


translate italian ep319hmadison_d806887a:


    mad "Anche se i nostri desideri sono qui..."


translate italian ep319hmadison_e99f6e2f:


    dpense "È così sorvegliata. Chi può biasimarla dopo quello che ha passato?"


translate italian ep319hmadison_d00f18cb:


    mad "Dobbiamo..."


translate italian ep319hmadison_592754b5:


    mad "Tratteniamoci."


translate italian ep319hmadison_bb9305c7:


    mad "Ma..."


translate italian ep319hmadison_48a192a6:


    mad "Non puoi continuare così..."


translate italian ep319hmadison_1390acac:


    d "Lo so..."


translate italian ep319hmadison_a6762298:


    mad "E non posso neanche io."


translate italian ep319hmadison_916964a1:


    dpense "Ho bisogno di essere paziente. Ha bisogno di tempo per fidarsi di nuovo."


translate italian ep319hmadison_336548fb:


    mad "Questo è brutto, smettila di farmi complimenti..."


translate italian ep319hmadison_40a2f618:


    d "non posso..."


translate italian ep319hmadison_de49923d:


    mad "Smettila di dire quello che ho bisogno di sentire..."


translate italian ep319hmadison_dc3bdbc7:


    d "Non lo farò..."


translate italian ep319hmadison_e6ceeb5a:


    mad "Stop..."


translate italian ep319hmadison_f0fd1cdb:


    dpense "Ha paura di far entrare qualcuno. Devo trovare un modo per sfondare quel muro."


translate italian ep319hmadison_a75434a9:


    mad "Ho delle ragazze che mi aspettano!"


translate italian ep319hmadison_81f6fd8e:


    dpense "So che sta solo cercando di allontanarmi, ma non posso arrendermi."


translate italian ep319hmadison_bbfbae37:


    dpense "Credo che per ora sarò da solo."


translate italian ep319hsolo_bbfbae37:


    dpense "Credo che per ora sarò da solo."

translate italian strings:


    old "7:30 PM"
    new "19:30"


    old "Kiss her[TEMP1!t]"
    new "Baciala[TEMP1!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
