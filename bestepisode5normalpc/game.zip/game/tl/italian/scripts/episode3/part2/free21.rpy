


translate italian bluebathsequence_bfc258f4:


    sofia "Eccoti..."


translate italian bluebathsequence_640cb0b2:


    sofia "Sbrigati, non abbiamo molto tempo..."


translate italian bluebathsequence_39a0fffb:


    sofia "Ah!"


translate italian bluebathsequence_eaf3c1ee:


    d "È questo che vuoi?"


translate italian bluebathsequence_5b2496bc:


    dpense "È sempre così ansiosa..."


translate italian bluebathsequence_e5f0d377:


    sofia "Quello che voglio..."


translate italian bluebathsequence_50fca145:


    sofia "Voglio un uomo..."


translate italian bluebathsequence_99fba79e:


    sofia "Chissà come prendermi..."


translate italian bluebathsequence_65a81c4a:


    sofia "Chi mi guida e..."


translate italian bluebathsequence_6ef36208:


    sofia "AH!"


translate italian bluebathsequence_3b78e516:


    dpense "Mi sta facendo impazzire..."


translate italian bluebathsequence_c50c170c:


    d "Sei già eccitata prima ancora di iniziare..."


translate italian bluebathsequence_d9512405:


    sofia "Sono eccitata da quando mi hai fatto... nell'aula magna..."


translate italian bluebathsequence_c48e54c4:


    sofia "Da quando ho sentito le tue dita..."


translate italian bluebathsequence_5b26181d:


    d "Queste dita?"


translate italian bluebathsequence_5a262f9a:


    dpense "Adoro come reagisce..."


translate italian bluebathsequence_2f26ac84:


    sofia "Mmm..."


translate italian bluebathsequence_cf4f776b:


    d "Sei bagnata fradicia!"


translate italian bluebathsequence_0b8370ab:


    sofia "Te l'avevo detto!"


translate italian bluebathsequence_74d543c4:


    sofia "Ma non sono le tue dita che voglio oggi!"


translate italian bluebathsequence_abc5915a:


    sofia "Voglio te!"


translate italian bluebathsequence_5707bfa6:


    sofia "Quindi affrettati, non abbiamo molto tempo!"


translate italian bluebathsequence_6c2ebf4b:


    d "Lasciami toglierlo..."


translate italian bluebathsequence_b7c5a512:


    sofia "Vai avanti!"


translate italian bluebathsequence_56afc663:


    dpense "È così bagnata che scivola via..."


translate italian bluebathsequence_2f26ac84_1:


    sofia "Mmm..."


translate italian bluebathsequence_79cf69e9:


    sofia "Continua..."


translate italian bluebathsequence_ebb813c0:


    sofia "Mi piace così!"


translate italian bluebathsequence_47efd07c:


    sofia "Oh mio Dio, è così bello..."


translate italian bluebathsequence_0bd2f923:


    dpense "Lei è incredibile..."


translate italian bluebathsequence_56849dc7:


    sofia "Posso sentirti nel profondo dentro di me..."


translate italian bluebathsequence_a26bcf05:


    sofia "Ohhhhhh"


translate italian bluebathsequence_fc4c4d59:


    sofia "Di più! Di più!"


translate italian bluebathsequence_021156c2:


    sofia "Più veloce!"


translate italian bluebathsequence_33fabc63:


    sofia "Più forte!"


translate italian bluebathsequence_eb8f7bf6:


    dpense "È selvaggia!"


translate italian bluebathsequence_56d2001c:


    sofia "Andiamo, lo sento arrivare!"


translate italian bluebathsequence_312c0410:


    d "Anch'io, sento che sta crescendo."


translate italian bluebathsequence_944ded0c:


    sofia "Voglio sentirti... dentro di me! Fallo!"


translate italian bluebathsequence_420528c9:


    sofia "Riempimi!"


translate italian bluebathsequence_d75056be:


    sofia "SÌ! ti sento gonfiare!!!"


translate italian bluebathsequence_dad3c95e:


    d "Ahhhhhhhhhh!!!"


translate italian bluebathsequence_6a936112:


    dpense "Questo è irreale..."


translate italian bluebathsequence_3eb7df3c:


    sofia "Dio mio!!!"


translate italian bluebathsequence_fb6a33b0:


    sofia "Sembra incredibile..."


translate italian bluebathsequence_541b1006:


    sofia "Puoi fare quello che vuoi con me..."


translate italian bluebathsequence_925c17d4:


    sofia "Sono tua..."


translate italian bluebathsequence_4971b75a:


    sofia "Wow, è stato intenso..."


translate italian bluebathsequence_24a08cec:


    dpense "Non posso credere quanto sia stato fantastico..."


translate italian bluebathsequence_1774c03c:


    sofia "Adesso unisciti agli altri..."


translate italian bluebathsequence_2aa95cae:


    sofia "A dopo..."


translate italian bluebathsequence_d5fa7ba5:


    dpense "Non vedo l'ora che arrivi la prossima volta..."


translate italian freepokersequence_c2938bd3:


    emerick "Ah, finalmente..."


translate italian freepokersequence_cf8678ec:


    emerick "Il ragazzo riesce a mandare in crash il gioco e si prende il suo dolce tempo..."


translate italian freepokersequence_24dcd6cc:


    emerick "Spero che almeno tu sappia giocare..."


translate italian freepokersequence_32415610:


    emerick "Iniziamo con 1000 dollari... E scommetti sempre un minimo di 100 quando vuoi continuare, senza chiamare."


translate italian freepokersequence_e8a73106:


    emerick "Rilanciamo solo una volta, quindi non superiamo i 200."


translate italian freepokersequence_04aa1bf5:


    emerick "Stiamo giocando a Texas Hold'em: 2 carte, 5 sul board. Lo conosci o hai bisogno di un ripasso?"


translate italian freepokersequence_07fcd65a:


    d "Puoi rinfrescarmi la memoria? E' da un po' che non gioco..."


translate italian freepokersequence_36279863:


    emerick "Red, puoi spiegarglielo?"


translate italian freepokersequence_a9c4bc36:


    beth "Ok, ragazzi, andate avanti per il primo round, vi spiegherò man mano che procediamo..."


translate italian freepokersequence_ec5fc430:


    d "Non preoccuparti, so come si gioca."


translate italian freepokersequence_54d07f02:


    emerick "Bene, lo vedremo!"


translate italian firsthand_e86a8a7a:


    dpense "7 e 2..."


translate italian firsthand_ceb191ba:


    beth "Puoi scegliere di scommettere 100 per giocare la tua mano o passare..."


translate italian firsthand_212cc397:


    beth "7 e 2 è la mano peggiore che puoi avere... Lascia, è più facile."


translate italian firsthand_4d9cec0f:


    beth "Aspettiamo una mano migliore."


translate italian raisefirst_4af3fef4:


    d "Hum..."


translate italian raisefirst_da6cdede:


    d "Punto 100"


translate italian raisefirst_a8f7e65c:


    emerick "Sono dentro..."


translate italian raisefirst_dee9a1f0:


    hec "Lascio..."


translate italian raisefirst_73612da1:


    ben "Lascio..."


translate italian raisefirst_e963ac4e:


    mac "Sono dentro..."


translate italian raisefirst_cbfb1f43:


    beth "Il board..."


translate italian raisefirst_360c9b51:


    beth "Sette di cuori. Re di picche. Regina di fiori."


translate italian raisefirst_ac0535ba:


    dpense "Ho un paio di 7..."


translate italian raisefirst_27738fbb:


    dpense "Ma il re e la regina..."


translate italian raisefirst_cd216665:


    emerick "Non male..."


translate italian raisefirst_04e21e0e:


    mac "Hmm..."


translate italian raisefirst_bb544eb2:


    dpense "È il mio turno di agire per primo."


translate italian foldfirst_86a9bfaa:


    d "Lascio."


translate italian foldfirst_42175e86:


    emerick "Ah! Già lasci..."


translate italian foldfirst_6ac4b55b:


    d "Aspetterò un po' prima di ripulirti..."


translate italian foldfirst_e75f4463:


    emerick "Si certo..."


translate italian betfirst_507e59b5:


    d "Scommetto 100..."


translate italian betfirst_a8f7e65c:


    emerick "Sono dentro..."


translate italian betfirst_e963ac4e:


    mac "Sono dentro..."


translate italian betfirst_1ca60585:


    beth "Il turn..."


translate italian betfirst_efb4200a:


    beth "Due di cuori."


translate italian betfirst_85a67f5b:


    dpense "Ne ho due paia adesso..."


translate italian betfirst_84464fb5:


    emerick "Un mattone..."


translate italian betfirst_d30b2f3d:


    mac "Parli troppo, sul serio!"


translate italian betfirst_d6926074:


    emerick "Sì? Perché, ti dà fastidio?"


translate italian betfirst_92675bce:


    mac "No, no..."


translate italian betfirstturn_507e59b5:


    d "Scommetto 100..."


translate italian betfirstturn_bf39ee43:


    emerick "Io rilancio..."


translate italian betfirstturn_01952dec:


    mac "Call..."


translate italian callraiseturnfirst_d4af3017:


    d "Io call..."


translate italian callraiseturnfirst_7312aa2f:


    dpense "Andiamo... Il river..."


translate italian callraiseturnfirst_43774c19:


    beth "E il river."


translate italian callraiseturnfirst_86e388f5:


    beth "Otto di fiori."


translate italian callraiseturnfirst_72054f19:


    dpense "Un 8... non aiuta molto"


translate italian callraiseturnfirst_cf34f265:


    dpense "Ne ho ancora due paia..."


translate italian betfirstriver_507e59b5:


    d "Scommetto 100..."


translate italian betfirstriver_bf39ee43:


    emerick "Io rilancio..."


translate italian betfirstriver_4857b6aa:


    mac "Lascio..."


translate italian betfirstriver_6aae5fac:


    emerick "Ah, eccoci qua! Mr. Pro lascio!"


translate italian betfirstriver_98b0aa51:


    mac "..."


translate italian betfirstriver_3f18fd8f:


    emerick "E tu, francese?"


translate italian betfirstriver_5c342d8e:


    emerick "Call o lasci come Mac?"


translate italian endfirst_585c495f:


    d "Io call!"


translate italian endfirst_1ddc9ab4:


    emerick "Bene!"


translate italian endfirst_0123b601:


    beth "Ragazzi, mostrate le mani!"


translate italian endfirst_9af984ce:


    emerick "Doppia coppia, Re-Regina!"


translate italian endfirst_a9039faa:


    d "Dannazione..."


translate italian endfirst_57a20cf5:


    hec "7 e 2..."


translate italian endfirst_855e48ca:


    ben "Pfft..."


translate italian endfirst_29ac5843:


    d "Che cosa?"


translate italian endfirst_a44c39cf:


    mac "Niente niente..."


translate italian endfirst_d866667e:


    emerick "Questo è un buon inizio!"


translate italian secondhand_a25952de:


    ben "È impossibile essere così fortunati..." with hpunch


translate italian secondhand_71235bca:


    emerick "Questo è il gioco, Ben!"


translate italian secondhand_7bdb1b2e:


    ben "Sì, sì... beh, sono fuori, ragazzi..."


translate italian secondhand_53648650:


    mac "Buonanotte, Ben!"


translate italian secondhand_f6ff6b04:


    hec "Notte..."


translate italian secondhand_5617520a:


    emerick "Va bene ragazzi, quanto vi resta?"


translate italian secondhand_dcb8ab17:


    hec "400..."


translate italian secondhand_7607269e:


    dpense "Ho [moneypoker]$..."


translate italian secondhand_723b2ccf:


    dpense "Devo gestirlo..."


translate italian secondhand_92d4ec21:


    d "[moneypoker]..."


translate italian secondhand_bfb72c89:


    emerick "E tu, Mac?"


translate italian secondhand_7af6f01b:


    mac "Sono rimasto fermo a 1000 fin dall'inizio..."


translate italian secondhand_51a2c941:


    emerick "Andiamo avanti!"


translate italian secondhand_acb6662d:


    dpense "Assi!"


translate italian secondhand_309b2606:


    dpense "Questo è interessante!"


translate italian secondhand_cfb4069e:


    beth "Hai la mano migliore nel gioco."


translate italian secondhand_d2c68232:


    beth "Devi scommettere quando sei in vantaggio."


translate italian secondhand_9ffa980a:


    beth "Tu agisci per ultimo, vediamo cosa fanno gli altri..."


translate italian secondhand_29aafa4e:


    emerick "Scommetto 100!"


translate italian secondhand_534589df:


    hec "Ci sono..."


translate italian secondhand_2abf8722:


    mac "Ci sono..."


translate italian secondhand_4a9c96af:


    beth "Vai avanti, rilancia!"


translate italian callsecond_d4af3017:


    d "Io call..."


translate italian callsecond_a0eff481:


    beth "Beh... Almeno non ti vedranno arrivare..."


translate italian foldsecond_5853f4b8:


    d "Non mi sembra..."


translate italian foldsecond_8cd9bc60:


    beth "Sei serio?"


translate italian foldsecond_29ac5843:


    d "Che cosa?"


translate italian foldsecond_0d45e5bf:


    beth "Non importa..."


translate italian raisesecond_5449efcb:


    d "Io rilancio!"


translate italian raisesecond_72f87a6e:


    beth "Perfetto."


translate italian raisesecond_b2b546ab:


    emerick "Call..."


translate italian raisesecond_534589df:


    hec "Call..."


translate italian raisesecond_2abf8722:


    mac "Call..."


translate italian boardsecond_71d323cf:


    beth "I ragazzi del consiglio..."


translate italian boardsecond_8c073ec8:


    beth "Nove di fiori. Fante di picche. Regina di picche."


translate italian boardsecond_4eadc122:


    dpense "Hmm..."


translate italian boardsecond_5b5e5b81:


    beth "Già... questo board non è a tuo favore... Nove-Jack-Regina..."


translate italian boardsecond_18a9af10:


    beth "Sei già battuto da due coppie, tris, scale... alla fine è possibile anche un colore..."


translate italian boardsecond_1a210212:


    beth "Aspetta di vedere cosa fanno gli altri..."


translate italian boardsecond_29aafa4e:


    emerick "Scommetto 100!"


translate italian boardsecond_d222b261:


    hec "Ci sto!"


translate italian boardsecond_f0146759:


    emerick "Oh, oh! Qualcuno ha una mano!"


translate italian boardsecond_0b44c64a:


    mac "Lascio."


translate italian boardsecond_a170c960:


    dpense "Cosa devo fare?"


translate italian boardsecond_8a805c56:


    beth "Lascia... Questa mano puzza di guai..."


translate italian boardsecond_f487f85b:


    beth "Nel poker, se hai un dubbio... non c'è dubbio..."


translate italian boardsecond_130fe238:


    beth "Evidentemente non sei in una buona posizione..."


translate italian boardsecond_7bf7d14d:


    beth "Salva ciò che ti è rimasto, potrai comunque tornare più tardi..."


translate italian boardsecond_bdc68931:


    d "Tutto dentro!"


translate italian boardsecond_585c495f:


    d "Ci sto!"


translate italian boardsecond_9cff1cb6:


    emerick "Ci sto!"


translate italian boardsecond_bdc68931_1:


    d "Tutto dentro!"


translate italian boardsecond_5449efcb:


    d "Io rilancio!"


translate italian boardsecond_9cff1cb6_1:


    emerick "Ci sto!"


translate italian boardsecond_7404b6d9:


    d "Lascio..."


translate italian boardsecond_f7de9063:


    emerick "Bene, Hector è all in... Mostra la tua mano!"


translate italian boardsecond_1d55aa40:


    hec "Serie di 9!"


translate italian boardsecond_c2596d04:


    emerick "O si!"


translate italian boardsecond_8b385b22:


    emerick "Non male... ho Re-Jack..."


translate italian boardsecond_d95b091a:


    sofia "Ecco il turn..."


translate italian boardsecond_2e8a73d2:


    sofia "2 di Cuori..."


translate italian boardsecond_9eeb175e:


    emerick "Sei ancora bravo, Hector!"


translate italian boardsecond_ebe96f90:


    hec "Nessuna brutta sconfitta... Nessuna brutta sconfitta..."


translate italian boardsecond_65c54f8c:


    emerick "Dai! Vogliamo il river!"


translate italian boardsecond_25e4f758:


    sofia "Ecco il river..."


translate italian boardsecond_70ddf0f2:


    sofia "Dieci di picche..."


translate italian boardsecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate italian boardsecond_58145255:


    emerick "Dritto, tesoro!" with hpunch


translate italian boardsecond_cfed94d4:


    hec "Accidenti..."


translate italian boardsecond_7426dcb3:


    emerick "Oh andiamo Hector, non è poi così male!"


translate italian boardsecond_9a3c3b3d:


    hec "Vai all'inferno!"


translate italian boardsecond_a21e69bd:


    emerick "Ahah! Andiamo avanti!"


translate italian turnsecond_5b45644b:


    emerick "Bene ragazzi, siete tutti e due all-in... Mostrate le vostre mani!"


translate italian turnsecond_1d55aa40:


    hec "Serie di 9!"


translate italian turnsecond_09efb43f:


    d "Poker d'Assi!"


translate italian turnsecond_c2596d04:


    emerick "O si!"


translate italian turnsecond_8b385b22:


    emerick "Non male... ho Re-Jack..."


translate italian turnsecond_d95b091a:


    sofia "Ecco il turn..."


translate italian turnsecond_2e8a73d2:


    sofia "2 di Cuori..."


translate italian turnsecond_9eeb175e:


    emerick "Sei ancora bravo, Hector!"


translate italian turnsecond_ebe96f90:


    hec "Nessuna brutta sconfitta... Nessuna brutta sconfitta..."


translate italian turnsecond_08723f2a:


    dpense "mi serve un asso..."


translate italian turnsecond_65c54f8c:


    emerick "Dai! Vogliamo il river!"


translate italian turnsecond_25e4f758:


    sofia "Ecco il river..."


translate italian turnsecond_9a610ffe:


    sofia "Dieci di picche..."


translate italian turnsecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate italian turnsecond_58145255:


    emerick "Dritto, tesoro!" with hpunch


translate italian turnsecond_cfed94d4:


    hec "Accidenti..."


translate italian turnsecond_7426dcb3:


    emerick "Oh andiamo Hector, non è poi così male!"


translate italian turnsecond_9a3c3b3d:


    hec "Vai all'inferno!"


translate italian turnsecond_78561908:


    emerick "E grazie per essere venuto, francesino! Grazie per i tuoi soldi!"


translate italian turnsecond_d95b091a_1:


    sofia "Ecco il turn..."


translate italian turnsecond_2e8a73d2_1:


    sofia "2 di Cuori..."


translate italian turnsecond_29aafa4e:


    emerick "Scommetto 100!"


translate italian turnsecond_bdc68931:


    d "Tutto dentro!"


translate italian turnsecond_d4af3017:


    d "Ci sto..."


translate italian turnsecond_bdc68931_1:


    d "Tutto dentro!"


translate italian turnsecond_5449efcb:


    d "Io rilancio!"


translate italian turnsecond_9cff1cb6:


    emerick "Ci sto!"


translate italian turnsecond_7404b6d9:


    d "Lascio..."


translate italian turnsecond_f7de9063:


    emerick "Bene, Hector è all in... Mostra la tua mano!"


translate italian turnsecond_1d55aa40_1:


    hec "Serie di 9!"


translate italian turnsecond_c2596d04_1:


    emerick "O si!"


translate italian turnsecond_8b385b22_1:


    emerick "Non male... ho Re-Jack..."


translate italian turnsecond_9eeb175e_1:


    emerick "Sei ancora bravo, Hector!"


translate italian turnsecond_ebe96f90_1:


    hec "Nessuna brutta sconfitta... Nessuna brutta sconfitta..."


translate italian turnsecond_65c54f8c_1:


    emerick "Dai! Vogliamo il river!"


translate italian turnsecond_25e4f758_1:


    sofia "Ecco il river..."


translate italian turnsecond_9a610ffe_1:


    sofia "Dieci di picche..."


translate italian turnsecond_ff4ed839_1:


    emerick "BOOM!!!" with vpunch


translate italian turnsecond_58145255_1:


    emerick "Dritto, tesoro!" with hpunch


translate italian turnsecond_cfed94d4_1:


    hec "Accidenti..."


translate italian turnsecond_7426dcb3_1:


    emerick "Oh andiamo Hector, non è poi così male!"


translate italian turnsecond_9a3c3b3d_1:


    hec "Vai all'inferno!"


translate italian turnsecond_a21e69bd:


    emerick "Ahah! Andiamo avanti!"


translate italian riversecond_5b45644b:


    emerick "Bene ragazzi, siete tutti e due all-in... Mostrate le vostre mani!"


translate italian riversecond_1d55aa40:


    hec "Serie di 9!"


translate italian riversecond_09efb43f:


    d "Poker d'Assi!"


translate italian riversecond_c2596d04:


    emerick "O si!"


translate italian riversecond_8b385b22:


    emerick "Non male... ho Re-Jack..."


translate italian riversecond_9eeb175e:


    emerick "Sei ancora bravo, Hector!"


translate italian riversecond_ebe96f90:


    hec "Nessuna brutta sconfitta... Nessuna brutta sconfitta..."


translate italian riversecond_08723f2a:


    dpense "mi serve un asso..."


translate italian riversecond_65c54f8c:


    emerick "Dai! Vogliamo il river!"


translate italian riversecond_25e4f758:


    sofia "Ecco il river..."


translate italian riversecond_9a610ffe:


    sofia "Dieci di picche..."


translate italian riversecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate italian riversecond_58145255:


    emerick "Dritto, tesoro!" with hpunch


translate italian riversecond_cfed94d4:


    hec "Accidenti..."


translate italian riversecond_7426dcb3:


    emerick "Oh andiamo Ettore, non è poi così male!"


translate italian riversecond_9a3c3b3d:


    hec "Vai all'inferno!"


translate italian riversecond_78561908:


    emerick "E grazie per essere venuto, francesino! Grazie per i tuoi soldi!"


translate italian riversecond_25e4f758_1:


    sofia "Ecco il river..."


translate italian riversecond_9a610ffe_1:


    sofia "Dieci di picche..."


translate italian riversecond_29aafa4e:


    emerick "Scommetto 100!"


translate italian riversecond_d4af3017:


    d "Ci sto..."


translate italian riversecond_bdc68931:


    d "Tutto dentro!"


translate italian riversecond_bdc68931_1:


    d "Tutto dentro!"


translate italian riversecond_5449efcb:


    d "Io rilancio!"


translate italian riversecond_9cff1cb6:


    emerick "Ci sto!"


translate italian riversecond_7404b6d9:


    d "Lascio..."


translate italian riversecond_f7de9063:


    emerick "Bene, Hector è all in... Mostra la tua mano!"


translate italian riversecond_1d55aa40_1:


    hec "Serie di 9!"


translate italian riversecond_c2596d04_1:


    emerick "O si!"


translate italian riversecond_a405345e:


    emerick "Non male... Ma..."


translate italian riversecond_ff4ed839_1:


    emerick "BOOM!!!" with vpunch


translate italian riversecond_58145255_1:


    emerick "Dritto, tesoro!" with hpunch


translate italian riversecond_cfed94d4_1:


    hec "Accidenti..."


translate italian riversecond_7426dcb3_1:


    emerick "Oh andiamo Hector, non è poi così male!"


translate italian riversecond_9a3c3b3d_1:


    hec "Vai all'inferno!"


translate italian riversecond_a21e69bd:


    emerick "Ahah! Andiamo avanti!"


translate italian finalsecond_f7de9063:


    emerick "Bene, Hector è all in... Mostra la tua mano!"


translate italian finalsecond_1d55aa40:


    hec "Serie di 9!"


translate italian finalsecond_c2596d04:


    emerick "O si!"


translate italian finalsecond_a405345e:


    emerick "Non male... Ma..."


translate italian finalsecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate italian finalsecond_58145255:


    emerick "Dritto, tesoro!" with hpunch


translate italian finalsecond_cfed94d4:


    hec "Accidenti..."


translate italian finalsecond_7426dcb3:


    emerick "Oh andiamo Hector, non è poi così male!"


translate italian finalsecond_9a3c3b3d:


    hec "Vai all'inferno!"


translate italian finalsecond_78561908:


    emerick "E grazie per essere venuto, francesino! Grazie per i tuoi soldi!"


translate italian finalsecond_a21e69bd:


    emerick "Ahah! Andiamo avanti!"


translate italian twistersequence_b12cdd7a:


    ruby "Va bene, cominciamo!"


translate italian twistersequence_a255f487:


    ruby "Chi vuole giocare?"


translate italian twistersequence_605daa46:


    kira "Sono dentro!"


translate italian twistersequence_207bcd32:


    s "Anche io!"


translate italian twistersequence_70936eb4:


    ruby "Va bene! Steven, Kira...."


translate italian twistersequence_b5432fd9:


    ruby "[name] ?"


translate italian twister1_854f7ed7:


    mad "Oh, andiamo, conta anche su di me!"


translate italian twister1_dc165b3b:


    ruby "Grande!"


translate italian twister1_738560b4:


    ruby "Quindi sarò io a girare la ruota!"


translate italian twister1_705961f2:


    ruby "E quando qualcuno cade, viene eliminato e perde!"


translate italian twister1_58455e31:


    dpense "Spero che non esageri con queste penitenze..."


translate italian twister1_3afbfedb:


    dpense "Il corpo atletico di Madison e quel seno impressionante saranno sicuramente una distrazione..."


translate italian twister1_8867adec:


    dpense "E Kira... quella figura snella con un sedere così rotondo e perfetto. Sarà interessante"


translate italian twister1_b12cdd7a:


    ruby "Va bene, cominciamo!"


translate italian twister1_1adf77ff:


    ruby "Primo giro... Mano destra rossa!" with hpunch


translate italian twister1_122f3e71:


    kira "Abbastanza facile."


translate italian twister1_b8a9c191:


    s "Fatto."


translate italian twister1_e3c1a095:


    d "Va bene, eccoci qui."


translate italian twister1_6a6f3496:


    mad "Un gioco da ragazzi!"


translate italian twister1_aeac2c84:


    ruby "Prossimo giro... Piede sinistro verde!" with hpunch


translate italian twister1_c1382146:


    kira "Mi sto allungando un po' adesso."


translate italian twister1_4201ad80:


    s "Non male."


translate italian twister1_55b0f2bb:


    d "Posso gestirlo."


translate italian twister1_354fbd29:


    mad "Mi sento bene finora!"


translate italian twister1_fd2ab163:


    dpense "Il tratto di Madison mostra la sua corporatura atletica. E' davvero in forma."


translate italian twister1_12ecdece:


    dpense "I movimenti di Kira accentuano le sue curve. Quel culo è un'altra cosa."


translate italian twister1_16e4c677:


    ruby "Piede destro azzurro!" with hpunch


translate italian twister1_759345ef:


    kira "Diventa complicato."


translate italian twister1_ba2f3a28:


    s "Whoa, ho quasi perso l'equilibrio!"


translate italian twister1_9ac46c0a:


    d "Attento, Steven!"


translate italian twister1_37961fdb:


    mad "Sto bene, sto bene."


translate italian twister1_ff6edbf5:


    ruby "Mano sinistra gialla!" with hpunch


translate italian twister1_d8dca636:


    kira "Ok, è dura."


translate italian twister1_a0d6dc23:


    s "Sto scivolando!"


translate italian twister1_830b4098:


    d "Aspetta, Steven!"


translate italian twister1_310bd1e1:


    mad "Concentrati, Steven!"


translate italian twister1_9dcbc0e8:


    ruby "Steven, sei fuori!"


translate italian twister1_dcd39989:


    s "Accidenti!"


translate italian twister1_6e17f083:


    ruby "Hai perso! Devi correre per casa in mutande."


translate italian twister1_86063441:


    s "Sul serio?"


translate italian twister1_3239e163:


    s "Va bene, una scommessa è una scommessa."


translate italian twister1_0c843431:


    s "Tornerò presto!"


translate italian twister1_ee4baf21:


    "ride"


translate italian twister1_b7b6e9ac:


    ruby "Va bene, andiamo avanti!"


translate italian twister1_65aec8b5:


    ruby "Restano tre giocatori!"


translate italian twister1_d897c9d7:


    ruby "Prossimo giro... Mano destra verde!" with hpunch


translate italian twister1_5986ca7c:


    kira "Fatto."


translate italian twister1_5b657902:


    d "Abbastanza facile."


translate italian twister1_76175d7e:


    mad "Ancora in gioco."


translate italian twister1_f8247d44:


    dpense "La resistenza di Madison è impressionante. Ha un aspetto fantastico."


translate italian twister1_d229fb74:


    dpense "La concentrazione di Kira è ammirevole e la sua figura è sbalorditiva."


translate italian twister1_43358402:


    ruby "Piede sinistro rosso!" with hpunch


translate italian twister1_bd6057c8:


    kira "L'ho quasi perso lì!"


translate italian twister1_5d3a4772:


    d "Attento!"


translate italian twister1_3efe91a9:


    mad "Ancora stabile."


translate italian twister1_87f0e3b4:


    ruby "Piede destro giallo!" with hpunch


translate italian twister1_818e5609:


    kira "Sento la tensione."


translate italian twister1_4dd5f4c3:


    d "Ancora un po'."


translate italian twister1_1b2e41c7:


    mad "Ci penso io."


translate italian twister1_8feb4af2:


    dpense "La determinazione di Madison è chiara."


translate italian twister1_2e19129d:


    ruby "Kira, sei fuori!"


translate italian twister1_c4fb4f4c:


    kira "Oh beh, è ​​stato divertente finché è durato."


translate italian twister1_1a37fe6d:


    ruby "Kira, la tua penalità è..."


translate italian twister1_d2a489e9:


    ruby "Devi baciare chiunque tu voglia!"


translate italian twister1_f9115114:


    kira "Uhm, interessante..."


translate italian twister1_7a77e836:


    kira "Va bene, scelgo [name]!"


translate italian twister1_d9649ae4:


    mad "Davvero, Kira?"


translate italian twister1_71db9840:


    mad "Dovevi semplicemente scegliere [name], vero?"


translate italian twister1_99102486:


    kira "Perché? Gelosa?"


translate italian twister1_d9d3c314:


    mad "Io? NO!"


translate italian twister1_b38549e6:


    mad "Fai quello che vuoi..."


translate italian twister1_42fe5f0e:


    dpense "Questo bacio è qualcosa..."


translate italian twister1_5c6118f1:


    dpense "ma la reazione di Madison è ancora più intrigante."


translate italian twister1_26fbc773:


    ruby "Ok, andiamo avanti! Sono rimasti due giocatori... [name] e Madison!"


translate italian twister1_c95a5382:


    ruby "Complicheremo le cose!"


translate italian twister1_f5469193:


    ruby "Prossimo giro... Entrambe le mani blu!" with hpunch


translate italian twister1_7959b43b:


    mad "Allungamento..."


translate italian twister1_610f5201:


    d "Quasi lì..."


translate italian twister1_3ff0b1af:


    dpense "Il tratto di Madison mette in mostra il suo fisico impressionante. È così vicina che riesco a sentire il calore del suo corpo."


translate italian twister1_59bb579b:


    ruby "Piede destro verde!" with hpunch


translate italian twister1_0fbf0d2a:


    mad "Chiudi uno!"


translate italian twister1_2ea85ac8:


    d "Ancora un po'..."


translate italian twister1_8e5eb314:


    dpense "I nostri corpi si avvicinano, la tensione è palpabile."


translate italian twister1_a0fb982d:


    ruby "Piede sinistro giallo!" with hpunch


translate italian twister1_a637c946:


    mad "Tengo duro..."


translate italian twister1_b14c35cd:


    d "L'ho quasi perso lì!"


translate italian twister1_8d6b1f6e:


    dpense "Il corpo di Madison preme contro il mio, le sue curve sono impossibili da ignorare."


translate italian twister1_17b1529b:


    ruby "Ok, sarà più difficile!"


translate italian twister1_8e509e5b:


    ruby "Entrambe le mani blu! Ma non è la stessa cosa!" with hpunch


translate italian twister1_85c61c22:


    mad "La cosa sta diventando intensa!"


translate italian twister1_f153692d:


    d "Parlamene..."


translate italian twister1_7d81ee16:


    dpense "Siamo così vicini... posso sentire il suo respiro sulla mia pelle..."


translate italian twister1_61a8520a:


    dpense "Il suo corpo è premuto contro il mio e non posso fare a meno di notare quanto sia morbida."


translate italian twister1_462c5f1d:


    dpense "I nostri volti sono a pochi centimetri di distanza e posso vedere la scintilla nei suoi occhi. Questo gioco sta diventando più intenso di quanto mi aspettassi."


translate italian twister1_dc8bad59:


    mad "Sembra che siamo solo io e te..."


translate italian twister1_5b62eedd:


    d "Già... Questo è... interessante."


translate italian twister1_8de7275b:


    dpense "Il suo corpo è praticamente modellato sul mio, la tensione è elettrica."


translate italian twister1_74637e05:


    ruby "Madison, sei fuori! [name], hai vinto!"


translate italian twister1_26e90d0a:


    mad "Dannazione, c'è mancato poco."


translate italian twister1_36cd59a5:


    d "Bella partita, Madison."


translate italian twister1_9021a01e:


    ruby "Va bene, [name], sei tu il campione di Twister!"


translate italian twister1_283935f2:


    mad "Immagino che prenderò la mia penalità adesso."


translate italian twister1_9a10d66c:


    ruby "Madison, la tua penalità è... hmm... quale dovrebbe essere?"


translate italian twister1_16fcf0c7:


    dpense "Vediamo cosa le viene in mente..."


translate italian twister1_562e58ec:


    ruby "Che ne dici... devi baciare anche [name]?"


translate italian twister1_0b8cbe55:


    mad "Oh, è facile."


translate italian twister1_e9f9d80b:


    ruby "No, non solo un bacio. Un vero bacio."


translate italian twister1_224206c9:


    mad "Oh, intendi così?"


translate italian twister1_9be3f4e8:


    mad "Vieni qui, [name]."


translate italian twister1_ae94e9b1:


    dpense "Wow, ce la fa davvero... riesco a sentire ogni centimetro del suo corpo contro il mio. Questo è intenso."


translate italian twister1_51930a95:


    mad "Bene allora."


translate italian twister1_ca820d31:


    dpense "Le sue labbra sono così morbide... È bello, ma non posso fare a meno di chiedermi se potrebbe essere di più."


translate italian twister1_9b7b30a4:


    ruby "Bene. Steven dovrebbe tornare da un momento all'altro."


translate italian twister1_2fd3cfa8:


    dpense "Lo sguardo di Madison indugia su di me e non posso fare a meno di chiedermi a cosa stia pensando."

translate italian strings:


    old "9:00 PM"
    new "09:00"


    old "Go play Poker"
    new "Vai a giocare a poker"


    old "Go play Twister"
    new "Vai a giocare a Twister"


    old "I need a refresher"
    new "Ho bisogno di un ripasso"


    old "No, I'm good"
    new "No, sto bene"


    old "Bet[TEMP1!t]"
    new "Scommetti[TEMP1!t]"


    old "Fold[TEMP2!t]"
    new "Lascia[TEMP2!t]"


    old "Bet"
    new "Punta"


    old "Call"
    new "Ci sto"


    old "A few hands later..."
    new "Qualche mano dopo..."


    old "Raise"
    new "Rilancio"


    old "Yeah, I'm in[TEMP1!t]"
    new "Sì, ci sto[TEMP1!t]"


    old "No, thanks"
    new "No grazie"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
