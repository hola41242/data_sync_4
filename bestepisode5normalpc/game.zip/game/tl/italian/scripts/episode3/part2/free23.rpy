


translate italian poker23_3e30ce77:


    mac "Accidenti, questo è impossibile!" with vpunch


translate italian poker23_f8e333c6:


    emerick "Ahah!"


translate italian poker23_1f8b3bf4:


    mac "Ho di nuovo perso con gli assi!"


translate italian poker23_5b43b033:


    mac "Smetterò di giocarci!"


translate italian poker23_46928cb5:


    emerick "Questo è il gioco!"


translate italian poker23_1f88ae2d:


    mac "Sì sì... è una schifezza!"


translate italian poker23_1bd62c92:


    emerick "Siamo solo noi due adesso, Frenchie!"


translate italian poker23_ff6a1930:


    dpense "Sono riuscito a guadagnare fino a $2000 nelle poche mani che ho giocato..."


translate italian poker23_253a69ef:


    emerick "Va bene, è un avvertimento!"


translate italian poker23_3acfb082:


    beth "È il tuo turno di parlare [name]."


translate italian poker23_96927053:


    d "Io ci sto."


translate italian poker23_d89911e1:


    emerick "Hmm..."


translate italian poker23_1594e8a3:


    emerick "Io rilancio."


translate italian poker23_dc181045:


    d "Ci sto."


translate italian poker23_cbfb1f43:


    beth "Il board..."


translate italian poker23_e394760b:


    beth "Asso di cuori, Dieci di picche, Re di picche."


translate italian poker23_61e98f59:


    d "Scommetto 100."


translate italian poker23_1594e8a3_1:


    emerick "Io rilancio."


translate italian poker23_e48c9cb0:


    d "Hmm..."


translate italian poker23_dc181045_1:


    d "Vedo."


translate italian poker23_1ca60585:


    beth "Il Turn..."


translate italian poker23_4e0f3456:


    beth "Asso di picche."


translate italian poker23_e48c9cb0_1:


    d "Hmm..."


translate italian poker23_0c16dfff:


    dpense "Kira mi ha detto di giocare sulla sua fiducia..."


translate italian poker23_7266d996:


    dpense "Come lo faccio?"


translate italian poker23_907fdef1:


    emerick "Allora, hai deciso?"


translate italian poker23_1fc32aee:


    emerick "Non hai intenzione di lasciare, vero?"


translate italian poker23_cddf2c53:


    dpense "Sembra molto fiducioso..."


translate italian poker23_5e4910c9:


    d "Non riesco a ricordare..."


translate italian poker23_0ce9fdf0:


    d "Un colore è meglio di una scala, giusto?"


translate italian poker23_f8e333c6_1:


    emerick "Ahah!"


translate italian poker23_1592616c:


    emerick "SÌ!"


translate italian poker23_242b94d5:


    emerick "Hai l'uno o l'altro?"


translate italian poker23_d5ee268c:


    d "No, no, volevo solo sapere..."


translate italian poker23_d89911e1_1:


    emerick "Hmm..."


translate italian poker23_6e8a688e:


    emerick "Ascolta, Frenchie, non passeremo tutta la notte qui."


translate italian poker23_7426abd6:


    emerick "Quindi propongo qualcosa!"


translate italian poker23_c31b56fc:


    emerick "Andiamo all in e vediamo chi vince!"


translate italian poker23_ec7e4047:


    emerick "Che ne dici?"


translate italian poker23_13bcf77c:


    emerick "Quanto hai? 2000?"


translate italian poker23_fc6dea88:


    d "Sì..."


translate italian poker23_5bd579fe:


    emerick "Va bene, ho messo 2000 e basta."


translate italian poker23_f338cc08:


    d "Ehm..."


translate italian poker23_7bcc50f4:


    d "Va bene..."


translate italian poker23_d4af3017:


    d "Vedo..."


translate italian poker23_1b8051aa:


    emerick "Sai perché te lo propongo?"


translate italian poker23_76a68131:


    d "Perché sei sicuro di vincere?"


translate italian poker23_e39b1be7:


    emerick "Ovviamente!"


translate italian poker23_ba32e80a:


    d "Perché ti fidi di te stesso e del tuo gioco?"


translate italian poker23_e8143a9b:


    emerick "Ahah! Sempre!"


translate italian poker23_4e56fdd8:


    d "Perché sei pazzo?"


translate italian poker23_610444ad:


    emerick "Devi esserlo un po', vero?"


translate italian poker23_dbb2bc0c:


    emerick "Ma no... è perché so che vincerò!"


translate italian poker23_0a541187:


    emerick "Bene! Il river, Beth!"


translate italian poker23_5b38b6ff:


    beth "Il river..."


translate italian poker23_af61be04:


    beth "Il due di cuori..."


translate italian poker23_6faa39e5:


    beth "Mostrate le vostre carte, signori!"


translate italian poker23_f9d65ba9:


    emerick "Quattro uguali, tesoro!" with vpunch


translate italian poker23_7e7fc3d4:


    d "Oh!!! Quattro di un tipo...."


translate italian poker23_765965dc:


    d "Un poker è raro..."


translate italian poker23_e5f13971:


    emerick "Sì amico!"


translate italian poker23_03c37d01:


    emerick "Bel tentativo comunque!"


translate italian poker23_fb6205e3:


    d "Wow, è pazzesco..."


translate italian poker23_c154fd55:


    d "Pensavo avessi solo un asso..."


translate italian poker23_a5265cf0:


    d "Ok... Forse una casa piena..."


translate italian poker23_78ff97d6:


    emerick "Ahah, so come si gioca!"


translate italian poker23_b2842d1b:


    d "SÌ..."


translate italian poker23_96d96279:


    d "Bella mano comunque..."


translate italian poker23_01a6c5e7:


    d "Sai perché ti ho chiesto se un colore era più forte di una scala?"


translate italian poker23_88c2931a:


    emerick "Ehm... no!"


translate italian poker23_8b0f7c01:


    d "Beh... perché avevo..."


translate italian poker23_8e217ed9:


    d "Entrambi..."


translate italian poker23_bcfc41d9:


    d "Scala colore reale!" with vpunch


translate italian poker23_d3a632b6:


    emerick "Cosa?" with hpunch


translate italian poker23_a5e63099:


    emerick "Ma stai scherzando?"


translate italian filles23_e63d14a0:


    hec "Dai. Era solo uno scherzo!"


translate italian filles23_6e377ba4:


    julia "Lasciami in pace, Hector."


translate italian filles23_13caae44:


    hec "Non fare la puritana. Sono sicuro che ci sarà un sacco di divertimento sotto quel vestito!"


translate italian filles23_99f1a7c0:


    julia "Ti avevo detto di lasciarmi in pace!"


translate italian filles23_6b599e1a:


    hec "Vi siete truccate, sarebbe un peccato se nessuno ne approfittasse!"


translate italian filles23_31b3aea6:


    hec "Dai, andiamo in un posto un po' più privato!"


translate italian filles23_99ce83cb:


    d "Penso che ti abbia detto di lasciarla in pace."


translate italian filles23_1a134164:


    hec "Accidenti, sei sempre qui!" with hpunch


translate italian filles23_848785e8:


    hec "Come una zanzara, amico!"


translate italian filles23_97292c7a:


    hec "Va bene, ti lascio con la tua principessa... Sembra comunque frigida."


translate italian filles23_f9c7f0b0:


    d "Stai bene?"


translate italian filles23_9da28c53:


    julia "Sì, sì... ci sono abituata. Non preoccuparti."


translate italian filles23_398d0cff:


    julia "Ma è gentile da parte tua. Grazie."


translate italian filles23_27970b90:


    julia "Per essere qui di nuovo per me..."


translate italian filles23_098db63e:


    d "Oh, non è niente. Non lo sopporto comunque."


translate italian filles23_b44e6db9:


    julia "Ahah! Neanche io posso sopportarlo."


translate italian filles23_4af33191:


    julia "EHI..."


translate italian filles23_fad03ada:


    d "?"


translate italian filles23_2817e51d:


    julia "Potrebbe sembrare strano ma..."


translate italian filles23_73e08839:


    julia "Verresti con me in ospedale domani?"


translate italian filles23_46f54ac1:


    d "Cosa intendi? Sei malata?"


translate italian filles23_b95b525d:


    julia "No. Voglio solo far visita a mia madre."


translate italian filles23_cb1ee412:


    julia "E mi farebbe davvero comodo qualcuno con me, considerando i risultati dei test..."


translate italian filles23_73af0f04:


    d "Non sono buoni?"


translate italian filles23_8f9c6f6d:


    julia "No. Niente affatto."


translate italian filles23_a90e9d4d:


    julia "Le restano solo pochi giorni..."


translate italian filles23_6e7e6c4f:


    julia "Ne ero venuta a patti, ma ora penso che sia la fine."


translate italian filles23_bf456521:


    d "Sarò lì con te."


translate italian filles23_8ffcb975:


    julia "Grazie [name]."


translate italian filles23_4e67cd6a:


    julia "Significa molto per me."


translate italian filles23_643ee3b5:


    d "Non esitare se hai bisogno di qualcosa."


translate italian filles23_bd82f144:


    julia "Non voglio approfitarne..."


translate italian filles23_0d2bd84b:


    d "A questo servono gli amici, no?"


translate italian filles23_66c7136d:


    d "Voglio dire, siamo amici?"


translate italian filles23_60d8c678:


    julia "Siamo amici!"


translate italian filles23_9f9dba11:


    julia "Anche se non sono sicuro che un amico gli afferri il sedere il primo giorno che si incontrano..."


translate italian filles23_bfbf1c07:


    d "OH! Ehm..."


translate italian filles23_260e8d1d:


    julia "ahah ti sto prendendo in giro..."


translate italian filles23_29065e5a:


    d "Beh, a dire il vero, è carino."


translate italian filles23_f14e0ae3:


    julia "Ahah, lo so! Puoi guardare ma non puoi toccare"


translate italian filles23_ff49f6fb:


    d "Quindi, come amici, godiamoci il resto della serata!"


translate italian filles23_7eabd694:


    julia "Hai ragione. Non resterò ancora a lungo comunque."


translate italian filles23_b4b50c32:


    d "Andiamo!"


translate italian filles23_c1d6711f:


    ruby "Non ho mai... Uhm..."


translate italian filles23_fcbdc5b7:


    ruby "Comprato un giocattolo erotico!"


translate italian filles23_b4c311d4:


    kira "Puoi dire un dildo, lo sai!"


translate italian filles23_6b94590f:


    ruby "Ehm..."


translate italian filles23_0352a573:


    mad "Lascia che dica quello che vuole, Kira!"


translate italian filles23_05c46b86:


    mad "Ha il suo mondo con tutte le sue cose carine!"


translate italian filles23_be415281:


    kira "E mi dirai che tra tutti i tuoi peluche non hai un coniglietto contro cui strofinarti di tanto in tanto?"


translate italian filles23_a21ad27d:


    ruby "Ehm... No..."


translate italian filles23_2705baee:


    kira "Non so come fate voi ragazze, ma se di tanto in tanto non provo un po' di piacere, divento aggressiva!"


translate italian filles23_03785299:


    kira "A proposito, ho comprato uno di quei giocattoli... Dovresti vedere la cosa..."


translate italian filles23_d9ad2417:


    grace "Che cosa sembra?"


translate italian filles23_646ef5b5:


    mad "Grace?"


translate italian filles23_0c9d4e4e:


    grace "Che cosa? Sono solo curiosa!"


translate italian filles23_745587fa:


    kira "Ahah! È lungo, grosso e a coste..."


translate italian filles23_cf7d2902:


    kira "Non l'ho ancora testato, ma ne ho sentito parlare bene, quindi... Vedremo..."


translate italian filles23_0c6f12cb:


    kira "E tu, Madison? Qual è il tuo preferito?"


translate italian filles23_7fa17ae4:


    kira "Posso vederti con una paperella vibrante nella tua vasca da bagno!"


translate italian filles23_e57728f4:


    mad "Per far giocare mia figlia? No grazie!"


translate italian filles23_c308f921:


    mad "E non sono affari tuoi!"


translate italian filles23_fe8120c9:


    kira "Eccoci qua... Madison Forrester interpreta la puritana!"


translate italian filles23_4bd272c9:


    mad "Non sono un puritana!"


translate italian filles23_29ccd7f5:


    kira "Sì, Sì..."


translate italian filles23_d721fb2f:


    d "Di cosa state parlando qui?"


translate italian filles23_bcdd5352:


    ruby "Giocattoli!"


translate italian filles23_19dc7043:


    mad "Roba intima..."


translate italian filles23_0a7a132b:


    kira "Dildo e toccarsi!"


translate italian filles23_52720f61:


    d "Ahi... Ok..."


translate italian filles23_541a9a65:


    grace "Per i ragazzi è più semplice, suppongo..."


translate italian filles23_bec902dc:


    d "Come mai?"


translate italian filles23_81c99eed:


    grace "Beh, quando ne hai voglia, puoi facilmente provare piacere, giusto? È piuttosto veloce..."


translate italian filles23_10ab5d15:


    d "Ehm... penso che, come le ragazze, dipenda dalla persona... E abbiamo comunque bisogno di essere stimolati!"


translate italian filles23_129b6de5:


    kira "Oh, sicuramente... E sapevi che sia gli uomini che le donne possono essere sia visivi, uditivi o tattili a seconda della situazione?"


translate italian filles23_584173a2:


    ruby "Cosa intendi?"


translate italian filles23_b4384300:


    kira "Fondamentalmente... I ragazzi spesso reagiscono rapidamente agli stimoli visivi, come la vista del tuo corpo."


translate italian filles23_72c860a3:


    kira "Per molte donne, i suoni, le parole e persino certi tipi di tocco possono essere più eccitanti."


translate italian filles23_564c078d:


    ruby "Ah! Allora come funziona?"


translate italian filles23_07a91765:


    kira "Te lo lascio scoprire! È importante sapere cosa ti eccita e comunicarlo al tuo partner."


translate italian filles23_104a8c12:


    grace "Come fai a sapere tutto questo, Kira?"


translate italian filles23_fea58b2c:


    kira "Beh... sperimento e faccio le mie ricerche. C'è così tanto da imparare sui nostri corpi e sulla sessualità."


translate italian filles23_a728e041:


    kira "Le persone possono essere così puritane. Trovano il sesso così tabù che sono imbarazzati ad accettare il proprio corpo e la propria sessualità."


translate italian filles23_ffa5c37b:


    kira "Ma è del tutto naturale e salutare esplorarlo."


translate italian filles23_66374259:


    grace "Ti invidio..."


translate italian filles23_8dc09e6e:


    kira "Se posso darti un consiglio..."


translate italian filles23_0d3bc963:


    kira "Quando sei pronta per esplorare quella parte di te stessa con qualcuno, assicurati di indossare la tua lingerie migliore, lasciati andare e goditi il ​​momento con la persona che hai scelto."


translate italian filles23_76869d69:


    kira "In questo modo non avrai rimpianti!"


translate italian filles23_0adef93a:


    grace "Ehm... va bene..."

translate italian strings:


    old "11:00 PM"
    new "ORE 11:00"


    old "Because you're sure you'll win?"
    new "Perché sei sicuro di vincere?"


    old "Because you trust yourself?"
    new "Perché ti fidi di te stesso?"


    old "Because you're crazy?"
    new "Perché sei pazzo?"






translate italian filles23_0ea9962d:


    d "Beh, ad essere onesti, è carino."


translate italian filles23_208dc12d:


    mad "Grace?" with hpunch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
