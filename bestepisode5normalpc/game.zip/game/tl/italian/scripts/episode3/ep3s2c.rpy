


translate italian ep3s2c_fa64e7e4:


    d "Buongiorno, signora Drew."


translate italian ep3s2c_2f405874:


    drew "OH! [name]! Mi hai davvero colta di sorpresa."


translate italian ep3s2c_e40f222b:


    drew "Cosa ti porta qui?"


translate italian ep3s2c_30793e1a:


    d "Sono venuto a trovare Grace."


translate italian ep3s2c_eb73b104:


    drew "Sta finendo di prepararsi; scende subito."


translate italian ep3s2c_505dea50:


    drew "Sembra che voi due siate diventati molto intimi ultimamente..."


translate italian ep3s2c_c31186bc:


    d "Sì, passiamo molto tempo insieme."


translate italian ep3s2c_6dac8fb4:


    drew "Non preoccuparti, lo trovo piuttosto tenero."


translate italian ep3s2c_bf615426:


    drew "Tienila vicina. Portala lontano in questa competizione."


translate italian ep3s2c_019d7b3d:


    d "Concordo"


translate italian ep3s2c_0697ca82:


    drew "Ho guardato, lo sai. E devo dire che sono piuttosto impressionata."


translate italian ep3s2c_3deed7ed:


    d "Veramente?"


translate italian ep3s2c_03f5de77:


    drew "Sì, spero sinceramente che ci riuscirete entrambi."


translate italian ep3s2c_74782c19:


    drew "Anche se ti tengo d'occhio."


translate italian ep3s2c_8407fa45:


    drew "Per ora, mi accontento che tu esca con mia figlia."


translate italian ep3s2c_eee464d8:


    drew "Ma ricorda, deve vincere."


translate italian ep3s2c_ae5eb82d:


    d "E io?"


translate italian ep3s2c_fe8d23fa:


    drew "Beh, dovreste vincere insieme."


translate italian ep3s2c_169b9f75:


    drew "So come mostrare gratitudine. Più andrai lontano, maggiori saranno le tue ricompense."


translate italian ep3s2c_54957448:


    d "Premi?"


translate italian ep3s2c_e014bf88:


    drew "Per ora, la tua ricompensa è vedere mia figlia ogni volta che lo desideri."


translate italian ep3s2c_7eb0d926:


    drew "Ma sappi che hai catturato più occhi oltre ai suoi..."


translate italian ep3s2c_f1b55811:


    drew "Ora vai, sta aspettando. E non fare tardi."


translate italian ep3s2c_06c2d188:


    d "Inteso."


translate italian ep3s2c_2c7fb1a0:


    drew "Oh, e prima di andare... La prima risposta è Gizeh..."


translate italian ep3s2c_94518b14:


    dpense "Che cosa significa?"


translate italian ep3s2c_d05736e9:


    drew "Lo capirai quando sarà il momento."


translate italian ep3s2c_30bbb352:


    drew "Consideralo un piccolo bonus."


translate italian ep3s2c_06c2d188_1:


    d "Inteso."


translate italian ep3s2c_8bd88703:


    dpense "Cosa intendeva con questo?"


translate italian ep3s2c_d981fc7b:


    dpense "Strano…"


translate italian ep3s2c_50b572ee:


    dpense "Bene, andiamo nella stanza di Grace..."


translate italian ep3s2c_b6805db4:


    grace "Oh, [name]."


translate italian ep3s2c_627b921c:


    d "Spero di non interrompere?"


translate italian ep3s2c_ca4039c3:


    grace "Niente affatto, stavo appena finendo di prepararmi."


translate italian ep3s2c_9b902222:


    d "Sei stupenda."


translate italian ep3s2c_8390f9cc:


    grace "Smettila, mi fai arrossire."


translate italian ep3s2c_9a8a1bb6:


    d "Posso baciarti?"


translate italian ep3s2c_a9bed95f:


    grace "Forse? È praticamente d'obbligo!"


translate italian ep3s2c_495bb525:


    d "Sembra che tua madre ci abbia dato la sua benedizione."


translate italian ep3s2c_98ebbfd9:


    grace "Veramente? Cosa ha detto esattamente?"


translate italian ep3s2c_a70b9367:


    d "Ha notato che passiamo molto tempo insieme e..."


translate italian ep3s2c_4f14570b:


    grace "In realtà volevo parlarti di questo."


translate italian ep3s2c_01edd90d:


    grace "Ascolta, mentre siamo in questa competizione, manteniamolo il nostro piccolo segreto."


translate italian ep3s2c_e3b20b7b:


    d "Perché?"


translate italian ep3s2c_dffb0ec1:


    grace "Tutto qui può essere usato contro di noi."


translate italian ep3s2c_5703408b:


    grace "E stasera... Dopo la festa, avremo tutto il tempo per..."


translate italian ep3s2c_4dd2a10c:


    grace "Ahhh! Adoro quando le tue mani mi sfiorano."


translate italian ep3s2c_eb3879c2:


    d "E adoro la sensazione della tua pelle."


translate italian ep3s2c_31c40958:


    grace "Ah..."


translate italian ep3s2c_5c868772:


    grace "Uhmmm..."


translate italian ep3s2c_7126ab4d:


    grace "Fermati, o non riuscirò a trattenermi."


translate italian ep3s2c_27faf88b:


    grace "Stasera…"


translate italian ep3s2c_433869b9:


    d "Sei pronta per stasera?"


translate italian ep3s2c_499297e6:


    grace "A dire il vero, stiamo andando a lezione adesso, e poi incontrerò Ruby. Passiamo il pomeriggio a preparare tutto."


translate italian ep3s2c_7dd8afa4:


    grace "Ha pianificato tutto!"


translate italian ep3s2c_60371a03:


    d "Oh veramente? Allora non verrò a disturbarti!"


translate italian ep3s2c_4082c591:


    grace "Meglio di no."


translate italian ep3s2c_97610549:


    grace "Soprattutto con Ruby. Se ti metti sulla sua strada, sei nei guai."


translate italian ep3s2c_2c0572e7:


    d "Pronto? Da Ruby?"


translate italian ep3s2c_44e82c85:


    grace "Oh sì, quando è concentrata è meglio non disturbarla."


translate italian ep3s2c_eee5a2a8:


    d "Inteso. Allora, a che ora dovrei arrivare?"


translate italian ep3s2c_36b419b1:


    grace "In realtà la festa inizia alle 21:00, ma puoi venire alle 20:00 per prepararti."


translate italian ep3s2c_26b2a481:


    d "Per me va bene."


translate italian ep3s2c_c349746e:


    grace "E non dimenticare che il tema di stasera è chic e shock."


translate italian ep3s2c_ed1501d9:


    d "Sì, non sono ancora sicuro di cosa indossare. Non so nemmeno come mi vestirò."


translate italian ep3s2c_ba22db80:


    grace "Da quello che ho capito, Ruby ha accennato al fatto che lei avrebbe un abito... che Red dovrebbe portare con sé."


translate italian ep3s2c_ec5e29a1:


    grace "In caso contrario, ne ho un altro. Era di mio padre, quindi non preoccuparti, è tutto organizzato."


translate italian ep3s2c_1d7c521b:


    grace "Comunque, Ruby ha una lista di riserva nel caso qualcosa vada storto."


translate italian ep3s2c_935db071:


    grace "E ha anche un backup per la sua lista di backup..."


translate italian ep3s2c_06c2d188_2:


    d "Inteso."


translate italian ep3s2c_c5790358:


    grace "Scendi... sarò pronto tra due minuti."


translate italian ep3s2c_bfde5076:


    d "Wow... sei bellissima."


translate italian ep3s2c_4f3d4452:


    grace "Anche tu non sei poi così male!"


translate italian ep3s2c_4e193a9e:


    grace "Andiamo, non dovremmo fare tardi."


translate italian ep3s2c_ffe847fc:


    grace "Andiamo!"


translate italian ep3s2c_b4b50c32:


    d "Andiamo!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
