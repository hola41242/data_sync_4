


translate italian coming3_17342d50:


    "La mano destra su quella verde!"


translate italian coming3_4c61430b:


    "Ci sto!"


translate italian coming3_7a16ee9c:


    grace "Sei l'unica persona che voglio stasera..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
