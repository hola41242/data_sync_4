


translate italian Training2_2314b734:


    dpense "Piantare il piede nella terra..."


translate italian Training2_6a4e888c:


    dpense "Se voglio segnare, devo metterci più forza..."


translate italian Training2_dbd94726:


    ji "EHI!" with vpunch


translate italian Training2_62e760ef:


    ji "Se hai intenzione di vincere, devi impegnarti di più, eh!"


translate italian Training2_f7499b79:


    ji "Passami la palla!"


translate italian Training2_cba91d2b:


    ji "Guarda questo!"


translate italian Training2_43398bf1:


    d "Cosa..."


translate italian Training2_0144d7f9:


    d "Ehm?"


translate italian Training2_d83c8599:


    d "Ma..."


translate italian Training2_62ecd993:


    d "Chi sei ?"


translate italian Training2_c2e66dfd:


    ji "Sapere chi sono non ti aiuterà affatto."


translate italian Training2_5e4b894c:


    ji "Continua ad allenarti perché non vedo davvero l'ora di affrontarti."


translate italian Training2_8926922d:


    ji "Ci vediamo in finale..."


translate italian Training2_9d7f15ed:


    ji "Se arrivi così lontano."


translate italian Training2_e8e8e63a:


    d "Va bene..."


translate italian Training2_7994d614:


    dpense "Avrò davvero bisogno di salire di livello..."


translate italian Training2_08535ece:


    dpense "Quella ragazza ha qualche possibilità..."


translate italian Training2_ce2cd1a5:


    dpense "Ho quasi sentito il vento girare intorno alla palla..."


translate italian Training2_86048621:


    dpense "Dai... torniamo al sodo!"


translate italian Chambreep3_7d909d2f:


    dpense "Uhm... che ore sono?"


translate italian Chambreep3_cb1c8beb:


    dpense "5:30 DI POMERIGGIO"


translate italian Chambreep3_2aa2e6be:


    dpense "Dovrei uscire presto."


translate italian Chambreep3_ed39d6a5:


    dpense "Forse dovrei mandare un messaggio a Elise prima che vada a letto..."


translate italian Chambreep3_37e64b70:


    dpense "..."


translate italian Chambreep3_6f5ea18e:


    dpense "Nessuna risposta?"


translate italian Chambreep3_5284f567:


    dpense "È strano... Di solito risponde entro tre secondi..."


translate italian Chambreep3_9c2712db:


    dpense "Qualcun altro ha bisogno di qualcosa?"


translate italian Chambreep3_68c57ca6:


    dpense "Ruby dev'essere occupata... non la disturberò..."


translate italian Chambreep3_0d47971e:


    dpense "A chi devo inviare un messaggio?"


translate italian gracephoneep3s4_7cd0dad9:


    dpense "Quelle labbra..."


translate italian gracephoneep3s4_40bf0c88:


    dpense "Beh, sembra che stiano bene..."


translate italian juliaphoneep3s4_bffc964b:


    dpense "Spero che starà bene stasera..."


translate italian madphoneep3s4_4c58dcba:


    dpense "Sono stupido, ha detto che era con sua figlia..."


translate italian madphoneep3s4_fda3813c:


    dpense "Deve essere impegnata spesso..."


translate italian madphoneep3s4_99f61674:


    dpense "Penso che dovrò cambiare il modo in cui mi approccio a lei..."


translate italian bluephoneep3s4_28c2d9c9:


    dpense "È davvero cambiata..."


translate italian bluephoneep3s4_02a7ab74:


    dpense "È accaduto qualcosa..."


translate italian gabyphoneep3s4_d5bafb7c:


    dpense "Beh... Almeno ho controllato!"


translate italian gabyphoneep3s4_6ba6c89d:


    dpense "Non devo però dimenticare l'appuntamento con lei domani..."


translate italian gabyphoneep3s4_f008a47b:


    dpense "Altrimenti mi ucciderà!"


translate italian departsoiree_bd5a3951:


    dpense "Ok andiamo!"


translate italian departsoiree_2a7b2a88:


    dpense "Charlotte mi ha chiesto di andare al negozio prima della festa..."


translate italian ArriveeFete_d10b0838:


    d "Ora... La festa!"


translate italian ArriveeFete_af385284:


    d "Cominciamo..."


translate italian Charlottetime_44050cec:


    dpense "È chiuso..."


translate italian Charlottetime_f423db45:


    dpense "Ma le luci sono accese..."


translate italian Charlottetime_37b557c2:


    dpense "Ha detto che aveva delle cose da contare, credo..."


translate italian Charlottetime_5df73d10:


    dpense "Forse c'è una porta sul retro?"


translate italian Charlottetime_8b1242bd:


    dpense "La porta sul retro..."


translate italian Charlottetime_a3d61da9:


    dpense "È aperta."


translate italian Charlottetime_017bee57:


    d "Quindi è qui che ti nascondi?"


translate italian Charlottetime_c3e5e858:


    cha "Eh?"


translate italian Charlottetime_641b24ec:


    cha "Ahhh!"


translate italian Charlottetime_b31d7873:


    d "Non preoccuparti! HO CAPITO QUESTO!... Ekhm, voglio dire, HO CAPITO TE!!"


translate italian Charlottetime_bfd3fd79:


    cha "OH?"


translate italian Charlottetime_99c90c60:


    cha "Mi hai spaventata!"


translate italian Charlottetime_c8863a0d:


    d "Scusa! Non era mia intenzione."


translate italian Charlottetime_fca708e0:


    cha "Ti senti a tuo agio lì?"


translate italian Charlottetime_2c3a63c7:


    d "Cosa intendi?"


translate italian Charlottetime_0ebfde79:


    cha "Puoi lasciare andare il mio seno, lo sai..."


translate italian Charlottetime_a2a9798e:


    d "OH! Sì scusa!"


translate italian Charlottetime_2e1075ac:


    cha "Aspetta, mentre sei qui, stringimi. Devo contare il retro dello scaffale."


translate italian Charlottetime_d93e0955:


    d "Uh... Sì, va bene."


translate italian Charlottetime_cfa70a59:


    cha "Tienimi stretta, ok!"


translate italian Charlottetime_b82983f4:


    d "Si si!"


translate italian Charlottetime_46359b02:


    dpense "Che culo..."


translate italian Charlottetime_3957d45a:


    dpense "Aspetta..."


translate italian Charlottetime_b4475d8b:


    dpense "Non indossa mutandine?" with hpunch


translate italian Charlottetime_e11f72be:


    dpense "L'ha fatto apposta, non può essere..."


translate italian Charlottetime_eafe9e61:


    cha "Aspetta, devo sporgermi un po' di più per vedere il retro."


translate italian Charlottetime_e9fcb1fb:


    dpense "Sei seria?"


translate italian Charlottetime_9b0004ac:


    dpense "Vuole giocare..."


translate italian Charlottetime_53e24e7b:


    dpense "Allora giochiamo!"


translate italian Charlottetime_bfd3fd79_1:


    cha "OH?"


translate italian Charlottetime_e7fc63f0:


    cha "Che diavolo...?"


translate italian Charlottetime_385ef974:


    cha "Ah!"


translate italian Charlottetime_98998053:


    cha "Uhm..."


translate italian Charlottetime_38e5071e:


    cha "Sì... Continua..."


translate italian Charlottetime_a1818eb0:


    cha "Sapevo che ti saresti goduto il panorama."


translate italian Charlottetime_215da4ac:


    cha "Pensavo che tu... Humpfff..."


translate italian Charlottetime_a6aeabed:


    cha "Sapessi come sfruttare la tua occasione... Haaa..."


translate italian Charlottetime_38954f7f:


    cha "Sei davvero bravo in questo... Ohhh!"


translate italian Charlottetime_11bbaae7:


    cha "SÌ! Proprio lì!"


translate italian Charlottetime_64c167b7:


    cha "Fallo! Mangia quella figa!"


translate italian Charlottetime_4cd519e2:


    cha "Oh mio Dio, è fantastico..."


translate italian Charlottetime_c4c6380f:


    dpense "È bagnata..."


translate italian Charlottetime_e5d1a0b8:


    dpense "Non avrei mai pensato di poter leccare la figa di una donna in quel modo..."


translate italian Charlottetime_30c9594f:


    dpense "Ha un sapore così buono..."


translate italian Charlottetime_5bd1f2d3:


    dpense "Non ho mai avuto una donna così in vita mia..."


translate italian Charlottetime_38a2c2e0:


    dpense "È così eccitata..."


translate italian Charlottetime_ace19207:


    cha "Ok, ragazzone."


translate italian Charlottetime_bf324701:


    cha "Mostrami cosa sai fare."


translate italian Charlottetime_f7e912e8:


    cha "Togliti quei vestiti così posso dare un'occhiata al tuo bel corpo!"


translate italian Charlottetime_d40c7883:


    cha "Già.... Questo è quello che pensavo..."


translate italian Charlottetime_f83572f2:


    cha "Così muscoloso..."


translate italian Charlottetime_f40ea147:


    cha "Hai anche un odore forte."


translate italian Charlottetime_602fd819:


    cha "IO..."


translate italian Charlottetime_6b46261d:


    d "Basta parlare..."


translate italian Charlottetime_139f3ef4:


    cha "Whaaa!"


translate italian Charlottetime_d0858423:


    cha "Ti piace prendere il comando?"


translate italian Charlottetime_df64e08e:


    d "Non sono qui per chiacchiere..."


translate italian Charlottetime_7627c9c7:


    d "Penso che sia ora di liberare alcune bellezze dalla loro prigione."


translate italian Charlottetime_b04ed3cd:


    d "Oh mio Dio, queste sono delle tette fantastiche!"


translate italian Charlottetime_c085c6c5:


    cha "Sì... Accarezzale... Gioca con loro..."


translate italian Charlottetime_6d716f8d:


    d "Non ho tempo per giocare..."


translate italian Charlottetime_15b5a1b0:


    d "Volevi un giovane stallone..."


translate italian Charlottetime_eb5c5535:


    d "Ecco che arriva..."


translate italian Charlottetime_fc3eeae2:


    cha "Ahhhhhhhhh! Sei più di un ragazzo, proprio lì!"


translate italian Charlottetime_8ee6bc76:


    cha "Ahhh..."


translate italian Charlottetime_a5dfa887:


    cha "Siiii... ti sento... Riempi la mia figa stretta..."


translate italian Charlottetime_80e8641c:


    dpense "Certo, è sorprendentemente stretta..."


translate italian Charlottetime_44684764:


    cha "Avanti [name]! Allungami!"


translate italian Charlottetime_1f3544ea:


    cha "Dammelo più forte!"


translate italian Charlottetime_7eb1ed65:


    d "Prendi questo!"


translate italian Charlottetime_be561219:


    cha "Dio mio! Dio mio! Dio mio!"


translate italian Charlottetime_f18aa612:


    d "L'hai voluto tu!"


translate italian Charlottetime_09fa1492:


    cha "SÌ! SÌ! Di più! Di più!"


translate italian Charlottetime_3951848a:


    d "Sto venendo!"


translate italian Charlottetime_fac14cdd:


    cha "Vengo anch'io!!!"


translate italian Charlottetime_fd6d20bb:


    d "Girati e ti sborrerò sulla schiena!"


translate italian Charlottetime_f8d931fa:


    cha "Dammi il tuo sperma caldo [name]!"


translate italian Charlottetime_85a345ef:


    cha "Voglio sentirlo sulla mia pelle!"


translate italian Charlottetime_b4461efb:


    d "Ahhhhh!!!"


translate italian Charlottetime_85f0a600:


    d "Quello era buono!"


translate italian Charlottetime_87137957:


    cha "Sì..."


translate italian Charlottetime_d91aadfa:


    cha "Mi sento vuota adesso..."


translate italian Charlottetime_6e5b9427:


    d "Bene! Perché non ho finito!"


translate italian Charlottetime_363cd597:


    cha "Che cosa?"


translate italian Charlottetime_36f25c9c:


    cha "IL MIO CULO!"


translate italian Charlottetime_18b75d90:


    cha "Stai attento, io..."


translate italian Charlottetime_4f482ae4:


    cha "Ahhhhhh!"


translate italian Charlottetime_f9f78226:


    cha "Dio mio! Mi stai davvero facendo il culo..."


translate italian Charlottetime_3271d50d:


    cha "Fottimi il culo [name]! Fottimi! Scopamiiiii!"


translate italian Charlottetime_93db56f7:


    cha "Ti è rimasto così tanto..."


translate italian Charlottetime_258c8329:


    cha "Sei ancora duro come la roccia!"


translate italian Charlottetime_7ab6f1b2:


    d "Non durerò a lungo! Sei così stretta!"


translate italian Charlottetime_3414f046:


    cha "Vieni dentro di me!"


translate italian Charlottetime_b78a309b:


    cha "Riempimi il culo!"


translate italian Charlottetime_8c9fa616:


    d "Ahhhhhhhhhhh!"


translate italian Charlottetime_bf1e921f:


    cha "AHhhhhhhhhhhhhhhh!"


translate italian Charlottetime_933cc1f7:


    cha "Sto venendo!!!!"


translate italian Charlottetime_31a9b907:


    d "Questo è quello che io chiamo una buona spalancata!"


translate italian Charlottetime_f8e2e91c:


    cha "'Non potrò sedermi oggi..."


translate italian Charlottetime_6bba4eab:


    d "Non posso restare, devo..."


translate italian Charlottetime_dd5f6d96:


    cha "Si si..."


translate italian Charlottetime_17dba0b7:


    cha "Vai alla tua festa..."


translate italian Charlottetime_aee3450e:


    cha "Ci vediamo!"


translate italian Charlottetime_f1c77c07:


    d "Sì, ci vediamo!"


translate italian Charlottetime_f272ff3b:


    cha "Non troppo presto..."

translate italian strings:


    old "14:30"
    new "14:30"


    old "17:30"
    new "17:30"


    old "Hey! Are you awake?"
    new "EHI! Sei sveglia?"


    old "Blue"
    new "Blu"


    old "Pass"
    new "Passare"


    old "You guys doing okay?"
    new "Ragazze, state bene?"


    old "Yeah, we're good! We're almost done :)"
    new "Sì, siamo a posto! Abbiamo quasi finito :)"


    old "You need anything?"
    new "Ti serve qualcosa?"


    old "Nope!"
    new "No!"


    old "Ruby thought of everything as usual!"
    new "Ruby ha pensato a tutto come al solito!"


    old "Okay... Well, see you later then!"
    new "Ok... beh, ci vediamo più tardi allora!"


    old "Yes! See you later!"
    new "SÌ! A dopo!"


    old "I can't wait to see you already!"
    new "Non vedo l'ora di vederti già!"


    old "Feeling better?"
    new "Sentirsi meglio?"


    old "Still a bit of back pain, but I'm okay..."
    new "Ancora un po' di mal di schiena, ma sto bene..."


    old "If you need massages, I'm here!"
    new "Se hai bisogno di massaggi, sono qui!"


    old "Haha! No, it's okay!"
    new "Ahah! No va bene!"


    old "I'm getting ready for tonight..."
    new "Mi sto preparando per stasera..."


    old "Well, don't hesitate if you need anything!"
    new "Beh, non esitare se hai bisogno di qualcosa!"


    old "I'll remember that!"
    new "Me lo ricorderò!"


    old "See you tonight!"
    new "Ci vediamo stasera!"


    old "Are you ready for tonight?"
    new "Sei pronto per stasera?"


    old "I'm not even dressed yet..."
    new "Non mi sono nemmeno ancora vestita..."


    old "Seriously?"
    new "Sul serio?"


    old "Stay like that, it works for me!"
    new "Resta così, per me funziona!"


    old "If only I could..."
    new "Se solo potessi..."


    old "I won't bother you any longer then!"
    new "Allora non ti disturbo più!"


    old "Oh, you're not bothering me!"
    new "Oh, non mi dai fastidio!"


    old "Tease!"
    new "Burlone!"


    old "You have no idea how much!"
    new "Non hai idea di quanto!"


    old "Alright, see you later!"
    new "Va bene, ci vediamo più tardi!"


    old "See you later!"
    new "Arrivederci!"


    old "Join her"
    new "Unisciti a lei"


    old "Or not"
    new "O no"








translate italian Chambreep3_3a83ddfa:


    dpense "OH! C'è un aggiornamento del mio telefono!"


translate italian Chambreep3_5e298433:


    dpense "Nuova funzionalità: invia messaggi tramite l'applicazione 'contatti'!"


translate italian Chambreep3_ec2c1d7a:


    dpense "Ok, ci proverò..."


translate italian Charlottetime_9b93c49a:


    cha "Che cosa?" with hpunch

translate italian strings:


    old "A wallpaper has been added"
    new "È stato aggiunto uno sfondo"


    old "Join her[TEMP1!t]"
    new "Unisciti a lei[TEMP1!t]"


    old "Or not[TEMP2!t]"
    new "Oppure no[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
