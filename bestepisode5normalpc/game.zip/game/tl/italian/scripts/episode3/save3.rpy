


translate italian save3_285f8ea7:


    "Per favore salva il gioco qui..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
