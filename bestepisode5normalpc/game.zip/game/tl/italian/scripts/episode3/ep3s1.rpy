


translate italian ep3s1_4b26bc0b:


    dpense "Hmm... Che sonno ristoratore. Oggi sembra impegnativo, ma sono pronto."


translate italian ep3s1_be8d8a59:


    dpense "C'è quella grande festa stasera. Devo fare una buona impressione. Ci saranno persone che non ho mai incontrato e, ovviamente, ci saranno anche le ragazze."


translate italian ep3s1_ab10fc20:


    dpense "Sarà un'esperienza da ricordare."


translate italian ep3s1_251d6609:


    dpense "Vado a controllare Julia. Spero che stia bene."


translate italian ep3s1_cbf61221:


    dpense "Dopo quello che ha passato ieri. Non deve sentirsi benissimo oggi."


translate italian ep3s1_83d877ff:


    dpense "Non sorprende che rimanga un po' a casa."


translate italian ep3s1_1ec5d604:


    dpense "Ora... Concentrati sulla giornata che ti aspetta!"


translate italian ep3s1_e9a08faa:


    dpense "Ruby si sta occupando di tutti i preparativi. Forse dovrei passare da lei per fare colazione prima della lezione? Avrà bisogno di aiuto!"


translate italian ep3s1_d1c4015e:


    dpense "Lunedì c'è il torneo. Non sono ancora dove voglio essere... Forse dovrei andare in palestra prima dell'inizio delle lezioni?"


translate italian ep3s1_58decb74:


    dpense "Devo andare a prendere Grace? Dopo ieri... penso che dobbiamo parlare."


translate italian ep3s1_23383d89:


    dpense "Va bene, qualunque cosa mi capiti, sono pronto."

translate italian strings:


    old "8:30 AM"
    new "08:30"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
