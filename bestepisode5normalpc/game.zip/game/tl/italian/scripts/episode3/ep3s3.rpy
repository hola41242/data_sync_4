


translate italian ep3s3_2ddd95bb:


    dpense "Un altro giorno... un'altra lezione..."


translate italian ep3s3_dc432cdc:


    dpense "Sono tutti qui."


translate italian ep3s3_4e7dabcc:


    dpense "Il blu sembra un po'... diverso oggi."


translate italian ep3s3_e3e365da:


    dpense "Mi sta aspettando?"


translate italian ep3s3_196077bc:


    dpense "Non indossa il trucco blu."


translate italian ep3s3_7d7d8bab:


    dpense "Le ragazze sembrano tutte carine oggi."


translate italian ep3s3_051fbf9a:


    dpense "Anche Madison, con il suo nuovo taglio di capelli."


translate italian ep3s3_eb478b29:


    dpense "Cosa significano tutti questi tagli di capelli ultimamente?"


translate italian ep3s3_78d0ae4a:


    dpense "Red è con Steven..."


translate italian ep3s3_dec237ba:


    dpense "Probabilmente complotta contro qualcuno..."


translate italian ep3s3_ae753f0b:


    dpense "Quei due insieme..."


translate italian ep3s3_9d146b53:


    dpense "Cercherò di evitarli..."


translate italian ep3s3_948122a8:


    dpense "Non ho davvero bisogno di problemi all'interno dell'Accademia..."


translate italian ep3s3_68ac6f64:


    beth "Ciao bello!"


translate italian ep3s3_5dda0f88:


    d "Hmm?"


translate italian ep3s3_c9c1336f:


    beth "Ascolta, ci sarà una sfida durante la prossima lezione."


translate italian ep3s3_c4dae10d:


    d "Come fai a sapere?"


translate italian ep3s3_87807a25:


    beth "Non importa. Ricorda solo che comporterà alcune domande."


translate italian ep3s3_6b4b1159:


    beth "Per le risposte non scegliere mai la risposta D..."


translate italian ep3s3_dd5d68f3:


    d "Eh?"


translate italian ep3s3_2508ad6c:


    beth "A, B, C, D... Mai D! Capisci?"


translate italian ep3s3_b69cc98d:


    d "Ma come fai a saperlo?"


translate italian ep3s3_a5f7a2d0:


    beth "Fidati di me, tutto qui!"


translate italian ep3s3_7bcc50f4:


    d "Va bene..."


translate italian ep3s3_0b732a56:


    sofia "Posso aiutarti con il prossimo test."


translate italian ep3s3_bec902dc:


    d "Come mai?"


translate italian ep3s3_010257d7:


    sofia "Lì, durante la lezione, ci sarà un test finale."


translate italian ep3s3_01c7de32:


    d "Un test?"


translate italian ep3s3_3d972ad4:


    sofia "SÌ. Ad ogni modo, ci sarà una domanda in cui dovrai trovare il punto nell'immagine."


translate italian ep3s3_44b10ff2:


    d "Ehm... ok."


translate italian ep3s3_99269401:


    sofia "Fare clic sul punto nella domanda."


translate italian ep3s3_37c947b7:


    d "Cosa intendi con 'clicca sul punto'?"


translate italian ep3s3_039ea5b7:


    sofia "Cavolo, sei lento!"


translate italian ep3s3_7e8a2cca:


    sofia "Ad ogni modo, quando hai la domanda sui punti, non guardare l'immagine, premi semplicemente sul punto, tutto qui."


translate italian ep3s3_013db366:


    d "Va bene, ci proverò."


translate italian ep3s3_065c8531:


    sofia "Devi avere successo. E farò di tutto per aiutarti."


translate italian ep3s3_bbaee512:


    d "Ehm... Grazie?"


translate italian ep3s3_e80e7368:


    sofia "Arrivederci."


translate italian ep3s3_5d27ba6f:


    gaby "Buongiorno a tutti."


translate italian ep3s3_53d46b9f:


    gaby "Siediti uno per tavolo, per favore!"


translate italian ep3s3_43b49e4c:


    d "Va bene."


translate italian ep3s3_693e08b4:


    gaby "Oggi parleremo un po’ del commercio, in particolare delle sue origini."


translate italian ep3s3_672697a3:


    gaby "Quale pensi sia una delle prime forme di commercio?"


translate italian ep3s3_bb9e3929:


    d "L'arrivo dei soldi?"


translate italian ep3s3_21d685ea:


    gaby "Hmm, è una buona idea ma è ancora troppo recente."


translate italian ep3s3_f67ff181:


    gaby "La moneta e l'economia ad essa associata furono piuttosto fondate dai romani con i loro mercati."


translate italian ep3s3_498ed84d:


    d "Regali tra tribù?"


translate italian ep3s3_3001538f:


    gaby "Beh, non è una cattiva risposta, ma il concetto di commercio implica uno scambio."


translate italian ep3s3_7244dc6f:


    gaby "Anche se spesso i doni venivano usati durante i rituali per ottenere protezione, divina o strategica tra le tribù."


translate italian ep3s3_9523ba64:


    gaby "Non era proprio quello che si potrebbe chiamare commercio."


translate italian ep3s3_799d5576:


    d "Baratto?"


translate italian ep3s3_c9667fb0:


    gaby "Questa è un'ottima risposta!"


translate italian ep3s3_b1ef523b:


    gaby "Il baratto era un mezzo di scambio per molte tribù che cominciavano a stabilirsi nei villaggi durante la loro sedentarizzazione."


translate italian ep3s3_3abd7c0d:


    gaby "Ha stabilito nozioni di valore, quantità e proprietà."


translate italian ep3s3_c1748d43:


    gaby "Tutti questi concetti sono ancora attuali oggi, in particolare nel mercato azionario con il valore di un'azione, il numero di azioni e i proprietari di tali azioni."


translate italian ep3s3_c43fcdc4:


    d "Prostituzione?"


translate italian ep3s3_1d22fb2c:


    gaby "Che cosa?"


translate italian ep3s3_62da3e44:


    d "Beh, usare il proprio corpo per guadagnare soldi!"


translate italian ep3s3_f9cc5397:


    gaby "OH!"


translate italian ep3s3_7789f8f3:


    gaby "Non ci avevo pensato affatto. Ma avrebbe potuto effettivamente essere corretto, tranne per il fatto che la prostituzione come la conosciamo è apparsa solo molto più tardi."


translate italian ep3s3_70cb96c7:


    gaby "Con l’emergere del denaro, delle civiltà e della vita comunitaria."


translate italian ep3s3_d699719c:


    gaby "In precedenza, tali rapporti erano piuttosto... bestiali e dettati dagli istinti e dalla tribù."


translate italian suitecourseco0_ac74b583:


    gaby "No, era un baratto."


translate italian suitecourseco0_1f6d8475:


    gaby "Per molte tribù che iniziarono a stabilirsi nei villaggi durante la loro sedentarizzazione, il baratto era un mezzo di scambio."


translate italian suitecourseco0_3abd7c0d:


    gaby "Ha stabilito nozioni di valore, quantità e proprietà."


translate italian suitecourseco0_c1748d43:


    gaby "Tutti questi concetti sono ancora attuali oggi, in particolare nel mercato azionario con il valore di un'azione, il numero di azioni e i proprietari di tali azioni."


translate italian suitecourseco_eb10b496:


    gaby "Quindi vedete, è nel passato che troviamo le basi di ciò che abbiamo oggi."


translate italian suitecourseco_b7e5c992:


    gaby "Conoscere le origini di qualcosa per comprenderne il funzionamento o i suoi effetti è spesso il modo migliore per apprendere ed evolversi."


translate italian suitecourseco_6b8ee6cc:


    gaby "A questo proposito domani al museo c'è una mostra sul Giurassico e sulla vita nel Neolitico."


translate italian suitecourseco_5917ed0d:


    gaby "[name], visto che hai dato la risposta giusta, vorresti accompagnarmi a questa mostra?"


translate italian suitecourseco_b9239156:


    d "Mi farebbe molto piacere!"


translate italian suitecourseco_b21afd26:


    gaby "Perfetto. Vieni a trovarmi alla fine della lezione."


translate italian suitecourseco_094116c0:


    d "Ok, signora."


translate italian suitecourseco_fe3248b2:


    d "Ah no mi dispiace, ma ho già impegni per domani."


translate italian suitecourseco_d51f7177:


    gaby "OH? Chiunque altro?"


translate italian suitecourseco_c8be3742:


    ji "Io, signora!"


translate italian suitecourseco_df0cb0e4:


    gaby "Ottimo..."


translate italian suitecourseco_a685ef35:


    gaby "Qualcuno vuole accompagnarmi?"


translate italian suitecourseco_7e3f71e4:


    ji "Io, signora!" with hpunch


translate italian suitecourseco_77e4be5c:


    ji "lo vorrei anche io!" with hpunch


translate italian suitecourseco_ee90ce3a:


    ruby "signora! Non pensi che sarebbe interessante per il nostro studente appena arrivato dalla Francia vedere nuovi posti in una città che non conosce?"


translate italian suitecourseco_c4afb5bd:


    ruby "Dopotutto, come si può conoscere una città senza conoscerne le origini, e quale posto migliore di un museo potrebbe dimostrarglielo?"


translate italian suitecourseco_d6d0fc86:


    ruby "E' quello che hai appena detto, vero?"


translate italian suitecourseco_988772c9:


    gaby "Hai ragione!"


translate italian suitecourseco_ff59d716:


    gaby "[name], ti piacerebbe accompagnarmi a questa mostra?"


translate italian suitecourseco_b9239156_1:


    d "Mi farebbe molto piacere!"


translate italian suitecourseco_b21afd26_1:


    gaby "Perfetto. Vieni a trovarmi alla fine della lezione."


translate italian suitecourseco_094116c0_1:


    d "Ok, signora."


translate italian suitecourseco_fe3248b2_1:


    d "Ah no mi dispiace, ma ho già impegni per domani."


translate italian suitecourseco_d51f7177_1:


    gaby "OH? Chiunque altro?"


translate italian suitecourseco_c8be3742_1:


    ji "Io, signora!"


translate italian suitecourseco_df0cb0e4_1:


    gaby "Ottimo..."


translate italian suitecourseco_3302879f:


    gaby "Molto bene, vieni a trovarmi dopo la lezione."


translate italian preepreuve_7c509ee7:


    gaby "Quindi abbiamo visto che..."


translate italian preepreuve_f1b10217:


    drew "A tutti i partecipanti al BEST!"


translate italian preepreuve_f3581df3:


    drew "Riceverai un tablet sul quale dovrai rispondere alle domande."


translate italian preepreuve_0e0e1ad0:


    drew "Queste domande ci permetteranno di valutare la tua logica, il tuo senso di deduzione e le tue conoscenze generali."


translate italian preepreuve_ea74468a:


    drew "Essere i MIGLIORI significa avere una mente acuta per le sfide che ci circondano."


translate italian preepreuve_b8b787a7:


    drew "Avrai quindi 3 minuti di tempo all'inizio del test per rispondere alle dieci domande che ti verranno poste."


translate italian preepreuve_6c53b35c:


    drew "Puoi saltare una domanda se non conosci la risposta."


translate italian preepreuve_32c8c257:


    drew "Non rispondere a una domanda non significa eliminazione."


translate italian preepreuve_4a68b967:


    drew "Verrà comunque valutato il tuo punteggio totale e gli ultimi dieci studenti in classifica verranno eliminati."


translate italian preepreuve_48d61694:


    drew "Ripeto, avete tre minuti per rispondere alle dieci domande."


translate italian preepreuve_64c124f1:


    drew "Puoi saltare le domande, ma il tuo punteggio verrà valutato alla fine e gli ultimi dieci verranno eliminati."


translate italian preepreuve_7e2c012b:


    drew "Buona fortuna a tutti."


translate italian postepreuve_4a800c5f:


    gaby "Puoi mettere via il tablet."


translate italian postepreuve_0d6e0638:


    gaby "Questo conclude la nostra lezione per oggi."


translate italian postepreuve_c5fbc9ab:


    gaby "[name], potresti restare con me per un paio di minuti?"


translate italian postepreuve_2d1667b9:


    d "Sicuro!"


translate italian postepreuve_b7e2f84a:


    gaby "Buona giornata a tutti!"


translate italian gabimusee1_d993aed7:


    gaby "Domani ti aspetto al museo verso le 14.00. Va bene per te?"


translate italian gabimusee1_32e2a5d2:


    gaby "So che stasera hai una festa, quindi non mi aspetto che ti alzi presto."


translate italian gabimusee1_d52492ad:


    d "Per me va bene!"


translate italian gabimusee1_d89a5895:


    gaby "Spero che la visita ti piacerà."


translate italian gabimusee1_17580177:


    d "Non preoccuparti, finché sto con te, sarei felice ovunque nel mondo."


translate italian gabimusee1_2dad25e0:


    gaby "E' un po' banale... Non esagerare, giovanotto."


translate italian gabimusee1_cd1d68c1:


    gaby "Questa è solo una visita, non un appuntamento."


translate italian gabimusee1_9c209113:


    d "E perché non possono essere entrambe le cose?"


translate italian gabimusee1_54945a89:


    gaby "Che cosa? NO!"


translate italian gabimusee1_40091c60:


    d "Ahah! A domani, mia signora!"


translate italian gabimusee1_6e90ecf8:


    gaby "Mia signora?"


translate italian gabimusee1_48876117:


    gaby "..."


translate italian afterepreuve_49d76cd7:


    d "Allora, ragazze, com'è andata?"


translate italian afterepreuve_9db1793b:


    mad "Liscio, è stato abbastanza facile."


translate italian afterepreuve_94a379b9:


    ruby "Sì, non male!"


translate italian afterepreuve_df08b2d1:


    grace "Ho avuto però difficoltà con alcune domande."


translate italian afterepreuve_5134a24b:


    mad "In che gradi siete finiti?"


translate italian afterepreuve_c3762510:


    ruby "Ho ottenuto 13esimo!"


translate italian afterepreuve_6fb2ffbf:


    grace "31 per me..."


translate italian afterepreuve_f4af23e0:


    mad "Sono seconda... Indovina chi è il primo..."


translate italian afterepreuve_62fb39a8:


    d "Hum?"


translate italian afterepreuve_5c9d97f5:


    emerick "Chi è il migliore ?"


translate italian afterepreuve_8144b71e:


    "Voi!"


translate italian afterepreuve_b89e940c:


    grace "Emerick..."


translate italian afterepreuve_41884caf:


    grace "E tu, [name]?"


translate italian afterepreuve_b620d1f0:


    d "Sono a posto [Rank]."


translate italian afterepreuve_2d7cab0e:


    grace "Grande!"


translate italian afterepreuve_1cdd7644:


    ruby "Julia è stata esclusa, penso che sia al 15° posto..."


translate italian afterepreuve_c0599f41:


    mad "Esclusa?"


translate italian afterepreuve_a1a0d10a:


    mad "Giusto, non c'era oggi."


translate italian afterepreuve_7910c319:


    ruby "Già, prima ho sentito la signora Drew parlare di qualche aggressione."


translate italian afterepreuve_f8a6ff1c:


    d "Ero lì la scorsa notte..."


translate italian afterepreuve_efd85f70:


    grace "Che cosa?"


translate italian afterepreuve_75d8ffec:


    d "Ieri sera, mentre tornavo a casa, mi sono imbattuto in Hector e la sua squadra che aggredivano Julia."


translate italian afterepreuve_c9393e49:


    grace "Sul serio?"


translate italian afterepreuve_25ef201b:


    grace "Quel cretino!"


translate italian afterepreuve_1094b572:


    d "Quando sono entrato, se ne sono andati, ma la sua schiena era dolorante."


translate italian afterepreuve_1a886072:


    ruby "Hmm... Questo spiega tutto."


translate italian afterepreuve_4067eee5:


    ruby "Brrrrrrrr... Se fossi più forte li prenderei giù e li ridurrei in poltiglia."


translate italian afterepreuve_221a7213:


    ruby "Io comincerei schiacciandoli fino a formare una pasta..."


translate italian afterepreuve_cdfa9673:


    ruby "Poi li macinerei fino a farli scoppiare..."


translate italian afterepreuve_63bcf30e:


    ruby "Io li taglierei a pezzetti e li metterei nel frullatore..."


translate italian afterepreuve_7523033d:


    ruby "IO..."


translate italian afterepreuve_136f81dc:


    d "Ruby?"


translate italian afterepreuve_b09db3c1:


    d "Non ti stai lasciando prendere un po' la mano?"


translate italian afterepreuve_585a72a2:


    ruby "OH? Si scusa..."


translate italian afterepreuve_fb656274:


    mad "Non preoccuparti, li schiacceremo sul campo!"


translate italian afterepreuve_2307991b:


    ruby "Che cosa?"


translate italian afterepreuve_6be94e9a:


    mad "Il sorteggio è fatto... Sono i nostri prossimi avversari..."


translate italian afterepreuve_5f32c47f:


    ruby "OH?"


translate italian afterepreuve_ea7bcd1b:


    ruby "Va bene!"


translate italian afterepreuve_e13999ea:


    ruby "Bene... abbiamo del lavoro da fare per stasera!"


translate italian afterepreuve_49591a81:


    ruby "Pronta per uscire, Grace?"


translate italian afterepreuve_eb67e331:


    grace "Proprio dietro di te."


translate italian afterepreuve_22a275e6:


    mad "Ho mia figlia questo pomeriggio, ci vediamo stasera."


translate italian afterepreuve_e7e750c1:


    grace "Nessun problema."


translate italian afterepreuve_47debeb0:


    ruby "Allora... ci vediamo stasera?"


translate italian afterepreuve_030945bb:


    mad "Ci vediamo!"


translate italian afterepreuve_4cf42b7d:


    d "Dopo!"


translate italian afterepreuve_c9415513:


    dpense "Ho ancora un po' di tempo prima di stasera."


translate italian afterepreuve_194a59d5:


    dpense "Potrei continuare ad allenarmi, oppure..."


translate italian afterepreuve_d9e0a872:


    dpense "Magari rilassati un po' prima di stasera. Sarà una bella serata!"

translate italian strings:


    old "10:30 AM"
    new "10:30"


    old "The appearance of money?"
    new "L'apparenza del denaro?"


    old "Gifts?"
    new "I regali?"


    old "Barter?[TEMP1!t]"
    new "Baratto?[TEMP1!t]"


    old "Prostitution?"
    new "Prostituzione?"


    old "Yes[TEMP1!t]"
    new "Sì[TEMP1!t]"


    old "No[TEMP2!t]"
    new "No[TEMP2!t]"












translate italian preepreuve_6964222b:


    "Se vuoi, puoi saltare questo quiz ottenendo il punteggio minimo necessario per continuare l'avventura."


translate italian preepreuve_692de64d:


    "Tieni presente che non otterrai un punteggio migliore o punti extra."

translate italian strings:


    old "Do you want to skip the quiz?"
    new "Vuoi saltare il quiz?"








translate italian preepreuve_3eb12593:


    "È stato effettuato un salvataggio nello slot 9-1 per il backup."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
