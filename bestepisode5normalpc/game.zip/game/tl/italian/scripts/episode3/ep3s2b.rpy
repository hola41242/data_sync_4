


translate italian ep3s2b_0ae9bcd0:


    ""


translate italian ep3s2b_0ae9bcd0_1:


    ""


translate italian ep3s2b_d56e0059:


    mad "Sì? Cosa vuoi, papà?"


translate italian ep3s2b_32c1a608:


    "Madison, chi è questo ragazzo francese con cui hai collaborato per la competizione?"


translate italian ep3s2b_0091a552:


    mad "Come hai fatto a scoprirlo? E cosa ti importa?"


translate italian ep3s2b_185b9e19:


    "È solo che non voglio che mia figlia esca con ragazzi che non sanno fare la loro parte per vincere!"


translate italian ep3s2b_522008c6:


    "Hai una figlia, ricordalo. E suo 'papà', se è così che puoi chiamarlo, non è qui per sostenerla."


translate italian ep3s2b_062d0790:


    mad "Lei è una mia responsabilità, non tua. Non ho bisogno della tua approvazione su come vivo la mia vita o con chi passo il mio tempo."


translate italian ep3s2b_5b68cb36:


    "Voglio che porti questo ragazzo francese a cena domani sera. Potrebbe essere la tua occasione per mostrare un po' di responsabilità."


translate italian ep3s2b_07c235cf:


    "Non farmi pentire di averti dato questa opportunità."


translate italian ep3s2b_d6d05e4d:


    mad "Ma perché vuoi vederlo?"


translate italian ep3s2b_6ae5d577:


    "Domani sera, 19:00."


translate italian ep3s2b_315b4afb:


    mad "..."


translate italian ep3s2b_0b0d85c6:


    mad "Cosa stai facendo qui?"


translate italian ep3s2b_4189c756:


    mad "In realtà, sei appena in tempo; Ho bisogno di parlare con te."


translate italian ep3s2b_552c4164:


    d "Tutto ok? Non voglio intromettermi."


translate italian ep3s2b_63f41e3d:


    mad "Mio padre vuole incontrarti domani sera alle sette per cena. Pensi di potercela fare?"


translate italian ep3s2b_81bb9408:


    d "Me? Perché?"


translate italian ep3s2b_02f9f09e:


    mad "Non chiedere, dì semplicemente di sì..."


translate italian ep3s2b_128ee54e:


    d "Eh sì, nessun problema. Devo solo capire come arrivare a casa tua."


translate italian ep3s2b_61c99aed:


    mad "Non preoccuparti di questo; Ti passo a prendere."


translate italian ep3s2b_d627f5ff:


    mad "Ecco, dammi il tuo numero. Sarà più facile se devo chiamarti."


translate italian ep3s2b_08c3c4ca:


    d "Sicuro."


translate italian ep3s2b_f0d4cb36:


    mad "Grazie. Per... sai, essere lì. Faremo questa cena. Mio padre non mi imporrà come gestirò la mia vita."


translate italian ep3s2b_865b61b3:


    mad "Ascolta, riguardo a domani sera... Mio padre ha problemi con le mie scelte, soprattutto riguardo a mia figlia."


translate italian ep3s2b_77086cd0:


    mad "Non ha mai accettato la mia relazione passata, tanto meno il fatto che sono una mamma single."


translate italian ep3s2b_74fbeb94:


    d "Ho capito. Deve essere dura per te. Sappi solo che non devi giustificarti con me o con nessun altro, se è per questo."


translate italian ep3s2b_c665b921:


    mad "Grazie. Questo... significa molto, lo sai."


translate italian ep3s2b_432871ef:


    d "Apprezzo davvero che tu sia venuto a prendermi. E io sono qui, qualunque cosa pensi tuo padre."


translate italian ep3s2b_68a4faa7:


    mad "Mio padre ha questo modo di... beh, sta dando molta importanza a questo incontro con te."


translate italian ep3s2b_4d78f3f9:


    mad "Dopo il nostro successo alla BEST, ti vede come un elemento dirompente."


translate italian ep3s2b_c2a05840:


    mad "È un po' imbarazzante, ma vuole vederti domani sera."


translate italian ep3s2b_de30ff18:


    d "Capisco. Ti dà fastidio se vengo?"


translate italian ep3s2b_0409766e:


    mad "No, al contrario. Potrebbe essere interessante. La mamma si occuperà della cena, come al solito. Mio padre, però, probabilmente proverà a subentrare. Solo... stai calmo."


translate italian ep3s2b_ea49cf54:


    d "Fatto."


translate italian ep3s2b_c270fcf5:


    d "Non vedo l'ora di vedere contro chi affronteremo lunedì."


translate italian ep3s2b_a7d2d034:


    mad "OH! Non ti è stato detto?"


translate italian ep3s2b_30d72d9c:


    d "Riguardo a cosa?"


translate italian ep3s2b_bf9328cc:


    mad "Il sorteggio è stato effettuato."


translate italian ep3s2b_52e0f737:


    d "E?"


translate italian ep3s2b_e9ec6def:


    mad "Indovinare..."


translate italian ep3s2b_aafe548a:


    mad "La squadra di calcio maschile... Sono tosti."


translate italian ep3s2b_6d68cbc1:


    mad "Steven, il loro capitano, sa come motivare la sua squadra ed è forte."


translate italian ep3s2b_047aa479:


    mad "Poi c'è Hector, quel ragazzo subdolo e imprevedibile in campo."


translate italian ep3s2b_6706d7cc:


    d "Sì, lo conosco. Ho avuto... un incontro con lui ieri."


translate italian ep3s2b_8f2bb8a5:


    mad "Hmm... Potrebbe essere una buona cosa allora."


translate italian ep3s2b_bec902dc:


    d "Come mai?"


translate italian ep3s2b_80e30dba:


    mad "Probabilmente si concentrerà su di te. Questo ci darà campo libero."


translate italian ep3s2b_bb20d578:


    d "Sì, ma penso che diventerà fisico!"


translate italian ep3s2b_1940ca92:


    mad "Parte del gioco. Fai solo attenzione a eventuali trucchi sporchi."


translate italian ep3s2b_e8fc89cc:


    d "Cercheremo."


translate italian ep3s2b_0b4e5289:


    mad "Poi c'è Ben, che segue Steven senza fare domande."


translate italian ep3s2b_1683d1f4:


    mad "E Mac, il portiere. Un vero e proprio muro."


translate italian ep3s2b_0ea43725:


    mad "Ma è il loro quinto giocatore ad essere un mistero. Non sappiamo chi sia."


translate italian ep3s2b_112950f5:


    d "Un giocatore misterioso? Complica le cose."


translate italian ep3s2b_b8846a29:


    mad "Esattamente. Dobbiamo stare attenti, soprattutto con Steven e la sua influenza sulla squadra. Ha questo... carisma, anche se non è il mio tipo di leader."


translate italian ep3s2b_27a52dc6:


    d "Troveremo un modo per oltrepassare la loro difesa. Abbiamo le nostre forze, a cominciare da te."


translate italian ep3s2b_e0621148:


    mad "Apprezzo l'ottimismo. Ma sì, hai ragione. Mostreremo loro di cosa siamo fatti."


translate italian ep3s2b_91e758df:


    mad "Adesso ho davvero bisogno di tornare ad allenarmi. Abbiamo una partita da vincere e non lascerò che mio padre o questi pagliacci ci distraggano dal nostro obiettivo."


translate italian ep3s2b_b38d594c:


    d "Sono con te, Madison. Supereremo questa cosa insieme."


translate italian ep3s2b_f39ff206:


    mad "Grazie, davvero. Per tutto."


translate italian ep3s2b_9d72cfd2:


    d "Sai, stavo pensando..."


translate italian ep3s2b_cfa39340:


    d "Quando Emerick vinse il percorso a ostacoli, nessuno lo vide davvero affrontare gli ostacoli. Strano, vero?"


translate italian ep3s2b_d66a57ee:


    mad "Ora che me lo dici... Era come se fosse scomparso, per poi riapparire alla fine, senza che nessuno sapesse come."


translate italian ep3s2b_ff0beae2:


    d "Lo abbiamo visto arrivare da un percorso diverso verso lo stadio, quando abbiamo cercato la nostra borsa se n'era già andato. Non ci ho nemmeno provato."


translate italian ep3s2b_ac184b92:


    mad "Le regole di questa competizione sono così vaghe che è frustrante."


translate italian ep3s2b_11d7cc60:


    d "Queste ambiguità nelle regole, possiamo usarle a nostro vantaggio? Per contrastare Emerick, intendo."


translate italian ep3s2b_72dc96cb:


    mad "Questa è un'idea. Se le regole non sono chiare significa che ci sono zone grigie da esplorare."


translate italian ep3s2b_ae06e0f4:


    mad "Forse possiamo trovare un modo per metterli contro di lui, soprattutto se fa affidamento su di loro per i suoi piani."


translate italian ep3s2b_b386fe59:


    d "Esattamente. Dovremmo iniziare a cercare scappatoie, punti che potremmo mettere in discussione o sfruttare."


translate italian ep3s2b_5760655e:


    d "Se Emerick sta giocando con le regole, nulla ci vieta di fare lo stesso, ma in modo legittimo."


translate italian ep3s2b_35b5c838:


    mad "Concordato. Potremmo anche discuterne con gli altri, vedere se hanno notato qualche irregolarità."


translate italian ep3s2b_b6cd81e7:


    mad "Ma per ora concentriamoci sulla preparazione della partita. Avremo bisogno di tutta la nostra forza e strategia per questo."


translate italian ep3s2b_4fdbb733:


    d "Sì."


translate italian ep3s2b_cfe3c6a6:


    mad "È ora di andare a lezione con Gabriella."


translate italian ep3s2b_dc09f676:


    d "Andiamo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
