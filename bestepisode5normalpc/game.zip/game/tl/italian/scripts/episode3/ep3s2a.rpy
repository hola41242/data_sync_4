


translate italian ep3s2a_11692d1a:


    ruby "Dove potrebbe essere? Ero sicura di averli lasciati proprio qui..."


translate italian ep3s2a_f45efed9:


    ruby "Non si trova da nessuna parte! Dai, non è che li avrei usati... No, non è possibile..."


translate italian ep3s2a_c8e09e9f:


    d "Alla ricerca di qualcosa in particolare? Bisogno di una mano?"


translate italian ep3s2a_4d5c3078:


    ruby "Oh, uh... No, beh sì... È solo che, sai, avevo dei progetti e... sono svaniti."


translate italian ep3s2a_82e7f578:


    d "Vuoi che ti aiuti a cercarli?"


translate italian ep3s2a_b47d4f38:


    ruby "No, lasciamo perdere. Se continuo a cercare, farò tardi. Non possiamo far aspettare la giornata."


translate italian ep3s2a_94cefeaa:


    ruby "Non ho ancora fatto colazione... Oggi sarà una maratona."


translate italian ep3s2a_9e16ac9f:


    ruby "Soprattutto con tutto quello che devo preparare per stasera. Niente è pronto, assolutamente niente!"


translate italian ep3s2a_cc397e3f:


    d "Cos'hai in programma, esattamente?"


translate italian ep3s2a_7186988a:


    ruby "È una sorpresa!"


translate italian ep3s2a_c63a6995:


    d "Ok ok! Immagino che ci vedremo stasera allora!"


translate italian ep3s2a_bd6a0342:


    ruby "Esattamente! Bene, allora andiamo?"


translate italian ep3s2a_d8d1b09d:


    d "Non stai dimenticando nulla?"


translate italian ep3s2a_6b0b0af2:


    ruby "Eh?"


translate italian ep3s2a_3339f33a:


    ruby "Oh, oh!"


translate italian ep3s2a_60cfb41d:


    ruby "Ho anche dimenticato di vestirmi!"


translate italian ep3s2a_9f5cc69e:


    ruby "Sai cosa, dammi due minuti e facciamo un salto alla mensa! Fai una colazione veloce."


translate italian ep3s2a_ca8a4f56:


    d "Per me va bene."


translate italian ep3s2a_27b44026:


    dpense "Non ha detto due minuti?"


translate italian ep3s2a_074aea1e:


    ruby "Ok, sono pronta!"


translate italian ep3s2a_bf017898:


    ruby "Colpiamolo!"


translate italian ep3s2a_0d33e6e7:


    ruby "Ah, questo colpisce nel segno!"


translate italian ep3s2a_bec598f0:


    d "Sì, un buon succo di frutta al mattino e siamo pronti per una fantastica giornata!"


translate italian ep3s2a_f8bc6076:


    ruby "Bella giornata, bella giornata... Abbiamo lezione tra pochi minuti, poi devo tornare a casa per prendere tutto quello che ho preparato per la festa."


translate italian ep3s2a_6dfa40f3:


    ruby "E poi, oggi pomeriggio, devo ancora preparare i giochi per stasera e vestirmi!"


translate italian ep3s2a_5032c97b:


    d "Allora, quale vestito pensi di indossare?"


translate italian ep3s2a_e84c5d39:


    ruby "Vedrai! Te l'avevo detto, avresti dovuto scegliere!"


translate italian ep3s2a_033f2e7d:


    d "Qualche suggerimento sui giochi che hai in programma?"


translate italian ep3s2a_53d03f1a:


    ruby "Uh... No, sarebbe un imbroglio!"


translate italian ep3s2a_886fed77:


    ruby "Ma non preoccuparti, non ti annoierai!"


translate italian ep3s2a_7a67eec2:


    d "Non posso aspettare di vederlo!"


translate italian ep3s2a_979e7529:


    ruby "Beh, allora immagino che dovremmo andare a lezione."


translate italian ep3s2a_116b0c41:


    ruby "Spero che Gabriella sia di buon umore!"


translate italian ep3s2a_a735b1d5:


    d "Oh, non te l'avevo detto!"


translate italian ep3s2a_2307991b:


    ruby "Che cosa?"


translate italian ep3s2a_f3ddd5e4:


    d "L'ho incontrata ieri sera sulla sua moto!"


translate italian ep3s2a_351fd21f:


    ruby "Ha una moto?"


translate italian ep3s2a_ae03bbda:


    d "Sì! Mi ha quasi investito perché non stavo prestando attenzione..."


translate italian ep3s2a_430c9b2b:


    ruby "Poi?"


translate italian ep3s2a_3193c1a9:


    d "Bene, ho finito per ottenere il suo numero!"


translate italian ep3s2a_d9ee4a01:


    ruby "Non è possibile!"


translate italian ep3s2a_16e5da27:


    d "Lo giuro!"


translate italian ep3s2a_d2894bee:


    ruby "Te l'avevo detto! Anche il destino sta cercando di metterti insieme con lei!"


translate italian ep3s2a_6c1aa172:


    d "Oh, andiamo, è ridicolo!"


translate italian ep3s2a_e1d4fa0d:


    ruby "Bene, per ora è solo un contatto, ma è un progresso!"


translate italian ep3s2a_4e839775:


    ruby "Dovrei diventare Cupido. Penso di avere un talento per questo!"


translate italian ep3s2a_f5eeefc8:


    d "Stai andando troppo avanti lì."


translate italian ep3s2a_e62774af:


    ruby "Uh... Sì, vedremo!"


translate italian ep3s2a_c739e98c:


    ruby "Tuttavia, non vedo l'ora di vedere cosa succederà dopo con lei!"


translate italian ep3s2a_7ccab813:


    d "Sei implacabile, lo sai? Non esiste un passo successivo, non esiste nemmeno un primo passo."


translate italian ep3s2a_517c3e0c:


    ruby "Sì, sì, questo è quello che dici..."


translate italian ep3s2a_e862964b:


    ruby "Ma tu hai il numero di telefono della tua MILF!"


translate italian ep3s2a_474f9baa:


    d "Ruby..."

translate italian strings:


    old "9:00 AM"
    new "09:00"


    old "Ten minutes later..."
    new "Dieci minuti dopo..."


    old "9:30 AM"
    new "9:30 DEL MATTINO"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
