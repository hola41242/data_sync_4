

translate italian strings:


    old "Look at the numbers backwards"
    new "Guarda i numeri al contrario"


    old "Don't click on the image"
    new "Non fare clic sull'immagine"


    old "The answer is in the question"
    new "La risposta è nella domanda"





translate italian strings:


    old "Please choose your teammate..."
    new "Scegli il tuo compagno di squadra..."


    old "    Bonus: Objects"
    new "Bonus: oggetti"


    old "    Bonus: Speed"
    new "Bonus: Velocità"


    old "    Bonus: Hint"
    new "Bonus: Suggerimento"


    old "    Bonus: Brain"
    new "Bonus: Cervello"


    old "    Bonus: Mother"
    new "Bonus: Madre"


    old "    Bonus: Places"
    new "Bonus: Luoghi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
