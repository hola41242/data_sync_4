

translate italian e1s2_34ad7e5c:


    "…E sei rimasta sola con lui tutta la notte?"


translate italian e1s2_5db95835:


    "Ebbene sì, perché?"


translate italian e1s2_41cf68f1:


    "Beh, non lo so... È strano, non è vero? non lo conosci, tua madre dice che dorme qui e all'improvviso un ragazzo resta sul divano tutta la notte..."


translate italian e1s2_24bb8b8a:


    "Sì, ma non lo so, mi impressiona un po'... in senso positivo..."


translate italian e1s2_9237b6e9:


    "Questo è il mio Cortex, non sembra, ma sì, ho la stessa impressione!"


translate italian e1s2_09695720:


    "La tua corazza?"


translate italian e1s2_2f271829:


    "Te lo spiegherò più tardi! Bene, sono le 8, devo svegliarlo! Uh... Cavolo, come si chiamava ancora?... Vabbè..."


translate italian e1s2_c73588b3:


    "CORTEXXXXXXXXXXXXXXX!!!!" with hpunch


translate italian e1s2_67b0fbce:


    d "Cheaaaaaaaaaaaaaaaaa!"


translate italian e1s2_8614e399:


    ruby "Ahaha, lo so, sono dannatamente stupenda, ma non avevo mai pensato al significato letterale di quell'espressione!"


translate italian e1s2_be15c680:


    d "Ehi, cosa fai qui?"


translate italian e1s2_4ad557e3:


    ruby "Bene, la signora Drew mi ha chiesto di portarti in camera tua, ed è meglio obbedirle subito o... Bene, andiamo?"


translate italian e1s2_a250c6af:


    d "Aspetta, e Grace?"


translate italian e1s2_1c28c67e:


    grace "SÌ?"


translate italian e1s2_a76605d6:


    grace "non preoccuparti per me, ho ancora un'ora per prepararmi! non so cosa sta succedendo, ma è meglio arrivare puntuali all'Università, quindi sbrigati altrimenti mia madre si lamenterà e non vogliamo disturbarla il primo giorno di lezione!"


translate italian e1s2_0226421c:


    ruby "SÌ! Andiamo, andiamo, andiamo!"


translate italian e1s2_c71a801b:


    d "Sto arrivando..."


translate italian e1s2_72e488c4:


    d "Quindi anche tu sei all'Università. Cosa stai studiando?"


translate italian e1s2_b6638c06:


    ruby "Sto studiando cinema, tutte le forme di cinema. È davvero emozionante! Sai che è stato fatto un esperimento per vedere se Jack sarebbe potuto rimanere sulla porta con Rose?"


translate italian e1s2_be0b1d53:


    d "Di cosa stai parlando ? Titanic? Veramente ?"


translate italian e1s2_53942f8e:


    ruby "Sì !!! Era così egoista... Oh Jack, sto congelando..."


translate italian e1s2_74616e87:


    ruby "Ok, Rose, cercherò di restare in vita nel mare a 4 gradi..."


translate italian e1s2_5d969260:


    d "Sei per davvero ?"


translate italian e1s2_07929c8d:


    ruby "Ok ok... Ma è molto interessante, lo giuro!"


translate italian e1s2_287a87b4:


    d "Posso immaginare. E cosa ti piace del cinema?"


translate italian e1s2_6f407893:


    ruby "Beh, ad esempio, adoro i film horror... adoro guardarli, ma mi copro gli occhi non appena c'è qualcosa di spaventoso! Sai, come il jumpscare nei film horror..."


translate italian e1s2_414a8171:


    ruby "È come se avessi una grossa palla nello stomaco che esplode, mi si ferma il respiro e faccio fatica a riprendermi... Comunque mi piace... ma ho troppa paura!"


translate italian propcineruby_3634a7f3:


    d "Beh, se vuoi, un giorno potremmo andare a vedere un film insieme a teatro. Potrebbe essere davvero divertente... ma non voglio costringerti a fare nulla..."


translate italian propcineruby_99e540a3:


    ruby "SÌ! SÌ! SÌ!"


translate italian propcineruby_6287fda8:


    d "Ehm..."


translate italian propcineruby_c43add9f:


    ruby "non sono mai stata invitata al cinema, anche se lo adoro... Quindi sì, accetto il tuo invito, Cortex!"


translate italian propcineruby_d8d89651:


    d "Ahah! Ok, andiamo al cinema insieme e ti lascio anche scegliere il film!"


translate italian propcineruby_41df4702:


    ruby "E posso avere dei popcorn per renderlo come una vera esperienza cinematografica?"


translate italian propcineruby_37851153:


    d "Sì, certo... ti comprerò una grande confezione di popcorn se vuoi!"


translate italian propcineruby_47d453f2:


    ruby "Sapevo di aver fatto la scelta giusta scegliendoti come mio Cortex, ne ero sicuro!"


translate italian propcineruby_e0d30fc1:


    d "Sì probabilmente..."


translate italian fincineruby_c945114a:


    ruby "Va bene, ci siamo quasi. Ti mostrerò la tua stanza!"


translate italian discoverroom_1a237ef5:


    ruby "Vai a dare un'occhiata alla tua stanza! Arrivo tra 10 minuti, la mia treccia è un disastro e devo rifarla!"


translate italian discoverroom_e7861de8:


    d "Cos'è! Cos'è tutto questo?"


translate italian discoverroom_f963a737:


    d "È meglio che non tocchi niente... Sarà qui tra circa 10 minuti... Cosa devo fare nel frattempo?"


translate italian discoverroom_a6338c52:


    d "Inalare..."


translate italian discoverroom_64e98b03:


    d "Shhhh! Espira..."


translate italian discoverroom_a6338c52_1:


    d "Inalare..."


translate italian discoverroom_64e98b03_1:


    d "Shhhh! Espira..."


translate italian discoverroom_64e98b03_2:


    d "Shhhh! Espira..."


translate italian discoverroom_2bd4d989:


    d "Stai parlando con me?"


translate italian discoverroom_cd4fae71:


    d "Ok, ragazzo, devi dimostrare quanto sei bravo!"


translate italian discoverroom_6dbb1ebc:


    d "Chi è il migliore ?"


translate italian discoverroom_c656e65a:


    d "Io sono il migliore !"


translate italian discoverroom_da8c427f:


    d "Spero che mi spiegherà perché siamo tutti soli in una camera da letto..."


translate italian rubychambre_5b47cd33:


    d "Ok, basta!"


translate italian rubychambre_138d5fe3:


    d "Dovrò fare un sacco di pulizie qui... Per farlo sentire come se fosse mio..."


translate italian rubychambre_af3ce623:


    d "non so perché ho una stanza tutta per me ma la farò a modo mio!"


translate italian rubychambre_508037ac:


    ruby "Ebbene, la settimana scorsa mi è stato chiesto di raccogliere tutto quello che potevo per fare spazio a un ragazzo francese che sarebbe arrivato questa settimana..."


translate italian rubychambre_a5e75010:


    ruby "Quindi ho preso un po' di tutto quello che mi è capitato... Ma non so nemmeno cosa ti piace! Quindi preferirei lasciartelo ridecorare..."


translate italian rubychambre_182f01ea:


    ruby "Comunque quando hai tempo, perché abbiamo solo 15 minuti prima delle 9!!! Allora cambiati i vestiti e andiamo!"


translate italian rubychambre_450849eb:


    d "Cambiare? Ma non ho nemmeno la mia roba! E dov'è la tua treccia? Perché l'hai cambiato?"


translate italian rubychambre_7d7560a5:


    ruby "Oh, la mia treccia non era bella... E dovevo farla velocemente... non ti piace?"


translate italian rubychambre_bfcede80:


    d "Hum... mi piace ma cambia molto il tuo aspetto..."


translate italian rubychambre_e4dc2b71:


    ruby "Mettiamo da parte le chiacchiere per ora... Guarda nell'armadio, non preoccuparti, troverai qualcosa di interessante, ne sono sicura!"


translate italian rubychambre_ddbc3bea:


    ruby "D'altronde è tutto quello che ho potuto salvare dai vestiti dimenticati... Allora provatelo e me lo farete vedere!"


translate italian rubychambre_dd5d68f3:


    d "Eh?"


translate italian rubychambre_06b04368:


    ruby "Dai dai!"


translate italian rubychambre_794a94d7:


    d "Ok... cosa abbiamo qui?"


translate italian rubychambre_04593aa2:


    d "Vuoi davvero che lo indossi???"


translate italian rubychambre_fa34f206:


    ruby "Sì, andiamo! non essere un bambino!!!"


translate italian rubychambre_d83c8599:


    d "Ma..."


translate italian rubychambre_16f08f36:


    ruby "Andiamo, siamo già in ritardo!"


translate italian rubychambre_7bcc50f4:


    d "Va bene..."


translate italian tenuefier_d419757e:


    ruby "Oh mio Dio, oh mio Dio, oh mio Dio!"


translate italian tenuefier_da447aff:


    d "Cosa c'è che non va ?"


translate italian tenuefier_0954f056:


    ruby "Mi dispiace, ma sono qui con un ragazzo che si sta spogliando davanti a me e io non ho chiuso occhio!"


translate italian tenuefier_474f9baa:


    d "Ruby..."


translate italian tenuefier_4016e5f2:


    ruby "Oh mamma, cosa devi pensare di me? So che avrei dovuto voltare le spalle, ma non l'ho fatto e..."


translate italian tenuefier_474f9baa_1:


    d "Ruby..."


translate italian tenuefier_5d647fc8:


    ruby "non che tu non sia bello... NO! Sei decisamente bello, ma ora che sei qui, non è appropriato che una ragazza guardi un... uomo ben fatto... così..."


translate italian tenuefier_dbf049bf:


    d "RUBY!!!" with vpunch


translate italian tenuefier_8fe3ea01:


    ruby "Oh si ?"


translate italian tenuefier_ff81dc7d:


    d "Potresti girarti, per favore?"


translate italian tenuefier_aa02d9c8:


    ruby "Oh si ! Certo certo ..."


translate italian tenuefier_cf05acac:


    ruby "Cos'è... all'improvviso fa caldo qui dentro?"


translate italian tenueshy_ff81dc7d:


    d "Potresti girarti, per favore?"


translate italian tenueshy_aa02d9c8:


    ruby "Oh si ! Certo certo ..."


translate italian tenueshy_b2766e52:


    ruby "Cos'è... all'improvviso fa caldo qui dentro?"


translate italian rubydepart_f3a9f496:


    d "Va bene ! Puoi guardare adesso! Verso l'infinito e oltre !"


translate italian rubydepart_74e895dc:


    ruby "Oh grande ! Ero sicura che avresti trovato qualcosa di buono! E conosci Toy Story anche in Francia?"


translate italian rubydepart_75fcdfb3:


    d "Hum... Pensi che non abbiamo film?"


translate italian rubydepart_fb3f392c:


    ruby "NO ! No, certo che no... Ma non ci sono mai stato quindi..."


translate italian rubydepart_ac6d9b74:


    ruby "Sapevi che Toy Story è il primo film interamente animato in 3D?"


translate italian rubydepart_05244633:


    d "No ma è interessante!"


translate italian rubydepart_0fdce267:


    ruby "Si lo so ! L'anno scorso abbiamo imparato molte cose a riguardo! Ad esempio, nel film c'erano più di 110.000 fotogrammi..."


translate italian rubydepart_8ec775d3:


    ruby "E ci sono volute dalle 2 alle 15 ore per ogni fotogramma... Quindi è stata una fattoria di macchine a realizzare questo tempo di rendering di 500 anni per realizzarlo ^^"


translate italian rubydepart_992e6eaa:


    d "Ruby ?"


translate italian rubydepart_0a4c4274:


    ruby "SÌ ?"


translate italian rubydepart_f74d81d3:


    d "non hai detto che non vogliamo fare tardi?"


translate italian rubydepart_e28cd635:


    ruby "OH ! SÌ ! Sì... Beh... Cortex, sei pronto a partire?"


translate italian rubydepart_44c0877a:


    ruby "non era una domanda! Dobbiamo andare ! non vogliamo arrivare in ritardo!"

translate italian strings:


    old "Invite her someday to cinema [TEMP1!t]"
    new "Invitatela un giorno al cinema [TEMP1!t]"


    old "Not interested [TEMP2!t]"
    new "Non interessato [TEMP2!t]"


    old "Do push-ups [TEMP1!t]"
    new "Fai flessioni [TEMP1!t]"


    old "Go to the bathroom [TEMP2!t]"
    new "Vai in bagno [TEMP2!t]"


    old "Wait for Ruby"
    new "Aspetta Ruby"


    old "30 push-ups later..."
    new "30 flessioni dopo..."


    old "Undress in front of her [TEMP1!t]"
    new "Spogliati davanti a lei [TEMP1!t]"


    old "Ask her to turn [TEMP2!t]"
    new "Chiedile di girare [TEMP2!t]"


    old "Yes Minus ! [TEMP1!t]"
    new "Sì Minus! [TEMP1!t]"


    old "Nope [TEMP2!t]"
    new "No [TEMP2!t]"


















translate italian e1s2_770af536:


    "Beh, sì, perché?"


translate italian e1s2_80c276a3:


    "Non lo so, è strano, non è vero? L'hai appena incontrato, tua madre dice che dorme qui, e all'improvviso un tizio passa la notte sul tuo divano..."


translate italian e1s2_31e3cfa2:


    "Sì, è stato sicuramente strano, ma mi ha fatto un'impressione... in senso positivo."


translate italian e1s2_501d5b80:


    "Questo è il mio Cortex, non sembra così, ma sì, sembra proprio un bel tipo!"


translate italian e1s2_78364aef:


    "Te lo spiegherò dopo. Beh, sono le 8, dovrei svegliarlo. Uh... accidenti, come si chiamava di nuovo? Oh beh..."


translate italian e1s2_7df24e34:


    "COOOOOOOROOOO!!!!" with hpunch


translate italian e1s2_6b6758b7:


    ruby "Bene, la signora Drew mi ha chiesto di accompagnarti nella tua stanza, ed è meglio obbedirle subito o... beh, andiamo?"


translate italian e1s2_45a5dd64:


    d "Aspetta, e Grace?"


translate italian e1s2_67c680bf:


    grace "Non preoccuparti per me, ho ancora un'ora per prepararmi. Non so cosa succede, ma è meglio che siamo puntuali per arrivare all'università. Sbrigati o mia madre si lamenterà e non voglio farlo il primo giorno di lezione!"


translate italian e1s2_bf9bfb15:


    d "Quindi anche tu sei all'università. Cosa stai studiando?"


translate italian e1s2_1af9e6cb:


    ruby "Sto studiando cinema, in tutte le sue forme. È super eccitante! Sai che è stato fatto un esperimento per vedere se Jack sarebbe riuscito a rimanere sulla porta con Rose?"


translate italian e1s2_55638aae:


    d "Di cosa stai parlando? Del Titanic? Davvero?"


translate italian e1s2_96cc0adf:


    ruby "Sì! Era così egoista. Oh Jack, mi sto congelando..."


translate italian e1s2_f2d78baa:


    ruby "Ok, Rose, cercherò di sopravvivere nell'acqua gelida."


translate italian e1s2_4d71f41f:


    d "Dici sul serio?"


translate italian e1s2_b3ab0599:


    ruby "Va bene, va bene, ma è super interessante, lo giuro!"


translate italian e1s2_b62db3ff:


    ruby "Mi piace come mi fa sentire. Per esempio, adoro i film horror. Adoro guardarli, ma mi copro gli occhi non appena c'è qualcosa di spaventoso! Sai, come un jumpscare."


translate italian e1s2_9cf93c5d:


    ruby "È come se avessi una palla enorme nello stomaco che esplode, il mio respiro si ferma e faccio fatica a riprendermi. Comunque, mi piace, ma mi spavento troppo facilmente!"


translate italian propcineruby_6e776a5e:


    d "Beh, se vuoi, potremmo andare a vedere un film insieme al cinema un giorno. Potrebbe essere molto divertente, ma non voglio farti pressione per niente..."


translate italian propcineruby_4ea2e005:


    ruby "Sì! Sicuramente sì!"


translate italian propcineruby_1f60adc7:


    ruby "Non sono mai stata invitata al cinema, anche se lo adoro. Quindi, sì, accetto il tuo invito, Cortex!"


translate italian propcineruby_141e7c18:


    ruby "E potresti procurarmi dei popcorn per far sì che l'esperienza sia come quella di un vero film?"


translate italian propcineruby_849605a1:


    d "Sì...probabilmente."


translate italian discoverroom_85dbadc3:


    ruby "Vai a dare un'occhiata alla tua stanza! Sarò lì tra dieci minuti. La mia treccia è un disastro e devo rifarla!"


translate italian discoverroom_1594124b:


    d "Meglio che non tocchi niente. Sarà qui tra circa dieci minuti... cosa dovrei fare nel frattempo?"


translate italian discoverroom_16a1548f:


    d "Shhhh! Espira..."


translate italian discoverroom_16a1548f_1:


    d "Shhhh! Espira..."


translate italian discoverroom_16a1548f_2:


    d "Shhhh! Espira..."


translate italian discoverroom_84ecfab6:


    d "Stai parlando con me?"


translate italian discoverroom_8a3f962d:


    d "Ok amico, devi dimostrare loro quanto sei bravo!"


translate italian discoverroom_863e77a7:


    d "Chi è il migliore?"


translate italian discoverroom_a238a1d1:


    d "Sono il migliore!"


translate italian rubychambre_5bef6195:


    d "Ok, basta così!"


translate italian rubychambre_41072c92:


    d "Dovrò riorganizzare questa stanza. Per farla sentire mia..."


translate italian rubychambre_c06c20e5:


    d "Non so perché ho una stanza tutta per me, ma farò in modo che mi senta come a casa!"


translate italian rubychambre_664ab157:


    ruby "Bene, la settimana scorsa mi è stato chiesto di arredare e decorare una stanza per un ragazzo francese che sarebbe arrivato questa settimana."


translate italian rubychambre_8806eefc:


    ruby "Quindi ho preso un po' di tutto quello che mi è capitato... ma non so nemmeno cosa ti piace! Quindi dovresti decisamente riarredarlo..."


translate italian rubychambre_2d6b02e1:


    ruby "Comunque, fallo quando hai tempo. Sono già le nove meno un quarto, quindi dobbiamo andare! Cambiati in fretta e andiamo!"


translate italian rubychambre_a794f044:


    d "Cambiare? Non ho nemmeno la mia roba! E dov'è la tua treccia? Perché l'hai cambiata?"


translate italian rubychambre_91fb8673:


    ruby "Oh, la mia treccia non era bella, e dovevo farla in fretta. Ti piace?"


translate italian rubychambre_a6f5264d:


    d "Hmm... mi piace, ma cambia molto il tuo aspetto."


translate italian rubychambre_7f6541d4:


    ruby "Grazie, ma devi prepararti. Controlla l'armadio, ho trovato alcuni articoli per te. Troverai qualcosa che ti piace, ne sono sicuro!"


translate italian rubychambre_bc471c95:


    ruby "Oltretutto, è tutto quello che sono riuscito a raccogliere dagli oggetti smarriti. Forza, prova qualcosa e fammi vedere come ti sta!"


translate italian rubychambre_f4d512f9:


    d "Bene... cosa abbiamo qui?"


translate italian rubychambre_5a34b207:


    d "Vuoi davvero che indossi questo?!"


translate italian rubychambre_44a8b55f:


    ruby "Dai, dai! Non comportarti come un bambino!"


translate italian tenuefier_893914d0:


    ruby "Oh mio dio, oh mio dio, oh mio dio!"


translate italian tenuefier_2baafa95:


    d "Cosa c'è che non va?"


translate italian tenuefier_df0c0189:


    ruby "Mi dispiace, ma ti stai spogliando davanti a me e non ho nemmeno pensato di chiudere gli occhi!"


translate italian tenuefier_42253061:


    ruby "Oh, cosa penserà di me mia madre? Avrei dovuto voltarmi dall'altra parte, ma non l'ho fatto e..."


translate italian tenuefier_ec8a59ae:


    ruby "Non che tu non sia bello... NO! Sei sicuramente bello, ma ora che sei mezzo nudo, e non è appropriato guardare con aria lasciva un... uomo ben fatto... in questo modo..."


translate italian tenuefier_0a90153a:


    d "RUBYYY!!!" with vpunch


translate italian tenuefier_ad8e36ef:


    ruby "Oh... sì?"


translate italian tenuefier_2f16cf06:


    d "Potresti girarti, per favore?"


translate italian tenuefier_f744f755:


    ruby "Oh sì! Certo, certo..."


translate italian tenuefier_3be2d750:


    ruby "Whaaa... all'improvviso sta diventando caldo qui?"


translate italian tenueshy_2f16cf06:


    d "Potresti girarti, per favore?"


translate italian tenueshy_f744f755:


    ruby "Oh sì! Certo, certo..."


translate italian tenueshy_3be2d750:


    ruby "Whaaa... all'improvviso sta diventando caldo qui?"


translate italian rubydepart_59094040:


    d "Okay! Ora puoi guardare! Verso l'infinito e oltre!"


translate italian rubydepart_9e16abcd:


    ruby "Oh, fantastico! Ero sicura che avresti trovato qualcosa che ti stesse bene e che ti facesse fare bella figura! E hai Toy Story anche in Francia?"


translate italian rubydepart_2293fb7a:


    d "Mmm... pensi che non abbiamo film?"


translate italian rubydepart_0d55d8d0:


    ruby "NO! No, certo che no, ma non ci ho mai pensato..."


translate italian rubydepart_5efecdc4:


    ruby "Sapevi che Toy Story è il primo film completamente animato in 3D?"


translate italian rubydepart_c2b42767:


    d "No, ma è interessante!"


translate italian rubydepart_88c4f110:


    ruby "Sì, lo so! L'anno scorso abbiamo imparato un sacco di cose a riguardo! Per esempio, c'erano più di centodiecimila fotogrammi nel film..."


translate italian rubydepart_a8d12340:


    ruby "E ci volevano dalle due alle quindici ore per il rendering di ogni fotogramma. Quindi avevano un mucchio di macchine su cui lavorare, cinquecento anni di rendering solo per realizzare il film!"


translate italian rubydepart_136f81dc:


    d "Ruby?"


translate italian rubydepart_b89db320:


    ruby "SÌ?"


translate italian rubydepart_438eb630:


    d "Non hai detto che abbiamo fretta?"


translate italian rubydepart_9dfd8c7e:


    ruby "Oh! Sì! Sì, beh... Cortex, sei pronto per andare?"


translate italian rubydepart_a95d95e2:


    ruby "Non importa! Dobbiamo andare! Non possiamo fare tardi!"

translate italian strings:


    old "Ask her to turn around [TEMP2!t]"
    new "Chiedile di girarsi [TEMP2!t]"


    old "Yes Minus! [TEMP1!t]"
    new "Sì Minus! [TEMP1!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
