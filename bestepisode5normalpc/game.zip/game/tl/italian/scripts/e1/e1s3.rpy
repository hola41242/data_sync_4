

translate italian e1s3_c5ea222a:


    ruby "Julia! Cosa hai fatto ai tuoi capelli?"


translate italian e1s3_7f35a1c9:


    julia "Oh, ero stanca che la gente mi chiedesse se volevo diventare una rockstar!"


translate italian e1s3_0cfbc407:


    ruby "Beh, ti sta bene! E il colore...Wow!"


translate italian e1s3_fbaf289d:


    julia "Grazie! E ti sei liberata della treccia?"


translate italian e1s3_3a174d23:


    ruby "SÌ! È adatto per lo sport, ma ne ero stanca! Dovevo rifarla ogni volta...e non avevo molto tempo stamattina...ho dovuto portare Cortex nella sua stanza!"


translate italian e1s3_cb399fc3:


    julia "Cortex?"


translate italian e1s3_064cabec:


    d "Ha deciso che eravamo Minus e Cortex..."


translate italian e1s3_c697cc23:


    julia "Il ritorno del pervertito... spero che tu ti sia comportato bene con Ruby! Altrimenti vedrai cosa si prova a farsi picchiare da una donna!"


translate italian e1s3_8e0cfd62:


    julia "Sei fortunato che sono di buon umore! Ma non mettermi alla prova oggi... Stai lontano da me e andrà tutto bene!"


translate italian e1s3_f2b26f55:


    ruby "Era perfetto, Julia! Smettila! L'ho portato nella sua stanza perché potesse cambiarsi e vedere dove avrebbe dormito."


translate italian e1s3_758413b0:


    ruby "Povero ragazzo, non conosce nessuno qui e gli hanno portato via i bagagli senza che sapesse dove andare..."


translate italian e1s3_2113284b:


    julia "OH! Ok... beh, ascolta, farò uno sforzo..."


translate italian e1s3_1252b777:


    julia "E... Meno e Corteccia ???"


translate italian e1s3_46523c1d:


    ruby "Oh sì...Ti ricordi Pinky e The Brain quando eravamo bambini?"


translate italian e1s3_757fcd56:


    julia "Uhm... Oh! Gli Animaniacs?"


translate italian e1s3_33d2c520:


    ruby "Sììì! Beh, in francese si chiama Minus e Cortex!"


translate italian e1s3_e476f539:


    julia "Oh... Ma come fai a saperlo?"


translate italian e1s3_9697caca:


    ruby "Bene, l'anno scorso abbiamo studiato Steven Spielberg e lui faceva parte del team che ha creato gli Animaniacs e..."


translate italian e1s3_d6560304:


    julia "Va bene, va bene, va bene! non so come fai a tenere così tante informazioni nella tua testolina..."


translate italian e1s3_064cabec_1:


    d "Ha deciso che eravamo Minus e Cortex..."


translate italian e1s3_3fdb3897:


    julia "Oh, è il ragazzo dell'aereo! Spero che Ruby sia stata amichevole con te! Ruby, non l'hai annoiato troppo con tutte le tue storie, vero?"


translate italian e1s3_f465834e:


    julia "Poverino, è appena arrivato e probabilmente è stato bombardato da storie su film, animali o ghiaccio che si scioglie in Antartide..."


translate italian e1s3_3ce36968:


    d "Hahaha! No, davvero, era carina! Mi ha mostrato il dormitorio e la mia stanza che..."


translate italian e1s3_9c209af9:


    ruby "Che ho preparato io stessa!"


translate italian e1s3_33074fdd:


    d "Sì, la stanza che ha preparato per me..."


translate italian e1s3_7c219f85:


    julia "Se vuoi, posso farti visitare il campus così puoi vedere cosa possiamo fare dopo le lezioni."


translate italian e1s3_aa3d626c:


    d "Sarebbe perfetto!"


translate italian e1s3_1252b777_1:


    julia "E... Minus e Cortex ???"


translate italian e1s3_46523c1d_1:


    ruby "Oh sì...Ti ricordi Pinky e The Brain quando eravamo bambini?"


translate italian e1s3_757fcd56_1:


    julia "Uhm... Oh! Gli Animaniacs?"


translate italian e1s3_33d2c520_1:


    ruby "Sììì! Beh, in francese si chiama Minus e Cortex!"


translate italian e1s3_e476f539_1:


    julia "Oh... Ma come fai a saperlo?"


translate italian e1s3_c0ebf8c0:


    ruby "Bene, l'anno scorso abbiamo studiato Steven Spielberg e lui faceva parte del team che ha creato gli Animaniacs e..."


translate italian e1s3_d6560304_1:


    julia "Va bene, va bene, va bene! non so come fai a tenere così tante informazioni nella tua testolina..."


translate italian e1s3_fce2fe54:


    ruby "Puoi stare con lui per un po' e fargli fare un giro? Devo andare in bagno, la lezione inizia!"


translate italian e1s3_f5328420:


    julia "Naturalmente, vai avanti!"


translate italian e1s3_9c687826:


    ruby "Grazie!!! Arrivederci!"


translate italian e1s3_6ffafcc2:


    julia "Bene, visto che siamo solo noi, lascia che ti dia un breve resoconto delle persone dell'Università."


translate italian e1s3_6862ab50:


    julia "Vedrai che alcune sono più o meno le 'star' da queste parti, mentre altre sono una specie di outsider..."


translate italian e1s3_2c3a63c7:


    d "Cosa intendi?"


translate italian e1s3_343aa2f3:


    julia "Aspetta, lascia che te lo mostri!"


translate italian e1s3_676dd9d3:


    julia "Dunque, vedi, quello è Steven, uno dei ragazzi dell'università, che ci prova costantemente con le ragazze e cerca di rimorchiare, come dice lui..."


translate italian e1s3_1b31ae3c:


    julia "Gioca nella squadra di calcio maschile. Stanno cercando compagni di squadra, quindi puoi provare se vuoi."


translate italian e1s3_c873f017:


    julia "non l'ho mai visto con nessuno e tutte le ragazze della squadra lo hanno già inserito nella lista nera..."


translate italian e1s3_ba25435e:


    d "Oh sì, è vero, hai la tua squadra... Stai bene?"


translate italian e1s3_00433e96:


    julia "Siamo una delle migliori squadre accademiche di calcio del paese! E alcuni di noi dovrebbero unirsi alla squadra nazionale! Abbiamo tutti lo stesso sogno..."


translate italian e1s3_2bf8680d:


    julia "Per arrivare in nazionale e giocare con ragazze come Alex Morgan o Megan Rapinoe!"


translate italian e1s3_dc1001c7:


    d "Le ho viste giocare in Francia! Abbiamo anche una buona squadra femminile!"


translate italian e1s3_6a905540:


    julia "Sì è vero. Abbiamo visto tutte le tue partite contro la nostra squadra! Beh, non hai ancora vinto la coppa, ma a volte c'era mancato poco! Anche tu hai dei grandi attaccanti... Beh, hai avuto..."


translate italian e1s3_0544436e:


    d "Sì, non seguo più le notizie sul calcio femminile, a dire il vero..."


translate italian e1s3_7fc1ec03:


    julia "Comunque ! Quindi nella squadra ci sono diverse ragazze della nostra età e alcune un po' più grandi..."


translate italian e1s3_a2f9cbb1:


    julia "Nella nostra classe c'è Ruby che gioca come ala, è una con grande tecnica e molto veloce!"


translate italian e1s3_c6be00ee:


    d "Ruby? Veloce ?"


translate italian e1s3_5f857b41:


    julia "Sì, quando non parla, ti assicuro che può farlo!!!"


translate italian e1s3_5d0c78ae:


    d "Hahaha ! E tu sei veloce?"


translate italian e1s3_f2a292ff:


    julia "Io sono un centrocampista, gioco più tecnicamente per creare occasioni, con Grace dietro che..."


translate italian e1s3_55b5e56c:


    d "Grace...La rossa?"


translate italian e1s3_c16050f0:


    julia "Si si ! Lei è il nostro capitano! Gioca a centrocampo difensivo e organizza il gioco."


translate italian e1s3_3f570464:


    julia "Gioca proprio dietro di me e l'obiettivo è mandare i palloni migliori ai nostri attaccanti."


translate italian e1s3_78d34c84:


    d "Hai buoni attaccanti?"


translate italian e1s3_5c0f1f9d:


    julia "Abbiamo il meglio... Sfortunatamente è estremamente arrogante. Ma sì, è forte."


translate italian e1s3_cbea19fa:


    julia "Ebbene, parliamo del diavolo..."


translate italian e1s3_28fe81f1:


    d "Ehi, la conosco! L'ho incontrata nel taxi ieri sera! Sì, è davvero piena di sé!"


translate italian e1s3_d57cf1ce:


    d "Quando se ne andò, disse qualcosa del tipo: 'Tutti sanno...'"


translate italian e1s3_1056edaa:


    julia "Tutti conoscono Madison Forrester... Sì, lo so, lo dice spesso. Comunque, lei è la nostra stella."


translate italian e1s3_ccdb04ff:


    julia "Devo ammettere che non vado molto d'accordo con lei. Ma ha molti problemi e responsabilità che a volte la mettono sulla difensiva..."


translate italian e1s3_f572ad70:


    julia "Madison e Ruby stanno spesso insieme. Ruby ha perso i suoi genitori quando era piccola, e i genitori di Madison l'hanno accolta e praticamente adottata."


translate italian e1s3_af8699d8:


    julia "Quindi Ruby ha una fiducia cieca in Madison... E Madison è piuttosto protettiva nei confronti di Ruby..."


translate italian e1s3_95cbd31a:


    julia "Il ragazzo che vedi lì è Emerick..."


translate italian e1s3_578bed5e:


    d "Ok... Perché ha così tante persone intorno a lui?"


translate italian e1s3_a109e363:


    julia "Diciamo solo che è un pezzo forte della scuola... Ha ereditato una notevole fortuna da suo nonno e non ha paura di ostentarla..."


translate italian e1s3_78c32aa1:


    julia "Le ragazze lo odiano... non mi interessa... Ma devi stare attento con lui perché è spietato in tutto quello che fa."


translate italian e1s3_435be169:


    julia "E non ha paura di usare i suoi soldi e le sue conoscenze per ottenere ciò che vuole"


translate italian e1s3_2c3a63c7_1:


    d "Cosa intendi?"


translate italian e1s3_90077d39:


    julia "Era un campione di atletica leggera e ha una buona conoscenza di tutto ciò che riguarda gli affari..."


translate italian e1s3_96276d06:


    julia "E oltre a ciò, ha fondi... E contatti... non è qualcuno con cui vorresti incrociare..."


translate italian e1s3_ae8c5b38:


    julia "Madison soprattutto non lo sopporta perché sembra essere sempre un passo avanti a lei."


translate italian e1s3_1e0a6dea:


    d "Ok... Cercheremo di evitarlo allora!"


translate italian e1s3_ff45d902:


    julia "Se potete! E ora arrivano i problemi..."


translate italian e1s3_4593d887:


    julia "Questo è il nostro portiere, Elizabeth, tanto duro quanto misterioso."


translate italian e1s3_6012255c:


    julia "Fa parte del 'trio vincente' con sua sorella ed Emerick..."


translate italian e1s3_7507cb6f:


    julia "Fondamentalmente sono i più ricchi dell'Università... E Madison non li sopporta..."


translate italian e1s3_a385248f:


    julia "Sua sorella gemella è Sofia, il nostro difensore centrale."


translate italian e1s3_7038dddb:


    julia "È molto più accessibile di sua sorella, ma non lasciarti ingannare dai suoi modi affascinanti, è tanto seducente quanto formidabile!"


translate italian e1s3_a361dbe9:


    julia "Tra di noi li chiamiamo Rossi e Blu per via di come si distinguono..."


translate italian e1s3_82263fdf:


    d "Rosso e blu ? Ti piacciono i Pokémon?"


translate italian e1s3_d73aa6a3:


    julia "Ahah! Sì!"


translate italian e1s3_061975f3:


    julia "Ad ogni modo, penso che adesso tu abbia una buona visione del mondo che ci circonda! Spero che riuscirai a trovare il tuo posto tra..."


translate italian e1s3_48cb0ac4:


    d "Lo farò..."


translate italian e1s3_b0281f40:


    drew "Tutti gli studenti, per favore, dirigetevi verso l'anfiteatro!"


translate italian e1s3_1ddcc86e:


    julia "Wooo, il Drago è qui! Andiamo !"


translate italian e1s3_09b45265:


    sofia "Ehi tu!"


translate italian e1s3_39f080a3:


    sofia "La prossima volta che vuoi prendere qualcosa come il culo di Julia, assicurati di poterlo sostenere!"


translate italian e1s3_20cbf439:


    sofia "Chi lo sa ? Forse riceverai una ricompensa!"


translate italian e1s3_2dee059e:


    d "Tieni i tuoi cavalli Squirtle! Penso che tu non possa gestirmi..."


translate italian e1s3_0bd9218a:


    sofia "Squirtle?"


translate italian e1s3_a06175a5:


    d "Sì... E se ti facessi uno Squirter? Forse ti evolverai!"


translate italian e1s3_b01e04e8:


    sofia "È uno scherzo ?"


translate italian e1s3_eeebd644:


    d "Più tardi, Blu, ho qualcuno da incontrare!"


translate italian e1s3_c247e1f9:


    beth "Sei il francese appena arrivato?"


translate italian e1s3_af8b11bb:


    d "Oh...Hum...Sì...Perché?"


translate italian e1s3_885c5460:


    beth "Ho sentito che i francesi hanno talento in molti campi..."


translate italian e1s3_e33f6790:


    beth "non vedo l'ora di vederti in azione!"


translate italian e1s3_e921fbd3:


    d "Farò del mio meglio..."


translate italian e1s3_30b8e981:


    d "Hum... Dove andrò a sedermi?"


translate italian rubyamphi_3f651d03:


    ruby "[name] ! Vieni qui!"


translate italian rubyamphi_e0dee2f2:


    d "Hai finito con la storia del mignolo e della treccia?"


translate italian rubyamphi_a14d33f1:


    ruby "SÌ ! Gli altri non capiscono... e adesso ricordo il tuo nome!"


translate italian rubyamphi_5ed010e1:


    ruby "BENE ! Sono così emozionato ! non so cosa stia succedendo, ma è la prima volta che ci chiedono di essere qui tutti nello stesso momento!"


translate italian rubyamphi_7ef11e91:


    d "Immagino che lo scopriremo molto presto..."


translate italian juliaamphi_96104f9b:


    julia "Puoi venire a sederti con me se vuoi!"


translate italian juliaamphi_f36a5ff4:


    d "Va bene!"


translate italian juliaamphi_23835985:


    d "Porca miseria, c'è un sacco di gente qui!"


translate italian juliaamphi_85bbaf5a:


    julia "SÌ! non so perché ci hanno riuniti tutti così, ma è la prima volta che ci chiedono di venire in aula così!"


translate italian juliaamphi_7f818c7c:


    d "Penso che ci diranno cosa sta succedendo molto presto..."


translate italian graceamphi_346d228a:


    d "Posso sedermi qui?"


translate italian graceamphi_45725a3f:


    grace "Sì, naturalmente !"


translate italian graceamphi_4f482101:


    grace "Ancora una volta, mi scuso per il mio atteggiamento di ieri sera... non dovrei bere..."


translate italian graceamphi_ace85e09:


    d "non preoccuparti, è stato dimenticato!"


translate italian graceamphi_9bf01bdc:


    d "Sai perché ci hanno portato tutti qui?"


translate italian graceamphi_b12bd012:


    grace "No, ma lo scopriremo presto!"


translate italian madisonamphi_2b7db42d:


    mad "non venire a disturbarmi adesso, non è il momento..."


translate italian madisonamphi_9ea9e686:


    d "non sono qui per quello... E buongiorno anche a te..."


translate italian madisonamphi_2d925ea2:


    mad "non capisco perché ci chiedono di essere qui tutti nello stesso momento..."


translate italian madisonamphi_4874636b:


    mad "Devo allenarmi in palestra..."


translate italian madisonamphi_5d9c6a27:


    d "Penso che lo scopriremo molto presto."


translate italian amphi_93de61e7:


    drew "Cari studenti..."


translate italian amphi_42e38028:


    drew "Sono orgogliosa di presentarvi il signor Orushi, direttore della Orushi Corp. e direttore principale del progetto BEST!"


translate italian amphi_f0f28a42:


    rufus "MIAO"


translate italian amphi_b33469a9:


    orushi "Ehm... Signor Rufus, per favore!"


translate italian amphi_b241a330:


    ruby "Oh, un gatto parlante! Quello è Tom?"


translate italian amphi_b007ce34:


    "Ruby!!!" with vpunch


translate italian amphi_edd537f7:


    ruby "Ok ok..."


translate italian amphi_a79dd47c:


    rufus "FSHHHHHHHHHHHHH"


translate italian amphi_bd8ba672:


    orushi "Buona giornata, cari studenti! Sono Orushi, della Orushi Corp."


translate italian amphi_99c49339:


    orushi "Vi starete chiedendo perché siete stati portati nell'anfiteatro proprio all'inizio del vostro primo giorno."


translate italian amphi_7a42adda:


    orushi "Comprendo la vostra sorpresa."


translate italian amphi_8fadeb0a:


    orushi "Ora fate parte di un programma speciale per il quale siete stati selezionati."


translate italian amphi_c98428d2:


    "(Studenti) Cosa?" with vpunch


translate italian amphi_fd03bb4a:


    orushi "Questo programma di valutazione, il B.E.S.T, determinerà tra i 100 partecipanti che siete, un solo studente che riuscirà a superare i test e a distinguersi da tutti gli altri."


translate italian amphi_152c62ad:


    orushi "Sarete tutti in competizione l'uno contro l'altro. Durante il primo semestre si terranno dei test per determinare chi tra voi è il migliore."


translate italian amphi_3e180d9d:


    orushi "Possono svolgersi di giorno o di notte, individualmente o in gruppo, e verrà dato un annuncio quando sarà il momento di riunirsi..."


translate italian amphi_d6132e39:


    orushi "Al termine di questa competizione, la persona selezionata riceverà il titolo di MIGLIOR studente, un assegno di $ 500.000 e una posizione all'interno della Orushi Corp come assistente del direttore."


translate italian amphi_2b553e94:


    orushi "So che questa è una posizione ambita e che molti di voi chiedono solo di diventare stagisti presso la Orushi Corp."


translate italian amphi_843ce427:


    orushi "Non perdete quindi questa occasione e, soprattutto, mostrate tutto il vostro talento durante i test."


translate italian amphi_7a414ab7:


    orushi "Siete 100 e, dopo ogni prova, una parte verrà eliminata."


translate italian amphi_18d675f3:


    orushi "Il primo test manterrà tra voi 50 studenti."


translate italian amphi_6ff63c68:


    orushi "Questa sarà una prova a due squadre. Il computer determinerà il vostro compagno di squadra per questa prova."


translate italian amphi_569ee4ce:


    orushi "Dovrete terminare la prova ed essere tra le prime 25 squadre, altrimenti sarete eliminati."


translate italian amphi_0367d4b5:


    orushi "Ora la signora Drew vi dirà chi sono le squadre!\nIn bocca al lupo e ricordate: siate sempre i migliori!"


translate italian amphi_7b0099ba:


    drew "[name] con Ruby!"


translate italian amphi_17791e2a:


    ruby "Grande ! Siamo insieme per questo!"


translate italian amphi_0b246b84:


    d "Sì ! Spero che faremo bene!"


translate italian amphi_739bdf64:


    ruby "non preoccuparti ! Corro veloce! Vai e seguimi... se puoi!"


translate italian amphi_882aa9f2:


    d "Vedremo..."


translate italian amphi_7ad0cb20:


    drew "[name] con Julia!"


translate italian amphi_4378768a:


    julia "OH ! Siamo insieme !"


translate italian amphi_f05c4e0f:


    d "Sì ! Spero di non deludervi!"


translate italian amphi_4bccb5b2:


    julia "NO ! Devi mantenere una buona mentalità! Sei un vincitore!"


translate italian amphi_f9311cf0:


    d "Va bene ! Vinceremo questa prova insieme!"


translate italian amphi_238ae119:


    julia "Questo è quello che voglio sentire!"


translate italian amphi_b19db6ac:


    drew "[name] con Grace!"


translate italian amphi_ff39ce3d:


    grace "Sembra che siamo nella stessa squadra per questo!"


translate italian amphi_64256f24:


    d "Sì... non sei delusa?"


translate italian amphi_1142e283:


    grace "Ovviamente no ! non avrei potuto desiderare un compagno di squadra migliore per una prova! Sei forte e sembri allenato!"


translate italian amphi_a33da4f1:


    d "Devo mostrarti il ​​mio lato migliore!"


translate italian amphi_5c729483:


    grace "Sicuro ! Vinciamo questo!"


translate italian amphi_6ec0e013:


    drew "[name] con Madison!"


translate italian amphi_3cbbdcb1:


    mad "Dio mio...."


translate italian amphi_e5d8bebc:


    d "Ok... dobbiamo stare insieme per questo..."


translate italian amphi_04c5548f:


    mad "non ho scelta. Ma forse è un bene che... Sei... In forma...."


translate italian amphi_0d217974:


    d "Anche tu..."


translate italian amphi_4845a04a:


    mad "Vedremo, seguitemi e non perdete tempo!"


translate italian amphi_0e114910:


    d "non lo farò."


translate italian amphi_39df151c:


    orushi "Comunque non vi farò aspettare ancora..."


translate italian amphi_d5a82ce4:


    orushi "Oh, quasi dimenticavo! Questo sarà anche un test di velocità! Avrete a disposizione 10 minuti prima dell'inizio del corso."


translate italian amphi_1abbe7bc:


    orushi "Il percorso inizierà nei pressi dello stadio con un forte rumore... Lo riconoscerete..."


translate italian amphi_a22e4927:


    orushi "Come ho appena detto, dieci minuti per prepararsi e parte il conto alla rovescia..."


translate italian amphi_6e8c0661:


    orushi "Ora!"


















translate italian e1s3_cf35a02d:


    julia "Siamo una delle migliori squadre accademiche di calcio del paese! E ci si aspetta che alcuni di noi si uniscano alla squadra nazionale!"


translate italian e1s3_050733da:


    drew "Tutti gli studenti, per favore, recatevi in ​​auditorium!"


translate italian amphi_48029896:


    orushi "Ti starai chiedendo perché sei stato portato nell'auditorium proprio all'inizio del tuo primo giorno."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
