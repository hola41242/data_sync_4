

translate italian e1s1_e5c597fd:


    dpense "Tutti conoscono Madison Forrester... io no!"


translate italian e1s1_a70be8a3:


    dpense "Perché questa ragazza è così cattiva?"


translate italian e1s1_b545e893:


    dpense "È incredibilmente bella, ma non riesco a sopportare questa sua visione..."


translate italian e1s1_c92b4616:


    dpense "E non so dove siano i miei bagagli..."


translate italian e1s1_e121c6a0:


    d "Autista ! Quanto siamo lontani dall'Università?"


translate italian e1s1_8665f3d9:


    "Ce l'abbiamo fatta!" with vpunch


translate italian e1s1_40668af7:


    d "Quella non è l'Università! Quello è un muro!"


translate italian e1s1_42198499:


    "Lei mi ha chiesto di lasciarti qui, ragazzo."


translate italian e1s1_79a98cf6:


    d "Lei ?"


translate italian e1s1_371dcb1d:


    d "Chi è lei ?"


translate italian e1s1_e6a3617d:


    d "Se n'è andato!"


translate italian e1s1_d8b3be19:


    dpense "Ok... Dove sono? Chi è questa 'Lei' che ha chiesto all'autista di lasciarmi vicino a un muro?"


translate italian e1s1_c5e69234:


    dpense "Quante domande senza risposta..."


translate italian e1s1_9106fdeb:


    "Benvenuto in America, [name]"


translate italian e1s1_6f4899e6:


    d "Chi...Chi sei? E come fai a sapere il mio nome?"


translate italian e1s1_d6d5b2b2:


    "Sono la signora Drew, l'assistente del signor Orushi della Orushi Corp. Sono anche il direttore dell'Università."


translate italian e1s1_295d0fd1:


    drew "So tutto quello che ho bisogno di sapere su di te, [name]."


translate italian e1s1_ec77f0b1:


    drew "Vieni dalla Francia, uno studente leggermente al di sopra della media, con alcune capacità atletiche dovute all'allenamento e alla buona salute."


translate italian e1s1_d64d0926:


    d "Che cosa ? Mi stavi spiando?"


translate italian e1s1_ab50beb6:


    drew "Spiarti? Pensi di essere abbastanza importante da permetterci di mandare qualcuno in Francia solo per spiarti, ragazzo?"


translate italian e1s1_7eeb58f1:


    drew "No certo che no."


translate italian e1s1_b3db403f:


    drew "Sei solo un numero in un file. In questo caso, sei il novantesimo."


translate italian e1s1_8b86fe0d:


    d "90esimo? 90esimo di cosa?"


translate italian e1s1_e1b74faa:


    drew "Ti ho già detto troppo... Domani capirai."


translate italian e1s1_bc25ba71:


    drew "Ora, se vuoi scusarmi, ti presenterò mia figlia. Ti mostrerà il tuo dormitorio e la tua stanza nel campus."


translate italian e1s1_8fd1e978:


    drew "Prego entra."


translate italian e1s1_e714ec0e:


    drew "Vedrai che mia figlia è gentile e..."


translate italian e1s1_06bd448a:


    drew "UBRIACA ???" with hpunch


translate italian e1s1_e8290730:


    drew "Grace! Cosa stai facendo? Perché stai bevendo da sola a quest'ora? Dovresti prepararti per domani!"


translate italian e1s1_e350ad45:


    grace "Dai... Puoi smetterla di urlarmi contro in questo modo? Ho un mal di testa micidiale!"


translate italian e1s1_67eae1bf:


    drew "Grace! Sii consapevole delle tue parole! Abbiamo un ospite, quindi per favore abbassa i toni e presentati adeguatamente!"


translate italian e1s1_3dbeaa27:


    grace "Oh mio Dio... Ok, lo farò. Ma devi provare questo champagne, è fantastico!"


translate italian e1s1_c1eff7a6:


    grace "Scusa, io sono Grace e tu..."


translate italian e1s1_d7ec0052:


    grace "Il Groper!!!"


translate italian e1s1_8bb9bfa2:


    grace "Mamma, questo è un pervertito!"


translate italian e1s1_2f61cd1f:


    grace "Il Redneck!!!"


translate italian e1s1_7149415c:


    grace "Mamma, questo ragazzo è davvero bello! Ha parlato con Julia prima e anche lei non sembra immune al suo fascino!"


translate italian drewsuite_c214990b:


    drew "Andiamo Grace, non è il modo corretto di salutare un ospite!"


translate italian drewsuite_e1aae156:


    grace "Ma..."


translate italian drewsuite_f9ed221e:


    drew "Niente ma!"


translate italian drewsuite_d584d61f:


    drew "Mi scuso, deve essere stato un malinteso..."


translate italian drewsuite_3f3108a6:


    drew "[name] questa è Grace, figlia mia."


translate italian drewsuite_51b54e3f:


    drew "E Grace, lui è [name], uno studente francese che starà con noi all'Università per questo semestre."


translate italian drewsuite_0cb358b4:


    grace "Sì... va bene, mamma..."


translate italian drewsuite_db71b97f:


    grace "Mi dispiace [name], ho bevuto un po' troppo e tendo a parlare troppo quando sono alticcia..."


translate italian drewsuite_4523b2d5:


    drew "Quindi ora che ci siamo occupati di questo..."


translate italian drewsuite_696a8742:


    drew "Non penso che tu sia nelle condizioni di mostrare a [name] la sua stanza e il dormitorio, Grace..."


translate italian drewsuite_4f707c1b:


    grace "Certo che posso... Oof!" with vpunch


translate italian drewsuite_24e2b9f5:


    drew "Hai bisogno di riposarti e ho molto da fare."


translate italian drewsuite_981fef1c:


    drew "Quindi [name], ho bisogno che tu rimanga qui per la notte e tenga d'occhio Grace per assicurarti che non continui a bere."


translate italian drewsuite_89842c29:


    drew "Puoi dormire sul divano e domani alle 8 qualcuno ti accompagnerà nella tua stanza."


translate italian drewangry_30cf94b3:


    drew "Devo avvisarti che non è un buon inizio se mi parli in questo modo. Devo ricordarti che sono il direttore dell'Università, e devi tenere a mente le tue tasse scolastiche..."


translate italian drewangry_bff2d64d:


    d "Mi dispiace, signora Drew."


translate italian drewangry_f64c1619:


    drew "Preferisco che... devo andare! Ci vediamo domani alle 9, e non tardate!!!"


translate italian drewangry_6ed0d999:


    d "Io ci sarò..."


translate italian drewok_e22ffbfe:


    drew "Questo è quello che speravo... ho riposto molta fiducia in te [name]. Non deludermi mai... e sarai ricompensato."


translate italian drewok_12b3f958:


    d "Ci proverò, signora Drew"


translate italian drewok_792664f7:


    drew "Devo andare ! Ci vediamo domani alle 9 e non tardate!!!"


translate italian drewok_6ed0d999:


    d "Io ci sarò..."


translate italian gracetip_2181f854:


    cr "Dammi solo un momento... voglio assicurarmi che tu comprenda appieno le regole di questo gioco!"


translate italian gracetip_9674208e:


    cr "Anche se credo che tu sia intelligente, mi piacerebbe controllare le tue statistiche prima di procedere ulteriormente nella storia."


translate italian gracetip_216f0561:


    cr "Quindi diamo un'occhiata! Per favore apri la finestra delle statistiche."


translate italian gracetip_ac943f4c:


    cr "Sembra che tu abbia già preso alcune decisioni che hanno influenzato il tuo personaggio."


translate italian gracetip_6a85a930:


    cr "Per ora non ha molta importanza..."


translate italian gracetip_e4bf9eaf:


    cr "... ma forse non provare a palpare Julia sull'aereo avrebbe potuto cambiare la percezione delle altre ragazze?"


translate italian gracetip_666e6ece:


    cr "...ma forse provare a palpare Julia sull'aereo avrebbe potuto cambiare la percezione delle altre ragazze?"


translate italian gracetip_858181c8:


    cr "Vedete, tutte le statistiche possono cambiare in tempi relativamente brevi."


translate italian gracetip_737ef232:


    cr "Ti consiglierei di effettuare più salvataggi, con scelte diverse, poiché presto influenzerà gli eventi futuri."


translate italian gracetip_7d746e81:


    cr "Ok, torniamo al gioco adesso. Divertiti!!!"


translate italian gracetip_6c4282e7:


    d "Allora, Grace, giusto?"


translate italian gracetip_8a13d7b7:


    grace "Si sono io..."


translate italian gracetip_2a9d73d8:


    d "Hai bisogno di aiuto per qualcosa?"


translate italian gracetip_2e0cb4e0:


    grace "No, sto bene... andrò semplicemente nella mia stanza a dormire... Domani sarà dura..."


translate italian gracetip_d298f5af:


    d "Certamente..."


translate italian gracetip_9430e9e5:


    grace "Oooooh...Ahhhh" with vpunch


translate italian gracetip_f09681f9:


    grace "Sei il mio eroe !"


translate italian gracetip_ab50bccd:


    d "Non ne sono sicuro, ma ho detto a tua madre che mi sarei preso cura di te..."


translate italian gracetip_d692729b:


    grace "Quindi... Forse dovrei allenarmi di più e saltare il bagno serale in piscina."


translate italian gracetip_6155d7c2:


    grace "Puoi lasciarmi andare adesso..."


translate italian gracetip_b91aafb4:


    cr "Qui sono disponibili alcune scelte che potrebbero essere nascoste, a seconda delle statistiche richieste..."


translate italian gracetip_4b67e7da:


    cr "In questo caso, avrai la scelta oppure no, e potresti o meno essere in grado di fare clic sul pulsante a seconda di quanto si fida di te."


translate italian gracetip_79574a66:


    cr "Per aiutarti, il tuo livello di istruzione deve essere 2 o superiore affinché lei possa fidarsi di te."


translate italian gracetip_bdaabba9:


    grace "Avresti potuto aiutarmi!"


translate italian gracetip_fde4e366:


    d "Mi dispiace che tu sia caduto troppo in fretta!"


translate italian gracetip_62ef3f60:


    grace "Stai dicendo che sono grasso?"


translate italian gracetip_d7d0f724:


    d "No, no!!! Ovviamente no ! Sei fantastico !"


translate italian sitcouch_2e864f0f:


    grace "Okay bene... ti lascio qui... non rompere nulla per favore altrimenti mia madre si arrabbierà..."


translate italian sitcouch_5e1e37ee:


    d "Certo... buonanotte Grace"


translate italian sitcouch_9556c425:


    grace "Buona notte"


translate italian roomgrace_bee99c83:


    grace "Sei forte !"


translate italian roomgrace_ef94450c:


    d "Forse mi sono allenato un po'..."


translate italian roomgrace_c95d349c:


    grace "Forte e bello... Julia ha buon gusto..."


translate italian roomgrace_e9b720f7:


    d "Julia?"


translate italian roomgrace_45538cff:


    grace "zzz"


translate italian roomgrace_1678ca47:


    dpense "Lei stà dormendo ?"


translate italian roomgrace_d0c6195d:


    dpense "Dio mio..."


translate italian roomgrace_14601ec4:


    dpense "Devo scoprire dov'è la sua stanza..."


translate italian roomgrace_5015de77:


    dpense "Sì, questa deve essere la sua stanza..."


translate italian roomgrace_d4648271:


    dpense "È accogliente!"


translate italian roomgrace_19a6086b:


    dpense "La metto sul suo letto..."


translate italian roomgrace_3789c9b9:


    dpense "Ecco qua..."


translate italian roomgrace_44d8ac77:


    grace "Grazie, mio ​​eroe...!"


translate italian roomgrace_15696b9a:


    dpense "Che cosa ???"


translate italian roomgrace_7e765a2f:


    grace "Un eroe forte e bello..."


translate italian roomgrace_20a391a1:


    dpense "Pensa che me ne sia andato?..."


translate italian roomgrace_0e0b4bc1:


    dpense "Lei è bellissima..."


translate italian roomgrace_3f712c16:


    dpense "Forse dovrei spogliarla?"


translate italian roomgrace_e9a7858f:


    dpense "No, penserà che sono un pervertito..."


translate italian roomgrace_3e2f8822:


    dpense "Dormi bene, rossa..."


translate italian couch_d5603e5f:


    dpense "Ok... ora penso che sia ora di dormire."


translate italian couch_109f25a8:


    dpense "Questa giornata è stata piuttosto movimentata..."


translate italian couch_4003f62c:


    dpense "Domani alle nove ha detto... Va bene, signora Drew..."

translate italian strings:


    old "EPISODE 1 {p} \n Natural Selection"
    new "EPISODIO 1 {p} \n Selezione naturale"


    old "You think I'm a babysitter ? [TEMP1!t]"
    new "Pensi che io sia una babysitter? [TEMP1!t]"


    old "Sure Mrs Drew ! I'll take care of her. [TEMP2!t]"
    new "Certo, signora Drew! Mi prenderò cura di lei. [TEMP2!t]"


    old "Catch her [TEMP1!t]"
    new "Prendila [TEMP1!t]"


    old "Don't [TEMP2!t]"
    new "Non [TEMP2!t]"


    old "Do you want me to help you to your room ? [TEMP3!t]"
    new "Vuoi che ti aiuti nella tua stanza? [TEMP3!t]"


    old "Oh ! Yes ! Sure ! [TEMP4!t]"
    new "OH ! SÌ ! Sicuro ! [TEMP4!t]"


    old "YOUR SPORT HAS INCREASED"
    new "IL TUO SPORT È AUMENTATO"


















translate italian e1s1_432555d0:


    dpense "Quella ragazza Madison sembra popolare. Non ho la minima idea di lei, però."


translate italian e1s1_ac1be3dc:


    dpense "Perché era così cattiva?"


translate italian e1s1_97d011b3:


    dpense "È incredibilmente bella, ma non sopporto di avere a che fare con lei..."


translate italian e1s1_f60858d9:


    dpense "E non so dove siano i miei bagagli."


translate italian e1s1_473f6b00:


    d "Autista! Quanto siamo lontani dall'Università?"


translate italian e1s1_ecd642ad:


    "Siamo arrivati, signore." with vpunch


translate italian e1s1_9ea7faaf:


    d "Quella non è l'università. Quello è un muro!"


translate italian e1s1_e475c27b:


    "Mi ha chiesto di accompagnarti qui, amico."


translate italian e1s1_7481d909:


    d "Lei?"


translate italian e1s1_4b13a5b2:


    d "Chi è lei?"


translate italian e1s1_88e451f1:


    dpense "Okay. Dove mi trovo? Chi è questa 'Lei' menzionata dall'autista e perché mi ha fatto scendere a un muro?"


translate italian e1s1_7984c0cd:


    dpense "Non ho idea di cosa stia succedendo."


translate italian e1s1_709d6e47:


    d "Chi...chi sei? E come fai a sapere il mio nome?"


translate italian e1s1_c1df6248:


    "Sono la signora Drew, assistente del signor Orushi della Orushi Corp. Sono anche il preside dell'università."


translate italian e1s1_0435afa2:


    drew "Vieni dalla Francia, sei uno studente leggermente sopra la media, con discrete capacità atletiche dovute a una vita dedicata allo sport e a una buona genetica."


translate italian e1s1_fbe90eca:


    d "Cosa? Mi stai spiando?"


translate italian e1s1_2df3db58:


    drew "Ti spiano? Pensi di essere abbastanza importante da farci mandare qualcuno in Francia solo per spiarti, ragazzo?"


translate italian e1s1_3f9e51b2:


    drew "No. Ovviamente no."


translate italian e1s1_ff2c6a79:


    d "90°? Il 90° cosa?"


translate italian e1s1_9dfdb7ea:


    drew "Ti ho già detto abbastanza. Domani, capirai pienamente."


translate italian e1s1_f32fa33e:


    drew "UBRIACA?" with hpunch


translate italian e1s1_7cad2307:


    drew "Grace! Cosa stai facendo? Perché stai bevendo da sola a quest'ora? Dovresti prepararti per domani!"


translate italian e1s1_edf991e2:


    grace "Dai... puoi smetterla di urlare contro di me, per favore? Ho un mal di testa tremendo."


translate italian e1s1_3c64e8bc:


    drew "Grace! Sii consapevole di te stessa! Abbiamo un ospite, quindi per favore modera i toni e presentati in modo appropriato!"


translate italian e1s1_6d964eef:


    grace "Oh mio Dio... okay. Lo farò, ma devi provare questo Champagne, è fantastico!"


translate italian e1s1_2b0b620b:


    grace "Mi dispiace, io sono Grace e tu sei..."


translate italian e1s1_c989b760:


    grace "Il palpeggiatore!"


translate italian e1s1_8c026b32:


    grace "Mamma, questo tizio è un pervertito!"


translate italian e1s1_a7185c32:


    grace "Il bifolco!"


translate italian e1s1_661d57e7:


    grace "Mamma, questo ragazzo è davvero affascinante! Ha parlato con Julia sull'aereo e anche lei non sembra immune al suo fascino!"


translate italian drewsuite_f4948315:


    drew "Dai Grace, questo non è il modo giusto per accogliere un ospite."


translate italian drewsuite_61724c00:


    drew "Mi scuso a nome di mia figlia, deve esserci stato un malinteso."


translate italian drewsuite_9435ba4d:


    drew "[name], questa è Grace, mia figlia."


translate italian drewsuite_d974a255:


    drew "E Grace, questo è [name], uno studente francese in scambio che soggiornerà con noi all'università per questo semestre."


translate italian drewsuite_b775e404:


    grace "Okay, okay, mamma. Ho capito."


translate italian drewsuite_e08c517d:


    grace "Mi dispiace [name], ho bevuto un po' troppo e tendo ad eccitarmi facilmente quando sono alticcia."


translate italian drewsuite_862b2f2f:


    drew "Ecco fatto."


translate italian drewsuite_845674e8:


    drew "Non credo che tu sia in grado di mostrargli la sua stanza e il dormitorio, Grace."


translate italian drewsuite_eb162a64:


    grace "Certo che posso... Uffa!" with vpunch


translate italian drewsuite_96f9ff5a:


    drew "Hai bisogno di riposarti un po', signorina, e io ho un sacco di cose da fare."


translate italian drewsuite_58bc0ab8:


    drew "[name], potresti restare qui per la notte e tenere d'occhio Grace per assicurarti che non continui a bere?"


translate italian drewsuite_22d14705:


    drew "Puoi dormire sul divano e domani mattina ti farò accompagnare in camera da qualcuno."


translate italian drewangry_f8542dc5:


    drew "Devo avvertirti che non è un buon inizio se mi parli in questo modo. Devo ricordarti che sono il preside dell'università e che devi mantenere la tua fedina penale pulita come studente in scambio."


translate italian drewangry_ecdd06d1:


    drew "Molto meglio, giovanotto. Devo uscire. Ci vediamo domani alle nove in punto. I ritardi non saranno tollerati."


translate italian drewangry_c288903d:


    d "Io ci sarò."


translate italian drewok_05586da9:


    drew "Questo è ciò che speravo di sentire. Ho riposto molta fiducia in te, [name]. Non deludermi e mi assicurerò che tu venga ricompensato."


translate italian drewok_60e769c1:


    d "Ci proverò, signora Drew."


translate italian drewok_e2d829c9:


    drew "Devo uscire. Ci vediamo domani alle nove in punto. I ritardi non saranno tollerati."


translate italian drewok_c288903d:


    d "Io ci sarò."


translate italian gracetip_33a7f69e:


    cr "Datemi solo un momento. Voglio assicurarmi che abbiate capito appieno le regole di questo gioco."


translate italian gracetip_05c5b6e7:


    cr "... ma forse essere più diretti con Julia sull'aereo avrebbe potuto cambiare la percezione delle altre ragazze?"


translate italian gracetip_39949567:


    cr "Ti consiglio di effettuare più salvataggi, con scelte diverse, poiché ciò influenzerà gli eventi futuri."


translate italian gracetip_b0177253:


    cr "Ok, torniamo al gioco ora. Divertitevi!"


translate italian gracetip_faf676c5:


    d "Allora, Grace, giusto?"


translate italian gracetip_a1ed8ae4:


    grace "Sì, sono io."


translate italian gracetip_8a81dd88:


    d "Hai bisogno di aiuto per qualcosa?"


translate italian gracetip_e67f97c2:


    grace "No, sto bene. Vado in camera mia e dormo. Domani sarà dura."


translate italian gracetip_4d710522:


    d "Certo."


translate italian gracetip_eb17abbf:


    grace "Ooooh...ahhhh" with vpunch


translate italian gracetip_56de7896:


    grace "Grazie per il salvataggio, eroe!"


translate italian gracetip_2c5bbbe4:


    d "Non so se mi comporterei da eroe, ma ho detto a tua madre che mi sarei preso cura di te."


translate italian gracetip_ccb7a8bc:


    grace "Forse dovrei concentrarmi sull'allenamento e smettere di saltare le nuotate serali in piscina."


translate italian gracetip_6522caea:


    cr "Qui ci sono alcune scelte che potrebbero essere nascoste, a seconda delle statistiche richieste."


translate italian gracetip_de6b2efc:


    cr "In questo caso, potresti avere la possibilità di scegliere o meno, e l'opzione potrebbe aprirsi a seconda di quanta fiducia lei ripone in te."


translate italian gracetip_b687572e:


    grace "Perché non mi hai preso?!"


translate italian gracetip_66025636:


    d "Mi dispiace che tu sia caduto troppo in fretta!"


translate italian gracetip_16464349:


    grace "Stai dicendo che sono grasso?"


translate italian gracetip_3cd51a3d:


    d "Cosa, no! Certo che no! Sei stupenda!"


translate italian sitcouch_63282405:


    grace "Ok, bene, ti lascio qui. Non rompere niente per favore o mia madre sarà furiosa."


translate italian sitcouch_507244c0:


    d "Certo. Buonanotte, Grace."


translate italian sitcouch_8065de9f:


    grace "Buona notte."


translate italian roomgrace_a49d7fcc:


    grace "Sei forte!"


translate italian roomgrace_c4cdd678:


    d "Di tanto in tanto potrei andare in palestra."


translate italian roomgrace_54eeaa13:


    grace "Forte e bello. Julia ha buon gusto..."


translate italian roomgrace_5a7b8daf:


    d "Julia?"


translate italian roomgrace_7248392c:


    dpense "Devo scoprire dov'è la sua stanza."


translate italian roomgrace_fd6e80d1:


    dpense "Sì, questa deve essere la sua stanza."


translate italian roomgrace_5ffba06b:


    dpense "Sembra accogliente!"


translate italian roomgrace_a203b104:


    dpense "La metterò semplicemente sul letto."


translate italian roomgrace_fdaa5493:


    dpense "Ecco fatto."


translate italian roomgrace_6e4512a7:


    grace "Grazie, mio ​​eroe!"


translate italian roomgrace_2c73141e:


    dpense "Che cosa?"


translate italian roomgrace_489910c7:


    dpense "Pensa che me ne sia andato?"


translate italian roomgrace_f16dac9a:


    dpense "Lei è bellissima."


translate italian roomgrace_4bebf18a:


    dpense "Forse dovrei aiutarla a spogliarsi?"


translate italian roomgrace_308174f2:


    dpense "No, penserà che sono un pervertito."


translate italian couch_af05b7c2:


    dpense "Ok, credo sia ora di andare a letto."


translate italian couch_760535b6:


    dpense "Questa giornata è stata piuttosto movimentata."


translate italian couch_fd086364:


    dpense "Domani alle nove ha detto. Va bene, signora Drew, non la deluderò."

translate italian strings:


    old "You think I'm a babysitter? [TEMP1!t]"
    new "Pensi che io sia una babysitter? [TEMP1!t]"


    old "Sure Mrs. Drew. I'll take care of her. [TEMP2!t]"
    new "Certo, signora Drew. Mi prenderò cura di lei. [TEMP2!t]"


    old "Oh! Yes, I'll do that. [TEMP4!t]"
    new "Oh! Sì, lo farò. [TEMP4!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
