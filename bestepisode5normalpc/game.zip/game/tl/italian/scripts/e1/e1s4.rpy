

translate italian e1s4_db02abfd:


    dpense "Le ragazze sono andate a cambiarsi negli spogliatoi."


translate italian e1s4_3fa91343:


    dpense "non ho nessuna attrezzatura, per fortuna indosso i pantaloni della tuta..."


translate italian e1s4_98a88ee3:


    dpense "Ebbene... mi hanno detto di prendere il sentiero del boschetto verso lo stadio..."


translate italian e1s4_9a15f8ed:


    dpense "Seguirò gli altri che sembrano andare in quella direzione..."


translate italian e1s4_2ead2b4e:


    dpense "Wow, questa è un'altra cosa..."


translate italian e1s4_1bab997e:


    dpense "Beh, sembra che dovrò saltare, fare la trave e arrampicarmi su un muro altissimo..."


translate italian e1s4_c9218e91:


    dpense "È come un percorso a ostacoli..."


translate italian e1s4_0ed28279:


    d "Cosa stanno facendo?"


translate italian e1s4_1b095f4a:


    dpense "non ha detto che la gara inizia esattamente tra 10 minuti?"


translate italian e1s4_9d966740:


    d "Oh sì... okay..."


translate italian e1s4_81359d8a:


    mad "Fatti trovare pronto, appena suona la campanella andiamo dritti..."


translate italian e1s4_d08d7bd8:


    d "Sono pronto... Bel vestito..."


translate italian e1s4_1cee3c7b:


    mad "Sì, beh tieni gli occhi davanti a te!"


translate italian e1s4_0277facd:


    ruby "Ti sono mancata?"


translate italian e1s4_db9355e4:


    d "Ehm, sì, diciamo che... temevo soprattutto che fossi in ritardo."


translate italian e1s4_fdfcc728:


    ruby "Beh, in realtà Grace era alle prese con il suo outfit... quindi abbiamo perso un po' di tempo..."


translate italian e1s4_e1eac1fe:


    d "Hum... parlando di outfit... Cos'è questo?"


translate italian e1s4_15b19890:


    ruby "OH !!! È il mio stile Kimono!"


translate italian e1s4_58b90a37:


    d "Stile kimono? Ma non siamo su un tatami!"


translate italian e1s4_62d07dbf:


    ruby "Lo so, ma il mio completo da corsa è... l'ho perso..."


translate italian e1s4_474f9baa:


    d "Ruby..."


translate italian e1s4_af65d736:


    ruby "non preoccuparti ! Ciò aumenterà la mia agilità!"


translate italian e1s4_54658857:


    julia "Così sei pronto?"


translate italian e1s4_5631dc25:


    d "Sì, non vedo l'ora di vedere di cosa sei capace!"


translate italian e1s4_3077b247:


    julia "Si tratta più di ciò di cui sei capace!"


translate italian e1s4_f85d2bb0:


    d "non preoccuparti per me."


translate italian e1s4_d07ece43:


    grace "Scusa, eravamo quasi in ritardo..."


translate italian e1s4_df8f2fbb:


    d "Finché sei qui prima dell'inizio della gara, va tutto bene!"


translate italian e1s4_b0b96245:


    grace "Il mio outfit non era molto facile da indossare..."


translate italian e1s4_ff44cb0f:


    d "Sembra fantastico! Sembri Lara Croft!"


translate italian e1s4_5dba12c1:


    grace "Già, beh non sono agile come lei!"


translate italian e1s4_3f58bfa9:


    d "Eppure guarda cosa abbiamo davanti!"


translate italian e1s4_c41a91e8:


    grace "Lo faremo passo dopo passo e dovrebbe andare tutto bene."


translate italian e1s4_5470ffc5:


    d "Stai facendo stretching?"


translate italian e1s4_40f16f49:


    ruby "Sì ! non so cosa dovremo fare quindi..."


translate italian e1s4_b2b5a412:


    ruby "Pensi che suoneranno un certo suono per l'inizio della gara?"


translate italian e1s4_4f399a57:


    d "non sono sicuro che sia davvero così importante..."


translate italian e1s4_5048dc99:


    ruby "No, ma voglio dire, sarà come una canzone, come 'I'm a survival'? O un grande corno? O qualcos'altro..."


translate italian e1s4_f097499a:


    ruby "Questo risponde alla mia domanda."


translate italian e1s4_85a51d50:


    d "Eh???"


translate italian e1s4_dacec8f6:


    dpense "Va bene..."


translate italian e1s4_5a7f4942:


    dpense "Devo saltare..."


translate italian e1s4_e3de31ff:


    dpense "non perdere tempo...."


translate italian e1s4_e5d68ef1:


    dpense "non cadere adesso..."


translate italian e1s4_3afc310b:


    dpense "Madison..."


translate italian e1s4_bef27060:


    dpense "È veloce!!!"


translate italian e1s4_11722e7d:


    julia "AHHHHH!"


translate italian e1s4_fb09c47b:


    julia "Pervertito...ma un gentiluomo!"


translate italian e1s4_1d8d941c:


    d "non sono..."


translate italian e1s4_ef7f41a7:


    julia "Lo so, bello!"


translate italian e1s4_392c0bca:


    julia "Grazie !"


translate italian e1s4_d1328c7d:


    d "Nessun problema..."


translate italian e1s4_c45d2021:


    julia "Lo sapevo che eri un gentiluomo!"


translate italian e1s4_3287f850:


    dpense "Devo unirmi a Madison!"


translate italian e1s4_fb09c47b_1:


    julia "Pervertito...ma un gentiluomo!"


translate italian e1s4_1d8d941c_1:


    d "non sono..."


translate italian e1s4_ef7f41a7_1:


    julia "Lo so, bello!"


translate italian e1s4_392c0bca_1:


    julia "Grazie !"


translate italian e1s4_d1328c7d_1:


    d "Nessun problema..."


translate italian e1s4_c45d2021_1:


    julia "Lo sapevo che eri un gentiluomo!"


translate italian e1s4_3287f850_1:


    dpense "Devo unirmi a Madison!"


translate italian e1s4_ec5f501a:


    d "Datemi la mano, ragazze!"


translate italian e1s4_d2ca9147:


    grace "Grazie !"


translate italian e1s4_861f2793:


    ruby "Grazie!"


translate italian trial2_55085e54:


    d "Salta ! Ti darò una spinta!"


translate italian trial3_d9e39fb2:


    d "Madison! Dove si trova lo stadio ?"


translate italian trial3_125278f2:


    mad "Subito dopo la collina!"


translate italian trial3_5e6cd201:


    d "Avanti Madison! Possiamo farlo !"


translate italian trial3_4c002cd5:


    d "Julia! Dove si trova lo stadio ?"


translate italian trial3_3427b926:


    julia "Subito dopo la collina!"


translate italian trial3_c14b1157:


    julia "non mi hai aiutato... Perché dovrei aiutarti?"


translate italian trial3_b0c2fcfb:


    julia "Adesso vai via !"


translate italian trial3_2a135b5e:


    dpense "Ok... è arrabbiata con me..."


translate italian trial3_f400f290:


    d "Sù ragazze ! Possiamo farlo !"


translate italian trial3_f400f290_1:


    d "Sù ragazze ! Possiamo farlo !"


translate italian trial4_d9f3189b:


    drew "È NECESSARIO TROVARE IL PROPRIO BAGAGLIO E PARTIRE CON ESSO QUANDO SI ARRIVA ALL'ANFITEATRO."


translate italian trial4_1e17d9fa:


    d "Uhm... Va bene... Ma dove troviamo i bagagli in uno stadio grande come questo?"


translate italian trial4_fc9b9b9d:


    mad "Apri gli occhi, Genio..."


translate italian trial4_93a57ae7:


    d "Ehm? OH !!!"


translate italian trial4_ef3a2b6b:


    mad "NO...!"


translate italian trial4_c3051f60:


    mad "No, no, no, no!"


translate italian trial4_29a24172:


    mad "Correre !!!" with hpunch


translate italian trial4_01f455e7:


    emerick "Madison! non correre! Perderai come sempre!"


translate italian trial4_3ff9bc88:


    mad "non dovresti essere così sicuro di te, testa di cazzo!"


translate italian trial4_0646d43a:


    dpense "Wow... Sembra che non siano amici..."


translate italian trial4_7c86948c:


    mad "Ma come facciamo a sapere qual è il nostro?"


translate italian trial4_84bf4ca9:


    d "non lo so."


translate italian trial4_e46aa47d:


    mad "Ci sono numeri su ciascuno."


translate italian trial4_731b6dfa:


    d "Numeri?"


translate italian trial4_213cb8be:


    dpense "Forza [name]... Pensa!"


translate italian trial4_cc180ec8:


    dpense "Ci deve essere un indizio da qualche parte..."


translate italian trial4_b3db403f:


    drew "Sei solo un numero in un file. In questo caso, sei il novantesimo."


translate italian trial4_8b86fe0d:


    d "90esimo? 90esimo di cosa?"


translate italian trial4_ab1a0815:


    drew "Ti ho già detto troppo... Domani capirai."


translate italian trial4_a2ee175d:


    d "Aspetta, la signora Drew mi ha detto che sono il numero 90!"


translate italian trial4_ad3c3345:


    mad "Numero 90 di cosa?"


translate italian trial4_f0986419:


    d "non lo so, ma ha detto che avrei capito cosa significa oggi!"


translate italian trial4_b42bbe57:


    mad "Se hai 90 anni, allora anch'io devo avere un numero!"


translate italian trial4_94831b94:


    d "84...67...90...è tutto qui? SÌ!"


translate italian trial4_2684ce6d:


    d "Ho trovato il mio!"


translate italian trial4_4c50fb8d:


    mad "Avanti, Madison, pensa..."


translate italian trial4_225df61f:


    d "Se me lo ha detto, deve aver dato un indizio anche a te..."


translate italian trial4_169a4c34:


    mad "Numero 10!"


translate italian trial4_eda8436c:


    mad "Di solito mi chiama il 10 di picche! Perché sono il numero 10 della squadra!"


translate italian trial4_9879eab6:


    mad "Fatto!"


translate italian trial4_bdd2cfd3:


    d "Le ragazze arriveranno... Grace potrebbe sapere cosa fare!"


translate italian trial4_d7ead446:


    grace "Mia mamma ha dato a tutti noi un numero! non capivo perché fosse importante ma ora lo so!"


translate italian trial4_c6beaf67:


    grace "Tutte le borse hanno un numero... devi trovare il tuo!"


translate italian trial4_bf736dcc:


    d "Un numero?"


translate italian trial4_11db95ef:


    grace "SÌ! Quando l'hai vista, deve averti detto qualcosa! Ricorda!"


translate italian trial4_213cb8be_1:


    dpense "Forza [name]... Pensa!"


translate italian trial4_82b91c50:


    dpense "Devi avere un indizio da qualche parte..."


translate italian trial4_b3db403f_1:


    drew "Sei solo un numero in un file. In questo caso, sei il novantesimo."


translate italian trial4_8b86fe0d_1:


    d "90esimo? 90esimo di cosa?"


translate italian trial4_ab1a0815_1:


    drew "Ti ho già detto troppo... Domani capirai."


translate italian trial4_20d845c7:


    d "Gli anni 90! capito"


translate italian trial4_a206b243:


    d "Bagaglio ? Che bagaglio ?"


translate italian trial4_d0a982ec:


    ruby "Penso che ci sia qualcosa laggiù!"


translate italian trial4_6e7ff7a1:


    grace "Mia mamma ha dato a tutti noi un numero! non capivo perché fosse importante ma ora lo so!"


translate italian trial4_0c4da74e:


    grace "È il numero della nostra squadra, ragazze!"


translate italian trial4_c6beaf67_1:


    grace "Tutte le borse hanno un numero... devi trovare il tuo!"


translate italian trial4_bf736dcc_1:


    d "Un numero?"


translate italian trial4_11db95ef_1:


    grace "SÌ! Quando l'hai vista, deve averti detto qualcosa! Ricorda!"


translate italian trial4_213cb8be_2:


    dpense "Forza [name]... Pensa!"


translate italian trial4_82b91c50_1:


    dpense "Devi avere un indizio da qualche parte..."


translate italian trial4_b3db403f_2:


    drew "Sei solo un numero in un file. In questo caso, sei il novantesimo."


translate italian trial4_8b86fe0d_2:


    d "90esimo? 90esimo di cosa?"


translate italian trial4_ab1a0815_2:


    drew "Ti ho già detto troppo... Domani capirai."


translate italian trial4_20d845c7_1:


    d "Gli anni 90! capito"


translate italian trial4_3df96114:


    grace "Ho anche il mio!"


translate italian trial4_c17f7d6d:


    ruby "SÌ ! Anche io !"


translate italian trial4_58f59dc6:


    julia "Lo stesso qui !"


translate italian trial5_27b88c6d:


    mad "Presto ! L'anfi!"


translate italian trial5_78e34d14:


    d "Dobbiamo tornare indietro da dove siamo venuti?"


translate italian trial5_a1ac5cc2:


    mad "Sembra di sì!"


translate italian trial5_0413c8be:


    d "Dove sono gli altri?"


translate italian trial5_66ae6200:


    mad "non lo so... ma finché corriamo verso l'anfiteatro possiamo vincere!"


translate italian trial5_09de3f57:


    d "Hai visto Emerick?"


translate italian trial5_f2708063:


    mad "non da quando stavamo cercando le borse..."


translate italian trial5_da52e09c:


    d "Lo stesso qui..."


translate italian trial5_6933428f:


    mad "Abbiamo vinto??"


translate italian trial5_6bc83719:


    d "Sembra così!"


translate italian trial5_94d0ff02:


    mad "Oh, è fantastico!"


translate italian trial5_ec79c7cd:


    d "Waah! Ce l'abbiamo fatta!"


translate italian trial5_30f5bf78:


    dpense "È così allegra quando vince!"


translate italian trial5_c1a3e6e6:


    d "Madison... tu..."


translate italian trial5_42add1f3:


    dpense "Questa è un'altra Madison..."


translate italian trial5_09f48158:


    mad "Silenzio..."


translate italian trial5_9f153aac:


    dpense "Potrei fare qualsiasi cosa per questi occhi e queste labbra..."


translate italian trial5_75ca9fd9:


    mad "Voi..."


translate italian trial5_873f2806:


    mad "Scusa... non dovrei..."


translate italian trial5_1466bf93:


    emerick "Madison... Madison... Madison..."


translate italian trial5_5aa65267:


    emerick "Ehi piccioncini! Pensavi davvero di aver vinto?"


translate italian trial5_d7bc0bc2:


    emerick "Ahahahahah!"


translate italian trial5_a796af6c:


    mad "Oh merda..."


translate italian trial5_9e386227:


    d "Mah..."


translate italian trial5_02c64f73:


    emerick "Bel tentativo, Maddie... Ma come sempre, sei ancora dietro di me."


translate italian trial5_2f2a683b:


    emerick "Ma tu, Frenchy, mi hai impressionato."


translate italian trial5_a324b55d:


    mad "Fai attenzione con lui... La sua lingua è ancora più pericolosa quando fa i complimenti..."


translate italian trial5_dd115bf5:


    d "non preoccuparti. non avevo intenzione di diventare amico di uno come lui."


translate italian trial5_7b361f19:


    mad "Stai aumentando la mia stima, però!"


translate italian trial5_67022165:


    mad "Continua così e forse riuscirò a tollerarti!"


translate italian trial5_e3320973:


    d "Sì... non sono sicuro di volerlo davvero..."


translate italian trial5_407e6732:


    sofia "Ci vediamo più tardi, Groper..."


translate italian trial5_3aa92f61:


    emerick "E allora, Madison? Siamo molto indietro questa volta! Come sempre, in realtà!"


translate italian trial5_83d40bd8:


    mad "non sfidare la fortuna!"


translate italian trial5_abb65a9e:


    emerick "La tigre mostra gli artigli, attenzione!"


translate italian trial5_0cc73e4b:


    grace "Emerick, vai via."


translate italian trial5_4702d6a8:


    emerick "Ok...ma non abbiamo ancora finito...dimostrerò a tutti che sono il MIGLIORE"


translate italian trial5_166c3d90:


    mad "Sì, sì, qualunque cosa..."


translate italian trial5_94c5f187:


    grace "Presto ! L'anfi!"


translate italian trial5_f07c88c7:


    d "Dobbiamo tornare indietro da dove siamo venuti??"


translate italian trial5_0390dffa:


    grace "Sembra di sì!"


translate italian trial5_3aa92f61_1:


    emerick "E allora, Madison? Siamo molto indietro questa volta! Come sempre, in realtà!"


translate italian trial5_83d40bd8_1:


    mad "non sfidare la fortuna!"


translate italian trial5_abb65a9e_1:


    emerick "La tigre mostra gli artigli, attenzione!"


translate italian trial5_0cc73e4b_1:


    grace "Emerick, vai via."


translate italian trial5_4702d6a8_1:


    emerick "Ok...ma non abbiamo ancora finito...dimostrerò a tutti che sono il MIGLIORE"


translate italian trial5_166c3d90_1:


    mad "Sì, sì, qualunque cosa..."


translate italian trialfin_7361b1fc:


    "Clap clap clap"


translate italian trialfin_a3f82246:


    orushi "Cari studenti! Avete terminato la sfida! Congratulazioni a tutti voi!!"


translate italian trialfin_6f496e2c:


    orushi "Devo dire che alcuni di voi si sono arresi alla Grande Muraglia, mentre altri non sono riusciti a trovare quale valigia portare!"


translate italian trialfin_ce43e569:


    orushi "Ad ogni modo, ecco i risultati della sfida e il tuo nuovo grado nella competizione!"


translate italian trialfin_9dd369ee:


    cr "Oh ! Vedo che sei sempre in gioco! E hai appena terminato la prima prova!!!"


translate italian trialfin_c61cc570:


    cr "Congratulazioni!"


translate italian trialfin_3bbf030e:


    cr "Ora daremo un'ultima occhiata alla finestra delle statistiche perché c'è qualcosa di nuovo introdotto dalla competizione!"


translate italian trialfin_e5a61280:


    cr "Si prega di fare clic sul pulsante delle statistiche!"


translate italian trialfin_25799538:


    cr "Come puoi vedere, il tuo grado MIGLIORE ora è [Rank]"


translate italian trialfin_c793ee1f:


    cr "Ogni azione durante una prova può aumentare questo grado o diminuirlo"


translate italian trialfin_ccc055be:


    cr "Nella prima prova non ci sono state azioni CATTIVE... ma nei prossimi eventi appariranno... fate attenzione!"


translate italian trialfin_331e6b8a:


    cr "Ok, ora ti lascio giocare! Vai a richiedere la tua ricompensa..."


translate italian trialfin_1ca94d08:


    cr "C'è una RICOMPENSA SPECIALE se stai seguendo un percorso speciale... con un personaggio speciale :)"


translate italian trialfin_c6beee0f:


    orushi "Come potete vedere, in questo concorso si tiene conto sia delle vostre azioni individuali che di quelle collettive."


translate italian trialfin_1962243b:


    orushi "Pertanto, i primi 50 classificati sono qualificati per la fase successiva!"


translate italian trialfin_0ad95992:


    orushi "Ancora una volta, congratulazioni a tutti voi!"


translate italian trialfin_12447cbb:


    orushi "Vi lascio il resto del pomeriggio libero."


translate italian trialfin_14f60090:


    orushi "Ci vediamo presto..."


translate italian trialfin_f4d45d06:


    rufus "Miao..."


translate italian trialfin_238811a2:


    grace "Ragazze ! Andiamo a cambiarci."


translate italian trialfin_dd3be176:


    d "Ci vediamo più tardi."


translate italian trialfin_17d82854:


    dpense "Dovrei andare a vedere dov'è lo spogliatoio..."


translate italian reward_273dcdfc:


    julia "Ciao bello !"


translate italian reward_3f69cd63:


    d "Hmm ?"


translate italian reward_3bcca2d1:


    julia "Grazie per il tuo aiuto durante la prova!"


translate italian reward_250f7ffa:


    grace "Lascia che ti ricompensi per il tuo aiuto, mio ​​cavaliere bianco..."


translate italian reward_7c4ebb9b:


    d "OH ? ..."


translate italian reward_41d76fca:


    ruby "Sapevo di poter contare su di te Cortex!"


translate italian reward_16fd5bdd:


    d "Sempre meno... Sempre!"


translate italian final1_1c9356b0:


    dpense "Che giornata..."


translate italian final1_6cab8d90:


    dpense "Un processo, alcuni avversari, le ragazze..."


translate italian final1_d050ec5e:


    dpense "Questa classifica... Tutto questo è pazzesco..."


translate italian final1_8bfacc8f:


    cr "Non hai finito tra i primi e Beth non è interessata a te, quindi... nessuna ricompensa da parte delle gemelle.!"


translate italian final1_dbf8cd2e:


    cr "Prova di nuovo a migliorare il tuo MIGLIOR RANK, fai altre scelte e ricevi dei premi da loro!"


translate italian sofiabj_9c5ddf66:


    d "Waaaah! Cosa stai facendo qui ?"


translate italian sofiabj_36c8ebe5:


    sofia "Beh... devo dire che hai fatto una bellissima figura oggi..."


translate italian sofiabj_65c5b248:


    sofia "E... Quando avrò quelle... Impressioni..."


translate italian sofiabj_e57aa0b9:


    sofia "Devo soddisfare la mia..."


translate italian sofiabj_c67bd742:


    sofia "Curiosità..."


translate italian sofiabj_0ace3fae:


    sofia "Quindi... dimmi, signor Frenchie..."


translate italian sofiabj_a44e81b1:


    sofia "C'è qualcosa che hai che può soddisfarmi?"


translate italian sofiabj_2384fcb7:


    sofia "Oppure continuerai a palpare il culo di una piccola vergine..."


translate italian sofiabj_d2275832:


    sofia "Mentre potresti giocare con un intero..."


translate italian sofiabj_5cd1ddff:


    sofia "E un corpo sexy..."


translate italian sofiabj_5ab2b6e7:


    d "Quindi, è un'abitudine per le ragazze entrare negli spogliatoi?"


translate italian sofiabj_6413fc68:


    d "O era solo l'opportunità di vedere un ragazzo nuovo nudo?"


translate italian sofiabj_45991d45:


    sofia "Hmm, è un'abitudine del francese lasciare che le ragazze vedano tutto il pacco senza vergogna?"


translate italian sofiabj_5b05403c:


    d "EHI! Sei venuta qui! non ti ho chiesto niente!"


translate italian sofiabj_ba6905d9:


    sofia "E il pacco non è grande come mi aspettavo..."


translate italian sofiabj_25ed2fde:


    sofia "non sono sicura che mi costringerai... come l'hai detto? Uno squirtatore???"


translate italian sofiabj_59892900:


    d "ero sotto la doccia fredda..."


translate italian sofiabj_45991d45_1:


    sofia "Hmm, è un'abitudine del francese lasciare che le ragazze vedano tutto il pacco senza vergogna?"


translate italian sofiabj_5b05403c_1:


    d "EHI! Sei venuta qui! non ti ho chiesto niente!"


translate italian sofiabj_ba6905d9_1:


    sofia "E il pacco non è grande come mi aspettavo..."


translate italian sofiabj_25ed2fde_1:


    sofia "non sono sicura che mi costringerai... come l'hai detto? Uno squirtatore???"


translate italian sofiabj_59892900_1:


    d "ero sotto la doccia fredda..."


translate italian bluejob_221e359c:


    d "Quindi... forse puoi fare qualcosa al riguardo?"


translate italian bluejob_b31d7ba7:


    d "Oppure questa bocca serve solo per chiacchierare?"


translate italian bluejob_9864ef2f:


    sofia "Oh... Qualcuno ha le palle?"


translate italian bluejob_dff221f1:


    sofia "non ho l'abitudine di giocare con i perdenti..."


translate italian bluejob_fe933c48:


    sofia "Ma con quello che ho visto prima..."


translate italian bluejob_d7394d4d:


    sofia "Penso che meriti un premio di consolazione..."


translate italian bluejob_2ad66fc4:


    sofia "E se aggiungessi un po' di..."


translate italian bluejob_bbf61877:


    sofia "Motivazione..."


translate italian bluejob_e4a37cb5:


    sofia "Per il nostro piccoletto lì..."


translate italian bluejob_8a63b182:


    d "Penso che tu possa fare di più..."


translate italian bluejob_caddeb77:


    sofia "Pallone gonfiato e avido... Che uomo !"


translate italian bluejob_35e464ec:


    sofia "Ok, francese... vuoi giocare?"


translate italian bluejob_6839384e:


    sofia "Vediamo quanto resisterai contro di me..."


translate italian bluejob_8ce2bde3:


    sofia "E se mi impressioni... solo un po'..."


translate italian bluejob_8405f452:


    sofia "Forse ti lascerò giocare con me..."


translate italian bluejob_e75e0f01:


    sofia "Allora... d'accordo?"


translate italian bluejob_01d20d04:


    d "Abbiamo un accordo, Blu..."


translate italian bluejob_93f7f7d7:


    sofia "Sofia... ho un nome, piccolo stronzo..."


translate italian bluejob_1ac0edce:


    sofia "Ora... basta parlare... Azione..."


translate italian bluejob_2bb9fb81:


    mad "Stronzo..."


translate italian bluejob_7c871c87:


    mad "Lo stesso..."


translate italian bluejob_bbf61877_1:


    sofia "Motivazione..."


translate italian bluejob_e4a37cb5_1:


    sofia "Per il nostro piccoletto lì..."


translate italian bluejob_8a63b182_1:


    d "Penso che tu possa fare di più..."


translate italian bluejob_caddeb77_1:


    sofia "Pallone gonfiato e avido... Che uomo!"


translate italian bluejob_35e464ec_1:


    sofia "Ok, francese... vuoi giocare?"


translate italian bluejob_6839384e_1:


    sofia "Vediamo quanto resisterai contro di me..."


translate italian bluejob_8ce2bde3_1:


    sofia "E se mi impressioni... solo un po'..."


translate italian bluejob_8405f452_1:


    sofia "Forse ti lascerò giocare con me..."


translate italian bluejob_e75e0f01_1:


    sofia "Allora... d'accordo ?"


translate italian bluejob_01d20d04_1:


    d "Abbiamo un accordo, Blu..."


translate italian bluejob_93f7f7d7_1:


    sofia "Sofia... ho un nome, piccolo stronzo..."


translate italian bluejob_a399e704:


    sofia "E ti consiglio di non scherzarci sopra mentre gioco con il tuo cazzo in mano..."


translate italian bluejob_1ac0edce_1:


    sofia "Ora... basta parlare... Azione..."


translate italian bluejob_2bb9fb81_1:


    mad "Stronzo..."


translate italian bluejob_7c871c87_1:


    mad "Lo stesso..."


translate italian bluejob_2b2db848:


    d "Forza Sofia, puoi fare di meglio!"


translate italian bluejob_4f004b7d:


    sofia "Penso che potrei dirti la stessa cosa!"


translate italian bluejob_b49239f2:


    d "Te la sei cercata..."


translate italian bluejob_71957600:


    sofia "Ohhh..."


translate italian bluejob_e8006c39:


    sofia "Cosa..."


translate italian bluejob_4dbe7388:


    sofia "Fottimi ?"


translate italian bluejob_248c587d:


    sofia "Ok... Ora stiamo parlando!"


translate italian bluejob_92442ef8:


    d "Quindi... impressionata?"


translate italian bluejob_768930d5:


    sofia "No..."


translate italian bluejob_c30f547e:


    d "Neanche un po ?"


translate italian bluejob_882be446:


    sofia "Forse..."


translate italian bluejob_cb3c584d:


    sofia "Vediamo come gestirai questa cosa..."


translate italian bluejob_d088a656:


    d "Wow... sai come usare la lingua!"


translate italian bluejob_42db099b:


    sofia "non solo la mia lingua!"


translate italian bluejob_07d235c4:


    d "Ohhh?"


translate italian bluejob_1908f85f:


    sofia "COSÌ ?"


translate italian bluejob_122c476a:


    d "non male... Ma forse potresti farlo più velocemente?"


translate italian bluejob_1abffde1:


    sofia "Pensi di potermi dare ordini in questa posizione?"


translate italian bluejob_f529413b:


    d "Tua madre non ti ha detto di non parlare con la bocca piena?"


translate italian bluejob_483b7906:


    sofia "Stai zitto..."


translate italian bluejob_b6797206:


    dpense "Quella bocca... me la voglio scopare come un barbaro..."


translate italian bluejob_c15f7194:


    dpense "E' un vuoto a perdere? Sono già al limite !"


translate italian bluejob_38e37bbd:


    d "non posso più resistere!"


translate italian bluejob_320e7128:


    sofia "non ! Andiamo, francese! Dallo A me !"


translate italian bluejob_fadae4f3:


    dpense "Certo che te lo darò... tutto nella tua fottuta bocca!"


translate italian bluejob_dad3c95e:


    d "Ahhhhhhhhhh!!!"


translate italian bluejob_d9e8a884:


    d "Ohhh..."


translate italian bluejob_7fb3f60d:


    d "Mio Dio... mi hai prosciugato..."


translate italian bluejob_d3db81d2:


    sofia "Hum hum..."


translate italian bluejob_7e015a72:


    sofia " {i} Gulp {/i} "


translate italian bluejob_a2ca227f:


    sofia "non male !"


translate italian finchoixblue_cbc2a050:


    sofia "Bene... Ora che il nostro piccolo accordo è sistemato... Continua a segnare durante la competizione..."


translate italian finchoixblue_2f2dd27a:


    d "Lo farò..."


translate italian finchoixblue_e68d49c9:


    sofia "Spero... perché voglio davvero, davvero giocare di nuovo con il nostro comune amico..."


translate italian finchoixblue_876533ea:


    d "non vorrai fermarti dopo questo..."


translate italian finchoixblue_6ece4bdc:


    sofia "non è mia intenzione!"


translate italian finchoixblue_0e4e8906:


    sofia "Ci vediamo, francese!"


translate italian finchoixblue_c81eac44:


    d "Yeah Yeah..."


translate italian finchoixblue_637a238f:


    dpense "non so in cosa mi sono cacciato..."


translate italian finchoixblue_a9ef37dd:


    d "Quindi se non hai niente da fare... Forse puoi andare a far volare un aquilone?"


translate italian finchoixblue_a81b1440:


    sofia "Ma stai scherzando ?"


translate italian finchoixblue_41ab0038:


    d "No..."


translate italian finchoixblue_3b22e690:


    sofia "non... Mai... Prova a parlarmi ancora, bastardo!!!"


translate italian finchoixblue_93c9e4c4:


    d "non preoccuparti ! non lo farò!"


translate italian finchoixblue_c81977b0:


    mad " {i} Risatina {/i} "


translate italian finchoixblue_223a7be2:


    mad "Magari è bravo..."


translate italian bethfk_22fa6fd0:


    dpense "Orushi..."


translate italian bethfk_63f75c72:


    dpense "Anche il gatto è strano!!!!"


translate italian bethfk_a4645742:


    dpense "Alle ragazze piaccio..."


translate italian bethfk_6ade56ff:


    dpense "Ma non so se posso essere il loro MIGLIORE.."


translate italian bethfk_949548e4:


    dpense "Questo Emerick sembra creare problemi..."


translate italian bethfk_e939f4bf:


    dpense "Devo stare attento intorno a lui..."


translate italian bethfk_a98aac7a:


    dpense "E le gemelle..."


translate italian bethfk_3120a8c0:


    dpense "Sono così..."


translate italian bethfk_9130a1ec:


    d "Ahhhhhh!!!!"


translate italian bethfk_855006e5:


    beth "Sorpresa!"


translate italian bethfk_8d3edbc7:


    beth "Te l'ho detto che ti tengo d'occhio..."


translate italian bethfk_b6632a8b:


    beth "E devo dire che sono davvero soddisfatta di quello che ho visto finora..."


translate italian bethfk_d543fc81:


    beth "Ho visto come ti prendi cura delle tue ragazze..."


translate italian bethfk_fe2e0e36:


    d "Le mie ragazze ?"


translate italian bethfk_2573a943:


    beth "Già... La piccola Ruby... Il Capitano... Anche Holy, Marie, Julia..."


translate italian bethfk_bbcedabb:


    beth "È così triste che non ho qualcuno come te che si prenda cura di me..."


translate italian bethfk_4a3e4292:


    beth "I miei bisogni..."


translate italian bethfk_be75ee24:


    beth "Qualcuno che possa gestirmi..."


translate italian bethfk_dc08f865:


    beth "Chi può vedere molto..."


translate italian bethfk_9f04486c:


    beth "Profondamente..."


translate italian bethfk_184c3e0d:


    beth "Nei miei..."


translate italian bethfk_89669174:


    beth "Occhi..."


translate italian bethfk_04bad0c3:


    beth "Ma cosa succede se..."


translate italian bethfk_fdba8dbe:


    beth "Mi piacerebbe provare..."


translate italian bethfk_35864525:


    beth "E vedere come un francese..."


translate italian bethfk_e271c468:


    beth "Bacio..."


translate italian redkiss_3800def7:


    dpense "Waahhhh... sto sognando...."


translate italian redkiss_ae82b41a:


    dpense "La sua lingua... quelle labbra... quel corpo..."


translate italian redkiss_60123473:


    dpense "Oh mio Dio... voglio..."


translate italian redkiss_08da671f:


    beth "Ohhh..."


translate italian redkiss_39d96f0d:


    beth "Ah, Qualcuno diventa avido..."


translate italian redkiss_d62019b2:


    beth "Penso di aver appena detto un bacio..."


translate italian redkiss_16d05a4b:


    beth "Ora, se mi scusi..."


translate italian redkiss_7b56213b:


    d "Dove stai andando ?"


translate italian redkiss_9a65c14b:


    beth "Ho delle commissioni da sbrigare, ma..."


translate italian redkiss_a695e7ba:


    beth "Quando decido che te lo meriti..."


translate italian redkiss_0786e21b:


    beth "Faresti meglio ad essere pronto..."


translate italian redkiss_e96e2b0e:


    dpense "Lo sono ora !"


translate italian redkiss_da1a2c02:


    beth "Ma... fino ad allora..."


translate italian redkiss_2413472c:


    beth "Giù, ragazzo !"


translate italian redkiss_26d97def:


    d "Dai !!!"


translate italian redkiss_637a238f:


    dpense "non so in cosa mi sono cacciato..."


translate italian redkiss_ef4b9cad:


    ruby " {i} Stupido Cortex... {/i} "


translate italian redkiss_0581bacf:


    d "non so cosa ti sia preso..."


translate italian redkiss_5e5295e8:


    d "Ma non voglio che le mie labbra si avvicinino alle tue..."


translate italian redkiss_1b0fd802:


    beth "Ovunque ? Pensi davvero che chiunque possa toccare questo corpo?"


translate italian redkiss_d2d7e74c:


    beth "Ascoltami, Frenchie One. Sarà una fredda giornata all'inferno prima che tu abbia di nuovo questa opportunità..."


translate italian redkiss_73b76202:


    d "non lo so. Ho sentito che il riscaldamento globale sta avendo l'effetto opposto all'inferno. Allora porta le racchette da neve, Salame! Scivolerà!"


translate italian redkiss_0a4b4b2c:


    ruby " {i} È incredibile... {/i} "


translate italian final_4a598229:


    "M ? Sì..."


translate italian final_aec9e18d:


    "È sotto controllo..."


translate italian final_b10b320a:


    "non sarà più una minaccia per te..."


translate italian final_8bda4787:


    "Farò del mio meglio per tenerlo lontano da queste ragazze..."


translate italian final_894d2571:


    "Si lo so..."


translate italian final_b2ae06ee:


    "Ci vediamo durante il torneo..."


translate italian final_9669528e:


    "Dopo..."


translate italian final_4a598229_1:


    "M ? Sì..."


translate italian final_aec9e18d_1:


    "È sotto controllo..."


translate italian final_b10b320a_1:


    "non sarà più una minaccia per te..."


translate italian final_8bda4787_1:


    "Farò del mio meglio per tenerlo lontano da queste ragazze..."


translate italian final_894d2571_1:


    "Si lo so..."


translate italian final_b2ae06ee_1:


    "Ci vediamo durante il torneo..."


translate italian final_9669528e_1:


    "Dopo..."

translate italian strings:


    old "2 minutes before the race starts..."
    new "2 minuti prima dell'inizio della gara..."


    old "1 minute before the race starts..."
    new "1 minuto prima dell'inizio della gara..."


    old "Help Julia [TEMP1!t]"
    new "Aiuta Julia [TEMP1!t]"


    old "Continue [TEMP2!t]"
    new "Continua [TEMP2!t]"


    old "Help the girls [TEMP1!t]"
    new "Aiuta le ragazze [TEMP1!t]"


    old "Do it like Madison [TEMP1!t]"
    new "Fallo come Madison [TEMP1!t]"


    old "Help the girls [TEMP2!t]"
    new "Aiuta le ragazze [TEMP2!t]"


    old "Join Madison [TEMP1!t]"
    new "Unisciti a Madison [TEMP1!t]"


    old "Encourage Madison [TEMP2!t]"
    new "Incoraggia Madison [TEMP2!t]"


    old "Join Julia [TEMP1!t]"
    new "Unisciti a Julia [TEMP1!t]"


    old "Encourage Girls [TEMP2!t]"
    new "Incoraggia le ragazze [TEMP2!t]"


    old "Remember [TEMP1!t]"
    new "Ricorda [TEMP1!t]"


    old "Wait for girls [TEMP2!t]"
    new "Aspetta le ragazze [TEMP2!t]"


    old "YOUR NEW RANK IS [Rank] !"
    new "IL TUO NUOVO GRADO È [Rank]!"


    old "Provoke her [TEMP1!t]"
    new "Provocala [TEMP1!t]"


    old "Tell her to go away [TEMP2!t]"
    new "Dille di andare via [TEMP2!t]"


    old "Go for the kiss [TEMP1!t]"
    new "Scegli il bacio [TEMP1!t]"


    old "Refuse [TEMP2!t]"
    new "Rifiuta [TEMP2!t]"


















translate italian trial4_08132be7:


    drew "DOVETE TROVARE IL VOSTRO BAGAGLIO E LASCIARLO CON ESSO QUANDO ARRIVATE ALL'AUDITORIUM."


translate italian trial5_21020def:


    mad "Presto! L'auditorium!"


translate italian trial5_fa81ccee:


    mad "Non lo so... ma finché corriamo verso l'auditorium, possiamo vincere!"


translate italian trial5_07f344d2:


    grace "Presto! L'auditorium!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
