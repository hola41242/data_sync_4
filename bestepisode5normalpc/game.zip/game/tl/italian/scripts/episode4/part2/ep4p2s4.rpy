


translate italian ep4p2s4_51f317c6:


    ruby "Non riesco ancora a credere che abbiamo vinto! Quella partita è stata intensa."


translate italian ep4p2s4_b7a16e73:


    d "Sì, ma la finale sarà ancora più dura. Dobbiamo restare lucidi."


translate italian ep4p2s4_cf3bc980:


    ruby "Pfft, con me in giro? Ce la faremo!"


translate italian ep4p2s4_d0877d63:


    emerick "Di nuovo tu? Non ti stanchi mai di intralciarmi?" with hpunch


translate italian ep4p2s4_db16eb90:


    d "Forse allora dovresti smetterla di urtarmi."


translate italian ep4p2s4_1a7a161f:


    emerick "Pensi di essere intoccabile solo per le tue vittorie? Notizia dell'ultimo minuto: non sei niente."


translate italian ep4p2s4_67d7ebd1:


    ruby "Emerick, questo è inutile. Lascia perdere."


translate italian ep4p2s4_5208f1a9:


    emerick "Stai fuori da questa storia, Ruby."


translate italian ep4p2s4_4320e783:


    ruby "Dico sul serio. Questo è infantile."


translate italian ep4p2s4_9b139935:


    d "Hai sbagliato."


translate italian ep4p2s4_e2bd787f:


    ruby "Fermi tutti e due!"


translate italian ep4p2s4_1cdf3893:


    emerick "Togliti!"


translate italian ep4p2s4_61e6b404:


    ruby "Ahhh!" with hpunch


translate italian ep4p2s4_bebbbb63:


    d "RUBY!!!!!!!!!!" with hpunch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
