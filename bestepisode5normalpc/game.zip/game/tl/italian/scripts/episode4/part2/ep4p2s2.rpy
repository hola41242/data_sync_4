


translate italian ep4p2s2_530acdfa:


    dpense "È qui che Sofia mi ha chiesto di incontrarla. Non dovrebbe volerci molto."


translate italian ep4p2s2_df219c63:


    sofia "Ah, eccoti! Ti ho visto vagare per il quartiere come un detective smarrito."


translate italian ep4p2s2_54b8e1eb:


    dpense "Sembra essere di buon umore. Bene, mi sentivo un po' nervoso."


translate italian ep4p2s2_bad4aa28:


    d "Mi sto solo godendo l'atmosfera."


translate italian ep4p2s2_e9b4b60e:


    sofia "Se continui così non ti lascerò andare."


translate italian ep4p2s2_a06bc4dc:


    d "Davvero mi fermeresti?"


translate italian ep4p2s2_60084afa:


    sofia "Forza, seguitemi. La mia casa è proprio lì."


translate italian ep4p2s2_7f47e358:


    d "I tuoi genitori sono a casa stasera?"


translate italian ep4p2s2_1fd8512e:


    sofia "No, come al solito, sono via per lavoro. Ma non preoccuparti, Elizabeth e io possiamo gestire le cose."


translate italian ep4p2s2_93e190ef:


    dpense "Viaggiare così tanto... Deve essere strano crescere senza vederli spesso."


translate italian ep4p2s2_673b7e9d:


    d "Deve essere tutto tranquillo senza i tuoi genitori in giro."


translate italian ep4p2s2_45d4e726:


    sofia "Troppo silenzioso, a volte, ma è stato così per la maggior parte delle nostre vite. Abbiamo chiesto ai nostri genitori di lasciarci vivere nella guest house..."


translate italian ep4p2s2_a2790c8b:


    sofia "Elizabeth, guarda chi c'è."


translate italian ep4p2s2_ed501987:


    beth "Capisco. Sei riuscito a convincerlo a venire."


translate italian ep4p2s2_898a5092:


    d "Buonasera, Elizabeth."


translate italian ep4p2s2_ca43a71d:


    beth "Buonasera. Sto cucinando la cena, quindi niente scherzi mentre sono in cucina."


translate italian ep4p2s2_cbf92592:


    dpense "Va dritta al punto. Come sempre."


translate italian ep4p2s2_a2cc0998:


    sofia "Si comporta come il capo, ma è felice che tu sia qui."


translate italian ep4p2s2_19d09601:


    sofia "Sedetevi, chiacchieriamo un po'. Allora, questa competizione... Cosa ne pensate?"


translate italian ep4p2s2_6a967106:


    d "È intenso."


translate italian ep4p2s2_589a490f:


    sofia "Sì, siamo tutti tesi."


translate italian ep4p2s2_8ec18dba:


    sofia "Emerick è insopportabile. Pensa di poter fare tutto ciò che vuole."


translate italian ep4p2s2_b94d27aa:


    beth "È fastidioso, ma sa come giocare le sue carte."


translate italian ep4p2s2_ac3a26ed:


    dpense "Elizabeth sembra sempre avere un piano. Non dice mai niente senza una ragione."


translate italian ep4p2s2_0f477363:


    sofia "Le ragazze di Grace, d'altro canto, sono interessanti. Ruby ha un temperamento unico. Julia è dolce. Grace è affascinante e Madison è... complicata."


translate italian ep4p2s2_5355fad2:


    beth "Non li stai un po' idealizzando? Hanno tutti i loro difetti."


translate italian ep4p2s2_c88ea45c:


    d "E tu, Elizabeth? Cosa pensi del gruppo?"


translate italian ep4p2s2_eac165f6:


    beth "Preferisco osservare. Ho bisogno di tutti i fatti prima di fare qualsiasi alleanza."


translate italian ep4p2s2_c98db75d:


    dpense "Alleanze? Ecco, questa è una parola interessante. Vede questa competizione come una partita a scacchi."


translate italian ep4p2s2_cda883af:


    d "E allora chi ritieni possa essere un potenziale alleato?"


translate italian ep4p2s2_8131e039:


    beth "Quelli che pensano prima di agire. Quelli che capiscono che ogni mossa è importante."


translate italian ep4p2s2_a79791d9:


    dpense "Sta cercando di valutarmi... Ma non ho intenzione di rivelare le mie carte così facilmente."


translate italian ep4p2s2_b48a7664:


    d "Immagino che questo significhi che stai osservando anche le mie scelte?"


translate italian ep4p2s2_a1842220:


    beth "Tutti osservano tutti. La vera domanda è: cosa stai osservando?"


translate italian ep4p2s2_4ac13fec:


    dpense "Sta capovolgendo la situazione. È impressionante, ma non lascerò che mi scuota."


translate italian ep4p2s2_d082a9f0:


    d "Direi che osservo soprattutto ciò che gli altri nascondono."


translate italian ep4p2s2_d368f496:


    beth "Interessante. Forse non sei poi così ingenuo."


translate italian ep4p2s2_011f8701:


    sofia "È stato fantastico! Grazie Beth!"


translate italian ep4p2s2_11f6c91b:


    d "Sì, era delizioso."


translate italian ep4p2s2_de71d125:


    beth "Lo so. Di niente."


translate italian ep4p2s2_f5a70e38:


    sofia "Elizabeth ed io siamo diverse, ma ci completiamo a vicenda."


translate italian ep4p2s2_f68be3d8:


    d "Si vede. Hai una dinamica unica."


translate italian ep4p2s2_95e4195d:


    beth "Unico, sì. E a volte estenuante."


translate italian ep4p2s2_6f689509:


    d "Ti dà fastidio quando ti chiamano 'Rosso' e 'Blu'?"


translate italian ep4p2s2_04ed70aa:


    sofia "Sinceramente va bene, ma ci riporta sempre a continui paragoni."


translate italian ep4p2s2_cc0e6b06:


    beth "È stancante. Siamo individui, non colori."


translate italian ep4p2s2_f615ef4b:


    sofia "Sai perché lo accetto? Anche se sono 'Blue', almeno non sono invisibile. Prima era peggio."


translate italian ep4p2s2_349ca4ea:


    beth "Per me sono solo etichette. Se la gente pensa che 'Rosso' mi definisca, è un problema loro, non mio."


translate italian ep4p2s2_8c8371e9:


    dpense "Devono aver portato questo peso per molto tempo. Questo genere di soprannomi non definisce chi sono."


translate italian ep4p2s2_89ca0014:


    sofia "Ecco perché ho cambiato il mio stile di recente. Nuovo taglio di capelli, nuovi vestiti... Mi aiuta a distinguermi."


translate italian ep4p2s2_f77098d1:


    beth "Oppure prendi le distanze."


translate italian ep4p2s2_8cc6ae08:


    sofia "Niente affatto! Mi sto evolvendo, Elizabeth. Non ha niente a che fare con te."


translate italian ep4p2s2_24100ba9:


    dpense "Sembra che questo argomento tocchi una corda sensibile tra loro."


translate italian ep4p2s2_5e1f4029:


    beth "Quando ti guardi allo specchio, forse vedi qualcuno di diverso, ma io vedo ancora mia sorella. Non hai bisogno di cambiare."


translate italian ep4p2s2_a51f08d8:


    sofia "Non è una trasformazione. È... autoespressione."


translate italian ep4p2s2_92fbc56d:


    dpense "Il loro legame è forte, ma le loro differenze stanno iniziando a vedersi. È colpa mia? O è solo il passare del tempo?"


translate italian ep4p2s2_e79b76f8:


    sofia "Basta parlare di Beth e me. Ora sei qui come mio ospite."


translate italian ep4p2s2_e0c34a25:


    sofia "Mi chiedo se mi vedi davvero per come sono o se anche tu mi stai mettendo in una scatola."


translate italian ep4p2s2_afa13238:


    d "Ti vedo come la ragazza a cui importa troppo di quello che penso."


translate italian ep4p2s2_50af6feb:


    sofia "Ah, quindi lo stai ammettendo. Non pensi molto."


translate italian ep4p2s2_b4416a79:


    beth "Non preoccuparti, Sofia. Se qualcuno ti fa del male, dovrà vedersela con me."


translate italian ep4p2s2_42854063:


    beth "Proteggo mia sorella, ma so anche riconoscere quando qualcuno può essere utile."


translate italian ep4p2s2_746f142e:


    d "Dovrei considerarlo una minaccia o un'opportunità?"


translate italian ep4p2s2_b249881f:


    beth "Entrambi. Dipende da te. Se pensi che abbasserò la guardia a causa del nostro legame, ti sbagli."


translate italian ep4p2s2_47340a30:


    sofia "Ok! Vieni, voglio mostrarti la mia stanza."


translate italian ep4p2s2_6ff2d3ba:


    sofia "Mettetevi comodi."


translate italian ep4p2s2_81411292:


    d "Qui è accogliente."


translate italian ep4p2s2_2b138a1c:


    sofia "Grazie. Volevo questo momento con te."


translate italian ep4p2s2_f7cd02e4:


    dpense "Sembra sincera. Vuole parlare di qualcosa di importante."


translate italian ep4p2s2_8f407172:


    d "Di cosa vuoi parlare?"


translate italian ep4p2s2_79a38c73:


    sofia "Di me. Di cosa la gente dice di me."


translate italian ep4p2s2_b046a057:


    sofia "Sai, la gente pensa che io sia superficiale, ma è solo una facciata."


translate italian ep4p2s2_b0caddbf:


    sofia "Poiché Elizabeth era così forte e indipendente, dovevo distinguermi in un modo diverso."


translate italian ep4p2s2_56628414:


    dpense "Questo spiega perché cerca di affermarsi attraverso le proprie scelte."


translate italian ep4p2s2_010dba7e:


    sofia "Essere 'Blue' era meglio che non essere nessuno."


translate italian ep4p2s2_615ccb96:


    sofia "A volte ho la sensazione che Elizabeth sia sempre stata la star e che io fossi solo la sua ombra."


translate italian ep4p2s2_549bd88f:


    sofia "Onestamente, tutto questo non ha senso. Ho provato a cambiare me stesso per adattarmi alla percezione che gli altri avevano di me, e non ha mai funzionato."


translate italian ep4p2s2_285f0b9f:


    d "Cosa intendi esattamente?"


translate italian ep4p2s2_b4c35998:


    sofia "Mi riferisco alla mia reputazione, a ciò che la gente pensa di me..."


translate italian ep4p2s2_af20113e:


    sofia "Ti piace il ronzio delle mie tette?"


translate italian ep4p2s2_ee6782ed:


    d "Sì! Adoro toccare la tua pelle morbida e giocare con i tuoi capezzoli."


translate italian ep4p2s2_f9e6dae8:


    sofia "Lo vedo!"


translate italian ep4p2s2_9b10c2c3:


    sofia "Quindi, la mia reputazione non rispecchia chi sono."


translate italian ep4p2s2_b27aa068:


    sofia "Sono rimasta con i ragazzi solo per dimostrare che potevo essere diversa, ma non ha mai significato nulla."


translate italian ep4p2s2_141a9915:


    sofia "Solo una volta ho avuto una vera relazione. Ed è stata... deludente."


translate italian ep4p2s2_acc35567:


    dpense "Si sta davvero aprendo. Non avrei mai immaginato che avesse questo lato di sé."


translate italian ep4p2s2_00609b4d:


    sofia "Con te è diverso. Mi sento... normale. Non giudicata. Non paragonata. Amata per quella che sono."


translate italian ep4p2s2_5d5f12cb:


    d "Meriti di essere amata per te stessa, Sofia. Sei fantastica così come sei."


translate italian ep4p2s2_06414540:


    sofia "A volte mi chiedo se merito qualcuno che mi accetti davvero. È stupido, non è vero?"


translate italian ep4p2s2_1b4ec24b:


    d "Niente affatto. Tutti hanno dei dubbi, ma se qualcuno non vede il tuo valore, è lui lo stupido."


translate italian ep4p2s2_de01fc66:


    sofia "Potrei quasi credere che tu sia un romantico."


translate italian ep4p2s2_bc47fbc5:


    sofia "Grazie... grazie a te ho la sensazione di aver trovato qualcuno che vede oltre la superficie."


translate italian ep4p2s2_d270a0bc:


    dpense "Questi momenti con lei sono preziosi. È molto più profonda delle voci che circolano su di lei."


translate italian ep4p2s2_14bee954:


    sofia "Basta con le chiacchiere serie! Sapevi che ho cambiato l'arredamento della mia stanza solo per te?"


translate italian ep4p2s2_ef5066d9:


    d "Ah sì? Com'era prima?"


translate italian ep4p2s2_c4efd746:


    sofia "Poster di unicorni e luci a forma di cuore."


translate italian ep4p2s2_3c735778:


    dpense "Sta scherzando, ma l'idea è adorabile."


translate italian ep4p2s2_a4ee1c19:


    d "Sono sicuro che avrebbe avuto il suo fascino."


translate italian ep4p2s2_dccdcd45:


    sofia "Onestamente, avrei dovuto tenere gli unicorni. Ti avrebbe fatto una buona impressione."


translate italian ep4p2s2_ec6f5d21:


    d "Certo, mi lascio impressionare facilmente."


translate italian ep4p2s2_98f55821:


    sofia "Mia sorella è di sotto, quindi..."


translate italian ep4p2s2_961ee93b:


    sofia "Non possiamo fare troppo rumore."


translate italian ep4p2s2_5fd024b0:


    sofia "Ma ho un'idea."


translate italian ep4p2s2_66b57b7d:


    d "Penso che mi piacerà."


translate italian ep4p2s2_a0f008fc:


    sofia "Sono sicuro che lo farai!"


translate italian ep4p2s2_de074968:


    sofia "Penso che il mio piccolo amico stia dormendo."


translate italian ep4p2s2_56251d19:


    sofia "Lo sveglierò. Ora, togliti i vestiti."


translate italian ep4p2s2_f607fa28:


    sofia "Meglio così!"


translate italian ep4p2s2_0ae9bcd0:


    ""


translate italian ep4p2s2_c804ee1b:


    d "Sofia... sei... irreale..."


translate italian ep4p2s2_f87ddc89:


    sofia "Zitto. Non fare rumore..."


translate italian ep4p2s2_4fdbb733:


    d "Sì."


translate italian ep4p2s2_e24aedd7:


    sofia "Mia sorella poteva sentirci."


translate italian ep4p2s2_d83c8599:


    d "Ma..."


translate italian ep4p2s2_db30d910:


    sofia "Mmmm Mmmm..."


translate italian ep4p2s2_f3f88eb9:


    d "Non durerò a lungo..."


translate italian ep4p2s2_e2ac8e66:


    d "Sofia..."


translate italian ep4p2s2_55aca788:


    sofia "Non preoccuparti..."


translate italian ep4p2s2_2f2dd27a:


    d "Lo farò..."


translate italian ep4p2s2_f6b31f93:


    sofia "Lo so... Stai tremando!"


translate italian ep4p2s2_b95efa92:


    d "IO..."


translate italian ep4p2s2_a8911b75:


    sofia "Fallo..."


translate italian ep4p2s2_5128c0e5:


    d "Nella tua bocca?"


translate italian ep4p2s2_a67cda65:


    sofia "Mmm mmm!"


translate italian ep4p2s2_e17b5d39:


    sofia "Mmmmm..."


translate italian ep4p2s2_f427720b:


    sofia "Ha il sapore dell'ananas!"


translate italian ep4p2s2_8433216a:


    d "Ahah... Incredibile!"


translate italian ep4p2s2_bcf27535:


    sofia "Vestiti e scendi prima che Elizabeth venga a controllare come stiamo. Potrebbe farti più domande della cena!"


translate italian ep4p2s2_7f6391f7:


    beth "Ehi, tu. Se mai dovessi fare del male a mia sorella, dovrai vedertela con me."


translate italian ep4p2s2_f903930d:


    dpense "Nota a me stesso: non contrariare mai Elizabeth."


translate italian ep4p2s2_55417eda:


    d "Capisco. Mi tieni d'occhio anche nella competizione?"


translate italian ep4p2s2_ec523280:


    beth "Certo. Ogni mossa che fai conta. Se sei intelligente, capirai che la nostra rivalità non esclude le opportunità."


translate italian ep4p2s2_511416a5:


    d "Opportunità?"


translate italian ep4p2s2_ceb58bee:


    beth "Forse. Finché sai qual è il tuo posto. Non farti un'idea sbagliata. Se pensi che il tuo legame con Sofia ti dia un vantaggio, hai già perso."


translate italian ep4p2s2_36738ef8:


    dpense "È formidabile. Un'avversaria, ma anche una potenziale alleata se gioco bene le mie carte."


translate italian ep4p2s2_e0104e45:


    beth "In questo gioco, gli alleati non sono amici. Sono una leva. Quindi pensaci bene: sarai una leva per Sofia..."


translate italian ep4p2s2_e3795a7e:


    beth "O per me?"


translate italian ep4p2s2_dd5bc1e1:


    beth "Se vuoi davvero restare nella vita di mia sorella, faresti meglio a dimostrare di essere migliore degli altri."


translate italian ep4p2s2_281de307:


    d "E se non ci riuscissi?"


translate italian ep4p2s2_ff4c841d:


    beth "Allora non dovrai preoccuparti di quello che penso, perché tu non ci sarai."


translate italian ep4p2s2_5da59355:


    d "Credo che dovrei stare all'erta."


translate italian ep4p2s2_a5ac2fd0:


    beth "E per una buona ragione. Buonanotte."


translate italian ep4p2s2_fc6e2dde:


    beth "Ricordati, ti sto guardando. Che sia per lei... o contro di te."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
