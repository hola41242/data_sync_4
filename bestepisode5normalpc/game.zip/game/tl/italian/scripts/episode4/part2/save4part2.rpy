


translate italian save4part2_285f8ea7:


    "Per favore, salva la partita qui..."


translate italian save4part2_f029d6e4:


    "Le mie più sentite condoglianze."


translate italian save4part2_c3393239:


    orushi "Visti i recenti eventi, credo che sia giunto il momento della resa dei conti!"


translate italian save4part2_fcba8ba6:


    mad "Entrerò nella torre di Orushi e scoprirò cosa sta succedendo!!!"


translate italian save4part2_80081324:


    orushi "Il primo scontro avverrà [name]..."


translate italian save4part2_c1c27e01:


    orushi "contro Grace!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
