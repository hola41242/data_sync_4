


translate italian match2_69284cbf:


    orushi "Benvenuti a questa semifinale. Oggi, giocherete per qualcosa di più di una semplice vittoria."


translate italian match2_5b842112:


    orushi "La partita si giocherà a 3 punti. Una nuova regola: ogni squadra avrà un portiere."


translate italian match2_d66f6358:


    orushi "Non dimenticare che la squadra che vincerà la finale otterrà la casa come ricompensa finale."


translate italian match2_5f03f6e1:


    orushi "Dai tutto quello che hai. Che vinca la squadra migliore!"


translate italian match2_41ca5aa1:


    d "Un portiere?"


translate italian match2_04684a01:


    grace "Non preoccuparti! Farò il portiere!"


translate italian match2_a68cfae0:


    d "Ah, va bene."


translate italian match2_73f5537e:


    dpense "Sono già lì."


translate italian match2_e5e45f56:


    s "Credono davvero di avere una possibilità?"


translate italian match2_28d49d51:


    s "Tutto questo finirà in fretta."


translate italian match2_9ad31edb:


    hec "Non preoccuparti, Steven. Mangeranno la polvere prima di avere la possibilità di iniziare."


translate italian match2_c1d792e1:


    mad "Non montarti la testa, Steven. Tutto può succedere."


translate italian match2_59184b90:


    ruby "Siamo a una partita dalla finale. Non c'è modo che ci arrendiamo ora."


translate italian match2_d8416a09:


    julia "Rimani concentrata!"


translate italian match2_9f83db86:


    gaby "Non sei qui per caso! Mostra loro perché meriti questo posto."


translate italian match2_3d03d7c6:


    dpense "Anche Gaby è lì per incoraggiare le sue ragazze."


translate italian match2_8f114abf:


    orushi "Tutte le squadre in posizione."


translate italian match2_8db59867:


    orushi "Squadra B, il calcio d'inizio è vostro."


translate italian match2_9bc85abf:


    emerick "Guarda il francese, pensa già di essere in finale."


translate italian match2_91905166:


    beth "E se lo è, forse è perché è capace. A differenza di altri, lavora sodo per essere qui."


translate italian match2_f04114a2:


    emerick "Stai difendendo questo ragazzo? Stai scherzando?"


translate italian match2_bf78d112:


    beth "Non scherzo mai. Forse dovresti prendere spunto dal suo libro."


translate italian match2_98900f7b:


    kira "Forse dovremmo concentrarci sulla partita invece di perdere tempo a parlare."


translate italian match2_e6636ab0:


    emerick "Vedremo cosa dirai quando sarà a terra."


translate italian match2_9bc85abf_1:


    emerick "Guarda il francese, pensa già di essere in finale."


translate italian match2_3a13bbd2:


    sofia "È più duro di quanto sembri. Penso che potrebbe sorprenderti."


translate italian match2_f9ca9132:


    emerick "Davvero? Questo ragazzo verrà distrutto."


translate italian match2_e56250a5:


    sofia "Forse. Ma in una partita può succedere di tutto."


translate italian match2_9691e1fd:


    emerick "Che carina, Sofia. Hai intenzione di essere anche tu la sua cheerleader?"


translate italian match2_b32c3ce6:


    kira "Siete entrambi estenuanti. La partita sta per iniziare, quindi guardate e imparate."


translate italian match2_503584a0:


    s "Osservate attentamente, ho intenzione di concludere tutto dall'inizio."


translate italian match2_be56c117:


    dpense "Cosa sta facendo?"


translate italian match2_096c4e5a:


    dpense "Aspetta... davvero?!"


translate italian match2_ea102efd:


    gaby "Attenzione!"


translate italian match2_c0039868:


    mad "Che cosa?!"


translate italian match2_95ae5709:


    d "Che diavolo???"


translate italian match2_8088ed99:


    grace "Io... non l'ho vista arrivare. È stato troppo veloce."


translate italian match2_3d8da864:


    s "Ti avevo avvisato. È stato veloce, non è vero?"


translate italian match2_00d132e0:


    emerick "Questo è quello che chiamo un inizio perfetto. Non hanno alcuna possibilità."


translate italian match2_6f805dcc:


    sofia "Questo è solo l'inizio."


translate italian match2_689fbeda:


    mad "Non possiamo assolutamente lasciarci umiliare in questo modo."


translate italian match2_93b0ef9b:


    ruby "È solo un punto. Possiamo ancora recuperare."


translate italian match2_57ae5e3e:


    julia "Respira. Torneremo in pista."


translate italian match2_0d53043d:


    dpense "1-0... Fin dal primo impegno. Possiamo ancora recuperare, ma dobbiamo svegliarci."


translate italian match2_42673556:


    d "Non preoccuparti Grace, non è colpa tua."


translate italian match2_0c7d5527:


    mad "Va bene, Grace. Il prossimo lo prenderai."


translate italian match2_d18bbbec:


    ruby "Sì, ti copriamo le spalle!"


translate italian match2_1fb89bd3:


    gaby "Non lasciatevi abbattere. Riorganizzatevi e giocate in modo intelligente."


translate italian match2_c06dbb22:


    ruby "Andiamo!"


translate italian match2_4104810c:


    dpense "Gioca in modo intelligente, dice."


translate italian match2_12e1e4bf:


    dpense "La loro squadra si basa su diversi punti chiave."


translate italian match2_5eb5d451:


    dpense "Steven irradia forza pura e probabilmente cercherà di segnare più gol con potenza."


translate italian match2_a5154a0c:


    dpense "Hector è aggressivo, il suo compito è recuperare palla con una forte pressione."


translate italian match2_7d87dabb:


    dpense "Mac è imponente ma relativamente agile, il che lo rende un portiere eccellente; è difficile trovare l'angolazione giusta per tirare."


translate italian match2_82a57563:


    dpense "Ben è piuttosto agile e veloce. Dubito che abbia molta potenza."


translate italian match2_780e314b:


    dpense "L'ultimo sembra piuttosto innocuo. Probabilmente è uno dei rinforzi."


translate italian match2_9223ecc1:


    dpense "La loro squadra sembra piuttosto forte..."


translate italian match2_85f324f3:


    ruby "Andiamo!"


translate italian match2_a0bce6d2:


    s "Ehi, dammelo!"


translate italian match2_33e7a978:


    ruby "Se ci riesci, prendilo!"


translate italian match2_79a053dc:


    dpense "Cercherà di passare a Madison"


translate italian match2_0e37c63d:


    dpense "Hector cercherà di intercettarlo, ma Madison dovrebbe superarlo."


translate italian match2_af1bc548:


    dpense "Lo bloccherò!"


translate italian match2_5e575114:


    hec "Togliti di mezzo, cavaliere bianco!"


translate italian match2_1364de62:


    d "Se vuoi la palla devi superarmi."


translate italian match2_f4c3b9f5:


    dpense "Non è abbastanza veloce."


translate italian match2_574765f5:


    mad "Hai mangiato troppo ieri sera o cosa? Sei un po' lento!"


translate italian match2_a561a0a6:


    mad "Julia, è tuo!"


translate italian match2_55928131:


    julia "Ci sono!"


translate italian match2_9f8121b0:


    dpense "Julia sta avanzando, ma Ben la intercetterà! Perderà la palla!"


translate italian match2_b5dcb408:


    julia "Ecco! Fai la differenza."


translate italian match2_aa45fd5c:


    d "Grazie Julia!"


translate italian match2_f8317683:


    dpense "Questa è la mia occasione... Farò il tiro. Glielo farò vedere!"


translate italian match2_5a9b36ce:


    dpense "Accidenti, il Mac occupa così tanto spazio!"


translate italian match2_ce01da72:


    dpense "Posizionare i miei piedi"


translate italian match2_1f235451:


    dpense "E spara!"


translate italian match2_51696d02:


    mac "Troppo debole..."


translate italian match2_e2904d9a:


    mad "Hai fatto tutto di fretta!"


translate italian match2_29cf30b1:


    ruby "Va bene, lo capirai!"


translate italian match2_799f9fce:


    dpense "Ora hanno il possesso. Devo rimediare..."


translate italian match2_e44e7c0d:


    d "Bene, Ruby!"


translate italian match2_90634bd2:


    dpense "Ruby invia un passaggio preciso a Julia."


translate italian match2_c379c03a:


    dpense "Ma Julia è circondata."


translate italian match2_6fe7774e:


    dpense "Si prepara a sparare..."


translate italian match2_b9160fb9:


    mad "Forza Julia, fallo!" with hpunch


translate italian match2_245e1e23:


    dpense "Julia finge un tiro potente..."


translate italian match2_5ecbefd0:


    dpense "Mac blocca sulla destra, ma la palla va dall'altra parte!"


translate italian match2_da18de86:


    dpense "Devo approfittarne!"


translate italian match2_23b9f044:


    dpense "Tiro alzato di Kira!"


translate italian match2_ee630cd2:


    d "Questa volta..."


translate italian match2_44d8ab2b:


    d "Entra!"


translate italian match2_529bf17d:


    kira "Ehi, questa è la mia occasione!"


translate italian match2_3e63910a:


    mad "Goal!"


translate italian match2_10e86634:


    julia "Ben fatto, [name]!"


translate italian match2_3c5c4af6:


    ruby "Brava!"


translate italian match2_ddfd26c8:


    dpense "Non è abbastanza potente."


translate italian match2_f818e2dd:


    ruby "Non così veloce!"


translate italian match2_15b9b540:


    dpense "Cosa sta facendo?"


translate italian match2_3d50fe88:


    ruby "IIIIIIIIII....KEIIIIIIIII!"


translate italian match2_77201de2:


    d "Davvero???"


translate italian match2_b7b3ca9b:


    ruby "Ho sempre sognato di dire queste parole ahah!"


translate italian match2_dae059c5:


    mad "Che goal hai fatto?!"


translate italian match2_799370a7:


    julia "Ruby, sei incredibile!"


translate italian match2_20b630f1:


    ruby "L'unica cosa che conta è che abbiamo segnato, giusto?"


translate italian match2_7a59b4c5:


    dpense "1-1. Ruby ha trasformato una situazione critica in un momento incredibile."


translate italian match2_50e9ab37:


    hec "Cos'è questo circo?!"


translate italian match2_9d67ac96:


    s "Li schiacceremo. La prossima volta niente."


translate italian match2_dc01440e:


    gaby "È stato inaspettato, ma efficace. Continua così e non mollare."


translate italian match2_8646a8e5:


    dpense "La partita è ripresa, ma dobbiamo mantenere questa energia."


translate italian match2_0fc283ec:


    emerick "Davvero?!"


translate italian match2_5bd864ec:


    beth "Non c'è bisogno di farsi prendere dal panico."


translate italian match2_132e5c23:


    sofia "È stata una bella giocata. Sono meglio di quanto pensassi."


translate italian match2_f7f4510f:


    kira "Interessante..."


translate italian match2_ec16b204:


    emerick "Stai zitta, Kira. Non è il momento per le fantasie."


translate italian match2_cc6b5705:


    beth "Forza [name], mostraci cosa sai fare."


translate italian match2_bfbc8487:


    sofia "Rimani concentrato [name]."


translate italian match2_bc7d616f:


    dpense "La squadra di Steven sembra destabilizzata dopo il nostro pareggio."


translate italian match2_ffa0489a:


    gaby "Bella reazione, ma non allentare la pressione. Torneranno più forti."


translate italian match2_f3d4e5e0:


    ruby "È solo l'inizio, li abbiamo scossi per bene."


translate italian match2_afcc1829:


    mad "Dobbiamo continuare così. Non lasciare che prendano di nuovo il controllo."


translate italian match2_d419577e:


    dpense "Adesso o mai più!"


translate italian match2_d8110760:


    dpense "Riesco a recuperare la palla."


translate italian match2_c6abc97e:


    dpense "Devo solo superare questo tizio e..."


translate italian match2_28acde52:


    hec "Avanti! Adesso!" with hpunch


translate italian match2_9d4ca66f:


    dpense "Hmm?"


translate italian match2_a315a1f9:


    dpense "Che diavolo???"


translate italian match2_0a953b4b:


    mad "Dietro di te!!!" with hpunch


translate italian match2_07a7c5f3:


    julia "Gli faranno male!"


translate italian match2_fc120b89:


    dpense "Mancato! Bastardo..."


translate italian match2_abf9d5be:


    hec "Ahi!"


translate italian match2_c36be87a:


    hec "Togliti di mezzo! Idiota!"


translate italian match2_b67fd9f0:


    dpense "Questo tizio..."


translate italian match2_9a56cc01:


    dpense "Julia sta correndo..."


translate italian match2_c1b81708:


    dpense "Le passerò..."


translate italian match2_05315ce2:


    d "Ciao!"


translate italian match2_1b8dbf39:


    mad "Che diavolo?"


translate italian match2_1ef192a0:


    ruby "C'è fallo lì!"


translate italian match2_bb722d24:


    dpense "E Steven che prende la palla come se niente fosse successo"


translate italian match2_a0fe57e5:


    s "E questo è il secondo!"


translate italian match2_f0c3d1c8:


    d "Grace!!!"


translate italian match2_16e96a3a:


    grace "Io... l'ho toccato..."


translate italian match2_34768985:


    ruby "Non è finita, possiamo ancora tornare."


translate italian match2_5da8614c:


    gaby "Rimani concentrato. C'è ancora tempo. Mantieni la testa fredda."


translate italian match2_7370e626:


    dpense "2-1... Dobbiamo reagire subito. Questa partita non è finita."


translate italian match2_f945104f:


    emerick "Sì! Questo è ciò che volevo vedere. Proprio come previsto."


translate italian match2_db64e3e5:


    kira "Mi piace questa dinamica."


translate italian match2_358ea9d2:


    emerick "Smettila di parlare, Kira. Questo ragazzo deve capire con chi ha a che fare."


translate italian match2_97af930d:


    sofia "Non sottovalutare [name]."


translate italian matchep4second_e78da9e2:


    dpense "Julia palleggia velocemente verso la porta"


translate italian matchep4second_28480f4d:


    mac "Sei tornato, Frenchie!"


translate italian matchep4second_47836406:


    mac "Pensi di avere qualche possibilità con i tuoi tiri deboli?"


translate italian matchep4second_6cd653ed:


    dpense "Sono in una buona posizione per scattare, ma questa volta seguirò il consiglio di Gabriella."


translate italian matchep4second_4d2be1f1:


    d "Un ultimo consiglio per la prossima partita?"


translate italian matchep4second_31a27688:


    gaby "Oh? Hmm... Gioca con la barra."


translate italian matchep4second_8a31fef2:


    dpense "Non sono sicuro di quello che sto facendo..."


translate italian matchep4second_a0e89740:


    mac "Troppo alto!"


translate italian matchep4second_d0988695:


    dpense "Va bene!"


translate italian matchep4second_6a6fbc07:


    dpense "E adesso?"


translate italian matchep4second_8baee4f0:


    mad "[name]! Papera!"


translate italian matchep4second_11991fc8:


    d "Che cosa???"


translate italian matchep4second_f3eab93d:


    dpense "Mi sento come se stessi guardando un uccello volare."


translate italian matchep4second_0e5206c6:


    dpense "Sta... facendo una rovesciata? Davvero?"


translate italian matchep4second_08f1d4c9:


    mad "E questo è in faccia a te!"


translate italian matchep4second_5d63347f:


    d "È dentro! Che colpo!"


translate italian matchep4second_fed7f7c0:


    ruby "Incredibile, Madison!"


translate italian matchep4second_70a788d3:


    d "Wow! Che colpo era quello?"


translate italian matchep4second_fe640476:


    mad "Non lo so. Ho solo improvvisato!"


translate italian matchep4second_6a99c886:


    hec "Questa partita è diventata davvero folle!"


translate italian matchep4second_9b6cbc23:


    s "Dovremo stringere i denti. Non è finita."


translate italian matchep4second_59f5c083:


    gaby "Bella giocata. Non allentare la pressione. Continua così."


translate italian matchep4second_141c267f:


    dpense "Julia tiene palla, palleggiando con incredibile agilità."


translate italian matchep4second_b2f80deb:


    dpense "Le ragazze sono inarrestabili!"


translate italian matchep4second_38fafc12:


    dpense "Ruby sparerà!"


translate italian matchep4second_3ee87ee0:


    dpense "Aspetta! Se l'è perso???"


translate italian matchep4second_39c058d3:


    julia "È dentro!"


translate italian matchep4second_359a4e58:


    ruby "Ce l'abbiamo fatta! Che spettacolo!"


translate italian matchep4second_c970baeb:


    mad "Ahah! Bella giocata, Ruby!"


translate italian matchep4second_e6a4702b:


    hec "Hanno segnato di nuovo... questo non può succedere."


translate italian matchep4second_ac22af49:


    s "Li annienteremo, non c'è dubbio."


translate italian matchep4second_e0d12a3b:


    gaby "Meglio. Continua così e non mollare."


translate italian matchep4second_51e0ab44:


    dpense "2-2. La partita è ripresa, ma dobbiamo mantenere questa energia."


translate italian matchep4second_499c4e94:


    dpense "2-1. Ora dobbiamo finire."


translate italian matchep4second_6fb1e762:


    emerick "Non c'è modo!"


translate italian matchep4second_4eb64cbf:


    kira "Il loro gioco sta diventando più fluido. Questa partita non è finita."


translate italian matchep4second_f94e811f:


    ruby "Continuiamo ad andare avanti, non lasciamoli respirare!"


translate italian matchep4second_d25b09e0:


    dpense "L'altra squadra prova il tutto per tutto e avanza in blocco."


translate italian matchep4second_8ecbf1ba:


    dpense "Si stanno avvicinando all'obiettivo."


translate italian matchep4second_6f171c3f:


    d "Grace, preparati!"


translate italian matchep4second_f80cd25b:


    dpense "Stanno facendo un tiro incrociato!"


translate italian matchep4second_2018f902:


    dpense "Grace verrà battuta!"


translate italian matchep4second_39197b2c:


    d "Dannazione!"


translate italian matchep4second_05315ce2:


    d "Ciao!"


translate italian matchep4second_23e0014d:


    grace "Stai bene?"


translate italian matchep4second_ff0c8649:


    d "Sì, sto bene. Devo continuare a giocare in ogni caso."


translate italian matchep4second_a7849659:


    grace "Grazie [name]! Ci hai salvato..."


translate italian matchep4second_ad983571:


    d "Non è finita."


translate italian matchep4second_5c5a871f:


    dpense "Tirano un tiro incrociato!"


translate italian matchep4second_f0c3d1c8:


    d "Grace!!!"


translate italian matchep4second_aa175d96:


    d "Che parata plastica!"


translate italian matchep4second_b66c1976:


    grace "Grazie!"


translate italian matchep4second_ffe847fc:


    grace "Andiamo!"


translate italian matchep4second_158eee26:


    dpense "Ruby riceve palla e si lancia verso il lato avversario."


translate italian matchep4second_59a47ab7:


    dpense "Julia e Madison la seguono."


translate italian matchep4second_ba0c383f:


    ruby "Madison, a te!"


translate italian matchep4second_8d89b654:


    dpense "Madison ha preso palla ma quel tizio la sta marcando."


translate italian matchep4second_86f915da:


    dpense "Passa a Julia."


translate italian matchep4second_9a044c12:


    ruby "EHI!"


translate italian matchep4second_ec185663:


    d "Julia!"


translate italian matchep4second_4839864c:


    dpense "Sta usando un passaggio di tacco anche mentre cade..."


translate italian matchep4second_5d8fbd38:


    dpense "Ben fatto Julia!"


translate italian matchep4second_1e2f00ad:


    julia "Uffa!"


translate italian matchep4second_03a729f4:


    dpense "Madison non è aperta..."


translate italian matchep4second_0aa83cc9:


    dpense "Ruby o..."


translate italian matchep4second_11b34c7a:


    ruby "È tuo, fai attenzione a Mac!" with hpunch


translate italian matchep4second_c6c0e157:


    dpense "Ora tocca a me. Devo prepararmi a fare questo scatto adesso."


translate italian matchep4second_0ad36974:


    gaby "Ecco fatto, sai cosa fare."


translate italian matchep4second_de458733:


    dpense "Mi metto in posizione, il mio cuore accelera. È questo. Nessuna esitazione."


translate italian matchep4second_46a94b4e:


    dpense "Posiziona il mio piede..."


translate italian matchep4second_00c2f60b:


    dpense "Sposta il mio peso in avanti..."


translate italian matchep4second_baa240b1:


    dpense "Hector urla qualcosa, ma non riesco più a sentirlo. Concentrati."


translate italian matchep4second_a0d76026:


    dpense "Respirare..."


translate italian matchep4second_d3be1be3:


    mad "Forza, puoi farcela, concentrati!"


translate italian matchep4second_8c5ead54:


    ruby "So che puoi fare gol, provaci!"


translate italian matchep4second_00251041:


    julia "Ora è tutto tuo, tutti contano su di te."


translate italian matchep4second_027daccb:


    dpense "Grace, Ruby, Madison, Julia... Stanno tutte guardando. Non posso deluderle."


translate italian matchep4second_80f103fb:


    d "Questa volta è QUELLA GIUSTA!"


translate italian matchep4second_1c691cc8:


    hec "No... Non è possibile!"


translate italian matchep4second_763c08a6:


    julia "Ce l'ha fatta!"


translate italian matchep4second_7150340a:


    dpense "È il goal vincente. Abbiamo vinto!"


translate italian matchep4second_932c5ef1:


    d "L'ho fatto!"


translate italian matchep4second_ff6fc861:


    d "Ahah!"


translate italian matchep4second_3b8a129e:


    emerick "Accidenti!"


translate italian matchep4second_3058ff8c:


    kira "La finale sarà divertente!"


translate italian matchep4second_e5123440:


    beth "Hmm..."


translate italian matchep4second_e1bd8ff6:


    ruby "Sei il migliore Cortex!"


translate italian matchep4second_0e3e9124:


    d "Non posso fare nulla senza di te Minus!"


translate italian matchep4second_2dd9ffce:


    mad "Abbiamo dato tutto e ha pagato. Meritiamo questa finale."


translate italian matchep4second_e37298c9:


    dpense "Le ragazze si congratulano a vicenda, i sorrisi illuminano i loro volti. È una vittoria meritata."


translate italian matchep4second_404ff5ef:


    orushi "Uomo della partita: [name]!"


translate italian matchep4second_9601c912:


    ruby "[name]! Puoi incontrarti con me dopo?"


translate italian matchep4second_b95a51bd:


    d "Certo! Dammi solo il tempo di farmi la doccia e cambiarmi e uscirò subito!"

translate italian strings:


    old "EDUCATION ACTIVATED"
    new "ISTRUZIONE ATTIVATA"


    old "TEMPERAMENT ACTIVATED"
    new "TEMPERAMENTO ATTIVATO"


    old "SPORT ACTIVATED"
    new "SPORT ATTIVATO"


    old "BUDDY ACTIVATED"
    new "COMPAGNO ATTIVATO"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
