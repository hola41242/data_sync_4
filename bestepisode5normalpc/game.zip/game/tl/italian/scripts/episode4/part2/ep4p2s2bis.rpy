


translate italian ep4p2s2bis_49b4de62:


    kira "Ah, eccoti qua! Ci hai messo abbastanza."


translate italian ep4p2s2bis_5522736e:


    d "Ero impegnato... e poi sei tu che mi hai invitato, giusto?"


translate italian ep4p2s2bis_71249c93:


    kira "Esatto, e sono contento che tu sia venuto. Goditi la serata!"


translate italian ep4p2s2bis_abfc4897:


    d "Sembrate piuttosto eccitati stasera. Avete in programma qualcosa di speciale?"


translate italian ep4p2s2bis_0bd36608:


    kira "Niente di folle, solo una serata divertente con gli amici. Mi piace vedere come la gente si rilassa dopo qualche drink. Sempre divertente."


translate italian ep4p2s2bis_22c9f1f2:


    d "Posso immaginare. Quindi, hai un piano di gioco per la serata o ti limiti a seguire la corrente?"


translate italian ep4p2s2bis_3f159b67:


    kira "Un po' di entrambi. Vado a controllare Fanny, mi assicuro che faccia un bel spettacolo e scatto qualche foto per OnlyStan. Paga bene, sai?"


translate italian ep4p2s2bis_321c818f:


    d "Sì, sembra una miniera d'oro..."


translate italian ep4p2s2bis_0f7efc7b:


    kira "Chi lo sa? In questo momento sono soldi facili."


translate italian ep4p2s2bis_f6f2c8fb:


    d "Sembra che tu abbia capito tutto. Hai mai pensato di fare qualcosa di legittimo?"


translate italian ep4p2s2bis_7452d65d:


    kira "Cosa è legittimo, davvero? Se paga, funziona. A differenza tua, non ho bisogno di sudare per ottenere risultati."


translate italian ep4p2s2bis_8a617357:


    d "Dice la ragazza che usa il telefono come se fosse un lavoro a tempo pieno."


translate italian ep4p2s2bis_c7798e5b:


    kira "Touché. Ma siamo onesti, tra studiare e gestire un'azienda, chi ha il vero potere qui?"


translate italian ep4p2s2bis_b42f115b:


    d "Immagino che lo vedremo dopo aver vinto il premio BEST"


translate italian ep4p2s2bis_dcce6b13:


    kira "Oh? Fiducia? Mi piace. Non rovinarla."


translate italian ep4p2s2bis_b0546b66:


    kira "Divertitevi, ma non dimenticate la grande partita di domani."


translate italian palazio_gabriella_charlotte_14ef5c37:


    dpense "Ah, Gabriella?"


translate italian palazio_gabriella_charlotte_49c12c87:


    dpense "E... Charlotte?"


translate italian palazio_gabriella_charlotte_1d8386f2:


    cha "Ultimamente mi incuriosisce l'idea di uscire con un ragazzo più giovane."


translate italian palazio_gabriella_charlotte_0fb2ac99:


    dpense "Interessante... Origliamo un po'."


translate italian palazio_gabriella_charlotte_3769dfaf:


    gaby "Ah? Vuoi dire... qualcuno che ha appena l'età per ordinare un drink?"


translate italian palazio_gabriella_charlotte_87137957:


    cha "Sì..."


translate italian palazio_gabriella_charlotte_50cf5c9c:


    gaby "Oh, interessante. E questa sarebbe una novità per te, eh?"


translate italian palazio_gabriella_charlotte_c6ff4f28:


    cha "Completamente. Non mi era mai passato per la testa prima. Tu?"


translate italian palazio_gabriella_charlotte_c70a5ce7:


    gaby "Lo stesso vale per me, ma sinceramente inizio a capirne il fascino."


translate italian palazio_gabriella_charlotte_6a3e5667:


    cha "Hanno questa energia fresca, sai? È piuttosto eccitante."


translate italian palazio_gabriella_charlotte_03604e35:


    dpense "Stanno parlando di me?"


translate italian palazio_gabriella_charlotte_3869eae3:


    gaby "Sì, e c'è qualcosa di spontaneo in loro. Qualcosa di... imprevedibile. Può essere rinfrescante."


translate italian palazio_gabriella_charlotte_2087bed4:


    cha "Esatto. Deve avere anche un po' di maturità. Niente babysitter."


translate italian palazio_gabriella_charlotte_b7c2e1d5:


    gaby "E dovrebbe essere intelligente. Se è solo carino ma noioso, non funzionerà."


translate italian palazio_gabriella_charlotte_ae875628:


    cha "Oh, assolutamente. Ma immagina qualcuno con energia e arguzia? È raro."


translate italian palazio_gabriella_charlotte_6887397d:


    gaby "E chi sa come tenere il passo. Ad alcuni piace fare grandi discorsi, ma..."


translate italian palazio_gabriella_charlotte_1871a36d:


    cha "Ti è capitato di addormentarti subito dopo? Ci sono riuscito."


translate italian palazio_gabriella_charlotte_1aac0b32:


    gaby "Voglio qualcuno che mi ascolti davvero, capisci?"


translate italian palazio_gabriella_charlotte_c80e4db7:


    cha "Oh, intendi un tizio che non si limita ad annuire ma si impegna davvero? Questo è fondamentalmente un unicorno."


translate italian palazio_gabriella_charlotte_d90f3750:


    gaby "Esatto! Un ragazzo che sa quando sfoggiare il coraggio ma anche quando trattenersi."


translate italian palazio_gabriella_charlotte_47a77884:


    cha "Mmm, questa sì che sarebbe una cosa che vale la pena esplorare..."


translate italian palazio_gabriella_charlotte_aa5bd80d:


    dpense "È stata una discussione interessante. Devo restare in contatto con loro."


translate italian palazio_gabriella_charlotte_b425999c:


    dpense "Non sapevo che si conoscessero."


translate italian palazio_gabriella_charlotte_3b497e25:


    dpense "Potrebbe essere interessante..."


translate italian palazio_dancefloor_6d208509:


    dpense "Wow! Chi è quella donna?"


translate italian palazio_dancefloor_8d839d85:


    d "Balli bene. Difficile non notarlo."


translate italian palazio_dancefloor_16616b27:


    ji "Oh? È questa la tua frase d'apertura? Grassetto."


translate italian palazio_dancefloor_7e8f7728:


    d "Mi piace considerarla più come un'osservazione che come una frase d'approccio."


translate italian palazio_dancefloor_77c1853a:


    ji "Hmm... Quindi dovrei ringraziarti?"


translate italian palazio_dancefloor_703bcbb5:


    d "Solo se lo pensi davvero."


translate italian palazio_dancefloor_db7ea34b:


    ji "Mi piacciono gli uomini che sanno parlare. Dimmi, non sei un po' giovane per me?"


translate italian palazio_dancefloor_73f96a46:


    d "Forse, ma l'età è solo una questione di prospettiva, non è vero?"


translate italian palazio_dancefloor_57e473f6:


    ji "Amo un giovane uomo sicuro di sé. Ma essere audaci non sarà sufficiente."


translate italian palazio_dancefloor_3a66788a:


    d "Allora di cosa altro ho bisogno?"


translate italian palazio_dancefloor_5c95885b:


    ji "Mistero. Controllo. E, cosa più importante, sapere quando smettere di inseguire."


translate italian palazio_dancefloor_7367dea2:


    ji "Mandami un messaggio... se pensi di riuscire a tenere il passo. E a proposito, io sono Evelyn."


translate italian palazio_dancefloor_17ec4e46:


    dpense "Lei è misteriosa... È intrigante."


translate italian palazio_dancefloor_d70e0b8e:


    dpense "Mi piace che!"


translate italian palazio_kira_fanny_f5e96e01:


    d "Quindi, questo è il tuo grande progetto stasera?"


translate italian palazio_kira_fanny_397b9762:


    kira "Cosa posso dire? Il denaro non si crea da solo."


translate italian palazio_kira_fanny_3d79c3a3:


    d "E io che pensavo ti stessi semplicemente godendo lo spettacolo."


translate italian palazio_kira_fanny_ecc06f6e:


    kira "Oh, certo che sì, ma mi assicuro anche che ogni angolazione faccia sì che Fanny valga ogni centesimo."


translate italian palazio_kira_fanny_eabe8c3d:


    d "Mmm... capisco."


translate italian palazio_kira_fanny_87a80f3c:


    d "Aspettare..."


translate italian palazio_kira_fanny_6feb7f18:


    d "Non indossa mutandine?" with hpunch


translate italian palazio_kira_fanny_bf70984c:


    kira "Ahah! No! I ragazzi si eccitano a pensarci, quindi mi concentro sul suo sedere!"


translate italian palazio_kira_fanny_8df0b723:


    d "Sei fortunato che non ci siano molte persone lì dentro."


translate italian palazio_kira_fanny_45c23257:


    kira "Sì, è presto. Ecco perché siamo venuti qui ora."


translate italian palazio_kira_fanny_ae34bddc:


    d "Cosa intendi?"


translate italian palazio_kira_fanny_8d1b7bcd:


    kira "Possiamo lavorare senza che degli idioti ubriachi ci diano fastidio."


translate italian palazio_kira_fanny_829f95d3:


    d "Ti stai impegnando davvero tanto."


translate italian palazio_kira_fanny_0b799d82:


    kira "Sembri sorpreso. Non faccio le cose a metà. Se lo faccio, lo faccio bene."


translate italian palazio_kira_fanny_5f32cb00:


    d "Ricordami di non sottovalutarti mai."


translate italian palazio_kira_fanny_2624a59e:


    kira "Scelta intelligente!"


translate italian palazio_kira_fanny_80e19788:


    kira "Vieni qui! Facciamoci un selfie insieme"


translate italian palazio_kira_fanny_6672ddba:


    kira "Fanny! Vieni qui! Doppio bacio!"


translate italian palazio_kira_fanny_b7e3ab68:


    kira "Controlla i tuoi OnlyStan più tardi."


translate italian palazio_kira_fanny_1a7ff2b3:


    d "Ti ascolta davvero."


translate italian palazio_kira_fanny_0bf9a922:


    kira "Certo che sì."


translate italian palazio_kira_fanny_c4de64ce:


    kira "Lei sa da dove provengono i suoi soldi!"


translate italian palazio_kira_fanny_d066b3a0:


    kira "Gli uomini la pagano profumatamente, e Fanny non deve nemmeno muovere un dito."


translate italian palazio_kira_fanny_90d0f720:


    kira "Sto addirittura iniziando a usare l'intelligenza artificiale per creare brevi clip... ora vi faccio vedere!"


translate italian palazio_kira_fanny_17b9a34a:


    d "E nessuno si lamenta?"


translate italian palazio_kira_fanny_9834c423:


    kira "Perché dovrebbero? Stanno ottenendo esattamente ciò che vogliono, anche se non è 'reale'. Win-win."


translate italian palazio_kira_fanny_8ad9b91e:


    kira "Sai, i contenuti falsi sono molto più redditizi di quelli veri. Non è una truffa, è solo un adattamento al mercato."


translate italian palazio_kira_fanny_f9ee1416:


    d "E tu? Gestisci questo piccolo impero da dietro le quinte... hai mai pensato di salire sul palco?"


translate italian palazio_kira_fanny_ba2693ca:


    kira "Io? Mai. Sono un Orushi. Ho una reputazione da mantenere. Esibirsi? Non è il mio genere."


translate italian palazio_kira_fanny_5e1f4a8b:


    kira "Comunque, divertiti, ma non dimenticare che domani hai una partita. Vediamo se sei bravo in campo come lo sei con le ragazze."


translate italian palazio_kira_fanny_f77eea5e:


    dpense "Ha ragione. La partita..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
