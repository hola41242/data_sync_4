


translate italian ep4p2s3_1b4b1a57:


    dpense "Bene...domani c'è la partita."


translate italian ep4p2s3_f5497cd8:


    dpense "Dovrò confrontarmi con la squadra di Steven."


translate italian ep4p2s3_a4145184:


    dpense "E Hector... probabilmente cercherà guai."


translate italian ep4p2s3_fd950b31:


    dpense "Pfff..."


translate italian ep4p2s3_e009422d:


    dpense "Red mi ha chiesto di mandarle un messaggio."


translate italian ep4p2s3_8d0d9a0a:


    dpense "Facciamolo... Almeno sarà tutto tolto dai piedi."


translate italian ep4p2s3_b2db8fea:


    dpense "Beh, direi che è già qualcosa."


translate italian ep4p2s3_7de58b15:


    dpense "Che pomeriggio con Grace..."


translate italian ep4p2s3_8ecbb8fb:


    dpense "Il suo calore, la sua risata... e quel momento nella jacuzzi. Indimenticabile."


translate italian ep4p2s3_e869a1ff:


    dpense "La serata a casa di Sofia è stata incredibile."


translate italian ep4p2s3_18b96cc1:


    dpense "Lei si apre completamente con me, mentre Red resta indietro, sempre in guardia."


translate italian roommcep42_9a227918:


    d "Che ne dici?"


translate italian roommcep42_1d8f8cec:


    dpense "E... nessuna risposta..."


translate italian roommcep42_cd3b9b76:


    dpense "Bene, è ora di dormire un po'... anche se ho ancora la testa in subbuglio."


translate italian roommcep42_68efe25b:


    d "Di nuovo? Che cos'è questo?"


translate italian roommcep42_4ee878c5:


    "Charlotte chiede di aggiungerti ai suoi contatti..."


translate italian roommcep42_f16cfd6d:


    "Vuoi aggiungerla?"


translate italian roommcep42_29a3c486:


    d "Cosa vuole da me?"


translate italian roommcep42_06b50b53:


    d "Non ho capito niente di tutto ciò..."


translate italian roommcep42_cf36c76d:


    d "Ho già abbastanza persone con cui avere a che fare..."


translate italian roommcep42_e5eaf1ae:


    dpense "Speriamo che questa notte mi porti un po' di riposo... O forse solo sogni più strani, come al solito."


translate italian reverobotchat_5074775d:


    dpense "Tutto sembra... strano. Non so bene dove mi trovo, ma mi sembra stranamente familiare, come un ricordo che non riesco a cogliere."


translate italian reverobotchat_b353e56c:


    d "Che posto è questo?"


translate italian reverobotchat_1d9e1362:


    "Hai fatto molta strada, ma c'è ancora molto da fare."


translate italian reverobotchat_61c079a3:


    dpense "Chi c'è?"


translate italian reverobotchat_a8e4f680:


    "Le tue scelte plasmano il percorso. Il risultato non è mai fisso."


translate italian reverobotchat_e203e08c:


    dpense "Dove mi trovo?"


translate italian reverobotchat_90cc6b8b:


    dpense "C'è un ronzio meccanico nell'aria."


translate italian reverobotchat_172d9967:


    dpense "Che cos'è questo?"


translate italian reverobotchat_1d738374:


    dpense "Un... gatto-robot?"


translate italian reverobotchat_ba346cd0:


    d "Signor Rufus? È lei?"


translate italian reverobotchat_a4080e44:


    "Profilo attivato."


translate italian reverobotchat_77795da7:


    dpense "Cosa? Cosa significa?"


translate italian reverobotchat_68c3eab0:


    "Analizzare."


translate italian reverobotchat_90926537:


    "Adattare."


translate italian reverobotchat_c12d5bca:


    "Atto."


translate italian reverobotchat_ba7bb93c:


    d "Di cosa stai parlando? Adattarsi a cosa?"


translate italian reverobotchat_445be304:


    "I pezzi sono in movimento. Tu sei uno di loro."


translate italian reverobotchat_d1fb5488:


    d "Pezzi? Movimento? Cosa significa tutto questo?"


translate italian reverobotchat_dea02d29:


    "È giunto il momento. Svegliati... e ricorda."


translate italian reverobotchat_733ada87:


    "PROFILO ATTIVATO."


translate italian reverobotchat_2ecd560f:


    dpense "Quel sogno... Mi è sembrato così vivido. Il gatto robot, la voce... Cosa significa 'Profilo attivato'?"


translate italian reverobotchat_e68135ad:


    "PROFILO ATTIVATO" with hpunch


translate italian reverobotchat_11991fc8:


    d "Che cosa???"


translate italian reverobotchat_91b9690d:


    d "Questo è il mio telefono?"

translate italian strings:


    old "A great night with good company!"
    new "Una fantastica serata in ottima compagnia!"


    old "Look who we found tonight!"
    new "Guarda chi abbiamo trovato stasera!"


    old "Awesome night! Let's do this again anytime!😊"
    new "Fantastica serata! Facciamolo di nuovo quando vuoi!😊"


    old "A great night with my BF!"
    new "Una fantastica serata con il mio ragazzo!"


    old "Partying together!"
    new "Facciamo festa insieme!"


    old "Oh! I missed this? Next time I will be there!"
    new "Oh! Mi è sfuggito? La prossima volta ci sarò!"


    old "You're doing great [name]."
    new "Stai andando alla grande [name]."


    old "What do you want from me?"
    new "Cosa vuole da me?"


    old "Just listen to me."
    new "Ascoltami e basta."


    old "Play for you."
    new "Gioca per te."


    old "What does that mean?"
    new "Che cosa significa?"


    old "Time will come."
    new "Verrà il momento."


    old "Come on! This is cryptic!"
    new "Dai! Questo è criptico!"


    old "Once we met, remember this."
    new "Una volta che ci siamo incontrati, ricordatelo."


    old "remember what?"
    new "ricordi cosa?"


    old "Hey, ready for tomorrow?"
    new "Ehi, pronti per domani?"


    old "Of course! You?"
    new "Certo! Tu?"


    old "I’m a little nervous. Steven’s team is tough, and I don’t want to let everyone down."
    new "Sono un po' nervoso. La squadra di Steven è tosta e non voglio deludere tutti."


    old "Don’t even think about that! They’re strong, sure, but so are we."
    new "Non pensarci nemmeno! Sono forti, certo, ma lo siamo anche noi."


    old "Plus, we’ve got Madison! And you! You’re our secret weapon."
    new "E poi abbiamo Madison! E tu! Tu sei la nostra arma segreta."


    old "Secret weapon, huh? No pressure there."
    new "Arma segreta, eh? Nessuna pressione."


    old "Hey, if anyone can handle it, it’s you. You’ve got this."
    new "Ehi, se c'è qualcuno che può farcela, quello sei tu. Hai questo."


    old "Thanks, Ruby. I’ll do my best."
    new "Grazie, Ruby. Farò del mio meglio."


    old "I know you will. Just focus on the game, not the scoreboard. We’ll handle the rest."
    new "So che lo farai. Concentrati solo sulla partita, non sul tabellone. Noi ci occuperemo del resto."


    old "Hum... Can I ask you something?"
    new "Mmm... Posso chiederti una cosa?"


    old "Sure!"
    new "Sicuro!"


    old "Tomorrow, after the match..."
    new "Domani, dopo la partita..."


    old "Would you like to come to the cinema with me?"
    new "Vuoi venire al cinema con me?"


    old "Yes! It would be a pleasure!"
    new "Sì! Sarebbe un piacere!"


    old "Thank you so much!!!"
    new "Grazie mille!!!"


    old "I promised to you."
    new "Te l'ho promesso."


    old "Alright. I’ll try to get some sleep. See you tomorrow!"
    new "Va bene. Cercherò di dormire un po'. Ci vediamo domani!"


    old "You better bring your A-game tomorrow, because we’re taking them down. Good night!"
    new "Meglio che tu dia il massimo domani, perché li stiamo abbattendo. Buonanotte!"


    old "Hey, remember earlier at the hospital? I found something weird in my pocket: '1410'."
    new "Ehi, ti ricordi prima all'ospedale? Ho trovato qualcosa di strano nella mia tasca: '1410'."


    old "What? That’s random."
    new "Cosa? È casuale."


    old "I have no idea where it came from. That’s why I’m asking you."
    new "Non ho idea da dove provenga. Ecco perché te lo chiedo."


    old "I… don’t think it rings a bell. Maybe it’s a date? 14/10? Or a time? 14:10?"
    new "Io... non credo che ti faccia suonare un campanello. Forse è una data? 14/10? O un orario? 14:10?"


    old "No, it’s just '1410'. Plain and simple."
    new "No, è solo '1410'. Chiaro e semplice."


    old "Hmm… That’s strange. Do you think someone might have slipped it into your pocket?"
    new "Hmm... Che strano. Pensi che qualcuno possa avertelo infilato in tasca?"


    old "Honestly, I don’t know. Maybe. It’s weird though."
    new "Onestamente, non lo so. Forse. È strano però."


    old "Yeah… With everything going on today, I didn’t even notice."
    new "Sì... Con tutto quello che è successo oggi, non me ne sono nemmeno accorto."


    old "But this is kind of unsettling."
    new "Ma questo è un po' inquietante."


    old "I’ll let you know if I figure it out."
    new "Ti farò sapere se ci riesco."


    old "Please do. Good night!"
    new "Per favore, fallo. Buonanotte!"


    old "Good night, Julia."
    new "Buonanotte, Julia."





translate italian strings:


    old "Once we meet, remember this."
    new "Quando ci incontreremo, ricordatelo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
