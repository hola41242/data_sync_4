


translate italian ep4p2s1_91945af7:


    grace "Non vedevo l'ora di trascorrere un po' di tempo insieme."


translate italian ep4p2s1_b6d0af63:


    d "Capisco. Allora, cosa ti passa per la testa oggi?"


translate italian ep4p2s1_3ac0262d:


    grace "Dai, ho un'idea che potrebbe piacerti. Seguimi."


translate italian ep4p2s1_e525e412:


    grace "Ecco la mia stanza. Probabilmente te la ricordi... ma questa volta ho una sorpresa."


translate italian ep4p2s1_4ba5428a:


    d "Una sorpresa? Ora sono curioso."


translate italian ep4p2s1_ca1a1e05:


    grace "Bene, preparati! Spero che ti piacciano le jacuzzi perché la mia ti farà dimenticare tutte le tue preoccupazioni. Niente batte l'acqua calda e la buona compagnia!"


translate italian ep4p2s1_7878335e:


    d "Una jacuzzi? Davvero? È un'idea fantastica."


translate italian ep4p2s1_ce4cf5f3:


    grace "Dammi un secondo, prendo dei costumi da bagno."


translate italian ep4p2s1_06a838b1:


    dpense "Oh no... Non ho pensato di portare un costume da bagno. Cosa farò se me lo chiede?"


translate italian ep4p2s1_7a6ff864:


    grace "Dimmi cosa ne pensi."


translate italian ep4p2s1_edaa937c:


    dpense "Wow... Sa davvero come attirare l'attenzione. Quel costume da bagno le sta benissimo, ma si vede che si diverte a mettere alla prova le mie reazioni."


translate italian ep4p2s1_cc979e67:


    d "È... molto elegante."


translate italian ep4p2s1_8b13eea6:


    dpense "Non so se 'elegante' è la parola che sperava. Sa esattamente cosa sta facendo."


translate italian ep4p2s1_feae9023:


    grace "Davvero? Aspetta, ne ho un altro."


translate italian ep4p2s1_8d6d2b18:


    dpense "Ed eccola di nuovo... Si sta divertendo troppo a prendermi in giro."


translate italian ep4p2s1_149a78e5:


    d "Anche questo è spettacolare. Hai un gusto fantastico."


translate italian ep4p2s1_e35882b0:


    dpense "Come faccio a restare concentrato? Lei è incredibile in tutti questi abiti."


translate italian ep4p2s1_035e7d2c:


    grace "Hmm... Sei sicuro che sia il costume da bagno ad impressionarti?"


translate italian ep4p2s1_5417fd7d:


    dpense "Ha quel sorriso provocante... Sa esattamente cosa sta facendo e come farmi perdere l'equilibrio."


translate italian ep4p2s1_0bea34b9:


    d "È quello che dovrei dire, ma mi stai rendendo le cose difficili."


translate italian ep4p2s1_b8942a86:


    grace "Entra nella jacuzzi, arrivo tra due secondi."


translate italian ep4p2s1_b2deb524:


    dpense "Niente costume... Vabbè, improvviserò. Entro per primo, forse non se ne accorgerà."


translate italian ep4p2s1_5bec97e4:


    d "Wow... È ancora meglio di quanto immaginassi."


translate italian ep4p2s1_55301d7a:


    dpense "L'acqua è perfetta. Lenitiva, calda..."


translate italian ep4p2s1_81295a2f:


    grace "Pronti! Visto? Non ci ho messo molto."


translate italian ep4p2s1_ce4058d4:


    dpense "È incredibile. Quel costume da bagno... sa esattamente come attirare l'attenzione."


translate italian ep4p2s1_2891d94c:


    grace "Aspetta un attimo... Sei... nudo?!"


translate italian ep4p2s1_07c397d9:


    dpense "Oh no..."


translate italian ep4p2s1_1694b6fb:


    d "Uh, sì. Scusa, non avevo il costume da bagno. Pensavo che sarebbe stato meno imbarazzante così."


translate italian ep4p2s1_5cf2745f:


    grace "Meno imbarazzante?"


translate italian ep4p2s1_493c649c:


    grace "Be', almeno sai davvero improvvisare, non è vero?"


translate italian ep4p2s1_b0b8bf84:


    dpense "La sua risata è così naturale e genuina. Trasforma quello che avrebbe potuto essere un momento imbarazzante in qualcosa di leggero e divertente. È incredibile."


translate italian ep4p2s1_9c5ed970:


    grace "Immagino che questo renda le cose... interessanti. Va bene, farò finta di non vedere niente."


translate italian ep4p2s1_2689ddc3:


    d "Grazie per la tua... comprensione."


translate italian ep4p2s1_f9e2bcdc:


    grace "Allora... dimmi, cosa ti passa per la testa in questo momento?"


translate italian ep4p2s1_f8bb1a7d:


    d "Soprattutto tu e il tuo... corpo."


translate italian ep4p2s1_05d4fb55:


    dpense "{size=-5}Lei è il mix perfetto di calore ed energia. Ogni dettaglio di questo momento è impresso nella mia memoria: il calore dell'acqua, il suo sorriso che illumina tutto e quello sguardo nei suoi occhi che dice che potrebbe restare qui per sempre."


translate italian ep4p2s1_91cb5e2f:


    grace "Sai... Sembra che il mondo intero non esista più. Solo tu, io e quest'acqua calda."


translate italian ep4p2s1_dfb599a8:


    grace "È raro sentirsi così... bene. Con te, posso essere veramente me stessa."


translate italian ep4p2s1_15438c00:


    d "È grazie a te. Tu rendi tutto speciale."


translate italian ep4p2s1_c72f2895:


    grace "L'acqua è calda... ma non quanto te in questo momento."


translate italian ep4p2s1_4b8541f2:


    dpense "La sua schiena contro il mio petto, la sua pelle bagnata che sfiora la mia... È come se tutto il mio corpo reagisse alla sua vicinanza."


translate italian ep4p2s1_8625c88f:


    grace "Sai, penso che sia carino che tu sia imbarazzato. Dimostra che sei vulnerabile, e questo è raro nei ragazzi."


translate italian ep4p2s1_57705c71:


    dpense "Carina? Questo è un modo per dirlo... ma almeno non sembra a disagio."


translate italian ep4p2s1_33273874:


    grace "Puoi toccarmi, lo sai... Amo la sensazione delle tue mani sulla mia pelle..."


translate italian ep4p2s1_b59160c0:


    d "Grace..."


translate italian ep4p2s1_fd9b9b99:


    dpense "Sa esattamente cosa sta facendo. Il mio cuore sta battendo così forte che deve sentirlo."


translate italian ep4p2s1_c5774ad3:


    dpense "Ogni sua mossa, ogni sua parola sussurrata... mi ha completamente stregato."


translate italian ep4p2s1_b318ce0d:


    grace "Shh... Non c'è bisogno di parole."


translate italian ep4p2s1_3cf0e8c6:


    grace "Volevo dirti... questo significa davvero molto per me. Tu, noi... tutto ciò che condividiamo."


translate italian ep4p2s1_d5ffd576:


    grace "A volte ho la sensazione di pensare troppo a tutto, ma con te tutto sembra così semplice."


translate italian ep4p2s1_14f051c6:


    d "Sei incredibile, Grace. Non so come ho fatto ad essere così fortunato."


translate italian ep4p2s1_a9e714f0:


    grace "Non è fortuna... sei tu."


translate italian ep4p2s1_78fa8715:


    grace "Sei così... Duro..."


translate italian ep4p2s1_a6ee6892:


    grace "Adoro quella sensazione..."


translate italian ep4p2s1_3d1cb93e:


    grace "Io... Mi fa... eccitare..."


translate italian ep4p2s1_4b00b4ea:


    d "Grace, mi stai rendendo difficile resistere..."


translate italian ep4p2s1_4123acb2:


    grace "Quindi... non..."


translate italian ep4p2s1_e9612217:


    grace "Prendimi [name], fammi sentire il tuo desiderio."


translate italian ep4p2s1_4239d05c:


    grace "Che ne dici se continuiamo in un posto un po' più... comodo?"


translate italian ep4p2s1_b1ce614c:


    grace "Avvicinati. Lascia che ti mostri quanto sei importante per me."


translate italian ep4p2s1_3ced0deb:


    grace "Io... vorrei provare qualcosa, ma... non ne sono sicura."


translate italian ep4p2s1_060b5aa3:


    d "Grace, puoi dirmi qualsiasi cosa."


translate italian ep4p2s1_070c0a44:


    grace "È solo che... non l'ho mai fatto prima. Non voglio deluderti."


translate italian ep4p2s1_0d6bf48d:


    d "Ehi, guardami. Non hai niente da dimostrare. Tutto ciò che conta è che condividiamo questo momento insieme."


translate italian ep4p2s1_0ad386e3:


    grace "Sei davvero... Sai esattamente cosa dire. Grazie."


translate italian ep4p2s1_e7cbe062:


    grace "Voglio che questo momento sia speciale... solo per noi due."


translate italian ep4p2s1_c7b664d2:


    d "Grace... io..."


translate italian ep4p2s1_92ea9e59:


    dpense "Non c'è bisogno di finire la frase. Lei sa. Lei capisce."


translate italian ep4p2s1_967def27:


    dpense "Lo fa con tutto il cuore."


translate italian ep4p2s1_b77f8cb3:


    dpense "Sento che non è una professionista ma lo sta facendo per me"


translate italian ep4p2s1_5d9a560f:


    grace "Questo è... diverso da quello che ho visto nei film"


translate italian ep4p2s1_7b33f5ab:


    d "Oh? Guardi i porno?"


translate italian ep4p2s1_00fe7e07:


    grace "No... Beh sì, ma era a scopo educativo!"


translate italian ep4p2s1_fcae45c4:


    d "Educativo?"


translate italian ep4p2s1_64ab9de4:


    grace "Sì... avevo bisogno di consigli su come farlo bene, quindi..."


translate italian ep4p2s1_97ab9f33:


    d "Avresti dovuto chiedere a Kira!"


translate italian ep4p2s1_a46e0701:


    grace "Non è una cattiva idea!"


translate italian ep4p2s1_6a1ea1df:


    dpense "Ora sento la sua tensione... Devo fare qualcosa."


translate italian ep4p2s1_c68a4ce9:


    d "Vieni qui, non c'è bisogno che tu mi faccia piacere in questo modo."


translate italian ep4p2s1_d921915a:


    grace "Sei sicuro che..."


translate italian ep4p2s1_cfff1add:


    d "Ssshhh!"


translate italian ep4p2s1_7e93c462:


    grace "Sei incredibile... Mi fai sentire così... viva."


translate italian ep4p2s1_ca2de023:


    dpense "Voglio che sappia quanto è speciale. Voglio che questo momento resti impresso nei nostri cuori per sempre."


translate italian ep4p2s1_ddcb961f:


    d "Grace... sei tutto per me. E farò tutto il possibile per renderti felice."


translate italian ep4p2s1_39da1184:


    grace "Sii gentile... È la prima volta..."


translate italian ep4p2s1_0fca028b:


    d "Per ora mi limiterò a mettere la punta..."


translate italian ep4p2s1_21a8ca52:


    grace "Va bene..."


translate italian ep4p2s1_aeb55d36:


    d "Va bene?"


translate italian ep4p2s1_af36b020:


    grace "Sì... Puoi continuare..."


translate italian ep4p2s1_e9aa9767:


    grace "Oh mio Dio... Sei così... grande!"


translate italian ep4p2s1_99d97c19:


    grace "Lo sento attraverso il mio... Ohhhhhhhhhhhhh!"


translate italian ep4p2s1_1b3995fd:


    d "Grace? Stai bene?"


translate italian ep4p2s1_bc3d1f74:


    grace "Va bene? È meraviglioso!!!"


translate italian ep4p2s1_452f4bf8:


    grace "Mio Dio, hai raggiunto il mio grembo! È stato quasi travolgente!"


translate italian ep4p2s1_cdd4eede:


    grace "Ne voglio di più!!!"


translate italian ep4p2s1_6a230ed2:


    d "Cioè?"


translate italian ep4p2s1_3ec569ec:


    grace "Sì [name]! Fallo!"


translate italian ep4p2s1_777bd54e:


    dpense "Eccoci qui, insieme, in questo momento sospeso."


translate italian ep4p2s1_73c2150f:


    dpense "Ogni battito cardiaco, ogni respiro in sincronia. Questa è la vera felicità."


translate italian ep4p2s1_74aab3e0:


    grace "È incredibile! Per favore non fermarti!"


translate italian ep4p2s1_f400c5bf:


    dpense "Ogni momento trascorso con lei è un mix di emozioni intense."


translate italian ep4p2s1_459e7e6a:


    dpense "I suoi gesti sono delicati ma pieni di passione."


translate italian ep4p2s1_87e8bae4:


    grace "Più in profondità! Voglio sentirti riempirmi completamente!"


translate italian ep4p2s1_d1f5d42b:


    dpense "Lei si sta donando completamente a me e io voglio fare lo stesso per lei."


translate italian ep4p2s1_2db32ad0:


    grace "Io... sono così felice di essere con te..."


translate italian ep4p2s1_419cc14a:


    dpense "Il suo respiro, i suoi sussurri... tutto di lei sembra sincronizzarsi con me."


translate italian ep4p2s1_316f8b34:


    dpense "È come se fossimo diventati una cosa sola."


translate italian ep4p2s1_b0ccaec1:


    grace "[name] Penso che sto per venire..."


translate italian ep4p2s1_1e1adda8:


    d "Ecco fatto, Grace! Lascia che il piacere arrivi. Voglio che tu lo senta davvero."


translate italian ep4p2s1_4c15fa43:


    grace "[name]! Non riesco a fermarlo!"


translate italian ep4p2s1_26e8afcc:


    grace "E' proprio..."


translate italian ep4p2s1_fb38a634:


    grace "Belloooooooo!"


translate italian ep4p2s1_6e552b19:


    dpense "Non riesco a trattenermi... Il suo corpo, il suo orgasmo..."


translate italian ep4p2s1_d7dfd55e:


    dpense "Vengo anch'io!"


translate italian ep4p2s1_333214ba:


    d "Grace!! Io..."


translate italian ep4p2s1_fc5e024b:


    grace "Oh mio Dio! Lo sento pulsare dentro di me!"


translate italian ep4p2s1_b2db4984:


    grace "Più forte!"


translate italian ep4p2s1_847f2188:


    grace "Voglio che tu mi riempia!"


translate italian ep4p2s1_1540e282:


    d "Grace! Io..."


translate italian ep4p2s1_1385b400:


    grace "Ahhhhhhhhhhhhhhhh!"


translate italian ep4p2s1_801e530d:


    grace "SIIIIIIIIIIIII!"


translate italian ep4p2s1_39192f82:


    grace "È così bellooooooo!"


translate italian ep4p2s1_2825f206:


    grace "Sto venendo ancora! Ahhh, ahhhh, unhhhhh"


translate italian ep4p2s1_59364ac1:


    grace "Non riesco a respirare, non riesco..."


translate italian ep4p2s1_a2035db7:


    grace "Ohhhhhhhhhhhh"


translate italian ep4p2s1_b844df27:


    grace "È stato... perfetto. Grazie per questo momento."


translate italian ep4p2s1_4c6db8a5:


    dpense "Vederla così in pace mi riempie di felicità. Voglio darle molto di più di questo momento."


translate italian ep4p2s1_95225672:


    d "Grace... sei incredibile. Rendi tutto speciale."


translate italian ep4p2s1_d9b36350:


    grace "Grazie per questa... prima volta..."


translate italian ep4p2s1_580278d9:


    grace "L'hai resa indimenticabile..."


translate italian ep4p2s1_957fa26d:


    d "Spero che non ti abbia fatto male..."


translate italian ep4p2s1_841ac660:


    grace "Mi hai fatto male??? Stai scherzando?"


translate italian ep4p2s1_6d159a7a:


    grace "La prossima volta voglio che tu ci vada più forte! Ne avevo bisogno di più!"


translate italian ep4p2s1_39dccf09:


    d "Ahaha! Sei incredibile!"


translate italian ep4p2s1_3eee8d5e:


    grace "È questo che ti piace di me, no?"


translate italian ep4p2s1_2d1667b9:


    d "Certo!"


translate italian ep4p2s1_a1f2194a:


    grace "Bene... mia madre tornerà da un momento all'altro. Dovremmo vestirci."


translate italian ep4p2s1_e439758c:


    drew "Allora, sei ancora qui, [name]? Immagino che tu abbia avuto una giornata piacevole."


translate italian ep4p2s1_9f20b4e2:


    dpense "Signora Drew... Sempre impressionante e un po' intimidatoria. Ma oggi, c'è qualcosa di diverso nel suo sguardo... quasi come una sfida."


translate italian ep4p2s1_dd984e2d:


    d "Sì, Signora Drew. Grace mi ha invitato a passare un po' di tempo qui."


translate italian ep4p2s1_a7f3baa7:


    drew "Lo vedo. Sembra particolarmente felice ultimamente. Potrebbe essere la tua influenza?"


translate italian ep4p2s1_1a216738:


    dpense "Il suo tono è lusinghiero, ma i suoi occhi sembrano analizzare ogni parola. Trasuda un'aura che fonde controllo e seduzione."


translate italian ep4p2s1_c8837520:


    d "Grace è incredibile. Merita tutta la felicità del mondo."


translate italian ep4p2s1_80d74b76:


    drew "Affascinante, ma ricorda che sono la madre di Grace e anche il tuo preside."


translate italian ep4p2s1_8b8420f6:


    drew "Finché vinci e fai le cose per bene, non vedo alcun problema."


translate italian ep4p2s1_f3b2beab:


    dpense "Le sue parole sono lusinghiere, ma sono anche un avvertimento. Sta mettendo alla prova i miei nervi, la mia sicurezza e le mie intenzioni."


translate italian ep4p2s1_d00f5771:


    drew "Non abbassare la guardia. Sembri promettente, ma le vere sfide sono appena iniziate. Fidati, ti guarderò."


translate italian ep4p2s1_958ea060:


    dpense "È affascinante, seducente, ma pericolosa. Il suo sorriso nasconde intenzioni che non riesco a decifrare. Vorrei capirla, ma ho paura di scottarmi."


translate italian ep4p2s1_73e47ea6:


    drew "Buona fortuna, [name], e buona notte."


translate italian ep4p2s1_a5c33cac:


    dpense "Una serata indimenticabile, a molti livelli. Grace... e Mrs. Drew. Le cose si stanno complicando sempre di più."






translate italian ep4p2s1_954ede5f:


    d "Vieni qui, non c'è bisogno che tu mi faccia piacere in questo modo."


translate italian ep4p2s1_0ae9bcd0:


    ""


translate italian ep4p2s1_c4fcc899:


    grace "Oh mio dio! Lo sento pulsare dentro di me!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
