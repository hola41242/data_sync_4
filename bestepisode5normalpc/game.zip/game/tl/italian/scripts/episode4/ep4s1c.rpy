


translate italian ep4s1c_6dad0253:


    d "Mi ha chiesto di aspettarla all'angolo..."


translate italian ep4s1c_5856afbc:


    d "Hmm... Ora dovrebbe essere lei."


translate italian ep4s1c_785af72e:


    mad "Stai scherzando? Sai almeno che ore sono?"


translate italian ep4s1c_79b7b2d0:


    d "Mi dispiace, avevo un appuntamento con Gabriella e..."


translate italian ep4s1c_33f79b07:


    mad "Non mi interessa!" with hpunch


translate italian ep4s1c_46cf0602:


    mad "A volte ho la sensazione che lo fai apposta!"


translate italian ep4s1c_fe54f4ad:


    d "No, ma..."


translate italian ep4s1c_29bea964:


    mad "Siete pronti? Andiamo?" with hpunch


translate italian ep4s1c_f4ce41d5:


    d "Sì, andiamo."


translate italian ep4s1c_16848415:


    dpense "Sembra nervosa... beh, più del solito..."


translate italian ep4s1c_4a19f7fa:


    d "Tutto bene? Sembri un po'... teso."


translate italian ep4s1c_93632179:


    mad "I miei genitori non sono facili da impressionare. Soprattutto mio padre."


translate italian ep4s1c_a5086d58:


    d "Cosa intendi per impressionare?"


translate italian ep4s1c_b14eac55:


    mad "Diciamo solo che è esigente. Troppo esigente."


translate italian ep4s1c_00663f12:


    mad "Stasera sarebbe meglio non parlare troppo, soprattutto se si tratta di argomenti delicati."


translate italian ep4s1c_a436ea69:


    mad "E qualunque cosa tu faccia, non contraddirlo. Anche se non sei d'accordo."


translate italian ep4s1c_9093d13b:


    d "Capito, resterò in silenzio."


translate italian ep4s1c_2355a152:


    mad "Grazie... lo apprezzo."


translate italian ep4s1c_230d6202:


    mad "Siamo qui."


translate italian ep4s1c_84714175:


    cassie "Mamma!"


translate italian ep4s1c_a21367c6:


    mad "Ciao tesoro."


translate italian ep4s1c_f0f27eb0:


    mad "È quasi ora di andare a letto, vero?"


translate italian ep4s1c_006d7bde:


    cassie "Sì, ma prima volevo darti un abbraccio!"


translate italian ep4s1c_7f1f0a96:


    dpense "Faccina buffa..."


translate italian ep4s1c_d5a2866d:


    cassie "È il mio signor Kitty!"


translate italian ep4s1c_a647ab43:


    d "OH?"


translate italian ep4s1c_fe4611ae:


    d "Buuu!"


translate italian ep4s1c_84714175_1:


    cassie "Mamma!"


translate italian ep4s1c_73b051f2:


    mad "Che idiota!"


translate italian ep4s1c_7ef88f63:


    d "Hmm... Pronto?"


translate italian ep4s1c_84714175_2:


    cassie "Mamma!"


translate italian ep4s1c_22cc38e4:


    mad "Non aver paura Cassie! Non morde!"


translate italian ep4s1c_c622716f:


    mad "Lei è timida..."


translate italian ep4s1c_ed02c613:


    ted "Finalmente si è fatto vedere, eh?"


translate italian ep4s1c_da8cfc7c:


    mad "E tu? Ancora qui a non fare niente come al solito."


translate italian ep4s1c_fdef9d73:


    ted "A differenza di altre persone, io sono qui per aiutare."


translate italian ep4s1c_cfea4d5b:


    charles "Ha ragione, Madison. Tuo fratello si sta sacrificando per prendersi cura di tua figlia mentre tu sei via con le tue lezioni e il football."


translate italian ep4s1c_48143dc6:


    mad "Sto lavorando sodo per avere successo, papà."


translate italian ep4s1c_fdea709a:


    charles "Riuscire? Lo chiami successo? Guarda dove sei."


translate italian ep4s1c_a0d653f4:


    charles "Guardate le gemelle Da Fonseca, Elizabeth e Sofia, e persino Emerick! Sono sempre più avanti di voi."


translate italian ep4s1c_e23b0113:


    mad "Faccio del mio meglio, papà."


translate italian ep4s1c_65b21c17:


    charles "Il tuo meglio non è abbastanza buono. Sei un Forrester!"


translate italian ep4s1c_fb11c0f9:


    charles "La nostra famiglia dovrebbe essere la più potente in questa città, e tu non ci sei nemmeno lontanamente vicino."


translate italian ep4s1c_43b093b0:


    charles "Nel frattempo, tuo fratello è qui, e si sacrifica per te affinché tu possa inseguire risultati che non sono nemmeno degni del nostro nome."


translate italian ep4s1c_14e60a85:


    mad "Non sta sacrificando niente! Sta solo restando a casa perché sa che gli darai il tuo impero!"


translate italian ep4s1c_b4652781:


    mad "Cosa ha fatto?! Non ha fatto domanda per l'università o per un lavoro, niente!"


translate italian ep4s1c_70ed9669:


    charles "Madison, guardati. Sei una delusione rispetto a quello che mi aspetto da te."


translate italian ep4s1c_1f24c8da:


    charles "E tuo fratello tiene unita questa famiglia, non apprezzato. Non sei nemmeno vicino a dove dovresti essere."


translate italian ep4s1c_01762278:


    mad "Credi che non lo senta? Il peso di essere un Forrester, le aspettative, il giudizio costante?"


translate italian ep4s1c_2e303027:


    mad "Non mi capirai mai. Faccio tutto quello che posso, e non è mai abbastanza per te."


translate italian ep4s1c_5af23123:


    mad "Vado a cambiarmi e a mettere Cassie a letto... [name], tu puoi restare qui finché non torno."


translate italian ep4s1c_276d651a:


    d "Davvero? Va bene..."


translate italian ep4s1c_3f32141d:


    dpense "Wow, la tensione qui è irreale."


translate italian ep4s1c_401cb507:


    dpense "Con un padre così e un fratello che crea sempre problemi, non c'è da stupirsi che Madison sia sempre nervosa."


translate italian ep4s1c_b51a0db4:


    dpense "Come posso aiutarla in una situazione come questa?"


translate italian ep4s1c_fa0b69c6:


    ji "Piacere di conoscerti... [name]?"


translate italian ep4s1c_a647ab43_1:


    d "OH?"


translate italian ep4s1c_f4cad055:


    d "Sì, sono io. È un piacere conoscerti..."


translate italian ep4s1c_cb378405:


    d "Tu devi essere la... sorella di Madison?"


translate italian ep4s1c_d63a0bdf:


    ji "Oh oh oh! Che fascino! Purtroppo no..."


translate italian ep4s1c_af8697e3:


    carmen "Io sono sua madre... Ma puoi chiamarmi Carmen."


translate italian ep4s1c_c36276f3:


    carmen "Ha anche delle buone maniere... intrigante."


translate italian ep4s1c_0f7ade2f:


    carmen "La cena sarà pronta tra pochi minuti."


translate italian ep4s1c_df8b1672:


    charles "Allora, dimmi, [name]. Da dove vieni esattamente? Da quale famiglia provieni?"


translate italian ep4s1c_dde4c475:


    dpense "Perché ho la sensazione che questa domanda finirà male..."


translate italian ep4s1c_566bdb5d:


    d "Uh... Vengo da una famiglia normale. Niente... di notevole."


translate italian ep4s1c_bdd50929:


    charles "Normale, eh?"


translate italian ep4s1c_f465d5bd:


    charles "E cosa fai? Hai delle competenze, dei grandi progetti?"


translate italian ep4s1c_c9cbe71f:


    d "Sto ancora cercando di capire le cose... Non ho ancora piani concreti."


translate italian ep4s1c_9117d419:


    charles "Stai ancora cercando di capire le cose, eh?"


translate italian ep4s1c_7b058e25:


    charles "Nessun passato degno di nota, nessun progetto concreto, e nonostante ciò stai con mia figlia?"


translate italian ep4s1c_e94675da:


    mad "Papà, non è il momento."


translate italian ep4s1c_fad03ada:


    d "?"


translate italian ep4s1c_9364193b:


    charles "Madison, non ti relazioni con persone senza futuro."


translate italian ep4s1c_fa7f34d3:


    charles "Siamo Forresters e non ci abbassiamo a quel livello."


translate italian ep4s1c_dfdc475a:


    mad "Questo è ridicolo. Lui è qui con me, e questo dovrebbe bastare."


translate italian ep4s1c_2418351b:


    charles "No, non lo è. Mia figlia non passerà il tempo con un nessuno."


translate italian ep4s1c_298da46a:


    dpense "Sapevo che sarebbe andata male..."


translate italian ep4s1c_d7ddfd07:


    charles "Vedete? È esattamente quello che ho detto."


translate italian ep4s1c_b51e7b23:


    charles "Frequenta persone senza ambizioni, ed è per questo che resta sempre indietro rispetto agli altri."


translate italian ep4s1c_be095a14:


    charles "Dimmi, [name], non ho ragione?"


translate italian ep4s1c_9b75d279:


    d "Forse..."


translate italian ep4s1c_ab508016:


    dpense "Mi ha detto di essere accomodante, ma detesto dirlo."


translate italian ep4s1c_e80c2f3b:


    mad "Grazie per la cena, ma non posso restare in questa atmosfera."


translate italian ep4s1c_4a253169:


    mad "Ne ho abbastanza. Ce ne andiamo."


translate italian ep4s1c_3f42795c:


    mad "Scusa mamma, ma stasera non ho intenzione di occuparmi di questo!"


translate italian ep4s1c_df44d9ad:


    carmen "Ma... il pollo l'ho già preparato!"


translate italian ep4s1c_27c40301:


    carmen "Carlo!"


translate italian ep4s1c_e0d01298:


    charles "Che cosa?"


translate italian ep4s1c_339cc60f:


    d "No, ti sbagli."


translate italian ep4s1c_ad367550:


    d "Madison lavora incredibilmente duramente. Riesce a conciliare studio, football e cura della figlia."


translate italian ep4s1c_c3273228:


    d "È una donna forte e merita molto più rispetto."


translate italian ep4s1c_64cef363:


    mad "Che cosa siete..."


translate italian ep4s1c_b0ca796d:


    d "Non vedi tutto quello che fa per avere successo, e tutti i sacrifici a cui è sottoposta."


translate italian ep4s1c_95ea10a0:


    d "Lei dà il massimo e non è giusto sminuirla in questo modo."


translate italian ep4s1c_02bb2db2:


    charles "Come osi parlarmi in quel modo in casa mia?!"


translate italian ep4s1c_bd9f2cf9:


    carmen "Tesoro, per favore, non è il momento di arrabbiarsi. Sono giovani..."


translate italian ep4s1c_80325eb3:


    charles "Basta! Non voglio sentirlo. Voi due, uscite. Ora!" with hpunch


translate italian ep4s1c_9f370207:


    mad "Sì, sì. Ce ne andiamo."


translate italian ep4s1c_3f42795c_1:


    mad "Scusa mamma, ma stasera non ho intenzione di occuparmi di questo!"


translate italian ep4s1c_df44d9ad_1:


    carmen "Ma... il pollo l'ho già preparato!"


translate italian ep4s1c_27c40301_1:


    carmen "Carlo!"


translate italian ep4s1c_e0d01298_1:


    charles "Che cosa?"


translate italian end_dinner_departure_bec8b557:


    d "Avremmo dovuto mangiare prima del pollo! No?"


translate italian end_dinner_departure_ed6750c3:


    d "O almeno un doggy-bag?"


translate italian end_dinner_departure_02ddc437:


    mad "Basta... salire in macchina"


translate italian end_dinner_departure_828c1428:


    mad "Grazie per essere venuti stasera. So che non è stato facile."


translate italian end_dinner_departure_2255152a:


    d "Va bene. Mi dispiace solo che le cose siano andate in quel modo."


translate italian end_dinner_departure_7d7004a3:


    mad "Hai fatto quello che ti ho chiesto. Era tutto quello che potevo aspettarmi."


translate italian end_dinner_departure_6691cdab:


    dpense "Perché sembra che ci sia qualcosa di irrisolto? Come se ci fosse così tanto non detto tra noi..."


translate italian end_dinner_departure_c6150c87:


    d "Stai bene?"


translate italian end_dinner_departure_b6b5e82c:


    mad "Sto bene. Solo... Stanco."


translate italian end_dinner_departure_df35f693:


    dpense "Stanco... È davvero tutto qui?"


translate italian end_dinner_departure_37e64b70:


    dpense "..."


translate italian end_dinner_departure_565e71b6:


    d "Tua madre è giovane, no?"


translate italian end_dinner_departure_e4b71768:


    d "Voglio dire... tuo padre sembra molto più anziano di lei?"


translate italian end_dinner_departure_edbe80d3:


    mad "Sì. Si sono incontrati in un hotel dove mia madre lavorava per pagarsi la retta. Aveva diciotto anni."


translate italian end_dinner_departure_03cdb1b6:


    mad "Cominciarono a frequentarsi e lei rimase incinta."


translate italian end_dinner_departure_4801c24b:


    mad "Per evitare scandali... e poiché mia madre è bella, mio ​​padre l'ha sposata."


translate italian end_dinner_departure_58c8c435:


    mad "Ecco perché mi rimproverava di aver avuto un figlio così giovane."


translate italian end_dinner_departure_1767b585:


    mad "Non voleva che commettessi gli stessi errori che avevano commesso lui e mia madre..."


translate italian end_dinner_departure_a80c510e:


    d "Oh, capisco..."


translate italian end_dinner_departure_7e53ce03:


    mad "Siamo qui."


translate italian end_dinner_departure_1590ce56:


    d "Madison... a proposito di stasera"


translate italian end_dinner_departure_33de70ff:


    mad "Non farlo. È finita. Dimentichiamolo e basta."


translate italian end_dinner_departure_f4ed03c1:


    mad "Grazie per la comprensione. Buonanotte."


translate italian end_dinner_departure_c7ba9543:


    d "Buonanotte, Madison."


translate italian end_dinner_departure_d92c02fb:


    d "Sai che non devi trasportare tutto da sola, vero?"


translate italian end_dinner_departure_24a5a86e:


    mad "Lo so."


translate italian end_dinner_departure_80070976:


    mad "Entrate."


translate italian end_dinner_departure_e3023bd7:


    dpense "C'è qualcos'altro. Lo sento. Ma perché non mi lascia entrare?"


translate italian end_dinner_exclusion_bec8b557:


    d "Avremmo dovuto mangiare prima del pollo! No?"


translate italian end_dinner_exclusion_ed6750c3:


    d "O almeno un doggy-bag?"


translate italian end_dinner_exclusion_8d1dace7:


    mad "Non ci posso credere! Mio padre è incredibile!"


translate italian end_dinner_exclusion_9a3e72c3:


    d "Madison, mi dispiace, pensavo solo..."


translate italian end_dinner_exclusion_789f9dad:


    mad "Cosa pensavi?! Ti avevo detto di non affrontarlo! Perché non riesci mai ad ascoltarmi?"


translate italian end_dinner_exclusion_842f20c1:


    mad "Devi sempre fare le cose a modo tuo, non è vero? Perché non ascolti mai?"


translate italian end_dinner_exclusion_3114f6e9:


    mad "Perché vai sempre contro quello che dico?"


translate italian end_dinner_exclusion_cefb8915:


    mad "Perché... Perché fai sempre...?"


translate italian end_dinner_exclusion_79ddb1a3:


    mad "Tu... Con il Rosso..."


translate italian end_dinner_exclusion_b186eaf3:


    mad "Basta...salire in macchina."


translate italian end_dinner_exclusion_6691cdab:


    dpense "Perché sembra che ci sia qualcosa di irrisolto? Come se ci fosse così tanto non detto tra noi..."


translate italian end_dinner_exclusion_c6150c87:


    d "Stai bene?"


translate italian end_dinner_exclusion_b6b5e82c:


    mad "Sto bene. Solo... Stanco."


translate italian end_dinner_exclusion_df35f693:


    dpense "Stanco... È davvero tutto qui?"


translate italian end_dinner_exclusion_37e64b70:


    dpense "..."


translate italian end_dinner_exclusion_565e71b6:


    d "Tua madre è giovane, no?"


translate italian end_dinner_exclusion_e4b71768:


    d "Voglio dire... tuo padre sembra molto più anziano di lei?"


translate italian end_dinner_exclusion_edbe80d3:


    mad "Sì. Si sono incontrati in un hotel dove mia madre lavorava per pagarsi la retta. Aveva diciotto anni."


translate italian end_dinner_exclusion_03cdb1b6:


    mad "Cominciarono a frequentarsi e lei rimase incinta."


translate italian end_dinner_exclusion_4801c24b:


    mad "Per evitare scandali... e poiché mia madre è bella, mio ​​padre l'ha sposata."


translate italian end_dinner_exclusion_58c8c435:


    mad "Ecco perché mi rimproverava di aver avuto un figlio così giovane."


translate italian end_dinner_exclusion_1767b585:


    mad "Non voleva che commettessi gli stessi errori che avevano commesso lui e mia madre..."


translate italian end_dinner_exclusion_a80c510e:


    d "Oh, capisco..."


translate italian end_dinner_exclusion_7e53ce03:


    mad "Siamo qui."


translate italian end_dinner_exclusion_e1fe360c:


    d "Madison... a proposito di stasera..."


translate italian end_dinner_exclusion_33de70ff:


    mad "Non farlo. È finita. Dimentichiamolo e basta."


translate italian end_dinner_exclusion_f4ed03c1:


    mad "Grazie per la comprensione. Buonanotte."


translate italian end_dinner_exclusion_c7ba9543:


    d "Buonanotte, Madison."


translate italian end_dinner_exclusion_d92c02fb:


    d "Sai che non devi trasportare tutto da sola, vero?"


translate italian end_dinner_exclusion_24a5a86e:


    mad "Lo so."


translate italian end_dinner_exclusion_80070976:


    mad "Entrate."


translate italian madicarep4_d8f6e37a:


    mad "Perché sei..."


translate italian madicarep4_69f7a537:


    mad "Perché rendi tutto così complicato?"


translate italian madicarep4_cecb0a3c:


    mad "Andiamo."


translate italian madicarep4_f3931eec:


    d "Ehm... Dove?"


translate italian madicarep4_e1fca818:


    mad "Vedrai."


translate italian madicarep4_b606edb1:


    d "Dove stiamo andando?"


translate italian madicarep4_15b9b540:


    dpense "Cosa sta facendo?"


translate italian madicarep4_53a281cf:


    dpense "Non siamo... da nessuna parte..."


translate italian madicarep4_328d9c7f:


    d "E allora? Dove sono..."


translate italian madicarep4_8777e1e5:


    mad "Per una volta nella vita, stai zitto e fai quello che ti viene detto." with hpunch


translate italian madicarep4_21ae9489:


    dpense "È vero?"


translate italian madicarep4_973d116c:


    dpense "In questo momento non riesco nemmeno a pensare lucidamente..."


translate italian madicarep4_9c7e17ef:


    dpense "Ha bisogno di affetto."


translate italian madicarep4_181bd2fb:


    dpense "Ha bisogno di amore."


translate italian madicarep4_3c1a2941:


    dpense "Lei ha bisogno..."


translate italian madicarep4_722429d9:


    dpense "Me."


translate italian madicarep4_16408cd2:


    mad "Ahhhh..."


translate italian madicarep4_c2706398:


    dpense "Ti darò tutto, Madison."


translate italian madicarep4_30c998e5:


    mad "Di più...."


translate italian madicarep4_482bce7e:


    dpense "Verrai trattata come una regina, come dovresti essere."


translate italian madicarep4_570d1a88:


    mad "Più forte!"


translate italian madicarep4_e41549ac:


    mad "Ahh... Così... Proprio così..."


translate italian madicarep4_9c9ea9b2:


    mad "Ahhh... Ahhh... Ahhh"


translate italian madicarep4_9009007c:


    mad "FUUCCCCCCCCCCCCCCCKKKKK"


translate italian madicarep4_1e64df45:


    mad "Aspetta... Lasciami girare..."


translate italian madicarep4_8fa495fa:


    d "Sei così meravigliosa."


translate italian madicarep4_0ae9bcd0:


    ""


translate italian madicarep4_b17db2f4:


    dpense "Se l'amore fosse un tempio..."


translate italian madicarep4_9b7ac599:


    dpense "Saresti la mia religione!"


translate italian madicarep4_2acc949b:


    d "Hai...?"


translate italian madicarep4_2b13f232:


    mad "Si e tu?"


translate italian madicarep4_06f80c70:


    d "Mmm... no, ma ci sono vicino."


translate italian madicarep4_3192ed71:


    mad "Ok... lascia che lo faccia io."


translate italian madicarep4_48ad44f5:


    mad "..."


translate italian madicarep4_362c6bb7:


    d "...Madison..."


translate italian madicarep4_c5fd0efd:


    mad "IO..."


translate italian madicarep4_10d22e60:


    mad "HMMMMMMMM."


translate italian madicarep4_c96dfce7:


    d "Madison, io..."


translate italian madicarep4_8ed3e38a:


    mad "Fallo! Fallo!"


translate italian madicarep4_719c3868:


    mad "AHAHAHAHA!"


translate italian madicarep4_60aa49f8:


    d "Madi... io... AAAAHHH!"


translate italian madicarep4_dd056acf:


    mad "Voglio sentire..."


translate italian madicarep4_b1d8ec0d:


    mad "TUOOOOOO!"


translate italian madicarep4_c5fd0efd_1:


    mad "IO..."


translate italian madicarep4_e48aa4b0:


    mad "Sei incredibile!"


translate italian madicarep4_e3b20b7b:


    d "Perché?"


translate italian madicarep4_f0151273:


    mad "Ogni volta che provo a frapporti delle barriere..."


translate italian madicarep4_81742674:


    mad "E tu..."


translate italian madicarep4_d50aab69:


    mad "Grazie."


translate italian madicarep4_3d140dca:


    d "Prego."


translate italian carmadi_9073db10:


    dpense "E di nuovo tace..."


translate italian carmadi_b7c92e7a:


    d "Madison, parlami. Non puoi continuare a fare così. Cosa sta succedendo davvero?"


translate italian carmadi_7968a21e:


    mad "Sono un Forrester. Tu e io... Non possiamo farlo. Non dovremmo."


translate italian carmadi_490f3c49:


    d "Cosa significa? Continui a respingermi, ma perché?"


translate italian carmadi_e4c53d96:


    mad "Ho delle responsabilità, un nome da mantenere. Tu... Tu non ci rientri. Non ci riuscirai mai."


translate italian carmadi_16ef6dd4:


    d "Madison, non è giusto."


translate italian carmadi_2e133450:


    mad "La vita non è giusta. Soprattutto per persone come me."


translate italian carmadi_d6eb2433:


    mad "Non possiamo continuare così."


translate italian carmadi_b93e5c76:


    mad "Tutto questo deve finire."


translate italian carmadi_d5cb0d6f:


    dpense "Forrester... È davvero questo che ci tiene separati? O ha solo paura?"


translate italian carmadi_30c3b5c1:


    dpense "Devo cambiare argomento per lasciarla calmare."


translate italian carmadi_565e71b6:


    d "Tua madre è giovane, no?"


translate italian carmadi_e4b71768:


    d "Voglio dire... tuo padre sembra molto più anziano di lei?"


translate italian carmadi_7ac5d7ec:


    mad "Sì. Si sono conosciuti in un hotel mentre la mamma studiava, aveva 18 anni."


translate italian carmadi_0afeaecb:


    mad "Inizia una relazione e lei rimane incinta."


translate italian carmadi_a1079f88:


    mad "Per evitare scandali... E poiché la mamma è bella, la sposò."


translate italian carmadi_1e47bb42:


    mad "Ecco perché mi rimprovera di avere un figlio prematuro."


translate italian carmadi_eae292b4:


    mad "Voleva che non commettessi gli stessi errori che avevano fatto lui e lei..."


translate italian carmadi_ba9103a5:


    d "Oh... capisco..."


translate italian carmadi_2083bc62:


    mad "Siamo qui. Uscite."


translate italian carmadi_5726cc40:


    d "Madison, sai che sono qui per te."


translate italian carmadi_fd221f30:


    d "Non sei solo."


translate italian carmadi_24a5a86e:


    mad "Lo so."


translate italian carmadi_ce96d8e7:


    dpense "E se n'è andata."


translate italian carmadi_42642c81:


    dpense "Di cosa ha così tanta paura?"


translate italian carmadi_1e49c06a:


    dpense "Non mi arrenderò."

translate italian strings:


    old "Boo!"
    new "Buuu!"


    old "Hello?"
    new "Ciao?"


    old "Agree with him[TEMP1!t]"
    new "Sono d'accordo con lui[TEMP1!t]"


    old "Stand up to the father[TEMP2!t]"
    new "Resisti al padre[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
