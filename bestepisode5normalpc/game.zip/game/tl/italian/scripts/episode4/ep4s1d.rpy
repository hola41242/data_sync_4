


translate italian ep4s1d_3151755a:


    "Io sono Malenia, lama di Miquella..."


translate italian ep4s1d_3151755a_1:


    "Io sono Malenia, lama di Miquella..."


translate italian ep4s1d_3dd2e30c:


    d "Sì, sì, sì..."


translate italian ep4s1d_3151755a_2:


    "Io sono Malenia, lama di Miquella..."


translate italian ep4s1d_43f42653:


    "Sono..."


translate italian ep4s1d_7e31e439:


    d "Vaffanculo!"


translate italian ep4s1d_88827fe4:


    dpense "Ho bisogno di qualcosa che mi calmi..."


translate italian ep4s1d_06a6996e:


    dpense "Dovrei andare a vedere cosa sta facendo Ruby."


translate italian ep4s1d_cefad54e:


    ruby "No! No! No!"


translate italian ep4s1d_e8cfd3f7:


    ruby "Argh!!!"


translate italian ep4s1d_ca2c7e19:


    ruby "Quindi sei il tipo che prende il microfono e cerca di farmi la predica."


translate italian ep4s1d_1c93a4f7:


    ruby "Sei la persona più inutile che abbiamo nel nostro team!"


translate italian ep4s1d_3ffb0504:


    ruby "Non ho mai visto nessuno infuriarsi così tanto come te!"


translate italian ep4s1d_96c7a6f6:


    ruby "Forse dovresti tornare a giocare a Team Fortress 2!"


translate italian ep4s1d_0df3fca5:


    ruby "Raaaaaaah"


translate italian ep4s1d_8e2bcb51:


    ruby "E se Mercy ti piace così tanto, perché non la sposi e basta?"


translate italian ep4s1d_36ead268:


    dpense "Okay... Non è il momento giusto..."


translate italian ep4s1d_8ad52066:


    dpense "La lascerò stare."

translate italian strings:


    old "After some training and some homework..."
    new "Dopo un po' di allenamento e un po' di compiti..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
