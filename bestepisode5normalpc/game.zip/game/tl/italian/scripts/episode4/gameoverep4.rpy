


translate italian gameoverep4_a733e2ee:


    orushi "Sfortunatamente non sei riuscito a superare tutte le prove, [name]..."


translate italian gameoverep4_84c6535c:


    orushi "È deludente..."


translate italian gameoverep4_3bdd13e5:


    orushi "Bene, la prossima volta... prova a fare scelte migliori!"


translate italian gameoverep4_783ab545:


    "Fshhhhhhhhhh!!!!"


translate italian gameoverep4_e233951b:


    "Lo stesso giocatore tira di nuovo!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
