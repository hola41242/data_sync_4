


translate italian masterepreuveep4_c28a81b6:


    "Hai completato con successo la sfida!"


translate italian masterepreuveep4_90ac4d81:


    "Attendi la visualizzazione del risultato."


translate italian masterepreuveep4_5f25cb0b:


    "Se sei arrivato primo, la tua classifica BEST verrà aggiornata di conseguenza."


translate italian masterepreuveep4_7ec3c5c3:


    "La tua squadra si è classificata al secondo posto e la tua classifica BEST verrà aggiornata di conseguenza."


translate italian masterepreuveep4_53bc6a15:


    "La tua squadra si è classificata al 5° posto, la tua classifica BEST verrà aggiornata di conseguenza."


translate italian masterepreuveep4_56b59a55:


    "La tua squadra si è classificata al 14° posto, la tua classifica BEST verrà aggiornata di conseguenza."


translate italian emericktrialep4_b2f31e5e:


    "Annuncio a tutti i partecipanti:"


translate italian emericktrialep4_e6973948:


    "Il primo duo a vincere la sfida è:"


translate italian emericktrialep4_ea83f46d:


    "La squadra di Emerick."


translate italian emericktrialep4_c23b34ab:


    dpense "Dannazione... Di nuovo lui..."


translate italian gracefintrialep4_9cdc3488:


    "Ronzio ronzio"


translate italian gracefintrialep4_97d130d1:


    grace "Ho ricevuto un messaggio da mia madre."


translate italian gracefintrialep4_3deed7ed:


    d "Veramente?"


translate italian gracefintrialep4_0bbee708:


    grace "Sì. Mi ha appena dato il codice."


translate italian gracefintrialep4_fd6aa687:


    grace "Andiamo all'auditorium."


translate italian gracefintrialep4_43b49e4c:


    d "Va bene."


translate italian gracefintrialep4_5f9ff550:


    grace "Eccoci qui!"


translate italian gracefintrialep4_5b5ee1b7:


    dpense "È un po' come barare, ma vabbè..."


translate italian gracefintrialep4_ade1dd2d:


    dpense "Immagino che la signora Drew sia disposta a fare qualsiasi cosa per garantire il successo della figlia."


translate italian rienDansCettePiece_5a2e0c5c:


    "Sembra che qui non ci sia niente."


translate italian rienDansCetObjet_0d41afa0:


    d "Non ho trovato nulla."


translate italian plusRienDansCetObjet_ba8fb8ed:


    d "Qui non c'è più niente da trovare..."


translate italian trouveUnObjet_99bd8c4e:


    d "Oh, ho trovato qualcosa!"


translate italian trouveUnObjet_5686c6b1:


    d "Il numero che ho trovato è [currentFoundObject.linkedNumber]"


translate italian trouveUnObjet_3dadca81:


    "ronzio ronzio" with hpunch


translate italian trouveUnObjet_c97b3b7f:


    julia "Oh, ho ricevuto un messaggio da Ruby."


translate italian trouveUnObjet_deda3703:


    julia "Ha trovato un numero che non abbiamo! È [str(getNotFoundObject().linkedNumber)]!"


translate italian trouveUnObjet_4762ac9d:


    julia "Non ci resta che tornare all'auditorium."


translate italian trouveUnObjet_d1fb860d:


    "Non c'è altro da trovare qui"


translate italian changerPiece_e6b6555b:


    "Non c'è niente da trovare qui"


translate italian changerPiece_d1fb860d:


    "Non c'è altro da trovare qui"


translate italian rubypown_0f0f27bd:


    ruby "Oh, è questo un enigma geniale?!"


translate italian rubypown_3691690b:


    ruby "Li adoro! Lasciatemi fare!"


translate italian rubypown_392c8349:


    dpense "In due secondi netti, riesce a smascherare la mente dietro al crimine..."








translate italian masterepreuveep4_bbe3c7e7:


    "Il tempo è scaduto! Il tuo grado B.E.S.T. verrà aggiornato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
