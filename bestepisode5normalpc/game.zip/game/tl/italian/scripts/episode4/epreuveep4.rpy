


translate italian epreuveep4_f5e6cdac:


    "Vuoi saltare la prova? (Tieni presente che dovrai raggiungere il punteggio minimo per continuare la storia.)"

translate italian strings:


    old "Skip the trial"
    new "Salta la prova"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
