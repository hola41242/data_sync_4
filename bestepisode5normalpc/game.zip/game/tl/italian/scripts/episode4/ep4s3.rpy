


translate italian ep4s3_e8bd61eb:


    d "Bene, è il momento di dare il via alla giornata!"


translate italian ep4s3_32954422:


    d "Oh, ciao! Non mi aspettavo di vederti."


translate italian ep4s3_f6313d78:


    d "Se ti trovi da queste parti... il tuo padrone non può essere lontano, vero?"


translate italian ep4s3_91988ae3:


    rufus "Prrrrrrrr!"


translate italian ep4s3_e776a54d:


    d "Sei bravo, eh?"


translate italian ep4s3_3dfcc959:


    d "Ugh, non sopporto i gatti!"


translate italian ep4s3_22182f2e:


    rufus "Ciao!"


translate italian ep4s3_b13ccae6:


    d "Sì, sì, fischia quanto vuoi."


translate italian ep4s3_886abaf6:


    d "Oh!"


translate italian ep4s3_33c6f2cd:


    beth "Seguimi."


translate italian ep4s3_2f10d688:


    d "Oh... Va bene..."


translate italian ep4s3_75deccb4:


    beth "Tra pochi minuti ci sarà una sfida."


translate italian ep4s3_4ebefc7f:


    beth "So già cosa dobbiamo fare."


translate italian ep4s3_d2069617:


    beth "E so dove si trovano gli oggetti che dobbiamo trovare."


translate italian ep4s3_2e165cba:


    beth "Dovrai scegliere il tuo partner per oggi."


translate italian ep4s3_47e8a1be:


    beth "Scegli me."


translate italian ep4s3_9ad54e19:


    d "Oh... Ehm..."


translate italian ep4s3_2ca6f83a:


    beth "So di te e di mia sorella."


translate italian ep4s3_2f10d688_1:


    d "Oh... Va bene..."


translate italian ep4s3_633d7fff:


    beth "Meglio di no..."


translate italian ep4s3_a19c6b04:


    sofia "Lasciatelo stare!"


translate italian ep4s3_60e7b84a:


    beth "Sofia!"


translate italian ep4s3_f97abb54:


    beth "Oh, al diavolo. Scopritelo da soli."


translate italian ep4s3_3992efb2:


    sofia "Ieri sera ho seguito mia sorella per vedere cosa stava facendo."


translate italian ep4s3_95cd67eb:


    sofia "So dove è andata a curiosare."


translate italian ep4s3_416e814f:


    sofia "Vuoi unirti a noi per la sfida?"


translate italian ep4s3_9ad54e19_1:


    d "Oh... Ehm..."


translate italian ep4s3_e1f05114:


    d "Ciao a tutti!"


translate italian ep4s3_d52773cf:


    d "Siamo pronti per la giornata?"


translate italian ep4s3_71a7b4cc:


    ruby "Pronti? Sono *così* emozionato!"


translate italian ep4s3_fe2b3523:


    d "Hmm... Ruby..."


translate italian ep4s3_6f8e0a32:


    ruby "Sì?"


translate italian ep4s3_b8112270:


    d "Tifa? Davvero?"


translate italian ep4s3_acb088b5:


    ruby "Ehi! Lei è una combattente, e oggi mi sento una combattente!"


translate italian ep4s3_af768ada:


    ruby "Zitto!"


translate italian ep4s3_8c0c30a9:


    d "Bene... Allora è più come Yuffie."


translate italian ep4s3_b25157d3:


    ruby "Grace mi ha detto che oggi ci sarà una nuova sfida. Sarà epica!"


translate italian ep4s3_134c20f9:


    d "Davvero?"


translate italian ep4s3_318ce411:


    grace "Sì. Mia madre si è svegliata all'alba per preparare tutto."


translate italian ep4s3_d925e272:


    d "Sembra intenso."


translate italian ep4s3_9098eb6d:


    mad "E anche i miei genitori sembravano aver capito che stava succedendo qualcosa."


translate italian ep4s3_51b7f2ff:


    d "Cosa intendi dire?"


translate italian drewappelep4_e54fe14c:


    drew "Attenzione a tutti i partecipanti BEST!"


translate italian drewappelep4_dba9fc01:


    drew "Vi preghiamo di recarvi immediatamente all'auditorium!"


translate italian drewappelep4_421c99b2:


    d "Credo che sia arrivato il momento dello spettacolo..."


translate italian drewappelep4_f3bea7c5:


    drew "Cari partecipanti."


translate italian drewappelep4_96e44cc9:


    drew "Avete iniziato questo viaggio come cento. Ora, ne siete rimasti solo quaranta."


translate italian drewappelep4_3999b90e:


    drew "E oggi la posta in gioco si fa ancora più alta."


translate italian drewappelep4_2f4698d7:


    drew "È un grande piacere per me..."


translate italian drewappelep4_91cf5307:


    drew "Ed è per me un grande onore presentarvi..."


translate italian drewappelep4_40b3fe90:


    drew "Mmm..."


translate italian drewappelep4_c0f0836c:


    drew "Signor Orushi della Orushi Corp.!"


translate italian drewappelep4_182d15dd:


    orushi "Grazie, signora Drew."


translate italian drewappelep4_db9faf88:


    rufus "Miaooooo..."


translate italian drewappelep4_38aa3afe:


    orushi "E grazie a tutti per il caloroso benvenuto."


translate italian drewappelep4_2165a5cb:


    orushi "Studenti..."


translate italian drewappelep4_831e141a:


    orushi "Sono entusiasta di partecipare insieme a voi a questa straordinaria competizione."


translate italian drewappelep4_a25e37f6:


    orushi "La giornata di oggi segna una svolta importante, poiché solo la metà di voi riuscirà a superare questa sfida."


translate italian drewappelep4_acdbcee0:


    orushi "Abbiamo messo alla prova le vostre abilità atletiche nella prima sfida."


translate italian drewappelep4_1f1b4369:


    orushi "E la vostra cultura generale nel secondo."


translate italian drewappelep4_7c90e673:


    orushi "Adesso metteremo alla prova la vostra comprensione del mondo che ti circonda."


translate italian drewappelep4_0b26132b:


    orushi "La sfida di oggi è una gara di orienteering."


translate italian drewappelep4_9ea1b9d2:


    orushi "Si tratta di un evento a tempo e la vostra classifica dipenderà interamente dalla velocità con cui lo completerete."


translate italian drewappelep4_9cefd6b5:


    orushi "In breve: più velocemente finirete, più alto sarà il vostro grado."


translate italian drewappelep4_d03a3a60:


    orushi "Date tutto quello che avete e, soprattutto... siate il MIGLIORE!"


translate italian drewappelep4_c96615ed:


    orushi "Ora lascio che sia lei, signora Drew, a spiegarvi le regole."


translate italian drewappelep4_ed65a178:


    mad "Se vinco, sono la prima!"


translate italian drewappelep4_5a767a3c:


    ruby "Veramente?"


translate italian drewappelep4_8c7a55bc:


    mad "Sì, sono proprio dietro Emerick... Devo vincere"


translate italian drewappelep4_6d39de95:


    dpense "Mmm..."


translate italian drewappelep4_f8d0d0c8:


    drew "Grazie, signor Orushi."


translate italian drewappelep4_5b11c3d5:


    drew "Ecco come funziona."


translate italian drewappelep4_2a6aa502:


    drew "Tra un attimo riceverete tutti un invito sui vostri telefoni"


translate italian drewappelep4_f1d0ce9e:


    drew "Accetta l'invito e installerà la BEST app. Questa app sarà essenziale per la competizione che andrà avanti."


translate italian drewappelep4_45bf5076:


    d "Possono davvero farlo?"


translate italian drewappelep4_d3c76b14:


    ruby "Puoi rifiutare se vuoi, ma senza non puoi partecipare."


translate italian drewappelep4_43a5dd76:


    d "Immagino di non avere molta scelta."


translate italian drewappelep4_bbf0abb5:


    drew "La sfida è semplice: si tratta di una gara di orienteering."


translate italian drewappelep4_6c4fc160:


    drew "Sullo schermo vedrai una mappa con i vari luoghi che puoi visitare."


translate italian drewappelep4_b861a299:


    drew "I suggerimenti per ogni luogo saranno elencati nella sezione 'Suggerimenti'."


translate italian drewappelep4_0d24b286:


    drew "Tieni presente che ogni spostamento tra luoghi ti costerà tempo."


translate italian drewappelep4_e75a16a0:


    drew "In ogni buona posizione, dovrai trovare un oggetto con un numero sopra."


translate italian drewappelep4_479f68d0:


    drew "Il tuo obiettivo è collezionare quattro numeri."


translate italian drewappelep4_4bf7d85d:


    drew "Una volta ottenuti tutti e quattro i dati, torna all'auditorium per connetterti all'app."


translate italian drewappelep4_c1aa9c15:


    drew "Se hai raccolto i numeri corretti, si sbloccherà una nuova sezione dell'app."


translate italian drewappelep4_a8875244:


    drew "Completa questa sezione per finalizzare la tua classifica."


translate italian drewappelep4_c74feb05:


    drew "Ed ecco il colpo di scena: questa sfida è un evento a squadre."


translate italian drewappelep4_9e1cc064:


    drew "Devi scegliere un compagno con cui completare la sfida."


translate italian drewappelep4_ba1ba14b:


    drew "Scegli con saggezza."


translate italian drewappelep4_694e6df3:


    drew "Ogni persona ha i suoi punti di forza e di debolezza e la scelta del partner avrà un impatto significativo sui risultati."


translate italian drewappelep4_0a57b22e:


    drew "Questa decisione potrebbe decretare il successo o il fallimento della tua prestazione."


translate italian drewappelep4_ec5bb550:


    drew "Prenditi il ​​tuo tempo, scegli il tuo partner e avvia l'app."


translate italian drewappelep4_9bc471f1:


    drew "Buona fortuna!"


translate italian drewappelep4_88d05149:


    d "Bene allora...facciamolo!"


translate italian redtrialep4_a82fd129:


    beth "Ok, esplora e ti mostrerò dove si trovano le cose nascoste."


translate italian redtrialep4_6c20eb5c:


    d "Bene. Andiamo!"


translate italian maditrialep4_6c20eb5c:


    d "Bene. Andiamo!"


translate italian juliatrialep4_6c20eb5c:


    d "Bene. Andiamo!"


translate italian rubytrialep4_6c20eb5c:


    d "Bene. Andiamo!"


translate italian gracetrialep4_6c20eb5c:


    d "Bene. Andiamo!"


translate italian bluetrialep4_21c5256c:


    sofia "Ti mostrerò dove ho visto mia sorella ieri!"


translate italian bluetrialep4_6c20eb5c:


    d "Bene. Andiamo!"

translate italian strings:


    old "Pet the cat[TEMP1!t]"
    new "Accarezzare il gatto[TEMP1!t]"


    old "Don't"
    new "Non"





translate italian ep4s3i_e40a7f98:


    d "Manderò un messaggio a Ruby per sapere dove si trovano."


translate italian drewappelep4_d396a4fb:


    "È stato effettuato un salvataggio nello slot 9-2 per il backup."

translate italian strings:


    old "Hey, where are you?"
    new "Ehi, dove sei?"


    old "In the hall!"
    new "Nella sala!"


    old "Okay coming!"
    new "Ok, sto arrivando!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
