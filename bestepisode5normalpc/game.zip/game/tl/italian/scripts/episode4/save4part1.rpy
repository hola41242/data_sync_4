


translate italian save4part1_285f8ea7:


    "Per favore, salva la partita qui..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
