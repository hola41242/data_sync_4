


translate italian ep4s1a_20c9ad11:


    julia "Grazie per essere venuto con me oggi, [name]."


translate italian ep4s1a_8f3f1879:


    julia "Ne avevo davvero bisogno."


translate italian ep4s1a_7e35fbb9:


    d "Ehi, niente paura. Sono qui per questo."


translate italian ep4s1a_798b37f7:


    d "Te l'ho detto, sono al tuo fianco ogni volta che hai bisogno di me."


translate italian ep4s1a_1cedbfe4:


    julia "Sì, lo so. Ma grazie comunque."


translate italian ep4s1a_886abaf6:


    d "Oh!"


translate italian ep4s1a_68ada36b:


    julia "Che cosa?"


translate italian ep4s1a_e86145ea:


    d "No, no... niente..."


translate italian ep4s1a_e44d7546:


    julia "Bene, entriamo."


translate italian ep4s1a_54134776:


    d "Vuoi che ti aspetti qui fuori?"


translate italian ep4s1a_453a8aaf:


    julia "No, voglio che tu venga con me."


translate italian ep4s1a_e8f90dc9:


    julia "In realtà non c'è più..."


translate italian ep4s1a_0a6d6189:


    julia "Mamma..."


translate italian ep4s1a_76710067:


    d "Cosa le è successo esattamente?"


translate italian ep4s1a_10ac15f6:


    julia "Le è stato diagnosticato un tumore al seno quando era molto giovane."


translate italian ep4s1a_a5e75600:


    julia "Si diffuse sulla sua pelle, su tutta la spalla e..."


translate italian ep4s1a_14b2730a:


    julia "Beh, in realtà ovunque."


translate italian ep4s1a_b52d04e6:


    julia "A poco a poco, i tumori si diffusero in tutto il suo corpo... E alla fine raggiunsero il cervello."


translate italian ep4s1a_6038d7cf:


    julia "Fu allora che dovettero metterla in coma farmacologico... per fermare il dolore."


translate italian ep4s1a_4e452bbd:


    d "OH..."


translate italian ep4s1a_bef3d6e9:


    d "Dev'essere stato davvero difficile per entrambi."


translate italian ep4s1a_8987783b:


    julia "È stato difficile. Vedere mia madre perdere i capelli mentre i miei crescevano... non avevo idea di come prendermene cura. Non è stata di certo la tua infanzia normale."


translate italian ep4s1a_b629e81e:


    julia "Dopo un po', ha iniziato a perdere la testa. Avere questi deliri, come allucinazioni dovute ai trattamenti e al cancro che le aveva colpito il cervello..."


translate italian ep4s1a_8c680c87:


    julia "Non era più se stessa. Mi urlava contro, diceva cose su mia sorella... Io non ne ho nemmeno una."


translate italian ep4s1a_80f1e158:


    d "È orribile. Devi preoccuparti di prenderlo un giorno?"


translate italian ep4s1a_9e506163:


    julia "Purtroppo è una questione genetica..."


translate italian ep4s1a_a327b7fb:


    julia "Ho fatto il test e per fortuna non ho i pennarelli per farlo."


translate italian ep4s1a_47d7d147:


    julia "Ma spesso salta una generazione, quindi c'è sempre la possibilità che i miei figli possano prenderlo..."


translate italian ep4s1a_ad25a9e6:


    d "Capisco... Dev'essere davvero dura gestire tutto questo."


translate italian ep4s1a_b4a2294b:


    julia "Lo è, ma io procedo un passo alla volta."


translate italian ep4s1a_5fd62a27:


    d "Non so nemmeno cosa dire..."


translate italian ep4s1a_a1b2ccce:


    julia "Non preoccuparti, non ti sto chiedendo di prenderlo o di provare pena per me."


translate italian ep4s1a_09cc0a8a:


    julia "Il solo fatto che tu sia qui con me oggi significa molto."


translate italian ep4s1a_162d485e:


    d "Vieni a trovarla spesso?"


translate italian ep4s1a_a1fcf155:


    julia "Cerco di venire ogni due giorni."


translate italian ep4s1a_4f7968df:


    julia "Ma tra lavoro e scuola, a volte non ci riesco proprio."


translate italian ep4s1a_73baebc1:


    julia "E le cure costano molto..."


translate italian ep4s1a_dd8840b0:


    julia "Ma i dottori dicono... Non le resta molto tempo."


translate italian ep4s1a_0a6d6189_1:


    julia "Mamma..."


translate italian ep4s1a_714f2208:


    d "Allora, cosa farai nel resto del pomeriggio?"


translate italian ep4s1a_834ed170:


    julia "Bene, prima mi rilasso. La schiena mi fa ancora un po' male."


translate italian ep4s1a_56e0418c:


    julia "Poi ho delle lezioni da recuperare e il mio appartamento è un disastro..."


translate italian ep4s1a_c6c5499b:


    julia "E tu?"


translate italian ep4s1a_616de764:


    d "Incontrerò Gabriella al museo."


translate italian ep4s1a_d97405e0:


    julia "Ohhh sì, il tuo grande appuntamento con la milf di Ruby!"


translate italian ep4s1a_a776abc5:


    d "Ahah, sì... Voglio dire, non è proprio un appuntamento, ma è un'occasione per conoscerla meglio."


translate italian ep4s1a_ec12eec5:


    julia "Vedrai, è un po' misteriosa, ma è una brava persona."


translate italian ep4s1a_89114304:


    julia "Lei è la nostra allenatrice ed è super tosta."


translate italian ep4s1a_79aab06d:


    julia "Solo... non farla incazzare, lo sai?"


translate italian ep4s1a_a2edb627:


    d "Farò del mio meglio per mantenere l'atmosfera rilassata!"


translate italian ep4s1a_7b68489f:


    d "Ho cenato con Madison."


translate italian ep4s1a_95e9319e:


    julia "Madison? Oh, wow..."


translate italian ep4s1a_257943fa:


    d "Sì, vado a casa sua per cenare con la sua famiglia."


translate italian ep4s1a_02e67166:


    julia "Oh, wow... Attento, ti stai addentrando in un territorio molto vasto."


translate italian ep4s1a_2c3a63c7:


    d "Cosa intendi?"


translate italian ep4s1a_893d4e1a:


    julia "Madison è una Forrester."


translate italian ep4s1a_9bab20a6:


    julia "Sono la terza famiglia più influente della città, dopo gli Orushi."


translate italian ep4s1a_0ed8cdd3:


    julia "Quindi sì, per loro tutto ruota intorno alla perfezione."


translate italian ep4s1a_b1190186:


    julia "Vestiti bene."


translate italian ep4s1a_4ca205d9:


    d "Uh... Okay. Ho ancora il vestito che indossavo ieri. Immagino che lo indosserò."


translate italian ep4s1a_6f595adf:


    julia "Sì, se vuoi fare una buona impressione, dovresti farlo."


translate italian ep4s1a_37cb29af:


    d "Grazie per il suggerimento..."


translate italian ep4s1a_b2c92cdc:


    julia "Nessun problema!"


translate italian ep4s1a_657ccf98:


    d "Devo allenarmi per la prossima partita e dovrei anche studiare un po'..."


translate italian ep4s1a_e134941d:


    julia "Sì, non saltare la formazione o i compiti scolastici."


translate italian ep4s1a_b4f01913:


    julia "Bene, vi lascio qui. Grazie ancora per tutto."


translate italian ep4s1a_f32bf035:


    d "Oh, non dirlo!"


translate italian ep4s1a_a0beed8f:


    julia "OH?"


translate italian ep4s1a_026c94db:


    d "Mi dispiace... in Francia ci baciamo su entrambe le guance."


translate italian ep4s1a_d031609a:


    julia "No, sono io... io... uh..."


translate italian ep4s1a_ff8ab879:


    julia "Beh, sembra che mi hai rubato il primo bacio..."


translate italian ep4s1a_4e452bbd_1:


    d "OH..."


translate italian ep4s1a_50e16c23:


    julia "Oh, non fare quella faccia! Non me l'aspettavo, ecco tutto!"


translate italian ep4s1a_44cfdc8a:


    d "Vuoi riprovare? Questa volta sarai pronto!"


translate italian ep4s1a_8c3c7c10:


    julia "Hmm... Forse più tardi, chi lo sa?"


translate italian ep4s1a_669d7f1d:


    julia "Bene, ci vediamo dopo!"


translate italian ep4s1a_c5072505:


    d "Ci vediamo."


translate italian ep4s1a_5f13b557:


    dpense "Julia... C'è qualcosa di così toccante in lei."


translate italian ep4s1a_04fa9d91:


    dpense "Nonostante tutto quello che sta passando con sua madre, è così forte. Ma in momenti come questi, riesco a vedere la sua vulnerabilità."


translate italian ep4s1a_38ba8bbc:


    dpense "Quel mix di forza e fragilità... È difficile non sentirsi attratti da lei."


translate italian ep4s1a_7c6dc66b:


    dpense "E quel bacio... Beh, accidentale o meno, è stato inaspettato."


translate italian ep4s1a_c51fab7f:


    dpense "La sua risata dopo, il modo in cui se ne è liberata con facilità. Ha un modo di far sembrare naturali anche i momenti imbarazzanti."


translate italian ep4s1a_7b26a132:


    dpense "Le ho davvero rubato il primo bacio?"


translate italian ep4s1a_e9feed51:


    dpense "Mi chiedo cosa significhi questo per noi…"


translate italian ep4s1a_628b3fc9:


    dpense "Aspetta... Cosa c'è nella mia tasca?"


translate italian ep4s1a_10b0457b:


    dpense "Qualcuno l'ha inserito di nascosto senza che me ne accorgessi?"


translate italian ep4s1a_0def6966:


    dpense "1410? Cosa significa?"


translate italian ep4s1a_9d5f494f:


    dpense "E chi ha lasciato questo biglietto? Riguarda Julia?"

translate italian strings:


    old "Take care of her: 1410"
    new "Prenditi cura di lei: 1410"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
