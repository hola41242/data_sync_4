


translate italian introep4_d12fc746:


    ruby "Ciao! Ciao!"


translate italian introep4_3f6be409:


    ruby "Mentre la competizione si fa più serrata e rimangono solo 40 partecipanti, ripercorriamo l'incredibile viaggio del nostro eroe: [name]!"


translate italian introep4_b9184002:


    ruby "Finora è stata una corsa sfrenata, non è vero? Dal primo percorso a ostacoli, dove [name] e [chosen] hanno dimostrato vera grinta, al superamento della seconda sfida con un punteggio di [score] su 10!"


translate italian introep4_520d55a2:


    ruby "Davvero un lavoro impressionante, [name]! Hai fatto bene a essere uno dei quaranta concorrenti rimasti, al [Rank] posto."


translate italian introep4_b7440b24:


    ruby "Oh, e non dimentichiamo quel momento con Red nello spogliatoio... Le scintille volavano! Quei due hanno sicuramente un legame."


translate italian introep4_6507d017:


    ruby "E chi potrebbe dimenticare la scena della doccia bollente con Madison? Le cose si stanno facendo interessanti..."


translate italian introep4_2bfaee56:


    ruby "C'è Blue... Esplorare nuove profondità insieme, eh? Quei momenti sono stati indimenticabili."


translate italian introep4_51f6fdaa:


    ruby "E Grace... Che serata è stata quella. Si è conclusa con una nota così alta con lei."


translate italian introep4_636ca528:


    ruby "Ma ora la posta in gioco è più alta che mai. La prossima sfida è dietro l'angolo, e non è altro che contro la squadra di Steven!"


translate italian introep4_92f583ba:


    ruby "Non so voi, ma io sono sul bordo della sedia solo a pensarci! Questa partita sarà epica!"


translate italian introep4_03936d73:


    ruby "Ma prima di arrivarci, il nostro eroe deve prendere alcune decisioni importanti. Cosa farà dopo?"


translate italian introep4_f771828c:


    ruby "Trascorrerà del tempo di qualità con Gabriella al museo, magari trovando ispirazione tra le opere d'arte?"


translate italian introep4_9a72089e:


    ruby "Sarà al fianco di Julia in ospedale, supportandola mentre fa visita alla madre in questo momento difficile?"


translate italian introep4_38d24d7d:


    ruby "Forse si unirà a Madison per cenare con suo padre. Potrebbe essere una serata interessante, per usare un eufemismo."


translate italian introep4_6bd2a1f7:


    ruby "Forse si concentrerà sulla preparazione per la prossima sfida, affinando le sue capacità per ciò che verrà."


translate italian introep4_2ae225eb:


    ruby "Con la concorrenza che accelera e tutte queste relazioni da gestire, non posso fare a meno di chiedermi come [name] gestirà tutto. La pressione aumenta e ogni decisione conta."


translate italian introep4_582b7e53:


    ruby "Spero davvero che [name] possa essere all'altezza della situazione nella prossima sfida che Orushi ha preparato per noi. Non sarà facile, ma se c'è qualcuno che può farlo, è lui!"


translate italian introep4_fc654be2:


    ruby "Sono così emozionata di vedere come andrà a finire! L'attesa mi sta uccidendo! Ma per ora, vi lascio fare. Buona fortuna!"


translate italian introep4_c17416f5:


    "Aggiorna la versione del tuo telefono..."


translate italian introep4_33f67964:


    "Le notifiche sono state abilitate..."


translate italian introep4_616fdfab:


    "Sono state installate nuove app..."


translate italian introep4_8975978c:


    "Hai ricevuto un invito per installare OnlyStan."


translate italian introep4_9a5f6a1c:


    "Vuoi installarlo?"


translate italian introep4_05d09197:


    "Applicazione installata, controlla le tue informazioni..."


translate italian introep4_473a1d4a:


    d "Hmm, dev'essere Kira..."


translate italian introep4_873c3127:


    "Inserisci un nome utente:"


translate italian introep4_6adface7:


    d "Ok, diamo un'occhiata a questa applicazione."


translate italian introep4_2d8cef31:


    d "Non voglio avere più cose sul mio telefono."

translate italian strings:


    old "EPISODE 4"
    new "EPISODIO 4"


    old "ACCELERATION"
    new "ACCELERAZIONE"


    old "No[TEMP1!t]"
    new "Non[TEMP1!t]"


    old "Your Username?"
    new "Il tuo nome utente?"


    old "Awake?"
    new "Sveglia?"


    old "Yeah, bit of a headache but I'm fine."
    new "Sì, un po' di mal di testa, ma sto bene."


    old "'I had fun at the party, thanks for bringing me."
    new "'Mi sono divertito alla festa, grazie per avermi portato."


    old "I had fun too! It was over too soon."
    new "Mi sono divertita anch'io! È finita troppo presto."


    old "You don't regret how it ended?"
    new "Non ti penti di come è finita?"


    old "Regret? Are you insane? It was marvelous."
    new "Rimpianti? Sei pazzo? È stato meraviglioso."


    old "It was the best night of my life!"
    new "È stata la notte più bella della mia vita!"


    old "You actually make time for me, listen to what I say..."
    new "Trovi davvero il tempo per me, ascolti quello che dico..."


    old "I never felt so respected by a man..."
    new "Non mi sono mai sentita così rispettata da un uomo..."


    old "My man?"
    new "Il mio uomo?"


    old "Your man."
    new "Il tuo uomo."


    old "Have to go. See you later!"
    new "Devo andare. Ci vediamo dopo!"


    old "See ya!"
    new "Ci vediamo!"


    old "Hey! Do you still want me to come with you to the hospital?"
    new "Ehi! Vuoi ancora che venga con te all'ospedale?"


    old "If you don't mind..."
    new "Se non ti dispiace..."


    old "No, no, not at all."
    new "No, no, per niente."


    old "Great! I'm heading there soon."
    new "Ottimo! Ci andrò presto."


    old "Should we meet out front?"
    new "Ci incontriamo fuori?"


    old "Alright! See you in a bit!"
    new "Bene! Ci vediamo tra un po'!"


    old "See you soon!"
    new "A dopo!"


    old "Awake and ready to meet up with you!"
    new "Sveglio e pronto ad incontrarti!"


    old "What part of 'only in case of emergency' do you not understand?"
    new "Quale parte di 'solo in caso di emergenza' non hai capito?"


    old "Hey, it was just so you wouldn’t worry."
    new "Ehi, era solo per non farti preoccupare."


    old "I wasn't worried."
    new "Non ero preoccupata."


    old "I'm not gonna miss our date either!"
    new "Non mancherò nemmeno al nostro appuntamento!"


    old "It's not a date!"
    new "Non è un appuntamento!"


    old "Yeah, yeah!"
    new "Sì, Sì!"


    old "Just be on time."
    new "Basta essere puntuali."


    old "Yes, ma'am!"
    new "Sì, signora!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
