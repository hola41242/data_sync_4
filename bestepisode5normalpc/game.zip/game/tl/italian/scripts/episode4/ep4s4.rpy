


translate italian postepreuvep4_d95c0c5f:


    d "Sì!!!! Ce l'ho fatta! Sono il MIGLIORE!"


translate italian postepreuvep4_2b9a1516:


    ruby "Ahah! Lo sapevo! Ho fatto bene a credere in te fin dall'inizio!"


translate italian postepreuvep4_ebb64208:


    ruby "Il mio istinto non mi tradisce mai!"


translate italian postepreuvep4_914d232a:


    d "Grazie, Ruby!"


translate italian postepreuvep4_b502f042:


    grace "Congratulazioni!"


translate italian postepreuvep4_85e4ae4e:


    mad "Sì. Congratulazioni."


translate italian postepreuvep4_968df1dc:


    d "Non fare quella faccia, Madison! Avrai la tua possibilità nelle prossime sfide!"


translate italian postepreuvep4_76bb8453:


    mad "Oh, certo che lo farò."


translate italian postepreuvep4_f34661f2:


    mad "Non permetterò a nessun altro di prendermi quel posto!"


translate italian postepreuvep4_4b66f82a:


    d "Prima dovrai battermi!"


translate italian postepreuvep4_49fdce4f:


    mad "Cavolo..."


translate italian postepreuvep4_fae32503:


    julia "Non preoccuparti. È solo una perdente un po' sgradevole, ma se ne farà una ragione."


translate italian postepreuvep4_0af351f3:


    ruby "Sì, e penso che in fondo sia davvero felice!"


translate italian postepreuvep4_2c3a63c7:


    d "Cosa intendi?"


translate italian postepreuvep4_4966be78:


    ruby "Bene, hai sconfitto Emerick! E niente la rende più felice che vederlo sconfitto."


translate italian postepreuvep4_a06e5c1b:


    emerick "Dai, chi è il migliore?"


translate italian postepreuvep4_ff9aa7c2:


    mad "Accidenti! Ti metti sempre in mostra, non è vero?"


translate italian postepreuvep4_a0b9bdc0:


    ruby "Beh, per essere onesti, è piuttosto forte."


translate italian postepreuvep4_59401327:


    mad "Ruby! Dovresti essere dalla mia parte!" with hpunch


translate italian postepreuvep4_ca7f4ebd:


    ruby "Lo dico e basta! Non c'è bisogno di prendermi a pugni!"


translate italian postepreuvep4_8c3a0b8e:


    mad "Ugh, come vuoi. La prossima volta lo schiaccerò!"


translate italian postepreuvep4_3c809472:


    d "Non vedo l'ora!"


translate italian postepreuvep4_3548917f:


    mad "Finalmente!" with hpunch


translate italian postepreuvep4_2307991b:


    ruby "Che cosa?"


translate italian postepreuvep4_11760e79:


    mad "Sono il numero uno!"


translate italian postepreuvep4_c2d13269:


    mad "Ahah!"


translate italian postepreuvep4_efcd65ff:


    mad "Sono così felice!"


translate italian postepreuvep4_b6d09f2c:


    d "Congratulazioni!"


translate italian postepreuvep4_88b285a4:


    mad "Grazie!"


translate italian postepreuvep4_fe9c9277:


    mad "Quel cretino dev'essere devastato per aver perso la corona!"


translate italian postepreuvep4_8a5b80e4:


    ruby "Ora non ti resta che conservarlo!"


translate italian postepreuvep4_f5b25916:


    mad "Oh, lo farò!"


translate italian postepreuvep4_2c4dd3c6:


    dpense "Mmm... Ci sarà un problema però."


translate italian postepreuvep4_8a15ed11:


    dpense "A un certo punto dovrò vincere."


translate italian postepreuvep4_11e68000:


    dpense "Quando arriverà quel giorno, Madison, saremo rivali."


translate italian finpart1ep4_c9b7daef:


    sofia "Ce l'abbiamo fatta!"


translate italian finpart1ep4_c804b774:


    d "Ahah sì!"


translate italian finpart1ep4_41790409:


    julia "Bravi tutti!"


translate italian finpart1ep4_5360cfd9:


    grace "Comunque, avete combattuto tutti duramente! Siamo ancora tutti in gara."


translate italian finpart1ep4_46f6ea63:


    grace "E ora siamo rimasti solo in 20!"


translate italian finpart1ep4_88510f87:


    ruby "La fine è vicina!"


translate italian finpart1ep4_d3f9eca3:


    julia "Questo mi ha sfinita. Vado a riposarmi un po'."


translate italian finpart1ep4_7e5c2c3c:


    ruby "Sì, anche io. E abbiamo ancora la partita di domani."


translate italian finpart1ep4_3d33b78b:


    sofia "Vuoi venire stasera?"


translate italian finpart1ep4_a821b5e8:


    d "Dove?"


translate italian finpart1ep4_a2d67328:


    sofia "A casa mia."


translate italian finpart1ep4_0d83ea1f:


    d "Ah, sì?..."


translate italian finpart1ep4_3d0cbac8:


    d "Sì, assolutamente!"


translate italian finpart1ep4_da93614d:


    sofia "Ottimo! Passa verso le 20:00."


translate italian finpart1ep4_daa9b8fd:


    sofia "Ehm... sai dove viviamo?"


translate italian finpart1ep4_1e98cad6:


    d "Nel quartiere di Madison, giusto?"


translate italian finpart1ep4_108c8239:


    sofia "Sì, proprio dietro."


translate italian finpart1ep4_61a478ae:


    d "Lo troverò."


translate italian finpart1ep4_5b1a7f4a:


    sofia "Mandami un messaggio quando sei nei paraggi e verrò a prenderti."


translate italian finpart1ep4_5a2f6599:


    d "E tua sorella?"


translate italian finpart1ep4_efb9908d:


    sofia "E lei?"


translate italian finpart1ep4_e3d67dfa:


    d "Beh... non dirà qualcosa?"


translate italian finpart1ep4_94e6f7b8:


    sofia "Non ha niente da dire."


translate italian finpart1ep4_7911cccb:


    sofia "E sinceramente, penso che sarà felice che tu sia con me."


translate italian finpart1ep4_dcc8fdd9:


    d "Come mai?"


translate italian finpart1ep4_29c56406:


    sofia "Anche se siamo diverse, siamo pur sempre gemelle!"


translate italian finpart1ep4_d7a76cc2:


    sofia "Quindi siamo... connesse!"


translate italian finpart1ep4_294b570e:


    sofia "Ciò significa che penso che lei voglia il meglio per me."


translate italian finpart1ep4_7e8a8360:


    sofia "E con te..."


translate italian finpart1ep4_f6caeca9:


    sofia "Mi sento bene."


translate italian finpart1ep4_cfced47e:


    sofia "Sai, Elisabeth potrebbe non dirlo, ma le importa di me."


translate italian finpart1ep4_00b9550f:


    d "Davvero? Non lo dimostra molto."


translate italian finpart1ep4_a9802b78:


    sofia "Sì, non è il tipo che lo esprime apertamente, ma lo sento. Connessione gemellare, capisci?"


translate italian finpart1ep4_02a44635:


    d "Dev'essere bello avere questa cosa."


translate italian finpart1ep4_e22c7d25:


    sofia "Lo è. E in questo momento, sento che anche tu fai parte di quella connessione."


translate italian finpart1ep4_510a6c8f:


    mad "*si schiarisce la gola* Hum! Hum!" with vpunch


translate italian finpart1ep4_bd15cdba:


    dpense "OH..."


translate italian finpart1ep4_c152dad6:


    d "Bene, allora è deciso. Ci vediamo a casa tua alle 20:00!"


translate italian finpart1ep4_34e9aab5:


    sofia "Perfetto!"


translate italian finpart1ep4_025b7b74:


    d "Mi dispiace, ma ho già degli impegni per questo pomeriggio."


translate italian finpart1ep4_e5596a13:


    d "E con la partita di domani, credo che dovrei mantenermi in ottima forma."


translate italian finpart1ep4_6dbfad43:


    sofia "Ah, va bene..."


translate italian finpart1ep4_931ca24a:


    sofia "Bene, ci vediamo dopo allora?"


translate italian finpart1ep4_4fdbb733:


    d "Sì."


translate italian finpart1ep4_76c93456:


    beth "Ben fatto, Frenchie."


translate italian finpart1ep4_f72f2645:


    d "Anche tu non eri poi così male."


translate italian finpart1ep4_dcb12307:


    d "Ma mi chiedo ancora da dove prendi tutte queste informazioni..."


translate italian finpart1ep4_9fb1fca3:


    d "Sembra che tu sappia tutto prima di chiunque altro."


translate italian finpart1ep4_05cb055d:


    beth "Oh, è semplice."


translate italian finpart1ep4_8bf45f55:


    beth "Ho delle cose compromettenti su uno dei membri dello staff di Orushi."


translate italian finpart1ep4_c1b7f1d3:


    beth "Quindi o mi dà le informazioni che ha sulle sfide che stanno preparando..."


translate italian finpart1ep4_27c53a50:


    beth "Oppure mostro a sua moglie cosa ha combinato con la madre di Emerick."


translate italian finpart1ep4_30170964:


    d "La mamma di Emerick?"


translate italian finpart1ep4_ea5c16fc:


    beth "Sì. Tende a uscire molto e a lasciarsi andare quando è in buona compagnia."


translate italian finpart1ep4_1d9c4eea:


    d "Ehm... Lui lo sa?"


translate italian finpart1ep4_eaa48dbb:


    beth "Chi? Emerick?"


translate italian finpart1ep4_4fdbb733_1:


    d "Sì."


translate italian finpart1ep4_328d8e67:


    beth "Nah. Quel tizio non riesce a vedere oltre il suo naso."


translate italian finpart1ep4_a3ecdb69:


    beth "Non ci aspettiamo che noti nulla di ciò che lo circonda."


translate italian finpart1ep4_10cc8e1f:


    d "Ma non è tuo alleato?"


translate italian finpart1ep4_0acb728c:


    beth "Emerick? Un alleato?"


translate italian finpart1ep4_619c193e:


    beth "È un cagnolino da compagnia."


translate italian finpart1ep4_b083584a:


    beth "Lo tengo vicino e gli lascio fare i suoi piccoli trucchi per tenere gli Orushi dalla mia parte."


translate italian finpart1ep4_62d2c152:


    d "Ah? E Kira?"


translate italian finpart1ep4_b1596419:


    beth "Nah... Questo è un livello completamente diverso. Evitiamo di incrociarci."


translate italian finpart1ep4_87c7b85c:


    dpense "Interessante..."


translate italian finpart1ep4_5e031470:


    beth "Comunque, ecco il mio numero così possiamo comunicare più facilmente."


translate italian finpart1ep4_a1c55f8b:


    d "Wow! La grande Elisabeth mi dà il suo numero!"


translate italian finpart1ep4_c8b3625d:


    d "Dovrei sentirmi onorato?"


translate italian finpart1ep4_e2aa9109:


    beth "Non farmene pentire, [name]."


translate italian finpart1ep4_c684e4b2:


    d "Ok, sto scherzando."


translate italian finpart1ep4_8f1a7e3e:


    beth "Mandami un messaggio stasera."


translate italian finpart1ep4_85454a22:


    d "Ehm... se vuoi."


translate italian finpart1ep4_021335d3:


    grace "Vuoi venire a trovarmi questo pomeriggio?"


translate italian finpart1ep4_e5da28cf:


    grace "Resterò a casa da sola finché non tornerà mia madre."


translate italian finpart1ep4_7a1a5887:


    d "Sì, certo!"


translate italian finpart1ep4_7a5a0376:


    grace "Ottimo! Andiamo insieme!"


translate italian finpart1ep4_aa6a11f5:


    d "Penso che domani andrò ad allenarmi un po'."


translate italian finpart1ep4_15f30b71:


    grace "Sì, capisco."


translate italian finpart1ep4_e6682e66:


    grace "Ci vediamo domani allora."


translate italian finpart1ep4_3e02fdf4:


    d "Perfetto."


translate italian finpart1ep4_c2d0abb3:


    d "Bene, ci vediamo domani, ragazze!"


translate italian finpart1ep4_5fb753fe:


    ruby "Ci vediamo domani!"


translate italian finpart1ep4_739b751a:


    julia "Ci vediamo!"

translate italian strings:


    old "Of course![TEMP1!t]"
    new "Certo![TEMP1!t]"


    old "I’ve got other things to do."
    new "Ho altre cose da fare."


    old "No, thanks."
    new "No grazie."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
