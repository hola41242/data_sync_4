


translate italian ep4s1b_2aef19a0:


    "Quel maledetto ascensore... Devono assolutamente sostituirlo." with hpunch


translate italian ep4s1b_20db93c1:


    dpense "È chiaro che qualcuno non sta avendo una buona giornata."


translate italian ep4s1b_f023dd57:


    d "Sono qui..."


translate italian ep4s1b_7e007843:


    gaby "Proprio al momento giusto!"


translate italian ep4s1b_237b830f:


    dpense "È tanto sexy quanto severa."


translate italian ep4s1b_9e1cd86e:


    dpense "La sua scollatura..."


translate italian ep4s1b_6ff3d2b0:


    gaby "È affascinante."


translate italian ep4s1b_774234f3:


    d "È..."


translate italian ep4s1b_4cb68f51:


    d "Scusa, cosa?"


translate italian ep4s1b_123981c4:


    gaby "È affascinante vedere come le civiltà antiche abbiano gettato le basi di tutto ciò che abbiamo oggi."


translate italian ep4s1b_3ad169b2:


    d "Oh! Uhm... Sì!"


translate italian ep4s1b_6e5af138:


    gaby "Anche se il tempo è passato, la loro influenza è ancora qui. Potremmo essere moderni, ma le nostre radici sono antiche, profondamente radicate nella storia."


translate italian ep4s1b_64f8e3ca:


    d "Quindi, siamo come versioni aggiornate del mondo antico? Come tavolette high-tech basate su tavole di argilla?"


translate italian ep4s1b_ed00c3fc:


    gaby "Questo è un modo per dirlo, ma... la cosa è un po' più complessa."


translate italian ep4s1b_b51c5cb8:


    dpense "Nota per me stesso: non paragonare le civiltà antiche agli iPad davanti a un professore."


translate italian ep4s1b_8c66ec4d:


    gaby "Ciò che è importante riconoscere è che vecchio non significa necessariamente sorpassato."


translate italian ep4s1b_36eb79ab:


    gaby "Infatti, ciò che è antico è spesso più stabile e più affidabile di qualcosa di nuovo."


translate italian ep4s1b_46126506:


    d "Quindi stai dicendo che le cose vecchie hanno più valore di quelle nuove?"


translate italian ep4s1b_82c0b67e:


    d "Ti piace un'auto d'epoca o una nuova fiammante?"


translate italian ep4s1b_f047d55f:


    gaby "Diciamo semplicemente che l'esperienza racchiude una saggezza che non si può ottenere da qualcosa di giovane e non ancora sperimentato."


translate italian ep4s1b_092c33aa:


    dpense "Esperienza, eh? Sì, ce l'ha. Mi chiedo se si rende conto di quanto velocemente questa conversazione potrebbe... prendere una piega diversa."


translate italian ep4s1b_1628d00c:


    d "Immagino che le cose nuove siano entusiasmanti, ma non esisterebbero senza quelle vecchie, giusto?"


translate italian ep4s1b_00a2dc22:


    d "Si potrebbe dire che si completano a vicenda... un po' come una coppia."


translate italian ep4s1b_443de289:


    gaby "Uh... stavo parlando di civiltà, ma... sì, è un paragone azzeccato."


translate italian ep4s1b_22c093f7:


    dpense "Adatto? Quello era quasi un 'A+'."


translate italian ep4s1b_1b0c331e:


    gaby "Prendiamo questa scultura, per esempio. Rappresenta le tradizioni e i valori di un'epoca passata."


translate italian ep4s1b_e5cc9718:


    gaby "Ma questi valori, nonostante si siano evoluti, sono ancora presenti nella nostra società."


translate italian ep4s1b_22c6401f:


    gaby "Li abbiamo adattati, ma le loro radici sono ancora lì. È come... Come una fondazione su cui è stata costruita la nostra società."


translate italian ep4s1b_aa28714c:


    d "Solide fondamenta. Come te. Voglio dire, non come te-te, ma... Sai cosa intendo."


translate italian ep4s1b_f05d77db:


    gaby "Sì, credo di aver capito."


translate italian ep4s1b_f8fd408a:


    dpense "Bel lavoro, [name], hai appena paragonato una donna a un fondotinta. Se la faccio franca, merito una medaglia."


translate italian ep4s1b_65731413:


    gaby "Queste civiltà capirono che era fondamentale trovare un equilibrio tra il vecchio e il nuovo."


translate italian ep4s1b_eb5c5da1:


    gaby "Non si tratta di sostituire tutto, ma di evolversi mantenendo ciò che ha valore dal passato."


translate italian ep4s1b_c28fbdee:


    d "Quindi, per evolvere, devi rispettare il vecchio mentre accogli il nuovo? Questo... Ha senso."


translate italian ep4s1b_50f19c6d:


    d "E se lo facessimo con... Tutto?"


translate italian ep4s1b_26954de7:


    gaby "Cosa intendi dire?"


translate italian ep4s1b_d47c4d06:


    d "Voglio dire, sai, relazioni, dinamiche. Non è poi così diverso, giusto?"


translate italian ep4s1b_c654f226:


    d "Rispettare l'esperienza e imparare dalle novità."


translate italian ep4s1b_e2038cd7:


    gaby "Ehm... suppongo di sì."


translate italian ep4s1b_d265d969:


    dpense "Bingo. Ci sta pensando. Dai, Gabriella, fammi un piccolo sorriso."


translate italian ep4s1b_0c7848ff:


    gaby "Ciò che voglio dire è che queste civiltà sapevano che l'armonia nasceva dalla comprensione delle proprie radici, ma anche dall'essere aperti a nuove idee."


translate italian ep4s1b_a660b588:


    d "Come noi, vero? Una vecchia civiltà e una nuova generazione... Esplorando nuove idee insieme."


translate italian ep4s1b_80d6b94e:


    gaby "Questo è... un modo per vederla, sì."


translate italian ep4s1b_6629519d:


    dpense "Penso che stia iniziando a cambiare idea."


translate italian ep4s1b_d15890e0:


    gaby "C'è molto altro da vedere al piano di sopra. La parte successiva della mostra si concentra su come la vita moderna si ricolleghi a quelle antiche fondamenta."


translate italian ep4s1b_869e1168:


    d "Sembra fantastico, ma... Ho programmato una cena stasera. Dovrei incontrare Madison."


translate italian ep4s1b_ea20ae3b:


    gaby "Oh, non sapevo che avessi dei piani."


translate italian ep4s1b_0d7758e5:


    dpense "Non lo dà a vedere, ma capisco che è un po' delusa."


translate italian ep4s1b_175c9f5c:


    d "Sì, quasi me ne dimenticavo... Avevo promesso che ci sarei stato."


translate italian ep4s1b_1467dd29:


    dpense "Non posso proprio restare. Ho fatto una promessa."


translate italian ep4s1b_d26bb7e7:


    d "Gabriella, mi dispiace tanto, ma devo andare. Non posso restare."


translate italian ep4s1b_a81dc863:


    gaby "Oh... capisco. I piani per la cena sono importanti."


translate italian ep4s1b_57b94c81:


    dpense "Sento la sua delusione, ma sta cercando di nasconderla."


translate italian ep4s1b_bcf8ece3:


    d "Mi farò perdonare, te lo prometto."


translate italian ep4s1b_bbfd92a2:


    gaby "Va bene. Vai, non farla aspettare."


translate italian ep4s1b_53eff1d8:


    dpense "Non riesco a scrollarmi di dosso la sensazione che andando via mi sto perdendo qualcosa di importante."


translate italian ep4s1b_305f0aa8:


    dpense "La cena può aspettare. Non sono ancora pronto a lasciarla."


translate italian ep4s1b_bdee29e8:


    d "Sapete cosa? La cena può aspettare."


translate italian ep4s1b_bd4db720:


    gaby "Davvero? Sono contenta."


translate italian ep4s1b_15d7de72:


    dpense "C'è qualcosa nel suo sorriso che mi rende impossibile andarmene ora."


translate italian ep4s1b_d6e11cdb:


    gaby "Bene, allora andiamo di sopra."


translate italian ep4elevator_7667e06b:


    gaby "Prenderemo l'ascensore per arrivare al secondo piano."


translate italian ep4elevator_01b3701d:


    gaby "Cosa... Cosa è successo?"


translate italian ep4elevator_c6eacd14:


    d "Penso che l'ascensore si sia fermato."


translate italian ep4elevator_3f7ab310:


    dpense "Naturalmente doveva succedere subito."


translate italian ep4elevator_77feb3f8:


    gaby "È bloccato? Cosa facciamo?"


translate italian ep4elevator_2ce331f6:


    d "Proviamo a chiamare aiuto. Usciremo da qui."


translate italian ep4elevator_7ddedd2d:


    d "Ehi? C'è qualcuno là fuori? L'ascensore è bloccato!"


translate italian ep4elevator_52150cb5:


    "Abbiamo già chiamato il tecnico... Ma non risponde. Potreste rimanere bloccati per un po'."


translate italian ep4elevator_034ac3e3:


    dpense "Fantastico... Intrappolati in un ascensore. Solo io e Gabriella. Potrebbe andare peggio... Potrebbe decisamente andare peggio."


translate italian ep4elevator_fba8c6cd:


    gaby "Per quanto tempo pensi che resteremo bloccati?"


translate italian ep4elevator_738373b2:


    "Difficile dirlo. Dovrete avere pazienza."


translate italian ep4elevator_0ab0a545:


    dpense "Non potrebbe esserci momento peggiore. Ora mi manca decisamente la cena con Madison..."


translate italian ep4elevator_f505d2df:


    d "Dovrei far sapere a Madison che arriverò in ritardo."


translate italian ep4elevator_b982659c:


    dpense "Nessun segnale... non è semplicemente perfetto?"


translate italian ep4elevator_312f63db:


    dpense "Quindi credo che ora saremo solo io e Gaby, senza distrazioni."


translate italian ep4elevator_3a4b1a0d:


    gaby "Immagino che saremo bloccati per un po'..."


translate italian ep4elevator_8c147f51:


    dpense "Solo noi due, incollati insieme. Potrebbe essere interessante."


translate italian ep4elevator_cff633d9:


    gaby "Qui dentro sta diventando caldo. Lo sento soltanto io?"


translate italian ep4elevator_3da2c0ae:


    d "No, è decisamente più caldo. Probabilmente perché non c'è ventilazione."


translate italian ep4elevator_6b2fa339:


    d "Forse dovremmo... Rilassarci un po'. Sai, così non ci surriscaldiamo."


translate italian ep4elevator_0a9639bc:


    gaby "Cosa? Io... No, non è necessario."


translate italian ep4elevator_966568ec:


    d "Guarda, siamo solo noi due. Nessuno ci vedrà."


translate italian ep4elevator_409c7c4d:


    dpense "Lei esita, ma vedo che ci sta pensando."


translate italian ep4elevator_c0b28a5d:


    dpense "Il caldo rende più difficile resistere."


translate italian ep4elevator_c66e1d4d:


    gaby "Non lo so... Non mi sembra giusto."


translate italian ep4elevator_7b8b73cd:


    dpense "Dai, Gabriella, stai già sudando. Lasciati andare."


translate italian ep4elevator_0ca38835:


    d "Fidati, ti sentirai meglio. Ci provo."


translate italian ep4elevator_f21b46f4:


    dpense "Mi toglierò la maglietta. Fa troppo caldo per preoccuparmi di altro."


translate italian ep4elevator_a2af452c:


    gaby "Immagino di sì."


translate italian ep4elevator_ce90d82c:


    dpense "Si sta davvero togliendo la giacca?! I suoi movimenti sono lenti, esitanti..."


translate italian ep4elevator_1b378c31:


    dpense "Ma lo sta facendo. E ora non riesco a smettere di guardare."


translate italian ep4elevator_53f21230:


    dpense "Il modo in cui la sua camicetta aderisce alla pelle, quel sottile strato di tessuto, tutta quella bellezza nascosta, evidente da vedere."


translate italian ep4elevator_3bfd40bf:


    dpense "Le sue curve, il suo corpo... non riesco a staccarle gli occhi di dosso."


translate italian ep4elevator_3cc651e4:


    dpense "Quella camicetta abbraccia perfettamente la sua figura. Riesco a vedere ogni linea, ogni curva..."


translate italian ep4elevator_a06eab4e:


    dpense "In questo momento non esiste nient'altro se non lei."


translate italian ep4elevator_1d229afa:


    gaby "Questo...non era così che immaginavo che sarebbe andata la giornata di oggi."


translate italian ep4elevator_45f8bbf6:


    d "Neanch'io, ma non mi lamento."


translate italian ep4elevator_c03d21c1:


    dpense "Lei è lì, a pochi metri di distanza. La distanza sembra più piccola, l'aria tra noi è densa di calore e... Qualcos'altro."


translate italian ep4elevator_0465ce21:


    dpense "Ora è così vicina. La sua pelle, il suo corpo... appena fuori dalla tua portata."


translate italian ep4elevator_d5e0f854:


    dpense "Il mio cuore sta battendo forte e, dal modo in cui mi guarda... spero che lo senta anche lei."


translate italian ep4elevator_d5f13aa0:


    gaby "Penso... che ci stiamo avvicinando un po' troppo."


translate italian ep4elevator_8d148ee1:


    dpense "Troppo vicino? Esiste davvero una cosa come troppo vicino in questo momento?"


translate italian ep4elevator_2ff5d7f3:


    d "Forse... ma a volte queste cose accadono in modo naturale, non è vero?"


translate italian ep4elevator_e29be498:


    dpense "Sembra che voglia dire qualcosa, ma non parla."


translate italian ep4elevator_de3d9a7b:


    dpense "Anche lei lo vuole? È proprio lì accanto a me. Questa tensione mi sta facendo impazzire."


translate italian ep4elevator_eceab2b3:


    gaby "Questo è... Sbagliato, ma..."


translate italian ep4elevator_c21e7875:


    dpense "Lei guarda altrove, ma è ancora così vicina. Potrebbe volerlo tanto quanto lo voglio io."


translate italian ep4elevator_910ce499:


    d "Ma sembra giusto, non è vero?"


translate italian ep4elevator_6f6aa215:


    dpense "La sua mano è proprio lì. Voglio raggiungerla, prenderla. Chiudendo quell'ultimo pezzettino di spazio tra noi."


translate italian ep4elevator_4ff38949:


    dpense "Il suo respiro è superficiale, il suo petto si alza e si abbassa più velocemente. È ancora qui. Deve volerlo anche lei."


translate italian ep4elevator_fcb96b1b:


    gaby "Non dovremmo..."


translate italian ep4elevator_2c4142c9:


    d "Forse... ma vuoi davvero fermarti?"


translate italian ep4elevator_8dff537d:


    dpense "Ancora silenziosa, ancora proprio di fronte a me."


translate italian ep4elevator_47b86c10:


    dpense "È come se fossimo congelati, in attesa dell'inevitabile."


translate italian ep4elevator_4468b7df:


    "Il riparatore è qui! Scusate per il ritardo. Due minuti e sarete liberi."


translate italian ep4elevator_1e0c076a:


    gaby "Oh! Ehm... Grazie!"


translate italian ep4elevator_6f9314a4:


    dpense "Eravamo... Eravamo quasi... Cosa è appena successo?"


translate italian ep4elevator_05c6b624:


    "Ora puoi procedere."


translate italian ep4elevator_1a23e951:


    d "Giusto... Grazie."


translate italian ep4elevator_5796a093:


    dpense "Finalmente siamo usciti dall'ascensore. Lei continua a guardare altrove, però. Siamo quasi..."


translate italian ep4elevator_b437b2be:


    dpense "Ho ripreso a ricevere il segnale sul mio telefono, bene."


translate italian ep4elevator_8cd916f1:


    d "Dovrei controllare i miei messaggi."


translate italian ep4elevator_df81e54d:


    mad "Dove sei?" with hpunch


translate italian ep4elevator_fd83eba6:


    mad "Sei in ritardo!" with hpunch


translate italian ep4elevator_cb375f76:


    mad "Mi stai davvero ignorando?" with hpunch


translate italian ep4elevator_3ac6e9bf:


    mad "Meglio avere una buona ragione per farlo!" with hpunch


translate italian ep4elevator_34af879e:


    mad "Sei incredibile." with hpunch


translate italian ep4elevator_7eea6d94:


    dpense "Ottimo. Madison è furiosa. Sarà divertente da spiegare."


translate italian ep4elevator_73791ccf:


    gaby "Tutto bene?"


translate italian ep4elevator_30eecdde:


    d "Sì... Solo alcuni messaggi di cui devo occuparmi."


translate italian ep4elevator_164e2365:


    dpense "Non riesco a smettere di pensare a cosa è quasi successo lì... e a cosa sarebbe potuto succedere se non fossimo stati interrotti."


translate italian ep4elevator_86714805:


    gaby "Bene, credo che sia qui che le nostre strade si dividono..."


translate italian ep4elevator_2bc57af2:


    dpense "Si comporta in modo disinvolto, ma non riesce a ingannarmi. So che sta pensando anche lei a quello che è successo."


translate italian ep4elevator_31316f12:


    d "Sì, credo di sì... Ci vediamo in giro?"


translate italian ep4elevator_4bad11ec:


    gaby "Sì... Ci vediamo."


translate italian ep4elevator_e1631a3d:


    dpense "Lei sorride ancora, ma sembra tesa e guardinga. Ci siamo andati così vicini laggiù... troppo vicini forse."


translate italian ep4elevator_5ffc9210:


    gaby "Stai attento, [name]."


translate italian ep4elevator_8cd50de3:


    d "Anche tu, Gabriella."


translate italian ep4elevator_8234f528:


    dpense "Chissà se la prossima volta che ci incontreremo le cose saranno diverse."


translate italian ep4elevator_07cf2c01:


    dpense "La giornata non è ancora finita, e devo ancora vedermela con Madison. Spero solo di riuscire a salvare quel che resta della serata."

translate italian strings:


    old "Go to the dinner with Madison[TEMP1!t]"
    new "Vai a cena con Madison[TEMP1!t]"


    old "Stay with Gabriella[TEMP2!t]"
    new "Resta con Gabriella"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
