


translate italian ep4s2_94fa98b5:


    dpense "BENE..."


translate italian ep4s2_69ed6f54:


    dpense "Un altro giorno da ricordare."


translate italian ep4s2_004519e6:


    dpense "Controllo velocemente il telefono prima di andare a dormire."


translate italian ep4s2_87ce1d2e:


    dpense "Bisogna stare attenti per domani."


translate italian ep4s2_4408d1f3:


    dpense "Ancora nessuna notizia da Elise."


translate italian ep4s2_c054dd5a:


    dpense "È insolito..."


translate italian ep4s2_ffc0b3a5:


    dpense "Spero che stia bene..."


translate italian roommcep4_5dda0f88:


    d "Hmm?"


translate italian bluephonep4inter_bffc964b:


    dpense "Spero che stasera stia bene..."

translate italian strings:


    old "Hey, still awake?"
    new "Ehi, ancora sveglia?"


    old "For you? Always. :)"
    new "Per te? Sempre. :)"


    old "I couldn't end the day without talking to you."
    new "Non potevo concludere la giornata senza parlare con te."


    old "You're such a sweetheart. I missed you today."
    new "Sei un tesoro. Mi sei mancato oggi."


    old "I missed you too. Feels like something was missing all day."
    new "Anche tu mi sei mancata. Sembra che mi sia mancato qualcosa per tutto il giorno."


    old "Same here. But hearing from you now makes up for it."
    new "Stessa cosa per me. Ma sentirti ora ripaga."


    old "Good. I was worried I might’ve been the only one feeling like that."
    new "Bene. Temevo di essere l'unico a provare quella sensazione."


    old "Never. You’re stuck with me now, remember?"
    new "Mai. Ora sei bloccato con me, ricordi?"


    old "Wouldn’t want it any other way."
    new "Non lo vorrei in nessun altro modo."


    old "Me neither."
    new "Neanche io."


    old "Alright, I’ll let you get some rest now. Sweet dreams, my girl."
    new "Bene, ora ti lascio riposare un po'. Sogni d'oro, ragazza mia."


    old "Sweet dreams, my guy. Sleep well. <3"
    new "Sogni d'oro, amico mio. Dormi bene. <3"


    old "Hey, Sofia. Missed me today?"
    new "Ciao, Sofia. Mi hai perso oggi?"


    old "Maybe... Or maybe I was just busy thinking about last night. ;) "
    new "Forse... O forse ero semplicemente impegnato a pensare alla scorsa notte. ;)"


    old "Oh? The part where you couldn’t keep your balance?"
    new "Oh? La parte in cui non riuscivi a mantenere l'equilibrio?"


    old "Please. You’re the one who couldn’t resist. That bathroom got... steamy fast."
    new "Per favore. Sei tu che non hai saputo resistere. Quel bagno è diventato... bollente in fretta."


    old "Can you blame me? You’re hard to resist."
    new "Puoi biasimarmi? È difficile resisterti."


    old "Good answer. Let’s just say I’ve been replaying that moment in my head all day."
    new "Bella risposta. Diciamo che ho ripercorso quel momento nella mia testa per tutto il giorno."


    old "Now I’m replaying it too. Thanks for that."
    new "Ora lo sto rigiocando anch'io. Grazie per questo."


    old "You're welcome. But let’s switch gears before this conversation gets too hot."
    new "Di niente. Ma cambiamo argomento prima che la conversazione diventi troppo accesa."


    old "I have a surprise for you!"
    new "Ho una sorpresa per te!"


    old "What? What kind of surprise?"
    new "Cosa? Che tipo di sorpresa?"


    old "WoW! It fits you so well!"
    new "Wow! Ti sta così bene!"


    old "Ahah! Thank you!"
    new "Ahah! Grazie!"


    old "My sister knows about us, you know."
    new "Mia sorella sa di noi, lo sai."


    old "Wait, Elisabeth? How?"
    new "Aspetta, Elisabeth? Come?"


    old "She has her ways. Plus, she knows there’s an event tomorrow."
    new "Ha i suoi modi. Inoltre, sa che domani c'è un evento."


    old "She’s convinced it’ll be an elimination round."
    new "È convinta che sarà un turno a eliminazione diretta."


    old "Elisabeth always has the inside scoop, doesn’t she?"
    new "Elisabeth ha sempre le informazioni riservate, non è vero?"


    old "Of course. She loves to be in control. Don’t let her intimidate you tomorrow, okay?"
    new "Certo. Le piace avere il controllo. Non lasciarti intimidire da lei domani, okay?"


    old "You worried about me?"
    new "Ti preoccupi per me?"


    old "Maybe. But I know you’ll handle it. Just don’t let her play her games with you."
    new "Forse. Ma so che lo gestirai. Solo non lasciarla giocare i suoi giochi con te."


    old "Got it. Thanks for the heads-up, Sofia."
    new "Capito. Grazie per la dritta, Sofia."


    old "Don’t thank me yet. I might need another... Private moment to stay motivated. You know, like last night."
    new "Non ringraziarmi ancora. Potrei aver bisogno di un altro... Momento privato per restare motivato. Sai, come ieri sera."


    old "Careful, or I might call your bluff."
    new "Attento, o potrei scoprire il tuo bluff."


    old "Bluff? Who said I was bluffing? Goodnight, [name]. Sweet dreams. ;) "
    new "Bluff? Chi ha detto che stavo bluffando? Buonanotte, [name]. Sogni d'oro. ;)"


    old "Goodnight, Sofia. Don’t dream too much about me."
    new "Buonanotte, Sofia. Non sognarmi troppo."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
