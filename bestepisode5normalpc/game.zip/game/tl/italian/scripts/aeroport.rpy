

translate italian aeroport_f4a872b8:


    dpense "Ahh aria fresca... Un nuovo paese, una nuova cultura, nuove persone..."


translate italian aeroport_b07237c8:


    dpense "Sono l'ultimo... Se ne sono andati tutti..."


translate italian aeroport_808acf6d:


    dpense "Benvenuto in America !"


translate italian aeroport_555b6725:


    "Tutto quello che ti ho chiesto è che tu ti prenda cura di lei mentre sono via!"


translate italian aeroport_e4ca3e2d:


    mad "Mi stai dicendo che non l'hai notata alle prese con il ciuccio???"


translate italian aeroport_b983271d:


    mad "Ascoltami, mio ​​stupido fratello! Sarò lì tra pochi minuti.. mantienila calma..."


translate italian aeroport_196a6471:


    d "TAXI!" with hpunch


translate italian aeroport_60fb3963:


    mad "Quello è mio !"


translate italian aeroport_80be1ed7:


    d "Non credo."


translate italian aeroport_ed1ba37f:


    mad "OH SÌ, è mio!"


translate italian aeroport_33058132:


    mad "Non penserai che lascerò che un pervertito come te, che ha palpato la mia compagna di squadra, prenda questo taxi prima di me!"


translate italian aeroport_f0452d08:


    d "Cosa ti ha detto?"


translate italian aeroport_25e103b1:


    mad "Non ho tempo per te. Me ne vado, puoi trovarne un altro!"


translate italian aeroport_6723e0fa:


    dpense "Non le lascerò prendere il mio taxi in quel modo!"


translate italian aeroport_dc7b7945:


    d "Vengo anch'io! Autista, portaci all'Accademia!"


translate italian aeroport_40bc89bc:


    mad "È uno scherzo ? Pensi davvero che condividerai il viaggio con me?"


translate italian aeroport_1bf3f63c:


    d "Non penso, lo so. Non ti conosco e non ho paura di te quindi smettila di fare questo atteggiamento adesso o scendi da questo taxi! Oppure condividiamo questo taxi e presto tutto finirà."


translate italian aeroport_de3c83e7:


    mad "Ohh..."


translate italian aeroport_b63493c8:


    d "E condividiamo il viaggio! Non te lo sto chiedendo!"


translate italian aeroport_fd8e2ede:


    mad "Che gentiluomo..."


translate italian aeroport_64483950:


    "E' questa l'ultima, signora Drew?"


translate italian aeroport_4352eddb:


    drew "Sì, signor Orushi. È il ragazzo francese. Come hai chiesto tu."


translate italian aeroport_7116406b:


    orushi "È perfetto, signora Drew! Come vedo, è già tra gli artigli della tigre."


translate italian aeroport_7844bdbe:


    orushi "E come stanno tutti gli altri?"


translate italian aeroport_6e3b1b13:


    drew "Tornano a casa o al campus per la notte. I loro bagagli sono stati conservati come da te richiesto."


translate italian aeroport_d5ab5b44:


    orushi "Finalmente. Abbiamo i 100 concorrenti."


translate italian aeroport_41d0c460:


    orushi "Domani si aprirà il gioco B.E.S.T!"


translate italian aeroport_5ddfbed5:


    orushi "Sei tu a capo di quel signor Rufus?"


translate italian aeroport_533d812c:


    "RrrrrrrrrrrrrrrrrRRRrrrrrr..."


translate italian aeroport_14d7b0f5:


    orushi "Che lo spettacolo abbia inizio!"


translate italian aeroport_897eabbe:


    mad "Ascolta... fai il bravo burattino e vai a chiamare un altro taxi."


translate italian aeroport_c27801fc:


    d "Ma... l'ho chiamato!"


translate italian aeroport_159a23f2:


    mad "E ?"


translate italian aeroport_b8b1a077:


    d "E..."


translate italian aeroport_f4b1a052:


    dpense "Cosa posso fare in questa situazione?"


translate italian aeroport_e19a32cd:


    d "Ascolta, ho chiamato questo taxi, ma vedo che stai attraversando un momento difficile e hai fretta, perché non condividiamo?"


translate italian aeroport_92c1c803:


    mad "Che cosa ?"


translate italian aeroport_e9d9321a:


    d "Condividi... il viaggio..."


translate italian aeroport_f351df9d:


    mad "Non condivido..."


translate italian aeroport_ed92ac6c:


    d "Pagherò anche perché la corsa la dovrei pagare comunque e non ho voglia di aspettare."


translate italian aeroport_21823f25:


    mad "Certo, immagino... grazie."


translate italian aeroport_fe0cba53:


    d "Ora prova a rilassarti e a fare un respiro profondo. Non puoi sgridare così qualcuno..."


translate italian aeroport_64483950_1:


    "E' questa l'ultima, signora Drew?"


translate italian aeroport_4352eddb_1:


    drew "Sì, signor Orushi. È il ragazzo francese. Come hai chiesto tu."


translate italian aeroport_7116406b_1:


    orushi "È perfetto, signora Drew! Come vedo, è già tra gli artigli della tigre."


translate italian aeroport_7844bdbe_1:


    orushi "E come stanno tutti gli altri?"


translate italian aeroport_6e3b1b13_1:


    drew "Tornano a casa o al campus per la notte. I loro bagagli sono stati conservati come da te richiesto."


translate italian aeroport_d5ab5b44_1:


    orushi "Finalmente. Abbiamo i 100 concorrenti."


translate italian aeroport_41d0c460_1:


    orushi "Domani si aprirà il gioco B.E.S.T!"


translate italian aeroport_bb4cf1c0:


    orushi "Ha sentito questo, signor Rufus?"


translate italian aeroport_533d812c_1:


    "RrrrrrrrrrrrrrrrrRRRrrrrrr..."


translate italian aeroport_14d7b0f5_1:


    orushi "Che lo spettacolo abbia inizio!"

translate italian strings:


    old "A NEW LIFE...."
    new "UNA NUOVA VITA...."


    old "You've found a RUFUS !"
    new "Hai trovato un RUFUS!"





translate italian strings:


    old "Rrrrrrrrrrrrrrrrr..."
    new "Rrrrrrrrrrrrrrrrr..."
















translate italian aeroport_5398bcd5:


    dpense "Ahh aria fresca. Un nuovo paese, una nuova cultura, nuove persone..."


translate italian aeroport_e9a0d30e:


    dpense "Io sono l'ultimo. Se ne sono andati tutti."


translate italian aeroport_211e98a9:


    dpense "Benvenuti in America!"


translate italian aeroport_5179d2f2:


    "TUTTO QUELLO CHE DOVEVATE FARE È STATO PRENDERVI CURA DI LEI MENTRE IO NON CI SONO!"


translate italian aeroport_709901dd:


    mad "Stai dicendo che non hai notato che ha difficoltà con il ciuccio?"


translate italian aeroport_43b0627a:


    mad "Ascoltami, fratello idiota! Sarò lì tra qualche minuto. Tienila calma."


translate italian aeroport_249cf055:


    mad "Questo è mio!"


translate italian aeroport_83e05748:


    mad "Ne ho più bisogno io di te!"


translate italian aeroport_77d696c7:


    mad "Credi che lascerò che un pervertito come te, che ha palpeggiato il mio compagno di squadra, prenda questo taxi?!"


translate italian aeroport_d34bda64:


    d "Cosa ti ha detto?"


translate italian aeroport_899e50ff:


    mad "Non ho tempo per questo. Me ne vado, puoi chiamare un altro taxi!"


translate italian aeroport_d2ce5a28:


    mad "È uno scherzo? Pensi davvero di poter condividere il viaggio con me?"


translate italian aeroport_3c3457a8:


    d "Non credo, lo so. Non ti conosco e ho chiamato questo taxi. Quindi smettila con questo atteggiamento o esci da questo taxi. Oppure, puoi semplicemente rilassarti e possiamo condividere il viaggio."


translate italian aeroport_f51580c2:


    d "Bene? Bene. Stiamo condividendo il viaggio. Affrontatelo e basta."


translate italian aeroport_fa152289:


    "È questa l'ultima, signora Drew?"


translate italian aeroport_79ea6de1:


    orushi "Perfetto, signora Drew. Vedo che è già nelle grinfie della tigre."


translate italian aeroport_331801eb:


    orushi "E gli altri come stanno?"


translate italian aeroport_adddebb1:


    orushi "Domani inizierà la partita MIGLIORE!"


translate italian aeroport_103b7468:


    orushi "Hai sentito, signor Rufus?"


translate italian aeroport_c13cf216:


    orushi "Che lo spettacolo abbia inizio!"


translate italian aeroport_4e324a7e:


    mad "Ascolta, fai il bravo ragazzo e vai a chiamare un altro taxi."


translate italian aeroport_a5b917da:


    d "Ma... l'ho chiamato!"


translate italian aeroport_984881d1:


    mad "E?"


translate italian aeroport_d6920383:


    d "E?!"


translate italian aeroport_ce157163:


    dpense "Cosa posso fare in questa situazione?"


translate italian aeroport_dc68927a:


    mad "Che cosa?"


translate italian aeroport_895c541d:


    d "Possiamo condividere il taxi..."


translate italian aeroport_997010f1:


    mad "Non condivido."


translate italian aeroport_e03560e5:


    mad "Certo, credo. Grazie."


translate italian aeroport_36596b81:


    d "Ora, prova a rilassarti e fai un respiro profondo. Non puoi semplicemente urlare a chiunque in quel modo..."


translate italian aeroport_b1d8ddd1:


    "È questa l'ultima, signora Drew?"


translate italian aeroport_f29d7abc:


    drew "Sì, signor Orushi. È il ragazzo dalla Francia. Come da lei richiesto."


translate italian aeroport_e4a116f7:


    orushi "Perfetto, signora Drew! Vedo che è già nelle grinfie della tigre."


translate italian aeroport_7711cc3b:


    orushi "E gli altri come stanno?"


translate italian aeroport_adddebb1_1:


    orushi "Domani inizierà la partita MIGLIORE!"


translate italian aeroport_29f32552:


    orushi "Hai sentito, signor Rufus?"








translate italian rufustuto_96bf5f8d:


    "Durante il gioco alcuni gatti sono nascosti nei rendering: trovali per sbloccare alcuni rendering extra nella galleria."


translate italian rufustuto_76ea4bfd:


    "Con la mod Walkthrough, puoi vedere una notifica quando un gatto è nascosto nei rendering successivi. Apri gli occhi!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
