
translate italian strings:


    old "Rufus Found : [persistent.rufusgame] / 9"
    new "Rufus trovato: [persistent.rufusgame] / 9"








translate italian strings:


    old "Rufus Found : [persistent.rufusgame] / 15"
    new "Rufus trovato: [persistent.rufusgame] / 15"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
