
translate italian strings:


    old "Replayer"
    new "Rigiocatore"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
