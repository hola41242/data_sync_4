

translate italian avion_0e0160fd:


    ji "Ciao ?"


translate italian avion_e95421cf:


    d "C...iao"


translate italian avion_59864c14:


    ji "Posso aiutarla ?"


translate italian avion_e9697244:


    d "Oh.... hum...no... scusa...!"


translate italian avion_59c8bef9:


    d "Posso sedermi qui ?"


translate italian avion_929cf346:


    ji "Sì, naturalmente! Non è stato preso; siediti e rilassati. È un volo lungo."


translate italian avion_dd2965bd:


    ji "Mi sono seduta qui anch'io per riprendere fiato e stare vicino alla finestra..."


translate italian avion_b0802ea2:


    d "Riprendere fiato?"


translate italian avion_d59574f1:


    ji "Sì, in prima classe c'è una festa con tutte le ragazze, ma è un po'... rumorosa!"


translate italian avion_da42aa4a:


    d "Hmm... va bene..."


translate italian avion_ebbadba5:


    "Le scelte contano in questo gioco e il personaggio principale ha 4 attributi in 4 rami: B.E.S.T"


translate italian avion_862ea8b3:


    "BUDDY riguarda l'atteggiamento dell'MC e avrà un impatto sulle sue interazioni con gli altri personaggi."


translate italian avion_8c05e44e:


    "L'ISTRUZIONE riguarda la conoscenza generale del MC e avrà un impatto su test e dialoghi"


translate italian avion_c2327bd8:


    "Lo SPORT riguarda il livello atletico dell'MC ed è necessario per completare determinati obiettivi durante il gioco."


translate italian avion_0daa0f65:


    "Il TEMPERAMENTO riguarda le azioni dell'MC e sarà fondamentale per lui ottenere il MIGLIOR risultato nel gioco."


translate italian avion_37fd5c70:


    "Alcune scelte porteranno ad un aggiornamento..."


translate italian avion_e248561e:


    "Inoltre, alcune scelte non saranno disponibili se non soddisfi il minimo richiesto"


translate italian matte_d3e6cc48:


    "Qui il tuo temperamento è aumentato"


translate italian matte_3b3626f9:


    "Se guardi la finestra delle statistiche vedrai che il Temperamento ha ottenuto un +1"


translate italian matte_55fa1820:


    "Se fai una scelta o un'altra, verranno influenzate statistiche diverse"


translate italian matte_91b5e938:


    "Ora torniamo alla storia..."


translate italian matte_20b35922:


    ji "Posso aiutarti in qualche modo?"


translate italian matte_ccaf5fec:


    d "OH ! eh.... no no grazie.... scusa ero perso nei miei pensieri mentre ti guardavo..."


translate italian matte_6c7fff83:


    ji "Mi stavi controllando?"


translate italian matte_875b38d8:


    d "Mi spiace, non intendevo..."


translate italian matte_886e6305:


    ji "AHAH... Non preoccuparti, non sei il primo pervertito che mi ha guardato in quel modo!"


translate italian matte_bff3ad4b:


    d "Non sono un pervertito..."


translate italian matte_7ebe0117:


    d "Ehi, ma se e questo è un grosso problema se ti stavo guardando, non che lo fossi, intendiamoci, potresti biasimarmi? Dopotutto sono solo umano"


translate italian matte_ce684cf0:


    d "Sono [name]... scusa se il mio inglese non è buono ma sono francese e andrò negli Stati Uniti per migliorarlo."


translate italian matte_cf80a00d:


    ji "Oh, è cosi ? Quindi stai dicendo che non sono abbastanza attraente perché tu possa guardarmi?"


translate italian matte_ab7b2ae1:


    julia "A proposito, mi chiamo Julia, signor Pervertito."


translate italian matte_a03052c8:


    d "Oh, quindi non stiamo ancora insieme e ho già un soprannome? Non so se questo mi piace molto però."


translate italian matte_eb29e630:


    julia "Ancora? Non siamo fiduciosi?"


translate italian matte_7667148e:


    d "Cerco ! Allora cosa deve fare una ragazza come te su un jet come questo?"


translate italian matte_cb69a6fa:


    julia "Oh, non lo sai? All'inizio questo jet era solo per noi..."


translate italian matte_919e3327:


    julia "Ma l'azienda cerca di risparmiare qualche budget..."


translate italian matte_a8f70784:


    julia "Quindi dobbiamo condividere questo aereo con alcuni studenti o famiglie con budget limitati..."


translate italian matte_f31d507b:


    julia "Per me non è un problema, ma gli altri non sono così amichevoli come me..."


translate italian matte_5d546338:


    d "Ma quanti siete?"


translate italian matte_af7767aa:


    julia "Beh, se conti Gabriella come nostra guida, noi siamo...."


translate italian matte_acc2b90e:


    "Forti rumori provenienti dalla cabina di prua..."


translate italian matte_ff6594cd:


    ji "E SAI COSA HANNO PROVATO A FARE QUESTI RAGAZZI???"


translate italian matte_7c8a480f:


    d "Loro chi sono... ???"


translate italian matte_a3b6f8a2:


    julia "Queste sono le mie ragazze... devo vedere cosa stanno facendo... ci vediamo pervertito!"


translate italian matte_ce392a47:


    d "Non sono un pervertito !"


translate italian matte_15487c24:


    julia "Mi scusi ..."


translate italian grope_4f934acb:


    dpense "Non so perché ma devo toccare...."


translate italian grope_38cf1df9:


    dpense "So che è brutto..."


translate italian grope_6cb9f1a5:


    dpense "non posso..."


translate italian grope_93427ddd:


    julia "OH SÌ, LO SEI!!!!"


translate italian grope_3783fa80:


    julia "Pervertito..."


translate italian grope_f505e264:


    dpense "Mi ha colpito! Non ci credo!"


translate italian timide_66e6c047:


    "Qui la vostra educazione è aumentata"


translate italian timide_67d96a22:


    "Se guardi la finestra delle statistiche vedrai che l'Istruzione ha ottenuto un +1"


translate italian timide_55fa1820:


    "Se fai una scelta o un'altra, verranno influenzate statistiche diverse"


translate italian timide_91b5e938:


    "Ora torniamo alla storia..."


translate italian timide_f0da4fbd:


    dpense "Sembra fiduciosa... sono un po' intimidita da lei. Ho bisogno di essere più fiducioso. Inoltre è americana, quindi... ecco quello..."


translate italian timide_b9ae6907:


    dpense "Forse... Ciao! Vengo dalla Francia ! E tu ?"


translate italian timide_1d396d27:


    dpense "No, non è un buon approccio. Ciao, mi chiamo [name]. Qual è il tuo?"


translate italian timide_ef598f94:


    dpense "Forse troppo formale. Ciao, mi chiamo Bryan. Dov'è Bryan? Bryan è in cucina."


translate italian timide_375e8c32:


    dpense "Dico semplicemente il mio nome e le chiedo il suo o le chiedo della festa in prima classe?"


translate italian timide_298d44ce:


    dpense "Sì, immagino che funzionerà o almeno sarà un buon rompighiaccio, quindi possiamo andare avanti da lì"


translate italian timide_2c3c8e7d:


    d "Quindi tu..."


translate italian timide_ff6594cd:


    ji "E SAI COSA HANNO PROVATO A FARE QUESTI RAGAZZI???"


translate italian timide_3157f6c5:


    d "Chi sono... ???"


translate italian timide_7618e110:


    julia "Queste sono le mie ragazze..."


translate italian timide_83ccf072:


    julia "Mi scusi..."


translate italian timide_bba6d66a:


    julia "Scusate, andrò a vedere cosa stanno facendo! Ciao !"


translate italian timide_320c3073:


    d "Ciao..."


translate italian timide_6689b535:


    d "Non conosco il suo nome..."


translate italian steven_cec17e94:


    dpense "Era carina..."


translate italian steven_37e64b70:


    dpense "..."


translate italian steven_6f1ae60c:


    "Sei un incasinato, amico!"


translate italian steven_172f6531:


    "Ehi amico, sei un dannato bastardo fortunato!"


translate italian suitesteven_5c0e76f8:


    d "Che cosa ?"


translate italian suitesteven_9c017fbf:


    "Eccoti qui e hai già parlato con una delle ragazze più popolari dell'università."


translate italian suitesteven_928c2998:


    d "Popolare? Come ?"


translate italian suitesteven_a44e5c43:


    "Non lo sai? Pensavo che fossi così forte... Il ragazzo che salì sull'aereo e incontrò Julia, la migliore mediana della squadra."


translate italian suitesteven_76324af9:


    d "IO ..."


translate italian suitesteven_0fc22f54:


    "Non sai niente Jon Snow..."


translate italian suitesteven_263cb021:


    d "Io non..."


translate italian suitesteven_29c04876:


    "Il Trono di Spade, amico! Dai, non lo sai?! Daenerys Targaryen, Jamie, incesto..."


translate italian suitesteven_d161cfe2:


    d "So cos'è Game of Thrones..."


translate italian suitesteven_7ddaf8de:


    "Bene, allora va bene! Io sono Ruby e tu?"


translate italian suitesteven_adba3d07:


    d "[name]..."


translate italian suitesteven_486ce07e:


    ruby "Oh, mi piace, è carino... Non come alcune persone che chiamano i loro figli Clitorine, vero?"


translate italian suitesteven_cbdaca76:


    ruby "Alcune persone, te lo dico, danno nomi strani ai loro figli ovunque, ma non i tuoi! Il tuo mi piace! Scusa, sto divagando. Allora dove stai andando?"


translate italian suitesteven_c1ff616e:


    d "Il mio primo giorno all'università è domani, quindi..."


translate italian suitesteven_aa318b6f:


    ruby "Veramente? Anche io! Ascoltare! Dovremmo incontrarci prima di entrare... hai davvero bisogno di qualcuno che ti accompagni quando arrivi lì!"


translate italian suitesteven_f1cac575:


    d "Perché ?"


translate italian suitesteven_46acb989:


    ruby "È la giungla! Andiamo, ci sono ragazze ovunque che aspettano nell'oscurità, alcune con degli artigli pronte a combattere per la vittoria e la fama!"


translate italian suitesteven_7cb8c249:


    ruby "E sai cosa fa la fama?"


translate italian suitesteven_263cb021_1:


    d "Io non..."


translate italian suitesteven_051f879a:


    ruby "Lo so... lo so! La fama significa RAGAZZE! Sarai il prescelto se avrai successo! Immagina le ragazze ai tuoi piedi! e più fama significa ???"


translate italian suitesteven_3a792386:


    d "Più ragazze?"


translate italian suitesteven_6d15a124:


    ruby "Sei intelligente, no? Sarò il tuo partner! No... sarò il tuo Cupido! Io sono Minus e tu sei Cortex, ok? Allora sei pronto a conquistare questo mondo?"


translate italian suitesteven_9c57e89e:


    ruby "Ok, non ancora Cortex... sistemerò il problema! Beh è stato davvero bello parlare con te ma ho delle commissioni da sbrigare... altre ragazze aspettano i miei consigli... a domani..."


translate italian suitesteven_b95efa92:


    d "IO..."


translate italian suitesteven_9064b9b7:


    ruby "E aspettatemi prima di entrare nell'arena!!!"


translate italian suitesteven_1523fe20:


    d "..."


translate italian suitesteven_9fd6da5c:


    dpense "Sono tutti pazzi come questa ragazza???"


translate italian suitesteven_1523fe20_1:


    d "..."


translate italian suitesteven_86c73062:


    d "Sono esausto ..."


translate italian suitesteven_dbdac134:


    "E' questa la nostra piccola Julia che torna dai Rednecks?"


translate italian suitesteven_ab6debc8:


    "Stava parlando con un ragazzo... spero che non si sia fatto qualche idea su di te..."


translate italian suitesteven_9610c720:


    julia "Sì, questo pervertito mi ha appena palpato mentre gli passavo davanti!"


translate italian suitesteven_0773b254:


    "COSAAA ???" with hpunch


translate italian suitesteven_cf866db8:


    "Forza Julia, finalmente qualcuno ne ha preso un pezzo! Puoi metterti la cintura di castità e tornare in convento..."


translate italian suitesteven_8b314319:


    julia "Ahah, molto divertente, Madison! Certo, non sono libera come te con il mio corpo... o con le scelte per la mia vita!"


translate italian suitesteven_d8a71b92:


    mad "Cosa intendi ???"


translate italian suitesteven_58956991:


    julia "Niente, lo sanno tutti che sei davvero la regina della virtù... Devi solo chiederlo al tuo ragazzo..."


translate italian suitesteven_534b4206:


    julia "Oh, non possiamo... Ti ha lasciato con un bambino di cui occuparti e scompare! Buona scelta Madison!"


translate italian suitesteven_1f27d426:


    mad "Non parlare di mio figlio! Ti ficcherò il mio pugno in gola, così capirai quanto sono grande come regina..."


translate italian suitesteven_0951d6fb:


    "Ragazze ragazze ragazze... Fermatevi adesso!"


translate italian suitesteven_686615df:


    mad "Ok, Grace... ma dì alla Santa Vergine di calmarsi i nervi o di usare un vibratore per sciogliersi prima che io ne usi uno dei miei nel suo fottuto culo!"


translate italian suitesteven_99a38228:


    mad "Sono qui fuori !!!!" with vpunch


translate italian suitesteven_7c3b1f00:


    ruby "Maddie... calmati!"


translate italian suitesteven_0207512d:


    julia "I rednecks, come dici tu, sono molto più carini che averti intorno a Madison..."


translate italian suitesteven_4a92e9bb:


    mad "Sì, certo... e sono pronti a mostrarti quanto sono carini se apri abbastanza bocca..."


translate italian suitesteven_06ebd413:


    julia "Fai schifo..."


translate italian suitesteven_0944faa3:


    mad "Andiamo Julia, non fare la brava ragazza con me e non metterti la cintura di castità!"


translate italian suitesteven_9be940f7:


    julia "Ahah, molto divertente Madison! Certo, non sono libera come te con il mio corpo... o con le scelte della mia vita!"


translate italian suitesteven_d8a71b92_1:


    mad "Cosa intendi ???"


translate italian suitesteven_b2377a6e:


    julia "Niente, lo sanno tutti che sei certamente la regina della virtù... Non mi resta che chiederlo al tuo fidanzato..."


translate italian suitesteven_6834550e:


    julia "Oh non possiamo... ti ha lasciato con un bambino di cui occuparti ed è scomparso! Buona scelta Madison!"


translate italian suitesteven_956f0d4b:


    mad "Non parlare di mio figlio! Ti ficcherò il mio pugno in gola. Allora imparerai quanto sono virtuoso..."


translate italian suitesteven_0951d6fb_1:


    "Ragazze ragazze ragazze... Fermatevi adesso!"


translate italian suitesteven_686615df_1:


    mad "Ok, Grace... ma dì alla Santa Vergine di calmarsi i nervi o di usare un vibratore per sciogliersi prima che io ne usi uno dei miei nel suo fottuto culo!"


translate italian suitesteven_99a38228_1:


    mad "Sono qui fuori !!!!" with vpunch


translate italian suitesteven_7c3b1f00_1:


    ruby "Maddie... calmati!"


translate italian filles_36dfd72e:


    grace "Andiamo ragazze, rimarremo su questo volo per 8 ore, quindi facciamo uno sforzo per andare d'accordo."


translate italian filles_5dafe21b:


    ruby "Vado a parlare con Madison, è stata nervosa tutta la mattina e non so perché."


translate italian filles_f0a26782:


    grace "Ok Ruby, vai avanti e fallo mentre parlo con Julia."


translate italian filles_6bd44eb9:


    grace "Julia... non lasciarti disturbare dai suoi giochetti mentali, sai com'è fatta!"


translate italian filles_73643294:


    julia "Sì, è così volgare ed estremamente sgradevole..."


translate italian filles_a5b7a657:


    grace "Non rispondere ai suoi commenti e andrà tutto bene... La conosco dall'asilo"


translate italian filles_481de8d6:


    grace "Sapete che ne ha passate tante... e qui siamo una squadra ragazze!"


translate italian filles_6cb619bc:


    grace "Ieri abbiamo appena vinto la partita dell'esibizione in Europa e oggi vi comportate come nemici invece di festeggiare insieme!"


translate italian filles_963cc653:


    julia "Lo so, Capitano! Ma lei ha questo potere su di me... può premere i miei pulsanti e io vado sul tetto all'istante!"


translate italian filles_97d18b70:


    julia "Se mantengo la calma, è per la squadra, per tutte voi ragazze, perché significa così tanto per me..."


translate italian filles_43472939:


    grace "Sì, mantieni questo atteggiamento e saremo a posto..."


translate italian filles_35bcedfb:


    grace "Bene, vado a bere dello champagne... Non ho comprato quelle bottiglie quando eravamo in Francia per niente... devo provarle!"


translate italian filles_fb3145c4:


    julia "Ok ci sentiamo dopo..."


translate italian dream_b8e5bfe6:


    julia "È così che mi immagini?"


translate italian dream_7b19b0bd:


    julia "Sono un po' delusa..."


translate italian dream_67c1772c:


    julia "Mi aspettavo di più da te..."


translate italian dream_ef072154:


    julia "dovrò prendere l'iniziativa..."


translate italian dream_0234bf95:


    julia "So che vuoi toccare..."


translate italian dream_16bce50e:


    julia "Presto potrai goderti tutto questo..."


translate italian dream_e7985afa:


    julia "Ma prima..."


translate italian dream_18805abb:


    julia "SVEGLIATI !!!" with hpunch


translate italian dream_ef072154_1:


    julia "dovrò prendere l'iniziativa..."


translate italian dream_0234bf95_1:


    julia "So che vuoi toccare..."


translate italian dream_16bce50e_1:


    julia "Presto potrai goderti tutto questo..."


translate italian dream_e7985afa_1:


    julia "Ma prima..."


translate italian dream_18805abb_1:


    julia "SVEGLIATI !!!" with hpunch


translate italian suiteavion_5c0e76f8:


    d "Che cosa ?"


translate italian suiteavion_54f6be08:


    ji "Svegliati !"


translate italian suiteavion_960aeedf:


    d "COSAAAAAAAAAAAAAAAAAAAAA..." with vpunch


translate italian suiteavion_926f9119:


    ruby "AHHHHHHHHHHHHHHHHHHHHHH..." with vpunch


translate italian suiteavion_35678e56:


    d "Mi hai spaventato !!!"


translate italian suiteavion_fd67742c:


    ruby "Sei pazzo ??? Sei tu che mi hai spaventata!"


translate italian suiteavion_1523fe20:


    d "..."


translate italian suiteavion_e83ddfad:


    ruby "Siamo atterrati! Ok Cortex, è ora di andare!"


translate italian suiteavion_a75ec2bd:


    ruby "Non dimenticare! Domani mattina aspettatemi all'ingresso! Conquisteremo il mondo! O forse per ora basta l'Università... ci penserò..."

translate italian strings:


    old "Look at her [TEMP1!t]"
    new "Guardala [TEMP1!t]"


    old "Stay quiet [TEMP2!t]"
    new "Stai tranquillo [TEMP2!t]"


    old "Grope her [TEMP1!t]"
    new "Tentatela [TEMP1!t]"


    old "I'm not a pervert ! [TEMP2!t]"
    new "Non sono un pervertito ! [TEMP2!t]"


    old "YOUR TEMPERAMENT HAS INCREASED"
    new "IL TUO TEMPERAMENTO È AUMENTATO"


    old "YOUR EDUCATION HAS INCREASED"
    new "LA TUA ISTRUZIONE È AUMENTATA"


    old "MEANWHILE"
    new "NEL FRATTEMPO"


    old "HOURS LATER"
    new "ORE DOPO"


    old "Yes sure ! [TEMP1!t]"
    new "Si certo ! [TEMP1!t]"


    old "I don't need you, thanks ! [TEMP2!t]"
    new "Non ho bisogno di te, grazie! [TEMP2!t]"


    old "YOUR BUDDY HAS INCREASED"
    new "IL TUO LIVELLO 'AMICO' È AUMENTATO"





translate italian avion_a77ac93c:


    ji "Ciao?"


translate italian avion_6a17aa40:


    d "Ehm, ciao."


translate italian avion_8adf166c:


    ji "Posso aiutarla?"


translate italian avion_098df146:


    d "Oh, uh, scusa! Stavo solo guardando."


translate italian avion_28d35901:


    d "Penso che questo sia il mio posto. Ti dispiace se mi siedo?"


translate italian avion_ce4cc110:


    ji "Sì, certo. Per favore, siediti e rilassati. Sarà un lungo volo."


translate italian avion_2e54462d:


    ji "Mi sono seduta qui da sola per schiarirmi le idee e stare vicino al finestrino."


translate italian avion_b1b5a06e:


    d "Vuoi schiarirti le idee?"


translate italian avion_394fe6c3:


    ji "Sì, c'è un po' di festa in prima classe con le ragazze, ma è un po' rumoroso."


translate italian avion_7c12217f:


    "In questo gioco le scelte contano e hai quattro attributi in quattro rami: B.E.S.T"


translate italian avion_6e67c913:


    "BUDDY riguarda la tua abilità sociale e avrà un impatto sulle sue interazioni con gli altri personaggi."


translate italian avion_fe1c61dc:


    "L'ISTRUZIONE riguarda la tua cultura generale e avrà un impatto sui test e sui dialoghi."


translate italian avion_71bf6ca1:


    "SPORT riguarda il tuo livello atletico ed è necessario per raggiungere determinati obiettivi durante il gioco."


translate italian avion_5aef870f:


    "Il TEMPERAMENTO riguarda il tuo atteggiamento e il tuo ego e sarà fondamentale per ottenere il MIGLIOR risultato nel gioco."


translate italian avion_fd4e33a9:


    "Alcune scelte non saranno disponibili se non si soddisfano i requisiti minimi richiesti."


translate italian matte_50d78a9e:


    "Il tuo temperamento è migliorato."


translate italian matte_c2ff206b:


    "Se guardi la finestra delle statistiche vedrai che Temperamento ha ottenuto +1"


translate italian matte_a204a91e:


    "A seconda delle scelte che farai, cresceranno diversi attributi."


translate italian matte_04c22d84:


    d "Oh! Uh, no no, va bene. Grazie. Scusa, mi sono perso nei miei pensieri mentre ti guardavo..."


translate italian matte_161819b3:


    ji "Mi stavi guardando?"


translate italian matte_33290fa1:


    ji "Ahaha... non preoccuparti. Non sei il primo a fare il pervertito con me in questo modo."


translate italian matte_109f239c:


    d "Ehi, diciamo che ti stavo guardando, e non lo stavo facendo, non sarebbe poi così male, vero? Dopotutto sono solo un essere umano"


translate italian matte_64dae949:


    d "Sono [name]. Mi dispiace se il mio inglese non è buono, ma sono francese e andrò negli Stati Uniti per migliorarlo."


translate italian matte_974197f5:


    ji "Oh, è così? Quindi stai dicendo che non sono abbastanza attraente perché tu mi guardi?"


translate italian matte_521b9be8:


    d "Oh, quindi non stiamo ancora insieme e ho già un nomignolo? Non so se questo mi piaccia."


translate italian matte_f6d9c954:


    julia "E ancora? Non ne siamo certi?"


translate italian matte_ef64d92c:


    d "Ci provo! Allora cosa ci fa una ragazza come te su un jet come questo?"


translate italian matte_e14ee53b:


    julia "Oh, non lo sai? All'inizio questo jet era solo per noi."


translate italian matte_b482344d:


    julia "Ma ora l'accademia sta cercando di risparmiare denaro dove può."


translate italian matte_1c3b9124:


    julia "A volte dobbiamo condividere questo aereo con alcuni studenti o famiglie."


translate italian matte_76905a7b:


    julia "Per me non è un problema, ma altri non sono amichevoli come me."


translate italian matte_71c63e4f:


    d "Quanti siete?"


translate italian matte_00032fb4:


    julia "Beh, se si conta Gabriella, la nostra guida, ci sono..."


translate italian matte_76aa842e:


    "Rumori forti provenienti dalla cabina di fronte"


translate italian matte_70a4593d:


    ji "E SAPETE COSA HANNO CERCATO DI FARE QUESTI RAGAZZI?!"


translate italian matte_3ddcfdcb:


    d "Chi sono?"


translate italian matte_a1cea24a:


    julia "Quelle sono le mie ragazze. Devo andare a controllare come stanno... arrivederci pervertito!"


translate italian matte_be32e64a:


    d "Non sono un pervertito!"


translate italian matte_83ccf072:


    julia "Scusami..."


translate italian grope_f3ad0544:


    dpense "In realtà non dovrei, ma è così bello..."


translate italian grope_4069971b:


    dpense "Non riesco a fermarmi..."


translate italian grope_25b49ff5:


    julia "OH, SEI VERAMENTE UN PERVERTITO!"


translate italian grope_e5740a5c:


    dpense "Mi ha colpito! Non ci posso credere!"


translate italian timide_b27c8e81:


    "La tua istruzione è aumentata."


translate italian timide_a204a91e:


    "A seconda delle scelte che farai, cresceranno diversi attributi."


translate italian timide_b6723f7d:


    dpense "Sembra sicura di sé. Mi intimidisce un po'. Ho bisogno di essere più sicura di me. Inoltre, è americana, quindi... ecco."


translate italian timide_b7e759f8:


    dpense "Forse dovrei iniziare con 'Ciao! Io sono francese! E tu?'"


translate italian timide_8212f678:


    dpense "No, non è un buon approccio. 'Ciao, mi chiamo [name]. E tu?'"


translate italian timide_961931c2:


    dpense "Forse troppo formale? 'Ciao, hai fame? Sì? Bene, ciao fame, sono [name].'"


translate italian timide_ca382aeb:


    dpense "Devo semplicemente presentarmi e chiedere informazioni sulla festa in prima classe?"


translate italian timide_806583b6:


    dpense "Sì, credo che andrà bene o almeno sarà un buon modo per rompere il ghiaccio."


translate italian timide_e7cb9db9:


    d "Allora... piacere di conoscerti..."


translate italian timide_70a4593d:


    ji "E SAPETE COSA HANNO CERCATO DI FARE QUESTI RAGAZZI?!"


translate italian timide_6ed3c163:


    d "Chi era?"


translate italian timide_adcda054:


    julia "Quelle sono le mie ragazze."


translate italian timide_0a12bd65:


    julia "Scusa, devo andare a controllare cosa stanno facendo. Ciao!"


translate italian timide_7fe1a0a3:


    d "Ciao."


translate italian timide_98834053:


    d "Non ho nemmeno capito il suo nome..."


translate italian steven_f0a46d58:


    dpense "Era carina."


translate italian steven_2b5cc8ea:


    "Sei un fottuto amico!"


translate italian steven_79c7d4f9:


    "Ehi amico, sei proprio un bastardo fortunato!"


translate italian suitesteven_29ac5843:


    d "Che cosa?"


translate italian suitesteven_c74818a4:


    "Hai appena parlato con una delle ragazze più popolari della nostra università."


translate italian suitesteven_445516a0:


    d "Popolare? Come?"


translate italian suitesteven_2e214d17:


    "Non lo sai? Pensavo che stessi facendo il tipo tranquillo. Il ragazzo che è salito sull'aereo e ha incontrato Julia, la migliore centrocampista della nostra squadra."


translate italian suitesteven_a818720e:


    "Non sai niente, Jon Snow."


translate italian suitesteven_12f41864:


    d "Io non... cosa?"


translate italian suitesteven_14baaefe:


    "Il Trono di Spade, amico! Dai, non lo sai?! Daenerys Targaryen, Jamie, incesto..."


translate italian suitesteven_e8068e8a:


    d "So cos'è Il Trono di Spade."


translate italian suitesteven_b61caa41:


    "Bene, allora va bene! Io sono Ruby, e tu?"


translate italian suitesteven_1604c1be:


    d "[name]."


translate italian suitesteven_e1f07e97:


    ruby "Oh, mi piace, è piuttosto carino. Non come alcune persone che chiamano il loro bambino Clitorine, giusto?"


translate italian suitesteven_30c66acb:


    ruby "Alcune persone, ti dico, danno ai loro figli nomi strani. Ma non il tuo! Mi piace il tuo nome! Scusa, sto divagando. Allora, dove stai andando?"


translate italian suitesteven_8d82ba13:


    d "Domani è il mio primo giorno all'università, quindi..."


translate italian suitesteven_94f6ab85:


    ruby "Davvero? Anch'io! Ascolta, dovremmo incontrarci prima che inizi. Sarà davvero utile avere qualcuno che ti guidi quando sarai lì!"


translate italian suitesteven_e3b20b7b:


    d "Perché?"


translate italian suitesteven_e93176d9:


    ruby "È una giungla lì! Dai, ci sono ragazze ovunque, pronte ad aspettare. Alcune hanno gli artigli pronti a combattere per la vittoria e la fama!"


translate italian suitesteven_b4c5be94:


    ruby "E sapete cosa fa la fama?"


translate italian suitesteven_c6f1becc:


    ruby "Sappi. Lo so, tu non sai niente. La fama significa RAGAZZE! Sarai il prescelto se avrai successo! Immagina delle ragazze che si gettano ai tuoi piedi! E cosa significherebbe più fama?"


translate italian suitesteven_07bd820b:


    d "Altre ragazze?"


translate italian suitesteven_60fa4a54:


    ruby "Sei piuttosto intelligente, eh? Sarò il tuo gregario! Aspetta, no, sarò il tuo Cupido! Saremo come Pinky...aspetta...tu sei francese. Io sono Minus e tu sei Cortex, okay? Allora sei pronto a conquistare il mondo?!"


translate italian suitesteven_1e83bfb6:


    ruby "Okay, non sei ancora pronto Cortex. Sistemeremo la cosa! Beh, è ​​stato bello incontrarti, ma ho alcune cose di cui occuparmi. Le altre ragazze aspettano i miei saggi consigli. Ci vediamo domani!"


translate italian suitesteven_b95efa92_1:


    d "IO..."


translate italian suitesteven_b53beaf3:


    ruby "E aspettatemi prima di entrare nell'arena accademica!"


translate italian suitesteven_dbdea2d2:


    dpense "Sono tutti pazzi come questa ragazza?"


translate italian suitesteven_1f5828f4:


    d "Sono esausto."


translate italian suitesteven_c0b26c1f:


    "È questa la nostra piccola Julia che torna dalla campagna?"


translate italian suitesteven_ece3d305:


    "Stava parlando con un tizio. Spero che non si sia fatto un'idea sbagliata su di te..."


translate italian suitesteven_1781b603:


    julia "Sì, questo pervertito mi ha palpeggiato mentre gli passavo davanti!"


translate italian suitesteven_d5c9de16:


    "COSAAAA??!" with hpunch


translate italian suitesteven_dad3e066:


    "Dai Julia, finalmente qualcuno ha un pezzo! Puoi indossare la cintura di castità e tornare al convento."


translate italian suitesteven_ec0ad1d8:


    julia "Haha, molto divertente, Madison! Non tutti possono essere liberi come te con il loro corpo o con le loro scelte nella vita!"


translate italian suitesteven_060f387e:


    mad "Cosa intendi?"


translate italian suitesteven_b9a169a9:


    julia "Niente. Tutti sanno che sei la regina della virtù. Devi solo chiedere al tuo ragazzo."


translate italian suitesteven_c6e5105b:


    julia "Oh, aspetta, non possiamo. Ti ha lasciata sola con un bambino ed è scomparso. Ottima scelta, Madison!"


translate italian suitesteven_018ba193:


    mad "Non parlare di mio figlio! Ti infilo il pugno in gola così saprai quanto sono generosa come regina!"


translate italian suitesteven_b468c864:


    "Ragazze, ragazze, ragazze! Basta così, subito!"


translate italian suitesteven_80adbe6d:


    mad "Okay Grace, ma di' alla Santa Vergine di calmare le sue tette o di usare un dildo per sciogliersi prima che io gliene infili uno nel fottuto culo!"


translate italian suitesteven_6e1984a1:


    mad "Me ne vado!" with vpunch


translate italian suitesteven_da1598b9:


    ruby "Maddie, calmati!"


translate italian suitesteven_903e5d8e:


    julia "La campagna, come dici tu, è molto più bella della tua zona, Madison."


translate italian suitesteven_a1560e5c:


    mad "Sì, certo. Scommetto che i redneck sono pronti a mostrarti quanto sono gentili se apri la bocca abbastanza."


translate italian suitesteven_b3c31478:


    mad "Dai Julia, non fare la brava ragazza con me. Vuoi mettere la cintura di castità?"


translate italian suitesteven_ec0ad1d8_1:


    julia "Haha, molto divertente, Madison! Non tutti possono essere liberi come te con il loro corpo o con le loro scelte nella vita!"


translate italian suitesteven_060f387e_1:


    mad "Cosa intendi?"


translate italian suitesteven_b9a169a9_1:


    julia "Niente. Tutti sanno che sei la regina della virtù. Devi solo chiedere al tuo ragazzo."


translate italian suitesteven_c6e5105b_1:


    julia "Oh, aspetta, non possiamo. Ti ha lasciata sola con un bambino ed è scomparso. Ottima scelta, Madison!"


translate italian suitesteven_018ba193_1:


    mad "Non parlare di mio figlio! Ti infilo il pugno in gola così saprai quanto sono generosa come regina!"


translate italian suitesteven_b468c864_1:


    "Ragazze, ragazze, ragazze! Basta così, subito!"


translate italian suitesteven_80adbe6d_1:


    mad "Okay Grace, ma di' alla Santa Vergine di calmare le sue tette o di usare un dildo per sciogliersi prima che io gliene infili uno nel fottuto culo!"


translate italian suitesteven_6e1984a1_1:


    mad "Me ne vado!" with vpunch


translate italian suitesteven_da1598b9_1:


    ruby "Maddie, calmati!"


translate italian filles_1d7d4d72:


    grace "Forza ragazze, dovremo prendere questo volo per otto ore, quindi cerchiamo di andare d'accordo."


translate italian filles_c1b1f90f:


    grace "Okay Ruby, tu fai questo mentre io parlo con Julia."


translate italian filles_9af21f39:


    grace "Julia, non farti prendere dai suoi giochetti mentali, sai com'è fatta!"


translate italian filles_f4d64a4a:


    julia "Sì, può essere così volgare e sgradevole."


translate italian filles_2022fcdc:


    grace "Ignora i suoi commenti e andrà tutto bene. La conosco dall'asilo, sta solo cercando di farti arrabbiare."


translate italian filles_9328fe6e:


    grace "Sai che ha passato tante cose e qui siamo tutti dalla stessa parte."


translate italian filles_da9df0ba:


    grace "Ieri abbiamo vinto la nostra partita amichevole in Europa e ora vi comportate come nemici invece di festeggiare insieme!"


translate italian filles_6f2a6535:


    julia "Lo so, Capitano, ma lei ha questo potere su di me. Può premere i miei pulsanti e io vado subito in tilt!"


translate italian filles_6b09a32f:


    julia "Resterò calma, per la squadra. Lo prometto. Per te e le ragazze, perché questo significa tanto per me..."


translate italian filles_5f52d6a5:


    grace "Sì, mantieni questo atteggiamento e andrà tutto bene."


translate italian filles_1e3fbdab:


    grace "Bene, io prenderò un po' di champagne! Non ho comprato queste bottiglie per niente quando eravamo in Francia. Devo provarlo!"


translate italian filles_239ecae8:


    julia "Ok. Ci vediamo dopo."


translate italian dream_7853e24a:


    julia "Sono un po' delusa."


translate italian dream_374d0074:


    julia "Dovrò prendere l'iniziativa."


translate italian dream_bc9425a5:


    julia "So che vuoi toccarmi."


translate italian dream_f4bdb854:


    julia "Presto potrete godere di tutto questo."


translate italian dream_19554152:


    julia "SVEGLIATI!" with hpunch


translate italian dream_374d0074_1:


    julia "Dovrò prendere l'iniziativa."


translate italian dream_bc9425a5_1:


    julia "So che vuoi toccarmi."


translate italian dream_f4bdb854_1:


    julia "Presto potrete godere di tutto questo."


translate italian dream_19554152_1:


    julia "SVEGLIATI!" with hpunch


translate italian suiteavion_29ac5843:


    d "Che cosa?"


translate italian suiteavion_332c64eb:


    ji "Svegliati!"


translate italian suiteavion_d98b07ec:


    d "Mi hai spaventato!"


translate italian suiteavion_58043dd2:


    ruby "Sei pazzo? Tu che mi hai spaventato!"


translate italian suiteavion_82a4a47b:


    ruby "Siamo atterrati! Ok Cortex, è ora di andare!"


translate italian suiteavion_22f7922c:


    ruby "Non dimenticare, domani mattina, aspettami all'ingresso! Conquisteremo il mondo! O forse l'accademia è sufficiente per ora. Ci penserò."

translate italian strings:


    old "I'm not a pervert! [TEMP2!t]"
    new "Non sono un pervertito! [TEMP2!t]"


    old "Yeah, sure! [TEMP1!t]"
    new "Sì, certo! [TEMP1!t]"


    old "I don't need your help, thanks anyways! [TEMP2!t]"
    new "Non ho bisogno del tuo aiuto, grazie comunque! [TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
