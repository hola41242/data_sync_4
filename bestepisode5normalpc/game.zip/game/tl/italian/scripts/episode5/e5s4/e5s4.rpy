



translate italian e5s4_5698db07_1:


    julia "IO..."


translate italian e5s4_f67fdb4c:


    julia "[name]!"


translate italian e5s4_ec185663:


    d "Giulia!"


translate italian e5s4_f66d8d77:


    d "Mi dispiace tanto... Stai bene?"


translate italian e5s4_5698db07:


    julia "IO..."


translate italian e5s4_1d4287af:


    julia "Non so nemmeno cosa dovrei fare..."


translate italian e5s4_28738a97:


    julia "Sapevo che prima o poi sarebbe successo, ma..."


translate italian e5s4_629cc342:


    julia "Ora che è reale, io... non so come gestirlo."


translate italian e5s4_9ebde8b0:


    julia "Le scartoffie, il funerale..."


translate italian e5s4_50d9ab42:


    julia "Come diavolo dovrei..."


translate italian e5s4_cd6b97e7:


    d "Ciao... sono qui."


translate italian e5s4_49d41ef1:


    d "Ti aiuterò, ok?"


translate italian e5s4_8fbf9556:


    d "Non preoccuparti. Lo risolveremo insieme."


translate italian e5s4_34c78612:


    d "Per prima cosa devi respirare."


translate italian e5s4_d6f16a8e:


    julia "Sì..."


translate italian e5s4_23439b72:


    julia "Ma non so come farò a superare tutto questo..."


translate italian e5s4_bf67669b:


    julia "Non so nemmeno quanto costi un funerale..."


translate italian e5s4_3e3d52f9:


    julia "E io..."


translate italian e5s4_29ccc355:


    d "Sono proprio qui."


translate italian e5s4_fd221f30:


    d "Non sei solo."


translate italian e5s4_492a2071:


    julia "Grazie..."


translate italian e5s4_7da0825a:


    ji "La signora Carter?"


translate italian e5s4_bc97c9f8:


    d "Ehm?"


translate italian e5s4_3fb1de81:


    julia "SÌ?"


translate italian e5s4_314d5042:


    ji "Abbiamo una lettera per te. Devi leggerla da solo. Contiene informazioni sensibili."


translate italian e5s4_d573cabd:


    ji "Sappi solo che tutto ciò che riguarda tua madre è stato sistemato."


translate italian e5s4_c0ea87f6:


    julia "Aspetta... Cosa?"


translate italian e5s4_d9a48665:


    julia "Ma... chi ha fatto questo?"


translate italian e5s4_5da38dbf:


    julia "Chi sei?"


translate italian e5s4_a871997c:


    ji "Non mi è permesso dire altro."


translate italian e5s4_039f4e17:


    ji "Basta seguire quanto scritto nella lettera."


translate italian e5s4_f3656921:


    julia "[name]?"


translate italian e5s4_ace848dd:


    julia "Che diavolo sta succedendo?"


translate italian e5s4_d461a700:


    d "Non ne ho idea..."


translate italian e5s4_7fec0a9e:


    julia "Ha detto che devo leggerlo da solo."


translate italian e5s4_54b177ed:


    d "Sì... Va bene."


translate italian e5s4_8cb51d10:


    d "Ti lascio un po' di spazio."


translate italian e5s4_0b0d807e:


    d "Ma chiamami se hai bisogno di qualcosa, okay?"


translate italian e5s4_f35e0197:


    julia "Io... tornerò indietro e mi siederò un po' con mia madre."


translate italian e5s4_2c5d85d2:


    d "Grazie per avermi chiamato, Julia."


translate italian e5s4_5df5ea6f:


    julia "Avrei voluto vederti in circostanze migliori..."


translate italian e5s4_0dabc311:


    d "Ehi. Stai facendo ciò che è meglio per lei."


translate italian e5s4_7f1dab77:


    d "E ce la faremo. Insieme."


translate italian e5s4_41dfeedb:


    julia "Ci vediamo domani."


translate italian e5s4_c5072505:


    d "Ci vediamo."


translate italian e5s4_0d61ad15:


    dpense "Giulia..."


translate italian e5s4_c37ac3d7:


    dpense "Ha tenuto duro fino alla fine."


translate italian e5s4_286ea794:


    dpense "E ora deve gestire tutto da sola."


translate italian e5s4_2eb10f7c:


    dpense "Vorrei poter fare di più..."


translate italian e5s4_3b9ee1cc:


    dpense "Quel tizio... Marc."


translate italian e5s4_982b997f:


    dpense "Che diavolo era quell'incontro?"


translate italian e5s4_bb85925e:


    dpense "Tutto ciò che ha detto risuona ancora nella mia testa."


translate italian e5s4_a1601672:


    dpense "È davvero tutto uno spettacolo? Una trappola?"


translate italian e5s4_603617f4:


    dpense "Ruby?"


translate italian e5s4_c683ab53:


    ruby "Ehi... tutto bene?"


translate italian e5s4_04ba0593:


    d "Sì... Sto solo cercando di elaborare tutto."


translate italian e5s4_4390ce19:


    ruby "Ho sentito parlare di Julia..."


translate italian e5s4_abe27dd9:


    d "Sì. Sono andato a trovarla."


translate italian e5s4_77adc2bc:


    d "Sta cercando di tenere duro, ma... è dura."


translate italian e5s4_c79f6782:


    d "Oggi ha perso la mamma."


translate italian e5s4_74bb3c80:


    d "...Aspetta. E Julia?"


translate italian e5s4_dcd7a911:


    ruby "Oh. Non lo sapevi?"


translate italian e5s4_f59e34d5:


    ruby "Sua madre è mancata oggi."


translate italian e5s4_75fdf57c:


    d "Merda... No, non ne avevo sentito parlare."


translate italian e5s4_1cd391bf:


    d "Come sta?"


translate italian e5s4_0c999dd1:


    ruby "Non va bene, ovviamente. Sta cercando di tenere duro, ma... sì."


translate italian e5s4_a9039faa:


    d "Dannazione..."


translate italian e5s4_26979248:


    d "È davvero tanto da assimilare."


translate italian e5s4_4b6212a6:


    ruby "Sì. Ultimamente è tutto un disastro."


translate italian e5s4_78e4e56a:


    ruby "E con quello che è successo a me... e quello che è successo a te..."


translate italian e5s4_3b7ab98b:


    d "Sì. Volevo parlarti di questo."


translate italian e5s4_84aa0ed1:


    d "Ho incontrato una persona. Si chiama Marc."


translate italian e5s4_37015eab:


    d "Mi ha raccontato delle cose. Cose pazzesche."


translate italian e5s4_7e8a656c:


    ruby "Aspetta. Aspetta. Sembra una cosa grandiosa."


translate italian e5s4_c40f4064:


    ruby "Lasciami chiamare Madison e Grace. Dobbiamo parlare tutti."


translate italian e5s4_2e4816fd:


    ruby "Aggiungo Madison... e Grace..."


translate italian e5s4_70a8750f:


    ji "Palazio Pizza, cosa posso offrirti?"


translate italian e5s4_a7091c0a:


    d "...Ruby?"


translate italian e5s4_010c8e4c:


    ruby "Oops! Numero sbagliato!"


translate italian e5s4_0de41c26:


    ji "Aspetta! Chi chiama per la prima volta avrà uno sconto del 20%% sulle pizze al salame piccante!"


translate italian e5s4_ca32cdf5:


    ruby "CIAO!"


translate italian e5s4_39c3230b:


    ruby "Bene! Questa volta ho beccato la vera Madison."


translate italian e5s4_4820c91d:


    mad "Cosa sta succedendo?"


translate italian e5s4_7908ae5f:


    grace "Wow, sembra una cosa seria."


translate italian e5s4_da7d5668:


    ruby "Volevo parlare con tutti voi. Perché... la situazione sta sfuggendo di mano."


translate italian e5s4_98c3ec1f:


    ruby "Grace, tu non c'eri, quindi ti spiegherò."


translate italian e5s4_1e9d5276:


    ruby "Emerick mi ha spinto. Ha perso la testa. Non credo che volesse arrivare a tanto, ma..."


translate italian e5s4_f9ded3c8:


    ruby "Sono stato spinto in strada. Un'auto mi ha quasi investito."


translate italian e5s4_6839a591:


    ruby "[name] mi ha riportato indietro giusto in tempo."


translate italian e5s4_b1974b0e:


    grace "Cosa?! Dici sul serio?"


translate italian e5s4_d005625a:


    ruby "Sì. Ora sto bene, ma... ci sono andato vicino."


translate italian e5s4_7725f489:


    mad "Quando l'ho scoperto, ero furioso."


translate italian e5s4_09776ff3:


    mad "Emerick è fuori controllo."


translate italian e5s4_63484afd:


    grace "Perché diavolo gli è ancora permesso avvicinarsi a noi?"


translate italian e5s4_4e7f2bec:


    ruby "Non lo so. Si comporta come se niente fosse."


translate italian e5s4_5755b285:


    mad "E poi Julia..."


translate italian e5s4_ad61733b:


    d "Sì. Sono andato a trovarla oggi."


translate italian e5s4_ec3da36e:


    d "Sta cercando di tenere duro, ma... è dura."


translate italian e5s4_bf553881:


    d "Sua madre è morta."


translate italian e5s4_6aaccc2f:


    grace "Lo so... è orribile."


translate italian e5s4_725c0812:


    ruby "Non ne parla molto, ma si vede che è distrutta."


translate italian e5s4_c811593d:


    d "Non l'ho vista, ma ho sentito cosa è successo..."


translate italian e5s4_c0efb8e2:


    d "Questo è... questo è davvero pesante."


translate italian e5s4_2b4f2f00:


    grace "Sì. Sua madre è morta oggi."


translate italian e5s4_dcd0fc0a:


    ruby "Si sta trattenendo tutto. Come sempre."


translate italian e5s4_6ef35f4c:


    d "E per di più, oggi ho incontrato una persona. Un ragazzo di nome Marc."


translate italian e5s4_6768b0ed:


    mad "Chi è quello?"


translate italian e5s4_a08e946d:


    d "Lui sostiene di sapere tutto sul MIGLIORE"


translate italian e5s4_dd8a418e:


    d "Ha detto che questo torneo non è come pensiamo."


translate italian e5s4_ce38d77f:


    ruby "Vuoi dire che non si tratta solo di vincere la casa?"


translate italian e5s4_e081b323:


    d "Esatto. Secondo lui, facciamo parte di un sistema più ampio. Qualcosa di pianificato."


translate italian e5s4_ce54a2ac:


    d "Siamo stati scelti. Testati. Osservati."


translate italian e5s4_c810dd52:


    grace "Che diavolo..."


translate italian e5s4_0b6ddbfd:


    mad "Sapevo che tutta questa faccenda sembrava truccata."


translate italian e5s4_693ce52c:


    ruby "Cos'altro ha detto?"


translate italian e5s4_09bbb130:


    d "Non molto. Ma ha detto che avrei iniziato a capire presto..."


translate italian e5s4_0014d5db:


    d "...che il gioco... è già iniziato."


translate italian e5s4_47f431db:


    ruby "Questo è molto più di quanto ci aspettassimo..."


translate italian e5s4_30451cc7:


    grace "Aspetta, cosa intendi quando dici che siamo stati osservati? Da quando?"


translate italian e5s4_773f8271:


    d "Non lo so. Ha detto che va avanti da un po'."


translate italian e5s4_7e0a53c0:


    mad "Quindi, cosa siamo? Topi da laboratorio in un esperimento?"


translate italian e5s4_0d4f13f4:


    d "Non credo che sia così semplice..."


translate italian e5s4_1b07d801:


    ruby "Allora cos'è? Un test? Una trappola?"


translate italian e5s4_1a76835e:


    d "Davvero? Non ho ancora il quadro completo."


translate italian e5s4_e7cb1601:


    grace "Ha detto chi c'è dietro?"


translate italian e5s4_f0bf102d:


    d "No. Solo che fa parte di qualcosa di molto più grande. Che siamo stati scelti."


translate italian e5s4_4c84a898:


    mad "Scelti per cosa esattamente? Per competere? Per combattere? Per perdere tutto?"


translate italian e5s4_28e28f81:


    ruby "Sapevo fin dall'inizio che qualcosa non andava, ma questo..."


translate italian e5s4_7d2acf2e:


    grace "Hai detto che sa tutto? Allora perché non ti ha detto di più?"


translate italian e5s4_2864f00d:


    d "Ha detto che non ero ancora pronto. Che avrei capito presto."


translate italian e5s4_2246aae3:


    mad "Uffa. È davvero criptico."


translate italian e5s4_2fca0cd3:


    ruby "Sembra l'inizio di un discorso di reclutamento per una setta..."


translate italian e5s4_641fa8fe:


    grace "Oppure la trama di un quiz televisivo davvero malriuscito."


translate italian e5s4_aab1be9e:


    d "Diceva che eravamo tutti parte di qualcosa... di più profondo della semplice vittoria."


translate italian e5s4_0016133e:


    ruby "Beh, questo è confortante. Davvero rassicurante."


translate italian e5s4_8ffa9e0d:


    mad "Quindi cosa facciamo? Continuiamo a far finta che non stia succedendo nulla?"


translate italian e5s4_f54ee289:


    grace "Abbiamo bisogno di più informazioni. Non possiamo combattere qualcosa che non comprendiamo nemmeno."


translate italian e5s4_ccc9f612:


    d "Domani cercherò di capirne di più. Se possibile, gli parlerò di nuovo."


translate italian e5s4_67e061e3:


    ruby "Ma... fai attenzione, okay?"


translate italian e5s4_d4fb4120:


    mad "Sì. Non sappiamo con cosa abbiamo a che fare."


translate italian e5s4_27b73db8:


    grace "E se è davvero più grande del torneo... avremo bisogno l'uno dell'altro."


translate italian e5s4_ee54b1de:


    ruby "Lo facciamo già."


translate italian e5s4_aed0c0fd:


    mad "Bene... probabilmente dovremmo riposarci un po'."


translate italian e5s4_0979b50c:


    mad "Domani abbiamo lezione e probabilmente ci saranno altre cose folli da affrontare."


translate italian e5s4_4db8fe42:


    grace "Sì... mi gira la testa."


translate italian e5s4_75665dc5:


    ruby "Dormiamoci sopra. Ne riparleremo domani."


translate italian e5s4_daf14272:


    mad "Buona notte a tutti."


translate italian e5s4_8065de9f:


    grace "Buona notte."


translate italian e5s4_64dc9e96:


    ruby "Ehi... uh, prima che riattacchi del tutto..."


translate italian e5s4_f7fe7a5c:


    ruby "Posso chiederti una cosa strana?"


translate italian e5s4_ac60fa45:


    d "Ovviamente."


translate italian e5s4_ce0d0261:


    ruby "Ti andrebbe bene se venissi stasera?"


translate italian e5s4_b1312370:


    ruby "Io... non voglio restare sola dopo tutto quello che è successo oggi."


translate italian e5s4_0965e6eb:


    ruby "Emerick, la questione del torneo, il discorso di Marc..."


translate italian e5s4_094b1b4f:


    ruby "È semplicemente... troppo. La mia testa non smette di girare."


translate italian e5s4_a6d68059:


    ruby "E so che non sono l'unica persona a cui sei legato."


translate italian e5s4_9cfe6a2e:


    ruby "Non voglio intromettermi né pestare i piedi a nessuno."


translate italian e5s4_3ecfbc5f:


    ruby "Ma stasera... non voglio sentirmi sempre seconda a qualcun altro."


translate italian e5s4_de84ef76:


    ruby "Non chiedo niente di speciale."


translate italian e5s4_9dd34e12:


    ruby "Lasciami solo... sentirmi al sicuro, solo per una notte."


translate italian e5s4_474f9baa:


    d "Ruby..."


translate italian e5s4_5e7830cb:


    ruby "Per favore. Sono stanca di fingere di stare bene quando non è così."


translate italian e5s4_2859ae71:


    d "Sì... vieni. Non devi affrontare tutto questo da sola."


translate italian e5s4_434d1abc:


    ruby "Grazie..."


translate italian e5s4_b930ba57:


    ruby "Avevo proprio bisogno di sentirmelo dire stasera."


translate italian e5s4_195d64bd:


    d "Vorrei dire di sì, ma... cerco di restare fedele a Grace."


translate italian e5s4_d645eb8e:


    d "Se lo merita."


translate italian e5s4_0dd95e4c:


    ruby "...Sì. Lo fa."


translate italian e5s4_3002dbb4:


    ruby "Grazie per essere stato onesto."


translate italian e5s4_f576134c:


    d "Per me sei importante, Ruby. Davvero."


translate italian e5s4_5b14b936:


    d "Ma ora sto con Julia e voglio restare fedele a questo."


translate italian e5s4_8c980e8f:


    ruby "È... gentile da parte tua."


translate italian e5s4_4b4f83cf:


    ruby "È fortunata."


translate italian e5s4_2a4276d1:


    d "Madison e io abbiamo qualcosa... e non voglio rovinarlo."


translate italian e5s4_adadc0dd:


    ruby "Allora non renderò le cose più difficili."


translate italian e5s4_7a5cf108:


    ruby "Starò bene. Avevo solo bisogno di chiedere."


translate italian e5s4_7da82755:


    d "Non sono sicuro che sia una buona idea stasera..."


translate italian e5s4_ad7efad5:


    d "Non voglio che le cose tra noi si confondano."


translate italian e5s4_1f0c1a1b:


    ruby "Abbastanza giusto."


translate italian e5s4_d3f8e7cd:


    ruby "Grazie per essere stato sincero con me."


translate italian e5s4_6d70222a:


    d "Sempre. Riposati un po', ok?"


translate italian e5s4_9b1f8f0e:


    d "Credo di avere qualche minuto prima che lei arrivi."


translate italian e5s4_6975dc98:


    d "Lei ha capito... Comunque, spero che stasera stia bene."


translate italian e5s4_f767a823:


    d "Probabilmente dovrei controllare il mio telefono."


translate italian e5s4_419a87f2:


    dpense "Un messaggio da Grace?"


translate italian e5s4_1fd0f147:


    dpense "Sembra davvero felice qui..."


translate italian e5s4_8ad5a773:


    dpense "E onestamente... lo penso anch'io."


translate italian e5s4_51c7130e:


    dpense "È un ricordo meraviglioso. Solo noi due, nessuna pressione..."


translate italian e5s4_13fc833d:


    dpense "Dovrebbe essere fantastico sul mio OnlyStan..."


translate italian e5s4_7a73f481:


    d "Bellissima foto."


translate italian e5s4_ccdf9116:


    d "Apparentemente siamo forti, sicuri di noi stessi e radiosi."


translate italian e5s4_00e09755:


    d "Questo è solo per noi."


translate italian e5s4_31e40bcd:


    d "Non tutto deve essere lì fuori."


translate italian e5s4_01878ec1:


    dpense "Accidenti... È piena di sorprese."


translate italian e5s4_4f70d01f:


    dpense "Carlotta?"


translate italian e5s4_f3c23a86:


    dpense "Adesso sono davvero curioso..."


translate italian e5s4_6eb69ed4:


    d "Un altro messaggio?"


translate italian e5s4_d8219e99:


    dpense "...Wow."


translate italian e5s4_0e3304c8:


    dpense "Okay, questo... non è proprio quello che mi aspettavo prima di andare a letto."


translate italian e5s4_a7578e9c:


    dpense "Cosa sta progettando?"


translate italian e5s4_c3c1f016:


    dpense "Gabriella?"


translate italian e5s4_977cfae9:


    dpense "Perché ho la sensazione che il massaggio non andrà come mi aspettavo?"


translate italian e5s4_492a2071_1:


    julia "Grazie..."


translate italian bluephoneep5_61f19795:


    dpense "Accidenti... Anche i suoi baci sono civettuoli."


translate italian fine5s4_95524d6a:


    dpense "Elisa..."


translate italian fine5s4_43c4fe17:


    dpense "Ancora nessuna risposta."


translate italian fine5s4_80dafe19:


    dpense "Di solito rispondi subito ai messaggi."


translate italian fine5s4_19228ffc:


    dpense "Spero che vada tutto bene."


translate italian fine5s4_37e64b70:


    dpense "..."


translate italian fine5s4_9126c2f0:


    dpense "Le mando un messaggio. Forse lo vedrà più tardi."


translate italian fine5s4_82a44376:


    dpense "Ciao. Volevo solo farti sapere. Spero che tu stia bene. Fammi sapere se hai bisogno di qualcosa."


translate italian fine5s4_1e77a7f2:


    dpense "Odio non sapere... Elise, dove sei?"


translate italian fine5s4_68c6e8ec:


    ruby "EHI..."


translate italian fine5s4_57d6c7f9:


    d "Ehi, entra pure."


translate italian fine5s4_7271dc12:


    d "Tu sei..."


translate italian fine5s4_4e8b0497:


    d "Bellissima."


translate italian fine5s4_7b1a680f:


    ruby "Grazie..."


translate italian fine5s4_09e8c19c:


    ruby "...di nuovo per avermi permesso di venire."


translate italian fine5s4_7811c038:


    ruby "So che è tardi. Non volevo restare sola."


translate italian fine5s4_651a15b8:


    d "Non sei solo stasera."


translate italian fine5s4_39aa7b90:


    ruby "È stato molto... Emerick, il torneo, Marc..."


translate italian fine5s4_81cee369:


    ruby "Ormai non so nemmeno più dove mi trovo."


translate italian fine5s4_43aeba9d:


    d "Proprio qui. Con me."


translate italian fine5s4_84084c39:


    ruby "Attento... Continua a parlare così, potrei innamorarmi di te."


translate italian fine5s4_46951e3c:


    d "Forse è proprio quello di cui hai bisogno."


translate italian fine5s4_dbda7c19:


    ruby "Forse."


translate italian fine5s4_cf7c937e:


    ruby "Puoi avvicinarti? Davvero... molto vicino?"


translate italian fine5s4_7ed84a97:


    d "Il più vicino possibile."


translate italian fine5s4_91f296cd:


    ruby "Sembra... sicuro."


translate italian fine5s4_79ae661e:


    ruby "Anche se sei vicino a qualcun altro... stasera hai fatto spazio anche per me."


translate italian fine5s4_3faf247b:


    ruby "Ciò significa molto."


translate italian fine5s4_67a0444c:


    d "Ti vedo, Ruby. Ti ho sempre vista."


translate italian fine5s4_2f91314d:


    ruby "Hai un buon profumo..."


translate italian fine5s4_f7e4daff:


    ruby "È pericoloso quando sono così vulnerabile."


translate italian fine5s4_ffdb82a9:


    d "Allora cercherò di non approfittarne..."


translate italian fine5s4_8e992ec1:


    ruby "Mi fido di te."


translate italian fine5s4_63507eef:


    ruby "Sento... che qualcosa sta cambiando. Tra noi."


translate italian fine5s4_d7eb5bfa:


    d "Non sei l'unico."


translate italian fine5s4_c0931e2c:


    ruby "Grazie per essere qui."


translate italian fine5s4_d79ba712:


    ruby "Buona notte, [name]..."


translate italian fine5s4_cc1bfc17:


    d "Buonanotte, Ruby."


translate italian fine5s4_c0028710:


    dpense "Si addormentò velocemente..."


translate italian fine5s4_bcc36e54:


    dpense "Sembra così serena adesso. Così... dolce."


translate italian fine5s4_1f9e783f:


    dpense "La sua spalla è nuda... la coperta è scivolata un po' più giù."


translate italian fine5s4_814b1353:


    dpense "La mia mano è appoggiata sul suo fianco..."


translate italian fine5s4_1096a323:


    dpense "Senza pensarci, la mia mano scivola... solo un po'..."


translate italian fine5s4_5f6783d6:


    dpense "Il suo seno."


translate italian fine5s4_ff931967:


    dpense "A malapena. Il calore della sua pelle sotto le mie dita."


translate italian fine5s4_f5cab973:


    dpense "Lei non si muove. Respira solo... lentamente. Calma."


translate italian fine5s4_c5eaa7ad:


    dpense "Lei è qui, tra le mie braccia."


translate italian fine5s4_6ffb99f3:


    dpense "Fidarsi di me per tutto."


translate italian fine5s4_db130c40:


    dpense "Il suo battito cardiaco... è veloce adesso."


translate italian fine5s4_1795db4e:


    dpense "L'ho svegliata?"


translate italian fine5s4_8efb18eb:


    ruby "Non muoverti..."


translate italian fine5s4_32e37ea9:


    dpense "È sveglia."


translate italian fine5s4_cae1a09f:


    dpense "E lei lo lascia accadere."


translate italian fine5s4_2f17f88f:


    dpense "E adesso... non credo che potrò tornare indietro."


translate italian fine5s4_ce5ea2b0:


    d "Spero che Ruby stia bene..."


translate italian fine5s4_ce3f5fa9:


    d "Sembrava davvero scossa."


translate italian fine5s4_b055f21c:


    d "È solo... difficile."


translate italian fine5s4_eb56c68a:


    d "Per quanto mi importi, non posso essere ovunque contemporaneamente."


translate italian fine5s4_30f54b62:


    d "E a volte, cercare di proteggere tutti significa deludere qualcuno."


translate italian fine5s4_7ba031f2:


    d "Ho fatto la mia scelta."


translate italian fine5s4_7f684aa6:


    d "Non significa che non mi importi di lei... ma devo essere onesto con me stesso."


translate italian fine5s4_c06faaaf:


    d "Mi ha chiesto conforto e io ho rifiutato..."


translate italian fine5s4_398d8d31:


    d "Spero solo che lei capisca il perché."


translate italian fine5s4_52f68f5b:


    d "Tutto questo... il MIGLIORE, Emerick, Marc..."


translate italian fine5s4_cc848cc7:


    d "È come se tutto stesse crollando e ricomponendosi allo stesso tempo."


translate italian fine5s4_f969ee57:


    d "E probabilmente domani non sarà più calmo."


translate italian fine5s4_ebf194fb:


    d "Un passo alla volta..."





translate italian e5s4_5698db07_1:


    julia "IO..."





translate italian e5s4_f67fdb4c:


    julia "[name]!"





translate italian e5s4_ec185663:


    d "Giulia!"





translate italian e5s4_f66d8d77:


    d "Mi dispiace tanto... Stai bene?"





translate italian e5s4_5698db07:


    julia "IO..."





translate italian e5s4_1d4287af:


    julia "Non so nemmeno cosa dovrei fare..."





translate italian e5s4_28738a97:


    julia "Sapevo che prima o poi sarebbe successo, ma..."





translate italian e5s4_629cc342:


    julia "Ora che è reale, io... non so come gestirlo."





translate italian e5s4_9ebde8b0:


    julia "Le scartoffie, il funerale..."





translate italian e5s4_50d9ab42:


    julia "Come diavolo dovrei..."





translate italian e5s4_cd6b97e7:


    d "Ciao... sono qui."





translate italian e5s4_49d41ef1:


    d "Ti aiuterò, ok?"





translate italian e5s4_8fbf9556:


    d "Non preoccuparti. Lo risolveremo insieme."





translate italian e5s4_34c78612:


    d "Per prima cosa devi respirare."





translate italian e5s4_d6f16a8e:


    julia "Sì..."





translate italian e5s4_23439b72:


    julia "Ma non so come farò a superare tutto questo..."





translate italian e5s4_bf67669b:


    julia "Non so nemmeno quanto costi un funerale..."





translate italian e5s4_3e3d52f9:


    julia "E io..."





translate italian e5s4_29ccc355:


    d "Sono proprio qui."





translate italian e5s4_fd221f30:


    d "Non sei solo."





translate italian e5s4_492a2071:


    julia "Grazie..."





translate italian e5s4_7da0825a:


    ji "La signora Carter?"





translate italian e5s4_bc97c9f8:


    d "Ehm?"





translate italian e5s4_3fb1de81:


    julia "SÌ?"





translate italian e5s4_314d5042:


    ji "Abbiamo una lettera per te. Devi leggerla da solo. Contiene informazioni sensibili."





translate italian e5s4_d573cabd:


    ji "Sappi solo che tutto ciò che riguarda tua madre è stato sistemato."





translate italian e5s4_c0ea87f6:


    julia "Aspetta... Cosa?"





translate italian e5s4_d9a48665:


    julia "Ma... chi ha fatto questo?"





translate italian e5s4_5da38dbf:


    julia "Chi sei?"





translate italian e5s4_a871997c:


    ji "Non mi è permesso dire altro."





translate italian e5s4_039f4e17:


    ji "Basta seguire quanto scritto nella lettera."





translate italian e5s4_f3656921:


    julia "[name]?"





translate italian e5s4_ace848dd:


    julia "Che diavolo sta succedendo?"





translate italian e5s4_d461a700:


    d "Non ne ho idea..."





translate italian e5s4_7fec0a9e:


    julia "Ha detto che devo leggerlo da solo."





translate italian e5s4_54b177ed:


    d "Sì... Va bene."





translate italian e5s4_8cb51d10:


    d "Ti lascio un po' di spazio."





translate italian e5s4_0b0d807e:


    d "Ma chiamami se hai bisogno di qualcosa, okay?"





translate italian e5s4_f35e0197:


    julia "Io... tornerò indietro e mi siederò un po' con mia madre."





translate italian e5s4_2c5d85d2:


    d "Grazie per avermi chiamato, Julia."





translate italian e5s4_5df5ea6f:


    julia "Avrei voluto vederti in circostanze migliori..."





translate italian e5s4_0dabc311:


    d "Ehi. Stai facendo ciò che è meglio per lei."





translate italian e5s4_7f1dab77:


    d "E ce la faremo. Insieme."





translate italian e5s4_41dfeedb:


    julia "Ci vediamo domani."





translate italian e5s4_c5072505:


    d "Ci vediamo."





translate italian e5s4_0d61ad15:


    dpense "Giulia..."





translate italian e5s4_c37ac3d7:


    dpense "Ha tenuto duro fino alla fine."





translate italian e5s4_286ea794:


    dpense "E ora deve gestire tutto da sola."





translate italian e5s4_2eb10f7c:


    dpense "Vorrei poter fare di più..."





translate italian e5s4_3b9ee1cc:


    dpense "Quel tizio... Marc."





translate italian e5s4_982b997f:


    dpense "Che diavolo era quell'incontro?"





translate italian e5s4_bb85925e:


    dpense "Tutto ciò che ha detto risuona ancora nella mia testa."





translate italian e5s4_a1601672:


    dpense "È davvero tutto uno spettacolo? Una trappola?"





translate italian e5s4_603617f4:


    dpense "Ruby?"





translate italian e5s4_c683ab53:


    ruby "Ehi... tutto bene?"





translate italian e5s4_04ba0593:


    d "Sì... Sto solo cercando di elaborare tutto."





translate italian e5s4_4390ce19:


    ruby "Ho sentito parlare di Julia..."





translate italian e5s4_abe27dd9:


    d "Sì. Sono andato a trovarla."





translate italian e5s4_77adc2bc:


    d "Sta cercando di tenere duro, ma... è dura."





translate italian e5s4_c79f6782:


    d "Oggi ha perso la mamma."





translate italian e5s4_74bb3c80:


    d "...Aspetta. E Julia?"





translate italian e5s4_dcd7a911:


    ruby "Oh. Non lo sapevi?"





translate italian e5s4_f59e34d5:


    ruby "Sua madre è mancata oggi."





translate italian e5s4_75fdf57c:


    d "Merda... No, non ne avevo sentito parlare."





translate italian e5s4_1cd391bf:


    d "Come sta?"





translate italian e5s4_0c999dd1:


    ruby "Non va bene, ovviamente. Sta cercando di tenere duro, ma... sì."





translate italian e5s4_a9039faa:


    d "Dannazione..."





translate italian e5s4_26979248:


    d "È davvero tanto da assimilare."





translate italian e5s4_4b6212a6:


    ruby "Sì. Ultimamente è tutto un disastro."





translate italian e5s4_78e4e56a:


    ruby "E con quello che è successo a me... e quello che è successo a te..."





translate italian e5s4_3b7ab98b:


    d "Sì. Volevo parlarti di questo."





translate italian e5s4_84aa0ed1:


    d "Ho incontrato una persona. Si chiama Marc."





translate italian e5s4_37015eab:


    d "Mi ha raccontato delle cose. Cose pazzesche."





translate italian e5s4_7e8a656c:


    ruby "Aspetta. Aspetta. Sembra una cosa grandiosa."





translate italian e5s4_c40f4064:


    ruby "Lasciami chiamare Madison e Grace. Dobbiamo parlare tutti."





translate italian e5s4_2e4816fd:


    ruby "Aggiungo Madison... e Grace..."





translate italian e5s4_70a8750f:


    ji "Palazio Pizza, cosa posso offrirti?"





translate italian e5s4_a7091c0a:


    d "...Ruby?"





translate italian e5s4_010c8e4c:


    ruby "Oops! Numero sbagliato!"





translate italian e5s4_0de41c26:


    ji "Aspetta! Chi chiama per la prima volta avrà uno sconto del 20%% sulle pizze al salame piccante!"





translate italian e5s4_ca32cdf5:


    ruby "CIAO!"





translate italian e5s4_39c3230b:


    ruby "Bene! Questa volta ho beccato la vera Madison."





translate italian e5s4_4820c91d:


    mad "Cosa sta succedendo?"





translate italian e5s4_7908ae5f:


    grace "Wow, sembra una cosa seria."





translate italian e5s4_da7d5668:


    ruby "Volevo parlare con tutti voi. Perché... la situazione sta sfuggendo di mano."





translate italian e5s4_98c3ec1f:


    ruby "Grace, tu non c'eri, quindi ti spiegherò."





translate italian e5s4_1e9d5276:


    ruby "Emerick mi ha spinta. Ha perso la testa. Non credo che volesse arrivare a tanto, ma..."





translate italian e5s4_f9ded3c8:


    ruby "Sono stata spinta in strada. Un'auto mi ha quasi investita."





translate italian e5s4_6839a591:


    ruby "[name] mi ha riportata indietro giusto in tempo."





translate italian e5s4_b1974b0e:


    grace "Cosa?! Dici sul serio?"





translate italian e5s4_d005625a:


    ruby "Sì. Ora sto bene, ma... ci sono andata vicino."





translate italian e5s4_7725f489:


    mad "Quando l'ho scoperto, ero furioso."





translate italian e5s4_09776ff3:


    mad "Emerick è fuori controllo."





translate italian e5s4_63484afd:


    grace "Perché diavolo gli è ancora permesso avvicinarsi a noi?"





translate italian e5s4_4e7f2bec:


    ruby "Non lo so. Si comporta come se niente fosse."





translate italian e5s4_5755b285:


    mad "E poi Julia..."





translate italian e5s4_ad61733b:


    d "Sì. Sono andato a trovarla oggi."





translate italian e5s4_ec3da36e:


    d "Sta cercando di tenere duro, ma... è dura."





translate italian e5s4_bf553881:


    d "Sua madre è morta."





translate italian e5s4_6aaccc2f:


    grace "Lo so... è orribile."





translate italian e5s4_725c0812:


    ruby "Non ne parla molto, ma si vede che è distrutta."





translate italian e5s4_c811593d:


    d "Non l'ho vista, ma ho sentito cosa è successo..."





translate italian e5s4_c0efb8e2:


    d "Questo è... questo è davvero pesante."





translate italian e5s4_2b4f2f00:


    grace "Sì. Sua madre è morta oggi."





translate italian e5s4_dcd0fc0a:


    ruby "Si sta trattenendo tutto. Come sempre."





translate italian e5s4_6ef35f4c:


    d "E per di più, oggi ho incontrato una persona. Un ragazzo di nome Marc."





translate italian e5s4_6768b0ed:


    mad "Chi è quello?"





translate italian e5s4_a08e946d:


    d "Lui sostiene di sapere tutto sul MIGLIORE"





translate italian e5s4_dd8a418e:


    d "Ha detto che questo torneo non è come pensiamo."





translate italian e5s4_ce38d77f:


    ruby "Vuoi dire che non si tratta solo di vincere la casa?"





translate italian e5s4_e081b323:


    d "Esatto. Secondo lui, facciamo parte di un sistema più ampio. Qualcosa di pianificato."





translate italian e5s4_ce54a2ac:


    d "Siamo stati scelti. Testati. Osservati."





translate italian e5s4_c810dd52:


    grace "Che diavolo..."





translate italian e5s4_0b6ddbfd:


    mad "Sapevo che tutta questa faccenda sembrava truccata."





translate italian e5s4_693ce52c:


    ruby "Cos'altro ha detto?"





translate italian e5s4_09bbb130:


    d "Non molto. Ma ha detto che avrei iniziato a capire presto..."





translate italian e5s4_0014d5db:


    d "...che il gioco... è già iniziato."





translate italian e5s4_47f431db:


    ruby "Questo è molto più di quanto ci aspettassimo..."





translate italian e5s4_30451cc7:


    grace "Aspetta, cosa intendi quando dici che siamo stati osservati? Da quando?"





translate italian e5s4_773f8271:


    d "Non lo so. Ha detto che va avanti da un po'."





translate italian e5s4_7e0a53c0:


    mad "Quindi, cosa siamo? Topi da laboratorio in un esperimento?"





translate italian e5s4_0d4f13f4:


    d "Non credo che sia così semplice..."





translate italian e5s4_1b07d801:


    ruby "Allora cos'è? Un test? Una trappola?"





translate italian e5s4_1a76835e:


    d "Davvero? Non ho ancora il quadro completo."





translate italian e5s4_e7cb1601:


    grace "Ha detto chi c'è dietro?"





translate italian e5s4_f0bf102d:


    d "No. Solo che fa parte di qualcosa di molto più grande. Che siamo stati scelti."





translate italian e5s4_4c84a898:


    mad "Scelti per cosa esattamente? Per competere? Per combattere? Per perdere tutto?"





translate italian e5s4_28e28f81:


    ruby "Sapevo fin dall'inizio che qualcosa non andava, ma questo..."





translate italian e5s4_7d2acf2e:


    grace "Hai detto che sa tutto? Allora perché non ti ha detto di più?"





translate italian e5s4_2864f00d:


    d "Ha detto che non ero ancora pronto. Che avrei capito presto."





translate italian e5s4_2246aae3:


    mad "Uffa. È davvero criptico."





translate italian e5s4_2fca0cd3:


    ruby "Sembra l'inizio di un discorso di reclutamento per una setta..."





translate italian e5s4_641fa8fe:


    grace "Oppure la trama di un quiz televisivo davvero malriuscito."





translate italian e5s4_aab1be9e:


    d "Diceva che eravamo tutti parte di qualcosa... di più profondo della semplice vittoria."





translate italian e5s4_0016133e:


    ruby "Beh, questo è confortante. Davvero rassicurante."





translate italian e5s4_8ffa9e0d:


    mad "Quindi cosa facciamo? Continuiamo a far finta che non stia succedendo nulla?"





translate italian e5s4_f54ee289:


    grace "Abbiamo bisogno di più informazioni. Non possiamo combattere qualcosa che non comprendiamo nemmeno."





translate italian e5s4_ccc9f612:


    d "Domani cercherò di capirne di più. Se possibile, gli parlerò di nuovo."





translate italian e5s4_67e061e3:


    ruby "Ma... fai attenzione, okay?"





translate italian e5s4_d4fb4120:


    mad "Sì. Non sappiamo con cosa abbiamo a che fare."





translate italian e5s4_27b73db8:


    grace "E se è davvero più grande del torneo... avremo bisogno l'uno dell'altro."





translate italian e5s4_ee54b1de:


    ruby "Lo facciamo già."





translate italian e5s4_aed0c0fd:


    mad "Bene... probabilmente dovremmo riposarci un po'."





translate italian e5s4_0979b50c:


    mad "Domani abbiamo lezione e probabilmente ci saranno altre cose folli da affrontare."





translate italian e5s4_4db8fe42:


    grace "Sì... mi gira la testa."





translate italian e5s4_75665dc5:


    ruby "Dormiamoci sopra. Ne riparleremo domani."





translate italian e5s4_daf14272:


    mad "Buona notte a tutti."





translate italian e5s4_8065de9f:


    grace "Buona notte."





translate italian e5s4_64dc9e96:


    ruby "Ehi... uh, prima che riattacchi del tutto..."





translate italian e5s4_f7fe7a5c:


    ruby "Posso chiederti una cosa strana?"





translate italian e5s4_ac60fa45:


    d "Ovviamente."





translate italian e5s4_ce0d0261:


    ruby "Ti andrebbe bene se venissi stasera?"





translate italian e5s4_b1312370:


    ruby "Io... non voglio restare sola dopo tutto quello che è successo oggi."





translate italian e5s4_0965e6eb:


    ruby "Emerick, la questione del torneo, il discorso di Marc..."





translate italian e5s4_094b1b4f:


    ruby "È semplicemente... troppo. La mia testa non smette di girare."





translate italian e5s4_a6d68059:


    ruby "E so che non sono l'unica persona a cui sei legato."





translate italian e5s4_9cfe6a2e:


    ruby "Non voglio intromettermi né pestare i piedi a nessuno."





translate italian e5s4_3ecfbc5f:


    ruby "Ma stasera... non voglio sentirmi sempre seconda a qualcun altro."





translate italian e5s4_de84ef76:


    ruby "Non chiedo niente di speciale."





translate italian e5s4_9dd34e12:


    ruby "Lasciami solo... sentirmi al sicuro, solo per una notte."





translate italian e5s4_474f9baa:


    d "Ruby..."





translate italian e5s4_5e7830cb:


    ruby "Per favore. Sono stanca di fingere di stare bene quando non è così."





translate italian e5s4_2859ae71:


    d "Sì... vieni. Non devi affrontare tutto questo da sola."





translate italian e5s4_434d1abc:


    ruby "Grazie..."





translate italian e5s4_b930ba57:


    ruby "Avevo proprio bisogno di sentirmelo dire stasera."





translate italian e5s4_195d64bd:


    d "Vorrei dire di sì, ma... cerco di restare fedele a Grace."





translate italian e5s4_d645eb8e:


    d "Se lo merita."





translate italian e5s4_0dd95e4c:


    ruby "...Sì. Lo fa."





translate italian e5s4_3002dbb4:


    ruby "Grazie per essere stato onesto."





translate italian e5s4_f576134c:


    d "Per me sei importante, Ruby. Davvero."





translate italian e5s4_5b14b936:


    d "Ma ora sto con Julia e voglio restare fedele a questo."





translate italian e5s4_8c980e8f:


    ruby "È... gentile da parte tua."





translate italian e5s4_4b4f83cf:


    ruby "È fortunata."





translate italian e5s4_2a4276d1:


    d "Madison e io abbiamo qualcosa... e non voglio rovinarlo."





translate italian e5s4_adadc0dd:


    ruby "Allora non renderò le cose più difficili."





translate italian e5s4_7a5cf108:


    ruby "Starò bene. Avevo solo bisogno di chiedere."





translate italian e5s4_7da82755:


    d "Non sono sicuro che sia una buona idea stasera..."





translate italian e5s4_ad7efad5:


    d "Non voglio che le cose tra noi si confondano."





translate italian e5s4_1f0c1a1b:


    ruby "Abbastanza giusto."





translate italian e5s4_d3f8e7cd:


    ruby "Grazie per essere stato sincero con me."





translate italian e5s4_6d70222a:


    d "Sempre. Riposati un po', ok?"





translate italian e5s4_9b1f8f0e:


    d "Credo di avere qualche minuto prima che lei arrivi."





translate italian e5s4_6975dc98:


    d "Lei ha capito... Comunque, spero che stasera stia bene."





translate italian e5s4_f767a823:


    d "Probabilmente dovrei controllare il mio telefono."





translate italian e5s4_419a87f2:


    dpense "Un messaggio da Grace?"





translate italian e5s4_1fd0f147:


    dpense "Sembra davvero felice qui..."





translate italian e5s4_8ad5a773:


    dpense "E onestamente... lo penso anch'io."





translate italian e5s4_51c7130e:


    dpense "È un ricordo meraviglioso. Solo noi due, nessuna pressione..."





translate italian e5s4_13fc833d:


    dpense "Dovrebbe essere fantastico sul mio OnlyStan..."





translate italian e5s4_7a73f481:


    d "Bellissima foto."





translate italian e5s4_ccdf9116:


    d "Apparentemente siamo forti, sicuri di noi stessi e radiosi."





translate italian e5s4_00e09755:


    d "Questo è solo per noi."





translate italian e5s4_31e40bcd:


    d "Non tutto deve essere lì fuori."





translate italian e5s4_01878ec1:


    dpense "Accidenti... È piena di sorprese."





translate italian e5s4_4f70d01f:


    dpense "Carlotta?"





translate italian e5s4_f3c23a86:


    dpense "Adesso sono davvero curioso..."





translate italian e5s4_6eb69ed4:


    d "Un altro messaggio?"





translate italian e5s4_d8219e99:


    dpense "...Wow."





translate italian e5s4_0e3304c8:


    dpense "Okay, questo... non è proprio quello che mi aspettavo prima di andare a letto."





translate italian e5s4_a7578e9c:


    dpense "Cosa sta progettando?"





translate italian e5s4_c3c1f016:


    dpense "Gabriella?"





translate italian e5s4_977cfae9:


    dpense "Perché ho la sensazione che il massaggio non andrà come mi aspettavo?"





translate italian e5s4_492a2071_1:


    julia "Grazie..."





translate italian bluephoneep5_61f19795:


    dpense "Accidenti... Anche i suoi baci sono civettuoli."





translate italian fine5s4_95524d6a:


    dpense "Elisa..."





translate italian fine5s4_43c4fe17:


    dpense "Ancora nessuna risposta."





translate italian fine5s4_80dafe19:


    dpense "Di solito rispondi subito ai messaggi."





translate italian fine5s4_19228ffc:


    dpense "Spero che vada tutto bene."





translate italian fine5s4_37e64b70:


    dpense "..."





translate italian fine5s4_9126c2f0:


    dpense "Le mando un messaggio. Forse lo vedrà più tardi."





translate italian fine5s4_82a44376:


    dpense "Ciao. Volevo solo farti sapere. Spero che tu stia bene. Fammi sapere se hai bisogno di qualcosa."





translate italian fine5s4_1e77a7f2:


    dpense "Odio non sapere... Elise, dove sei?"





translate italian fine5s4_68c6e8ec:


    ruby "EHI..."





translate italian fine5s4_57d6c7f9:


    d "Ehi, entra pure."





translate italian fine5s4_7271dc12:


    d "Tu sei..."





translate italian fine5s4_4e8b0497:


    d "Bellissima."





translate italian fine5s4_7b1a680f:


    ruby "Grazie..."





translate italian fine5s4_09e8c19c:


    ruby "...di nuovo per avermi permesso di venire."





translate italian fine5s4_7811c038:


    ruby "So che è tardi. Non volevo restare sola."





translate italian fine5s4_651a15b8:


    d "Non sei solo stasera."





translate italian fine5s4_39aa7b90:


    ruby "È stato molto... Emerick, il torneo, Marc..."





translate italian fine5s4_81cee369:


    ruby "Ormai non so nemmeno più dove mi trovo."





translate italian fine5s4_43aeba9d:


    d "Proprio qui. Con me."





translate italian fine5s4_84084c39:


    ruby "Attento... Continua a parlare così, potrei innamorarmi di te."





translate italian fine5s4_46951e3c:


    d "Forse è proprio quello di cui hai bisogno."





translate italian fine5s4_dbda7c19:


    ruby "Forse."





translate italian fine5s4_cf7c937e:


    ruby "Puoi avvicinarti? Davvero... molto vicino?"





translate italian fine5s4_7ed84a97:


    d "Il più vicino possibile."





translate italian fine5s4_91f296cd:


    ruby "Sembra... sicuro."





translate italian fine5s4_79ae661e:


    ruby "Anche se sei vicino a qualcun altro... stasera hai fatto spazio anche per me."





translate italian fine5s4_3faf247b:


    ruby "Ciò significa molto."





translate italian fine5s4_67a0444c:


    d "Ti vedo, Ruby. Ti ho sempre vista."





translate italian fine5s4_2f91314d:


    ruby "Hai un buon profumo..."





translate italian fine5s4_f7e4daff:


    ruby "È pericoloso quando sono così vulnerabile."





translate italian fine5s4_ffdb82a9:


    d "Allora cercherò di non approfittarne..."





translate italian fine5s4_8e992ec1:


    ruby "Mi fido di te."





translate italian fine5s4_63507eef:


    ruby "Sento... che qualcosa sta cambiando. Tra noi."





translate italian fine5s4_d7eb5bfa:


    d "Non sei l'unico."





translate italian fine5s4_c0931e2c:


    ruby "Grazie per essere qui."





translate italian fine5s4_d79ba712:


    ruby "Buona notte, [name]..."





translate italian fine5s4_cc1bfc17:


    d "Buonanotte, Ruby."





translate italian fine5s4_c0028710:


    dpense "Si addormentò velocemente..."





translate italian fine5s4_bcc36e54:


    dpense "Sembra così serena adesso. Così... dolce."





translate italian fine5s4_1f9e783f:


    dpense "La sua spalla è nuda... la coperta è scivolata un po' più giù."





translate italian fine5s4_814b1353:


    dpense "La mia mano è appoggiata sul suo fianco..."





translate italian fine5s4_1096a323:


    dpense "Senza pensarci, la mia mano scivola... solo un po'..."





translate italian fine5s4_5f6783d6:


    dpense "Il suo seno."





translate italian fine5s4_ff931967:


    dpense "A malapena. Il calore della sua pelle sotto le mie dita."





translate italian fine5s4_f5cab973:


    dpense "Lei non si muove. Respira solo... lentamente. Calma."





translate italian fine5s4_c5eaa7ad:


    dpense "Lei è qui, tra le mie braccia."





translate italian fine5s4_6ffb99f3:


    dpense "Fidarsi di me per tutto."





translate italian fine5s4_db130c40:


    dpense "Il suo battito cardiaco... è veloce adesso."





translate italian fine5s4_1795db4e:


    dpense "L'ho svegliata?"





translate italian fine5s4_8efb18eb:


    ruby "Non muoverti..."





translate italian fine5s4_32e37ea9:


    dpense "È sveglia."





translate italian fine5s4_cae1a09f:


    dpense "E lei lo lascia accadere."





translate italian fine5s4_2f17f88f:


    dpense "E adesso... non credo che potrò tornare indietro."





translate italian fine5s4_ce5ea2b0:


    d "Spero che Ruby stia bene..."





translate italian fine5s4_ce3f5fa9:


    d "Sembrava davvero scossa."





translate italian fine5s4_b055f21c:


    d "È solo... difficile."





translate italian fine5s4_eb56c68a:


    d "Per quanto mi importi, non posso essere ovunque contemporaneamente."





translate italian fine5s4_30f54b62:


    d "E a volte, cercare di proteggere tutti significa deludere qualcuno."





translate italian fine5s4_7ba031f2:


    d "Ho fatto la mia scelta."





translate italian fine5s4_7f684aa6:


    d "Non significa che non mi importi di lei... ma devo essere onesto con me stesso."





translate italian fine5s4_c06faaaf:


    d "Mi ha chiesto conforto e io ho rifiutato..."





translate italian fine5s4_398d8d31:


    d "Spero solo che lei capisca il perché."





translate italian fine5s4_52f68f5b:


    d "Tutto questo... il MIGLIORE, Emerick, Marc..."





translate italian fine5s4_cc848cc7:


    d "È come se tutto stesse crollando e ricomponendosi allo stesso tempo."





translate italian fine5s4_f969ee57:


    d "E probabilmente domani non sarà più calmo."





translate italian fine5s4_ebf194fb:


    d "Un passo alla volta..."




translate italian e5s4_8a1461c3:


    ji "Signorina Carter?"





translate italian e5s4_8a1461c3:


    ji "Signorina Carter?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
