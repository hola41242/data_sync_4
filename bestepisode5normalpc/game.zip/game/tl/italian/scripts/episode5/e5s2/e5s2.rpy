



translate italian kira_vs_emerick_430a38c0:


    kira "A cosa stavi pensando? Cosa stavi cercando di dimostrare esattamente con Ruby?"





translate italian kira_vs_emerick_60e88850:


    emerick "Non stavo cercando di dimostrare niente. Mi ha solo ostacolato. Ho perso la pazienza."





translate italian kira_vs_emerick_9974e51e:


    kira "Hai perso la calma? L'hai quasi mandata in ospedale!"





translate italian kira_vs_emerick_0c89150d:


    kira "Hai idea di quanto sia grave questa situazione?"





translate italian kira_vs_emerick_86f3cd68:


    emerick "E perché ti importa, Kira? Perché sei coinvolta?"





translate italian kira_vs_emerick_ea9cbdc9:


    emerick "Hai tutto! Status, privilegi, l'eredità."





translate italian kira_vs_emerick_7febb490:


    emerick "Allora perché sei in questa competizione? Non ne hai bisogno."





translate italian kira_vs_emerick_d74a1365:


    kira "E pensi che questo giustifichi quello che hai fatto?"





translate italian kira_vs_emerick_b892bef5:


    kira "Che solo perché sono nato in una posizione migliore, tu hai il diritto di agire come vuoi?"





translate italian kira_vs_emerick_1dde4087:


    kira "Emerick, quello che stai facendo è un sabotaggio. Non solo verso gli altri, ma anche verso te stesso."





translate italian kira_vs_emerick_2a562568:


    emerick "Sabotaggio? Sto lottando per ciò che merito, Kira."





translate italian kira_vs_emerick_8d747f52:


    emerick "Ti è stato dato tutto. Devo dimostrare il mio valore a ogni passo."





translate italian kira_vs_emerick_b35ade4d:


    kira "E pensi che sia questo il modo giusto per farlo? Inseguire Ruby o chiunque altro non ti rende più forte."





translate italian kira_vs_emerick_f356141e:


    kira "Ti fa solo sembrare un moccioso viziato."





translate italian kira_vs_emerick_dadcee83:


    emerick "Un moccioso viziato? Parli come se sapessi tutto, come se fossi superiore a tutto questo."





translate italian kira_vs_emerick_d4f971fb:


    emerick "Forse tu lo sei, Kira, ma io no. Devo giocare per vincere, costi quel che costi."





translate italian kira_vs_emerick_c20496a1:


    kira "Stai giocando per vincere? No, stai giocando perché hai paura. Non vuoi ammetterlo, ma hai paura di lui."





translate italian kira_vs_emerick_26c92200:


    emerick "Chi lui? [name]? Pensi davvero che io abbia paura di quel tizio?"





translate italian kira_vs_emerick_80b55e77:


    emerick "Non è niente. Niente!"





translate italian kira_vs_emerick_3ecc51be:


    ben "Ehi!"





translate italian kira_vs_emerick_9a9e3fee:


    emerick "Non ho paura di lui e non permetterò a nessuno di insinuare il contrario."





translate italian kira_vs_emerick_baa43a8e:


    kira "E tuttavia non riesci a smettere di reagire ogni volta che lo nomini."





translate italian kira_vs_emerick_4d09adb1:


    kira "È quasi fin troppo facile capire quanto ti dia fastidio. Ma non importa. Non sono qui per discutere con te."





translate italian kira_vs_emerick_ec295777:


    emerick "Allora perché sei qui? Per farmi di nuovo la predica?"





translate italian kira_vs_emerick_7b6d0751:


    kira "No. Sono qui per dirti di stare lontano da Ruby."





translate italian kira_vs_emerick_cc23a4dc:


    kira "Questa è l'ultima volta che fai una cosa del genere. E se continui così, Emerick, sarai tu quello fuori dal gioco."





translate italian gracee5s2_5e53d018:


    d "Stai andando alla grande, Grace. Ricorda, prenditi il ​​tuo tempo e concentrati sul tuo equilibrio."





translate italian gracee5s2_25a32f9d:


    grace "Ci sto provando! Ma sembra che questa parete rocciosa non finisca mai."





translate italian gracee5s2_881e7db3:


    d "Stai andando meglio di quanto pensi. L'arrampicata richiede pazienza e sicurezza. Mantieni il peso vicino al muro."





translate italian gracee5s2_ce836b73:


    grace "Più facile a dirsi che a farsi... Ok, credo di aver capito. E adesso?"





translate italian gracee5s2_2c06a82d:


    d "Vedete quella sporgenza a circa due metri di altezza? Ancora un po' di sforzo e potremo fare una breve pausa."





translate italian gracee5s2_f6f41eba:


    grace "Va bene. Ce la posso fare."





translate italian gracee5s2_60a521fb:


    grace "Wow... non mi ero mai reso conto di quanta forza ci volesse."





translate italian gracee5s2_bd94a93b:


    d "Ecco perché è così gratificante. Quando raggiungi la vetta, ti senti come se avessi conquistato il mondo."





translate italian gracee5s2_9f9db109:


    grace "Ce l'abbiamo fatta! Guarda che panorama..."





translate italian gracee5s2_6bf8c336:


    d "Davvero incredibile, eh? È per questo che adoro arrampicare. È come se il resto del mondo sparisse."





translate italian gracee5s2_3a586080:


    grace "Capisco perché ti piace. C'è così tanta pace quassù... solo noi e l'orizzonte."





translate italian gracee5s2_f6c9d445:


    d "Sai, Grace... essere qui mi fa chiedere: cosa ti spinge davvero a provare cose come questa?"





translate italian gracee5s2_dd25c71c:


    grace "Immagino sia perché mi sono perso tante cose quando ero più giovane."





translate italian gracee5s2_cf93a16e:


    grace "Mio padre era sempre impegnato in missioni umanitarie e mia madre…"





translate italian gracee5s2_d618ca6c:


    grace "Lei era tutta una questione di voti e risultati. Io non ho avuto modo di esplorare davvero ciò che desideravo."





translate italian gracee5s2_a0099d9f:


    d "Quindi ora stai recuperando il tempo perso?"





translate italian gracee5s2_9c28033b:


    grace "Esatto. Sto provando cose che non avrei mai immaginato, solo per vedere cosa funziona."





translate italian gracee5s2_236e6284:


    grace "Scalare una montagna, imparare nuove competenze... è il mio modo di scoprire chi sono veramente."





translate italian gracee5s2_a6989932:


    d "È davvero coraggioso. Molti non ci proverebbero nemmeno."





translate italian gracee5s2_793a9728:


    grace "Beh, avere qualcuno come te al tuo fianco aiuta. È più facile correre rischi quando sai di non essere solo."





translate italian sexygracee5s2_17ea1ead:


    grace "A proposito di rischi…"





translate italian sexygracee5s2_7cdaa598:


    grace "La vista è incredibile, ma sapete cosa è ancora meglio?"





translate italian sexygracee5s2_9baa9c83:


    d " Che cos'è?"





translate italian sexygracee5s2_1bf2c142:


    grace "Sai, l'ultima volta è stata fantastica. Ma non riesco a smettere di pensare a quanto ti desidero di nuovo."





translate italian sexygracee5s2_9dff1a4f:


    d "Davvero? Qui in mezzo alla natura?"





translate italian sexygracee5s2_88aafb2e:


    grace " Perché no? Non c'è nessuno in giro. Solo il vento e gli alberi. Voglio dire, questo è il nostro momento, no?"





translate italian sexygracee5s2_b96c9ffb:


    d "Grace... sei piena di sorprese."





translate italian sexygracee5s2_9fa4c060:


    grace "E ti piace."





translate italian sexygracee5s2_66f82310:


    grace "Ci siamo solo noi qui. Nessuna distrazione. Voglio che tu mi veda, solo io."





translate italian sexygracee5s2_03d8fcea:


    d "Sì, più di quanto immagini."





translate italian sexygracee5s2_34f8b5b1:


    grace " Allora mostramelo."





translate italian sexygracee5s2_0ae9bcd0:


    ""





translate italian sexygracee5s2_22f9d196:


    grace "Sì... Ecco fatto! Davvero buono!"





translate italian sexygracee5s2_0b254e36:


    d "Grace, sei così stretta!"





translate italian sexygracee5s2_3cf4a0c1:


    grace "Dovremo farlo più spesso!"





translate italian sexygracee5s2_86cf3182:


    d "Sono sempre felice di accontentarti!"





translate italian sexygracee5s2_a6949bdc:


    grace "Sì, più in profondità... Per favore..."





translate italian sexygracee5s2_e3427569:


    grace "È una bella sensazione."





translate italian sexygracee5s2_f78c3eac:


    grace "Aspetta un attimo. Prendimi da dietro!"





translate italian sexygracee5s2_bf58cff1:


    grace "Oh! Quell'angolazione è ancora più bella!"





translate italian sexygracee5s2_1cf81eb6:


    grace "Continua... Per favore..."





translate italian sexygracee5s2_44928221:


    d "Grace, non durerò a lungo!"





translate italian sexygracee5s2_dc177f84:


    grace "Quindi, non farlo!"





translate italian sexygracee5s2_b59160c0:


    d "Grace..."





translate italian sexygracee5s2_7f563f32:


    grace "Ohhhhhhhhhhhhh! Sì!!!!!!"





translate italian sexygracee5s2_bfc939b4:


    grace "Sai... tutta questa esperienza è qualcosa che non avrei mai pensato di fare."





translate italian sexygracee5s2_34708511:


    d "E sono felice che tu ci abbia provato. Sono momenti come questo che mi ricordano perché mi sono innamorato di te."





translate italian sexygracee5s2_441200b6:


    grace " Beh, l'hai sicuramente reso memorabile."





translate italian sexygracee5s2_0ae9bcd0_1:


    ""





translate italian sexygracee5s2_0ae9bcd0_2:


    ""





translate italian sexygracee5s2_0ae9bcd0_3:


    ""





translate italian endgracee5s2_c1b59b5c:


    d "Torniamo indietro e vediamo quali altre avventure ci aspettano."





translate italian endgracee5s2_80326d52:


    grace "Sento di aver raggiunto qualcosa di straordinario. Grazie per avermi mostrato i trucchi del mestiere, letteralmente."





translate italian endgracee5s2_67ab4f3a:


    d "Nessun problema. Hai gestito la tua prima salita davvero bene."





translate italian endgracee5s2_4c8911df:


    grace "Forse dovrò rifarlo un'altra volta. Ma ora credo sia il momento di tornare indietro."





translate italian gabye5s2_b234501b:


    d "Ah, eccoti qui, Gabriella. Pensavo quasi di essere in anticipo."





translate italian gabye5s2_954b7bc3:


    gaby "Sei puntuale, [name] Questo è già un buon inizio."





translate italian gabye5s2_7c485d36:


    d "Sei sempre pieno di sorprese, ma io sono pronto per qualsiasi cosa tu abbia in mente."





translate italian gabye5s2_fb6d37b0:


    gaby "Prima di iniziare, come stai dopo quell'ultima partita?"





translate italian gabye5s2_ebad0537:


    d "A dire il vero, sto meglio. La mia schiena non fa che peggiorare da... quell'incidente con Ruby."





translate italian gabye5s2_c4d1eb46:


    gaby "Quale incidente?"





translate italian gabye5s2_e7942129:


    d "Io... beh, stava per farsi male e ho dovuto intervenire. La situazione si è fatta un po'... intensa."





translate italian gabye5s2_59625d19:


    gaby "Ti sei messo in gioco per lei? Non pensavo che ne avessi le capacità."





translate italian gabye5s2_bbcf6a2f:


    d "Non potevo restare lì a guardare. Ma ora... ne sto pagando il prezzo."





translate italian gabye5s2_ae2363fb:


    gaby "Un eroe che ha bisogno di riprendersi un po', quindi?"





translate italian gabye5s2_5db421a6:


    d "Qualcosa del genere."





translate italian gabye5s2_94e0ebe2:


    gaby "Conosco un posto. Un piccolo studio massaggi non lontano da qui. Specialisti in terapia sportiva. Ho imparato qualche trucco anch'io da loro."





translate italian gabye5s2_078dcf7d:


    d "Vuoi offrirti di occuparti personalmente del massaggio?"





translate italian gabye5s2_e5cc8d38:


    gaby "Penso che ti piacerebbe un po' troppo."





translate italian gabye5s2_d788de3e:


    d "Non puoi biasimarmi per averci provato, vero?"





translate italian gabye5s2_9c8316b7:


    gaby "Bene, basta chiacchiere. È ora di un po' di allenamento."





translate italian gabye5s2_a4e1ec70:


    d "Allenarsi per cosa esattamente?"





translate italian gabye5s2_e0ffdaa0:


    gaby "Vedrai. Preparati a lavorare su quelle competenze."





translate italian gabye5s2_7dc7fb28:


    d "Okay, ma perché ho la sensazione che tu stia nascondendo qualcosa?"





translate italian gabye5s2_68703f1b:


    gaby "Se te lo dicessi ora, non sarebbe altrettanto divertente osservare la tua reazione."





translate italian gabye5s2_b40f9c8d:


    dpense "Aspetta... cosa c'è?"





translate italian gabye5s2_2f84c3bb:


    d "EHI!"





translate italian gabye5s2_8757c10b:


    mad "Ci hai messo abbastanza tempo per accorgerti di me, [name]."





translate italian gabye5s2_d1447287:


    d "Madison? Cosa ci fai qui?"





translate italian gabye5s2_fd76949c:


    mad "Gaby ha detto che avevi bisogno di un vero allenamento. Quindi... eccomi qui."





translate italian gabye5s2_245c1805:


    d "Oh, ci siamo."





translate italian gabye5s2_35142fea:


    gaby "L'esercizio di oggi è semplice. Voglio che vi spariate a vicenda con tutta la forza che riuscite a gestire."





translate italian gabye5s2_6b535cba:


    d "Che cosa???" with hpunch





translate italian gabye5s2_7e644d50:


    mad "Ahah! Lo ADORERÒ!"





translate italian gabye5s2_5c041625:


    gaby "E ricorda... devi rispondere alla palla con la stessa forza con cui ti arriva. Semplice, no?"





translate italian gabye5s2_0732ddf4:


    d "Aspetta, dici sul serio?!"





translate italian gabye5s2_f60ff0bc:


    mad "Guarda la palla, [name]!"





translate italian gabye5s2_74e1ee21:


    d "Non ero pronto!"





translate italian gabye5s2_29d4ac8e:


    mad "E adesso?"





translate italian gabye5s2_cf0a6a24:


    d "Madison!!!!!"





translate italian gabye5s2_10c440ff:


    d "Sei brava, Madison. Te lo concedo."





translate italian gabye5s2_05bb1173:


    mad "Anche tu non sei male. Immagino che dovremo continuare a incoraggiarci a vicenda."





translate italian gabye5s2_9a9a9608:


    gaby "Questo è lo spirito giusto. Ora, riposatevi un po'. Avremo bisogno di entrambi al meglio per la prossima partita."





translate italian gabye5s2_546f6774:


    d "Grazie, Gaby. E Madison... bel lavoro."





translate italian gabye5s2_fc01931e:


    mad "Anche tu, [name] Ma la prossima volta..."





translate italian gabye5s2_f464664f:


    mad "Non sembrare così terrorizzato quando la palla ti vola in faccia!"





translate italian evelyne5s2_a650529a:


    d "Wow... Che posto fantastico."





translate italian evelyne5s2_becac631:


    d "Ha detto che ci avrebbe aspettato dentro."





translate italian evelyne5s2_423e9317:


    ji "Giovane."





translate italian evelyne5s2_62fb39a8:


    d "Ronzio?"





translate italian evelyne5s2_c5e3e443:


    d "Evelyn, è bello vederti."





translate italian evelyne5s2_ff7aaf80:


    evelyn "Sei puntuale. Stavo iniziando a chiedermi se potessi essere audace e puntuale."





translate italian evelyne5s2_72e57299:


    d "Il mio obiettivo è impressionare."





translate italian evelyne5s2_a44f4722:


    evelyn "Impressionare? Attento, giovanotto. La prima impressione conta solo fino a un certo punto."





translate italian evelyne5s2_25feb380:


    d "Forse, ma è onesto. Questo conta qualcosa, no?"





translate italian evelyne5s2_8532cb87:


    evelyn "Vediamo se riesci a mantenerlo così."





translate italian evelyne5s2_8e674de3:


    d "Non ero nemmeno sicuro che volessi davvero incontrarti dopo la nostra chiamata."





translate italian evelyne5s2_fd2e5403:


    evelyn "Perché no? Mi hai sorpreso al Palazio. Mistero e sicurezza sono merci rare di questi tempi."





translate italian evelyne5s2_2364e806:


    d "Quindi ho superato il primo test?"





translate italian evelyne5s2_650b63e4:


    evelyn "\"Superato\" è un po' ambizioso. Diciamo che sei riuscito a rimanere nel consiglio."





translate italian evelyne5s2_c6ed178d:


    d "Intrigo o fallimento? Questo sì che è giusto."





translate italian evelyne5s2_18e2e1d8:


    evelyn "Bene. Ma ricorda... l'intrigo funziona solo se non ci si sforza troppo. L'equilibrio, tesoro, è la chiave."





translate italian evelyne5s2_e929b0ed:


    d "E per te che aspetto ha l'equilibrio?"





translate italian evelyne5s2_6cad5637:


    evelyn "Si tratta di sapere quando è il momento di andare avanti... e quando è il momento di far sì che qualcuno ti rincorra."





translate italian evelyne5s2_cd8ca222:


    evelyn "Quando parlare e quando lasciare che il silenzio dica più di quanto potrebbero mai fare le parole."





translate italian evelyne5s2_70b3fb67:


    evelyn "E soprattutto... si tratta di sicurezza, non di arroganza. Non dimenticare mai la differenza."





translate italian evelyne5s2_38f96d88:


    evelyn "Hai del potenziale, [name] Ma non sono qui per parole vuote. Apprezzo l'azione, la riflessione... lo scopo."





translate italian evelyne5s2_aabab7a7:


    d "Forse è per questo che sono qui. Per dimostrarti che non sono solo chiacchiere."





translate italian evelyne5s2_401a18a2:


    evelyn "Attenzione. Sembra sospettosamente simile a una promessa. E le promesse... hanno un peso."





translate italian evelyne5s2_4ad67b83:


    evelyn "Prima di andare, ho qualcosa per te."





translate italian evelyne5s2_463e2712:


    d "Che cos'è questo?"





translate italian evelyne5s2_777b6d4a:


    evelyn "Una chiave per un tipo di gioco diverso, [name] Una cosa a cui la maggior parte delle persone non si rende nemmeno conto di stare già giocando."





translate italian evelyne5s2_de2a154e:


    evelyn "Questo è un badge che ti consente di accedere alla sezione VIP del Palazio."





translate italian evelyne5s2_59c7e9cb:


    d "Un invito speciale da parte della donna stessa?"





translate italian evelyne5s2_3a658ded:


    evelyn "Non correre troppo. Sto semplicemente... offrendo una porta."





translate italian evelyne5s2_34ceb768:


    evelyn "Se poi avrai il coraggio di attraversarlo è tutta un'altra questione."





translate italian evelyne5s2_cbf5225d:


    d "Vedrai. Non ho intenzione di sprecare opportunità."





translate italian evelyne5s2_5518e0eb:


    evelyn "Bene. Non vedo l'ora di vedere fin dove sei disposto ad arrivare."





translate italian evelyne5s2_04857837:


    evelyn "Ma per ora... devo lasciarvi con il dubbio."





translate italian evelyne5s2_96cc6180:


    d "Allora non ti tratterrò."





translate italian evelyne5s2_a1b3e397:


    evelyn "Scelta saggia. E ricorda, [name]...quando la partita inizia, rischiate. E non deludetemi."





translate italian evelyne5s2_61b916eb:


    dpense "Un gioco diverso...? E quella sezione VIP... In cosa diavolo sto per infilarmi?"





translate italian evelyne5s2_fcc1ba01:


    dpense "È diversa da chiunque abbia mai incontrato. Sicura di sé, misteriosa... sembra che mi stia mettendo alla prova, sfidandomi a fare un passo avanti."





translate italian evelyne5s2_a0934412:


    dpense "Ma non sono uno che si tira indietro di fronte a una sfida."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
