



translate italian e5final_cbd86156:


    orushi "La sfida è finita."


translate italian e5final_8e9a8d61:


    orushi "Le scatole hanno rivelato la loro verità e solo dieci di voi hanno ottenuto un gettone."


translate italian e5final_c086ea0b:


    orushi "Ecco i dieci giocatori qualificati per la fase successiva del BEST:"


translate italian e5final_d41e48ec:


    orushi "Madison, Julia, Grace, Ruby, Sofia, Red, Kira, Steven, Emerick... e [name]."


translate italian e5final_2b68b3c9:


    dpense "Ce l'abbiamo fatta. Dieci ancora in piedi. Dieci per il vero combattimento."


translate italian e5final_61b2ee07:


    orushi "Interessante."


translate italian e5final_4957490e:


    orushi "Davvero molto interessante."


translate italian e5final_13c153a6:


    orushi "Devo ammettere che alcuni di voi hanno dimostrato... un potenziale inaspettato."


translate italian e5final_9f3a38d8:


    orushi "Avete affrontato prove. Vi siete combattuti. A volte vi siete traditi."


translate italian e5final_72a35d67:


    orushi "Hai corso, saltato, risolto, combattuto. Hai sedotto, bluffato, resistito."


translate italian e5final_3c5733bf:


    orushi "Ma soprattutto... credevate tutti che avesse un significato."


translate italian e5final_060f387e:


    mad "Cosa intendi?"


translate italian e5final_65ae2928:


    orushi "Ciò che hai appena sperimentato... è stato solo un riscaldamento."


translate italian e5final_34927185:


    orushi "Questa era solo una preselezione."


translate italian e5final_f0b208fd:


    orushi "Una prova generale, un torneo ombra, una serie di qualificazioni per... qualcosa di molto più grande."


translate italian e5final_0368b86e:


    beth "Tch. Lo immaginavo anch'io..."


translate italian e5final_4187ee7b:


    orushi "Ciò che hai affrontato qui... è stato solo un preludio."


translate italian e5final_c8946c78:


    orushi "Un torneo chiuso. Locale. Nascosto al mondo esterno."


translate italian e5final_bbb2d66e:


    orushi "Ma il vero MIGLIORE..."


translate italian e5final_5e129c9e:


    orushi "...è una competizione globale."


translate italian e5final_2c6aafb3:


    orushi "Trasmesso in diretta. In ogni Paese, in tutto il mondo..."


translate italian e5final_ba04c124:


    orushi "...dove ogni tua mossa influenzerà il modo in cui il mondo ti vedrà."


translate italian e5final_4c107ff4:


    dpense "Il mondo intero...?"


translate italian e5final_18ee960f:


    ruby "Impossibile... È uno scherzo?"


translate italian e5final_81d6844c:


    orushi "Oh, no. Non scherzo mai."


translate italian e5final_f3db7362:


    orushi "Pensi di aver finito? Hai appena iniziato."


translate italian e5final_4db8fb6f:


    orushi "Molto presto, i vostri nomi, i vostri volti, i vostri difetti, le vostre ambizioni..."


translate italian e5final_224643b2:


    orushi "...saranno portati alla luce."


translate italian e5final_5e919ebb:


    orushi "E chi sei veramente... sarà giudicato dal mondo intero."


translate italian e5final_4b89b6d5:


    orushi "Squadre da tutto il mondo. Selezionate con cura. Allenate per mesi."


translate italian e5final_517f47bb:


    orushi "Alcuni hanno fallito. Altri sono pronti. Tu... hai superato il primo cancello."


translate italian e5final_64f7aadd:


    grace "Perché noi? Perché tutto questo?"


translate italian e5final_3ec31ebc:


    orushi "Quello che hai attraversato non è stato un gioco. È stato un filtro. Una rivelazione."


translate italian e5final_59ea5225:


    orushi "BEST non è una competizione per bambini. È un catalizzatore."


translate italian e5final_1d7bdf66:


    orushi "Preparatevi."


translate italian e5final_b2411d5c:


    orushi "Il palcoscenico sta crescendo."


translate italian e5final_676d021d:


    orushi "Il gioco... sta cambiando scala."


translate italian e5final_783ba284:


    orushi "Squadre da tutto il mondo verranno qui per affrontarti."


translate italian e5final_abe03b34:


    orushi "E il primo è appena arrivato dall'aeroporto!"


translate italian e5final_63be2349:


    d "Che cosa..."


translate italian e5final_f3a28e44:


    d "IL..."


translate italian e5final_7543c4f0:


    d "Fanculo???"


translate italian e5final_5c553fbe:


    d "Elise...?!"


translate italian e5final_285f8ea7:


    "Per favore, salva la partita qui..."


translate italian e5final_b003f642:


    orushi "Non è finita!"


translate italian e5final_fcba8ba6:


    mad "Entrerò nella torre di Orushi e scoprirò cosa sta succedendo!!!"


translate italian e5final_d9821bcd:


    orushi "Questo processo ci dirà chi sarà il nuovo capitano della squadra!"


translate italian e5final_37648b20:


    orushi "Preparatevi per la finale!"





translate italian e5final_cbd86156:


    orushi "La sfida è finita."





translate italian e5final_8e9a8d61:


    orushi "Le scatole hanno rivelato la loro verità e solo dieci di voi hanno ottenuto un gettone."





translate italian e5final_c086ea0b:


    orushi "Ecco i dieci giocatori qualificati per la fase successiva del BEST:"





translate italian e5final_d41e48ec:


    orushi "Madison, Julia, Grace, Ruby, Sofia, Red, Kira, Steven, Emerick... e [name]."





translate italian e5final_2b68b3c9:


    dpense "Ce l'abbiamo fatta. Dieci ancora in piedi. Dieci per il vero combattimento."





translate italian e5final_61b2ee07:


    orushi "Interessante."





translate italian e5final_4957490e:


    orushi "Davvero molto interessante."





translate italian e5final_13c153a6:


    orushi "Devo ammettere che alcuni di voi hanno dimostrato... un potenziale inaspettato."





translate italian e5final_9f3a38d8:


    orushi "Avete affrontato prove. Vi siete combattuti. A volte vi siete traditi."





translate italian e5final_72a35d67:


    orushi "Hai corso, saltato, risolto, combattuto. Hai sedotto, bluffato, resistito."





translate italian e5final_3c5733bf:


    orushi "Ma soprattutto... credevate tutti che avesse un significato."





translate italian e5final_060f387e:


    mad "Cosa intendi?"





translate italian e5final_65ae2928:


    orushi "Ciò che hai appena sperimentato... è stato solo un riscaldamento."





translate italian e5final_34927185:


    orushi "Questa era solo una preselezione."





translate italian e5final_f0b208fd:


    orushi "Una prova generale, un torneo ombra, una serie di qualificazioni per... qualcosa di molto più grande."





translate italian e5final_0368b86e:


    beth "Tch. Lo immaginavo anch'io..."





translate italian e5final_4187ee7b:


    orushi "Ciò che hai affrontato qui... è stato solo un preludio."





translate italian e5final_c8946c78:


    orushi "Un torneo chiuso. Locale. Nascosto al mondo esterno."





translate italian e5final_bbb2d66e:


    orushi "Ma il vero MIGLIORE..."





translate italian e5final_5e129c9e:


    orushi "...è una competizione globale."





translate italian e5final_2c6aafb3:


    orushi "Trasmesso in diretta. In ogni Paese, in tutto il mondo..."





translate italian e5final_ba04c124:


    orushi "...dove ogni tua mossa influenzerà il modo in cui il mondo ti vedrà."





translate italian e5final_4c107ff4:


    dpense "Il mondo intero...?"





translate italian e5final_18ee960f:


    ruby "Impossibile... È uno scherzo?"





translate italian e5final_81d6844c:


    orushi "Oh, no. Non scherzo mai."





translate italian e5final_f3db7362:


    orushi "Pensi di aver finito? Hai appena iniziato."





translate italian e5final_4db8fb6f:


    orushi "Molto presto, i vostri nomi, i vostri volti, i vostri difetti, le vostre ambizioni..."





translate italian e5final_224643b2:


    orushi "...saranno portati alla luce."





translate italian e5final_5e919ebb:


    orushi "E chi sei veramente... sarà giudicato dal mondo intero."





translate italian e5final_4b89b6d5:


    orushi "Squadre da tutto il mondo. Selezionate con cura. Allenate per mesi."





translate italian e5final_517f47bb:


    orushi "Alcuni hanno fallito. Altri sono pronti. Tu... hai superato il primo cancello."





translate italian e5final_64f7aadd:


    grace "Perché noi? Perché tutto questo?"





translate italian e5final_3ec31ebc:


    orushi "Quello che hai attraversato non è stato un gioco. È stato un filtro. Una rivelazione."





translate italian e5final_59ea5225:


    orushi "BEST non è una competizione per bambini. È un catalizzatore."





translate italian e5final_1d7bdf66:


    orushi "Preparatevi."





translate italian e5final_b2411d5c:


    orushi "Il palcoscenico sta crescendo."





translate italian e5final_676d021d:


    orushi "Il gioco... sta cambiando scala."





translate italian e5final_783ba284:


    orushi "Squadre da tutto il mondo verranno qui per affrontarti."





translate italian e5final_abe03b34:


    orushi "E il primo è appena arrivato dall'aeroporto!"





translate italian e5final_63be2349:


    d "Che cosa..."





translate italian e5final_f3a28e44:


    d "IL..."





translate italian e5final_7543c4f0:


    d "Fanculo???"





translate italian e5final_5c553fbe:


    d "Elise...?!"





translate italian e5final_285f8ea7:


    "Per favore, salva la partita qui..."





translate italian e5final_b003f642:


    orushi "Non è finita!"





translate italian e5final_fcba8ba6:


    mad "Entrerò nella torre di Orushi e scoprirò cosa sta succedendo!!!"





translate italian e5final_d9821bcd:


    orushi "Questo processo ci dirà chi sarà il nuovo capitano della squadra!"





translate italian e5final_37648b20:


    orushi "Preparatevi per la finale!"





translate italian e5final_d18ed18b:


    orushi "Dieci di voi hanno ottenuto un gettone."





translate italian e5final_12a54177:


    orushi "Madison, Julia, Grace, Ruby, Sofia, Elizabeth, Kira, Steven, Emerick... e [name]."





translate italian e5final_b834ee76:


    orushi "Squadre da tutto il mondo..."





translate italian e5final_ee3d0d5e:


    orushi "Stanno venendo qui per affrontarti."





translate italian e5final_f50837a2:


    beth "Davvero?"





translate italian e5final_d91abf5f:


    mad "Chi sono..."





translate italian e5final_b77f246c:


    grace "Nuovi avversari?"





translate italian e5final_87a80f3c:


    d "Aspettare..."





translate italian e5final_d18ed18b:


    orushi "Dieci di voi hanno ottenuto un gettone."





translate italian e5final_12a54177:


    orushi "Madison, Julia, Grace, Ruby, Sofia, Elizabeth, Kira, Steven, Emerick... e [name]."





translate italian e5final_b834ee76:


    orushi "Squadre da tutto il mondo..."





translate italian e5final_ee3d0d5e:


    orushi "Stanno venendo qui per affrontarti."





translate italian e5final_f50837a2:


    beth "Davvero?"





translate italian e5final_d91abf5f:


    mad "Chi sono..."





translate italian e5final_b77f246c:


    grace "Nuovi avversari?"





translate italian e5final_87a80f3c:


    d "Aspettare..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
