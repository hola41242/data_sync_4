



translate italian e5s3_396d0192:


    dpense "E... nessuna risposta..."





translate italian e5s3_e3f5663e:


    dpense "Beh... credo di non avere scelta."





translate italian e5s3_e5c4ad3e:


    dpense "Forse finalmente avrò qualche risposta a tutto questo..."





translate italian e5s3_4ffc23de:


    dpense "Questo edificio fa paura."





translate italian e5s3_382711d6:


    dpense "Che cos'è questo…?"





translate italian e5s3_f75c3263:


    ji "Benvenuto, [name]."





translate italian e5s3_7d80e01f:


    ji "Puoi sederti qui."





translate italian e5s3_4446e157:


    d "Posso sapere il tuo nome?"





translate italian e5s3_d5a593df:


    ji "Non hai bisogno del mio nome, ma... se insisti, puoi chiamarmi Marc."





translate italian e5s3_28144102:


    d "Va bene…"





translate italian e5s3_cfd044c8:


    marc "COSÌ... [name] Sono sicuro che hai molte domande e stai aspettando delle risposte."





translate italian e5s3_70a2a024:


    marc "Ma sia chiaro: non sono qui per rispondere. Non direttamente."





translate italian e5s3_a6d898e9:


    d "Cosa? Allora perché sono qui?"





translate italian e5s3_2314e146:


    marc "Perché devi capire dove ti trovi... e perché alcune persone hanno garantito che tu ricevessi un piccolo aiuto."





translate italian e5s3_6555aa00:


    d "Aiuto? Perché dovrei aver bisogno di aiuto?"





translate italian e5s3_59e124c3:


    marc "Di nuovo con le domande inutili."





translate italian e5s3_8180340e:


    marc "Non sei di qui. Non conosci nessuno. Ti sei ritrovato coinvolto in una competizione che potrebbe cambiarti la vita..."





translate italian e5s3_d8fbc473:


    marc "E mi chiedi perché avresti bisogno di aiuto?"





translate italian e5s3_caf27d63:


    d "IO…"





translate italian e5s3_8368f671:


    marc "Non sprecare fiato. Ascolta attentamente, invece."





translate italian e5s3_1b4ce3bd:


    marc "Qualcuno ha pensato che meritassi una possibilità di comprendere il quadro generale prima di perderti in esso."





translate italian e5s3_98e83cac:


    marc "Dimmi, [name] …cosa sai del MIGLIORE?"





translate italian e5s3_18ba1390:


    d "Si tratta di una competizione tra studenti per ottenere una buona posizione presso la Orushi Corp."





translate italian e5s3_fac19c04:


    marc "Sbagliato."





translate italian e5s3_dd5d68f3:


    d "Cosa?"





translate italian e5s3_c726c09d:


    marc "Questo è quello che ti hanno detto. Ma non è affatto questo il vero scopo."





translate italian e5s3_389980e0:


    d "Allora di cosa si tratta?"





translate italian e5s3_3f2205d5:


    marc "Stai iniziando a porre domande migliori."





translate italian e5s3_4d4d3497:


    d "È una lotteria. 100 studenti vengono scelti a caso per competere per un posto."





translate italian e5s3_7d6733b2:


    marc "Non esiste la casualità, [name]."





translate italian e5s3_2c3a63c7:


    d "Cosa intendi?"





translate italian e5s3_0d77b1b7:


    marc "Stai iniziando a capire. Continua."





translate italian e5s3_e406ae20:


    d "È solo intrattenimento per qualche riccone che vuole guardare la gente litigare per il suo divertimento."





translate italian e5s3_6453588e:


    marc "Non è lontano dalla verità... ma non hai ancora colto il punto."





translate italian e5s3_9010a74c:


    marc "Orushi non è il vero pubblico qui."





translate italian e5s3_55c9c860:


    d "Allora chi è?"





translate italian e5s3_7ef99dd5:


    marc "Fate le domande giuste e vi spiegherò."





translate italian bestexplanation_715ebbc3:


    marc "Ricordate i gladiatori dell'Impero Romano?"





translate italian bestexplanation_aa785934:


    d "Hmm... sì."





translate italian bestexplanation_08235dd6:


    marc "Grandi arene, folle ruggenti, uomini che combattono contro bestie o tra loro fino alla morte. Spettacolo al suo massimo splendore."





translate italian bestexplanation_3be96c82:


    marc "Ma dimmi... chi ha pagato tutto questo?"





translate italian bestexplanation_1603dd57:


    d "L'Imperatore?"





translate italian bestexplanation_4615bff6:


    marc "No. La sua ricchezza non era infinita, contrariamente a quanto la gente amava credere."





translate italian bestexplanation_e99a02c7:


    d "E poi… l’Impero?"





translate italian bestexplanation_98b4de85:


    marc "Con il costo delle guerre continue? Difficilmente. Ancora non lo vedi."





translate italian bestexplanation_025df574:


    dpense "Cosa vuole dire...?"





translate italian bestexplanation_c663583e:


    marc "Erano le famiglie benestanti, i mercanti, le élite potenti. Finanziavano i giochi, non per beneficenza... ma per mantenere il controllo."





translate italian bestexplanation_59092df7:


    marc "Una popolazione affamata e arrabbiata è pericolosa. Ma date loro pane... e un circo, e dimenticheranno la loro miseria."





translate italian bestexplanation_58bd80c4:


    marc "Eroi da tifare. Sangue per placare le loro frustrazioni. Sogni di gloria per distrarli dalle loro catene."





translate italian bestexplanation_0bcc902d:


    marc "E ora, guardatevi intorno. Qual è il MIGLIORE se non l'arena moderna?"





translate italian bestexplanation_0d141fe1:


    marc "Nel corso della storia, le persone hanno percepito questa mano nascosta all'opera."





translate italian bestexplanation_eeaf8592:


    marc "Ma poiché non potevano vederlo, gli diedero dei nomi..."





translate italian bestexplanation_3eef63f3:


    marc "Leggende. Miti. Cospirazioni."





translate italian bestexplanation_274c8110:


    marc "Gli Illuminati. I Massoni. I Templari."





translate italian bestexplanation_682c07e5:


    marc "E oggi? Il Gruppo Bilderberg, il Deep State, le cosiddette élite globali."





translate italian bestexplanation_713e4e20:


    marc "Per secoli, è stato sufficiente controllare l'informazione. Decidere quali verità venivano raccontate... e quali sepolte."





translate italian bestexplanation_7d652284:


    marc "Ma i tempi sono cambiati. Le informazioni ora si muovono troppo velocemente."





translate italian bestexplanation_017f95a9:


    marc "Una voce, uno scandalo, un video virale... e intere nazioni possono bruciare prima ancora che abbiamo il tempo di reagire."





translate italian bestexplanation_b850f3b5:


    marc "Prendiamo un esempio recente... Pensi davvero che sia stata una coincidenza il fatto che i reality siano esplosi proprio quando è scoppiata l'ultima grande crisi economica?"





translate italian bestexplanation_1619c3d4:


    marc "Milioni di persone stavano perdendo il lavoro, la casa, il futuro..."





translate italian bestexplanation_e988bc62:


    marc "E cosa trovavano ad aspettarli ogni notte?"





translate italian bestexplanation_833bb17c:


    marc "Programmi su fama improvvisa, soldi facili e vite lussuose e completamente irraggiungibili."





translate italian bestexplanation_23c827d5:


    marc "Fateli sognare. Teneteli distratti. Mentre le loro vite reali andavano in pezzi, erano troppo impegnati a guardare gli altri fingere di vivere alla perfezione."





translate italian bestexplanation_87ca8bf2:


    marc "E quando gli schermi nei loro salotti non bastavano più... gli abbiamo fatto scivolare il circo direttamente nelle tasche."





translate italian bestexplanation_84a021c4:


    marc "I social media hanno preso il sopravvento. Scrolling infinito, indignazione infinita, infinite scariche di dopamina."





translate italian bestexplanation_a0e52b4b:


    marc "Un'indignazione senza fine per tenerli distratti, mentre le decisioni reali che riguardavano le loro vite venivano prese in segreto."





translate italian bestexplanation_a5dcf4d8:


    marc "Pane e circensi, [name] Basta questo. Schermi più piccoli. Stesso gioco."





translate italian bestexplanation_9d4ddd03:


    marc "Il controllo non riguarda più le catene. Riguarda ciò che cattura la loro attenzione. E chiunque controlli questo... controlla tutto."





translate italian bestexplanation_bd71ec79:


    marc "Ma questa volta è ancora più efficace. Perché CONTROLLARE le informazioni quando puoi DIVENTARE le informazioni stesse?"





translate italian bestexplanation_2e24d673:


    marc "In un mondo in cui le notizie si muovono più velocemente della verità, quale modo migliore per dare forma alla realtà se non mettendo il tuo gioco al centro di tutto?"





translate italian bestexplanation_c0e48e60:


    marc "Mentre le persone dovrebbero preoccuparsi del loro lavoro, della loro libertà, del loro futuro…"





translate italian bestexplanation_829eb3a5:


    marc "Di cosa parlano invece? Di TE. Delle tue vittorie. Dei tuoi fallimenti. Dei tuoi scandali. La tua vita è diventata notizia."





translate italian bestexplanation_72934bfc:


    marc "Eroi e cattivi, storie d'amore e tradimenti... il tutto perfettamente confezionato per un mondo alla disperata ricerca di distrazioni."





translate italian bestexplanation_b2f5c003:


    marc "E la parte migliore? Questa volta è tutto vero. Niente copione. Niente bugie. Solo tu... che vivi la storia che tutti vogliono consumare."





translate italian bestexplanation_2c94123f:


    marc "Non ti limiti a giocare, [name] Tu SEI il gioco."





translate italian bestexplanation_93630f24:


    dpense "Questo... questo non può essere reale... La mia vita... uno spettacolo per il mondo intero?"





translate italian bestexplanation_194eef8f:


    d "Perché io? Perché proprio noi? Cosa ci rende così speciali?"





translate italian bestexplanation_18d15a00:


    marc "Ah... la domanda più prevedibile di tutte."





translate italian bestexplanation_b5dd47e7:


    marc "Credi davvero nelle coincidenze, [name]?"





translate italian bestexplanation_6a19f320:


    marc "Ogni partecipante è stato scelto per un motivo. Non per chi è... ma per ciò che rappresenta."





translate italian bestexplanation_7032949a:


    d "Quindi qual è il mio ruolo in tutto questo? Perché sono qui?"





translate italian bestexplanation_9523f34b:


    marc "Tu sei l'ignoto. L'incognita. La variabile che non rientra nell'equazione."





translate italian bestexplanation_e70abc86:


    marc "Non hai alcuna eredità, nessun nome famoso, nessuna catena nascosta che ti spinge ad andare avanti."





translate italian bestexplanation_2816d66d:


    marc "Tu sei quello che non dovrebbe essere qui... eppure, eccoti qui."





translate italian bestexplanation_c9739e4d:


    marc "E questo ti rende pericoloso."





translate italian bestexplanation_74fe7708:


    marc "Porti con te qualcosa di raro, qualcosa di incontrollabile: la SPERANZA."





translate italian bestexplanation_5437e331:


    marc "Per ogni volto senza nome nell'ombra, per ogni anima dimenticata a cui è stato detto che non avrà mai importanza... tu sei la prova che potrebbero sbagliarsi."





translate italian bestexplanation_8552631c:


    marc "Sei il sogno impossibile."





translate italian bestexplanation_5a38659a:


    marc "Colui che potrebbe vincere..."





translate italian bestexplanation_8c10b855:


    marc "...quando tutto era progettato perché tu fallissi."





translate italian chooseexplanation_effff65f:


    d "E Grace? Perché è stata scelta?"





translate italian chooseexplanation_5ebdefac:


    marc "Grace è l'immagine perfetta di una vita già scritta prima ancora di iniziare."





translate italian chooseexplanation_7e280618:


    marc "Figlia del Preside, istruita, raffinata... la sua strada era segnata fin dalla nascita."





translate italian chooseexplanation_c0f77d45:


    marc "Sposatevi bene, rafforzate le alleanze familiari, vivete una vita di obbedienza silenziosa."





translate italian chooseexplanation_6414e87b:


    marc "Ma in fondo è il volto di ogni ragazza che, rinchiusa in una gabbia dorata, sogna di liberarsi."





translate italian chooseexplanation_08d8f426:


    marc "Per il mondo, è il simbolo della ribellione silenziosa contro un destino imposto dal sangue e dal dovere."





translate italian chooseexplanation_233ba0a3:


    d "E Madison?"





translate italian chooseexplanation_5ac0b015:


    marc "Madison è un paradosso. Una ribelle nata al potere, un'ereditiera che si rifiuta di piegarsi alla propria eredità."





translate italian chooseexplanation_a807e804:


    marc "Porta con sé il peso del nome della sua famiglia, ma ogni giorno lotta per dimostrare di essere più di questo."





translate italian chooseexplanation_cf0cd827:


    marc "E sua figlia… la sua più grande debolezza e la sua più grande forza."





translate italian chooseexplanation_64a40d1a:


    marc "Incarna ogni donna che lotta per fare tutto: madre, concorrente, leader."





translate italian chooseexplanation_8d5ca34a:


    marc "Mentre il mondo guarda e giudica."





translate italian chooseexplanation_7b57f102:


    d "E Ruby? Perché fa parte di tutto questo?"





translate italian chooseexplanation_28231b1f:


    marc "Ruby è puro caos e fascino."





translate italian chooseexplanation_4821a228:


    marc "Intelligente, avventuroso, sempre alla ricerca della prossima emozione senza paura."





translate italian chooseexplanation_44c3d1e8:


    marc "Lei è la scintilla luminosa in un mondo di ombre, l'avventuriera innocente che non si rende nemmeno conto del peso della storia che porta con sé."





translate italian chooseexplanation_1fa85134:


    marc "E a volte, [name] …sono proprio quelli che sembrano più spensierati a custodire i segreti più grandi."





translate italian chooseexplanation_bb64f688:


    marc "Quando le sue verità verranno a galla... il mondo starà a guardare."





translate italian chooseexplanation2_1c3079b9:


    d "E Julia?"





translate italian chooseexplanation2_ae2c4634:


    marc "Julia è quella dimenticata. L'outsider."





translate italian chooseexplanation2_0fb35fb3:


    marc "La ragazza a cui non è stato regalato nulla e che lotta per ogni centimetro che guadagna."





translate italian chooseexplanation2_6211ff91:


    marc "È la speranza degli ignorati, il simbolo dei lavoratori silenziosi che servono i potenti ma sognano di liberarsi."





translate italian chooseexplanation2_69202705:


    marc "Ma ricorda questo, [name]... a volte coloro che nascono dal nulla hanno radici più profonde di quanto pensino."





translate italian chooseexplanation2_859a3502:


    marc "E quando queste radici affiorano… possono scuotere le fondamenta stesse di questo mondo."





translate italian chooseexplanation2_3da51ed6:


    d "E i gemelli? Perché sono qui?"





translate italian chooseexplanation2_35059758:


    marc "Ah... Sofia ed Elisabeth. Due corpi, un legame, ma due destini completamente diversi."





translate italian chooseexplanation2_97175f08:


    marc "Sofia... è come un uccello che scopre il cielo. Spensierata, piena di curiosità, insegue ogni orizzonte senza paura."





translate italian chooseexplanation2_dcf6707e:


    marc "Vive per il brivido della libertà, incurante del peso delle conseguenze."





translate italian chooseexplanation2_e8c3c973:


    marc "Lei è il volto dell'innocenza e della meraviglia... e la gente non può fare a meno di seguirla ovunque voli."





translate italian chooseexplanation2_cba1f8fa:


    marc "Elisabeth è l'opposto. Calcolatrice. Introspettiva. Non vaga senza meta, studia, pianifica e aspetta il momento perfetto per colpire."





translate italian chooseexplanation2_c2bdea88:


    marc "Il suo potere è nascosto dietro un sorriso, una leonessa in guanti di velluto. Non insegue la preda... si assicura che la preda venga da lei."





translate italian chooseexplanation2_a856700f:


    marc "Insieme, costringono il mondo a porsi la domanda più antica di tutte: insegui la libertà... o rivendichi il potere?"





translate italian chooseexplanation2_bc44d1ad:


    d "E Kira?"





translate italian chooseexplanation2_d6d6e0c1:


    marc "Kira non finge. Non si nasconde dietro l'innocenza o la moderazione."





translate italian chooseexplanation2_089cab24:


    marc "Sa esattamente chi è e di cosa è capace."





translate italian chooseexplanation2_a8b7567f:


    marc "Dove gli altri esitano, lei agisce. Dove gli altri seguono le regole, lei le riscrive."





translate italian chooseexplanation2_8ca29b9f:


    marc "Lei è il potere nella sua forma più pura."





translate italian chooseexplanation2_4d999085:


    marc "Non ereditato, non donato... RICHIEDUTO per pura volontà."





translate italian chooseexplanation2_bd8c6903:


    marc "Alcuni la ammirano. Altri la temono. Ma nessuno la ignora."





translate italian chooseexplanation2_ee9574b3:


    marc "Quando Kira entra nella stanza, tutti sanno... che il gioco è già iniziato."





translate italian chooseexplanation2_f16412bc:


    d "Basta... non voglio più sentire queste cose."





translate italian chooseexplanation2_01dfbcae:


    marc "Che tu voglia sentirlo o no non cambia la realtà, [name]."





translate italian chooseexplanation2_5f87c28e:


    marc "Fai già parte dello spettacolo. L'unica domanda che rimane è... COME lo giocherai?"





translate italian endexplanation_abf69470:


    marc "Un'ultima cosa, [name]."





translate italian endexplanation_b846e833:


    marc "La differenza tra un giocatore… e un pezzo sulla scacchiera…"





translate italian endexplanation_fa02ec0d:


    marc "È sapere quando vieni spostato... e quando è il tuo turno di fare la tua mossa."





translate italian endexplanation_a29e294e:


    marc "La maggior parte delle persone trascorre l'intera vita senza mai rendersi conto di quale sia la propria identità."





translate italian endexplanation_a3d9b648:


    marc "Non commettere lo stesso errore."





translate italian endexplanation_91760533:


    dpense "Lasciai quel posto con più domande che risposte... ma una cosa era certa."





translate italian endexplanation_e182c802:


    dpense "Ormai non c'era più niente di tutto questo che fosse un gioco."





translate italian endexplanation_d92e8b06:


    dpense "E in qualche modo... stavo già giocando."





translate italian endexplanation_bc0637c8:


    dpense "Ah? Una chiamata da Julia?"





translate italian endexplanation_139a594e:


    d "Julia? Stai bene?"





translate italian endexplanation_638653d2:


    julia "[name]..."





translate italian endexplanation_3e7f2b81:


    julia "È mia madre..."





translate italian endexplanation_52ef2f00:


    julia "Suo..."





translate italian endexplanation_f234fa5f:


    julia "È finita..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
