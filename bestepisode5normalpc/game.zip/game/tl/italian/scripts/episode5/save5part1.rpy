



translate italian save5part1_285f8ea7:


    "Per favore, salva la partita qui..."





translate italian save5part1_f029d6e4:


    "Le mie più sentite condoglianze."





translate italian save5part1_c3393239:


    orushi "Visti i recenti eventi, credo che sia giunto il momento della resa dei conti!"





translate italian save5part1_fcba8ba6:


    mad "Entrerò nella torre di Orushi e scoprirò cosa sta succedendo!!!"





translate italian save5part1_80081324:


    orushi "Il primo scontro sarà [name]..."





translate italian save5part1_c1c27e01:


    orushi "contro Grace!"



translate italian strings:


    old "To all the beloved mothers in this world"
    new "A tutte le amate mamme di questo mondo"


    old "Cherish them while they're still there"
    new "Apprezzali finché sono ancora lì"


    old "To Mom, 1963-2025"
    new "Alla mamma, 1963-2025"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
