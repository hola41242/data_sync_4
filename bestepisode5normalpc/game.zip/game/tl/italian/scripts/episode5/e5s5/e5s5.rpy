



translate italian e5s5_dc2c3852:


    dpense "Ruby sta ancora dormendo..."


translate italian e5s5_1d84e809:


    dpense "Sembra serena. Come se tutto il caos si fosse dissolto durante la notte."


translate italian e5s5_6be8f3b2:


    dpense "La sua coperta scivolò..."


translate italian e5s5_eb32bf38:


    dpense "Il suo seno è scoperto, appena coperto dal bordo della camicia da notte."


translate italian e5s5_557bff10:


    dpense "Solo il suono del suo respiro, dolce e caldo."


translate italian e5s5_abd3a128:


    dpense "Allungo la mano e le sistemo delicatamente l'abito."


translate italian e5s5_86c38cc5:


    dpense "Si muove un po', ma non si sveglia."


translate italian e5s5_110eafbd:


    dpense "Merita quella dignità. Quel conforto."


translate italian e5s5_428112c6:


    dpense "Non sarò un'altra fonte di pressione nella sua vita."


translate italian e5s5_dc44a896:


    dpense "Ho lasciato che fosse così."


translate italian e5s5_de426a87:


    dpense "È bella così... ma più di questo, si fida di me."


translate italian e5s5_644ff621:


    dpense "E questo significa qualcosa."


translate italian e5s5_fe6609cf:


    dpense "Questo momento è suo."


translate italian e5s5_075b8981:


    dpense "È ora di muoversi."


translate italian e5s5_01e40ea8:


    dpense "Già buongiorno..."


translate italian e5s5_3b9c765c:


    dpense "È difficile credere che tutto ciò che è successo ieri sia reale."


translate italian e5s5_c5afb76f:


    dpense "Marc, Julia, Ruby... tutto mi gira in testa."


translate italian e5s5_f432cdb3:


    dpense "Un messaggio da Sofia?"


translate italian e5s5_99adca09:


    dpense "Vediamo cosa aveva in mente Charlotte..."


translate italian e5s5_b6e0b95a:


    dpense "Vediamo che tipo di \"massaggio di recupero\" mi ha prenotato Gabriella..."


translate italian e5s5_6d68e0ba:


    dpense "Blue mi aspetta al centro commerciale..."


translate italian e5s5_be915c33:


    dpense "Credo di avere la mattinata tutta per me."


translate italian e5s5_massage_chagaby_2001ee16:


    ji "Ah, devi essere [name] Benvenuti. Charlotte ha detto che sareste venuti. Stanza 2. Ecco il vostro asciugamano. Sono dentro."


translate italian e5s5_massage_chagaby_d367964b:


    dpense "Stanza 2...? 'Loro'...? Aveva davvero in mente qualcosa. Devo cambiarmi prima di entrare..."


translate italian e5s5_massage_chagaby_c448096f:


    dpense "Okay... Gabriella è già sul tavolo."


translate italian e5s5_massage_chagaby_8d3bb645:


    dpense "E anche Charlotte..."


translate italian e5s5_massage_chagaby_6c70e222:


    dpense "Mi fissa dritto negli occhi... e mi dice di non parlare."


translate italian e5s5_massage_chagaby_df24d594:


    gaby "Mmm... finalmente. La schiena mi sta uccidendo."


translate italian e5s5_massage_chagaby_b48a6ef5:


    gaby "Questo posto si riempie sempre in fretta, ma Charlotte si è assicurata che arrivassimo presto."


translate italian e5s5_massage_chagaby_85d25137:


    cha "Certo. Mi occupo di ciò che conta."


translate italian e5s5_massage_chagaby_e8889756:


    dpense "Aspetta... vuole che la massaggi?"


translate italian e5s5_massage_chagaby_edf9bd97:


    dpense "Ha il viso sepolto in quel tavolo... non ha idea che sono io."


translate italian e5s5_massage_chagaby_7289d39e:


    cha "Sii gentile e aiutala con le spalle, vuoi?"


translate italian e5s5_massage_chagaby_5e8e88eb:


    dpense "Aspetta... Cosa sta facendo Charlotte?"


translate italian e5s5_massage_chagaby_d540bdf7:


    dpense "Impossibile. Non lo farebbe..."


translate italian e5s5_massage_chagaby_fe6190ab:


    gaby "Oh... Quella pressione è proprio quella giusta..."


translate italian e5s5_massage_chagaby_29d92251:


    gaby "Più forte del solito oggi. Hanno cambiato di nuovo personale?"


translate italian e5s5_massage_chagaby_cb31e78a:


    dpense "Non riesco a reagire. Continua a massaggiare."


translate italian e5s5_massage_chagaby_da86f35d:


    dpense "Che..."


translate italian e5s5_massage_chagaby_0ae9bcd0:


    ""


translate italian e5s5_massage_chagaby_ce559f45:


    dpense "Non ha limiti..."


translate italian e5s5_massage_chagaby_dcaadb50:


    dpense "O forse per lei è solo un gioco?"


translate italian e5s5_massage_chagaby_d29b7782:


    dpense "E Gabriella..."


translate italian e5s5_massage_chagaby_7aa7436c:


    gaby "Proprio lì... mmh... quel nodo mi ha dato fastidio per tutta la settimana."


translate italian e5s5_massage_chagaby_de315c09:


    cha "Sta colpendo tutti i punti giusti, non è vero?"


translate italian e5s5_massage_chagaby_3d4d34f3:


    gaby "Ugh... sì. Non so cosa stia facendo, ma funziona."


translate italian e5s5_massage_chagaby_8e7fda38:


    gaby "Chiudo gli occhi e immagino chi potrebbe essere..."


translate italian e5s5_massage_chagaby_d5b8322d:


    cha "Ci vuole un tipo speciale di intuizione... alcune persone sanno semplicemente dove premere."


translate italian e5s5_massage_chagaby_73039866:


    cha "Ma sono sicuro che puoi immaginare il tuo studente!"


translate italian e5s5_massage_chagaby_f68665a9:


    gaby "Carlotta!"


translate italian e5s5_massage_chagaby_f1576f4c:


    dpense "Questa è una follia..."


translate italian e5s5_massage_chagaby_d45a79ad:


    dpense "Lei parla mentre Charlotte..."


translate italian e5s5_massage_chagaby_37cd8752:


    gaby "Più in profondità, solo un po'... sì... è così..."


translate italian e5s5_massage_chagaby_cba41796:


    gaby "Potrei sciogliermi se continui così."


translate italian e5s5_massage_chagaby_9d18feb0:


    cha "Non tentarlo, Gaby."


translate italian e5s5_massage_chagaby_fd51d7eb:


    gaby "Tentare? Sto solo dicendo quello che provo!"


translate italian e5s5_massage_chagaby_b9a49a1a:


    dpense "Non ne ha idea... e Charlotte non si ferma."


translate italian e5s5_massage_chagaby_02bed8bf:


    gaby "Davvero, ne ho bisogno ogni settimana."


translate italian e5s5_massage_chagaby_e8582554:


    gaby "Chiunque sia, merita un aumento."


translate italian e5s5_massage_chagaby_8cd9e86b:


    dpense "Rimani concentrato. Non..."


translate italian e5s5_massage_chagaby_dfc4dc6f:


    cha "Alleviare la pressione."


translate italian e5s5_massage_chagaby_87872403:


    d "Sta parlando con me o...?"


translate italian e5s5_massage_chagaby_3b63fb1d:


    gaby "Ahhh..."


translate italian e5s5_massage_chagaby_41603c23:


    gaby "[name]..."


translate italian e5s5_massage_chagaby_c967607c:


    dpense "Che cosa???" with hpunch


translate italian e5s5_massage_chagaby_e6a3a3b1:


    dpense "Ha appena detto il mio nome?"


translate italian e5s5_massage_chagaby_6cb9f1a5:


    dpense "Non posso..."


translate italian e5s5_massage_chagaby_ba532364:


    dpense "Cazzooooooo!"


translate italian e5s5_massage_chagaby_f9427bc8:


    cha "Mmm. Ora sono pronto per la giornata."


translate italian e5s5_massage_chagaby_3b6714f3:


    dpense "Mi ha prosciugato..."


translate italian e5s5_massage_chagaby_251f5469:


    gaby "Hai già finito?"


translate italian e5s5_massage_chagaby_1193d7cb:


    cha "Sì. E sembra che lo sia anche tu, Gaby."


translate italian e5s5_massage_chagaby_ef7acd06:


    gaby "Ugh... Potrei restare così per sempre."


translate italian e5s5_massage_chagaby_21b9efef:


    dpense "Lei ancora non lo sa..."


translate italian e5s5_massage_chagaby_75028c91:


    cha "Dai, [name] Lascia che la signora si goda il suo ultimo splendore."


translate italian e5s5_massage_chagaby_09be68e5:


    cha "Hai fatto bene."


translate italian e5s5_massage_chagaby_030147cd:


    d "Anche tu."


translate italian e5s5_massage_chagaby_b0f13d20:


    dpense "Era... tanto."


translate italian e5s5_massage_chagaby_f35bbe50:


    dpense "Charlotte ha pianificato ogni secondo di tutto questo. E Gabriella..."


translate italian e5s5_massage_chagaby_fef6075d:


    dpense "Non ne ha ancora la minima idea."


translate italian e5s5_massage_chagaby_40c298eb:


    dpense "Ma cos'era quello?"


translate italian e5s5_massage_gaby_main_926d4c1f:


    ji "Oh, sei già tornato? Sei stato veloce. La stanza 3 è di nuovo pronta per te."


translate italian e5s5_massage_gaby_main_2c096fcd:


    dpense "Si ricorda di me da prima... Meno male che non fa domande."


translate italian e5s5_massage_gaby_main_76e2a70e:


    "Receptionist" "Ciao! Devi essere [name], giusto? La tua sessione è pronta. Stanza 3, per favore."


translate italian e5s5_massage_gaby_main_6784b11e:


    dpense "Oh, è accogliente."


translate italian e5s5_massage_gaby_main_99f02fbd:


    dpense "Non male... Sono curioso di sapere chi mi massaggerà..."


translate italian e5s5_massage_gaby_main_e13226b5:


    gaby "Ecco fatto. Giusto in tempo."


translate italian e5s5_massage_gaby_main_9d4ca66f:


    dpense "Hmm?"


translate italian e5s5_massage_gaby_main_767727ac:


    d "Sinceramente non mi aspettavo che fossi qui."


translate italian e5s5_massage_gaby_main_fbbd8a7d:


    gaby "Hai una partita importante in arrivo. Ti voglio in ottima forma."


translate italian e5s5_massage_gaby_main_a5e4cd0a:


    d "Abbastanza giusto."


translate italian e5s5_massage_gaby_main_438e2467:


    dpense "È così calma... come se fosse solo un altro giorno di lavoro."


translate italian e5s5_massage_gaby_main_cf33235f:


    gaby "Sdraiati sulla schiena. Ci concentreremo sulle gambe."


translate italian e5s5_massage_gaby_main_a0543308:


    dpense "È pazzesco... Non aveva idea che fossi io prima."


translate italian e5s5_massage_gaby_main_1d98e1ca:


    dpense "E ora mi massaggerà come se niente fosse."


translate italian e5s5_massage_gaby_main_915b1cd1:


    gaby "Dimmi se la pressione è troppa."


translate italian e5s5_massage_gaby_main_cf335fae:


    d "È perfetto. Sodo, ma liscio."


translate italian e5s5_massage_gaby_main_235045f3:


    dpense "Le sue mani sono sicure. Precise. Sa esattamente cosa sta facendo."


translate italian e5s5_massage_gaby_main_d39bef52:


    gaby "I tuoi quadricipiti sono contratti. Sento molta tensione accumulata."


translate italian e5s5_massage_gaby_main_44ff6795:


    d "Ha senso. Ultimamente mi sono impegnato molto... e ho pensato molto."


translate italian e5s5_massage_gaby_main_f63e3072:


    gaby "Pensato?"


translate italian e5s5_massage_gaby_main_5b65b87f:


    d "Sulla partita. Sul restare concentrati."


translate italian e5s5_massage_gaby_main_4427b431:


    gaby "Mantieni questa mentalità. Devi essere acuto."


translate italian e5s5_massage_gaby_main_7c06ce06:


    dpense "Cerca di mantenere un tono professionale, ma avverte la tensione."


translate italian e5s5_massage_gaby_main_58db53c0:


    gaby "Mi sposto sulle cosce. Fammi sapere se diventa troppo sensibile."


translate italian e5s5_massage_gaby_main_b4033f39:


    d "Vuoi dire fisicamente o emotivamente?"


translate italian e5s5_massage_gaby_main_c3a0d04f:


    gaby "Fisicamente. Non complichiamoci le cose."


translate italian e5s5_massage_gaby_main_4ab0dab5:


    dpense "L'ho presa. Ora sta esitando."


translate italian e5s5_massage_gaby_main_9737a6f6:


    gaby "Hai molto caldo. I muscoli reagiscono bene."


translate italian e5s5_massage_gaby_main_ccbf27d4:


    d "Forse è solo il tuo tocco."


translate italian e5s5_massage_gaby_main_4e6d2b64:


    gaby "...Manteniamo un tono professionale, okay?"


translate italian e5s5_massage_gaby_main_de3c485f:


    d "Certo. Lo dico solo... hai delle dita magiche."


translate italian e5s5_massage_gaby_main_08df85ac:


    dpense "Ora ha le guance rosse. È agitata."


translate italian e5s5_massage_gaby_main_cd72dc97:


    gaby "Poi i fianchi. Cerca di respirare e rilassarti."


translate italian e5s5_massage_gaby_main_12e0eed0:


    d "È un po' difficile rilassarsi con te così vicino."


translate italian e5s5_massage_gaby_main_487ff192:


    gaby "Preferiresti qualcun altro?"


translate italian e5s5_massage_gaby_main_aa04a66e:


    d "Nemmeno lontanamente."


translate italian e5s5_massage_gaby_main_d1a462be:


    gaby "... [name]Non si tratta più solo di recupero."


translate italian e5s5_massage_gaby_main_337b6dff:


    d "Forse no. Ma mi sembra giusto."


translate italian e5s5_massage_gaby_main_cfd29dd2:


    gaby "Sono il tuo allenatore. Sono più grande. Questo non dovrebbe succedere."


translate italian e5s5_massage_gaby_main_50b86890:


    d "Allora perché mi tieni ancora le mani addosso?"


translate italian e5s5_massage_gaby_main_f3022391:


    gaby "IO..."


translate italian e5s5_massage_gaby_main_d72157de:


    d "Dimmi di fermarmi. Lo farò."


translate italian e5s5_massage_gaby_main_afb8b1fb:


    gaby "...NO."


translate italian e5s5_massage_gaby_main_7d997125:


    dpense "La sua guardia sta crollando. Ancora un po'..."


translate italian e5s5_massage_gaby_main_f857082d:


    dpense "La sua voce è appena un sussurro. Ma le sue mani... non si sono allontanate."


translate italian e5s5_massage_gaby_main_48984802:


    gaby "Non dovrei farlo..."


translate italian e5s5_massage_gaby_main_fe5a5f9b:


    d "Allora dimmi di toglierti le mani di dosso."


translate italian e5s5_massage_gaby_main_48876117:


    gaby "..."


translate italian e5s5_massage_gaby_main_1c29f5d0:


    dpense "Non dice una parola."


translate italian e5s5_massage_gaby_main_cd459cec:


    d "Anche tu sei tesa, lo sai. Tutta questa pressione... non è solo sul campo."


translate italian e5s5_massage_gaby_main_36fd47ae:


    gaby "Non è la stessa cosa."


translate italian e5s5_massage_gaby_main_8484350c:


    d "Non è vero? Sei sempre generosa. Hai sempre il controllo. Forse meriti di lasciar andare per una volta."


translate italian e5s5_massage_gaby_main_96dbd6e4:


    dpense "Per un attimo trattenne il respiro. Lo sentiva."


translate italian e5s5_massage_gaby_main_74527e74:


    gaby "Sei il mio studente..."


translate italian e5s5_massage_gaby_main_d074f7df:


    d "E tu sei una donna bellissima, Gabriella, che mi tocca come se volesse dimenticare le regole anche solo per un attimo."


translate italian e5s5_massage_gaby_main_885010d3:


    gaby "...Un attimo."


translate italian e5s5_massage_gaby_main_aac0affb:


    dpense "Sta tremando. Non per paura. Per l'attesa."


translate italian e5s5_massage_gaby_main_c70dd2d4:


    gaby "Ora mi concentrerò sulla parte interna delle cosce."


translate italian e5s5_massage_gaby_main_fea3af09:


    dpense "La sua voce è bassa. Controllata. Ma le sue dita sono più lente... più insistenti."


translate italian e5s5_massage_gaby_main_116b0692:


    d "Mmh... Lascia che ti aiuti..."


translate italian e5s5_massage_gaby_main_ffaad131:


    gaby "[name]!"


translate italian e5s5_massage_gaby_main_1a3acc53:


    d "Non preoccuparti, resterò professionale!"


translate italian e5s5_massage_gaby_main_d3ba05a9:


    gaby "Ma..."


translate italian e5s5_massage_gaby_main_226c70e9:


    dpense "Sta cercando di riprendere il controllo."


translate italian e5s5_massage_gaby_main_b8980a8e:


    dpense "Ma le sue dita tracciano dei disegni... troppo delicate per essere professionali."


translate italian e5s5_massage_gaby_main_77c76308:


    d "Lasciami aiutare... stai già facendo così tanto."


translate italian e5s5_massage_gaby_main_20b6d50e:


    gaby "[name]…"


translate italian e5s5_massage_gaby_main_d7b29708:


    d "Shh. Sentilo e basta."


translate italian e5s5_massage_gaby_main_913875c9:


    dpense "Il suo corpo si irrigidì. Ma non si mosse."


translate italian e5s5_massage_gaby_main_0ae9bcd0:


    ""


translate italian e5s5_massage_gaby_main_20313501:


    gaby "Ah..."


translate italian e5s5_massage_gaby_main_862affd8:


    gaby "Cavolo..."


translate italian e5s5_massage_gaby_main_f7c934e2:


    gaby "Questo non è..."


translate italian e5s5_massage_gaby_main_746cb4ce:


    gaby "Perché sono venuto qui…"


translate italian e5s5_massage_gaby_main_89fadf36:


    gaby "Perché…"


translate italian e5s5_massage_gaby_main_16534fb1:


    gaby "Non riesco a fermarmi."


translate italian e5s5_massage_gaby_main_4b1beaff:


    dpense "Ormai non evita più nulla."


translate italian e5s5_massage_gaby_main_3bb11019:


    d "Vedi? Sei incredibile in questo. Mi fai sciogliere al solo tocco."


translate italian e5s5_massage_gaby_main_da48d11f:


    gaby "Stai rendendo impossibile rimanere professionali..."


translate italian e5s5_massage_gaby_main_a400c057:


    d "Forse non voglio che tu lo faccia."


translate italian e5s5_massage_gaby_main_863b5583:


    gaby "...Se qualcuno lo scoprisse..."


translate italian e5s5_massage_gaby_main_c5c828de:


    d "Nessuno lo farà. Siamo solo noi. Solo in questo momento."


translate italian e5s5_massage_gaby_main_011f8b53:


    gaby "Poi..."


translate italian e5s5_massage_gaby_main_16366704:


    gaby "Non fermarti..."


translate italian e5s5_massage_gaby_main_4040ad56:


    dpense "La sua mano si muove lentamente su e giù... Dio, è una sensazione troppo bella."


translate italian e5s5_massage_gaby_main_127051e6:


    d "Sei incredibile... così dolce..."


translate italian e5s5_massage_gaby_main_84fb6e85:


    gaby "E tu sei... così difficile... è pazzesco..."


translate italian e5s5_massage_gaby_main_bc45f22f:


    dpense "Le premo le dita dentro, lentamente. Lei inarca la schiena, ansimando."


translate italian e5s5_massage_gaby_main_2819d3b3:


    gaby "[name]... questo è... ah..."


translate italian e5s5_massage_gaby_main_280253c4:


    dpense "La sua presa si stringe... mi sta accarezzando e ora..."


translate italian e5s5_massage_gaby_main_b4a12fa6:


    d "...Oh merda..."


translate italian e5s5_massage_gaby_main_49787490:


    dpense "L'altra mano mi accarezza delicatamente i testicoli."


translate italian e5s5_massage_gaby_main_142e2c27:


    d "Gabriella…"


translate italian e5s5_massage_gaby_main_6b6a3cd0:


    gaby "Ti piace? Ti piace quando gioco con te in questo modo?"


translate italian e5s5_massage_gaby_main_823df15c:


    d "Non posso... Voglio dire... Sì. Mi piace. Non fermarti..."


translate italian e5s5_massage_gaby_main_0f6591ea:


    dpense "Il suo corpo si scioglie contro il mio. I suoi fianchi si muovono sotto i miei colpi."


translate italian e5s5_massage_gaby_main_72fa43fa:


    gaby "Mi stai facendo impazzire... Non riesco a pensare... Voglio solo..."


translate italian e5s5_massage_gaby_main_182ffcf6:


    dpense "Lei si sta perdendo. E io riesco a malapena a trattenerla."


translate italian e5s5_massage_gaby_main_e7ebce38:


    d "Dillo. Cosa vuoi?"


translate italian e5s5_massage_gaby_main_2129045c:


    gaby "...Altro... Voi. Tutti voi... semplicemente..."


translate italian e5s5_massage_gaby_main_de6ec826:


    dpense "Si sta strofinando contro la mia mano, gemendo il mio nome..."


translate italian e5s5_massage_gaby_main_5fc8c6f9:


    gaby "[name]...non fermarti, non osare fermarti..."


translate italian e5s5_massage_gaby_main_7e736253:


    dpense "La sua voce si spezza... è vicina. E lo sono anch'io."


translate italian e5s5_massage_gaby_main_0d706a94:


    d "Insieme... ok?"


translate italian e5s5_massage_gaby_main_db99af1b:


    gaby "Sì... sì..."


translate italian e5s5_massage_gaby_main_755003ab:


    d "Gabriella!"


translate italian e5s5_massage_gaby_main_811a0b65:


    gaby "Oh mio dio... oh mio..."


translate italian e5s5_massage_gaby_main_0b2df493:


    gaby "...Cosa abbiamo appena fatto?"


translate italian e5s5_massage_gaby_main_6c647e79:


    d "Ci lasciamo andare. Solo per un momento."


translate italian e5s5_massage_gaby_main_f49451f4:


    gaby "Io... non posso credere che sia successo. Sono il tuo allenatore. Dovrei guidarti, non..."


translate italian e5s5_massage_gaby_main_f877753b:


    d "Non hai fatto niente di sbagliato. Eri solo... umano."


translate italian e5s5_massage_gaby_main_9383a269:


    gaby "Ciò non può accadere di nuovo."


translate italian e5s5_massage_gaby_main_1523fe20:


    d "..."


translate italian e5s5_massage_gaby_main_cd81800a:


    gaby "Devo andare."


translate italian e5s5_massage_gaby_main_7de26861:


    dpense "Se n'è andata. Proprio così."


translate italian e5s5_massage_gaby_main_c1d4a101:


    dpense "Non so cosa le passa per la testa, ma so esattamente cosa passa per la mia."


translate italian e5s5_massage_gaby_main_1529b40c:


    dpense "Quello è stato... indimenticabile."


translate italian e5s5_massage_gaby_main_c47791a5:


    dpense "Ma cosa significa esattamente, adesso?"


translate italian e5s5_massage_gaby_main_25815f44:


    dpense "Il blu mi aspetta..."


translate italian e5s5_massage_gaby_main_be915c33:


    dpense "Credo di avere la mattinata tutta per me."


translate italian e5s5_massage_gaby_main_50b86890_1:


    d "Allora perché mi tieni ancora le mani addosso?"


translate italian e5s5_massage_gaby_main_0ae9bcd0_1:


    ""


translate italian e5s5_massage_gaby_main_ffaad131_1:


    gaby "[name]!"


translate italian e5s5_blue_75debac5:


    sofia "Ei, tu!"


translate italian e5s5_blue_be3f1544:


    d "Sofia."


translate italian e5s5_blue_620fb770:


    d "Oggi sei splendida."


translate italian e5s5_blue_fc64dba5:


    sofia "Anche tu. Hai dormito bene?"


translate italian e5s5_blue_1834f689:


    d "Diciamo che ho avuto notti peggiori."


translate italian e5s5_blue_bcbec8d3:


    sofia "Perfetto. Ho bisogno del tuo occhio maschile per aiutarmi a scegliere una borsa."


translate italian e5s5_blue_7ec6a092:


    sofia "E forse... un po' di più se ti comporti bene."


translate italian e5s5_blue_ae000f54:


    d "Corruzione di prima mattina?"


translate italian e5s5_blue_fb33e447:


    sofia "Chiamalo fascino, signor Consulente di Moda."


translate italian e5s5_blue_d5388720:


    d "A proposito, di recente ho incontrato una persona. Si chiama Marc."


translate italian e5s5_blue_4252ada9:


    sofia "Marc? Non mi dice niente."


translate italian e5s5_blue_947a94bc:


    d "Sembrava sapere molto sui MIGLIORI... e su di noi."


translate italian e5s5_blue_91707ffd:


    sofia "Aspetta, cosa? Com'è possibile?"


translate italian e5s5_blue_c39a3e10:


    d "Non ne ho idea. Ha detto cose strane, come se avesse accesso a tutto. E mi ha avvertito."


translate italian e5s5_blue_70da401d:


    sofia "Ok, adesso mi sento in imbarazzo."


translate italian e5s5_blue_945cec7b:


    sofia "Pensi che sia una specie di spia? Un ex concorrente?"


translate italian e5s5_blue_b1595f94:


    d "Non lo so. Ma era troppo calmo. Troppo sicuro di sé."


translate italian e5s5_blue_66fe77eb:


    d "Volevo solo dirtelo. Per sicurezza."


translate italian e5s5_blue_4198957c:


    sofia "Grazie... Mi piace che tu mi dica queste cose. Ti prometto che starò attenta."


translate italian e5s5_blue_b1c1af7b:


    sofia "Forse chiederò a mia sorella. Se c'è qualcuno che può dirmi qualcosa su di lui, è lei."


translate italian e5s5_blue_725f748a:


    sofia "Lei può farlo per noi."


translate italian e5s5_blue_cf3e6cde:


    d "Noi... Hai mai pensato a cosa significa veramente?"


translate italian e5s5_blue_9ae6e49d:


    d "Tu ed io. Nel mezzo di questa competizione. Le altre ragazze, la posta in gioco... tutti che ci guardano."


translate italian e5s5_blue_e94e1e53:


    sofia "Penso soprattutto che tu mi piaccia davvero."


translate italian e5s5_blue_acf6b488:


    sofia "E che è troppo speciale per tenerlo nascosto solo per via di un gioco."


translate italian e5s5_blue_8b47f51d:


    d "Ma non è solo un gioco. Alcuni di loro farebbero qualsiasi cosa per vincere. Se rendiamo pubblici i nostri affari, diventiamo un bersaglio."


translate italian e5s5_blue_37ec2028:


    sofia "Forse. Ma se abbiamo troppa paura di amare, allora abbiamo già perso, non è vero?"


translate italian e5s5_blue_c82f9e2f:


    d "Io... non voglio che tu ti faccia male a causa mia. O che loro usino questa cosa contro di noi."


translate italian e5s5_blue_dc8acdeb:


    sofia "Pensi troppo, [name]. Ma..."


translate italian e5s5_blue_29b26585:


    sofia "Questo è uno dei motivi per cui mi sento al sicuro con te."


translate italian e5s5_blue_ebf8e1e8:


    d "Vuoi farti un selfie? Solo per noi."


translate italian e5s5_blue_4c765146:


    sofia "Mi piacerebbe molto."


translate italian e5s5_blue_5657a5b4:


    d "Ecco. Uno scatto perfetto di una coppia potente."


translate italian e5s5_blue_2bc5878d:


    d "Pensi che dovrei pubblicarlo? Renderlo... in un certo senso ufficiale?"


translate italian e5s5_blue_274949db:


    sofia "Hmm... intendi tipo, 'Ehi mondo, è mia'?"


translate italian e5s5_blue_7eef06a5:


    d "Voglio dire... siamo pronti per questo? Per mostrarlo a tutti, proprio quando la gente osserva ogni nostra mossa?"


translate italian e5s5_blue_dc3b82d2:


    sofia "Io dico che dovremmo smettere di nasconderci e iniziare a vivere. Se qualcosa sembra reale, lascialo essere reale."


translate italian e5s5_blue_75d187ba:


    d "Fatto. Potrebbe essere un piccolo passo, ma significa molto."


translate italian e5s5_blue_aa655c08:


    sofia "Wow... okay. Ora è disponibile."


translate italian e5s5_blue_2141b0cb:


    sofia "Riceverai dei commenti invidiosi."


translate italian e5s5_blue_d2080394:


    d "Lasciateli fare. A me interessa solo un'opinione."


translate italian e5s5_blue_e6fba878:


    d "La Tua."


translate italian e5s5_blue_2f874638:


    sofia "Ammaliatore."


translate italian e5s5_blue_f483d2ca:


    d "No... non ancora. Per ora teniamolo solo per noi."


translate italian e5s5_blue_5baa0c26:


    sofia "Va bene. Finché è reale, per me è sufficiente."


translate italian e5s5_blue_e9989e88:


    sofia "Ma un giorno, sarà meglio che tu mostri al mondo cosa sai fare."


translate italian e5s5_blue_845b87d7:


    d "Affare fatto. Ma è meglio che TU mi faccia vedere cosa sai fare!"


translate italian e5s5_blue_fc056c41:


    sofia "Intendi quel sedere???"


translate italian e5s5_blue_801518fe:


    d "Esattamente!"


translate italian e5s5_blue_da65a7e3:


    sofia "Ahah!"


translate italian e5s5_blue_2907598c:


    d "Teniamolo tra noi. Mi piace avere questo momento solo per noi."


translate italian e5s5_blue_233674e4:


    sofia "Anch'io. Rende tutto ancora più speciale."


translate italian e5s5_blue_64417f8f:


    d "Hmm? Un messaggio da Grace."


translate italian e5s5_blue_a2dd00bb:


    sofia "E uno da mia sorella."


translate italian e5s5_blue_a9a66518:


    d "È ora di andare."


translate italian e5s5_blue_a6f4c0d7:


    sofia "Immagino che compreremo quella borsa un'altra volta."


translate italian e5s5_blue_33e6da38:


    d "La prossima volta non lasceremo che nulla ci ostacoli."


translate italian e5s5_blue_7cd819e6:


    sofia "Affare fatto. Ora vai a vincere questa cosa."


translate italian e5s5_blue_a3289c70:


    d "Oh, vuoi vincere?"


translate italian e5s5_blue_f716865d:


    sofia "Io? No! Non mi interessa!"


translate italian e5s5_blue_fb9c731f:


    sofia "Ma ti aiuterò."


translate italian e5s5_blue_dd5d68f3:


    d "Eh?"


translate italian e5s5_blue_580c045a:


    sofia "Se potessi..."


translate italian e5s5_prep_match_64417f8f:


    d "Hmm? Un messaggio da Grace."


translate italian e5s5_prep_match_a9a66518:


    d "È ora di andare."





translate italian e5s5_dc2c3852:


    dpense "Ruby sta ancora dormendo..."





translate italian e5s5_1d84e809:


    dpense "Sembra serena. Come se tutto il caos si fosse dissolto durante la notte."





translate italian e5s5_6be8f3b2:


    dpense "La sua coperta scivolò..."





translate italian e5s5_eb32bf38:


    dpense "Il suo seno è scoperto, appena coperto dal bordo della camicia da notte."





translate italian e5s5_557bff10:


    dpense "Solo il suono del suo respiro, dolce e caldo."





translate italian e5s5_abd3a128:


    dpense "Allungo la mano e le sistemo delicatamente l'abito."





translate italian e5s5_86c38cc5:


    dpense "Si muove un po', ma non si sveglia."





translate italian e5s5_110eafbd:


    dpense "Merita quella dignità. Quel conforto."





translate italian e5s5_428112c6:


    dpense "Non sarò un'altra fonte di pressione nella sua vita."





translate italian e5s5_dc44a896:


    dpense "Ho lasciato che fosse così."





translate italian e5s5_de426a87:


    dpense "È bella così... ma più di questo, si fida di me."





translate italian e5s5_644ff621:


    dpense "E questo significa qualcosa."





translate italian e5s5_fe6609cf:


    dpense "Questo momento è suo."





translate italian e5s5_075b8981:


    dpense "È ora di muoversi."





translate italian e5s5_01e40ea8:


    dpense "Già buongiorno..."





translate italian e5s5_3b9c765c:


    dpense "È difficile credere che tutto ciò che è successo ieri sia reale."





translate italian e5s5_c5afb76f:


    dpense "Marc, Julia, Ruby... tutto mi gira in testa."





translate italian e5s5_f432cdb3:


    dpense "Un messaggio da Sofia?"





translate italian e5s5_99adca09:


    dpense "Vediamo cosa aveva in mente Charlotte..."





translate italian e5s5_b6e0b95a:


    dpense "Vediamo che tipo di \"massaggio di recupero\" mi ha prenotato Gabriella..."





translate italian e5s5_6d68e0ba:


    dpense "Blue mi aspetta al centro commerciale..."





translate italian e5s5_be915c33:


    dpense "Credo di avere la mattinata tutta per me."





translate italian e5s5_massage_chagaby_2001ee16:


    ji "Ah, devi essere [name] Benvenuti. Charlotte ha detto che sareste venuti. Stanza 2. Ecco il vostro asciugamano. Sono dentro."





translate italian e5s5_massage_chagaby_d367964b:


    dpense "Stanza 2...? 'Loro'...? Aveva davvero in mente qualcosa. Devo cambiarmi prima di entrare..."





translate italian e5s5_massage_chagaby_c448096f:


    dpense "Okay... Gabriella è già sul tavolo."





translate italian e5s5_massage_chagaby_8d3bb645:


    dpense "E anche Charlotte..."





translate italian e5s5_massage_chagaby_6c70e222:


    dpense "Mi fissa dritto negli occhi... e mi dice di non parlare."





translate italian e5s5_massage_chagaby_df24d594:


    gaby "Mmm... finalmente. La schiena mi sta uccidendo."





translate italian e5s5_massage_chagaby_b48a6ef5:


    gaby "Questo posto si riempie sempre in fretta, ma Charlotte si è assicurata che arrivassimo presto."





translate italian e5s5_massage_chagaby_85d25137:


    cha "Certo. Mi occupo di ciò che conta."





translate italian e5s5_massage_chagaby_e8889756:


    dpense "Aspetta... vuole che la massaggi?"





translate italian e5s5_massage_chagaby_edf9bd97:


    dpense "Ha il viso sepolto in quel tavolo... non ha idea che sono io."





translate italian e5s5_massage_chagaby_7289d39e:


    cha "Sii gentile e aiutala con le spalle, vuoi?"





translate italian e5s5_massage_chagaby_5e8e88eb:


    dpense "Aspetta... Cosa sta facendo Charlotte?"





translate italian e5s5_massage_chagaby_d540bdf7:


    dpense "Impossibile. Non lo farebbe..."





translate italian e5s5_massage_chagaby_fe6190ab:


    gaby "Oh... Quella pressione è proprio quella giusta..."





translate italian e5s5_massage_chagaby_29d92251:


    gaby "Più forte del solito oggi. Hanno cambiato di nuovo personale?"





translate italian e5s5_massage_chagaby_cb31e78a:


    dpense "Non riesco a reagire. Continua a massaggiare."





translate italian e5s5_massage_chagaby_da86f35d:


    dpense "Che..."





translate italian e5s5_massage_chagaby_0ae9bcd0:


    ""





translate italian e5s5_massage_chagaby_ce559f45:


    dpense "Non ha limiti..."





translate italian e5s5_massage_chagaby_dcaadb50:


    dpense "O forse per lei è solo un gioco?"





translate italian e5s5_massage_chagaby_d29b7782:


    dpense "E Gabriella..."





translate italian e5s5_massage_chagaby_7aa7436c:


    gaby "Proprio lì... mmh... quel nodo mi ha dato fastidio per tutta la settimana."





translate italian e5s5_massage_chagaby_de315c09:


    cha "Sta colpendo tutti i punti giusti, non è vero?"





translate italian e5s5_massage_chagaby_3d4d34f3:


    gaby "Ugh... sì. Non so cosa stia facendo, ma funziona."





translate italian e5s5_massage_chagaby_8e7fda38:


    gaby "Chiudo gli occhi e immagino chi potrebbe essere..."





translate italian e5s5_massage_chagaby_d5b8322d:


    cha "Ci vuole un tipo speciale di intuizione... alcune persone sanno semplicemente dove premere."





translate italian e5s5_massage_chagaby_73039866:


    cha "Ma sono sicuro che puoi immaginare il tuo studente!"





translate italian e5s5_massage_chagaby_f68665a9:


    gaby "Carlotta!"





translate italian e5s5_massage_chagaby_f1576f4c:


    dpense "Questa è una follia..."





translate italian e5s5_massage_chagaby_d45a79ad:


    dpense "Lei parla mentre Charlotte..."





translate italian e5s5_massage_chagaby_37cd8752:


    gaby "Più in profondità, solo un po'... sì... è così..."





translate italian e5s5_massage_chagaby_cba41796:


    gaby "Potrei sciogliermi se continui così."





translate italian e5s5_massage_chagaby_9d18feb0:


    cha "Non tentarlo, Gaby."





translate italian e5s5_massage_chagaby_fd51d7eb:


    gaby "Tentare? Sto solo dicendo quello che provo!"





translate italian e5s5_massage_chagaby_b9a49a1a:


    dpense "Non ne ha idea... e Charlotte non si ferma."





translate italian e5s5_massage_chagaby_02bed8bf:


    gaby "Davvero, ne ho bisogno ogni settimana."





translate italian e5s5_massage_chagaby_e8582554:


    gaby "Chiunque sia, merita un aumento."





translate italian e5s5_massage_chagaby_8cd9e86b:


    dpense "Rimani concentrato. Non..."





translate italian e5s5_massage_chagaby_dfc4dc6f:


    cha "Alleviare la pressione."





translate italian e5s5_massage_chagaby_87872403:


    d "Sta parlando con me o...?"





translate italian e5s5_massage_chagaby_3b63fb1d:


    gaby "Ahhh..."





translate italian e5s5_massage_chagaby_41603c23:


    gaby "[name]..."





translate italian e5s5_massage_chagaby_c967607c:


    dpense "Che cosa???" with hpunch





translate italian e5s5_massage_chagaby_e6a3a3b1:


    dpense "Ha appena detto il mio nome?"





translate italian e5s5_massage_chagaby_6cb9f1a5:


    dpense "Non posso..."





translate italian e5s5_massage_chagaby_ba532364:


    dpense "Cazzooooooo!"





translate italian e5s5_massage_chagaby_f9427bc8:


    cha "Mmm. Ora sono pronto per la giornata."





translate italian e5s5_massage_chagaby_3b6714f3:


    dpense "Mi ha prosciugato..."





translate italian e5s5_massage_chagaby_251f5469:


    gaby "Hai già finito?"





translate italian e5s5_massage_chagaby_1193d7cb:


    cha "Sì. E sembra che lo sia anche tu, Gaby."





translate italian e5s5_massage_chagaby_ef7acd06:


    gaby "Ugh... Potrei restare così per sempre."





translate italian e5s5_massage_chagaby_21b9efef:


    dpense "Lei ancora non lo sa..."





translate italian e5s5_massage_chagaby_75028c91:


    cha "Dai, [name] Lascia che la signora si goda il suo ultimo splendore."





translate italian e5s5_massage_chagaby_09be68e5:


    cha "Hai fatto bene."





translate italian e5s5_massage_chagaby_030147cd:


    d "Anche tu."





translate italian e5s5_massage_chagaby_b0f13d20:


    dpense "Era... tanto."





translate italian e5s5_massage_chagaby_f35bbe50:


    dpense "Charlotte ha pianificato ogni secondo di tutto questo. E Gabriella..."





translate italian e5s5_massage_chagaby_fef6075d:


    dpense "Non ne ha ancora la minima idea."





translate italian e5s5_massage_chagaby_40c298eb:


    dpense "Ma cos'era quello?"





translate italian e5s5_massage_gaby_main_926d4c1f:


    ji "Oh, sei già tornato? Sei stato veloce. La stanza 3 è di nuovo pronta per te."





translate italian e5s5_massage_gaby_main_2c096fcd:


    dpense "Si ricorda di me da prima... Meno male che non fa domande."





translate italian e5s5_massage_gaby_main_76e2a70e:


    "Receptionist" "Ciao! Devi essere [name], giusto? La tua sessione è pronta. Stanza 3, per favore."





translate italian e5s5_massage_gaby_main_6784b11e:


    dpense "Oh, è accogliente."





translate italian e5s5_massage_gaby_main_99f02fbd:


    dpense "Non male... Sono curioso di sapere chi mi massaggerà..."





translate italian e5s5_massage_gaby_main_e13226b5:


    gaby "Ecco fatto. Giusto in tempo."





translate italian e5s5_massage_gaby_main_9d4ca66f:


    dpense "Hmm?"





translate italian e5s5_massage_gaby_main_767727ac:


    d "Sinceramente non mi aspettavo che fossi qui."





translate italian e5s5_massage_gaby_main_fbbd8a7d:


    gaby "Hai una partita importante in arrivo. Ti voglio in ottima forma."





translate italian e5s5_massage_gaby_main_a5e4cd0a:


    d "Abbastanza giusto."





translate italian e5s5_massage_gaby_main_438e2467:


    dpense "È così calma... come se fosse solo un altro giorno di lavoro."





translate italian e5s5_massage_gaby_main_cf33235f:


    gaby "Sdraiati sulla schiena. Ci concentreremo sulle gambe."





translate italian e5s5_massage_gaby_main_a0543308:


    dpense "È pazzesco... Non aveva idea che fossi io prima."





translate italian e5s5_massage_gaby_main_1d98e1ca:


    dpense "E ora mi massaggerà come se niente fosse."





translate italian e5s5_massage_gaby_main_915b1cd1:


    gaby "Dimmi se la pressione è troppa."





translate italian e5s5_massage_gaby_main_cf335fae:


    d "È perfetto. Sodo, ma liscio."





translate italian e5s5_massage_gaby_main_235045f3:


    dpense "Le sue mani sono sicure. Precise. Sa esattamente cosa sta facendo."





translate italian e5s5_massage_gaby_main_d39bef52:


    gaby "I tuoi quadricipiti sono contratti. Sento molta tensione accumulata."





translate italian e5s5_massage_gaby_main_44ff6795:


    d "Ha senso. Ultimamente mi sono impegnato molto... e ho pensato molto."





translate italian e5s5_massage_gaby_main_f63e3072:


    gaby "Pensato?"





translate italian e5s5_massage_gaby_main_5b65b87f:


    d "Sulla partita. Sul restare concentrati."





translate italian e5s5_massage_gaby_main_4427b431:


    gaby "Mantieni questa mentalità. Devi essere acuto."





translate italian e5s5_massage_gaby_main_7c06ce06:


    dpense "Cerca di mantenere un tono professionale, ma avverte la tensione."





translate italian e5s5_massage_gaby_main_58db53c0:


    gaby "Mi sposto sulle cosce. Fammi sapere se diventa troppo sensibile."





translate italian e5s5_massage_gaby_main_b4033f39:


    d "Vuoi dire fisicamente o emotivamente?"





translate italian e5s5_massage_gaby_main_c3a0d04f:


    gaby "Fisicamente. Non complichiamoci le cose."





translate italian e5s5_massage_gaby_main_4ab0dab5:


    dpense "L'ho presa. Ora sta esitando."





translate italian e5s5_massage_gaby_main_9737a6f6:


    gaby "Hai molto caldo. I muscoli reagiscono bene."





translate italian e5s5_massage_gaby_main_ccbf27d4:


    d "Forse è solo il tuo tocco."





translate italian e5s5_massage_gaby_main_4e6d2b64:


    gaby "...Manteniamo un tono professionale, okay?"





translate italian e5s5_massage_gaby_main_de3c485f:


    d "Certo. Lo dico solo... hai delle dita magiche."





translate italian e5s5_massage_gaby_main_08df85ac:


    dpense "Ora ha le guance rosse. È agitata."





translate italian e5s5_massage_gaby_main_cd72dc97:


    gaby "Poi i fianchi. Cerca di respirare e rilassarti."





translate italian e5s5_massage_gaby_main_12e0eed0:


    d "È un po' difficile rilassarsi con te così vicino."





translate italian e5s5_massage_gaby_main_487ff192:


    gaby "Preferiresti qualcun altro?"





translate italian e5s5_massage_gaby_main_aa04a66e:


    d "Nemmeno lontanamente."





translate italian e5s5_massage_gaby_main_d1a462be:


    gaby "... [name]Non si tratta più solo di recupero."





translate italian e5s5_massage_gaby_main_337b6dff:


    d "Forse no. Ma mi sembra giusto."





translate italian e5s5_massage_gaby_main_cfd29dd2:


    gaby "Sono il tuo allenatore. Sono più grande. Questo non dovrebbe succedere."





translate italian e5s5_massage_gaby_main_50b86890:


    d "Allora perché mi tieni ancora le mani addosso?"





translate italian e5s5_massage_gaby_main_f3022391:


    gaby "IO..."





translate italian e5s5_massage_gaby_main_d72157de:


    d "Dimmi di fermarmi. Lo farò."





translate italian e5s5_massage_gaby_main_afb8b1fb:


    gaby "...NO."





translate italian e5s5_massage_gaby_main_7d997125:


    dpense "La sua guardia sta crollando. Ancora un po'..."





translate italian e5s5_massage_gaby_main_f857082d:


    dpense "La sua voce è appena un sussurro. Ma le sue mani... non si sono allontanate."





translate italian e5s5_massage_gaby_main_48984802:


    gaby "Non dovrei farlo..."





translate italian e5s5_massage_gaby_main_fe5a5f9b:


    d "Allora dimmi di toglierti le mani di dosso."





translate italian e5s5_massage_gaby_main_48876117:


    gaby "..."





translate italian e5s5_massage_gaby_main_1c29f5d0:


    dpense "Non dice una parola."





translate italian e5s5_massage_gaby_main_cd459cec:


    d "Anche tu sei tesa, lo sai. Tutta questa pressione... non è solo sul campo."





translate italian e5s5_massage_gaby_main_36fd47ae:


    gaby "Non è la stessa cosa."





translate italian e5s5_massage_gaby_main_8484350c:


    d "Non è vero? Sei sempre generosa. Hai sempre il controllo. Forse meriti di lasciar andare per una volta."





translate italian e5s5_massage_gaby_main_96dbd6e4:


    dpense "Per un attimo trattenne il respiro. Lo sentiva."





translate italian e5s5_massage_gaby_main_74527e74:


    gaby "Sei il mio studente..."





translate italian e5s5_massage_gaby_main_d074f7df:


    d "E tu sei una donna bellissima, Gabriella, che mi tocca come se volesse dimenticare le regole anche solo per un attimo."





translate italian e5s5_massage_gaby_main_885010d3:


    gaby "...Un attimo."





translate italian e5s5_massage_gaby_main_aac0affb:


    dpense "Sta tremando. Non per paura. Per l'attesa."





translate italian e5s5_massage_gaby_main_c70dd2d4:


    gaby "Ora mi concentrerò sulla parte interna delle cosce."





translate italian e5s5_massage_gaby_main_fea3af09:


    dpense "La sua voce è bassa. Controllata. Ma le sue dita sono più lente... più insistenti."





translate italian e5s5_massage_gaby_main_116b0692:


    d "Mmh... Lascia che ti aiuti..."





translate italian e5s5_massage_gaby_main_ffaad131:


    gaby "[name]!"





translate italian e5s5_massage_gaby_main_1a3acc53:


    d "Non preoccuparti, resterò professionale!"





translate italian e5s5_massage_gaby_main_d3ba05a9:


    gaby "Ma..."





translate italian e5s5_massage_gaby_main_226c70e9:


    dpense "Sta cercando di riprendere il controllo."





translate italian e5s5_massage_gaby_main_b8980a8e:


    dpense "Ma le sue dita tracciano dei disegni... troppo delicate per essere professionali."





translate italian e5s5_massage_gaby_main_77c76308:


    d "Lasciami aiutare... stai già facendo così tanto."





translate italian e5s5_massage_gaby_main_20b6d50e:


    gaby "[name]…"





translate italian e5s5_massage_gaby_main_d7b29708:


    d "Shh. Sentilo e basta."





translate italian e5s5_massage_gaby_main_913875c9:


    dpense "Il suo corpo si irrigidì. Ma non si mosse."





translate italian e5s5_massage_gaby_main_0ae9bcd0:


    ""





translate italian e5s5_massage_gaby_main_20313501:


    gaby "Ah..."





translate italian e5s5_massage_gaby_main_862affd8:


    gaby "Cavolo..."





translate italian e5s5_massage_gaby_main_f7c934e2:


    gaby "Questo non è..."





translate italian e5s5_massage_gaby_main_746cb4ce:


    gaby "Perché sono venuto qui…"





translate italian e5s5_massage_gaby_main_89fadf36:


    gaby "Perché…"





translate italian e5s5_massage_gaby_main_16534fb1:


    gaby "Non riesco a fermarmi."





translate italian e5s5_massage_gaby_main_4b1beaff:


    dpense "Ormai non evita più nulla."





translate italian e5s5_massage_gaby_main_3bb11019:


    d "Vedi? Sei incredibile in questo. Mi fai sciogliere al solo tocco."





translate italian e5s5_massage_gaby_main_da48d11f:


    gaby "Stai rendendo impossibile rimanere professionali..."





translate italian e5s5_massage_gaby_main_a400c057:


    d "Forse non voglio che tu lo faccia."





translate italian e5s5_massage_gaby_main_863b5583:


    gaby "...Se qualcuno lo scoprisse..."





translate italian e5s5_massage_gaby_main_c5c828de:


    d "Nessuno lo farà. Siamo solo noi. Solo in questo momento."





translate italian e5s5_massage_gaby_main_011f8b53:


    gaby "Poi..."





translate italian e5s5_massage_gaby_main_16366704:


    gaby "Non fermarti..."





translate italian e5s5_massage_gaby_main_4040ad56:


    dpense "La sua mano si muove lentamente su e giù... Dio, è una sensazione troppo bella."





translate italian e5s5_massage_gaby_main_127051e6:


    d "Sei incredibile... così dolce..."





translate italian e5s5_massage_gaby_main_84fb6e85:


    gaby "E tu sei... così difficile... è pazzesco..."





translate italian e5s5_massage_gaby_main_bc45f22f:


    dpense "Le premo le dita dentro, lentamente. Lei inarca la schiena, ansimando."





translate italian e5s5_massage_gaby_main_2819d3b3:


    gaby "[name]... questo è... ah..."





translate italian e5s5_massage_gaby_main_280253c4:


    dpense "La sua presa si stringe... mi sta accarezzando e ora..."





translate italian e5s5_massage_gaby_main_b4a12fa6:


    d "...Oh merda..."





translate italian e5s5_massage_gaby_main_49787490:


    dpense "L'altra mano mi accarezza delicatamente i testicoli."





translate italian e5s5_massage_gaby_main_142e2c27:


    d "Gabriella…"





translate italian e5s5_massage_gaby_main_6b6a3cd0:


    gaby "Ti piace? Ti piace quando gioco con te in questo modo?"





translate italian e5s5_massage_gaby_main_823df15c:


    d "Non posso... Voglio dire... Sì. Mi piace. Non fermarti..."





translate italian e5s5_massage_gaby_main_0f6591ea:


    dpense "Il suo corpo si scioglie contro il mio. I suoi fianchi si muovono sotto i miei colpi."





translate italian e5s5_massage_gaby_main_72fa43fa:


    gaby "Mi stai facendo impazzire... Non riesco a pensare... Voglio solo..."





translate italian e5s5_massage_gaby_main_182ffcf6:


    dpense "Lei si sta perdendo. E io riesco a malapena a trattenerla."





translate italian e5s5_massage_gaby_main_e7ebce38:


    d "Dillo. Cosa vuoi?"





translate italian e5s5_massage_gaby_main_2129045c:


    gaby "...Altro... Voi. Tutti voi... semplicemente..."





translate italian e5s5_massage_gaby_main_de6ec826:


    dpense "Si sta strofinando contro la mia mano, gemendo il mio nome..."





translate italian e5s5_massage_gaby_main_5fc8c6f9:


    gaby "[name]...non fermarti, non osare fermarti..."





translate italian e5s5_massage_gaby_main_7e736253:


    dpense "La sua voce si spezza... è vicina. E lo sono anch'io."





translate italian e5s5_massage_gaby_main_0d706a94:


    d "Insieme... ok?"





translate italian e5s5_massage_gaby_main_db99af1b:


    gaby "Sì... sì..."





translate italian e5s5_massage_gaby_main_755003ab:


    d "Gabriella!"





translate italian e5s5_massage_gaby_main_811a0b65:


    gaby "Oh mio dio... oh mio..."





translate italian e5s5_massage_gaby_main_0b2df493:


    gaby "...Cosa abbiamo appena fatto?"





translate italian e5s5_massage_gaby_main_6c647e79:


    d "Ci lasciamo andare. Solo per un momento."





translate italian e5s5_massage_gaby_main_f49451f4:


    gaby "Io... non posso credere che sia successo. Sono il tuo allenatore. Dovrei guidarti, non..."





translate italian e5s5_massage_gaby_main_f877753b:


    d "Non hai fatto niente di sbagliato. Eri solo... umano."





translate italian e5s5_massage_gaby_main_9383a269:


    gaby "Ciò non può accadere di nuovo."





translate italian e5s5_massage_gaby_main_1523fe20:


    d "..."





translate italian e5s5_massage_gaby_main_cd81800a:


    gaby "Devo andare."





translate italian e5s5_massage_gaby_main_7de26861:


    dpense "Se n'è andata. Proprio così."





translate italian e5s5_massage_gaby_main_c1d4a101:


    dpense "Non so cosa le passa per la testa, ma so esattamente cosa passa per la mia."





translate italian e5s5_massage_gaby_main_1529b40c:


    dpense "Quello è stato... indimenticabile."





translate italian e5s5_massage_gaby_main_c47791a5:


    dpense "Ma cosa significa esattamente, adesso?"





translate italian e5s5_massage_gaby_main_25815f44:


    dpense "Il blu mi aspetta..."





translate italian e5s5_massage_gaby_main_be915c33:


    dpense "Credo di avere la mattinata tutta per me."





translate italian e5s5_massage_gaby_main_50b86890_1:


    d "Allora perché mi tieni ancora le mani addosso?"





translate italian e5s5_massage_gaby_main_0ae9bcd0_1:


    ""





translate italian e5s5_massage_gaby_main_ffaad131_1:


    gaby "[name]!"





translate italian e5s5_blue_75debac5:


    sofia "Ei, tu!"





translate italian e5s5_blue_be3f1544:


    d "Sofia."





translate italian e5s5_blue_620fb770:


    d "Oggi sei splendida."





translate italian e5s5_blue_fc64dba5:


    sofia "Anche tu. Hai dormito bene?"





translate italian e5s5_blue_1834f689:


    d "Diciamo che ho avuto notti peggiori."





translate italian e5s5_blue_bcbec8d3:


    sofia "Perfetto. Ho bisogno del tuo occhio maschile per aiutarmi a scegliere una borsa."





translate italian e5s5_blue_7ec6a092:


    sofia "E forse... un po' di più se ti comporti bene."





translate italian e5s5_blue_ae000f54:


    d "Corruzione di prima mattina?"





translate italian e5s5_blue_fb33e447:


    sofia "Chiamalo fascino, signor Consulente di Moda."





translate italian e5s5_blue_d5388720:


    d "A proposito, di recente ho incontrato una persona. Si chiama Marc."





translate italian e5s5_blue_4252ada9:


    sofia "Marc? Non mi dice niente."





translate italian e5s5_blue_947a94bc:


    d "Sembrava sapere molto sui MIGLIORI... e su di noi."





translate italian e5s5_blue_91707ffd:


    sofia "Aspetta, cosa? Com'è possibile?"





translate italian e5s5_blue_c39a3e10:


    d "Non ne ho idea. Ha detto cose strane, come se avesse accesso a tutto. E mi ha avvertito."





translate italian e5s5_blue_70da401d:


    sofia "Ok, adesso mi sento in imbarazzo."





translate italian e5s5_blue_945cec7b:


    sofia "Pensi che sia una specie di spia? Un ex concorrente?"





translate italian e5s5_blue_b1595f94:


    d "Non lo so. Ma era troppo calmo. Troppo sicuro di sé."





translate italian e5s5_blue_66fe77eb:


    d "Volevo solo dirtelo. Per sicurezza."





translate italian e5s5_blue_4198957c:


    sofia "Grazie... Mi piace che tu mi dica queste cose. Ti prometto che starò attenta."





translate italian e5s5_blue_b1c1af7b:


    sofia "Forse chiederò a mia sorella. Se c'è qualcuno che può dirmi qualcosa su di lui, è lei."





translate italian e5s5_blue_725f748a:


    sofia "Lei può farlo per noi."





translate italian e5s5_blue_cf3e6cde:


    d "Noi... Hai mai pensato a cosa significa veramente?"





translate italian e5s5_blue_9ae6e49d:


    d "Tu ed io. Nel mezzo di questa competizione. Le altre ragazze, la posta in gioco... tutti che ci guardano."





translate italian e5s5_blue_e94e1e53:


    sofia "Penso soprattutto che tu mi piaccia davvero."





translate italian e5s5_blue_acf6b488:


    sofia "E che è troppo speciale per tenerlo nascosto solo per via di un gioco."





translate italian e5s5_blue_8b47f51d:


    d "Ma non è solo un gioco. Alcuni di loro farebbero qualsiasi cosa per vincere. Se rendiamo pubblici i nostri affari, diventiamo un bersaglio."





translate italian e5s5_blue_37ec2028:


    sofia "Forse. Ma se abbiamo troppa paura di amare, allora abbiamo già perso, non è vero?"





translate italian e5s5_blue_c82f9e2f:


    d "Io... non voglio che tu ti faccia male a causa mia. O che loro usino questa cosa contro di noi."





translate italian e5s5_blue_dc8acdeb:


    sofia "Pensi troppo, [name]. Ma..."





translate italian e5s5_blue_29b26585:


    sofia "Questo è uno dei motivi per cui mi sento al sicuro con te."





translate italian e5s5_blue_ebf8e1e8:


    d "Vuoi farti un selfie? Solo per noi."





translate italian e5s5_blue_4c765146:


    sofia "Mi piacerebbe molto."





translate italian e5s5_blue_5657a5b4:


    d "Ecco. Uno scatto perfetto di una coppia potente."





translate italian e5s5_blue_2bc5878d:


    d "Pensi che dovrei pubblicarlo? Renderlo... in un certo senso ufficiale?"





translate italian e5s5_blue_274949db:


    sofia "Hmm... intendi tipo, 'Ehi mondo, è mia'?"





translate italian e5s5_blue_7eef06a5:


    d "Voglio dire... siamo pronti per questo? Per mostrarlo a tutti, proprio quando la gente osserva ogni nostra mossa?"





translate italian e5s5_blue_dc3b82d2:


    sofia "Io dico che dovremmo smettere di nasconderci e iniziare a vivere. Se qualcosa sembra reale, lascialo essere reale."





translate italian e5s5_blue_75d187ba:


    d "Fatto. Potrebbe essere un piccolo passo, ma significa molto."





translate italian e5s5_blue_aa655c08:


    sofia "Wow... okay. Ora è disponibile."





translate italian e5s5_blue_2141b0cb:


    sofia "Riceverai dei commenti invidiosi."





translate italian e5s5_blue_d2080394:


    d "Lasciateli fare. A me interessa solo un'opinione."





translate italian e5s5_blue_e6fba878:


    d "La tua."





translate italian e5s5_blue_2f874638:


    sofia "Ammaliatore."





translate italian e5s5_blue_f483d2ca:


    d "No... non ancora. Per ora teniamolo solo per noi."





translate italian e5s5_blue_5baa0c26:


    sofia "Va bene. Finché è reale, per me è sufficiente."





translate italian e5s5_blue_e9989e88:


    sofia "Ma un giorno, sarà meglio che tu mostri al mondo cosa sai fare."





translate italian e5s5_blue_845b87d7:


    d "Affare fatto. Ma è meglio che TU mi faccia vedere cosa sai fare!"





translate italian e5s5_blue_fc056c41:


    sofia "Intendi quel sedere???"





translate italian e5s5_blue_801518fe:


    d "Esattamente!"





translate italian e5s5_blue_da65a7e3:


    sofia "Ahah!"





translate italian e5s5_blue_2907598c:


    d "Teniamolo tra noi. Mi piace avere questo momento solo per noi."





translate italian e5s5_blue_233674e4:


    sofia "Anch'io. Rende tutto ancora più speciale."





translate italian e5s5_blue_64417f8f:


    d "Hmm? Un messaggio da Grace."





translate italian e5s5_blue_a2dd00bb:


    sofia "E uno da mia sorella."





translate italian e5s5_blue_a9a66518:


    d "È ora di andare."





translate italian e5s5_blue_a6f4c0d7:


    sofia "Immagino che compreremo quella borsa un'altra volta."





translate italian e5s5_blue_33e6da38:


    d "La prossima volta non lasceremo che nulla ci ostacoli."





translate italian e5s5_blue_7cd819e6:


    sofia "Affare fatto. Ora vai a vincere questa cosa."





translate italian e5s5_blue_a3289c70:


    d "Oh, vuoi vincere?"





translate italian e5s5_blue_f716865d:


    sofia "Io? No! Non mi interessa!"





translate italian e5s5_blue_fb9c731f:


    sofia "Ma ti aiuterò."





translate italian e5s5_blue_dd5d68f3:


    d "Eh?"





translate italian e5s5_blue_580c045a:


    sofia "Se potessi..."





translate italian e5s5_prep_match_64417f8f:


    d "Hmm? Un messaggio da Grace."





translate italian e5s5_prep_match_a9a66518:


    d "È ora di andare."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
