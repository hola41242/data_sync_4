



translate italian e5s1_8637f884:


    d "RubyOOOOOOOOOOOOOOOOOO!"





translate italian e5s1_920afafe:


    ruby "AHHHHH!"





translate italian e5s1_4b54f67f:


    ruby "AHI!"





translate italian e5s1_038c54a1:


    ruby "Cosa? Cosa è appena successo?!"





translate italian e5s1_f9c7f0b0:


    d "Stai bene?"





translate italian e5s1_c7a35f1f:


    ruby "Uh... Sì, penso di sì"





translate italian e5s1_c3641176:


    d "Stavi per essere investito da quella macchina. Dovevo fare qualcosa."





translate italian e5s1_fe53a24b:


    ruby "Tu... hai rischiato la vita per me?"





translate italian e5s1_b58b165f:


    d "Non potevo restare lì a guardare mentre ti facevi male."





translate italian e5s1_55a5a4af:


    ruby "Non capisco... sei spuntato dal nulla. È stato come se il tempo si fosse fermato."





translate italian e5s1_7fd570da:


    d "Non avrei permesso che ti accadesse niente."





translate italian e5s1_8899f6e3:


    ruby "Ma... avresti potuto farti male. Perché correre un rischio del genere?"





translate italian e5s1_f5688640:


    d "Perché ci tengo a te, Ruby."





translate italian e5s1_f8bebc6f:


    ruby "…"





translate italian e5s1_1e1258b6:


    d "Aspetta... Dov'è Emerick?"





translate italian e5s1_30ab2173:


    ruby "Non lo so..."





translate italian e5s1_825fa3a7:


    d "Bastardo..."





translate italian e5s1_b63f180b:


    d "Forza, ti accompagno in camera tua. Mi assicurerò che tu sia al sicuro."





translate italian e5s1_8ae3f02b:


    ruby "Grazie."





translate italian e5s1_e8b6b321:


    emerick "Te li sei persi!!!"





translate italian e5s1_6c99bf40:


    hec "Non potevo spararle!"





translate italian e5s1_1264cc36:


    emerick "Maledetto francesino..."





translate italian e5s1_3d7614a7:


    ruby "Grazie per avermi riaccompagnato. Non riesco proprio... a scrollarmi di dosso quello che è successo. Ero così vicino a..."





translate italian e5s1_f11fc35f:


    d "Ehi, ehi... respira. Ora sei al sicuro. È tutto ciò che conta."





translate italian e5s1_432a0fd3:


    ruby "Ma se non ci fossi stato? Se non fossi arrivato in tempo..."





translate italian e5s1_d4906513:


    d "Non pensarci. Io ero lì. Ho visto cosa stava succedendo e non volevo che ti facessi male."





translate italian e5s1_e1af90f3:


    ruby "Sembra che tu sappia sempre esattamente quando ho bisogno di te. Come fai... come fai?"





translate italian e5s1_70fe1779:


    d "Non si tratta di sapere. Si tratta solo..."





translate italian e5s1_8206e8f8:


    d "Mi importa di te, Ruby. Non potevo restare a guardare mentre ti succedeva qualcosa."





translate italian e5s1_81c69a08:


    d "Ehi!"





translate italian e5s1_71b81e18:


    ruby "Ti senti male?"





translate italian e5s1_2d514ee4:


    d "Solo un piccolo livido sulla schiena. Non preoccuparti. Non è niente."





translate italian e5s1_11d44732:


    d "Sei importante per me. Sono felice che tu sia al sicuro ora."





translate italian e5s1_a2169b7c:


    ruby "Non sai cosa significhi per me. Davvero. Io..."





translate italian e5s1_3e72968c:


    mad "Quello che è successo?!"





translate italian e5s1_907147a6:


    ruby "Madison!"





translate italian e5s1_0fb8a98c:


    mad "Che diavolo hai fatto? Che le è successo?!"





translate italian e5s1_eabb95e2:


    ruby "Basta! Non mi ha fatto niente."





translate italian e5s1_83e0d8d4:


    mad "Allora perché sei così? Vedo che sei tutto scosso."





translate italian e5s1_1728ff72:


    ruby "Era Emerick. Mi ha spinto sulla strada... e [name] mi ha salvato."





translate italian e5s1_3cab6c49:


    ruby "Se non ci fosse stato lui…"





translate italian e5s1_12cc4401:


    mad "Emerick? Dici sul serio? Quel pezzo di merda!"





translate italian e5s1_2570fab1:


    mad "Non ci posso credere. Ogni dannata volta trova il modo di intromettersi, di ferire le persone a cui tengo."





translate italian e5s1_2e1eba66:


    ruby "Madison, calmati. È finita ora..."





translate italian e5s1_37657869:


    mad "No, non è finita. Sono stufa di sentirlo pensare di poter fare quello che vuole."





translate italian e5s1_b517a095:


    mad "Sono stufo di sentirmi trattato come se non fossimo niente."





translate italian e5s1_470b72d8:


    d "So che sei arrabbiata, Madison, ma prendiamoci un secondo..."





translate italian e5s1_ac434fb3:


    mad "Un secondo per cosa? Per lasciarlo continuare a calpestarci? No. Non più."





translate italian e5s1_5e7a1a65:


    mad "Non gli permetterò di fare del male a nessun altro."





translate italian e5s1_fd8fbac7:


    ruby "Madi, non devi..."





translate italian e5s1_bad2ad5b:


    mad "No. Troverò un modo. Andrò alla Torre Orushi se necessario. Troverò qualcosa su di lui, qualsiasi cosa pur di fargliela pagare."





translate italian e5s1_66cfc5ef:


    mad "Sono solo... sono così felice che tu stia bene. Quando ho visto il tuo messaggio, ho pensato..."





translate italian e5s1_c405af79:


    mad "Non posso perderti, Ruby. Non posso proprio."





translate italian e5s1_ed939cdf:


    ruby "Non mi perderai. Sono qui. Sto bene, grazie a lui."





translate italian e5s1_ed6663f6:


    mad "[name]... Grazie mille. Per averla salvata."





translate italian e5s1_a030f1cc:


    d "Non potevo guardarla farsi male."





translate italian e5s1_be37c700:


    d "Vi lascio un po' di spazio. Fatemi sapere se avete bisogno di qualcosa."





translate italian e5s1_9ccfef56:


    ruby "Grazie ancora. Per tutto."





translate italian e5s1_55428f52:


    mad "Sì. Grazie."





translate italian e5s1_65f68525:


    d "Che diavolo è successo lì dietro?"





translate italian e5s1_f22927de:


    d "Emerick... Stavolta ha esagerato. Ha spinto Ruby sulla strada..."





translate italian e5s1_dc85aaa9:


    d "Mi fa male solo a pensarci."





translate italian e5s1_6c0648a2:


    d "E Madison... era furiosa, e lo capisco."





translate italian e5s1_d52744de:


    d "Lei tiene a Ruby tanto quanto me. Devo aiutarla a gestire la situazione."





translate italian e5s1_bc37c3ae:


    d "Emerick non può farla franca."





translate italian e5s1_67fd8c9a:


    d "Ma quel… quel momento…"





translate italian e5s1_63201803:


    d "Quando ho visto Ruby in pericolo, mi è successo qualcosa. Ho sentito un'ondata..."





translate italian e5s1_319f03eb:


    d "Era come se ogni parte di me si fosse illuminata, muovendosi più velocemente di quanto avrei mai pensato."





translate italian e5s1_ab6a92fc:


    d "La mia mente era completamente lucida, senza esitazioni, senza dubbi."





translate italian e5s1_60d891a3:


    d "Mi sentivo... come se non fossi completamente me stesso. Come se avessi scoperto qualcosa che non sapevo nemmeno esistesse."





translate italian e5s1_5c347b7d:


    d "Ma qualunque cosa fosse, mi ha aiutato a salvarla."





translate italian e5s1_865436fc:


    d "Ed è questo che conta adesso."





translate italian e5s1_51325e82:


    d "Ruby... Non credo di aver mai realizzato quanto tengo a lei."





translate italian e5s1_45049fa3:


    d "Prima era solo una persona che conoscevo, una persona sempre presente. Ma ora... è diverso."





translate italian e5s1_cf2a24fa:


    d "Come se stessi davvero iniziando a vederla per quella che è."





translate italian e5s1_f9e11963:


    d "Forte, gentile, una persona di cui mi posso fidare. Sta diventando più di un semplice volto familiare."





translate italian e5s1_e5f54a54:


    d "Sta diventando…"





translate italian e5s1_62fb39a8:


    d "Ronzio?"





translate italian e5s1_1f1620be:


    d "Sarà divertente!"





translate italian e5s1_7984b7ea:


    d "Ancora?"





translate italian e5s1_866e135e:


    d "Devo contattare quella misteriosa donna del Palazzo..."





translate italian e5s1_25f6c8e6:


    d "Diamo un'occhiata al mio telefono prima che finisca la notte..."





translate italian e5s1_366d00ed:


    d "Potrei mandare un messaggio a Julia e invitarla ad andare a bere qualcosa..."





translate italian e5s1_ccda9b9f:


    d "Forse è disponibile il rosso..."





translate italian fine5s1_084c58a1:


    d "Non ci resta che aspettare..."





translate italian juliaphonep5intro_5545b2c5:


    d "Il momento perfetto per trascorrere del tempo di qualità con lei."





translate italian redphonep5intro_f0a39379:


    "La prossima volta: parla direttamente di Emerick..."





translate italian redep5s1_bd5a25f2:


    beth "Quindi è qui che ti sei nascosto dopo aver interpretato l'eroe?"





translate italian redep5s1_a1a48b13:


    dpense "Beth. Sempre veloce con i colpi."





translate italian redep5s1_3f224c48:


    d "Non mi nascondo. Mi riposo e basta."





translate italian redep5s1_0deb3c11:


    beth "Oh, certo. Un nobile cavaliere ha sempre bisogno di riprendere fiato dopo aver salvato una damigella in pericolo."





translate italian redep5s1_64e6437c:


    d "Se sei qui solo per prendermi in giro, puoi andartene."





translate italian redep5s1_ffbb90f6:


    beth "Perché andarmene quando posso godermi lo spettacolo?"





translate italian redep5s1_05179a5e:


    d "Quindi questa è la tua idea di compassione?"





translate italian redep5s1_8b8dfbb6:


    beth "La compassione è per i deboli. Hai bisogno di qualcuno che ti ricordi come giocare la partita senza cadere nelle trappole più banali."





translate italian redep5s1_e8de084b:


    d "E tu cosa sei? Un maestro stratega? Un esperto di giochi di potere?"





translate italian redep5s1_5e26d9f6:


    beth "Sono sicuramente migliore di te."





translate italian redep5s1_d4785663:


    beth "Quindi, cosa è successo veramente là fuori?"





translate italian redep5s1_179aeac0:


    d "Emerick spinse Ruby in strada. Se non fossi intervenuta..."





translate italian redep5s1_666292af:


    beth "Certo che sei intervenuto per salvarla. Ma Emerick non agisce mai senza motivo."





translate italian redep5s1_0f4ff2fd:


    beth "Pensi davvero che il tuo piccolo atto eroico sarà sufficiente? Emerick non lascerà correre, lo sai."





translate italian redep5s1_54274ac2:


    dpense "Sembra che lo conosca più di quanto pensassi."





translate italian redep5s1_2c3a63c7:


    d "Cosa intendi?"





translate italian redep5s1_2a80a354:


    beth "Emerick sa che una cosa del genere potrebbe ritorcersi contro di lui. Quindi, se avesse agito, aveva un piano."





translate italian redep5s1_35959abf:


    beth "La domanda è: perché adesso?"





translate italian redep5s1_6427f2c4:


    d "Non lo so. Non ci ho pensato. Volevo solo che Ruby fosse fuori pericolo."





translate italian redep5s1_43306920:


    beth "Ed era proprio questo che contava: una reazione impulsiva."





translate italian redep5s1_419f2773:


    beth "Non capisci, vero? Emerick non è solo un piantagrane. È un calcolatore."





translate italian redep5s1_4f90d58f:


    beth "Durante il campionato di atletica leggera, ha falsificato i registri, corrotto i funzionari e addirittura fatto pressione sugli altri concorrenti."





translate italian redep5s1_87dac044:


    beth "Tutto per assicurarsi la vittoria. E ora sei diventato il suo nuovo bersaglio."





translate italian redep5s1_bc2e5f67:


    dpense "Falsificare documenti? Corrompere funzionari? Quest'uomo non si fermerà davanti a nulla."





translate italian redep5s1_6d4a814f:


    dpense "Quindi è questo che mi trovo ad affrontare? Un tizio che sta giocando a un gioco di cui non conosco nemmeno le regole..."





translate italian redep5s1_277cda4c:


    d "E ora mi prende di mira? Perché? Non sono nessuno."





translate italian redep5s1_7a238ca9:


    beth "Non ancora. Ma sei qualcosa di nuovo, inaspettato. Ed Emerick odia le sorprese."





translate italian redep5s1_e9e5081e:


    beth "Tu sei una variabile sconosciuta nel suo piccolo piano."





translate italian redep5s1_691bd06e:


    beth "Ecco perché farà tutto il possibile per renderti prevedibile, per metterti in situazioni in cui lui avrà il controllo di tutti i pezzi."





translate italian redep5s1_cb07a3df:


    dpense "Prevedibile... Quindi questo è il suo obiettivo. Vuole che io reagisca esattamente come si aspetta."





translate italian redep5s1_e272ec68:


    d "Quindi, se ho capito bene, devo fare l'opposto di ciò che lui si aspetta."





translate italian redep5s1_5295505f:


    beth "Non solo. Devi sorprenderlo. Fai qualcosa che non ha previsto. È così che lo depisterai."





translate italian redep5s1_b8e76d53:


    d "Perché avrebbe dovuto farlo? Non aveva niente da guadagnare quella sera."





translate italian redep5s1_e7d5988c:


    beth "È questo il problema. Non fa mai nulla senza una ragione. Tutto ciò che fa ha uno scopo."





translate italian redep5s1_a7fe4640:


    beth "E ora sa che sei impulsiva. Sei solo un altro pezzo che può manipolare."





translate italian redep5s1_f1ffa118:


    dpense "Una pedina? Se è vero, allora sono già indietro."





translate italian redep5s1_d7428c05:


    d "Cosa dovrei fare allora?"





translate italian redep5s1_69262bbf:


    beth "Apri gli occhi. Osserva i suoi schemi. Emerick ama provocare le persone, farle reagire."





translate italian redep5s1_3c3dd45b:


    beth "Se vuoi tenergli testa, devi capire le sue mosse prima che le faccia lui."





translate italian redep5s1_2f536003:


    beth "E, soprattutto, smettetela di lanciarvi a capofitto. È esattamente quello che vuole."





translate italian redep5s1_c23626b7:


    beth "La prossima volta, pensa prima di agire. Fai un passo indietro e chiediti: cosa guadagna a farti agire?"





translate italian redep5s1_b357f90b:


    d "Quindi cosa faccio se vedo che sta di nuovo progettando qualcosa?"





translate italian redep5s1_63193259:


    beth "Una volta capito come funziona, puoi coglierlo di sorpresa con qualcosa che non si aspetterebbe."





translate italian redep5s1_0a365651:


    beth "A volte è frustrante guardarti. Non ti rendi nemmeno conto del tuo potenziale."





translate italian redep5s1_ed007cdb:


    d "E tuttavia, è proprio perché sono frustrato che sono ancora qui, a tener duro contro di te."





translate italian redep5s1_83ad7adf:


    beth "Riesci a tenere duro? Non stai quasi resistendo. Ma è carino vederti provarci."





translate italian redep5s1_f9db8479:


    d "Forse è perché ti ho lasciato credere di avere la meglio."





translate italian redep5s1_3f8f506a:


    beth "Davvero? Se è così, dimostramelo. Dimostrami che sai sorprendermi."





translate italian redep5s1_ecadf76a:


    d "E se ti dicessi che sono pronto a sorprenderti adesso?"





translate italian redep5s1_ff86c84c:


    beth "Allora smettila di parlare. Fallo."





translate italian redep5s1_1015556c:


    d "Se gioco secondo le tue regole... cosa ottengo in cambio?"





translate italian redep5s1_5625aa6e:


    beth "Non mi sorprenderai mai se giochi secondo le regole."





translate italian redep5s1_579d49d7:


    beth "Dovresti chiederti cosa stai rischiando invece di cosa stai guadagnando. "





translate italian redep5s1_d78e9edb:


    d "E se fossi disposto a correre questo rischio?"





translate italian redep5s1_4e6027c9:


    beth "Allora corri il rischio. Aspetti sempre che ti dicano cosa fare?"





translate italian redep5s1_f6aa457e:


    d "Allora lascia che ti dimostri che posso farlo."





translate italian redep5s1_b6d3aa81:


    beth "Questo è ciò che sto aspettando."





translate italian redep5s1_e3319f89:


    d "Posso fare molto di più che parlare."





translate italian redep5s1_6bf8e144:


    beth "Oh, non ne dubito. Ma questo non significa che ti renderò le cose facili."





translate italian redep5s1_4723bed9:


    d "Non cerco la semplicità."





translate italian redep5s1_f1f0ba53:


    beth "Bene. Perché non otterrai niente gratis. Se vuoi qualcosa, dovrai guadagnartela."





translate italian redep5s1_0fc5a3c2:


    d "E cosa devo fare per guadagnarmelo?"





translate italian redep5s1_4eec1a25:


    beth "Prima, dimostrami che sai mantenere la calma sotto pressione. Poi dimostrami che sai tenere il passo, ovunque ti conduca."





translate italian redep5s1_fdd23a56:


    d "Ovunque tu vada?"





translate italian redep5s1_54180c37:


    beth "Esatto. E ricorda, non mi aspetto niente di meno del tuo meglio."





translate italian redep5s1_6570101e:


    beth "Pensi davvero di essere pronto a fare tutto il necessario per sorprendermi?"





translate italian redep5s1_43cf3130:


    d "Sì. E lo dimostrerò."





translate italian redep5s1_d3696ed0:


    beth "Mmm... interessante. Ma pensare di poterlo fare è una cosa. Farlo è un'altra."





translate italian redep5s1_4629cd14:


    d "Allora dammi una possibilità."





translate italian redep5s1_1ee273de:


    beth "E se fallisci? Sei pronto a pagarne il prezzo?"





translate italian redep5s1_cc118cbe:


    d "Non fallirò."





translate italian redep5s1_04bb258a:


    beth "Davvero? Sembri così sicuro di te. Ma vedo un barlume di dubbio. Proprio lì."





translate italian redep5s1_40e44cbd:


    d "Guarda meglio. Non ho esitazioni."





translate italian redep5s1_cb9c376f:


    beth "Questo è ciò che scopriremo."





translate italian redep5s1_5d7e26e7:


    beth "Pensavi davvero di potermi sorprendere? Guardati ora... completamente in mia balia."





translate italian redep5s1_90848652:


    d "Forse era proprio qui che volevo essere."





translate italian redep5s1_c38e04e4:


    beth "Non c'è da sorprendersi."





translate italian redep5s1_4b505b9c:


    beth "Qui ho il controllo. Il ritmo, l'intensità... e tu mi seguirai."





translate italian redep5s1_43b49e4c:


    d "Va bene."





translate italian redep5s1_89fd0caf:


    beth "Non \"okay\". Sì, signora. Lo dica."





translate italian redep5s1_7f92de3e:


    d "Sì, signora."





translate italian redep5s1_508e1423:


    beth "Bene. Ora fammi vedere."





translate italian redep5s1_367faa66:


    beth "Dici di essere pronto a correre rischi. Ma le parole non bastano. Dillo in modo diverso."





translate italian redep5s1_c835d103:


    d "Sono pronto."





translate italian redep5s1_3ac72b58:


    beth "Sbagliato, dillo correttamente."





translate italian redep5s1_2929943c:


    beth "Bene. Ora dimostralo."





translate italian redep5s1_0ae9bcd0:


    ""





translate italian redep5s1_63e6442b:


    beth "Non male... ma si può fare di meglio."





translate italian redep5s1_49b0745e:


    d "Ti mostrerò che posso farcela."





translate italian redep5s1_7fd37676:


    beth "Ti sto dando una possibilità. Non sprecarla."





translate italian redep5s1_bfae3d79:


    beth "Resta con me. Adesso."





translate italian redep5s1_a19cd18e:


    beth "Niente male... per cominciare."





translate italian redep5s1_7ffab912:


    beth "Ricordate cosa ho detto: niente è mai garantito. Non con me."





translate italian redep5s1_b6f416e6:


    d "Sta giocando a un gioco diverso... e io ancora non so se sto vincendo o perdendo."





translate italian redep5s1_7f92de3e_1:


    d "Sì, signora."





translate italian redep5s1_0ae9bcd0_1:


    ""





translate italian juliaep5s1_4d6f6272:


    d "Ciao Julia! Spero di non averti fatto aspettare."





translate italian juliaep5s1_ab7fe98c:


    julia "Niente affatto. Sono appena arrivato anch'io. Siediti."





translate italian juliaep5s1_a720956f:


    d "Grazie. Questo posto è carino. Ci sono passato davanti un paio di volte, ma non ci sono mai entrato."





translate italian juliaep5s1_f626e85d:


    julia "Ci vengo ogni tanto. È accogliente, non troppo rumoroso e hanno delle ottime birre. Inoltre, è vicino al lavoro."





translate italian juliaep5s1_3fbe4498:


    d "Perfetto. Quindi, cosa c'è di buono qui?"





translate italian juliaep5s1_3786780c:


    julia "Bene, io consiglio la birra alla spina della casa!"





translate italian juliaep5s1_ea3bf1c0:


    d "Ok, mi fido. Ci provo."





translate italian juliaep5s1_d0682263:


    julia "Allora, cosa ci fai di nuovo? Ci sono altre storie pazze che dovrei sapere?"





translate italian juliaep5s1_672e8d69:


    d "Bene, di recente è successa una cosa che mi è rimasta impressa."





translate italian juliaep5s1_098aaba0:


    julia "Oh? Che succede?"





translate italian juliaep5s1_3197a1bb:


    d "Riguarda Emerick. Ha spinto Ruby in strada. È stato un bel colpo."





translate italian juliaep5s1_c28cc0bf:


    julia "Ruby? Sta bene, vero?"





translate italian juliaep5s1_d528fd6b:


    d "Sì, ora sta bene. Ma mi ha fatto davvero capire quanto lontano può arrivare."





translate italian juliaep5s1_9ee238f4:


    julia "È orribile. Non posso credere che qualcuno possa arrivare a tanto."





translate italian juliaep5s1_dcc960b9:


    julia "E tu? Stai bene dopo tutto questo?"





translate italian juliaep5s1_82e390d5:


    d "Sto bene. Mi ha solo fatto pensare a come comportarmi con lui la prossima volta."





translate italian juliaep5s1_2b47c55c:


    julia "Non dovresti affrontare una persona così da sola. Forse possiamo trovare una soluzione insieme."





translate italian juliaep5s1_aacfe805:


    julia "Bene, abbiamo parlato un po' del mio lavoro. Ma tu?"





translate italian juliaep5s1_0e905200:


    d "Che dire di me?"





translate italian juliaep5s1_7a0cb300:


    julia "Beh, ero curioso. Sei ancora un po' un mistero per me."





translate italian juliaep5s1_16c33588:


    julia "Com'è la tua famiglia? Mi sembra di non sapere molto delle tue origini."





translate italian juliaep5s1_9b6770e7:


    d "La mia famiglia è prevalentemente militare. Disciplina, addestramento e il non arrendersi mai. Queste sono state le lezioni che ho imparato crescendo."





translate italian juliaep5s1_b3756bb1:


    julia "Dev'essere stata dura. Essere sempre all'altezza delle aspettative."





translate italian juliaep5s1_e7a3c9e3:


    d "Non è stato sempre facile, ma mi ha sicuramente insegnato come affrontare le sfide."





translate italian juliaep5s1_a74bd090:


    d "Insegnanti. L'istruzione era tutto a casa mia. Davano valore all'apprendimento e mi incoraggiavano sempre a fare domande."





translate italian juliaep5s1_93891e8b:


    julia "È impressionante. Dev'essere stato bello avere persone che credevano nel tuo potenziale."





translate italian juliaep5s1_f1ac7016:


    d "Ci sono stati momenti in cui è stato bello, ma la pressione per esibirsi era reale."





translate italian juliaep5s1_42dc9c2c:


    d "Non penso alla famiglia in senso tradizionale. I miei amici sono sempre stati la mia vera famiglia."





translate italian juliaep5s1_5caf3c73:


    julia "Lo capisco. A volte le persone che scegli sono quelle che contano di più."





translate italian juliaep5s1_f8311687:


    d "Esatto. Mi hanno sempre sostenuto."





translate italian juliaep5s1_70e7243c:


    d "Ho dovuto risolvere le cose da sola. La mia famiglia non mi ha dato un grande vantaggio, quindi ho dovuto contare solo su me stessa."





translate italian juliaep5s1_d27239ad:


    julia "Dev'essere stato difficile, ma sembra che ti abbia reso forte."





translate italian juliaep5s1_0edfa3b6:


    d "Lo ha fatto. Sono grato per le lezioni che ho imparato lungo il cammino."





translate italian juliaep5s1_f48d95b7:


    julia "È interessante saperne di più su di te. Sento che sto iniziando a capirti meglio."





translate italian juliaep5s1_a6186baf:


    d "Beh, credo di non essere più un mistero."





translate italian juliaep5s1_03f6cf39:


    julia "Forse no, ma sei comunque molto intrigante."





translate italian juliaep5s1_cbac6963:


    d "Potrei dire lo stesso di te."





translate italian juliaep5s1_8063219d:


    julia "Immagino che dovremo continuare a conoscerci a vicenda, una conversazione alla volta."





translate italian juliaep5s1_37df8703:


    julia "Pensi davvero che possiamo vincere tutto? Il torneo, la casa... tutto?"





translate italian juliaep5s1_f148a045:


    d "È possibile. Vincere non è solo una questione di abilità. È una questione di come cresciamo insieme come squadra."





translate italian juliaep5s1_ed620926:


    d "E ho la sensazione che ogni partita che abbiamo giocato ci abbia avvicinati."





translate italian juliaep5s1_e579b0fc:


    julia "Immagino sia vero. Si vede davvero quanto tutti siano migliorati nel tempo."





translate italian juliaep5s1_9a92dac8:


    julia "Quella casa... sembra quasi troppo bella per essere vera, vero? Come un sogno che non possiamo realizzare."





translate italian juliaep5s1_10690dd7:


    d "Forse. Ma è il tipo di sogno che ci spinge a essere migliori. A volte non si tratta solo del premio."





translate italian juliaep5s1_1c85033f:


    d "Riguarda il modo in cui ci plasma lungo il cammino."





translate italian juliaep5s1_84120d2a:


    julia "E se dovessimo vincere, vivere insieme in un posto come quello... all'inizio sarebbe strano, non è vero?"





translate italian juliaep5s1_913c6ae7:


    d "All'inizio potrebbe essere un adattamento. Ma credo che ci insegnerà come affrontare le sfide e superarle insieme."





translate italian juliaep5s1_1225bdcc:


    julia "È confortante sentirlo. Mi fa sentire più sicuro dell'intera idea."





translate italian juliaep5s1_0c5889f4:


    d "Sarà un'opportunità per imparare gli uni dagli altri. Vivremo sotto lo stesso tetto, condividendo idee ed esperienze."





translate italian juliaep5s1_b704632a:


    julia "Mi piace come suona. Potremmo tutti crescere in modi inaspettati."





translate italian juliaep5s1_efecca29:


    d "Sarà come avere una palestra di personal training. Avremo tutto il necessario per rimanere allenati e preparati."





translate italian juliaep5s1_b5769240:


    julia "Pensi sempre alle prestazioni, eh? Ma hai ragione. Sarebbe un enorme vantaggio."





translate italian juliaep5s1_f6a5f7f1:


    d "Sarà divertente. Avremo i nostri alti e bassi, ma credo che ci renderà più uniti che mai."





translate italian juliaep5s1_55071f19:


    julia "Sì, lo capisco. A volte può essere caotico, ma anche davvero speciale."





translate italian juliaep5s1_77611e7a:


    d "Ciao Julia, posso chiederti una cosa un po' a caso?"





translate italian juliaep5s1_e97b18ed:


    julia "Certo. Cosa ti passa per la testa?"





translate italian juliaep5s1_bf9b1e2f:


    d "Io, ehm... ho appena aperto una pagina OnlyStan. E visto che sei qui, ho pensato che sarebbe stato bello se ci facessimo una foto veloce insieme. Sai, per iniziare."





translate italian juliaep5s1_a9f49b0b:


    julia "La tua prima foto? Non mi aspettavo fossi il tipo da OnlyStan. Di cosa parla la tua pagina?"





translate italian juliaep5s1_19e6c134:


    d "Onestamente, l'ho fatto più che altro per curiosità. Ci sono Fanny e Kira, e ho pensato di vedere di cosa si tratta."





translate italian juliaep5s1_2b14ba8c:


    d "Ma ho pensato: perché non usarlo per le mie cose? Qualcosa di più informale."





translate italian juliaep5s1_9c438131:


    julia "Quindi, ancora nessun contenuto? Questo sarebbe il tuo primo post in assoluto?"





translate italian juliaep5s1_3a725bb7:


    d "Sì. Voglio dire, ci sto ancora pensando, ma una foto con te sarebbe un ottimo inizio. Qualcosa di semplice, senza pressione."





translate italian juliaep5s1_c4887bf8:


    julia "Certo, perché no?"





translate italian juliaep5s1_a57d0efc:


    d "Facciamo in modo che sia una bella giornata."





translate italian juliaep5s1_886abaf6:


    d "Oh!"





translate italian juliaep5s1_1863f5f9:


    dpense "Perfetto. Farà un figurone sulla mia pagina."





translate italian juliaep5s1_4d155d2a:


    julia "Bene, hai iniziato alla grande. Pensi di continuare così?"





translate italian juliaep5s1_6cf2bb35:


    d "Vedremo. Chissà? Magari ne inizierai uno anche tu."





translate italian juliaep5s1_d9dfa20b:


    julia "Non così in fretta. Vediamo se il tuo vale la pena di essere seguito."





translate italian juliaep5s1_8b1d5c54:


    julia "È già tardi. Devo andare."





translate italian juliaep5s1_dd72b008:


    d "Lasciami venire con te. Non voglio che tu ti metta nei guai."





translate italian juliaep5s1_5ac0d64c:


    julia "Va bene. Grazie."





translate italian juliaep5s1_231f5bec:


    julia "Grazie per avermi accompagnato a casa. Era da tanto che non trascorrevo una serata così."





translate italian juliaep5s1_c51ede48:


    d "È stato fantastico passare del tempo con te. Spero che potremo rifarlo presto."





translate italian juliaep5s1_2d141c15:


    julia "Anch'io. Ora mi sento più rilassato, grazie a te."





translate italian juliaep5s1_5cc17a98:


    d "È stato bello parlare con te. Ora sento di capirti meglio."





translate italian juliaep5s1_f6e0d13e:


    julia "Che dolce! Ho imparato molto anche su di te stasera."





translate italian juliaep5s1_e8be2aee:


    d "Non vedo l'ora della prossima partita. Sarà fantastico sapere che stiamo lavorando insieme per qualcosa di così grande."





translate italian juliaep5s1_be275e87:


    julia "È rassicurante sapere che sei così concentrato. Cercherò di tenere il passo!"





translate italian juliaep5s1_687f426a:


    d "Era da un po' che non mi sentivo così a mio agio. Sono davvero contento che ci siamo riusciti."





translate italian juliaep5s1_e0e6383d:


    julia "Anch'io. Provo la stessa cosa."





translate italian juliaep5s1_e424cf81:


    d "Mi sembra giusto..."





translate italian juliaep5s1_60e205e5:


    julia "Sì... Questa volta non è stato rubato."





translate italian juliaep5s1_5769e4a9:


    d "Buonanotte, Julia."





translate italian juliaep5s1_5dfa7b90:


    julia "Buona notte, [name]."




translate italian juliaep5s1_012b7a2a:


    d "Beh, prima è successa una cosa a cui ho pensato."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
