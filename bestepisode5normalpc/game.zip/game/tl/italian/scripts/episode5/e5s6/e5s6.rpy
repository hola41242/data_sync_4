



translate italian e5s6_3fb2abb2:


    orushi "Miei cari concorrenti..."


translate italian e5s6_ff4534d8:


    orushi "Siete rimasti in venti."


translate italian e5s6_6b430812:


    orushi "Venti vite. Venti percorsi. Venti storie intrecciate."


translate italian e5s6_d91dcc73:


    orushi "Ma oggi... solo una manciata di persone andrà avanti."


translate italian e5s6_266e4fc3:


    orushi "Davanti a ciascuno di voi c'è una scatola sigillata."


translate italian e5s6_b65d1e21:


    orushi "Alcune di queste caselle contengono un gettone di selezione."


translate italian e5s6_998449ef:


    orushi "Altri sono vuoti."


translate italian e5s6_ea1631bc:


    orushi "Non vi dirò quanti gettoni ci sono."


translate italian e5s6_97ca7c04:


    orushi "Ciò che ti offro è una scelta. Solo una."


translate italian e5s6_1f277e8c:


    orushi "Ognuno di voi avrà l'opportunità di guardare di nascosto all'interno di una scatola..."


translate italian e5s6_0e53d205:


    orushi "...qualsiasi scatola tranne la tua."


translate italian e5s6_4cc4a23d:


    orushi "Potete farlo solo una volta."


translate italian e5s6_381bae70:


    orushi "Poi ognuno di voi prenderà una decisione:"


translate italian e5s6_f326ea5b:


    orushi "Tieni la tua scatola e abbi fiducia nella tua fortuna,"


translate italian e5s6_8b46f9ac:


    orushi "oppure scambiare le scatole con un altro giocatore."


translate italian e5s6_24201288:


    orushi "Ma ricordate..."


translate italian e5s6_1a15c350:


    orushi "Una scatola scambiata perde la sua certezza."


translate italian e5s6_bcb0b2a5:


    orushi "E una scatola conservata... potrebbe non essere altro che un miraggio."


translate italian e5s6_dea039ff:


    orushi "Riflettete attentamente. Perché questo non è solo un test di selezione..."


translate italian e5s6_89c37bde:


    orushi "È il riflesso di tutto ciò che avete imparato da quando sei arrivato qui."


translate italian e5s6_4f24f925:


    dpense "Devo scegliere una casella da spuntare... ma non la mia."


translate italian e5s6_observation_5a3b9d43_1:


    d "E quelli che non conosciamo?"


translate italian e5s6_observation_e50286b8_1:


    ruby "Non li conosciamo. Non possiamo fare affidamento sulle loro azioni perché non sappiamo come funzionano..."


translate italian e5s6_observation_2095c829_1:


    ruby "Non sappiamo quanti si qualificheranno alla fine, quindi..."


translate italian e5s6_observation_ac26ecd3:


    dpense "Tutti fissano la loro scatola... non sanno bene cosa farne."


translate italian e5s6_observation_810d625f:


    dpense "Nessuno sa quanti gettoni ci siano."


translate italian e5s6_observation_27801cb9:


    dpense "Sembra che stiano tutti cercando di scoprire qualche regola nascosta dietro tutto questo."


translate italian e5s6_observation_e657325b:


    mad "Quindi... dovremmo guardare una scatola per aiutarci a decidere?"


translate italian e5s6_observation_75b7e148:


    s "O forse è solo per confonderci le idee. Potrebbe essere una trappola totale..."


translate italian e5s6_observation_f72e8743:


    grace "Non mi piace. Troppo vago. Sembra che ci stiano prendendo in giro."


translate italian e5s6_observation_5d544f10:


    dpense "Ruby non dice niente."


translate italian e5s6_observation_38f0c86d:


    dpense "Sta solo guardando. Come sempre."


translate italian e5s6_observation_4fc8cc42:


    ruby "È tutta una questione di percezione. Questa volta non si tratta di un enigma logico."


translate italian e5s6_observation_538ff4e2:


    ruby "La vera domanda non è cosa vediamo noi. È cosa pensano di aver visto tutti gli altri."


translate italian e5s6_observation_fcd6c3eb:


    dpense "Ha ragione. Ma capisco che sta pensando a qualcosa di più profondo..."


translate italian e5s6_observation_3c9bb22b:


    ruby "Hai già scelto una casella da spuntare?"


translate italian e5s6_observation_3f2cdd4d:


    d "Non ancora. Voglio raccogliere le informazioni più utili."


translate italian e5s6_observation_4057739d:


    ruby "Lo stesso. Se combiniamo ciò che vediamo con ciò che fanno gli altri, forse possiamo individuare uno schema."


translate italian e5s6_observation_437737f7:


    d "Ti piace la logica comportamentale? Istinto contro ragionamento?"


translate italian e5s6_observation_27bf0648:


    ruby "Esatto. Non è una questione di scatola in sé. È una questione di cosa credono ci sia dentro... e cosa fanno dopo."


translate italian e5s6_observation_a57c028f:


    dpense "Ora il mio cervello si sta attivando. Ho capito a cosa mira."


translate italian e5s6_observation_6957997a:


    d "Quindi facciamo squadra. In silenzio."


translate italian e5s6_observation_b196b7bf:


    ruby "Silenziosamente."


translate italian e5s6_observation_5a3b9d43:


    d "E quelli che non conosciamo?"


translate italian e5s6_observation_e50286b8:


    ruby "Non li conosciamo. Non possiamo fare affidamento sulle loro azioni perché non sappiamo come funzionano..."


translate italian e5s6_observation_2095c829:


    ruby "Non sappiamo quanti si qualificheranno alla fine, quindi..."


translate italian e5s6_observation_e0ba5112:


    ruby "Meglio ignorarli per semplificare le cose."


translate italian e5s6_observation_ed6d2f04:


    ruby "Dobbiamo rimanere concentrati. Non abbiamo molte informazioni, ma chi agisce troppo in fretta... è quello che farà confusione."


translate italian e5s6_observation_294017f1:


    dpense "Ha quel tono calmo e analitico che ormai riconosco. Ha già un piano."


translate italian e5s6_observation_47cd4a00:


    ruby "meglio ignorarli per semplificare le cose."


translate italian e5s6_observation_9badd16e:


    dpense "Tutti guardano. Valutano. Calcolano."


translate italian e5s6_observation_eaf92f49:


    dpense "Ruby è immersa nei suoi pensieri. I suoi occhi scrutano la stanza, poi si posano su di me."


translate italian e5s6_observation_a9a53a3f:


    ruby "Hai notato come alcune persone tengono strette le loro scatole, anche senza aprirle?"


translate italian e5s6_observation_f2d439ff:


    d "Forse stanno giocando sul sicuro. O stanno bluffando."


translate italian e5s6_observation_68d0c586:


    ruby "Oppure cercare di far credere agli altri che sanno già cosa fare."


translate italian e5s6_observation_f4e1452b:


    d "Quindi, un bluff."


translate italian e5s6_observation_4132040c:


    ruby "O eccesso di sicurezza. Ma è nelle prime mosse che si commettono gli errori più stupidi."


translate italian e5s6_observation_71bf35f5:


    dpense "Colgo un accenno di sorriso sulle sue labbra. Sta decodificando i comportamenti. E lo sto facendo anch'io."


translate italian e5s6_observation_5bd18ff2:


    ruby "Cosa ne pensi della postura di Steven?"


translate italian e5s6_observation_3ded11ad:


    d "O ha paura di fare la scelta sbagliata, oppure aspetta che qualcun altro faccia la prima mossa."


translate italian e5s6_observation_8f485c95:


    ruby "È quello che penso anch'io..."


translate italian e5s6_observation_e915c292:


    dpense "Non parliamo molto. Ma ci osserviamo a vicenda. Riflettiamo sulle cose. Insieme."


translate italian e5s6_observation_13770013:


    emerick "Stai scherzando?!"


translate italian e5s6_observation_ef379675:


    emerick "Hanno bisbigliato per cinque minuti e nessuno ha detto niente?!"


translate italian e5s6_observation_0c8161c2:


    emerick "Questo è un dannato test e tu stai lasciando che questi due escogitino un piccolo piano romantico o qualcosa del genere?!"


translate italian e5s6_observation_750b2f38:


    ruby "Sei tu quello che urla, Emerick. Hai paura di perdere o cosa?"


translate italian e5s6_observation_211ec9af:


    emerick "Almeno non sto barando! Sto giocando da SOLO. Come si deve!"


translate italian e5s6_observation_37ba782e:


    dpense "Sta perdendo la testa, ma in fondo penso che stia perdendo soprattutto il controllo."


translate italian e5s6_observation_de527c80:


    orushi "Finitela."


translate italian e5s6_observation_2dfe950f:


    orushi "Giocatore Emerick, stai tranquillo: sento e vedo tutto."


translate italian e5s6_observation_c89c0bc6:


    orushi "E fidatevi di me: saprò esattamente chi merita di andare avanti."


translate italian e5s6_observation_5cc5d10c:


    orushi "Non ho mai proibito ai candidati di parlare tra loro."


translate italian e5s6_observation_ae49718d:


    orushi "Ciò che è vietato è condividere informazioni sul contenuto delle scatole: quelle che hanno aperto o quelle che hanno controllato."


translate italian e5s6_observation_db73bb00:


    orushi "Ma parliamo di strategia, impressioni o comportamento?"


translate italian e5s6_observation_4d64c97d:


    orushi "Non solo è consentito... è anche rivelatore."


translate italian e5s6_observation_72e35eab:


    orushi "E vi ricordo: questa è una sfida individuale."


translate italian e5s6_observation_e1efcdb2:


    orushi "Potete parlare quanto volete, ma non aspettatevi di essere salvati insieme."


translate italian e5s6_observation_c1150fb8:


    orushi "Alcuni parleranno, altri mentiranno. E a volte... tutti perdono."


translate italian e5s6_observation_3787fbaf:


    orushi "Dal momento che sembri così ansioso di dare il tono, Emerick..."


translate italian e5s6_observation_96383100:


    orushi "Partirai per primo."


translate italian e5s6_observation_b9c2f3ff:


    emerick "Finalmente."


translate italian e5s6_observation_6b3e59a8:


    emerick "Controllerò..."


translate italian e5s6_observation_3b1c981c:


    emerick "La scatola di Ruby."


translate italian e5s6_observation_ee17831d:


    dpense "La sta provocando."


translate italian e5s6_observation_ea3dd448:


    emerick "Mhhhh. Affascinante."


translate italian e5s6_observation_d2c80a33:


    dpense "Lo sta deliberatamente lasciando sul vago. Non può farne a meno."


translate italian e5s6_observation_599e0fed:


    orushi "Giocatrice Madison. La tua mossa."


translate italian e5s6_observation_bb118b62:


    mad "Bene, eccomi qui."


translate italian e5s6_observation_ea76f770:


    dpense "Sento la tensione in lei."


translate italian e5s6_observation_1965421c:


    ruby "È nervosa. Troppo tesa per rischiare un bluff."


translate italian e5s6_observation_bfd462c5:


    ruby "Spunta la casella di qualcun altro per sentirsi più sicura."


translate italian e5s6_observation_58193e62:


    mad "Io... spunterò una casella. Quella di Steven."


translate italian e5s6_observation_da7e21f9:


    dpense "Si avvicina cautamente al podio di Steven, solleva leggermente la scatola, poi la rimette giù altrettanto velocemente."


translate italian e5s6_observation_0a716f94:


    dpense "Nessuna parola. Nemmeno uno sguardo verso di lui."


translate italian e5s6_observation_413b4e4d:


    orushi "Giocatore Steven. Il tuo turno."


translate italian e5s6_observation_fe589a7d:


    dpense "Steven si alza di scatto. Non gli piace perdere tempo."


translate italian e5s6_observation_0af6d3e4:


    dpense "Cammina intorno al cerchio e si ferma davanti al podio di Madison."


translate italian e5s6_observation_ab0d797a:


    d "Lui spunterà la sua casella?"


translate italian e5s6_observation_5529a69b:


    ruby "È una forma di ritorsione. A seconda di cosa lei fa con la sua scatola, lui vuole fare un controllo incrociato."


translate italian e5s6_observation_39cc181d:


    ruby "Lui ha il vantaggio di poter scegliere dopo di lei."


translate italian e5s6_observation_59acf03b:


    dpense "Steven solleva lentamente il coperchio... poi lo chiude altrettanto velocemente."


translate italian e5s6_observation_270d2683:


    dpense "Nessuna parola. Nessuno sguardo. Torna al suo posto."


translate italian e5s6_observation_73397bdd:


    s "Questo è tutto ciò di cui ho bisogno."


translate italian e5s6_observation_0dfaa844:


    ruby "Sta bluffando. Oppure è sicuro della sua lettura."


translate italian e5s6_observation_92239153:


    d "O forse vuole solo confondere Madison."


translate italian e5s6_observation_f61ca382:


    orushi "Giocatrice Sofia. Tocca a te."


translate italian e5s6_observation_2eff792a:


    dpense "Blue si avvicina con calma. Nessuno stress visibile."


translate italian e5s6_observation_c1e009d5:


    dpense "Entra nel cerchio e i suoi occhi passano lentamente da un podio all'altro."


translate italian e5s6_observation_7ecb088b:


    dpense "Poi si ferma davanti a me."


translate italian e5s6_observation_c407ce85:


    ruby "OH."


translate italian e5s6_observation_d08b77f3:


    d "Lei... metterà la spunta sulla mia casella?"


translate italian e5s6_observation_c2a8c7bc:


    dpense "Si sporge in avanti. Solleva lentamente il coperchio..."


translate italian e5s6_observation_ef7b11e8:


    dpense "...poi lo chiude, senza dire una parola."


translate italian e5s6_observation_371e844a:


    dpense "Lei non parla. Ma per mezzo secondo i suoi occhi incontrano i miei."


translate italian e5s6_observation_340770b4:


    dpense "Mi rivolge un sorriso. Sottile. Debole. Ma c'è."


translate italian e5s6_observation_a4022d3c:


    ruby "Pensi che sia un messaggio?"


translate italian e5s6_observation_62a604ab:


    d "Non ne ho idea. È sempre difficile da capire."


translate italian e5s6_observation_6d29929a:


    ruby "O forse vuole che tu lo ottenga senza dire nulla."


translate italian e5s6_observation_a51faf27:


    dpense "Torna al suo posto, ancora calma come sempre."


translate italian e5s6_observation_c790e247:


    orushi "Giocatore Hector. La tua mossa."


translate italian e5s6_observation_7f24b98b:


    dpense "Hector si alza lentamente. Ridacchia guardandosi intorno."


translate italian e5s6_observation_f5d54b81:


    hec "Bene... credo che dovrò giocare."


translate italian e5s6_observation_ec149967:


    dpense "Passeggia nel cerchio, prendendosi il suo tempo."


translate italian e5s6_observation_a90e38aa:


    dpense "Si ferma davanti al podio di Julia."


translate italian e5s6_observation_0c545453:


    d "Lui spunterà la sua casella?"


translate italian e5s6_observation_82db18bb:


    ruby "Forse vuole confonderla. O semplicemente ricordarle che la sta guardando."


translate italian e5s6_observation_0ef07917:


    dpense "Solleva il coperchio, si prende un momento per guardare, poi lo chiude con noncuranza."


translate italian e5s6_observation_31cf088f:


    dpense "Poi torna indietro con un sorriso furbo sul volto."


translate italian e5s6_observation_5e717452:


    hec "Interessante..."


translate italian e5s6_observation_fd6f595a:


    dpense "Julia non sussulta."


translate italian e5s6_observation_e827eecb:


    dpense "Ma lei continua a fissarlo."


translate italian e5s6_observation_e8667989:


    orushi "Giocatore Kira. Tocca a te."


translate italian e5s6_observation_048b202a:


    dpense "Kira si alza in silenzio. Il suo volto, come sempre, è indecifrabile."


translate italian e5s6_observation_96962f07:


    dpense "Non guarda Emerick. Non guarda me. Si dirige verso Ben."


translate italian e5s6_observation_125f4494:


    ruby "Classico. Bersaglio facile."


translate italian e5s6_observation_7ce813bd:


    d "Pensi che stia andando sul sicuro?"


translate italian e5s6_observation_6702fa5c:


    ruby "Oppure sa esattamente cosa sta facendo."


translate italian e5s6_observation_dc7ec2e7:


    dpense "Kira si china, apre la scatola di Ben, la studia con calma..."


translate italian e5s6_observation_92f236ad:


    dpense "Poi lo chiude con un movimento netto."


translate italian e5s6_observation_dab9380a:


    dpense "Non un'ombra di emozione sul suo viso. Torna al suo posto senza dire una parola."


translate italian e5s6_observation_f77cc5d4:


    orushi "Giocatore Mac. La tua mossa."


translate italian e5s6_observation_99fb4c28:


    dpense "Mac si guarda intorno per un secondo, con aria assente."


translate italian e5s6_observation_b75228ec:


    mac "Bene... cerchiamo di semplificare."


translate italian e5s6_observation_7152bc37:


    dpense "Si avvicina al podio di Ben e dà una rapida occhiata all'interno."


translate italian e5s6_observation_85d5655c:


    dpense "Poi torna indietro senza dire nulla."


translate italian e5s6_observation_86216c3d:


    ruby "Probabilmente pensa che Ben sia troppo stupido per tenere un gettone."


translate italian e5s6_observation_15df2888:


    d "Oppure troppo stupido per sapere cosa ha visto."


translate italian e5s6_observation_5a13be4e:


    orushi "Giocatore Ben. Tocca a te."


translate italian e5s6_observation_028daeab:


    dpense "Ben guarda Mac, poi sorride come un idiota."


translate italian e5s6_observation_a6cd2453:


    ben "Stesso discorso, fratello."


translate italian e5s6_observation_1ca31caf:


    dpense "Si avvicina direttamente alla scatola di Mac e sbircia dentro come se fosse uno scherzo interno."


translate italian e5s6_observation_da8b37ca:


    dpense "Ritorna al suo posto, visibilmente soddisfatto di sé, anche se nessuno sa perché."


translate italian e5s6_observation_ea8cbfb9:


    ruby "Stallo."


translate italian e5s6_observation_040a0511:


    d "Zero cervelli, finta alleanza."


translate italian e5s6_observation_c48f2526:


    orushi "Giocatrice Elizabeth. Il tuo turno."


translate italian e5s6_observation_68cfe16d:


    dpense "Red resta lì senza dire una parola. Ancora con quel suo atteggiamento calmo e gelido... ma tutto in lei sembra calcolato."


translate italian e5s6_observation_0d9ef439:


    dpense "Gira lentamente la testa verso Hector. La sua scelta sorprende più di qualcuno."


translate italian e5s6_observation_b961d1e8:


    beth "Sceglierò la casella di Hector."


translate italian e5s6_observation_645e996e:


    dpense "Cammina con calma, solleva il coperchio, controlla il contenuto senza mostrare la minima emozione e torna al suo posto."


translate italian e5s6_observation_a02b9a4f:


    ruby "Hector? Sta attaccando il suo stesso gruppo?"


translate italian e5s6_observation_332b3b1b:


    d "È rischioso..."


translate italian e5s6_observation_3c12f12d:


    ruby "Oppure geniale. Colpire una delle pedine di Emerick per indebolire la struttura senza dover combattere direttamente."


translate italian e5s6_observation_775d2b2b:


    ruby "Quello che non capisco è... perché?"


translate italian e5s6_observation_6bfc2d3e:


    dpense "Il rosso colpisce senza fare rumore... ma ogni colpo va a segno."


translate italian e5s6_observation_5fc4ea0c:


    dpense "Fissa Grace a lungo, quasi come se la stesse osservando dall'alto."


translate italian e5s6_observation_a6eb1408:


    beth "Darò un'occhiata alla scatola di Grace."


translate italian e5s6_observation_3451a2af:


    dpense "Si avvicina, guarda dentro la scatola di Grace, poi torna indietro senza dire nulla."


translate italian e5s6_observation_efd26043:


    ruby "Sta prendendo di mira Grace..."


translate italian e5s6_observation_22cc5438:


    dpense "Il Rosso non mostra mai le sue carte. Gioca da solo, a modo suo. E a volte, è tutto ciò che serve."


translate italian e5s6_observation_815d5c0f:


    orushi "Giocatrice Julia. La tua mossa."


translate italian e5s6_observation_250197d6:


    dpense "Julia si alza lentamente. I suoi occhi scrutano la stanza come se cercasse di leggere i pensieri di tutti."


translate italian e5s6_observation_5f263a93:


    dpense "Nessuna fretta. Lei va avanti, concentrata."


translate italian e5s6_observation_957f3dc7:


    julia "Spunto la casella di Ben."


translate italian e5s6_observation_4b1a57a5:


    dpense "Dà una rapida occhiata, poi chiude delicatamente la scatola e torna al suo posto."


translate italian e5s6_observation_5551f768:


    ruby "Interessante."


translate italian e5s6_observation_9a9172ac:


    d "Ti aspettavi che scegliesse Ben?"


translate italian e5s6_observation_ad3c63ea:


    ruby "È silenzioso. Passa inosservato. Esattamente il tipo di persona che la gente ignora. Il che lo rende una fonte di informazioni perfetta."


translate italian e5s6_observation_f2362b94:


    ruby "E poiché Ben guardava Mac, forse stava seguendo una catena. Ottenendo una lettura più ampia rispetto alle altre."


translate italian e5s6_observation_bab9be02:


    dpense "Julia è sempre calma... ma sa esattamente dove sta andando."


translate italian e5s6_observation_37d8e615:


    orushi "Giocatore Ruby. Il tuo turno."


translate italian e5s6_observation_bdaa9598:


    dpense "Ruby rimane immobile per un attimo. Come se stesse calcolando un'ultima variabile prima di muoversi."


translate italian e5s6_observation_87fb0482:


    d "Sai già chi sceglierai?"


translate italian e5s6_observation_84766a69:


    ruby "Quasi. Voglio solo fare un controllo incrociato."


translate italian e5s6_observation_5910b51b:


    d "Stai pensando a Kira?"


translate italian e5s6_observation_677385f2:


    ruby "Guardò Ben. Era la scelta più sicura possibile nella stanza."


translate italian e5s6_observation_090f49ec:


    d "Vuoi capire perché ha scelto lui?"


translate italian e5s6_observation_f0c09d26:


    ruby "Forse. Quando si tratta di Kira... anche i movimenti più semplici possono far parte di qualcosa di più profondo."


translate italian e5s6_observation_a83de9ab:


    dpense "Si alza senza dire una parola e si dirige verso il podio di Kira."


translate italian e5s6_observation_94cb22f1:


    dpense "Apre la scatola con attenzione, la studia a lungo, poi la chiude."


translate italian e5s6_observation_3b3f1873:


    dpense "Non mostra nulla, ma so che sta memorizzando quei dati nella sua mente."


translate italian e5s6_observation_6744b0d6:


    ruby "Bene."


translate italian e5s6_observation_ca66aafa:


    dpense "Una sola parola. Tono neutro. Ma capisco che ha appena trovato il pezzo che le mancava."


translate italian e5s6_observation_8768f6ed:


    orushi "Giocatore [name] La tua mossa."


translate italian e5s6_observation_f05fbf9a:


    dpense "È il mio turno."


translate italian e5s6_observation_44642eca:


    dpense "Solo una mossa. Una casella da spuntare. E non la mia."


translate italian e5s6_observation_2aef89b8:


    dpense "Devo fare la scelta giusta."


translate italian e5s6_observation_525eb106:


    ruby "Sai cosa stiamo cercando. Comportamento, connessioni, verifiche incrociate. Scegli con la testa, non con il cuore."


translate italian e5s6_observation_d935a521:


    d "Non preoccuparti. Ho imparato la lezione."


translate italian observebox_eb2bc0fa_1:


    dpense "Mi alzo e con calma scambio la mia scatola con la sua."


translate italian observebox_eb2bc0fa_2:


    dpense "Mi alzo e con calma scambio la mia scatola con la sua."


translate italian observebox_974ba520_1:


    orushi "Token confermato."


translate italian observebox_974ba520_2:


    orushi "Token confermato."


translate italian observebox_974ba520_3:


    orushi "Token confermato."


translate italian observebox_974ba520_4:


    orushi "Token confermato."


translate italian observebox_f61ca382_1:


    orushi "Giocatrice Sofia. Tocca a te."


translate italian observebox_ecf3d79e_1:


    beth "Ovviamente."


translate italian observebox_e8ed82ca_1:


    orushi "…C'è un gettone all'interno della tua scatola."


translate italian observebox_e9754cba_1:


    ruby "..."


translate italian observebox_ac36ddb9_1:


    orushi "…La tua casella è vuota."


translate italian observebox_ac36ddb9_2:


    orushi "…La tua casella è vuota."


translate italian observebox_b0cd8174_1:


    sofia "NO...!"


translate italian observebox_88a75c4d_1:


    sofia "NO!"


translate italian observebox_5dced416_1:


    orushi "Hmm?"


translate italian observebox_c94f114d_1:


    sofia "Ho un gettone speciale... il gettone Sacrificio."


translate italian observebox_f852caa8_1:


    sofia "Voglio cedergli il mio posto."


translate italian observebox_71eb5446_1:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."


translate italian observebox_f452c162_1:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"


translate italian observebox_a5cda67b_1:


    sofia "Per favore... resta con me."


translate italian observebox_53155274_1:


    dpense "Sofia..."


translate italian observebox_a0b873b8_1:


    dpense "Lei... sta piangendo per me?"


translate italian observebox_77664c99:


    dpense "Mi alzo con calma e mi avvicino [chosenbox] la scatola di."


translate italian observebox_989aee24:


    dpense "Sollevo delicatamente il coperchio…"


translate italian observebox_2288c22f:


    dpense "...osservo attentamente."


translate italian observebox_dfc06a98:


    dpense "Poi lo chiudo. Non deve scivolare niente."


translate italian observebox_f05d166d:


    dpense "Ho quello che mi serve. Per ora."


translate italian observebox_c38e4058:


    orushi "Grace. Tocca a te."


translate italian observebox_658e3be4:


    ruby "Non perderà tempo. Andrà con un ragazzo che considera instabile."


translate italian observebox_917fb4dc:


    d "Mac, pensi?"


translate italian observebox_6e20a2d6:


    ruby "Non ha un gran cervello. E sempre all'ombra di Steven o Emerick."


translate italian observebox_4226a24e:


    dpense "Si dirige dritta verso la scatola di Mac."


translate italian observebox_3348cbd3:


    dpense "Solleva il coperchio, guarda dentro e poi lo chiude immediatamente."


translate italian observebox_a24f5d94:


    dpense "Non una parola. Torna al suo posto, con un'espressione assente."


translate italian observebox_866951a7:


    ruby "Sta cercando informazioni certe. E non le condividerà."


translate italian observebox_6b29c0bb:


    d "Suona da solista... ma sempre con un senso dell'onore."


translate italian observebox_16f332a0:


    dpense "Posso dire che ha visto esattamente ciò di cui aveva bisogno."


translate italian observebox_23140c05:


    orushi "Concorrenti…"


translate italian observebox_804938c3:


    orushi "Avete avuto tutti il tempo di osservare. Di analizzare."


translate italian observebox_a0ebc701:


    orushi "Adesso è il momento di prendere una decisione."


translate italian observebox_6b0be950:


    orushi "Ognuno di voi farà la sua mossa."


translate italian observebox_89d8e2cd:


    orushi "Quando arriva il vostro turno, avrete due opzioni:"


translate italian observebox_5edf0a7b:


    orushi "O tenere la scatola davanti..."


translate italian observebox_63f29e78:


    orushi "Oppure scambia due caselle visibili."


translate italian observebox_9785ac7e:


    orushi "Ma fate attenzione a questo:"


translate italian observebox_3227b1eb:


    orushi "Quando un giocatore scambia la propria scatola con quella di qualcun altro, quella scatola diventa intoccabile per il round successivo."


translate italian observebox_0c685453:


    orushi "In altre parole... non puoi prendere una scatola che qualcuno ha appena preso nel turno precedente."


translate italian observebox_77633d3e:


    orushi "Non è possibile nemmeno riprendere la propria scatola dopo uno scambio."


translate italian observebox_42c239e2:


    orushi "Rifletti attentamente. Le apparenze spesso ingannano..."


translate italian observebox_c3e81c73:


    orushi "E a volte una buona decisione può essere rovinata da una sola esitazione."


translate italian observebox_bdbce856:


    orushi "Giocatore Emerick. Tocca a te."


translate italian observebox_b989a26c:


    dpense "Emerick si alza. Si alza con la sua solita arroganza, come un profumo scadente che non si toglie mai."


translate italian observebox_b3d683ba:


    dpense "Esamina attentamente il cerchio, osservando ogni volto come se cercasse un punto debole."


translate italian observebox_a987d25e:


    emerick "Va bene... non ci girerò intorno."


translate italian observebox_29ada277:


    dpense "Si alza, si dirige verso Madison... poi devia all'ultimo secondo."


translate italian observebox_eede833e:


    dpense "Cammina dritto verso Ruby."


translate italian observebox_5e506b55:


    dpense "Lui si ferma davanti a lei con un sorriso compiaciuto."


translate italian observebox_627dc3c7:


    emerick "Vediamo se la tua calma nasconde qualcosa di utile."


translate italian observebox_c8a399c1:


    dpense "Emerick porge la sua scatola a Ruby senza dire una parola e prende la sua in cambio."


translate italian observebox_fc9f6b21:


    dpense "Ruby non batte ciglio. Accetta lo scambio senza mostrare la minima emozione."


translate italian observebox_e9ab0fe7:


    dpense "Ma sento che qualcosa si sta fissando nella sua mente. Sta già analizzando."


translate italian observebox_cba3c434:


    dpense "Se ne va con la scatola di Ruby come se avesse appena vinto un duello silenzioso."


translate italian observebox_599e0fed:


    orushi "Giocatrice Madison. La tua mossa."


translate italian observebox_c13cba8f:


    dpense "Si alza in fretta. Troppo in fretta per qualcuno che ha un piano perfettamente definito."


translate italian observebox_6be5b99f:


    dpense "Ma lei non trema. Cammina con la stessa grinta che ha sempre nelle partite."


translate italian observebox_c36c10e6:


    ruby "Corre d'istinto, ma sa che tutti gli occhi sono puntati su di lei."


translate italian observebox_e4be989b:


    dpense "Lancia un'occhiata a Steven, poi alla sua scatola."


translate italian observebox_4e2838a8:


    mad "Io tengo il mio."


translate italian observebox_72f07918:


    dpense "È una scelta coraggiosa. Quasi una sfida. Come se stesse dimostrando di non aver bisogno di nessuno."


translate italian observebox_ee5fc84f:


    ruby "Orgogliosa, impulsiva... ma non spericolata. Cerca di mantenere il controllo a tutti i costi."


translate italian observebox_412e3851:


    ruby "Ma questo significa anche che non le piaceva ciò che vedeva nella scatola di Steven."


translate italian observebox_6d8f6f7f:


    orushi "Giocatore Steven. La tua mossa."


translate italian observebox_401632f6:


    dpense "Steven si alza, sicuro di sé come sempre."


translate italian observebox_83e6273c:


    dpense "Fissa la sua scatola per un secondo... poi gira la testa verso Madison."


translate italian observebox_2236a400:


    d "Pensi che lui...?"


translate italian observebox_413119fd:


    ruby "Ha visto la sua scatola. Sa esattamente cosa c'è dentro."


translate italian observebox_2a6337b9:


    dpense "Lui cammina avanti senza esitazione. Dritto verso di lei."


translate italian observebox_5a81e0fe:


    s "Mi dispiace, Madison."


translate italian observebox_44297608:


    dpense "Lui afferra la scatola davanti a lei e la scambia con la sua, senza darle il tempo di reagire."


translate italian observebox_c0039868:


    mad "Che cosa?!"


translate italian observebox_96d59479:


    s "Questo è il gioco."


translate italian observebox_ade58ffd:


    dpense "Steven se ne va con la scatola di Madison. Nessuno si volta indietro."


translate italian observebox_57b7099a:


    mad "Accidenti..."


translate italian observebox_94393724:


    dpense "Stringe la mascella. Ma lo sopporta."


translate italian observebox_63b20ae4:


    d "Pensi che stia bluffando?"


translate italian observebox_211642e4:


    ruby "No. Lui gioca in base a ciò che ha visto."


translate italian observebox_72229415:


    d "Lei ha guardato la sua scatola, giusto?"


translate italian observebox_d2e01c1e:


    ruby "Esatto. E dopo, decise di tenersi il suo."


translate italian observebox_9a8af104:


    ruby "Quindi Steven deve aver visto un gettone."


translate italian observebox_f61ca382:


    orushi "Giocatrice Sofia. Tocca a te."


translate italian observebox_31deb386:


    dpense "Blue si alza con calma. Il suo sguardo scruta brevemente la stanza, poi si fissa dritto davanti a sé."


translate italian observebox_b936dcd0:


    dpense "Cammina con grazia, ma senza fretta. Ogni passo sembra intenzionale."


translate italian observebox_729e1a7a:


    dpense "Si sta dirigendo verso di me."


translate italian observebox_07dcdb93:


    dpense "Nessuna deviazione. Nessuno sguardo a nessun'altra scatola."


translate italian observebox_13e72a78:


    dpense "Si ferma davanti al mio podio. Mi guarda per un secondo."


translate italian observebox_6fcaa1ce:


    sofia "Io tengo il mio..."


translate italian observebox_167f365c:


    sofia "...ma volevo che tu lo sapessi."


translate italian observebox_e2ff0077:


    dpense "Il suo tono è dolce. Quasi intimo."


translate italian observebox_976665f6:


    dpense "Non un comando, non una supplica. Una dichiarazione. Semplice e diretta."


translate italian observebox_3197e801:


    ruby "Sta mandando un messaggio. È chiaro."


translate italian observebox_993daf80:


    d "Vuole che io capisca cosa ha visto. O cosa pensa di aver visto."


translate italian observebox_571c632a:


    dpense "Blue torna al suo posto, senza voltarsi indietro. Ma le sue parole risuonano ancora."


translate italian observebox_04ba7eb9:


    dpense "Si ferma per un secondo, incerta."


translate italian observebox_11641847:


    dpense "Poi si dirige verso il suo box."


translate italian observebox_ddbe835d:


    dpense "Nessuna parola. Nessuno sguardo nella mia direzione. Niente."


translate italian observebox_83dc8a5f:


    dpense "Appoggia una mano sul podio, chiude gli occhi per un attimo..."


translate italian observebox_7e0ec825:


    dpense "Poi si siede."


translate italian observebox_4bc5e1f8:


    ruby "Lei si tiene la sua."


translate italian observebox_6936d7e2:


    d "Ma non parlò con nessuno."


translate italian observebox_225e24fb:


    ruby "Quel silenzio potrebbe far parte della sua strategia."


translate italian observebox_d1f02b5d:


    dpense "Il silenzio torna a calare, un po' più pesante."


translate italian observebox_e2133619:


    dpense "Ruby socchiude gli occhi. Sta pensando. Sta collegando i puntini."


translate italian observebox_b4b02729:


    ruby "COSÌ…"


translate italian observebox_acb63775:


    ruby "Emerick ha scambiato la sua scatola con la mia. Una mossa sicura."


translate italian observebox_40f0e2e3:


    ruby "Madison guardò Steven. Poi tenne il suo."


translate italian observebox_ef4a94fe:


    ruby "Steven vide quello di Madison. E lo scambiò."


translate italian observebox_270f06e7:


    ruby "Blue ha spuntato la tua casella... e ha scelto di mantenere la sua."


translate italian observebox_636083ef:


    ruby "E adesso tocca a Hector."


translate italian observebox_8c74fffe:


    dpense "Ruby prende un piccolo respiro, come se stesse ricalibrando tutto."


translate italian observebox_1ad285c6:


    ruby "Guardò nella scatola di Julia. Sa cosa c'è dentro."


translate italian observebox_4870c84b:


    ruby "Ha tre opzioni:"


translate italian observebox_d098fb47:


    ruby "O Julia ha un gettone e lui ci prova."


translate italian observebox_89c3fa55:


    ruby "Oppure non lo fa, e lui pensa che sia meglio tenerselo."


translate italian observebox_dddf5678:


    ruby "Oppure… crede che una delle scatole già scambiate ora abbia più valore."


translate italian observebox_e4a4650a:


    d "Come quello che Steven ha preso da Madison."


translate italian observebox_c31975d7:


    ruby "Esatto. Forse pensava che ci fosse un gettone, e Steven l'ha fiutato."


translate italian observebox_09f2bc2c:


    ruby "In tal caso, se facesse uno scambio con Steven, otterrebbe la vecchia scatola di Madison."


translate italian observebox_69873bef:


    ruby "E il gettone all'interno. Se ce n'era uno."


translate italian observebox_ab5187e7:


    dpense "Ma oserebbe farlo?"


translate italian observebox_e1ed004a:


    ruby "È Hector. Correre grandi rischi non lo spaventa."


translate italian observebox_8ceac7af:


    dpense "Guardo Hector. Si alza lentamente. È la sua mossa."


translate italian observebox_4a1733e2:


    orushi "Giocatore Hector. Prendi la tua decisione."


translate italian observebox_cf0266c1:


    dpense "Hector si alza. Se la prende comoda, con un'aria rilassata e disinvolta."


translate italian observebox_c7992f91:


    dpense "Lancia un'occhiata a Steven, poi a Julia, poi a me..."


translate italian observebox_efa82178:


    dpense "Ma il suo sguardo continua a tornare su Julia."


translate italian observebox_02979c6a:


    ruby "Ha senso."


translate italian observebox_6963eb50:


    d "Pensi che lui voglia prenderle la scatola?"


translate italian observebox_82e64c6b:


    ruby "Lui ha già guardato dentro. Sa cosa c'è dentro."


translate italian observebox_a76ae010:


    ruby "E dubito che se la prenderebbe mai con Steven. Julia è la mossa più ovvia."


translate italian observebox_9a3405af:


    dpense "Hector cammina avanti con le braccia incrociate, come se volesse dimostrare di avere il controllo."


translate italian observebox_273de67e:


    hec "Non c'è bisogno di calcoli o progetti. Prendo solo la scatola che voglio."


translate italian observebox_8d7868f2:


    dpense "Mette la sua scatola davanti a Julia. Prende la sua senza dire una parola."


translate italian observebox_3321e440:


    dpense "Poi torna al suo posto, visibilmente soddisfatto di sé."


translate italian observebox_fb40cf92:


    ruby "Semplice. Il classico Hector."


translate italian observebox_32d8d6b8:


    d "Pensi che abbia visto un gettone?"


translate italian observebox_f2806587:


    ruby "Se non sta bluffando, allora sì."


translate italian observebox_9ddc0e31:


    dpense "Julia non reagisce. Ma vedo una leggera contrazione nella sua mascella."


translate italian observebox_e8667989:


    orushi "Giocatore Kira. Tocca a te."


translate italian observebox_64a10e80:


    dpense "Kira si alza, silenziosa come sempre."


translate italian observebox_642a5ab9:


    dpense "Evita il contatto visivo con chiunque."


translate italian observebox_0f16e36c:


    dpense "Non una parola. Solo un movimento diretto e preciso."


translate italian observebox_fb184ad6:


    d "Pensi che lei voglia conquistare Ben?"


translate italian observebox_089ab758:


    ruby "Lo controllò. Se pensa che abbia un pegno, non esiterà."


translate italian observebox_2b2e17a9:


    ruby "Ma con Kira non c'è modo di saperlo finché non agisce."


translate italian observebox_93d9ef9a:


    dpense "Si avvicina a Ben. Lui la guarda, visibilmente confuso e un po' ansioso."


translate italian observebox_ce69e237:


    dpense "Senza esitazione, scambia la sua scatola con la sua."


translate italian observebox_3624db6f:


    ben "Uh... okay?"


translate italian observebox_912e1fa9:


    dpense "Nessuna risposta. Kira torna al suo posto, impassibile."


translate italian observebox_b3606a65:


    ruby "Sta elaborando un piano. E sa che Ben non se ne accorgerà nemmeno."


translate italian observebox_9301699d:


    d "Pensi che stia bluffando?"


translate italian observebox_8740463c:


    ruby "No. Non bluffa mai. Agisce quando è sicura di avere il sopravvento."


translate italian observebox_34733ba8:


    orushi "Giocatore Mac. Procedi."


translate italian observebox_885a1765:


    dpense "Mac si alza lentamente, con le mani in tasca."


translate italian observebox_1865563a:


    dpense "Si guarda intorno, poi incrocia lo sguardo su Ben con un sorriso furbo."


translate italian observebox_2c791c35:


    mac "Spero che non mi odierai per questo, amico... Ti prendo la scatola!"


translate italian observebox_6e69f05e:


    dpense "Si avvicina al podio di Ben..."


translate italian observebox_18845cd4:


    dpense "...prende la scatola senza pensarci due volte e torna al suo posto."


translate italian observebox_f88d009d:


    ruby "Ha sbagliato."


translate italian observebox_29ac5843:


    d "Che cosa?"


translate italian observebox_6c82acdc:


    ruby "Prima ha guardato nella scatola di Ben."


translate italian observebox_669c4a61:


    d "Sì... e allora?"


translate italian observebox_72899aee:


    ruby "Kira lo ha scambiato. La scatola che ha visto ora è davanti a lei."


translate italian observebox_1713d740:


    d "Quindi ha semplicemente preso la scatola di Kira..."


translate italian observebox_2cf6da97:


    ruby "Esatto. E non si è nemmeno accorto dello scambio."


translate italian observebox_15f94f1a:


    dpense "Vedo Ruby scuotere la testa, visibilmente delusa."


translate italian observebox_a340fa6a:


    orushi "Giocatore Ben. Tocca a te."


translate italian observebox_044fdd94:


    dpense "Ben salta in piedi, decisamente troppo entusiasta."


translate italian observebox_5575fb41:


    ben "Bene, allora mi tengo il tuo!"


translate italian observebox_817b1883:


    dpense "Indica la scatola davanti a lui."


translate italian observebox_127b8362:


    dpense "Lui ride come se fosse una specie di scherzo interno, ma nessuno ride."


translate italian observebox_cafb54ab:


    ruby "Questa è una follia."


translate italian observebox_eb044607:


    d "Così tenne la scatola di Mac."


translate italian observebox_c706e221:


    ruby "Sì. Ma dal momento che Mac potrebbe averlo scambiato solo per fare i capricci al suo amico..."


translate italian observebox_4581777d:


    ruby "Non abbiamo idea di cosa ci sia realmente dentro."


translate italian observebox_8b87781d:


    dpense "Riesco a immaginare Ruby che cancella mentalmente i loro nomi."


translate italian observebox_70306ccc:


    ruby "Due giri sprecati. E nessuno dei due se ne rende conto."


translate italian observebox_fa7e1ee5:


    ruby "Solo Kira ha la chiave per risolvere questo ridicolo pasticcio."


translate italian observebox_a5d50b4b:


    ruby "O ha fatto una mossa intelligente sapendo che entrambi avrebbero sbagliato..."


translate italian observebox_4f25693e:


    ruby "Oppure ha semplicemente rischiato tutto, sperando che uno di loro non facesse la stupida."


translate italian observebox_1578061c:


    ruby "Ma a questo punto non possiamo dirlo..."


translate italian observebox_0104b540:


    orushi "Giocatrice Elizabeth, fai la tua scelta."


translate italian observebox_5e80f2b4:


    beth "Scambierò la mia scatola con quella di Hector."


translate italian observebox_d3e3843e:


    dpense "Cammina dritta verso Hector, come se tutto fosse stato pianificato in anticipo."


translate italian observebox_f6525f16:


    ruby "Sta inseguendo Hector. Non me l'aspettavo."


translate italian observebox_ea69dd94:


    d "Pensi che lei voglia zittirlo?"


translate italian observebox_f7fa6f24:


    ruby "Potrebbe essere. Dopo aver controllato, ha preso la scatola di Julia."


translate italian observebox_151dd19b:


    ruby "Ma è sorprendente... sta tradendo il suo stesso gruppo, non è vero?"


translate italian observebox_524f53ec:


    d "O forse si sta solo proteggendo da ciò che sta per accadere..."


translate italian observebox_548cb47b:


    beth "Scambierò la mia scatola con quella di Grace."


translate italian observebox_3d901c49:


    dpense "Si muove lentamente, con gli occhi fissi su Grace."


translate italian observebox_2689dc96:


    ruby "Sta inseguendo Grace. Un colpo diretto."


translate italian observebox_50da0e5e:


    d "Pensi che abbia visto qualcosa nella sua scatola?"


translate italian observebox_869911db:


    ruby "L'ha controllata al primo turno."


translate italian observebox_5c02eddf:


    ruby "Oppure... potrebbe stare bluffando e cercare semplicemente di depistare la nostra squadra."


translate italian observebox_03922bd1:


    d "Sarebbe rischioso."


translate italian observebox_1ce324f2:


    ruby "Esatto. Il che lo rende un potenziale diversivo."


translate italian observebox_815d5c0f:


    orushi "Giocatrice Julia. La tua mossa."


translate italian observebox_e113da56:


    dpense "Julia inspira lentamente, con lo sguardo calmo ma concentrato."


translate italian observebox_e6ad5521:


    ruby "All'inizio aveva spuntato la casella di Ben. Ma da allora sono cambiate troppe cose."


translate italian observebox_7d077aa8:


    ruby "Non sappiamo esattamente cosa avesse in mente Kira, sapendo che tre persone avevano visto la scatola di Ben..."


translate italian observebox_86ef9a80:


    ruby "Ma se lì dentro c'era un gettone... avrebbe dovuto andare a prenderlo da Kira subito."


translate italian observebox_ef7bec1c:


    ruby "Ci mancano dei pezzi. Ma dovrà comunque decidere."


translate italian observebox_b002e034:


    dpense "Lancia un'occhiata significativa a Steven."


translate italian observebox_ae94392f:


    d "Pensi che lei creda che lui abbia trovato qualcosa di prezioso?"


translate italian observebox_f8ab3945:


    ruby "Prese la scatola di Madison."


translate italian observebox_b594f079:


    ruby "Mossa rischiosa, ma sensata. Hector aveva visto la scatola di Julia."


translate italian observebox_21c132d9:


    d "Ma poiché non può riprendersi la sua scatola..."


translate italian observebox_f7c14dd5:


    ruby "Non può riavere indietro ciò che Hector le ha portato via..."


translate italian observebox_6f2fdbf9:


    dpense "Julia avanza in silenzio e scambia la sua scatola con quella di Steven."


translate italian observebox_49c15850:


    dpense "Julia osserva Blue per un attimo."


translate italian observebox_37b2a3e3:


    d "Pensi che non si fidi di Blue?"


translate italian observebox_54568809:


    ruby "Potrebbe essere. Blue ha spuntato la tua casella e poi ha deciso di tenere la sua."


translate italian observebox_485e2ab4:


    ruby "Julia potrebbe pensare di voler andare sul sicuro."


translate italian observebox_6c78b4ee:


    dpense "E poiché finora nessuno ha dato la caccia a Blue, è un bersaglio relativamente sicuro."


translate italian observebox_7675980e:


    dpense "Julia si fa avanti e scambia con calma la sua scatola con quella di Blue."


translate italian observebox_dabe3c58:


    dpense "Nessuna tensione nei suoi movimenti. Solo fredda logica."


translate italian observebox_c90be0da:


    dpense "Torna al suo posto, un po' in disparte dagli altri. Ma i suoi occhi continuano a scrutare la stanza."


translate italian observebox_0d05e656:


    ruby "Sta correndo un rischio. Ma almeno non è bloccata lì."


translate italian observebox_14e4d56f:


    d "Pensi che abbia fiutato la mossa giusta?"


translate italian observebox_429b79ba:


    ruby "Sta giocando con quello che ha. Come tutti noi."


translate italian observebox_0fded406:


    orushi "Giocatore Ruby. La tua mossa."


translate italian observebox_9bcd2f94:


    dpense "Ruby rimane in silenzio mentre tutti gli occhi sono puntati su di lei."


translate italian observebox_93afc8c1:


    dpense "Fissa la sua scatola per un attimo, ma i suoi occhi vagano. Sta pensando."


translate italian observebox_e52a9cbd:


    ruby "Aspetta."


translate italian observebox_bf2a25a9:


    dpense "Solleva la testa verso Orushi."


translate italian observebox_24ca5c61:


    ruby "Io... vorrei fare una domanda."


translate italian observebox_ee1a2f3b:


    orushi "Ti ascolto."


translate italian observebox_6a611e78:


    ruby "Hai detto che potremmo scambiare due scatole tra i giocatori, a patto che siano visibili, giusto?"


translate italian observebox_8b953aea:


    orushi "Ottima domanda, signorina."


translate italian observebox_1247e3c0:


    orushi "Le regole vietano solo di prendere una scatola che è stata scambiata nel turno precedente o di manipolare la propria scatola più di una volta."


translate italian observebox_a5e70cd2:


    orushi "Ma puoi proporre ad altri due giocatori di scambiarsi le caselle, purché ciò non violi quelle condizioni."


translate italian observebox_dd5d68f3:


    d "Eh?"


translate italian observebox_3a6a8dfe:


    ruby "Molto bene. Quindi, se volessi scambiare le scatole di altri due giocatori, potrei farlo?"


translate italian observebox_b42d5274:


    orushi "Intelligente..."


translate italian observebox_c3592c58:


    orushi "Puoi richiederlo e lo scambio verrà eseguito di conseguenza."


translate italian observebox_dcd25429:


    d "Davvero lo farai?"


translate italian observebox_c766f9be:


    ruby "Molto bene. Allora faccio la richiesta ufficialmente."


translate italian observebox_48143662:


    ruby "Voglio scambiare la scatola di Hector... con quella di Madison."


translate italian observebox_4a17ea6f:


    mad "Ruby...?"


translate italian observebox_ccb6903a:


    ruby "Non so cosa c'è nella mia scatola."


translate italian observebox_61abab49:


    ruby "Ma considerando la poca fiducia che ho in Emerick, non posso scommettere su questa scatola specifica."


translate italian observebox_e615cae3:


    ruby "Steven ha preso la scatola di Madison. Ma restituire loro le scatole originali andrebbe contro le regole, suppongo?"


translate italian observebox_c7901d2d:


    orushi "Corretto."


translate italian observebox_6046889d:


    ruby "Se il gettone fosse stato nella scatola di Kira... Julia ci avrebbe provato, visto che aveva visto la scatola di Ben nel primo round."


translate italian observebox_e4001d75:


    ruby "Hector afferrò la scatola di Julia nello stesso modo."


translate italian observebox_6a123181:


    ruby "E insieme a Elizabeth, lei è una delle poche che attualmente detiene una scatola che molto probabilmente contiene un gettone."


translate italian observebox_6f9bee03:


    ruby "Quindi se faccio questo, avrò maggiori possibilità di salvare Madison."


translate italian observebox_02d84031:


    dpense "Ruby fa un respiro profondo."


translate italian observebox_9a628144:


    ruby "Non posso semplicemente restare seduta e non fare nulla."


translate italian observebox_9afa24c5:


    ruby "E sono pronta a perdere per questo."


translate italian observebox_19cbd0fe:


    orushi "La tua richiesta è... non convenzionale."


translate italian observebox_8e3f076a:


    orushi "Ma è conforme alle regole. Approvato."


translate italian observebox_8e2f27e9:


    dpense "Ruby si fa avanti con calma, prende la scatola di Hector, poi quella di Madison e le scambia davanti a tutti."


translate italian observebox_443611cc:


    dpense "Hector la fulmina con lo sguardo. Madison sembra troppo scioccata per parlare."


translate italian observebox_c956f893:


    mad "Ma... Ruby... Tu..."


translate italian observebox_a1503ba2:


    emerick "Questo è completamente assurdo."


translate italian observebox_e2a55e6b:


    emerick "Adesso sta solo inventando delle regole!"


translate italian observebox_60dbd188:


    orushi "Giocatore Emerick, non sei autorizzato a giudicare le regole di questo gioco."


translate italian observebox_6a04ba9f:


    ruby "Là."


translate italian observebox_d525f880:


    ruby "Ora almeno ha una possibilità."


translate italian observebox_46adb172:


    dpense "Ruby torna al suo posto, con gli occhi bassi."


translate italian observebox_6222564e:


    dpense "Ha dato tutto... per Madison."


translate italian observebox_c3884886:


    ruby "Ho fatto tutto il possibile."


translate italian observebox_49cff7fa:


    ruby "Adesso è tutta una questione di fortuna."


translate italian observebox_84827799:


    orushi "Il tuo turno, [name]."


translate italian observebox_d414f5b7:


    ruby "Ascolta... da quello che ho visto, Emerick potrebbe aver corso un rischio enorme fin dall'inizio."


translate italian observebox_dae896d1:


    d "Vuoi dire che... stava bluffando?"


translate italian observebox_ac6ec22d:


    ruby "È possibile. È rimasto troppo calmo, troppo sicuro di sé. E ha fatto subito uno scambio con me."


translate italian observebox_9165ff32:


    d "Allora, cosa ne pensi?"


translate italian observebox_21f8b7e7:


    ruby "Non posso dirlo con certezza, ma è l'unico che nessuno ha mai inseguito. Questo la dice lunga."


translate italian observebox_132d903d:


    ruby "Gli altri hanno paura e non lo sfidano."


translate italian observebox_f573f78c:


    ruby "E non ho idea di cosa ci fosse originariamente nella mia scatola o nella sua."


translate italian observebox_20bf63df:


    d "E se tenessi solo il mio?"


translate italian observebox_db2421bf:


    ruby "Hai ancora la tua scatola originale. La scelta è tua. Ma ricorda, alcune scelte possono cambiare tutto."


translate italian observebox_8e682e31:


    dpense "Mi lascia con questo. Un'ultima occhiata, poi si raddrizza, come se non ci fossimo mai parlati."


translate italian observebox_14ecd1da:


    dpense "Alzo lo sguardo verso Orushi. È il mio turno."


translate italian observebox_46e9b526:


    orushi "[name], tocca a te."


translate italian observebox_2d4de5c9:


    dpense "Tutti gli occhi sono puntati su di me. La tensione è tangibile."


translate italian observebox_913e11b3:


    dpense "Non posso scegliere le scatole di Hector o Madison perché sono state appena traslocate."


translate italian observebox_13773ee9:


    dpense "Stringo forte la mia scatola."


translate italian observebox_a83cc689:


    dpense "Correrò il rischio. Ci credo."


translate italian observebox_33c410d7:


    dpense "Lancio un'occhiata a Ruby. Lei mi fissa in silenzio."


translate italian observebox_eb2bc0fa:


    dpense "Mi alzo e con calma scambio la mia scatola con la sua."


translate italian observebox_552a2159:


    dpense "Lancio un'occhiata a Kira. Lei mi fissa in silenzio."


translate italian observebox_7cc12e13:


    dpense "Lancio un'occhiata a Julia. Lei mi fissa in silenzio."


translate italian observebox_a2455dfe:


    dpense "Guardo Grace. Non dice nulla, ma avverto esitazione nei suoi occhi."


translate italian observebox_614d323f:


    dpense "Vado avanti e concludo lo scambio senza dire una parola."


translate italian observebox_6fe136ad:


    dpense "Red aggrotta leggermente la fronte quando mi vede avvicinarmi."


translate italian observebox_f60a68a1:


    dpense "Mi porge la scatola senza dire una parola. Io scambio."


translate italian observebox_d10389c1:


    dpense "Mi avvicino a Blue. Mi guarda con calma, come se sapesse che sarei arrivato."


translate italian observebox_3f0b66ea:


    dpense "Prendo la sua scatola. Lei non batte ciglio."


translate italian observebox_6585548e:


    dpense "Ben mi guarda sorpreso, quasi divertito."


translate italian observebox_3e04ce27:


    dpense "Prendo la sua scatola. Vediamo se il suo atteggiamento rilassato nasconde qualcosa."


translate italian observebox_500e43c2:


    dpense "Mac alza le sopracciglia."


translate italian observebox_b55ec828:


    dpense "Prendo la sua scatola."


translate italian observebox_9a0c0a4b:


    dpense "Emerick sorride compiaciuto quando mi avvicino. Quasi troppo sicuro di sé."


translate italian observebox_53cf4db2:


    dpense "Gli porgo la mia scatola. La prende senza dire una parola."


translate italian observebox_d52c6b75:


    dpense "Noto il disagio di Ruby..."


translate italian observebox_038794b2:


    blue "Tu... Pensi davvero che sia stata una buona idea?"


translate italian observebox_e33af6f5:


    dpense "Il suo sguardo mi trafigge. Non rabbia, solo incredulità ferita."


translate italian observebox_d7287a2b:


    blue "Avresti potuto fidarti di me."


translate italian observebox_3b8b4697:


    dpense "Ho fatto un errore?"


translate italian observebox_fabd831a:


    dpense "Torno al mio posto. Il mio cuore batte più forte di quanto vorrei ammettere."


translate italian observebox_e4da9d25:


    orushi "Molto bene. Grace? Tocca a te."


translate italian observebox_4e9cd4a5:


    dpense "Lei fa un passo avanti con sicurezza, ma i suoi occhi cercano brevemente i miei."


translate italian observebox_ec10dc98:


    dpense "Non dice nulla. Guarda solo con attenzione la sua scatola."


translate italian observebox_87a9f53c:


    grace "Io terrò il mio."


translate italian observebox_31227e7c:


    dpense "Non ci sono dubbi. È sicura di sé."


translate italian observebox_7e1415e0:


    dpense "Ultimo round completato."


translate italian observebox_56ae23ff:


    orushi "Ottimo."


translate italian observebox_e131215e:


    orushi "Avete tutti avuto l'opportunità di verificare. Di agire. Di tradire."


translate italian observebox_fb44ccf8:


    orushi "Ogni mossa è stata annotata. Ogni esitazione rivelatrice."


translate italian observebox_31e89f22:


    orushi "Ma ora il tempo della strategia è finito."


translate italian observebox_19da0fa9:


    orushi "Ciò che troverai nelle tue scatole determinerà cosa accadrà dopo."


translate italian observebox_f86ad1e4:


    orushi "Ricorda: solo coloro che hanno un token potranno procedere alla prova successiva."


translate italian observebox_7612ad25:


    orushi "E per gli altri… il viaggio finisce qui."


translate italian observebox_0d45be32:


    dpense "Un silenzio pesante cala nella stanza."


translate italian observebox_fda72d86:


    dpense "Tutti fissano la loro scatola. Alcuni con sicurezza, altri con un'ansia malcelata."


translate italian observebox_f91235b9:


    orushi "Li apriremo. Uno per uno."


translate italian observebox_cfb3751c:


    orushi "Giocatore Emerick. Cominciamo da te."


translate italian observebox_974ba520:


    orushi "Token confermato."


translate italian observebox_9a845405:


    ruby "Aveva davvero un gettone. Non mi sbagliavo..."


translate italian observebox_952daa01:


    emerick "Naturalmente avevo un gettone."


translate italian observebox_481b1855:


    emerick "E sei stato intelligente a non intrometterti nei miei affari."


translate italian observebox_930dd552:


    emerick "Forse meriti di andare avanti."


translate italian observebox_37771d92:


    orushi "Il bluff può essere un'arma potente..."


translate italian observebox_a2c85619:


    orushi "Ma la vera abilità sta nel non cadere nella trappola."


translate italian observebox_cad105a2:


    ruby "No... no no no..."


translate italian observebox_4a31fccb:


    ruby "Mi sbagliavo…"


translate italian observebox_474f9baa:


    d "Ruby..."


translate italian observebox_a0066e41:


    ruby "Pensavo che stesse bluffando..."


translate italian observebox_93b51ce3:


    ruby "Ha preso la mia scatola perché sapeva che era vuota..."


translate italian observebox_3e244d8a:


    ruby "E ha fatto di tutto per assicurarsi che tu volessi riprendertelo..."


translate italian observebox_ba4d9261:


    ruby "Era tutta una trappola. E ci sono finito dentro."


translate italian observebox_9401799d:


    ruby "Ti ho fatto perdere il tuo gettone..."


translate italian observebox_e0b0d250:


    d "Non mi hai fatto perdere nulla, Ruby. Ho fatto la scelta."


translate italian observebox_46bbe90c:


    emerick "È troppo tardi per le scuse, piccioncini."


translate italian observebox_8ba239ca:


    emerick "Hai giocato e hai perso."


translate italian observebox_910e4247:


    emerick "Mentre eri impegnato a sospettare di me, ho preso il tuo posto."


translate italian observebox_329dfa00:


    emerick "Pensavi davvero che mi importasse del mio gettone?"


translate italian observebox_5f1da96a:


    emerick "Tutto ciò che volevo era prenderti."


translate italian observebox_1ea28260:


    emerick "Sapevo che non avresti toccato la scatola di Ruby per principio!"


translate italian observebox_06cce23c:


    emerick "E tu hai abboccato. Patetico."


translate italian observebox_7be61e20:


    orushi "Una mossa davvero rara. Mettere a repentaglio la propria vittoria solo per sconfiggere un avversario. Rischioso. Ma efficace."


translate italian observebox_e9754cba:


    ruby "..."


translate italian observebox_4f50ea4b:


    orushi "L'arte della manipolazione, applicata con abilità."


translate italian observebox_f4581a68:


    orushi "Quando ci si concentra troppo sull'intento, si dimentica la conseguenza."


translate italian observebox_508c25d5:


    orushi "E ci sono ancora altre rivelazioni in arrivo..."


translate italian observebox_f156f9d9:


    orushi "Giocatrice Madison. Tocca a te."


translate italian observebox_28d58a31:


    orushi "Giocatore Madison. Il tuo box."


translate italian observebox_62e0e823:


    mad "Grazie, Ruby..."


translate italian observebox_b0a89566:


    mad "Non so come ringraziarti..."


translate italian observebox_88e218a6:


    ruby "È al sicuro..."


translate italian observebox_97edf630:


    d "L'hai salvata, Ruby."


translate italian observebox_398d812b:


    ruby "È il minimo che potessi fare."


translate italian observebox_f13f6513:


    orushi "La strategia può portare a una buona scelta, anche se non è la tua strategia."


translate italian observebox_3ff30284:


    orushi "Ora... continuiamo."


translate italian observebox_e8527e4f:


    orushi "Giocatore Steven. Vediamo cosa c'è nella tua scatola..."


translate italian observebox_c961a606:


    s "Ovviamente."


translate italian observebox_e944a555:


    s "C'è un motivo per cui sono il capitano."


translate italian observebox_577552c1:


    ruby "Quindi Madison in origine aveva davvero un gettone..."


translate italian observebox_9d5b49f0:


    d "Steven aveva un vantaggio posizionale."


translate italian observebox_13c6e254:


    orushi "Strategia, compostezza o puro istinto... In fin dei conti, è una questione tua, Steven."


translate italian observebox_fa8ccb8a:


    sofia "..."


translate italian observebox_c16a8868:


    d "Non so perché, ma provo un senso di colpa."


translate italian observebox_e6dcb139:


    dpense "Aspetta, perché all'improvviso ho una brutta sensazione?"


translate italian observebox_8fccd52b:


    dpense "È come se qualcosa non andasse."


translate italian observebox_3f6c7933:


    sofia "Uff... Almeno questo è fatto."


translate italian observebox_d8de9c70:


    orushi "Giocatore Hector. Il tuo turno."


translate italian observebox_6f4ae617:


    orushi "La casella è vuota."


translate italian observebox_d6e9b6e5:


    hec "Che cosa?!"


translate italian observebox_52249f1b:


    hec "Ma io ho rispettato le regole!"


translate italian observebox_fd3898fd:


    hec "Come può essere vuoto?!"


translate italian observebox_a7bc9564:


    hec "Aspetta... Sono Ruby! Mi hai incastrato!"


translate italian observebox_e5890989:


    hec "Quando hai scambiato la mia scatola e l'hai data a Madison!"


translate italian observebox_4cc575e6:


    ruby "Ho fatto quello che dovevo fare."


translate italian observebox_a4f3ffe8:


    hec "Pensi di poter decidere chi merita di restare?!"


translate italian observebox_ad601622:


    hec "Tutto questo gioco è una stronzata!"


translate italian observebox_af735833:


    hec "Siete tutti ipocriti!"


translate italian observebox_268aaefe:


    orushi "La decisione è definitiva."


translate italian observebox_fb9e53a4:


    hec "Andate a farvi fottere."


translate italian observebox_c80184b8:


    orushi "Giocatore Kira. Vediamo cosa c'è nella tua scatola."


translate italian observebox_869f53e1:


    kira "Perfetto."


translate italian observebox_7de0f032:


    orushi "Giocatore Mac. Vediamo ora cosa contiene la tua scatola."


translate italian observebox_c7696248:


    orushi "…Nessun gettone."


translate italian observebox_f80dea7d:


    mac "Che cosa?!"


translate italian observebox_60c7519a:


    ben "Bella, amico... te l'avevo detto che era l'altro."


translate italian observebox_d92fd476:


    mac "No, ci siamo incrociati! Pensavo che *tu* stessi prendendo Red's!"


translate italian observebox_4e249041:


    ruby "Ecco fatto. Due semicervelli non ne fanno uno intero."


translate italian observebox_0c2120c1:


    orushi "Sembra che un'alleanza senza riflessione sia destinata a fallire."


translate italian observebox_cd2893ad:


    orushi "Giocatore Ben. È il momento di rivelare cosa hai in mano."


translate italian observebox_ac36ddb9:


    orushi "…La tua casella è vuota."


translate italian observebox_72ed8d85:


    ben "Davvero?!"


translate italian observebox_f1d5bc35:


    mac "Hai preso quello di Kira, idiota..."


translate italian observebox_c3600366:


    ben "No! Era di Mac, non di Kira!"


translate italian observebox_f5b77199:


    beth "Dovremmo dare loro un segno di pietà."


translate italian observebox_e6242f29:


    orushi "Disattenzione. Confusione. Non importa come la si chiami, il risultato è sempre lo stesso."


translate italian observebox_c48f2526:


    orushi "Giocatrice Elizabeth. Il tuo turno."


translate italian observebox_e8ed82ca:


    orushi "…C'è un gettone all'interno della tua scatola."


translate italian observebox_ecf3d79e:


    beth "Ovviamente."


translate italian observebox_b72c5297:


    ruby "Hai controllato Hector all'inizio. Hai capito cosa stava succedendo?"


translate italian observebox_f353fcf0:


    beth "Mi sono accorto subito che c'era un problema nel nostro gruppo. Così l'ho corretto."


translate italian observebox_7ef400cc:


    d "(Si è rivoltata contro la sua stessa squadra. Fredda. Calcolatrice.)"


translate italian observebox_9cf9f448:


    emerick "Traditore."


translate italian observebox_18712cea:


    beth "Diciamo che preferisco puntare sull'intelligenza piuttosto che sull'arroganza."


translate italian observebox_44a16e27:


    ruby "Avevi controllato Grace..."


translate italian observebox_5e0488cd:


    beth "Sì. Punta sempre sul rosso."


translate italian observebox_f5a4af3c:


    dpense "Sempre egocentrico. Ma efficace."


translate italian observebox_f58573e9:


    orushi "Giocatrice Julia. È il tuo turno."


translate italian observebox_5bfa8e2b:


    ruby "Hai controllato Ben, vero?"


translate italian observebox_d1e1e790:


    julia "SÌ."


translate italian observebox_4b52c79e:


    ruby "Allora perché non sei andato a cercare Kira?"


translate italian observebox_d1f70c04:


    julia "..."


translate italian observebox_f31b8708:


    dpense "C'è qualcosa che non va..."


translate italian observebox_24a95c57:


    ruby "Quindi hai scelto la scatola di Steven..."


translate italian observebox_3f0dd858:


    julia "Esatto. Ho pensato che fosse la scelta migliore, date le circostanze."


translate italian observebox_ba15dbc5:


    dpense "Steven aveva la scatola di Madison... ma Kira aveva quella di Ben..."


translate italian observebox_0952e2a6:


    ruby "Quindi hai scelto la scatola di Blue?"


translate italian observebox_69e3e0f8:


    julia "Sì. Ho esitato... ma a quel punto mi è sembrata l'opzione più sicura."


translate italian observebox_2d8371f9:


    dpense "Avrebbe potuto scegliere Steven... o meglio ancora, Kira."


translate italian observebox_37d8e615:


    orushi "Giocatore Ruby. Il tuo turno."


translate italian observebox_3197b306:


    orushi "…C'è un gettone nella tua scatola."


translate italian observebox_8e9ab4e7:


    dpense "Sembra congelata... come se si aspettasse il peggio."


translate italian observebox_3193c932:


    mad "Ce l'hai fatta!"


translate italian observebox_0f2c1293:


    ruby "Io... l'ho fatto?"


translate italian observebox_85ff042c:


    d "Sì. Avevi la scatola di Emerick, giusto?"


translate italian observebox_7c8879d6:


    ruby "È lui che ha preso il mio... Ma io ho tenuto il suo. E non ho mai saputo se..."


translate italian observebox_94b8d948:


    ruby "Quando ho aiutato Madison, ho semplicemente accettato il mio destino. Pensavo che non sarei stato io."


translate italian observebox_87ad4670:


    mad "Hai fatto centro, Ruby."


translate italian observebox_c270dc58:


    ruby "Non ci posso credere..."


translate italian observebox_9013017e:


    ruby "In realtà sono riuscito a..."


translate italian observebox_18b51f9b:


    orushi "Un giocatore altruista e perspicace. Ma anche le scelte migliori a volte dipendono da un pizzico di fortuna."


translate italian observebox_1b038fdd:


    orushi "Giocatore [name]. Tocca a te."


translate italian observebox_11b6e570:


    d "SÌ!"


translate italian observebox_b1934d1a:


    ruby "Ce l'hai fatta!"


translate italian observebox_31063061:


    orushi "A volte, la mossa più intelligente... è non giocare troppo."


translate italian observebox_717cf009:


    d "Merda..."


translate italian observebox_1c2eed96:


    ruby "Tu... avevi un gettone nella tua scatola in origine. Perché l'hai scambiato?"


translate italian observebox_520730bb:


    d "Pensavo che forse Mac o Ben avessero maggiori probabilità..."


translate italian observebox_b0cd8174:


    sofia "NO...!"


translate italian observebox_88a75c4d:


    sofia "NO!"


translate italian observebox_70206759:


    sofia "Non lo lascerò andare così!"


translate italian observebox_5dced416:


    orushi "Hmm?"


translate italian observebox_c94f114d:


    sofia "Ho un gettone speciale... il gettone Sacrificio."


translate italian observebox_f852caa8:


    sofia "Voglio cedergli il mio posto."


translate italian observebox_5d296f3e:


    orushi "..."


translate italian observebox_71eb5446:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."


translate italian observebox_07cb4710:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta per cedere il posto a un altro giocatore eliminato."


translate italian observebox_f452c162:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"


translate italian observebox_a5cda67b:


    sofia "Per favore... resta con me."


translate italian observebox_53155274:


    dpense "Sofia..."


translate italian observebox_a0b873b8:


    dpense "Lei... sta piangendo per me?"


translate italian observebox_f195c7ff:


    d "Ti rendi conto di cosa significa?"


translate italian observebox_d0eb6209:


    sofia "Sì. Ma non mi interessa essere il migliore se questo significa restare solo."


translate italian observebox_6a9670cd:


    dpense "La stringo forte in un abbraccio..."


translate italian observebox_f4288911:


    d "Grazie. Un giorno ti ripagherò."


translate italian observebox_2bf1f1d9:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."


translate italian observebox_998c5c67:


    orushi "Questo gioco non è solo una questione di intelligenza o strategia. È anche una prova di ciò che sei disposto a sacrificare per gli altri."


translate italian observebox_114ae86f:


    orushi "Oggi hai dimostrato di non essere tentato dalle ricompense..."


translate italian observebox_56ed9463:


    orushi "Ma invece desideri elevare e aiutare chi ti circonda."


translate italian observebox_815a0bb9:


    orushi "Sarai immediatamente qualificato per il processo successivo. L'immunità è la tua ricompensa per questo atto."


translate italian observebox_df4d3d01:


    ruby "Oh."


translate italian observebox_325e86c7:


    dpense "Sono ancora qui grazie a lei."


translate italian observebox_25bb462a:


    dpense "E avrebbe potuto costarle tutto."


translate italian observebox_2774b746:


    orushi "Sei eliminato."


translate italian observebox_2c536cc9:


    d "Fanculo..."


translate italian observebox_7ea8f2bd:


    ruby "Io... io mi sbagliavo..."


translate italian observebox_16b3b1d0:


    ruby "Pensavo stesse bluffando, ma ha scelto una scatola senza gettoni apposta per intrappolarti."


translate italian observebox_72a7b667:


    ruby "Ti ho fatto perdere…"


translate italian observebox_82292ffe:


    d "Non potevi saperlo..."


translate italian observebox_a81f7dcc:


    emerick "Non si vince questa partita seguendo il proprio cuore."


translate italian observebox_ecb0e7fe:


    emerick "Bisogna pensare a una mossa in anticipo."


translate italian observebox_d93cefbd:


    sofia "Non lo lascerò andare così!"


translate italian observebox_781dbb01:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta, per cedere il posto a un altro giocatore eliminato."


translate italian observebox_cd3b6bc1:


    d "Capisci cosa significa?"


translate italian observebox_4744e459:


    sofia "Sì. Ma non mi interessa essere il migliore se sono da solo."


translate italian observebox_81607533:


    dpense "La stringo forte tra le mie braccia..."


translate italian observebox_5f088be5:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."


translate italian observebox_8a126ae0:


    orushi "Questo gioco non è solo una prova di intelligenza o strategia. Mette alla prova anche ciò che sei disposto a sacrificare per gli altri."


translate italian observebox_6a5a7c8b:


    orushi "Oggi hai dimostrato di non lasciarti tentare dal fascino della vittoria..."


translate italian observebox_9accf929:


    orushi "Ma che invece vuoi sostenere e incoraggiare chi ti circonda."


translate italian observebox_93f9a021:


    dpense "Sono ancora qui grazie a lei."


translate italian observebox_23148e2c:


    d "Uff... ha funzionato."


translate italian observebox_00153084:


    ruby "Ben fatto!"


translate italian observebox_bf6e0ecb:


    orushi "La tua scelta è stata quella giusta. Passi alla fase successiva."


translate italian observebox_f4288911_1:


    d "Grazie. Un giorno ti ripagherò."


translate italian observebox_5d296f3e_1:


    orushi "..."


translate italian observebox_5d296f3e_2:


    orushi "..."


translate italian observebox_5d296f3e_3:


    orushi "..."


translate italian observebox_815a0bb9_1:


    orushi "Sarai immediatamente qualificato per il processo successivo. L'immunità è la tua ricompensa per questo atto."


translate italian observebox_df4d3d01_1:


    ruby "Oh."


translate italian observebox_25bb462a_1:


    dpense "E avrebbe potuto costarle tutto."


translate italian observebox_2774b746_1:


    orushi "Sei eliminato."


translate italian observebox_3197b306_1:


    orushi "…C'è un gettone nella tua scatola."


translate italian observebox_3197b306_2:


    orushi "…C'è un gettone nella tua scatola."


translate italian e5s6_reveal_grace_dd66b7b6:


    orushi "Ultima scatola da rivelare... la giocatrice Grace."


translate italian e5s6_reveal_grace_3a0afec6:


    dpense "Lei è in piedi, con gli occhi fissi..."


translate italian e5s6_reveal_grace_2460a778:


    dpense "O non ha esitato, o lo ha nascosto molto bene."


translate italian e5s6_reveal_grace_3197b306:


    orushi "…C'è un gettone nella tua scatola."


translate italian e5s6_reveal_grace_4da47427:


    grace "Io... io ce l'ho fatta?!"


translate italian e5s6_reveal_grace_0b300a7d:


    ruby "Sì! Bella!"


translate italian e5s6_reveal_grace_79b24103:


    mad "Sapevo che ce l'avrebbe fatta."


translate italian e5s6_reveal_grace_ef1b0c25:


    dpense "L'ultimo a qualificarsi... grazie a Dio."


translate italian e5s6_reveal_grace_2490cefd:


    orushi "Il processo è ormai terminato."


translate italian e5s6_reveal_grace_4006ce28:


    orushi "Tutti i token sono stati rivelati."


translate italian e5s6_reveal_grace_4276c690:


    orushi "È tempo di concludere... e di parlare di ciò che verrà dopo."


translate italian e5s6_reveal_grace_394e93a6:


    d "Cosa succederà adesso?"





translate italian e5s6_3fb2abb2:


    orushi "Miei cari concorrenti..."





translate italian e5s6_ff4534d8:


    orushi "Siete rimasti in venti."





translate italian e5s6_6b430812:


    orushi "Venti vite. Venti percorsi. Venti storie intrecciate."





translate italian e5s6_d91dcc73:


    orushi "Ma oggi... solo una manciata di persone andrà avanti."





translate italian e5s6_266e4fc3:


    orushi "Davanti a ciascuno di voi c'è una scatola sigillata."





translate italian e5s6_b65d1e21:


    orushi "Alcune di queste caselle contengono un gettone di selezione."





translate italian e5s6_998449ef:


    orushi "Altri sono vuoti."





translate italian e5s6_ea1631bc:


    orushi "Non vi dirò quanti gettoni ci sono."





translate italian e5s6_97ca7c04:


    orushi "Ciò che ti offro è una scelta. Solo una."





translate italian e5s6_1f277e8c:


    orushi "Ognuno di voi avrà l'opportunità di guardare di nascosto all'interno di una scatola..."





translate italian e5s6_0e53d205:


    orushi "...qualsiasi scatola tranne la tua."





translate italian e5s6_4cc4a23d:


    orushi "Potete farlo solo una volta."





translate italian e5s6_381bae70:


    orushi "Poi ognuno di voi prenderà una decisione:"





translate italian e5s6_f326ea5b:


    orushi "Tieni la tua scatola e abbi fiducia nella tua fortuna,"





translate italian e5s6_8b46f9ac:


    orushi "oppure scambiare le scatole con un altro giocatore."





translate italian e5s6_24201288:


    orushi "Ma ricordate..."





translate italian e5s6_1a15c350:


    orushi "Una scatola scambiata perde la sua certezza."





translate italian e5s6_bcb0b2a5:


    orushi "E una scatola conservata... potrebbe non essere altro che un miraggio."





translate italian e5s6_dea039ff:


    orushi "Riflettete attentamente. Perché questo non è solo un test di selezione..."





translate italian e5s6_89c37bde:


    orushi "È il riflesso di tutto ciò che avete imparato da quando sei arrivato qui."





translate italian e5s6_4f24f925:


    dpense "Devo scegliere una casella da spuntare... ma non la mia."





translate italian e5s6_observation_5a3b9d43_1:


    d "E quelli che non conosciamo?"





translate italian e5s6_observation_e50286b8_1:


    ruby "Non li conosciamo. Non possiamo fare affidamento sulle loro azioni perché non sappiamo come funzionano..."





translate italian e5s6_observation_2095c829_1:


    ruby "Non sappiamo quanti si qualificheranno alla fine, quindi..."





translate italian e5s6_observation_ac26ecd3:


    dpense "Tutti fissano la loro scatola... non sanno bene cosa farne."





translate italian e5s6_observation_810d625f:


    dpense "Nessuno sa quanti gettoni ci siano."





translate italian e5s6_observation_27801cb9:


    dpense "Sembra che stiano tutti cercando di scoprire qualche regola nascosta dietro tutto questo."





translate italian e5s6_observation_e657325b:


    mad "Quindi... dovremmo guardare una scatola per aiutarci a decidere?"





translate italian e5s6_observation_75b7e148:


    s "O forse è solo per confonderci le idee. Potrebbe essere una trappola totale..."





translate italian e5s6_observation_f72e8743:


    grace "Non mi piace. Troppo vago. Sembra che ci stiano prendendo in giro."





translate italian e5s6_observation_5d544f10:


    dpense "Ruby non dice niente."





translate italian e5s6_observation_38f0c86d:


    dpense "Sta solo guardando. Come sempre."





translate italian e5s6_observation_4fc8cc42:


    ruby "È tutta una questione di percezione. Questa volta non si tratta di un enigma logico."





translate italian e5s6_observation_538ff4e2:


    ruby "La vera domanda non è cosa vediamo noi. È cosa pensano di aver visto tutti gli altri."





translate italian e5s6_observation_fcd6c3eb:


    dpense "Ha ragione. Ma capisco che sta pensando a qualcosa di più profondo..."





translate italian e5s6_observation_3c9bb22b:


    ruby "Hai già scelto una casella da spuntare?"





translate italian e5s6_observation_3f2cdd4d:


    d "Non ancora. Voglio raccogliere le informazioni più utili."





translate italian e5s6_observation_4057739d:


    ruby "Lo stesso. Se combiniamo ciò che vediamo con ciò che fanno gli altri, forse possiamo individuare uno schema."





translate italian e5s6_observation_437737f7:


    d "Ti piace la logica comportamentale? Istinto contro ragionamento?"





translate italian e5s6_observation_27bf0648:


    ruby "Esatto. Non è una questione di scatola in sé. È una questione di cosa credono ci sia dentro... e cosa fanno dopo."





translate italian e5s6_observation_a57c028f:


    dpense "Ora il mio cervello si sta attivando. Ho capito a cosa mira."





translate italian e5s6_observation_6957997a:


    d "Quindi facciamo squadra. In silenzio."





translate italian e5s6_observation_b196b7bf:


    ruby "Silenziosamente."





translate italian e5s6_observation_5a3b9d43:


    d "E quelli che non conosciamo?"





translate italian e5s6_observation_e50286b8:


    ruby "Non li conosciamo. Non possiamo fare affidamento sulle loro azioni perché non sappiamo come funzionano..."





translate italian e5s6_observation_2095c829:


    ruby "Non sappiamo quanti si qualificheranno alla fine, quindi..."





translate italian e5s6_observation_e0ba5112:


    ruby "Meglio ignorarli per semplificare le cose."





translate italian e5s6_observation_ed6d2f04:


    ruby "Dobbiamo rimanere concentrati. Non abbiamo molte informazioni, ma chi agisce troppo in fretta... è quello che farà confusione."





translate italian e5s6_observation_294017f1:


    dpense "Ha quel tono calmo e analitico che ormai riconosco. Ha già un piano."





translate italian e5s6_observation_47cd4a00:


    ruby "meglio ignorarli per semplificare le cose."





translate italian e5s6_observation_9badd16e:


    dpense "Tutti guardano. Valutano. Calcolano."





translate italian e5s6_observation_eaf92f49:


    dpense "Ruby è immersa nei suoi pensieri. I suoi occhi scrutano la stanza, poi si posano su di me."





translate italian e5s6_observation_a9a53a3f:


    ruby "Hai notato come alcune persone tengono strette le loro scatole, anche senza aprirle?"





translate italian e5s6_observation_f2d439ff:


    d "Forse stanno giocando sul sicuro. O stanno bluffando."





translate italian e5s6_observation_68d0c586:


    ruby "Oppure cercare di far credere agli altri che sanno già cosa fare."





translate italian e5s6_observation_f4e1452b:


    d "Quindi, un bluff."





translate italian e5s6_observation_4132040c:


    ruby "O eccesso di sicurezza. Ma è nelle prime mosse che si commettono gli errori più stupidi."





translate italian e5s6_observation_71bf35f5:


    dpense "Colgo un accenno di sorriso sulle sue labbra. Sta decodificando i comportamenti. E lo sto facendo anch'io."





translate italian e5s6_observation_5bd18ff2:


    ruby "Cosa ne pensi della postura di Steven?"





translate italian e5s6_observation_3ded11ad:


    d "O ha paura di fare la scelta sbagliata, oppure aspetta che qualcun altro faccia la prima mossa."





translate italian e5s6_observation_8f485c95:


    ruby "È quello che penso anch'io..."





translate italian e5s6_observation_e915c292:


    dpense "Non parliamo molto. Ma ci osserviamo a vicenda. Riflettiamo sulle cose. Insieme."





translate italian e5s6_observation_13770013:


    emerick "Stai scherzando?!"





translate italian e5s6_observation_ef379675:


    emerick "Hanno bisbigliato per cinque minuti e nessuno ha detto niente?!"





translate italian e5s6_observation_0c8161c2:


    emerick "Questo è un dannato test e tu stai lasciando che questi due escogitino un piccolo piano romantico o qualcosa del genere?!"





translate italian e5s6_observation_750b2f38:


    ruby "Sei tu quello che urla, Emerick. Hai paura di perdere o cosa?"





translate italian e5s6_observation_211ec9af:


    emerick "Almeno non sto barando! Sto giocando da SOLO. Come si deve!"





translate italian e5s6_observation_37ba782e:


    dpense "Sta perdendo la testa, ma in fondo penso che stia perdendo soprattutto il controllo."





translate italian e5s6_observation_de527c80:


    orushi "Finitela."





translate italian e5s6_observation_2dfe950f:


    orushi "Giocatore Emerick, stai tranquillo: sento e vedo tutto."





translate italian e5s6_observation_c89c0bc6:


    orushi "E fidatevi di me: saprò esattamente chi merita di andare avanti."





translate italian e5s6_observation_5cc5d10c:


    orushi "Non ho mai proibito ai candidati di parlare tra loro."





translate italian e5s6_observation_ae49718d:


    orushi "Ciò che è vietato è condividere informazioni sul contenuto delle scatole: quelle che hanno aperto o quelle che hanno controllato."





translate italian e5s6_observation_db73bb00:


    orushi "Ma parliamo di strategia, impressioni o comportamento?"





translate italian e5s6_observation_4d64c97d:


    orushi "Non solo è consentito... è anche rivelatore."





translate italian e5s6_observation_72e35eab:


    orushi "E vi ricordo: questa è una sfida individuale."





translate italian e5s6_observation_e1efcdb2:


    orushi "Potete parlare quanto volete, ma non aspettatevi di essere salvati insieme."





translate italian e5s6_observation_c1150fb8:


    orushi "Alcuni parleranno, altri mentiranno. E a volte... tutti perdono."





translate italian e5s6_observation_3787fbaf:


    orushi "Dal momento che sembri così ansioso di dare il tono, Emerick..."





translate italian e5s6_observation_96383100:


    orushi "Partirai per primo."





translate italian e5s6_observation_b9c2f3ff:


    emerick "Finalmente."





translate italian e5s6_observation_6b3e59a8:


    emerick "Controllerò..."





translate italian e5s6_observation_3b1c981c:


    emerick "La scatola di Ruby."





translate italian e5s6_observation_ee17831d:


    dpense "La sta provocando."





translate italian e5s6_observation_ea3dd448:


    emerick "Mhhhh. Affascinante."





translate italian e5s6_observation_d2c80a33:


    dpense "Lo sta deliberatamente lasciando sul vago. Non può farne a meno."





translate italian e5s6_observation_599e0fed:


    orushi "Giocatrice Madison. La tua mossa."





translate italian e5s6_observation_bb118b62:


    mad "Bene, eccomi qui."





translate italian e5s6_observation_ea76f770:


    dpense "Sento la tensione in lei."





translate italian e5s6_observation_1965421c:


    ruby "È nervosa. Troppo tesa per rischiare un bluff."





translate italian e5s6_observation_bfd462c5:


    ruby "Spunta la casella di qualcun altro per sentirsi più sicura."





translate italian e5s6_observation_58193e62:


    mad "Io... spunterò una casella. Quella di Steven."





translate italian e5s6_observation_da7e21f9:


    dpense "Si avvicina cautamente al podio di Steven, solleva leggermente la scatola, poi la rimette giù altrettanto velocemente."





translate italian e5s6_observation_0a716f94:


    dpense "Nessuna parola. Nemmeno uno sguardo verso di lui."





translate italian e5s6_observation_413b4e4d:


    orushi "Giocatore Steven. Il tuo turno."





translate italian e5s6_observation_fe589a7d:


    dpense "Steven si alza di scatto. Non gli piace perdere tempo."





translate italian e5s6_observation_0af6d3e4:


    dpense "Cammina intorno al cerchio e si ferma davanti al podio di Madison."





translate italian e5s6_observation_ab0d797a:


    d "Lui spunterà la sua casella?"





translate italian e5s6_observation_5529a69b:


    ruby "È una forma di ritorsione. A seconda di cosa lei fa con la sua scatola, lui vuole fare un controllo incrociato."





translate italian e5s6_observation_39cc181d:


    ruby "Lui ha il vantaggio di poter scegliere dopo di lei."





translate italian e5s6_observation_59acf03b:


    dpense "Steven solleva lentamente il coperchio... poi lo chiude altrettanto velocemente."





translate italian e5s6_observation_270d2683:


    dpense "Nessuna parola. Nessuno sguardo. Torna al suo posto."





translate italian e5s6_observation_73397bdd:


    s "Questo è tutto ciò di cui ho bisogno."





translate italian e5s6_observation_0dfaa844:


    ruby "Sta bluffando. Oppure è sicuro della sua lettura."





translate italian e5s6_observation_92239153:


    d "O forse vuole solo confondere Madison."





translate italian e5s6_observation_f61ca382:


    orushi "Giocatrice Sofia. Tocca a te."





translate italian e5s6_observation_2eff792a:


    dpense "Blue si avvicina con calma. Nessuno stress visibile."





translate italian e5s6_observation_c1e009d5:


    dpense "Entra nel cerchio e i suoi occhi passano lentamente da un podio all'altro."





translate italian e5s6_observation_7ecb088b:


    dpense "Poi si ferma davanti a me."





translate italian e5s6_observation_c407ce85:


    ruby "OH."





translate italian e5s6_observation_d08b77f3:


    d "Lei... metterà la spunta sulla mia casella?"





translate italian e5s6_observation_c2a8c7bc:


    dpense "Si sporge in avanti. Solleva lentamente il coperchio..."





translate italian e5s6_observation_ef7b11e8:


    dpense "...poi lo chiude, senza dire una parola."





translate italian e5s6_observation_371e844a:


    dpense "Lei non parla. Ma per mezzo secondo i suoi occhi incontrano i miei."





translate italian e5s6_observation_340770b4:


    dpense "Mi rivolge un sorriso. Sottile. Debole. Ma c'è."





translate italian e5s6_observation_a4022d3c:


    ruby "Pensi che sia un messaggio?"





translate italian e5s6_observation_62a604ab:


    d "Non ne ho idea. È sempre difficile da capire."





translate italian e5s6_observation_6d29929a:


    ruby "O forse vuole che tu lo ottenga senza dire nulla."





translate italian e5s6_observation_a51faf27:


    dpense "Torna al suo posto, ancora calma come sempre."





translate italian e5s6_observation_c790e247:


    orushi "Giocatore Hector. La tua mossa."





translate italian e5s6_observation_7f24b98b:


    dpense "Hector si alza lentamente. Ridacchia guardandosi intorno."





translate italian e5s6_observation_f5d54b81:


    hec "Bene... credo che dovrò giocare."





translate italian e5s6_observation_ec149967:


    dpense "Passeggia nel cerchio, prendendosi il suo tempo."





translate italian e5s6_observation_a90e38aa:


    dpense "Si ferma davanti al podio di Julia."





translate italian e5s6_observation_0c545453:


    d "Lui spunterà la sua casella?"





translate italian e5s6_observation_82db18bb:


    ruby "Forse vuole confonderla. O semplicemente ricordarle che la sta guardando."





translate italian e5s6_observation_0ef07917:


    dpense "Solleva il coperchio, si prende un momento per guardare, poi lo chiude con noncuranza."





translate italian e5s6_observation_31cf088f:


    dpense "Poi torna indietro con un sorriso furbo sul volto."





translate italian e5s6_observation_5e717452:


    hec "Interessante..."





translate italian e5s6_observation_fd6f595a:


    dpense "Julia non sussulta."





translate italian e5s6_observation_e827eecb:


    dpense "Ma lei continua a fissarlo."





translate italian e5s6_observation_e8667989:


    orushi "Giocatore Kira. Tocca a te."





translate italian e5s6_observation_048b202a:


    dpense "Kira si alza in silenzio. Il suo volto, come sempre, è indecifrabile."





translate italian e5s6_observation_96962f07:


    dpense "Non guarda Emerick. Non guarda me. Si dirige verso Ben."





translate italian e5s6_observation_125f4494:


    ruby "Classico. Bersaglio facile."





translate italian e5s6_observation_7ce813bd:


    d "Pensi che stia andando sul sicuro?"





translate italian e5s6_observation_6702fa5c:


    ruby "Oppure sa esattamente cosa sta facendo."





translate italian e5s6_observation_dc7ec2e7:


    dpense "Kira si china, apre la scatola di Ben, la studia con calma..."





translate italian e5s6_observation_92f236ad:


    dpense "Poi lo chiude con un movimento netto."





translate italian e5s6_observation_dab9380a:


    dpense "Non un'ombra di emozione sul suo viso. Torna al suo posto senza dire una parola."





translate italian e5s6_observation_f77cc5d4:


    orushi "Giocatore Mac. La tua mossa."





translate italian e5s6_observation_99fb4c28:


    dpense "Mac si guarda intorno per un secondo, con aria assente."





translate italian e5s6_observation_b75228ec:


    mac "Bene... cerchiamo di semplificare."





translate italian e5s6_observation_7152bc37:


    dpense "Si avvicina al podio di Ben e dà una rapida occhiata all'interno."





translate italian e5s6_observation_85d5655c:


    dpense "Poi torna indietro senza dire nulla."





translate italian e5s6_observation_86216c3d:


    ruby "Probabilmente pensa che Ben sia troppo stupido per tenere un gettone."





translate italian e5s6_observation_15df2888:


    d "Oppure troppo stupido per sapere cosa ha visto."





translate italian e5s6_observation_5a13be4e:


    orushi "Giocatore Ben. Tocca a te."





translate italian e5s6_observation_028daeab:


    dpense "Ben guarda Mac, poi sorride come un idiota."





translate italian e5s6_observation_a6cd2453:


    ben "Stesso discorso, fratello."





translate italian e5s6_observation_1ca31caf:


    dpense "Si avvicina direttamente alla scatola di Mac e sbircia dentro come se fosse uno scherzo interno."





translate italian e5s6_observation_da8b37ca:


    dpense "Ritorna al suo posto, visibilmente soddisfatto di sé, anche se nessuno sa perché."





translate italian e5s6_observation_ea8cbfb9:


    ruby "Stallo."





translate italian e5s6_observation_040a0511:


    d "Zero cervelli, finta alleanza."





translate italian e5s6_observation_c48f2526:


    orushi "Giocatrice Elizabeth. Il tuo turno."





translate italian e5s6_observation_68cfe16d:


    dpense "Red resta lì senza dire una parola. Ancora con quel suo atteggiamento calmo e gelido... ma tutto in lei sembra calcolato."





translate italian e5s6_observation_0d9ef439:


    dpense "Gira lentamente la testa verso Hector. La sua scelta sorprende più di qualcuno."





translate italian e5s6_observation_b961d1e8:


    beth "Sceglierò la casella di Hector."





translate italian e5s6_observation_645e996e:


    dpense "Cammina con calma, solleva il coperchio, controlla il contenuto senza mostrare la minima emozione e torna al suo posto."





translate italian e5s6_observation_a02b9a4f:


    ruby "Hector? Sta attaccando il suo stesso gruppo?"





translate italian e5s6_observation_332b3b1b:


    d "È rischioso..."





translate italian e5s6_observation_3c12f12d:


    ruby "Oppure geniale. Colpire una delle pedine di Emerick per indebolire la struttura senza dover combattere direttamente."





translate italian e5s6_observation_775d2b2b:


    ruby "Quello che non capisco è... perché?"





translate italian e5s6_observation_6bfc2d3e:


    dpense "Il rosso colpisce senza fare rumore... ma ogni colpo va a segno."





translate italian e5s6_observation_5fc4ea0c:


    dpense "Fissa Grace a lungo, quasi come se la stesse osservando dall'alto."





translate italian e5s6_observation_a6eb1408:


    beth "Darò un'occhiata alla scatola di Grace."





translate italian e5s6_observation_3451a2af:


    dpense "Si avvicina, guarda dentro la scatola di Grace, poi torna indietro senza dire nulla."





translate italian e5s6_observation_efd26043:


    ruby "Sta prendendo di mira Grace..."





translate italian e5s6_observation_22cc5438:


    dpense "Il Rosso non mostra mai le sue carte. Gioca da solo, a modo suo. E a volte, è tutto ciò che serve."





translate italian e5s6_observation_815d5c0f:


    orushi "Giocatrice Julia. La tua mossa."





translate italian e5s6_observation_250197d6:


    dpense "Julia si alza lentamente. I suoi occhi scrutano la stanza come se cercasse di leggere i pensieri di tutti."





translate italian e5s6_observation_5f263a93:


    dpense "Nessuna fretta. Lei va avanti, concentrata."





translate italian e5s6_observation_957f3dc7:


    julia "Spunto la casella di Ben."





translate italian e5s6_observation_4b1a57a5:


    dpense "Dà una rapida occhiata, poi chiude delicatamente la scatola e torna al suo posto."





translate italian e5s6_observation_5551f768:


    ruby "Interessante."





translate italian e5s6_observation_9a9172ac:


    d "Ti aspettavi che scegliesse Ben?"





translate italian e5s6_observation_ad3c63ea:


    ruby "È silenzioso. Passa inosservato. Esattamente il tipo di persona che la gente ignora. Il che lo rende una fonte di informazioni perfetta."





translate italian e5s6_observation_f2362b94:


    ruby "E poiché Ben guardava Mac, forse stava seguendo una catena. Ottenendo una lettura più ampia rispetto alle altre."





translate italian e5s6_observation_bab9be02:


    dpense "Julia è sempre calma... ma sa esattamente dove sta andando."





translate italian e5s6_observation_37d8e615:


    orushi "Giocatore Ruby. Il tuo turno."





translate italian e5s6_observation_bdaa9598:


    dpense "Ruby rimane immobile per un attimo. Come se stesse calcolando un'ultima variabile prima di muoversi."





translate italian e5s6_observation_87fb0482:


    d "Sai già chi sceglierai?"





translate italian e5s6_observation_84766a69:


    ruby "Quasi. Voglio solo fare un controllo incrociato."





translate italian e5s6_observation_5910b51b:


    d "Stai pensando a Kira?"





translate italian e5s6_observation_677385f2:


    ruby "Guardò Ben. Era la scelta più sicura possibile nella stanza."





translate italian e5s6_observation_090f49ec:


    d "Vuoi capire perché ha scelto lui?"





translate italian e5s6_observation_f0c09d26:


    ruby "Forse. Quando si tratta di Kira... anche i movimenti più semplici possono far parte di qualcosa di più profondo."





translate italian e5s6_observation_a83de9ab:


    dpense "Si alza senza dire una parola e si dirige verso il podio di Kira."





translate italian e5s6_observation_94cb22f1:


    dpense "Apre la scatola con attenzione, la studia a lungo, poi la chiude."





translate italian e5s6_observation_3b3f1873:


    dpense "Non mostra nulla, ma so che sta memorizzando quei dati nella sua mente."





translate italian e5s6_observation_6744b0d6:


    ruby "Bene."





translate italian e5s6_observation_ca66aafa:


    dpense "Una sola parola. Tono neutro. Ma capisco che ha appena trovato il pezzo che le mancava."





translate italian e5s6_observation_8768f6ed:


    orushi "Giocatore [name] La tua mossa."





translate italian e5s6_observation_f05fbf9a:


    dpense "È il mio turno."





translate italian e5s6_observation_44642eca:


    dpense "Solo una mossa. Una casella da spuntare. E non la mia."





translate italian e5s6_observation_2aef89b8:


    dpense "Devo fare la scelta giusta."





translate italian e5s6_observation_525eb106:


    ruby "Sai cosa stiamo cercando. Comportamento, connessioni, verifiche incrociate. Scegli con la testa, non con il cuore."





translate italian e5s6_observation_d935a521:


    d "Non preoccuparti. Ho imparato la lezione."





translate italian observebox_eb2bc0fa_1:


    dpense "Mi alzo e con calma scambio la mia scatola con la sua."





translate italian observebox_eb2bc0fa_2:


    dpense "Mi alzo e con calma scambio la mia scatola con la sua."





translate italian observebox_974ba520_1:


    orushi "Token confermato."





translate italian observebox_974ba520_2:


    orushi "Token confermato."





translate italian observebox_974ba520_3:


    orushi "Token confermato."





translate italian observebox_974ba520_4:


    orushi "Token confermato."





translate italian observebox_f61ca382_1:


    orushi "Giocatrice Sofia. Tocca a te."





translate italian observebox_ecf3d79e_1:


    beth "Ovviamente."





translate italian observebox_e8ed82ca_1:


    orushi "…C'è un gettone all'interno della tua scatola."





translate italian observebox_e9754cba_1:


    ruby "..."





translate italian observebox_ac36ddb9_1:


    orushi "…La tua casella è vuota."





translate italian observebox_ac36ddb9_2:


    orushi "…La tua casella è vuota."





translate italian observebox_b0cd8174_1:


    sofia "NO...!"





translate italian observebox_88a75c4d_1:


    sofia "NO!"





translate italian observebox_5dced416_1:


    orushi "Hmm?"





translate italian observebox_c94f114d_1:


    sofia "Ho un gettone speciale... il gettone Sacrificio."





translate italian observebox_f852caa8_1:


    sofia "Voglio cedergli il mio posto."





translate italian observebox_71eb5446_1:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."





translate italian observebox_f452c162_1:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"





translate italian observebox_a5cda67b_1:


    sofia "Per favore... resta con me."





translate italian observebox_53155274_1:


    dpense "Sofia..."





translate italian observebox_a0b873b8_1:


    dpense "Lei... sta piangendo per me?"





translate italian observebox_77664c99:


    dpense "Mi alzo con calma e mi avvicino [chosenbox] la scatola di."





translate italian observebox_989aee24:


    dpense "Sollevo delicatamente il coperchio…"





translate italian observebox_2288c22f:


    dpense "...osservo attentamente."





translate italian observebox_dfc06a98:


    dpense "Poi lo chiudo. Non deve scivolare niente."





translate italian observebox_f05d166d:


    dpense "Ho quello che mi serve. Per ora."





translate italian observebox_c38e4058:


    orushi "Grace. Tocca a te."





translate italian observebox_658e3be4:


    ruby "Non perderà tempo. Andrà con un ragazzo che considera instabile."





translate italian observebox_917fb4dc:


    d "Mac, pensi?"





translate italian observebox_6e20a2d6:


    ruby "Non ha un gran cervello. E sempre all'ombra di Steven o Emerick."





translate italian observebox_4226a24e:


    dpense "Si dirige dritta verso la scatola di Mac."





translate italian observebox_3348cbd3:


    dpense "Solleva il coperchio, guarda dentro e poi lo chiude immediatamente."





translate italian observebox_a24f5d94:


    dpense "Non una parola. Torna al suo posto, con un'espressione assente."





translate italian observebox_866951a7:


    ruby "Sta cercando informazioni certe. E non le condividerà."





translate italian observebox_6b29c0bb:


    d "Suona da solista... ma sempre con un senso dell'onore."





translate italian observebox_16f332a0:


    dpense "Posso dire che ha visto esattamente ciò di cui aveva bisogno."





translate italian observebox_23140c05:


    orushi "Concorrenti…"





translate italian observebox_804938c3:


    orushi "Avete avuto tutti il tempo di osservare. Di analizzare."





translate italian observebox_a0ebc701:


    orushi "Adesso è il momento di prendere una decisione."





translate italian observebox_6b0be950:


    orushi "Ognuno di voi farà la sua mossa."





translate italian observebox_89d8e2cd:


    orushi "Quando arriva il vostro turno, avrete due opzioni:"





translate italian observebox_5edf0a7b:


    orushi "Oppure tieni la scatola davanti a te..."





translate italian observebox_63f29e78:


    orushi "Oppure scambia due caselle visibili."





translate italian observebox_9785ac7e:


    orushi "Ma fate attenzione a questo:"





translate italian observebox_3227b1eb:


    orushi "Quando un giocatore scambia la propria scatola con quella di qualcun altro, quella scatola diventa intoccabile per il round successivo."





translate italian observebox_0c685453:


    orushi "In altre parole... non puoi prendere una scatola che qualcuno ha appena preso nel turno precedente."





translate italian observebox_77633d3e:


    orushi "Non è possibile nemmeno riprendere la propria scatola dopo uno scambio."





translate italian observebox_42c239e2:


    orushi "Rifletti attentamente. Le apparenze spesso ingannano..."





translate italian observebox_c3e81c73:


    orushi "E a volte una buona decisione può essere rovinata da una sola esitazione."





translate italian observebox_bdbce856:


    orushi "Giocatore Emerick. Tocca a te."





translate italian observebox_b989a26c:


    dpense "Emerick si alza. Si alza con la sua solita arroganza, come un profumo scadente che non si toglie mai."





translate italian observebox_b3d683ba:


    dpense "Esamina attentamente il cerchio, osservando ogni volto come se cercasse un punto debole."





translate italian observebox_a987d25e:


    emerick "Va bene... non ci girerò intorno."





translate italian observebox_29ada277:


    dpense "Si alza, si dirige verso Madison... poi devia all'ultimo secondo."





translate italian observebox_eede833e:


    dpense "Cammina dritto verso Ruby."





translate italian observebox_5e506b55:


    dpense "Lui si ferma davanti a lei con un sorriso compiaciuto."





translate italian observebox_627dc3c7:


    emerick "Vediamo se la tua calma nasconde qualcosa di utile."





translate italian observebox_c8a399c1:


    dpense "Emerick porge la sua scatola a Ruby senza dire una parola e prende la sua in cambio."





translate italian observebox_fc9f6b21:


    dpense "Ruby non batte ciglio. Accetta lo scambio senza mostrare la minima emozione."





translate italian observebox_e9ab0fe7:


    dpense "Ma sento che qualcosa si sta fissando nella sua mente. Sta già analizzando."





translate italian observebox_cba3c434:


    dpense "Se ne va con la scatola di Ruby come se avesse appena vinto un duello silenzioso."





translate italian observebox_599e0fed:


    orushi "Giocatrice Madison. La tua mossa."





translate italian observebox_c13cba8f:


    dpense "Si alza in fretta. Troppo in fretta per qualcuno che ha un piano perfettamente definito."





translate italian observebox_6be5b99f:


    dpense "Ma lei non trema. Cammina con la stessa grinta che ha sempre nelle partite."





translate italian observebox_c36c10e6:


    ruby "Corre d'istinto, ma sa che tutti gli occhi sono puntati su di lei."





translate italian observebox_e4be989b:


    dpense "Lancia un'occhiata a Steven, poi alla sua scatola."





translate italian observebox_4e2838a8:


    mad "Io tengo il mio."





translate italian observebox_72f07918:


    dpense "È una scelta coraggiosa. Quasi una sfida. Come se stesse dimostrando di non aver bisogno di nessuno."





translate italian observebox_ee5fc84f:


    ruby "Orgogliosa, impulsiva... ma non spericolata. Cerca di mantenere il controllo a tutti i costi."





translate italian observebox_412e3851:


    ruby "Ma questo significa anche che non le piaceva ciò che vedeva nella scatola di Steven."





translate italian observebox_6d8f6f7f:


    orushi "Giocatore Steven. La tua mossa."





translate italian observebox_401632f6:


    dpense "Steven si alza, sicuro di sé come sempre."





translate italian observebox_83e6273c:


    dpense "Fissa la sua scatola per un secondo... poi gira la testa verso Madison."





translate italian observebox_2236a400:


    d "Pensi che lui...?"





translate italian observebox_413119fd:


    ruby "Ha visto la sua scatola. Sa esattamente cosa c'è dentro."





translate italian observebox_2a6337b9:


    dpense "Lui cammina avanti senza esitazione. Dritto verso di lei."





translate italian observebox_5a81e0fe:


    s "Mi dispiace, Madison."





translate italian observebox_44297608:


    dpense "Lui afferra la scatola davanti a lei e la scambia con la sua, senza darle il tempo di reagire."





translate italian observebox_c0039868:


    mad "Che cosa?!"





translate italian observebox_96d59479:


    s "Questo è il gioco."





translate italian observebox_ade58ffd:


    dpense "Steven se ne va con la scatola di Madison. Nessuno si volta indietro."





translate italian observebox_57b7099a:


    mad "Accidenti..."





translate italian observebox_94393724:


    dpense "Stringe la mascella. Ma lo sopporta."





translate italian observebox_63b20ae4:


    d "Pensi che stia bluffando?"





translate italian observebox_211642e4:


    ruby "No. Lui gioca in base a ciò che ha visto."





translate italian observebox_72229415:


    d "Lei ha guardato la sua scatola, giusto?"





translate italian observebox_d2e01c1e:


    ruby "Esatto. E dopo, decise di tenersi il suo."





translate italian observebox_9a8af104:


    ruby "Quindi Steven deve aver visto un gettone."





translate italian observebox_f61ca382:


    orushi "Giocatrice Sofia. Tocca a te."





translate italian observebox_31deb386:


    dpense "Blue si alza con calma. Il suo sguardo scruta brevemente la stanza, poi si fissa dritto davanti a sé."





translate italian observebox_b936dcd0:


    dpense "Cammina con grazia, ma senza fretta. Ogni passo sembra intenzionale."





translate italian observebox_729e1a7a:


    dpense "Si sta dirigendo verso di me."





translate italian observebox_07dcdb93:


    dpense "Nessuna deviazione. Nessuno sguardo a nessun'altra scatola."





translate italian observebox_13e72a78:


    dpense "Si ferma davanti al mio podio. Mi guarda per un secondo."





translate italian observebox_6fcaa1ce:


    sofia "Io tengo il mio..."





translate italian observebox_167f365c:


    sofia "...ma volevo che tu lo sapessi."





translate italian observebox_e2ff0077:


    dpense "Il suo tono è dolce. Quasi intimo."





translate italian observebox_976665f6:


    dpense "Non un comando, non una supplica. Una dichiarazione. Semplice e diretta."





translate italian observebox_3197e801:


    ruby "Sta mandando un messaggio. È chiaro."





translate italian observebox_993daf80:


    d "Vuole che io capisca cosa ha visto. O cosa pensa di aver visto."





translate italian observebox_571c632a:


    dpense "Blue torna al suo posto, senza voltarsi indietro. Ma le sue parole risuonano ancora."





translate italian observebox_04ba7eb9:


    dpense "Si ferma per un secondo, incerta."





translate italian observebox_11641847:


    dpense "Poi si dirige verso il suo box."





translate italian observebox_ddbe835d:


    dpense "Nessuna parola. Nessuno sguardo nella mia direzione. Niente."





translate italian observebox_83dc8a5f:


    dpense "Appoggia una mano sul podio, chiude gli occhi per un attimo..."





translate italian observebox_7e0ec825:


    dpense "Poi si siede."





translate italian observebox_4bc5e1f8:


    ruby "Lei si tiene la sua."





translate italian observebox_6936d7e2:


    d "Ma non parlò con nessuno."





translate italian observebox_225e24fb:


    ruby "Quel silenzio potrebbe far parte della sua strategia."





translate italian observebox_d1f02b5d:


    dpense "Il silenzio torna a calare, un po' più pesante."





translate italian observebox_e2133619:


    dpense "Ruby socchiude gli occhi. Sta pensando. Sta collegando i puntini."





translate italian observebox_b4b02729:


    ruby "COSÌ…"





translate italian observebox_acb63775:


    ruby "Emerick ha scambiato la sua scatola con la mia. Una mossa sicura."





translate italian observebox_40f0e2e3:


    ruby "Madison guardò Steven. Poi tenne il suo."





translate italian observebox_ef4a94fe:


    ruby "Steven vide quello di Madison. E lo scambiò."





translate italian observebox_270f06e7:


    ruby "Blue ha spuntato la tua casella... e ha scelto di mantenere la sua."





translate italian observebox_636083ef:


    ruby "E adesso tocca a Hector."





translate italian observebox_8c74fffe:


    dpense "Ruby prende un piccolo respiro, come se stesse ricalibrando tutto."





translate italian observebox_1ad285c6:


    ruby "Guardò nella scatola di Julia. Sa cosa c'è dentro."





translate italian observebox_4870c84b:


    ruby "Ha tre opzioni:"





translate italian observebox_d098fb47:


    ruby "O Julia ha un gettone e lui ci prova."





translate italian observebox_89c3fa55:


    ruby "Oppure non lo fa, e lui pensa che sia meglio tenerselo."





translate italian observebox_dddf5678:


    ruby "Oppure… crede che una delle scatole già scambiate ora abbia più valore."





translate italian observebox_e4a4650a:


    d "Come quello che Steven ha preso da Madison."





translate italian observebox_c31975d7:


    ruby "Esatto. Forse pensava che ci fosse un gettone, e Steven l'ha fiutato."





translate italian observebox_09f2bc2c:


    ruby "In tal caso, se facesse uno scambio con Steven, otterrebbe la vecchia scatola di Madison."





translate italian observebox_69873bef:


    ruby "E il gettone all'interno. Se ce n'era uno."





translate italian observebox_ab5187e7:


    dpense "Ma oserebbe farlo?"





translate italian observebox_e1ed004a:


    ruby "È Hector. Correre grandi rischi non lo spaventa."





translate italian observebox_8ceac7af:


    dpense "Guardo Hector. Si alza lentamente. È la sua mossa."





translate italian observebox_4a1733e2:


    orushi "Giocatore Hector. Prendi la tua decisione."





translate italian observebox_cf0266c1:


    dpense "Hector si alza. Se la prende comoda, con un'aria rilassata e disinvolta."





translate italian observebox_c7992f91:


    dpense "Lancia un'occhiata a Steven, poi a Julia, poi a me..."





translate italian observebox_efa82178:


    dpense "Ma il suo sguardo continua a tornare su Julia."





translate italian observebox_02979c6a:


    ruby "Ha senso."





translate italian observebox_6963eb50:


    d "Pensi che lui voglia prenderle la scatola?"





translate italian observebox_82e64c6b:


    ruby "Lui ha già guardato dentro. Sa cosa c'è dentro."





translate italian observebox_a76ae010:


    ruby "E dubito che se la prenderebbe mai con Steven. Julia è la mossa più ovvia."





translate italian observebox_9a3405af:


    dpense "Hector cammina avanti con le braccia incrociate, come se volesse dimostrare di avere il controllo."





translate italian observebox_273de67e:


    hec "Non c'è bisogno di calcoli o progetti. Prendo solo la scatola che voglio."





translate italian observebox_8d7868f2:


    dpense "Mette la sua scatola davanti a Julia. Prende la sua senza dire una parola."





translate italian observebox_3321e440:


    dpense "Poi torna al suo posto, visibilmente soddisfatto di sé."





translate italian observebox_fb40cf92:


    ruby "Semplice. Il classico Hector."





translate italian observebox_32d8d6b8:


    d "Pensi che abbia visto un gettone?"





translate italian observebox_f2806587:


    ruby "Se non sta bluffando, allora sì."





translate italian observebox_9ddc0e31:


    dpense "Julia non reagisce. Ma vedo una leggera contrazione nella sua mascella."





translate italian observebox_e8667989:


    orushi "Giocatore Kira. Tocca a te."





translate italian observebox_64a10e80:


    dpense "Kira si alza, silenziosa come sempre."





translate italian observebox_642a5ab9:


    dpense "Evita il contatto visivo con chiunque."





translate italian observebox_0f16e36c:


    dpense "Non una parola. Solo un movimento diretto e preciso."





translate italian observebox_fb184ad6:


    d "Pensi che lei voglia conquistare Ben?"





translate italian observebox_089ab758:


    ruby "Lo controllò. Se pensa che abbia un pegno, non esiterà."





translate italian observebox_2b2e17a9:


    ruby "Ma con Kira non c'è modo di saperlo finché non agisce."





translate italian observebox_93d9ef9a:


    dpense "Si avvicina a Ben. Lui la guarda, visibilmente confuso e un po' ansioso."





translate italian observebox_ce69e237:


    dpense "Senza esitazione, scambia la sua scatola con la sua."





translate italian observebox_3624db6f:


    ben "Uh... okay?"





translate italian observebox_912e1fa9:


    dpense "Nessuna risposta. Kira torna al suo posto, impassibile."





translate italian observebox_b3606a65:


    ruby "Sta elaborando un piano. E sa che Ben non se ne accorgerà nemmeno."





translate italian observebox_9301699d:


    d "Pensi che stia bluffando?"





translate italian observebox_8740463c:


    ruby "No. Non bluffa mai. Agisce quando è sicura di avere il sopravvento."





translate italian observebox_34733ba8:


    orushi "Giocatore Mac. Procedi."





translate italian observebox_885a1765:


    dpense "Mac si alza lentamente, con le mani in tasca."





translate italian observebox_1865563a:


    dpense "Si guarda intorno, poi incrocia lo sguardo su Ben con un sorriso furbo."





translate italian observebox_2c791c35:


    mac "Spero che non mi odierai per questo, amico... Ti prendo la scatola!"





translate italian observebox_6e69f05e:


    dpense "Si avvicina al podio di Ben..."





translate italian observebox_18845cd4:


    dpense "...prende la scatola senza pensarci due volte e torna al suo posto."





translate italian observebox_f88d009d:


    ruby "Ha sbagliato."





translate italian observebox_29ac5843:


    d "Che cosa?"





translate italian observebox_6c82acdc:


    ruby "Prima ha guardato nella scatola di Ben."





translate italian observebox_669c4a61:


    d "Sì... e allora?"





translate italian observebox_72899aee:


    ruby "Kira lo ha scambiato. La scatola che ha visto ora è davanti a lei."





translate italian observebox_1713d740:


    d "Quindi ha semplicemente preso la scatola di Kira..."





translate italian observebox_2cf6da97:


    ruby "Esatto. E non si è nemmeno accorto dello scambio."





translate italian observebox_15f94f1a:


    dpense "Vedo Ruby scuotere la testa, visibilmente delusa."





translate italian observebox_a340fa6a:


    orushi "Giocatore Ben. Tocca a te."





translate italian observebox_044fdd94:


    dpense "Ben salta in piedi, decisamente troppo entusiasta."





translate italian observebox_5575fb41:


    ben "Bene, allora mi tengo il tuo!"





translate italian observebox_817b1883:


    dpense "Indica la scatola davanti a lui."





translate italian observebox_127b8362:


    dpense "Lui ride come se fosse una specie di scherzo interno, ma nessuno ride."





translate italian observebox_cafb54ab:


    ruby "Questa è una follia."





translate italian observebox_eb044607:


    d "Così tenne la scatola di Mac."





translate italian observebox_c706e221:


    ruby "Sì. Ma dal momento che Mac potrebbe averlo scambiato solo per fare i capricci al suo amico..."





translate italian observebox_4581777d:


    ruby "Non abbiamo idea di cosa ci sia realmente dentro."





translate italian observebox_8b87781d:


    dpense "Riesco a immaginare Ruby che cancella mentalmente i loro nomi."





translate italian observebox_70306ccc:


    ruby "Due giri sprecati. E nessuno dei due se ne rende conto."





translate italian observebox_fa7e1ee5:


    ruby "Solo Kira ha la chiave per risolvere questo ridicolo pasticcio."





translate italian observebox_a5d50b4b:


    ruby "O ha fatto una mossa intelligente sapendo che entrambi avrebbero sbagliato..."





translate italian observebox_4f25693e:


    ruby "Oppure ha semplicemente rischiato tutto, sperando che uno di loro non facesse la stupida."





translate italian observebox_1578061c:


    ruby "Ma a questo punto non possiamo dirlo..."





translate italian observebox_0104b540:


    orushi "Giocatrice Elizabeth, fai la tua scelta."





translate italian observebox_5e80f2b4:


    beth "Scambierò la mia scatola con quella di Hector."





translate italian observebox_d3e3843e:


    dpense "Cammina dritta verso Hector, come se tutto fosse stato pianificato in anticipo."





translate italian observebox_f6525f16:


    ruby "Sta inseguendo Hector. Non me l'aspettavo."





translate italian observebox_ea69dd94:


    d "Pensi che lei voglia zittirlo?"





translate italian observebox_f7fa6f24:


    ruby "Potrebbe essere. Dopo aver controllato, ha preso la scatola di Julia."





translate italian observebox_151dd19b:


    ruby "Ma è sorprendente... sta tradendo il suo stesso gruppo, non è vero?"





translate italian observebox_524f53ec:


    d "O forse si sta solo proteggendo da ciò che sta per accadere..."





translate italian observebox_548cb47b:


    beth "Scambierò la mia scatola con quella di Grace."





translate italian observebox_3d901c49:


    dpense "Si muove lentamente, con gli occhi fissi su Grace."





translate italian observebox_2689dc96:


    ruby "Sta inseguendo Grace. Un colpo diretto."





translate italian observebox_50da0e5e:


    d "Pensi che abbia visto qualcosa nella sua scatola?"





translate italian observebox_869911db:


    ruby "L'ha controllata al primo turno."





translate italian observebox_5c02eddf:


    ruby "Oppure... potrebbe stare bluffando e cercare semplicemente di depistare la nostra squadra."





translate italian observebox_03922bd1:


    d "Sarebbe rischioso."





translate italian observebox_1ce324f2:


    ruby "Esatto. Il che lo rende un potenziale diversivo."





translate italian observebox_815d5c0f:


    orushi "Giocatrice Julia. La tua mossa."





translate italian observebox_e113da56:


    dpense "Julia inspira lentamente, con lo sguardo calmo ma concentrato."





translate italian observebox_e6ad5521:


    ruby "All'inizio aveva spuntato la casella di Ben. Ma da allora sono cambiate troppe cose."





translate italian observebox_7d077aa8:


    ruby "Non sappiamo esattamente cosa avesse in mente Kira, sapendo che tre persone avevano visto la scatola di Ben..."





translate italian observebox_86ef9a80:


    ruby "Ma se lì dentro c'era un gettone... avrebbe dovuto andare a prenderlo da Kira subito."





translate italian observebox_ef7bec1c:


    ruby "Ci mancano dei pezzi. Ma dovrà comunque decidere."





translate italian observebox_b002e034:


    dpense "Lancia un'occhiata significativa a Steven."





translate italian observebox_ae94392f:


    d "Pensi che lei creda che lui abbia trovato qualcosa di prezioso?"





translate italian observebox_f8ab3945:


    ruby "Prese la scatola di Madison."





translate italian observebox_b594f079:


    ruby "Mossa rischiosa, ma sensata. Hector aveva visto la scatola di Julia."





translate italian observebox_21c132d9:


    d "Ma poiché non può riprendersi la sua scatola..."





translate italian observebox_f7c14dd5:


    ruby "Non può riavere indietro ciò che Hector le ha portato via..."





translate italian observebox_6f2fdbf9:


    dpense "Julia avanza in silenzio e scambia la sua scatola con quella di Steven."





translate italian observebox_49c15850:


    dpense "Julia osserva Blue per un attimo."





translate italian observebox_37b2a3e3:


    d "Pensi che non si fidi di Blue?"





translate italian observebox_54568809:


    ruby "Potrebbe essere. Blue ha spuntato la tua casella e poi ha deciso di tenere la sua."





translate italian observebox_485e2ab4:


    ruby "Julia potrebbe pensare di voler andare sul sicuro."





translate italian observebox_6c78b4ee:


    dpense "E poiché finora nessuno ha dato la caccia a Blue, è un bersaglio relativamente sicuro."





translate italian observebox_7675980e:


    dpense "Julia si fa avanti e scambia con calma la sua scatola con quella di Blue."





translate italian observebox_dabe3c58:


    dpense "Nessuna tensione nei suoi movimenti. Solo fredda logica."





translate italian observebox_c90be0da:


    dpense "Torna al suo posto, un po' in disparte dagli altri. Ma i suoi occhi continuano a scrutare la stanza."





translate italian observebox_0d05e656:


    ruby "Sta correndo un rischio. Ma almeno non è bloccata lì."





translate italian observebox_14e4d56f:


    d "Pensi che abbia fiutato la mossa giusta?"





translate italian observebox_429b79ba:


    ruby "Sta giocando con quello che ha. Come tutti noi."





translate italian observebox_0fded406:


    orushi "Giocatore Ruby. La tua mossa."





translate italian observebox_9bcd2f94:


    dpense "Ruby rimane in silenzio mentre tutti gli occhi sono puntati su di lei."





translate italian observebox_93afc8c1:


    dpense "Fissa la sua scatola per un attimo, ma i suoi occhi vagano. Sta pensando."





translate italian observebox_e52a9cbd:


    ruby "Aspetta."





translate italian observebox_bf2a25a9:


    dpense "Solleva la testa verso Orushi."





translate italian observebox_24ca5c61:


    ruby "Io... vorrei fare una domanda."





translate italian observebox_ee1a2f3b:


    orushi "Ti ascolto."





translate italian observebox_6a611e78:


    ruby "Hai detto che potremmo scambiare due scatole tra i giocatori, a patto che siano visibili, giusto?"





translate italian observebox_8b953aea:


    orushi "Ottima domanda, signorina."





translate italian observebox_1247e3c0:


    orushi "Le regole vietano solo di prendere una scatola che è stata scambiata nel turno precedente o di manipolare la propria scatola più di una volta."





translate italian observebox_a5e70cd2:


    orushi "Ma puoi proporre ad altri due giocatori di scambiarsi le caselle, purché ciò non violi quelle condizioni."





translate italian observebox_dd5d68f3:


    d "Eh?"





translate italian observebox_3a6a8dfe:


    ruby "Molto bene. Quindi, se volessi scambiare le scatole di altri due giocatori, potrei farlo?"





translate italian observebox_b42d5274:


    orushi "Intelligente..."





translate italian observebox_c3592c58:


    orushi "Puoi richiederlo e lo scambio verrà eseguito di conseguenza."





translate italian observebox_dcd25429:


    d "Davvero lo farai?"





translate italian observebox_c766f9be:


    ruby "Molto bene. Allora faccio la richiesta ufficialmente."





translate italian observebox_48143662:


    ruby "Voglio scambiare la scatola di Hector... con quella di Madison."





translate italian observebox_4a17ea6f:


    mad "Ruby...?"





translate italian observebox_ccb6903a:


    ruby "Non so cosa c'è nella mia scatola."





translate italian observebox_61abab49:


    ruby "Ma considerando la poca fiducia che ho in Emerick, non posso scommettere su questa scatola specifica."





translate italian observebox_e615cae3:


    ruby "Steven ha preso la scatola di Madison. Ma restituire loro le scatole originali andrebbe contro le regole, suppongo?"





translate italian observebox_c7901d2d:


    orushi "Corretto."





translate italian observebox_6046889d:


    ruby "Se il gettone fosse stato nella scatola di Kira... Julia ci avrebbe provato, visto che aveva visto la scatola di Ben nel primo round."





translate italian observebox_e4001d75:


    ruby "Hector afferrò la scatola di Julia nello stesso modo."





translate italian observebox_6a123181:


    ruby "E insieme a Elizabeth, lei è una delle poche che attualmente detiene una scatola che molto probabilmente contiene un gettone."





translate italian observebox_6f9bee03:


    ruby "Quindi se faccio questo, avrò maggiori possibilità di salvare Madison."





translate italian observebox_02d84031:


    dpense "Ruby fa un respiro profondo."





translate italian observebox_9a628144:


    ruby "Non posso semplicemente restare seduta e non fare nulla."





translate italian observebox_9afa24c5:


    ruby "E sono pronta a perdere per questo."





translate italian observebox_19cbd0fe:


    orushi "La tua richiesta è... non convenzionale."





translate italian observebox_8e3f076a:


    orushi "Ma è conforme alle regole. Approvato."





translate italian observebox_8e2f27e9:


    dpense "Ruby si fa avanti con calma, prende la scatola di Hector, poi quella di Madison e le scambia davanti a tutti."





translate italian observebox_443611cc:


    dpense "Hector la fulmina con lo sguardo. Madison sembra troppo scioccata per parlare."





translate italian observebox_c956f893:


    mad "Ma... Ruby... Tu..."





translate italian observebox_a1503ba2:


    emerick "Questo è completamente assurdo."





translate italian observebox_e2a55e6b:


    emerick "Adesso sta solo inventando delle regole!"





translate italian observebox_60dbd188:


    orushi "Giocatore Emerick, non sei autorizzato a giudicare le regole di questo gioco."





translate italian observebox_6a04ba9f:


    ruby "Là."





translate italian observebox_d525f880:


    ruby "Ora almeno ha una possibilità."





translate italian observebox_46adb172:


    dpense "Ruby torna al suo posto, con gli occhi bassi."





translate italian observebox_6222564e:


    dpense "Ha dato tutto... per Madison."





translate italian observebox_c3884886:


    ruby "Ho fatto tutto il possibile."





translate italian observebox_49cff7fa:


    ruby "Adesso è tutta una questione di fortuna."





translate italian observebox_84827799:


    orushi "Il tuo turno, [name]."





translate italian observebox_d414f5b7:


    ruby "Ascolta... da quello che ho visto, Emerick potrebbe aver corso un rischio enorme fin dall'inizio."





translate italian observebox_dae896d1:


    d "Vuoi dire che... stava bluffando?"





translate italian observebox_ac6ec22d:


    ruby "È possibile. È rimasto troppo calmo, troppo sicuro di sé. E ha fatto subito uno scambio con me."





translate italian observebox_9165ff32:


    d "Allora, cosa ne pensi?"





translate italian observebox_21f8b7e7:


    ruby "Non posso dirlo con certezza, ma è l'unico che nessuno ha mai inseguito. Questo la dice lunga."





translate italian observebox_132d903d:


    ruby "Gli altri hanno paura e non lo sfidano."





translate italian observebox_f573f78c:


    ruby "E non ho idea di cosa ci fosse originariamente nella mia scatola o nella sua."





translate italian observebox_20bf63df:


    d "E se tenessi solo il mio?"





translate italian observebox_db2421bf:


    ruby "Hai ancora la tua scatola originale. La scelta è tua. Ma ricorda, alcune scelte possono cambiare tutto."





translate italian observebox_8e682e31:


    dpense "Mi lascia con questo. Un'ultima occhiata, poi si raddrizza, come se non ci fossimo mai parlati."





translate italian observebox_14ecd1da:


    dpense "Alzo lo sguardo verso Orushi. È il mio turno."





translate italian observebox_46e9b526:


    orushi "[name], tocca a te."





translate italian observebox_2d4de5c9:


    dpense "Tutti gli occhi sono puntati su di me. La tensione è tangibile."





translate italian observebox_913e11b3:


    dpense "Non posso scegliere le scatole di Hector o Madison perché sono state appena traslocate."





translate italian observebox_13773ee9:


    dpense "Stringo forte la mia scatola."





translate italian observebox_a83cc689:


    dpense "Correrò il rischio. Ci credo."





translate italian observebox_33c410d7:


    dpense "Lancio un'occhiata a Ruby. Lei mi fissa in silenzio."





translate italian observebox_eb2bc0fa:


    dpense "Mi alzo e con calma scambio la mia scatola con la sua."





translate italian observebox_552a2159:


    dpense "Lancio un'occhiata a Kira. Lei mi fissa in silenzio."





translate italian observebox_7cc12e13:


    dpense "Lancio un'occhiata a Julia. Lei mi fissa in silenzio."





translate italian observebox_a2455dfe:


    dpense "Guardo Grace. Non dice nulla, ma avverto esitazione nei suoi occhi."





translate italian observebox_614d323f:


    dpense "Vado avanti e concludo lo scambio senza dire una parola."





translate italian observebox_6fe136ad:


    dpense "Red aggrotta leggermente la fronte quando mi vede avvicinarmi."





translate italian observebox_f60a68a1:


    dpense "Mi porge la scatola senza dire una parola. Io scambio."





translate italian observebox_d10389c1:


    dpense "Mi avvicino a Blue. Mi guarda con calma, come se sapesse che sarei arrivato."





translate italian observebox_3f0b66ea:


    dpense "Prendo la sua scatola. Lei non batte ciglio."





translate italian observebox_6585548e:


    dpense "Ben mi guarda sorpreso, quasi divertito."





translate italian observebox_3e04ce27:


    dpense "Prendo la sua scatola. Vediamo se il suo atteggiamento rilassato nasconde qualcosa."





translate italian observebox_500e43c2:


    dpense "Mac alza le sopracciglia."





translate italian observebox_b55ec828:


    dpense "Prendo la sua scatola."





translate italian observebox_9a0c0a4b:


    dpense "Emerick sorride compiaciuto quando mi avvicino. Quasi troppo sicuro di sé."





translate italian observebox_53cf4db2:


    dpense "Gli porgo la mia scatola. La prende senza dire una parola."





translate italian observebox_d52c6b75:


    dpense "Noto il disagio di Ruby..."





translate italian observebox_038794b2:


    blue "Tu... Pensi davvero che sia stata una buona idea?"





translate italian observebox_e33af6f5:


    dpense "Il suo sguardo mi trafigge. Non rabbia, solo incredulità ferita."





translate italian observebox_d7287a2b:


    blue "Avresti potuto fidarti di me."





translate italian observebox_3b8b4697:


    dpense "Ho fatto un errore?"





translate italian observebox_fabd831a:


    dpense "Torno al mio posto. Il mio cuore batte più forte di quanto vorrei ammettere."





translate italian observebox_e4da9d25:


    orushi "Molto bene. Grace? Tocca a te."





translate italian observebox_4e9cd4a5:


    dpense "Lei fa un passo avanti con sicurezza, ma i suoi occhi cercano brevemente i miei."





translate italian observebox_ec10dc98:


    dpense "Non dice nulla. Guarda solo con attenzione la sua scatola."





translate italian observebox_87a9f53c:


    grace "Io terrò il mio."





translate italian observebox_31227e7c:


    dpense "Non ci sono dubbi. È sicura di sé."





translate italian observebox_7e1415e0:


    dpense "Ultimo round completato."





translate italian observebox_56ae23ff:


    orushi "Ottimo."





translate italian observebox_e131215e:


    orushi "Avete tutti avuto l'opportunità di verificare. Di agire. Di tradire."





translate italian observebox_fb44ccf8:


    orushi "Ogni mossa è stata annotata. Ogni esitazione rivelatrice."





translate italian observebox_31e89f22:


    orushi "Ma ora il tempo della strategia è finito."





translate italian observebox_19da0fa9:


    orushi "Ciò che troverai nelle tue scatole determinerà cosa accadrà dopo."





translate italian observebox_f86ad1e4:


    orushi "Ricorda: solo coloro che hanno un token potranno procedere alla prova successiva."





translate italian observebox_7612ad25:


    orushi "E per gli altri… il viaggio finisce qui."





translate italian observebox_0d45be32:


    dpense "Un silenzio pesante cala nella stanza."





translate italian observebox_fda72d86:


    dpense "Tutti fissano la loro scatola. Alcuni con sicurezza, altri con un'ansia malcelata."





translate italian observebox_f91235b9:


    orushi "Li apriremo. Uno per uno."





translate italian observebox_cfb3751c:


    orushi "Giocatore Emerick. Cominciamo da te."





translate italian observebox_974ba520:


    orushi "Token confermato."





translate italian observebox_9a845405:


    ruby "Aveva davvero un gettone. Non mi sbagliavo..."





translate italian observebox_952daa01:


    emerick "Naturalmente avevo un gettone."





translate italian observebox_481b1855:


    emerick "E sei stato intelligente a non intrometterti nei miei affari."





translate italian observebox_930dd552:


    emerick "Forse meriti di andare avanti."





translate italian observebox_37771d92:


    orushi "Il bluff può essere un'arma potente..."





translate italian observebox_a2c85619:


    orushi "Ma la vera abilità sta nel non cadere nella trappola."





translate italian observebox_cad105a2:


    ruby "No... no no no..."





translate italian observebox_4a31fccb:


    ruby "Mi sbagliavo…"





translate italian observebox_474f9baa:


    d "Ruby..."





translate italian observebox_a0066e41:


    ruby "Pensavo che stesse bluffando..."





translate italian observebox_93b51ce3:


    ruby "Ha preso la mia scatola perché sapeva che era vuota..."





translate italian observebox_3e244d8a:


    ruby "E ha fatto di tutto per assicurarsi che tu volessi riprendertelo..."





translate italian observebox_ba4d9261:


    ruby "Era tutta una trappola. E ci sono finito dentro."





translate italian observebox_9401799d:


    ruby "Ti ho fatto perdere il tuo gettone..."





translate italian observebox_e0b0d250:


    d "Non mi hai fatto perdere nulla, Ruby. Ho fatto la scelta."





translate italian observebox_46bbe90c:


    emerick "È troppo tardi per le scuse, piccioncini."





translate italian observebox_8ba239ca:


    emerick "Hai giocato e hai perso."





translate italian observebox_910e4247:


    emerick "Mentre eri impegnato a sospettare di me, ho preso il tuo posto."





translate italian observebox_329dfa00:


    emerick "Pensavi davvero che mi importasse del mio gettone?"





translate italian observebox_5f1da96a:


    emerick "Tutto ciò che volevo era prenderti."





translate italian observebox_1ea28260:


    emerick "Sapevo che non avresti toccato la scatola di Ruby per principio!"





translate italian observebox_06cce23c:


    emerick "E tu hai abboccato. Patetico."





translate italian observebox_7be61e20:


    orushi "Una mossa davvero rara. Mettere a repentaglio la propria vittoria solo per sconfiggere un avversario. Rischioso. Ma efficace."





translate italian observebox_e9754cba:


    ruby "..."





translate italian observebox_4f50ea4b:


    orushi "L'arte della manipolazione, applicata con abilità."





translate italian observebox_f4581a68:


    orushi "Quando ci si concentra troppo sull'intento, si dimentica la conseguenza."





translate italian observebox_508c25d5:


    orushi "E ci sono ancora altre rivelazioni in arrivo..."





translate italian observebox_f156f9d9:


    orushi "Giocatrice Madison. Tocca a te."





translate italian observebox_28d58a31:


    orushi "Giocatore Madison. Il tuo box."





translate italian observebox_62e0e823:


    mad "Grazie, Ruby..."





translate italian observebox_b0a89566:


    mad "Non so come ringraziarti..."





translate italian observebox_88e218a6:


    ruby "È al sicuro..."





translate italian observebox_97edf630:


    d "L'hai salvata, Ruby."





translate italian observebox_398d812b:


    ruby "È il minimo che potessi fare."





translate italian observebox_f13f6513:


    orushi "La strategia può portare a una buona scelta, anche se non è la tua strategia."





translate italian observebox_3ff30284:


    orushi "Ora... continuiamo."





translate italian observebox_e8527e4f:


    orushi "Giocatore Steven. Vediamo cosa c'è nella tua scatola..."





translate italian observebox_c961a606:


    s "Ovviamente."





translate italian observebox_e944a555:


    s "C'è un motivo per cui sono il capitano."





translate italian observebox_577552c1:


    ruby "Quindi Madison in origine aveva davvero un gettone..."





translate italian observebox_9d5b49f0:


    d "Steven aveva un vantaggio posizionale."





translate italian observebox_13c6e254:


    orushi "Strategia, compostezza o puro istinto... In fin dei conti, è una questione tua, Steven."





translate italian observebox_fa8ccb8a:


    sofia "..."





translate italian observebox_c16a8868:


    d "Non so perché, ma provo un senso di colpa."





translate italian observebox_e6dcb139:


    dpense "Aspetta, perché all'improvviso ho una brutta sensazione?"





translate italian observebox_8fccd52b:


    dpense "È come se qualcosa non andasse."





translate italian observebox_3f6c7933:


    sofia "Uff... Almeno questo è fatto."





translate italian observebox_d8de9c70:


    orushi "Giocatore Hector. Il tuo turno."





translate italian observebox_6f4ae617:


    orushi "La casella è vuota."





translate italian observebox_d6e9b6e5:


    hec "Che cosa?!"





translate italian observebox_52249f1b:


    hec "Ma io ho rispettato le regole!"





translate italian observebox_fd3898fd:


    hec "Come può essere vuoto?!"





translate italian observebox_a7bc9564:


    hec "Aspetta... Sono Ruby! Mi hai incastrato!"





translate italian observebox_e5890989:


    hec "Quando hai scambiato la mia scatola e l'hai data a Madison!"





translate italian observebox_4cc575e6:


    ruby "Ho fatto quello che dovevo fare."





translate italian observebox_a4f3ffe8:


    hec "Pensi di poter decidere chi merita di restare?!"





translate italian observebox_ad601622:


    hec "Tutto questo gioco è una stronzata!"





translate italian observebox_af735833:


    hec "Siete tutti ipocriti!"





translate italian observebox_268aaefe:


    orushi "La decisione è definitiva."





translate italian observebox_fb9e53a4:


    hec "Andate a farvi fottere."





translate italian observebox_c80184b8:


    orushi "Giocatore Kira. Vediamo cosa c'è nella tua scatola."





translate italian observebox_869f53e1:


    kira "Perfetto."





translate italian observebox_7de0f032:


    orushi "Giocatore Mac. Vediamo ora cosa contiene la tua scatola."





translate italian observebox_c7696248:


    orushi "…Nessun gettone."





translate italian observebox_f80dea7d:


    mac "Che cosa?!"





translate italian observebox_60c7519a:


    ben "Bella, amico... te l'avevo detto che era l'altro."





translate italian observebox_d92fd476:


    mac "No, ci siamo incrociati! Pensavo che *tu* stessi prendendo Red's!"





translate italian observebox_4e249041:


    ruby "Ecco fatto. Due semicervelli non ne fanno uno intero."





translate italian observebox_0c2120c1:


    orushi "Sembra che un'alleanza senza riflessione sia destinata a fallire."





translate italian observebox_cd2893ad:


    orushi "Giocatore Ben. È il momento di rivelare cosa hai in mano."





translate italian observebox_ac36ddb9:


    orushi "…La tua casella è vuota."





translate italian observebox_72ed8d85:


    ben "Davvero?!"





translate italian observebox_f1d5bc35:


    mac "Hai preso quello di Kira, idiota..."





translate italian observebox_c3600366:


    ben "No! Era di Mac, non di Kira!"





translate italian observebox_f5b77199:


    beth "Dovremmo dare loro un segno di pietà."





translate italian observebox_e6242f29:


    orushi "Disattenzione. Confusione. Non importa come la si chiami, il risultato è sempre lo stesso."





translate italian observebox_c48f2526:


    orushi "Giocatrice Elizabeth. Il tuo turno."





translate italian observebox_e8ed82ca:


    orushi "…C'è un gettone all'interno della tua scatola."





translate italian observebox_ecf3d79e:


    beth "Ovviamente."





translate italian observebox_b72c5297:


    ruby "Hai controllato Hector all'inizio. Hai capito cosa stava succedendo?"





translate italian observebox_f353fcf0:


    beth "Mi sono accorto subito che c'era un problema nel nostro gruppo. Così l'ho corretto."





translate italian observebox_7ef400cc:


    d "(Si è rivoltata contro la sua stessa squadra. Fredda. Calcolatrice.)"





translate italian observebox_9cf9f448:


    emerick "Traditore."





translate italian observebox_18712cea:


    beth "Diciamo che preferisco puntare sull'intelligenza piuttosto che sull'arroganza."





translate italian observebox_44a16e27:


    ruby "Avevi controllato Grace..."





translate italian observebox_5e0488cd:


    beth "Sì. Punta sempre sul rosso."





translate italian observebox_f5a4af3c:


    dpense "Sempre egocentrico. Ma efficace."





translate italian observebox_f58573e9:


    orushi "Giocatrice Julia. È il tuo turno."





translate italian observebox_5bfa8e2b:


    ruby "Hai controllato Ben, vero?"





translate italian observebox_d1e1e790:


    julia "SÌ."





translate italian observebox_4b52c79e:


    ruby "Allora perché non sei andato a cercare Kira?"





translate italian observebox_d1f70c04:


    julia "..."





translate italian observebox_f31b8708:


    dpense "C'è qualcosa che non va..."





translate italian observebox_24a95c57:


    ruby "Quindi hai scelto la scatola di Steven..."





translate italian observebox_3f0dd858:


    julia "Esatto. Ho pensato che fosse la scelta migliore, date le circostanze."





translate italian observebox_ba15dbc5:


    dpense "Steven aveva la scatola di Madison... ma Kira aveva quella di Ben..."





translate italian observebox_0952e2a6:


    ruby "Quindi hai scelto la scatola di Blue?"





translate italian observebox_69e3e0f8:


    julia "Sì. Ho esitato... ma a quel punto mi è sembrata l'opzione più sicura."





translate italian observebox_2d8371f9:


    dpense "Avrebbe potuto scegliere Steven... o meglio ancora, Kira."





translate italian observebox_37d8e615:


    orushi "Giocatore Ruby. Il tuo turno."





translate italian observebox_3197b306:


    orushi "…C'è un gettone nella tua scatola."





translate italian observebox_8e9ab4e7:


    dpense "Sembra congelata... come se si aspettasse il peggio."





translate italian observebox_3193c932:


    mad "Ce l'hai fatta!"





translate italian observebox_0f2c1293:


    ruby "Io... l'ho fatto?"





translate italian observebox_85ff042c:


    d "Sì. Avevi la scatola di Emerick, giusto?"





translate italian observebox_7c8879d6:


    ruby "È lui che ha preso il mio... Ma io ho tenuto il suo. E non ho mai saputo se..."





translate italian observebox_94b8d948:


    ruby "Quando ho aiutato Madison, ho semplicemente accettato il mio destino. Pensavo che non sarei stato io."





translate italian observebox_87ad4670:


    mad "Hai fatto centro, Ruby."





translate italian observebox_c270dc58:


    ruby "Non ci posso credere..."





translate italian observebox_9013017e:


    ruby "In realtà sono riuscito a..."





translate italian observebox_18b51f9b:


    orushi "Un giocatore altruista e perspicace. Ma anche le scelte migliori a volte dipendono da un pizzico di fortuna."





translate italian observebox_1b038fdd:


    orushi "Giocatore [name]. Tocca a te."





translate italian observebox_11b6e570:


    d "SÌ!"





translate italian observebox_b1934d1a:


    ruby "Ce l'hai fatta!"





translate italian observebox_31063061:


    orushi "A volte, la mossa più intelligente... è non giocare troppo."





translate italian observebox_717cf009:


    d "Merda..."





translate italian observebox_1c2eed96:


    ruby "Tu... avevi un gettone nella tua scatola in origine. Perché l'hai scambiato?"





translate italian observebox_520730bb:


    d "Pensavo che forse Mac o Ben avessero maggiori probabilità..."





translate italian observebox_b0cd8174:


    sofia "NO...!"





translate italian observebox_88a75c4d:


    sofia "NO!"





translate italian observebox_70206759:


    sofia "Non lo lascerò andare così!"





translate italian observebox_5dced416:


    orushi "Hmm?"





translate italian observebox_c94f114d:


    sofia "Ho un gettone speciale... il gettone Sacrificio."





translate italian observebox_f852caa8:


    sofia "Voglio cedergli il mio posto."





translate italian observebox_5d296f3e:


    orushi "..."





translate italian observebox_71eb5446:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."





translate italian observebox_07cb4710:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta per cedere il posto a un altro giocatore eliminato."





translate italian observebox_f452c162:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"





translate italian observebox_a5cda67b:


    sofia "Per favore... resta con me."





translate italian observebox_53155274:


    dpense "Sofia..."





translate italian observebox_a0b873b8:


    dpense "Lei... sta piangendo per me?"





translate italian observebox_f195c7ff:


    d "Ti rendi conto di cosa significa?"





translate italian observebox_d0eb6209:


    sofia "Sì. Ma non mi interessa essere il migliore se questo significa restare solo."





translate italian observebox_6a9670cd:


    dpense "La stringo forte in un abbraccio..."





translate italian observebox_f4288911:


    d "Grazie. Un giorno ti ripagherò."





translate italian observebox_2bf1f1d9:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."





translate italian observebox_998c5c67:


    orushi "Questo gioco non è solo una questione di intelligenza o strategia. È anche una prova di ciò che sei disposto a sacrificare per gli altri."





translate italian observebox_114ae86f:


    orushi "Oggi hai dimostrato di non essere tentato dalle ricompense..."





translate italian observebox_56ed9463:


    orushi "Ma invece desideri elevare e aiutare chi ti circonda."





translate italian observebox_815a0bb9:


    orushi "Sarai immediatamente qualificato per il processo successivo. L'immunità è la tua ricompensa per questo atto."





translate italian observebox_df4d3d01:


    ruby "Oh."





translate italian observebox_325e86c7:


    dpense "Sono ancora qui grazie a lei."





translate italian observebox_25bb462a:


    dpense "E avrebbe potuto costarle tutto."





translate italian observebox_2774b746:


    orushi "Sei eliminato."





translate italian observebox_2c536cc9:


    d "Fanculo..."





translate italian observebox_7ea8f2bd:


    ruby "Io... io mi sbagliavo..."





translate italian observebox_16b3b1d0:


    ruby "Pensavo stesse bluffando, ma ha scelto una scatola senza gettoni apposta per intrappolarti."





translate italian observebox_72a7b667:


    ruby "Ti ho fatto perdere…"





translate italian observebox_82292ffe:


    d "Non potevi saperlo..."





translate italian observebox_a81f7dcc:


    emerick "Non si vince questa partita seguendo il proprio cuore."





translate italian observebox_ecb0e7fe:


    emerick "Bisogna pensare a una mossa in anticipo."





translate italian observebox_d93cefbd:


    sofia "Non lo lascerò andare così!"





translate italian observebox_781dbb01:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta, per cedere il posto a un altro giocatore eliminato."





translate italian observebox_cd3b6bc1:


    d "Capisci cosa significa?"





translate italian observebox_4744e459:


    sofia "Sì. Ma non mi interessa essere il migliore se sono da solo."





translate italian observebox_81607533:


    dpense "La stringo forte tra le mie braccia..."





translate italian observebox_5f088be5:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."





translate italian observebox_8a126ae0:


    orushi "Questo gioco non è solo una prova di intelligenza o strategia. Mette alla prova anche ciò che sei disposto a sacrificare per gli altri."





translate italian observebox_6a5a7c8b:


    orushi "Oggi hai dimostrato di non lasciarti tentare dal fascino della vittoria..."





translate italian observebox_9accf929:


    orushi "Ma che invece vuoi sostenere e incoraggiare chi ti circonda."





translate italian observebox_93f9a021:


    dpense "Sono ancora qui grazie a lei."





translate italian observebox_23148e2c:


    d "Uff... ha funzionato."





translate italian observebox_00153084:


    ruby "Ben fatto!"





translate italian observebox_bf6e0ecb:


    orushi "La tua scelta è stata quella giusta. Passi alla fase successiva."





translate italian observebox_f4288911_1:


    d "Grazie. Un giorno ti ripagherò."





translate italian observebox_5d296f3e_1:


    orushi "..."





translate italian observebox_5d296f3e_2:


    orushi "..."





translate italian observebox_5d296f3e_3:


    orushi "..."





translate italian observebox_815a0bb9_1:


    orushi "Sarai immediatamente qualificato per il processo successivo. L'immunità è la tua ricompensa per questo atto."





translate italian observebox_df4d3d01_1:


    ruby "Oh."





translate italian observebox_25bb462a_1:


    dpense "E avrebbe potuto costarle tutto."





translate italian observebox_2774b746_1:


    orushi "Sei eliminato."





translate italian observebox_3197b306_1:


    orushi "…C'è un gettone nella tua scatola."





translate italian observebox_3197b306_2:


    orushi "…C'è un gettone nella tua scatola."





translate italian e5s6_reveal_grace_dd66b7b6:


    orushi "Ultima scatola da rivelare... la giocatrice Grace."





translate italian e5s6_reveal_grace_3a0afec6:


    dpense "Lei è in piedi, con gli occhi fissi..."





translate italian e5s6_reveal_grace_2460a778:


    dpense "O non ha esitato, o lo ha nascosto molto bene."





translate italian e5s6_reveal_grace_3197b306:


    orushi "…C'è un gettone nella tua scatola."





translate italian e5s6_reveal_grace_4da47427:


    grace "Io... io ce l'ho fatta?!"





translate italian e5s6_reveal_grace_0b300a7d:


    ruby "Sì! Bella!"





translate italian e5s6_reveal_grace_79b24103:


    mad "Sapevo che ce l'avrebbe fatta."





translate italian e5s6_reveal_grace_ef1b0c25:


    dpense "L'ultimo a qualificarsi... grazie a Dio."





translate italian e5s6_reveal_grace_2490cefd:


    orushi "Il processo è ormai terminato."





translate italian e5s6_reveal_grace_4006ce28:


    orushi "Tutti i token sono stati rivelati."





translate italian e5s6_reveal_grace_4276c690:


    orushi "È tempo di concludere... e di parlare di ciò che verrà dopo."





translate italian e5s6_reveal_grace_394e93a6:


    d "Cosa succederà adesso?"





translate italian e5s6_63be2349:


    d "Che cosa..."





translate italian e5s6_8d826c96:


    d "È..."





translate italian e5s6_43dd0ffe:


    d "Questo posto?"





translate italian e5s6_7671f49d:


    d "Sembra l'ultimo podio disponibile."





translate italian e5s6_971c59f9:


    orushi "Il luogo che hai scelto ha segnato il tuo destino."





translate italian e5s6_a0031c50:


    orushi "Ogni posto corrisponde a una casella."





translate italian e5s6_d4759873:


    orushi "Ognuno di voi avrà l'opportunità di guardare segretamente all'interno di una scatola."





translate italian e5s6_ba297538:


    orushi "Attraverso il tablet sul tuo podio."





translate italian e5s6_observation_e0ba5112_1:


    ruby "Meglio ignorarli per semplificare le cose."





translate italian e5s6_observation_348067d8:


    dpense "Tutti fissano il loro podio... non sanno bene cosa farne."





translate italian e5s6_observation_3284c8da:


    dpense "Ruby è immersa nei suoi pensieri. I suoi occhi scrutano la stanza."





translate italian e5s6_observation_49af70de:


    ruby "Cosa ne pensi della postura di Steven?"





translate italian e5s6_observation_314c767a:


    ruby "È nervosa."





translate italian e5s6_observation_ebcf2176:


    mad "Io... spunterò una casella. Quella di Steven."





translate italian e5s6_observation_95f5ec4a:


    s "Quello di Madison."





translate italian e5s6_observation_e329c1fd:


    dpense "Nessuna parola. Nessuno sguardo."





translate italian e5s6_observation_80e94fc0:


    dpense "Il blu è calmo. Nessuno stress visibile."





translate italian e5s6_observation_4e4bb857:


    dpense "Lei mi guarda..."





translate italian e5s6_observation_0388a167:


    dpense "Lei rimane calma... Che strano."





translate italian e5s6_observation_4ddefbcd:


    hec "Quello di Julia."





translate italian e5s6_observation_d4fb69e8:


    dpense "Il suo volto, come sempre, è imperscrutabile."





translate italian e5s6_observation_240f57a3:


    dpense "Non guarda nessuno."





translate italian e5s6_observation_89a54bb2:


    kira "Quello di Ben."





translate italian e5s6_observation_d66ee7fe:


    dpense "Non c'era traccia di emozione sul suo viso."





translate italian e5s6_observation_99603abd:


    mac "Ben è uno!"





translate italian e5s6_observation_ebef6679:


    ruby "Azione inutile."





translate italian e5s6_observation_45f96703:


    dpense "È... per me?"





translate italian e5s6_observation_8379d5b0:


    dpense "Fissa Grace a lungo... quasi come se la stesse guardando dall'alto."





translate italian e5s6_observation_a3026be4:


    ruby "Dato che Ben guardava Mac, forse stava seguendo una catena. Ottenendo una lettura più ampia rispetto alle altre."





translate italian e5s6_observation_cf9bdec6:


    dpense "Ronzio..."





translate italian e5s6_observation_b21bc917:


    dpense "Lei resta lì senza dire una parola."





translate italian e5s6_observation_354038e0:


    dpense "Lo studia per un lungo momento."





translate italian e5s6_observation_4a3f2c65:


    dpense "Solo una casella da spuntare. E non la mia."





translate italian observebox_76b98c9b:


    dpense "Ho scelto la scatola di [chosenbox]."





translate italian observebox_3f819674:


    dpense "Vediamo cosa c'è dentro..."





translate italian observebox_37abc764:


    ruby "Non perderà tempo."





translate italian observebox_ad5ca45e:


    grace "Quello di Mac."





translate italian observebox_9bec83be:


    d "Sembra... fredda."





translate italian observebox_cfa5dd14:


    emerick "Prenderò quello di Ruby"





translate italian observebox_043e9f57:


    dpense "Lei non sta tremando."





translate italian observebox_21d3d23c:


    dpense "Lancia un'occhiata a Steven, poi al suo podio."





translate italian observebox_f892ddd4:


    dpense "Steven, sicuro di sé come sempre."





translate italian observebox_42dd5504:


    ruby "Lui ha visto la sua scatola. Sa esattamente cosa c'è dentro."





translate italian observebox_8bd60aeb:


    ruby "Quindi Steven deve aver visto un gettone all'interno."





translate italian observebox_38368806:


    dpense "Il suo sguardo scruta brevemente la stanza, poi si ferma dritto davanti a sé."





translate italian observebox_bc3c2b19:


    dpense "Mi guarda per un secondo."





translate italian observebox_f5a58c6f:


    d "Ma lei ha visto la mia scatola..."





translate italian observebox_d84d7e95:


    ruby "Potrebbe essere parte della sua strategia."





translate italian observebox_668b2336:


    dpense "Guardo Hector. È il suo turno."





translate italian observebox_4ddefbcd:


    hec "Quello di Julia."





translate italian observebox_dd2a4560:


    dpense "È chiaramente soddisfatto di sé."





translate italian observebox_c1e18fbb:


    kira "Ben..."





translate italian observebox_2eafc64b:


    dpense "Prende anche quello di Ben?"





translate italian observebox_47487229:


    ruby "Oppure ha semplicemente rischiato tutto, sperando che uno di loro fosse stupido."





translate italian observebox_490c8399:


    julia "Quello di Steven..."





translate italian observebox_d6520aff:


    ruby "E insieme a Elizabeth, è uno dei pochi che attualmente detiene una scatola che molto probabilmente contiene un gettone."





translate italian observebox_c0bb2703:


    ruby "Voglio scambiare le scatole di Hector e Madison."





translate italian observebox_0401e78a:


    orushi "[name]?"





translate italian observebox_cd3a2992:


    dpense "Posso cambiare la mia scatola o tenerla?"





translate italian observebox_a9c69f39:


    dpense "Farò uno scambio con qualcuno..."





translate italian observebox_2bfa840a:


    dpense "Ma la domanda è... Con chi?"





translate italian observebox_218eb14c:


    d "Io tengo il mio."





translate italian observebox_6fcaa1ce_1:


    sofia "Io tengo il mio..."





translate italian herochosenbox_15c8431d:


    d "Io prenderò [herofinalbox] è uno."





translate italian herochosenbox_175acb31:


    sofia "Tu... Pensi davvero che sia stata una buona idea?"





translate italian herochosenbox_c45efa37:


    dpense "Il suo sguardo mi trafigge. Non rabbia... solo incredulità ferita."





translate italian herochosenbox_78e93c48:


    sofia "Avresti potuto fidarti di me."





translate italian herochosenbox_3b8b4697:


    dpense "Ho fatto un errore?"





translate italian revealtrial_e4da9d25:


    orushi "Molto bene. Grace? Tocca a te."





translate italian revealtrial_ec10dc98:


    dpense "Non dice nulla. Guarda solo con attenzione la sua scatola."





translate italian revealtrial_87a9f53c:


    grace "Io terrò il mio."





translate italian revealtrial_31227e7c:


    dpense "Non ci sono dubbi. È sicura di sé."





translate italian revealtrial_7e1415e0:


    dpense "Ultimo round completato."





translate italian revealtrial_56ae23ff:


    orushi "Ottimo."





translate italian revealtrial_e131215e:


    orushi "Avete tutti avuto l'opportunità di verificare. Di agire. Di tradire."





translate italian revealtrial_fb44ccf8:


    orushi "Ogni mossa è stata annotata. Ogni esitazione rivelatrice."





translate italian revealtrial_31e89f22:


    orushi "Ma ora il tempo della strategia è finito."





translate italian revealtrial_19da0fa9:


    orushi "Ciò che troverai nelle tue scatole determinerà cosa accadrà dopo."





translate italian revealtrial_f86ad1e4:


    orushi "Ricorda: solo coloro che hanno un token potranno procedere alla prova successiva."





translate italian revealtrial_7612ad25:


    orushi "E per gli altri… il viaggio finisce qui."





translate italian revealtrial_0d45be32:


    dpense "Un silenzio pesante cala nella stanza."





translate italian revealtrial_fda72d86:


    dpense "Tutti fissano la loro scatola. Alcuni con sicurezza, altri con un'ansia malcelata."





translate italian revealtrial_f91235b9:


    orushi "Li apriremo. Uno per uno."





translate italian revealtrial_203b5f14:


    orushi "Giocatore Emerick. Iniziamo con te."





translate italian revealtrial_974ba520:


    orushi "Token confermato."





translate italian revealtrial_9a845405:


    ruby "Aveva davvero un gettone. Non mi sbagliavo..."





translate italian revealtrial_952daa01:


    emerick "Naturalmente avevo un gettone."





translate italian revealtrial_481b1855:


    emerick "E sei stato intelligente a non intrometterti nei miei affari."





translate italian revealtrial_930dd552:


    emerick "Forse meriti di andare avanti."





translate italian revealtrial_37771d92:


    orushi "Il bluff può essere un'arma potente..."





translate italian revealtrial_a2c85619:


    orushi "Ma la vera abilità sta nel non cadere nella trappola."





translate italian revealtrial_cad105a2:


    ruby "No... no no no..."





translate italian revealtrial_4a31fccb:


    ruby "Mi sbagliavo…"





translate italian revealtrial_474f9baa:


    d "Rubino..."





translate italian revealtrial_a0066e41:


    ruby "Pensavo che stesse bluffando..."





translate italian revealtrial_93b51ce3:


    ruby "Ha preso la mia scatola perché sapeva che era vuota..."





translate italian revealtrial_3e244d8a:


    ruby "E ha fatto di tutto per assicurarsi che tu volessi riprendertelo..."





translate italian revealtrial_ba4d9261:


    ruby "Era tutta una trappola. E ci sono finito dentro."





translate italian revealtrial_9401799d:


    ruby "Ti ho fatto perdere il tuo gettone..."





translate italian revealtrial_e0b0d250:


    d "Non mi hai fatto perdere nulla, Ruby. Ho fatto la scelta."





translate italian revealtrial_46bbe90c:


    emerick "È troppo tardi per le scuse, piccioncini."





translate italian revealtrial_8ba239ca:


    emerick "Hai giocato e hai perso."





translate italian revealtrial_910e4247:


    emerick "Mentre eri impegnato a sospettare di me, ho preso il tuo posto."





translate italian revealtrial_329dfa00:


    emerick "Pensavi davvero che mi importasse del mio gettone?"





translate italian revealtrial_5f1da96a:


    emerick "Tutto ciò che volevo era prenderti."





translate italian revealtrial_1ea28260:


    emerick "Sapevo che non avresti toccato la scatola di Ruby per principio!"





translate italian revealtrial_06cce23c:


    emerick "E tu hai abboccato. Patetico."





translate italian revealtrial_7be61e20:


    orushi "Una mossa davvero rara. Mettere a repentaglio la propria vittoria solo per sconfiggere un avversario. Rischioso. Ma efficace."





translate italian revealtrial_e9754cba:


    ruby "..."





translate italian revealtrial_4f50ea4b:


    orushi "L'arte della manipolazione, applicata con abilità."





translate italian revealtrial_f4581a68:


    orushi "Quando ci si concentra troppo sull'intento, si dimentica la conseguenza."





translate italian revealtrial_508c25d5:


    orushi "E ci sono ancora altre rivelazioni in arrivo..."





translate italian revealtrial_f156f9d9:


    orushi "Giocatrice Madison. Il tuo turno."





translate italian revealtrial_62e0e823:


    mad "Grazie, Ruby..."





translate italian revealtrial_b0a89566:


    mad "Non so come ringraziarti..."





translate italian revealtrial_88e218a6:


    ruby "È al sicuro..."





translate italian revealtrial_97edf630:


    d "L'hai salvata, Ruby."





translate italian revealtrial_398d812b:


    ruby "È il minimo che potessi fare."





translate italian revealtrial_f13f6513:


    orushi "La strategia può portare a una buona scelta, anche se non è la tua strategia."





translate italian revealtrial_3ff30284:


    orushi "Ora... continuiamo."





translate italian revealtrial_e8527e4f:


    orushi "Giocatore Steven. Vediamo cosa c'è nella tua scatola..."





translate italian revealtrial_c961a606:


    s "Ovviamente."





translate italian revealtrial_e944a555:


    s "C'è un motivo per cui sono il capitano."





translate italian revealtrial_9d5b49f0:


    d "Steven aveva un vantaggio posizionale."





translate italian revealtrial_13c6e254:


    orushi "Strategia, compostezza o puro istinto... In fin dei conti, è una questione tua, Steven."





translate italian revealtrial_f61ca382:


    orushi "Giocatrice Sofia. Il tuo turno."





translate italian revealtrial_2d609d6b:


    sofia "Io... io ho..."





translate italian revealtrial_4e4fec28:


    orushi "Shhh..."





translate italian revealtrial_3f6c7933:


    sofia "Uff... Almeno questo è fatto."





translate italian revealtrial_d8de9c70:


    orushi "Giocatore Hector. Il tuo turno."





translate italian revealtrial_6f4ae617:


    orushi "La casella è vuota."





translate italian revealtrial_c16e21b8:


    hec "Che cosa?!" with hpunch





translate italian revealtrial_52249f1b:


    hec "Ma io ho rispettato le regole!"





translate italian revealtrial_fd3898fd:


    hec "Come può essere vuoto?!"





translate italian revealtrial_a7bc9564:


    hec "Aspetta... Sono Ruby! Mi hai incastrato!"





translate italian revealtrial_e5890989:


    hec "Quando hai scambiato la mia scatola e l'hai data a Madison!"





translate italian revealtrial_4cc575e6:


    ruby "Ho fatto quello che dovevo fare."





translate italian revealtrial_a4f3ffe8:


    hec "Pensi di poter decidere chi merita di restare?!"





translate italian revealtrial_ad601622:


    hec "Tutto questo gioco è una stronzata!"





translate italian revealtrial_af735833:


    hec "Siete tutti ipocriti!"





translate italian revealtrial_268aaefe:


    orushi "La decisione è definitiva."





translate italian revealtrial_fb9e53a4:


    hec "Andate a farvi fottere."





translate italian revealtrial_c80184b8:


    orushi "Giocatore Kira. Vediamo cosa c'è nella tua scatola."





translate italian revealtrial_869f53e1:


    kira "Perfetto."





translate italian revealtrial_7de0f032:


    orushi "Giocatore Mac. Vediamo ora cosa contiene la tua scatola."





translate italian revealtrial_c7696248:


    orushi "…Nessun gettone."





translate italian revealtrial_f80dea7d:


    mac "Che cosa?!"





translate italian revealtrial_460a57b3:


    ben "Bella, amico... Ti avevo detto che era l'altra."





translate italian revealtrial_fad285ea:


    mac "No, ci siamo incrociati! Pensavo che stessi prendendo Red's!"





translate italian revealtrial_4e249041:


    ruby "Ecco fatto. Due semicervelli non ne fanno uno intero."





translate italian revealtrial_0c2120c1:


    orushi "Sembra che un'alleanza senza riflessione sia destinata a fallire."





translate italian revealtrial_cd2893ad:


    orushi "Giocatore Ben. È il momento di rivelare cosa hai in mano."





translate italian revealtrial_ac36ddb9:


    orushi "…La tua casella è vuota."





translate italian revealtrial_72ed8d85:


    ben "Davvero?!"





translate italian revealtrial_f1d5bc35:


    mac "Hai preso quello di Kira, idiota..."





translate italian revealtrial_2b2d5a4b:


    ben "No! Era tuo, non di Kira!"





translate italian revealtrial_f5b77199:


    beth "Dovremmo dare loro un segno di pietà."





translate italian revealtrial_e6242f29:


    orushi "Disattenzione. Confusione. Non importa come la si chiami, il risultato è sempre lo stesso."





translate italian revealtrial_c48f2526:


    orushi "Giocatrice Elizabeth. Il tuo turno."





translate italian revealtrial_9e1e3719:


    orushi "Qualificato."





translate italian revealtrial_ecf3d79e:


    beth "Ovviamente."





translate italian revealtrial_b72c5297:


    ruby "Hai controllato Hector all'inizio. Hai capito cosa stava succedendo?"





translate italian revealtrial_f353fcf0:


    beth "Mi sono accorto subito che c'era un problema nel nostro gruppo. Così l'ho corretto."





translate italian revealtrial_71bc0f38:


    dpense "Si è rivoltata contro la sua stessa squadra. Fredda. Calcolatrice."





translate italian revealtrial_9cf9f448:


    emerick "Traditore."





translate italian revealtrial_18712cea:


    beth "Diciamo che preferisco puntare sull'intelligenza piuttosto che sull'arroganza."





translate italian revealtrial_44a16e27:


    ruby "Avevi controllato Grace..."





translate italian revealtrial_5e0488cd:


    beth "Sì. Punta sempre sul rosso."





translate italian revealtrial_f5a4af3c:


    dpense "Sempre egocentrico. Ma efficace."





translate italian revealtrial_f58573e9:


    orushi "Giocatrice Julia. È il tuo turno."





translate italian revealtrial_e8ed82ca:


    orushi "…C'è un gettone all'interno della tua scatola."





translate italian revealtrial_5bfa8e2b:


    ruby "Hai controllato Ben, vero?"





translate italian revealtrial_d1e1e790:


    julia "SÌ."





translate italian revealtrial_4b52c79e:


    ruby "Allora perché non sei andato a cercare Kira?"





translate italian revealtrial_d1f70c04:


    julia "..."





translate italian revealtrial_f31b8708:


    dpense "C'è qualcosa che non va..."





translate italian revealtrial_37d8e615:


    orushi "Giocatore Ruby. Il tuo turno."





translate italian revealtrial_2dc2021c:


    orushi "Sei qualificato."





translate italian revealtrial_8e9ab4e7:


    dpense "Sembra congelata... come se si aspettasse il peggio."





translate italian revealtrial_3193c932:


    mad "Ce l'hai fatta!"





translate italian revealtrial_0f2c1293:


    ruby "Io... l'ho fatto?"





translate italian revealtrial_85ff042c:


    d "Sì. Avevi la scatola di Emerick, giusto?"





translate italian revealtrial_7c8879d6:


    ruby "È lui che ha preso il mio... Ma io ho tenuto il suo. E non ho mai saputo se..."





translate italian revealtrial_94b8d948:


    ruby "Quando ho aiutato Madison, ho semplicemente accettato il mio destino. Pensavo che non sarei stato io."





translate italian revealtrial_87ad4670:


    mad "Hai fatto centro, Ruby."





translate italian revealtrial_c270dc58:


    ruby "Non ci posso credere..."





translate italian revealtrial_9013017e:


    ruby "In realtà sono riuscito a..."





translate italian revealtrial_cd027434:


    orushi "Un giocatore altruista e perspicace."





translate italian revealtrial_aa20706b:


    orushi "Ma anche le scelte migliori a volte dipendono da un pizzico di fortuna."





translate italian revealtrial_1b038fdd:


    orushi "Giocatore [name]. Tocca a te."





translate italian revealtrial_d0a04df4:


    dpense "Eccoci qui."





translate italian revealtrial_2b78399e:


    dpense "Spero di non aver commesso errori."





translate italian revealtrial_46aadbcb:


    dpense "Mi guardano tutti..."





translate italian revealtrial_05392ae5:


    dpense "Non posso fallire adesso..."





translate italian revealtrial_3197b306:


    orushi "…C'è un gettone nella tua scatola."





translate italian revealtrial_11b6e570:


    d "SÌ!"





translate italian revealtrial_b1934d1a:


    ruby "Ce l'hai fatta!"





translate italian revealtrial_31063061:


    orushi "A volte, la mossa più intelligente... è non giocare troppo."





translate italian revealtrial_717cf009:


    d "Merda..."





translate italian revealtrial_24b7c379:


    ruby "Tu... Perché l'hai scambiato con lui?"





translate italian revealtrial_520730bb:


    d "Pensavo che forse Mac o Ben avessero maggiori probabilità..."





translate italian revealtrial_b0cd8174:


    sofia "NO...!"





translate italian revealtrial_88a75c4d:


    sofia "NO!"





translate italian revealtrial_70206759:


    sofia "Non lo lascerò andare così!"





translate italian revealtrial_5dced416:


    orushi "Hmm?"





translate italian revealtrial_69d62481:


    sofia "Sul mio gettone è scritta l'opzione Sacrificio."





translate italian revealtrial_5d296f3e:


    orushi "..."





translate italian revealtrial_71eb5446:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."





translate italian revealtrial_07cb4710:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta per cedere il posto a un altro giocatore eliminato."





translate italian revealtrial_f452c162:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"





translate italian revealtrial_a7f852ab:


    sofia "Per favore... voglio che tu resti con me."





translate italian revealtrial_e2ac8e66:


    d "Sofia..."





translate italian revealtrial_f195c7ff:


    d "Ti rendi conto di cosa significa?"





translate italian revealtrial_d0eb6209:


    sofia "Sì. Ma non mi interessa essere il migliore se questo significa restare solo."





translate italian revealtrial_2bf1f1d9:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."





translate italian revealtrial_9debc0ee:


    orushi "Questo gioco non riguarda solo intelligenza o strategia."





translate italian revealtrial_bad6979e:


    orushi "È anche una prova di ciò che sei disposto a sacrificare per gli altri."





translate italian revealtrial_114ae86f:


    orushi "Oggi hai dimostrato di non essere tentato dalle ricompense..."





translate italian revealtrial_56ed9463:


    orushi "Ma invece desideri elevare e aiutare chi ti circonda."





translate italian revealtrial_09d1ab31:


    orushi "Sarai immediatamente qualificato e l'immunità sarà la tua ricompensa per questo atto."





translate italian revealtrial_df4d3d01:


    ruby "Oh."





translate italian revealtrial_3a43fcc0:


    orushi "Ma c'è sempre una controparte."





translate italian revealtrial_b279dc41:


    orushi "Te lo spiegherò più tardi."





translate italian revealtrial_f5996909:


    orushi "[name]..."





translate italian revealtrial_357a3333:


    orushi "Tu continui."





translate italian revealtrial_325e86c7:


    dpense "Sono ancora qui grazie a lei."





translate italian revealtrial_25bb462a:


    dpense "E avrebbe potuto costarle tutto."





translate italian revealtrial_2774b746:


    orushi "Sei eliminato."





translate italian revealtrial_2c536cc9:


    d "Fanculo..."





translate italian revealtrial_7ea8f2bd:


    ruby "Io... io mi sbagliavo..."





translate italian revealtrial_16b3b1d0:


    ruby "Pensavo stesse bluffando, ma ha scelto una scatola senza gettoni apposta per intrappolarti."





translate italian revealtrial_72a7b667:


    ruby "Ti ho fatto perdere…"





translate italian revealtrial_82292ffe:


    d "Non potevi saperlo..."





translate italian revealtrial_a81f7dcc:


    emerick "Non si vince questa partita seguendo il proprio cuore."





translate italian revealtrial_ecb0e7fe:


    emerick "Bisogna pensare a una mossa in anticipo."





translate italian revealtrial_23148e2c:


    d "Uff... ha funzionato."





translate italian revealtrial_00153084:


    ruby "Ben fatto!"





translate italian revealtrial_bf6e0ecb:


    orushi "La tua scelta è stata quella giusta. Passi alla fase successiva."





translate italian revealtrial_974ba520_1:


    orushi "Token confermato."





translate italian revealtrial_974ba520_2:


    orushi "Token confermato."





translate italian revealtrial_974ba520_3:


    orushi "Token confermato."





translate italian revealtrial_974ba520_4:


    orushi "Token confermato."





translate italian revealtrial_ecf3d79e_1:


    beth "Ovviamente."





translate italian revealtrial_e9754cba_1:


    ruby "..."





translate italian revealtrial_ac36ddb9_1:


    orushi "…La tua casella è vuota."





translate italian revealtrial_ac36ddb9_2:


    orushi "…La tua casella è vuota."





translate italian revealtrial_5d296f3e_1:


    orushi "..."





translate italian revealtrial_5d296f3e_2:


    orushi "..."





translate italian revealtrial_5d296f3e_3:


    orushi "..."





translate italian revealtrial_b0cd8174_1:


    sofia "NO...!"





translate italian revealtrial_88a75c4d_1:


    sofia "NO!"





translate italian revealtrial_70206759_1:


    sofia "Non lo lascerò andare così!"





translate italian revealtrial_5dced416_1:


    orushi "Hmm?"





translate italian revealtrial_69d62481_1:


    sofia "Sul mio gettone è scritta l'opzione Sacrificio."





translate italian revealtrial_71eb5446_1:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."





translate italian revealtrial_07cb4710_1:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta per cedere il posto a un altro giocatore eliminato."





translate italian revealtrial_f452c162_1:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"





translate italian revealtrial_a7f852ab_1:


    sofia "Per favore... voglio che tu resti con me."





translate italian revealtrial_e2ac8e66_1:


    d "Sofia..."





translate italian revealtrial_f195c7ff_1:


    d "Ti rendi conto di cosa significa?"





translate italian revealtrial_d0eb6209_1:


    sofia "Sì. Ma non mi interessa essere il migliore se questo significa restare solo."





translate italian revealtrial_2bf1f1d9_1:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."





translate italian revealtrial_9debc0ee_1:


    orushi "Questo gioco non riguarda solo intelligenza o strategia."





translate italian revealtrial_bad6979e_1:


    orushi "È anche una prova di ciò che sei disposto a sacrificare per gli altri."





translate italian revealtrial_114ae86f_1:


    orushi "Oggi hai dimostrato di non essere tentato dalle ricompense..."





translate italian revealtrial_56ed9463_1:


    orushi "Ma invece desideri elevare e aiutare chi ti circonda."





translate italian revealtrial_09d1ab31_1:


    orushi "Sarai immediatamente qualificato e l'immunità sarà la tua ricompensa per questo atto."





translate italian revealtrial_df4d3d01_1:


    ruby "Oh."





translate italian revealtrial_3a43fcc0_1:


    orushi "Ma c'è sempre una controparte."





translate italian revealtrial_b279dc41_1:


    orushi "Te lo spiegherò più tardi."





translate italian revealtrial_f5996909_1:


    orushi "[name]..."





translate italian revealtrial_357a3333_1:


    orushi "Tu continui."





translate italian revealtrial_325e86c7_1:


    dpense "Sono ancora qui grazie a lei."





translate italian revealtrial_25bb462a_1:


    dpense "E avrebbe potuto costarle tutto."





translate italian revealtrial_2774b746_1:


    orushi "Sei eliminato."





translate italian revealtrial_3197b306_1:


    orushi "…C'è un gettone nella tua scatola."





translate italian e5s6_63be2349:


    d "Che cosa..."





translate italian e5s6_8d826c96:


    d "È..."





translate italian e5s6_43dd0ffe:


    d "Questo posto?"





translate italian e5s6_7671f49d:


    d "Sembra l'ultimo podio disponibile."





translate italian e5s6_971c59f9:


    orushi "Il luogo che hai scelto ha segnato il tuo destino."





translate italian e5s6_a0031c50:


    orushi "Ogni posto corrisponde a una casella."





translate italian e5s6_d4759873:


    orushi "Ognuno di voi avrà l'opportunità di guardare segretamente all'interno di una scatola."





translate italian e5s6_ba297538:


    orushi "Attraverso il tablet sul tuo podio."





translate italian e5s6_observation_e0ba5112_1:


    ruby "Meglio ignorarli per semplificare le cose."





translate italian e5s6_observation_348067d8:


    dpense "Tutti fissano il loro podio... non sanno bene cosa farne."





translate italian e5s6_observation_3284c8da:


    dpense "Ruby è immersa nei suoi pensieri. I suoi occhi scrutano la stanza."





translate italian e5s6_observation_49af70de:


    ruby "Cosa ne pensi della postura di Steven?"





translate italian e5s6_observation_314c767a:


    ruby "È nervosa."





translate italian e5s6_observation_ebcf2176:


    mad "Io... spunterò una casella. Quella di Steven."





translate italian e5s6_observation_95f5ec4a:


    s "Quello di Madison."





translate italian e5s6_observation_e329c1fd:


    dpense "Nessuna parola. Nessuno sguardo."





translate italian e5s6_observation_80e94fc0:


    dpense "Il blu è calmo. Nessuno stress visibile."





translate italian e5s6_observation_4e4bb857:


    dpense "Lei mi guarda..."





translate italian e5s6_observation_0388a167:


    dpense "Lei rimane calma... Che strano."





translate italian e5s6_observation_4ddefbcd:


    hec "Quello di Julia."





translate italian e5s6_observation_d4fb69e8:


    dpense "Il suo volto, come sempre, è imperscrutabile."





translate italian e5s6_observation_240f57a3:


    dpense "Non guarda nessuno."





translate italian e5s6_observation_89a54bb2:


    kira "Quello di Ben."





translate italian e5s6_observation_d66ee7fe:


    dpense "Non c'era traccia di emozione sul suo viso."





translate italian e5s6_observation_99603abd:


    mac "Ben è uno!"





translate italian e5s6_observation_ebef6679:


    ruby "Azione inutile."





translate italian e5s6_observation_45f96703:


    dpense "È... per me?"





translate italian e5s6_observation_8379d5b0:


    dpense "Fissa Grace a lungo... quasi come se la stesse guardando dall'alto."





translate italian e5s6_observation_a3026be4:


    ruby "Dato che Ben guardava Mac, forse stava seguendo una catena. Ottenendo una lettura più ampia rispetto alle altre."





translate italian e5s6_observation_cf9bdec6:


    dpense "Ronzio..."





translate italian e5s6_observation_b21bc917:


    dpense "Lei resta lì senza dire una parola."





translate italian e5s6_observation_354038e0:


    dpense "Lo studia per un lungo momento."





translate italian e5s6_observation_4a3f2c65:


    dpense "Solo una casella da spuntare. E non la mia."





translate italian observebox_76b98c9b:


    dpense "Ho scelto la scatola di [chosenbox]."





translate italian observebox_3f819674:


    dpense "Vediamo cosa c'è dentro..."





translate italian observebox_37abc764:


    ruby "Non perderà tempo."





translate italian observebox_ad5ca45e:


    grace "Quello di Mac."





translate italian observebox_9bec83be:


    d "Sembra... fredda."





translate italian observebox_cfa5dd14:


    emerick "Prenderò quello di Ruby"





translate italian observebox_043e9f57:


    dpense "Lei non sta tremando."





translate italian observebox_21d3d23c:


    dpense "Lancia un'occhiata a Steven, poi al suo podio."





translate italian observebox_f892ddd4:


    dpense "Steven, sicuro di sé come sempre."





translate italian observebox_42dd5504:


    ruby "Lui ha visto la sua scatola. Sa esattamente cosa c'è dentro."





translate italian observebox_8bd60aeb:


    ruby "Quindi Steven deve aver visto un gettone all'interno."





translate italian observebox_38368806:


    dpense "Il suo sguardo scruta brevemente la stanza, poi si ferma dritto davanti a sé."





translate italian observebox_bc3c2b19:


    dpense "Mi guarda per un secondo."





translate italian observebox_f5a58c6f:


    d "Ma lei ha visto la mia scatola..."





translate italian observebox_d84d7e95:


    ruby "Potrebbe essere parte della sua strategia."





translate italian observebox_668b2336:


    dpense "Guardo Hector. È il suo turno."





translate italian observebox_4ddefbcd:


    hec "Quello di Julia."





translate italian observebox_dd2a4560:


    dpense "È chiaramente soddisfatto di sé."





translate italian observebox_c1e18fbb:


    kira "Ben..."





translate italian observebox_2eafc64b:


    dpense "Prende anche quello di Ben?"





translate italian observebox_47487229:


    ruby "Oppure ha semplicemente rischiato tutto, sperando che uno di loro fosse stupido."





translate italian observebox_490c8399:


    julia "Quello di Steven..."





translate italian observebox_d6520aff:


    ruby "E insieme a Elizabeth, è uno dei pochi che attualmente detiene una scatola che molto probabilmente contiene un gettone."





translate italian observebox_c0bb2703:


    ruby "Voglio scambiare le scatole di Hector e Madison."





translate italian observebox_0401e78a:


    orushi "[name]?"





translate italian observebox_cd3a2992:


    dpense "Posso cambiare la mia scatola o tenerla?"





translate italian observebox_a9c69f39:


    dpense "Farò uno scambio con qualcuno..."





translate italian observebox_2bfa840a:


    dpense "Ma la domanda è... Con chi?"





translate italian observebox_218eb14c:


    d "Io tengo il mio."





translate italian observebox_6fcaa1ce_1:


    sofia "Io tengo il mio..."





translate italian herochosenbox_15c8431d:


    d "Io prenderò [herofinalbox] è uno."





translate italian herochosenbox_175acb31:


    sofia "Tu... Pensi davvero che sia stata una buona idea?"





translate italian herochosenbox_c45efa37:


    dpense "Il suo sguardo mi trafigge. Non rabbia... solo incredulità ferita."





translate italian herochosenbox_78e93c48:


    sofia "Avresti potuto fidarti di me."





translate italian herochosenbox_3b8b4697:


    dpense "Ho fatto un errore?"





translate italian revealtrial_e4da9d25:


    orushi "Molto bene. Grace? Tocca a te."





translate italian revealtrial_ec10dc98:


    dpense "Non dice nulla. Guarda solo con attenzione la sua scatola."





translate italian revealtrial_87a9f53c:


    grace "Io terrò il mio."





translate italian revealtrial_31227e7c:


    dpense "Non ci sono dubbi. È sicura di sé."





translate italian revealtrial_7e1415e0:


    dpense "Ultimo round completato."





translate italian revealtrial_56ae23ff:


    orushi "Ottimo."





translate italian revealtrial_e131215e:


    orushi "Avete tutti avuto l'opportunità di verificare. Di agire. Di tradire."





translate italian revealtrial_fb44ccf8:


    orushi "Ogni mossa è stata annotata. Ogni esitazione rivelatrice."





translate italian revealtrial_31e89f22:


    orushi "Ma ora il tempo della strategia è finito."





translate italian revealtrial_19da0fa9:


    orushi "Ciò che troverai nelle tue scatole determinerà cosa accadrà dopo."





translate italian revealtrial_f86ad1e4:


    orushi "Ricorda: solo coloro che hanno un token potranno procedere alla prova successiva."





translate italian revealtrial_7612ad25:


    orushi "E per gli altri… il viaggio finisce qui."





translate italian revealtrial_0d45be32:


    dpense "Un silenzio pesante cala nella stanza."





translate italian revealtrial_fda72d86:


    dpense "Tutti fissano la loro scatola. Alcuni con sicurezza, altri con un'ansia malcelata."





translate italian revealtrial_f91235b9:


    orushi "Li apriremo. Uno per uno."





translate italian revealtrial_203b5f14:


    orushi "Giocatore Emerick. Iniziamo con te."





translate italian revealtrial_974ba520:


    orushi "Token confermato."





translate italian revealtrial_9a845405:


    ruby "Aveva davvero un gettone. Non mi sbagliavo..."





translate italian revealtrial_952daa01:


    emerick "Naturalmente avevo un gettone."





translate italian revealtrial_481b1855:


    emerick "E sei stato intelligente a non intrometterti nei miei affari."





translate italian revealtrial_930dd552:


    emerick "Forse meriti di andare avanti."





translate italian revealtrial_37771d92:


    orushi "Il bluff può essere un'arma potente..."





translate italian revealtrial_a2c85619:


    orushi "Ma la vera abilità sta nel non cadere nella trappola."





translate italian revealtrial_cad105a2:


    ruby "No... no no no..."





translate italian revealtrial_4a31fccb:


    ruby "Mi sbagliavo…"





translate italian revealtrial_474f9baa:


    d "Rubino..."





translate italian revealtrial_a0066e41:


    ruby "Pensavo che stesse bluffando..."





translate italian revealtrial_93b51ce3:


    ruby "Ha preso la mia scatola perché sapeva che era vuota..."





translate italian revealtrial_3e244d8a:


    ruby "E ha fatto di tutto per assicurarsi che tu volessi riprendertelo..."





translate italian revealtrial_ba4d9261:


    ruby "Era tutta una trappola. E ci sono finito dentro."





translate italian revealtrial_9401799d:


    ruby "Ti ho fatto perdere il tuo gettone..."





translate italian revealtrial_e0b0d250:


    d "Non mi hai fatto perdere nulla, Ruby. Ho fatto la scelta."





translate italian revealtrial_46bbe90c:


    emerick "È troppo tardi per le scuse, piccioncini."





translate italian revealtrial_8ba239ca:


    emerick "Hai giocato e hai perso."





translate italian revealtrial_910e4247:


    emerick "Mentre eri impegnato a sospettare di me, ho preso il tuo posto."





translate italian revealtrial_329dfa00:


    emerick "Pensavi davvero che mi importasse del mio gettone?"





translate italian revealtrial_5f1da96a:


    emerick "Tutto ciò che volevo era prenderti."





translate italian revealtrial_1ea28260:


    emerick "Sapevo che non avresti toccato la scatola di Ruby per principio!"





translate italian revealtrial_06cce23c:


    emerick "E tu hai abboccato. Patetico."





translate italian revealtrial_7be61e20:


    orushi "Una mossa davvero rara. Mettere a repentaglio la propria vittoria solo per sconfiggere un avversario. Rischioso. Ma efficace."





translate italian revealtrial_e9754cba:


    ruby "..."





translate italian revealtrial_4f50ea4b:


    orushi "L'arte della manipolazione, applicata con abilità."





translate italian revealtrial_f4581a68:


    orushi "Quando ci si concentra troppo sull'intento, si dimentica la conseguenza."





translate italian revealtrial_508c25d5:


    orushi "E ci sono ancora altre rivelazioni in arrivo..."





translate italian revealtrial_f156f9d9:


    orushi "Giocatrice Madison. Il tuo turno."





translate italian revealtrial_62e0e823:


    mad "Grazie, Ruby..."





translate italian revealtrial_b0a89566:


    mad "Non so come ringraziarti..."





translate italian revealtrial_88e218a6:


    ruby "È al sicuro..."





translate italian revealtrial_97edf630:


    d "L'hai salvata, Ruby."





translate italian revealtrial_398d812b:


    ruby "È il minimo che potessi fare."





translate italian revealtrial_f13f6513:


    orushi "La strategia può portare a una buona scelta, anche se non è la tua strategia."





translate italian revealtrial_3ff30284:


    orushi "Ora... continuiamo."





translate italian revealtrial_e8527e4f:


    orushi "Giocatore Steven. Vediamo cosa c'è nella tua scatola..."





translate italian revealtrial_c961a606:


    s "Ovviamente."





translate italian revealtrial_e944a555:


    s "C'è un motivo per cui sono il capitano."





translate italian revealtrial_9d5b49f0:


    d "Steven aveva un vantaggio posizionale."





translate italian revealtrial_13c6e254:


    orushi "Strategia, compostezza o puro istinto... In fin dei conti, è una questione tua, Steven."





translate italian revealtrial_f61ca382:


    orushi "Giocatrice Sofia. Il tuo turno."





translate italian revealtrial_2d609d6b:


    sofia "Io... io ho..."





translate italian revealtrial_4e4fec28:


    orushi "Shhh..."





translate italian revealtrial_3f6c7933:


    sofia "Uff... Almeno questo è fatto."





translate italian revealtrial_d8de9c70:


    orushi "Giocatore Hector. Il tuo turno."





translate italian revealtrial_6f4ae617:


    orushi "La casella è vuota."





translate italian revealtrial_c16e21b8:


    hec "Che cosa?!" with hpunch





translate italian revealtrial_52249f1b:


    hec "Ma io ho rispettato le regole!"





translate italian revealtrial_fd3898fd:


    hec "Come può essere vuoto?!"





translate italian revealtrial_a7bc9564:


    hec "Aspetta... Sono Ruby! Mi hai incastrato!"





translate italian revealtrial_e5890989:


    hec "Quando hai scambiato la mia scatola e l'hai data a Madison!"





translate italian revealtrial_4cc575e6:


    ruby "Ho fatto quello che dovevo fare."





translate italian revealtrial_a4f3ffe8:


    hec "Pensi di poter decidere chi merita di restare?!"





translate italian revealtrial_ad601622:


    hec "Tutto questo gioco è una stronzata!"





translate italian revealtrial_af735833:


    hec "Siete tutti ipocriti!"





translate italian revealtrial_268aaefe:


    orushi "La decisione è definitiva."





translate italian revealtrial_fb9e53a4:


    hec "Andate a farvi fottere."





translate italian revealtrial_c80184b8:


    orushi "Giocatore Kira. Vediamo cosa c'è nella tua scatola."





translate italian revealtrial_869f53e1:


    kira "Perfetto."





translate italian revealtrial_7de0f032:


    orushi "Giocatore Mac. Vediamo ora cosa contiene la tua scatola."





translate italian revealtrial_c7696248:


    orushi "…Nessun gettone."





translate italian revealtrial_f80dea7d:


    mac "Che cosa?!"





translate italian revealtrial_460a57b3:


    ben "Bella, amico... Ti avevo detto che era l'altra."





translate italian revealtrial_fad285ea:


    mac "No, ci siamo incrociati! Pensavo che stessi prendendo Red's!"





translate italian revealtrial_4e249041:


    ruby "Ecco fatto. Due semicervelli non ne fanno uno intero."





translate italian revealtrial_0c2120c1:


    orushi "Sembra che un'alleanza senza riflessione sia destinata a fallire."





translate italian revealtrial_cd2893ad:


    orushi "Giocatore Ben. È il momento di rivelare cosa hai in mano."





translate italian revealtrial_ac36ddb9:


    orushi "…La tua casella è vuota."





translate italian revealtrial_72ed8d85:


    ben "Davvero?!"





translate italian revealtrial_f1d5bc35:


    mac "Hai preso quello di Kira, idiota..."





translate italian revealtrial_2b2d5a4b:


    ben "No! Era tuo, non di Kira!"





translate italian revealtrial_f5b77199:


    beth "Dovremmo dare loro un segno di pietà."





translate italian revealtrial_e6242f29:


    orushi "Disattenzione. Confusione. Non importa come la si chiami, il risultato è sempre lo stesso."





translate italian revealtrial_c48f2526:


    orushi "Giocatrice Elizabeth. Il tuo turno."





translate italian revealtrial_9e1e3719:


    orushi "Qualificato."





translate italian revealtrial_ecf3d79e:


    beth "Ovviamente."





translate italian revealtrial_b72c5297:


    ruby "Hai controllato Hector all'inizio. Hai capito cosa stava succedendo?"





translate italian revealtrial_f353fcf0:


    beth "Mi sono accorto subito che c'era un problema nel nostro gruppo. Così l'ho corretto."





translate italian revealtrial_71bc0f38:


    dpense "Si è rivoltata contro la sua stessa squadra. Fredda. Calcolatrice."





translate italian revealtrial_9cf9f448:


    emerick "Traditore."





translate italian revealtrial_18712cea:


    beth "Diciamo che preferisco puntare sull'intelligenza piuttosto che sull'arroganza."





translate italian revealtrial_44a16e27:


    ruby "Avevi controllato Grace..."





translate italian revealtrial_5e0488cd:


    beth "Sì. Punta sempre sul rosso."





translate italian revealtrial_f5a4af3c:


    dpense "Sempre egocentrico. Ma efficace."





translate italian revealtrial_f58573e9:


    orushi "Giocatrice Julia. È il tuo turno."





translate italian revealtrial_e8ed82ca:


    orushi "…C'è un gettone all'interno della tua scatola."





translate italian revealtrial_5bfa8e2b:


    ruby "Hai controllato Ben, vero?"





translate italian revealtrial_d1e1e790:


    julia "SÌ."





translate italian revealtrial_4b52c79e:


    ruby "Allora perché non sei andato a cercare Kira?"





translate italian revealtrial_d1f70c04:


    julia "..."





translate italian revealtrial_f31b8708:


    dpense "C'è qualcosa che non va..."





translate italian revealtrial_37d8e615:


    orushi "Giocatore Ruby. Il tuo turno."





translate italian revealtrial_2dc2021c:


    orushi "Sei qualificato."





translate italian revealtrial_8e9ab4e7:


    dpense "Sembra congelata... come se si aspettasse il peggio."





translate italian revealtrial_3193c932:


    mad "Ce l'hai fatta!"





translate italian revealtrial_0f2c1293:


    ruby "Io... l'ho fatto?"





translate italian revealtrial_85ff042c:


    d "Sì. Avevi la scatola di Emerick, giusto?"





translate italian revealtrial_7c8879d6:


    ruby "È lui che ha preso il mio... Ma io ho tenuto il suo. E non ho mai saputo se..."





translate italian revealtrial_94b8d948:


    ruby "Quando ho aiutato Madison, ho semplicemente accettato il mio destino. Pensavo che non sarei stato io."





translate italian revealtrial_87ad4670:


    mad "Hai fatto centro, Ruby."





translate italian revealtrial_c270dc58:


    ruby "Non ci posso credere..."





translate italian revealtrial_9013017e:


    ruby "In realtà sono riuscito a..."





translate italian revealtrial_cd027434:


    orushi "Un giocatore altruista e perspicace."





translate italian revealtrial_aa20706b:


    orushi "Ma anche le scelte migliori a volte dipendono da un pizzico di fortuna."





translate italian revealtrial_1b038fdd:


    orushi "Giocatore [name]. Tocca a te."





translate italian revealtrial_d0a04df4:


    dpense "Eccoci qui."





translate italian revealtrial_2b78399e:


    dpense "Spero di non aver commesso errori."





translate italian revealtrial_46aadbcb:


    dpense "Mi guardano tutti..."





translate italian revealtrial_05392ae5:


    dpense "Non posso fallire adesso..."





translate italian revealtrial_3197b306:


    orushi "…C'è un gettone nella tua scatola."





translate italian revealtrial_11b6e570:


    d "SÌ!"





translate italian revealtrial_b1934d1a:


    ruby "Ce l'hai fatta!"





translate italian revealtrial_31063061:


    orushi "A volte, la mossa più intelligente... è non giocare troppo."





translate italian revealtrial_717cf009:


    d "Merda..."





translate italian revealtrial_24b7c379:


    ruby "Tu... Perché l'hai scambiato con lui?"





translate italian revealtrial_520730bb:


    d "Pensavo che forse Mac o Ben avessero maggiori probabilità..."





translate italian revealtrial_b0cd8174:


    sofia "NO...!"





translate italian revealtrial_88a75c4d:


    sofia "NO!"





translate italian revealtrial_70206759:


    sofia "Non lo lascerò andare così!"





translate italian revealtrial_5dced416:


    orushi "Hmm?"





translate italian revealtrial_69d62481:


    sofia "Sul mio gettone è scritta l'opzione Sacrificio."





translate italian revealtrial_5d296f3e:


    orushi "..."





translate italian revealtrial_71eb5446:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."





translate italian revealtrial_07cb4710:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta per cedere il posto a un altro giocatore eliminato."





translate italian revealtrial_f452c162:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"





translate italian revealtrial_a7f852ab:


    sofia "Per favore... voglio che tu resti con me."





translate italian revealtrial_e2ac8e66:


    d "Sofia..."





translate italian revealtrial_f195c7ff:


    d "Ti rendi conto di cosa significa?"





translate italian revealtrial_d0eb6209:


    sofia "Sì. Ma non mi interessa essere il migliore se questo significa restare solo."





translate italian revealtrial_2bf1f1d9:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."





translate italian revealtrial_9debc0ee:


    orushi "Questo gioco non riguarda solo intelligenza o strategia."





translate italian revealtrial_bad6979e:


    orushi "È anche una prova di ciò che sei disposto a sacrificare per gli altri."





translate italian revealtrial_114ae86f:


    orushi "Oggi hai dimostrato di non essere tentato dalle ricompense..."





translate italian revealtrial_56ed9463:


    orushi "Ma invece desideri elevare e aiutare chi ti circonda."





translate italian revealtrial_09d1ab31:


    orushi "Sarai immediatamente qualificato e l'immunità sarà la tua ricompensa per questo atto."





translate italian revealtrial_df4d3d01:


    ruby "Oh."





translate italian revealtrial_3a43fcc0:


    orushi "Ma c'è sempre una controparte."





translate italian revealtrial_b279dc41:


    orushi "Te lo spiegherò più tardi."





translate italian revealtrial_f5996909:


    orushi "[name]..."





translate italian revealtrial_357a3333:


    orushi "Tu continui."





translate italian revealtrial_325e86c7:


    dpense "Sono ancora qui grazie a lei."





translate italian revealtrial_25bb462a:


    dpense "E avrebbe potuto costarle tutto."





translate italian revealtrial_2774b746:


    orushi "Sei eliminato."





translate italian revealtrial_2c536cc9:


    d "Fanculo..."





translate italian revealtrial_7ea8f2bd:


    ruby "Io... io mi sbagliavo..."





translate italian revealtrial_16b3b1d0:


    ruby "Pensavo stesse bluffando, ma ha scelto una scatola senza gettoni apposta per intrappolarti."





translate italian revealtrial_72a7b667:


    ruby "Ti ho fatto perdere…"





translate italian revealtrial_82292ffe:


    d "Non potevi saperlo..."





translate italian revealtrial_a81f7dcc:


    emerick "Non si vince questa partita seguendo il proprio cuore."





translate italian revealtrial_ecb0e7fe:


    emerick "Bisogna pensare a una mossa in anticipo."





translate italian revealtrial_23148e2c:


    d "Uff... ha funzionato."





translate italian revealtrial_00153084:


    ruby "Ben fatto!"





translate italian revealtrial_bf6e0ecb:


    orushi "La tua scelta è stata quella giusta. Passi alla fase successiva."





translate italian revealtrial_974ba520_1:


    orushi "Token confermato."





translate italian revealtrial_974ba520_2:


    orushi "Token confermato."





translate italian revealtrial_974ba520_3:


    orushi "Token confermato."





translate italian revealtrial_974ba520_4:


    orushi "Token confermato."





translate italian revealtrial_ecf3d79e_1:


    beth "Ovviamente."





translate italian revealtrial_e9754cba_1:


    ruby "..."





translate italian revealtrial_ac36ddb9_1:


    orushi "…La tua casella è vuota."





translate italian revealtrial_ac36ddb9_2:


    orushi "…La tua casella è vuota."





translate italian revealtrial_5d296f3e_1:


    orushi "..."





translate italian revealtrial_5d296f3e_2:


    orushi "..."





translate italian revealtrial_5d296f3e_3:


    orushi "..."





translate italian revealtrial_b0cd8174_1:


    sofia "NO...!"





translate italian revealtrial_88a75c4d_1:


    sofia "NO!"





translate italian revealtrial_70206759_1:


    sofia "Non lo lascerò andare così!"





translate italian revealtrial_5dced416_1:


    orushi "Hmm?"





translate italian revealtrial_69d62481_1:


    sofia "Sul mio gettone è scritta l'opzione Sacrificio."





translate italian revealtrial_71eb5446_1:


    orushi "Me l'aspettavo. Questo gettone è stato dato a un solo giocatore."





translate italian revealtrial_07cb4710_1:


    orushi "Il segnalino Sacrificio. Può essere utilizzato una sola volta per cedere il posto a un altro giocatore eliminato."





translate italian revealtrial_f452c162_1:


    orushi "È un atto finale. È davvero questo il tuo desiderio?"





translate italian revealtrial_a7f852ab_1:


    sofia "Per favore... voglio che tu resti con me."





translate italian revealtrial_e2ac8e66_1:


    d "Sofia..."





translate italian revealtrial_f195c7ff_1:


    d "Ti rendi conto di cosa significa?"





translate italian revealtrial_d0eb6209_1:


    sofia "Sì. Ma non mi interessa essere il migliore se questo significa restare solo."





translate italian revealtrial_2bf1f1d9_1:


    orushi "Calciatrice Sofia, hai dimostrato una dedizione rara."





translate italian revealtrial_9debc0ee_1:


    orushi "Questo gioco non riguarda solo intelligenza o strategia."





translate italian revealtrial_bad6979e_1:


    orushi "È anche una prova di ciò che sei disposto a sacrificare per gli altri."





translate italian revealtrial_114ae86f_1:


    orushi "Oggi hai dimostrato di non essere tentato dalle ricompense..."





translate italian revealtrial_56ed9463_1:


    orushi "Ma invece desideri elevare e aiutare chi ti circonda."





translate italian revealtrial_09d1ab31_1:


    orushi "Sarai immediatamente qualificato e l'immunità sarà la tua ricompensa per questo atto."





translate italian revealtrial_df4d3d01_1:


    ruby "Oh."





translate italian revealtrial_3a43fcc0_1:


    orushi "Ma c'è sempre una controparte."





translate italian revealtrial_b279dc41_1:


    orushi "Te lo spiegherò più tardi."





translate italian revealtrial_f5996909_1:


    orushi "[name]..."





translate italian revealtrial_357a3333_1:


    orushi "Tu continui."





translate italian revealtrial_325e86c7_1:


    dpense "Sono ancora qui grazie a lei."





translate italian revealtrial_25bb462a_1:


    dpense "E avrebbe potuto costarle tutto."





translate italian revealtrial_2774b746_1:


    orushi "Sei eliminato."





translate italian revealtrial_3197b306_1:


    orushi "…C'è un gettone nella tua scatola."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
