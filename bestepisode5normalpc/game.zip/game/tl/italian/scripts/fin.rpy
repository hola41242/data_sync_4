

translate italian fin_254dd07d:


    grace "Ei, tu ! Ti è piaciuto il gioco, finora?"


translate italian fin_df49880d:


    grace "Se l'hai fatto, questo è solo l'inizio, quindi preparati per una storia emozionante e di vasta portata."


translate italian fingrace_64116e44:


    grace "Grazie per aver scelto questo gioco. Ci auguriamo che tu ti sia divertito con noi."


translate italian fingrace_b7de489c:


    ji "Fai attenzione [name]..."


translate italian fingrace_2c7a6b72:


    mad "Papà... Perché vuoi incontrarlo?"


translate italian fingrace_315b4afb:


    mad "..."


translate italian fingrace_9f07be60:


    mad "Lo farò..."


translate italian fingrace_7a29416a:


    ji "Vai alla festa stasera?"


translate italian fingrace_aee41bbd:


    ji "Mamma..."


translate italian fingrace_d681a17c:


    ruby "Devo trovare un vestito..."


translate italian fingrace_3d8592ac:


    ruby "E un altro per la nostra serata teatrale!"


translate italian fingrace_7a16ee9c:


    grace "Sei l'unica persona che voglio stasera..."


translate italian fingrace_d13211cd:


    julia "Ehilà ! Sembra che tu abbia raggiunto la fine di questo aggiornamento! Spero che ti sia piaciuto !"


translate italian fingrace_38aab629:


    julia "Quando l'aggiornamento viene rilasciato, i Creatori lo aggiungono ai diversi siti web..."


translate italian fingrace_b9df2fb5:


    cr "Sì, lo farò quando avrò capito come funziona tutto questo..."


translate italian fingrace_7c77b00a:


    julia "Ok, quindi... Se ti piace il gioco, le ragazze o anche i Creatori, considera di mostrare il tuo supporto!"


translate italian fingrace_f803f865:


    julia "Di' loro cosa ti piace, cosa vuoi vedere nel gioco, quale personaggio è il tuo preferito..."


translate italian fingrace_241336b2:


    julia "Donando soldi per dimostrare il tuo sostegno, i creatori possono comprarmi dei vestiti e io ADORO davvero i vestiti!!!"


translate italian fingrace_4a83dbf2:


    cr "Non vuoi una Maserati e anche qualche cameriera a tua disposizione ???"


translate italian fingrace_c2ddfb8d:


    julia "Beh, se mi stai offrendo... Sto scherzando! Possono anche acquistare nuovo hardware per accelerare il processo di creazione... Più soldi sono più contenuti..."


translate italian fingrace_d1f2e7be:


    cr "Sì, hai ragione... un rendering o un'animazione richiedono tempo e non abbiamo una workstation della NASA..."


translate italian fingrace_8556d080:


    julia "Per favore, pensaci!"


translate italian fingrace_47f68eca:


    julia "Beh, non ti terrò più a lungo..."


translate italian fingrace_28c14350:


    julia "Spero davvero che tornerai quando verrà rilasciato un nuovo aggiornamento!"


translate italian fingrace_5c8aa31e:


    julia "Arrivederci !"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
