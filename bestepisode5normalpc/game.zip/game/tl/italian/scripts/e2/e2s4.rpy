

translate italian e2s4_5b6b04d6:


    ji "Zio Ted! Voglio guardare Paw Patrol!"


translate italian e2s4_c2c97b56:


    ted "No, Cassie, non è il momento dei cartoni animati in questo momento."


translate italian e2s4_6d11133e:


    cassie "Ma voglio davvero guardare!"


translate italian e2s4_a42216b5:


    ted "No, no..."


translate italian e2s4_692a2f61:


    cassie "Per favore, per favore, per favore!!!"


translate italian e2s4_98a1471a:


    ted "Ho detto di no, Cassie! Sono già le 8:30 e..."


translate italian e2s4_441c0783:


    mad "8:30 ???"


translate italian e2s4_d3ea60d5:


    mad "Accidenti, farò tardi!"


translate italian e2s4_32fabfce:


    mad "Cosa dovrei indossare?"


translate italian e2s4_34413095:


    mad "Oh, questo andrà bene!"


translate italian e2s4_15fa04e3:


    mad "Ted! Cassie è vestita?"


translate italian e2s4_0db593f2:


    ted "Si, si..."


translate italian e2s4_d1c52f83:


    mad "Non dimenticare di accompagnarla a scuola!"


translate italian e2s4_0db593f2_1:


    ted "Si, si..."


translate italian e2s4_a7500e50:


    mad "E assicurati che abbia il suo spuntino!"


translate italian e2s4_0db593f2_2:


    ted "Si, si..."


translate italian e2s4_c7abb2c6:


    mad "Sì, sì... Sì, sì... Sa dire qualcos'altro?"


translate italian e2s4_699afde9:


    mad "Cassie, me ne vado! Ci vediamo stasera, tesoro!"


translate italian e2s4_2f399ecc:


    cassie "Ci vediamo stasera, mamma! E stasera riceverò la mia favola della buonanotte, giusto? Hai promesso!"


translate italian e2s4_6ea8c9bd:


    mad "Ovviamente! Promesso!"


translate italian e2s4_e03d9c57:


    cassie "Sì!"


translate italian e2s4_3511f9dc:


    mad "Va bene, un nuovo giorno..."


translate italian e2s4_0c084aee:


    mad "Ci risiamo..."


translate italian e2s4_a512fbd7:


    mad "Lezione di economia..."


translate italian e2s4_cb7c44c2:


    mad "Formazione..."


translate italian e2s4_8cca5e36:


    mad "Andare a prendere Cassie a scuola..."


translate italian e2s4_bc9e9ad6:


    mad "E devo occuparmi di questi due..."


translate italian e2s4_90d878c6:


    beth "Allora, Madison, ti sei dimenticata di vestirti stamattina?"


translate italian e2s4_04f3053e:


    sofia "O mamma e papà hanno smesso di comprarti vestiti?"


translate italian e2s4_4a9669cc:


    mad "Vedi questo?"


translate italian e2s4_26f6c27a:


    mad "Spingilo dove non splende il sole."


translate italian e2s4_5cbb791c:


    ruby "Ehilà!"


translate italian e2s4_d215ddd0:


    mad "Ciao, Ruby..."


translate italian e2s4_b10d9f66:


    ruby "Mattinata difficile?"


translate italian e2s4_9ec6269c:


    mad "Sì, mi sono svegliata tardi, non ho avuto nemmeno il tempo di prepararmi o di dare un bacio a Cassie prima di dover andare via..."


translate italian e2s4_3edbc739:


    mad "Quindi ho preso le prime cose che ho trovato..."


translate italian e2s4_62205d67:


    ruby "Oh, sai, non hai bisogno di vestirti da diva ogni giorno, vero?"


translate italian e2s4_efde3ab7:


    mad "Sì, lo so, ma comunque..."


translate italian e2s4_24bb991b:


    mad "E mio fratello, devo ripetergli tutto cento volte..."


translate italian e2s4_595c80ce:


    mad "Estenuante..."


translate italian e2s4_31b16005:


    ruby "Dovresti prenderti una pausa..."


translate italian e2s4_8cbe499c:


    ruby "E magari incontrare qualcuno di nuovo!"


translate italian e2s4_94518faf:


    mad "Non ho tempo per quello!"


translate italian e2s4_7dc72278:


    mad "E chi vorrebbe una madre single con un fratello inutile, un programma frenetico e una vita completamente caotica..."


translate italian e2s4_62e0c03b:


    ruby "Potrei avere una piccola idea..."


translate italian e2s4_d19ecb96:


    mad "Eh?"


translate italian e2s4_77ba680b:


    ruby "Oh non importa..."


translate italian e2s4_37f47a0b:


    d "Ok, questa è l'aula giusta..."


translate italian e2s4_abda508c:


    d "Ma dove dovrei sedermi?"


translate italian madiruby_cb5052fe:


    d "Vi dispiace se mi siedo qui, signore?"


translate italian madiruby_94364417:


    ruby "Ovviamente!"


translate italian madiruby_93f7fde9:


    mad "Sì, sì, certo..."


translate italian madiruby_230cca25:


    d "È strano essere qui... in un'aula..."


translate italian madiruby_280960ba:


    ruby "Circondato da ragazze..."


translate italian madiruby_d22bf5e3:


    d "Eh? Ehm... sì, anche quello!"


translate italian madiruby_b4f07fd2:


    mad "Non sembra che ti dispiaccia..."


translate italian madiruby_fbef33c9:


    d "No, per niente..."


translate italian madiruby_28d87aa3:


    ruby "Nessuna sorpresa! Il ragazzo è seduto accanto a una bomba..."


translate italian madiruby_bf8a9c0a:


    ruby "Non si lamenterà, vero?"


translate italian madiruby_3efb7af7:


    mad "Ruby... Smettila!"


translate italian madiruby_dbf9b320:


    d "Non ha torto!"


translate italian madiruby_af9136f3:


    mad "Oh veramente?"


translate italian madiruby_e55d32ad:


    d "Non ho detto che sei tu la bomba!"


translate italian madiruby_40e66c37:


    mad "OH!"


translate italian madiruby_5f32c47f:


    ruby "OH?"


translate italian gracejulia_cb5052fe:


    d "Vi dispiace se mi siedo qui, signore?"


translate italian gracejulia_02600786:


    grace "Ovviamente!"


translate italian gracejulia_e9b99907:


    julia "Sì, sì, certo..."


translate italian gracejulia_230cca25:


    d "È strano essere qui... in un'aula..."


translate italian gracejulia_1f1d00ef:


    julia "Allora questa è la tua prima lezione?"


translate italian gracejulia_dbed4522:


    d "Sì... spero che l'insegnante sia gentile!"


translate italian gracejulia_1ba870f0:


    julia "Non preoccuparti... è brava..."


translate italian gracejulia_5e3e5401:


    julia "Basta che non interrompi la sua lezione!"


translate italian gracejulia_7bcc50f4:


    d "Va bene..."


translate italian gracejulia_5b680b5d:


    grace "Mi dispiace ancora per mia mamma ieri..."


translate italian gracejulia_67acc6de:


    d "Non preoccuparti... succede..."


translate italian gracejulia_cef63d47:


    grace "Mi è davvero piaciuto quel tempo con te..."


translate italian gracejulia_f07527e5:


    d "Spero che ce ne saranno altri..."


translate italian gracejulia_d10a5469:


    grace "Anche io..."


translate italian sittwins_bfce7842:


    d "Vi dispiace se mi siedo qui, signore?"


translate italian sittwins_49293452:


    beth "Naturalmente, con piacere!"


translate italian sittwins_f9455265:


    sofia "Uh... Sì, certo!"


translate italian sittwins_2686ee98:


    sofia "Allora, questa è la tua prima lezione?"


translate italian sittwins_dd8c52d3:


    d "Sì... non so nemmeno cosa portare..."


translate italian sittwins_8b052222:


    beth "E' sempre così la prima volta..."


translate italian sittwins_56e443ac:


    beth "Un po' doloroso... Ma una volta che inizi..."


translate italian sittwins_b660916b:


    beth "Ne vorrai di più..."


translate italian sittwins_e78947be:


    sofia "Non preoccuparti per mia sorella... Non morde... Beh, forse no..."


translate italian sittwins_013dbb2f:


    d "Oh, non ho paura! Non è con la bocca che mi raggiungerà..."


translate italian sittwins_7d2ee7e5:


    beth "O si? Sei sicuro?"


translate italian sittwins_ace3b8d4:


    beth "Dicono che non sono cattiva con la bocca, però..."


translate italian sittwins_10760d33:


    beth "A meno che tu non preferisca..."


translate italian sittwins_99c38ec9:


    beth "Più vicino e..."


translate italian sittwins_ab131cde:


    beth "Più ruvido..."


translate italian sittwins_6710910f:


    sofia "Oppure che esaudiamo tutti i tuoi desideri..."


translate italian sittwins_9ca925ff:


    sofia "Anche quelli più inespressi..."


translate italian sittwins_9ea58198:


    sofia "Andando oltre e..."


translate italian sittwins_03cc4247:


    sofia "Più in profondità..."


translate italian sittwins_590ce44c:


    sofia "Cose..."


translate italian sittwins_f338cc08:


    d "Ehm..."


translate italian suitecours_46fb28ab:


    gaby "Ciao a tutti!"


translate italian suitecours_883d9886:


    gaby "Sono Gabriella, la vostra insegnante di economia..."


translate italian suitecours_fa87f52f:


    gaby "Alcuni di voi forse mi conoscono come allenatore della squadra di calcio femminile..."


translate italian suitecours_ac5e6d6c:


    gaby "Mentre gli altri mi sono completamente sconosciuti..."


translate italian suitecours_58ff09da:


    gaby "Non giriamoci intorno... Mi piace quando le persone sono dirette e schiette con me... Se non siete qui per lavorare o se non siete interessati..."


translate italian suitecours_c9d37095:


    gaby "Potete andarvene subito..."


translate italian suitecours_34d67876:


    gaby "Per il resto di voi..."


translate italian suitecours_6f2a997a:


    gaby "Beh, sono sempre disponibile a rispondere alle vostre domande e sarò felice di aiutarvi!"


translate italian suitecours_85fcfaee:


    gaby "Vedo che lo studente francese è tra noi... [name], vero?"


translate italian suitecours_2d1f1461:


    d "Sì signora..."


translate italian suitecours_5532afff:


    gaby "Molto bene, vedo che stai cominciando a orientarti e che questa volta non ti sei perso..."


translate italian suitecours_11a49d80:


    gaby "E vestito in modo appropriato questa volta!"


translate italian suitecours_b2842d1b:


    d "SÌ..."


translate italian suitecours_daf08564:


    gaby "Allora, come stanno andando questi primi giorni per te?"


translate italian suitecours_4f3652ea:


    d "Ho conosciuto delle persone meravigliose da quando sono arrivato, e devo ammettere che non so ancora cosa fare per ringraziarle della loro ospitalità..."


translate italian suitecours_4debf90f:


    ruby "Awww! È così dolce!!!"


translate italian suitecours_27de816f:


    gaby "Ragazze... sempre troppo gentili!"


translate italian suitecours_df0cb0e4:


    gaby "Ottimo..."


translate italian suitecours_d88d27c1:


    d "Sai, non credo che esista una situazione bella o brutta..."


translate italian suitecours_bf5156e3:


    gaby "Interessante!"


translate italian suitecours_a1418d15:


    gaby "Pensi che il mondo non sia in bianco e nero? Che non è tutto nero o tutto bianco?"


translate italian suitecours_596be531:


    d "Non lo so... penso solo che non dovremmo vedere sempre il bicchiere mezzo vuoto..."


translate italian suitecours_df0cb0e4_1:


    gaby "Ottimo..."


translate italian suitecours_4367836d:


    d "Ho in mente la gara... Il resto, per ora, è un po' al di sopra di me..."


translate italian suitecours_6c000199:


    gaby "Il migliore? Ne fai parte?"


translate italian suitecours_531910ca:


    d "Beh, sono sorpreso quanto lei... ma sì..."


translate italian suitecours_df0cb0e4_2:


    gaby "Ottimo..."


translate italian suitecours_2df75f35:


    d "Beh, ascolti, sto vivendo la mia vita migliore in questo momento! Sto conoscendo ragazze da ogni parte, sono nelle MIGLIORI.. e sul serio, avere un'insegnante così bella è davvero piacevole... mi fa venir voglia di venire a lezione!"


translate italian suitecours_a1699582:


    gaby "Uh... non me lo aspettavo..."


translate italian suitecours_a9642ea4:


    d "Ahah! Sono pieno di sorprese!"


translate italian suitecours_9504acb6:


    gaby "E anche sfacciato..."


translate italian suitecours_df0cb0e4_3:


    gaby "Ottimo..."


translate italian suitecours_63b979ab:


    gaby "Allora, vedo che hai iniziato a stringere dei rapporti franco-americani..."


translate italian suitecours_099834b3:


    gaby "Chi può dirmi, se non [name], quale regalo ha fatto la Francia agli Stati Uniti per celebrare l'indipendenza americana?"


translate italian suitecours_ae64f34d:


    d "Ti fidi di me?"


translate italian suitecours_a7a44cf1:


    mad "Non particolarmente..."


translate italian suitecours_3f883698:


    d "La statua della Libertà."


translate italian suitecours_91da6cea:


    mad "Sei sicuro?"


translate italian suitecours_d38968bc:


    d "Si si..."


translate italian suitecours_57cbaadd:


    emerick "La statua della Libertà!" with hpunch


translate italian suitecours_3df4aaa1:


    d "Oh dannazione..."


translate italian suitecours_2d6dad60:


    gaby "Sì, è corretto, Emerick..."


translate italian suitecours_ca813997:


    mad "Mi dispiace..."


translate italian suitecours_edf1868e:


    mad "Ehm... sì..."


translate italian suitecours_3f883698_1:


    d "La statua della Libertà."


translate italian suitecours_0a6ece95:


    mad "Va bene."


translate italian suitecours_244ef33c:


    mad "La statua della Libertà?"


translate italian suitecours_36794003:


    gaby "SÌ!"


translate italian suitecours_dc636991:


    emerick "Accidenti, lo sapevo!"


translate italian suitecours_7e3ae4e5:


    gaby "Per favore, fai attenzione al tuo linguaggio, Emerick!"


translate italian suitecours_1bb5a634:


    emerick "Mi dispiace, signora!"


translate italian suitecours_781a1cd8:


    mad "Grazie !"


translate italian suitecours_26af0923:


    dpense "La statua della Libertà"


translate italian suitecours_57cbaadd_1:


    emerick "La statua della Libertà!" with hpunch


translate italian suitecours_3df4aaa1_1:


    d "Oh dannazione..."


translate italian suitecours_2d6dad60_1:


    gaby "Sì, è corretto, Emerick..."


translate italian suitecours_087fee55:


    gaby "Ok, la lezione di oggi si concentrerà sui principi generali dell'economia..."


translate italian suitecours_af59083d:


    gaby "E quindi, è tutta una questione di domanda e offerta..."


translate italian suitecours_916d515d:


    drew "A tutti i B.E.S.T. partecipanti..." with hpunch


translate italian suitecours_6820b807:


    drew "Siete pregati di riunirvi al centro dello stadio tra 10 minuti..."


translate italian suitecours_938fcc14:


    drew "Io ripeto..."


translate italian suitecours_e6f31e6b:


    drew "Tutti i partecipanti BEST dovranno ritrovarsi al centro dello stadio entro 10 minuti..."


translate italian suitecours_d7c1bae8:


    gaby "Beh, immagino che la lezione sia finita..."


translate italian suitecours_aab8223d:


    gaby "Buona fortuna a tutti!"


translate italian suitecours_cb6abcd7:


    orushi "Benvenuti, cari partecipanti di BEST.."


translate italian suitecours_04c60917:


    orushi "Ormai siete rimasti solo in 50 in questa competizione che premierà il migliore tra voi..."


translate italian suitecours_7d3c0eb2:


    orushi "Innanzitutto, voglio congratularmi con voi per aver completato con successo la prima sfida..."


translate italian suitecours_2ac1c2b2:


    orushi "Oggi abbiamo in serbo per voi una sfida un po’ speciale…"


translate italian suitecours_0d63aeed:


    orushi "Infatti, ho deciso di aggiungere una sfida bonus al processo di selezione..."


translate italian suitecours_118c8a2c:


    orushi "Questa sfida non sarà basata sull'eliminazione..."


translate italian suitecours_fae9f837:


    orushi "Considerando le prestazioni delle squadre sia maschili che femminili nel calcio..."


translate italian suitecours_fac953e3:


    orushi "Ho pensato che sarebbe stato interessante far emergere il vostro spirito di squadra..."


translate italian suitecours_d57d8af8:


    orushi "Mentre valuteremo le vostre capacità atletiche..."


translate italian suitecours_29f0eedd:


    orushi "Allora, abbiamo organizzato un torneo..."


translate italian suitecours_7377b77c:


    orushi "Che consisterà in diversi incontri ad eliminazione diretta..."


translate italian suitecours_13d3ec80:


    orushi "Alla fine, determinerà la squadra più forte..."


translate italian suitecours_dea55d2d:


    orushi "Naturalmente, se non c'è eliminazione, deve esserci comunque qualcosa in gioco..."


translate italian suitecours_2bc2747c:


    orushi "Quindi, abbiamo deciso di premiare la squadra che vincerà questo torneo con un bonus speciale..."


translate italian suitecours_88d75d0b:


    orushi "Guardate voi stessi..."


translate italian suitecours_c42abb16:


    orushi "La squadra vincitrice potrà usufruire di questa casa, situata non lontano dal campus, per tutta la durata di BEST.."


translate italian suitecours_72a3d47a:


    orushi "La casa dispone di cinque camere da letto individuali e di tutti i comfort necessari per allenarsi, riposarsi e prepararsi per le prossime MIGLIORI sfide nelle migliori condizioni possibili..."


translate italian suitecours_c87ce251:


    orushi "Ovviamente tutto questo ha un prezzo..."


translate italian suitecours_d32d8b03:


    orushi "E come avrete capito, gareggerete in squadre da 5 per guadagnarvi questo privilegio..."


translate italian suitecours_0a5480e5:


    orushi "Questo serve per valutare la vostra motivazione, le vostre prestazioni e il livello di connessione che avete con gli altri..."


translate italian suitecours_736785cb:


    orushi "Comporrete le vostre squadre..."


translate italian suitecours_040186bf:


    orushi "Solo un consiglio: pensate a ottimizzare i vostri giocatori..."


translate italian suitecours_1e8bfa8c:


    orushi "Non c'è niente per i perdenti..."


translate italian suitecours_12414ce8:


    orushi "Per formare le vostre squadre, il computer ha selezionato i capitani che sceglieranno i propri compagni per questa sfida..."


translate italian suitecours_48785378:


    orushi "Ecco l'elenco dei giocatori selezionati come capitani:"


translate italian suitecours_d09ce434:


    orushi "Lo studente Steven..."


translate italian suitecours_11afa90a:


    s "Si signore..."


translate italian suitecours_b2136f6a:


    orushi "Sarai il capitano della squadra A..."


translate italian suitecours_1a6f6865:


    s "Molto bene, signore..."


translate italian suitecours_c282e467:


    orushi "Lo studente Emerick..."


translate italian suitecours_905cbf84:


    emerick "Si signore..."


translate italian suitecours_59809014:


    orushi "Sarai il capitano della squadra B..."


translate italian suitecours_19945eb9:


    orushi "La studentessa Madison..."


translate italian suitecours_90670405:


    mad "Si signore..."


translate italian suitecours_acf02fcb:


    orushi "Sarai il capitano della squadra H..."


translate italian suitecours_c9f2c988:


    mad "Bene..."


translate italian suitecours_b31bba35:


    orushi "Ora che i capitani sono stati designati, per favore, uno per uno, nell'ordine menzionato prima, scegliete un compagno di squadra..."


translate italian suitecours_cbab976a:


    s "Ok, quindi scelgo Mac!"


translate italian suitecours_e8b0f8fe:


    emerick "Scelgo Elisabetta!"


translate italian suitecours_ebdc68c4:


    emerick "Sei riuscito a farlo?"


translate italian suitecours_2cfb5c45:


    beth "Sì, normalmente tutte le palline vengono messe in ordine... tranne le ultime..."


translate italian suitecours_cfc2ff6b:


    ji "Scelgo Marc!"


translate italian suitecours_90146bcc:


    ji "Scelgo Eden!"


translate italian suitecours_daeb8dcf:


    ji "Scelgo Luis!"


translate italian suitecours_0f400b9e:


    ji "Scelgo Brandon!"


translate italian suitecours_b9695e43:


    ji "Scelgo Emilia!"


translate italian suitecours_37e3f6ae:


    mad "Scelgo [name]!"


translate italian suitecours_355fdbbd:


    d "Oh! Non mi aspettavo che scegliessi me!"


translate italian suitecours_eeebc711:


    mad "Abbiamo fatto bene la prima sfida... speriamo di riuscire nella seconda..."


translate italian suitecours_ed398876:


    s "Ettore!"


translate italian suitecours_75c8baf1:


    emerick "Sofia!"


translate italian suitecours_ba6a93d7:


    mad "Grace!"


translate italian suitecours_a5120c1c:


    s "Ben!"


translate italian suitecours_c9eabda7:


    mad "Ruby!"


translate italian suitecours_b6c17e44:


    mad "Julia!"


translate italian suitecours_42b56b32:


    mad "Scelgo Grace!"


translate italian suitecours_ed398876_1:


    s "Ettore!"


translate italian suitecours_75c8baf1_1:


    emerick "Sofia!"


translate italian suitecours_c9eabda7_1:


    mad "Ruby!"


translate italian suitecours_a5120c1c_1:


    s "Ben!"


translate italian suitecours_b6c17e44_1:


    mad "Julia!"


translate italian suitecours_b736ea3c:


    ruby "Madison, prendi [name]!"


translate italian suitecours_636a4cae:


    mad "Sei sicura ?"


translate italian suitecours_8bb0774f:


    ruby "Ovviamente !"


translate italian suitecours_77f04cb3:


    mad "Ok... scelgo [name]!"


translate italian suitecours_5d37a177:


    d "Grazie..."


translate italian suitecours_1c7f72b8:


    mad "Puoi ringraziare Ruby..."


translate italian suitecours_4db55881:


    orushi "Ottimo! Ora che le vostre squadre sono formate... dovremo procedere con un disegno..."


translate italian suitecours_4bb9c3da:


    orushi "Siete 10 squadre, ma solo 8 potranno partecipare a questo torneo..."


translate italian suitecours_035d09f5:


    orushi "Dietro di voi ci sono delle tazze con una pallina dentro..."


translate italian suitecours_3cb93f68:


    orushi "8 palline nere e due palline bianche..."


translate italian suitecours_6ef0da47:


    orushi "Quindi ognuno di voi a turno sceglierà una tazza e mostrerà la pallina che ha estratto..."


translate italian suitecours_9c47e601:


    orushi "Chiunque della propria squadra può andare a pescare la palla..."


translate italian suitecours_ec0627c7:


    orushi "Se estrarrete una pallina nera, vi qualificherete! Se estrarrete una pallina bianca, non parteciperete a questo torneo..."


translate italian suitecours_f16f89f9:


    mad "Oh cavolo, non sono brava in queste cose..."


translate italian suitecours_584173a2:


    ruby "Cosa intendi?"


translate italian suitecours_494323f8:


    mad "Beh, diciamo solo che la fortuna di solito non è dalla mia parte..."


translate italian suitecours_1dbf4149:


    ruby "Ah... beh... Anche qui!"


translate italian suitecours_a647ab43:


    d "OH?"


translate italian suitecours_c2c87464:


    d "Posso farlo io se vuoi..."


translate italian suitecours_18ae2ed2:


    mad "Tu?"


translate italian suitecours_1856c7d4:


    d "Sì... Nel peggiore dei casi, se non riusciamo a giocare, puoi dare la colpa a me!"


translate italian suitecours_e0d5187b:


    mad "Allora ok..."


translate italian suitecours_f5e55f54:


    ruby "Aspetta... ho un'idea..."


translate italian suitecours_c8aa12cf:


    julia "Che cos'è?"


translate italian suitecours_1f45ebf6:


    ruby "Alla fine rimarrete solo in tre se ho capito bene l'ordine..."


translate italian suitecours_52b03409:


    julia "Uh... Sì... Siamo la squadra H, l'ottava squadra..."


translate italian suitecours_5c99e476:


    ruby "Ok... vediamo come vanno i risultati..."


translate italian suitecours_c320f17e:


    emerick "Vado per primo!"


translate italian suitecours_4f781c37:


    emerick "Palla nera!"


translate italian suitecours_d42d80c6:


    orushi "Squadra qualificata!"


translate italian suitecours_b416f0d3:


    s "Palla nera!"


translate italian suitecours_d42d80c6_1:


    orushi "Squadra qualificata!"


translate italian suitecours_3988fd6d:


    ji "Nero!"


translate italian suitecours_d42d80c6_2:


    orushi "Squadra qualificata!"


translate italian suitecours_3988fd6d_1:


    ji "Nero!"


translate italian suitecours_d42d80c6_3:


    orushi "Squadra qualificata!"


translate italian suitecours_3988fd6d_2:


    ji "Nero!"


translate italian suitecours_d42d80c6_4:


    orushi "Squadra qualificata!"


translate italian suitecours_3988fd6d_3:


    ji "Nero!"


translate italian suitecours_d42d80c6_5:


    orushi "Squadra qualificata!"


translate italian suitecours_3988fd6d_4:


    ji "Nero!"


translate italian suitecours_d42d80c6_6:


    orushi "Squadra qualificata!"


translate italian suitecours_a1d614f0:


    orushi "Quindi, sette squadre sono ora qualificate..."


translate italian suitecours_5e014e97:


    orushi "È rimasta solo una pallina nera tra gli ultimi tre sacchi..."


translate italian suitecours_11df4754:


    orushi "Squadra H, continuate..."


translate italian suitecours_09dd397c:


    dpense "Mi fiderò di Blu..."


translate italian suitecours_dac16296:


    d "prenderò l'ultimo..."


translate italian suitecours_0b442ff1:


    mad "Dio mio ! [name] cosa stai facendo?"


translate italian suitecours_58018565:


    d "Non lo so !"


translate italian suitecours_4fa6cf9d:


    mad "E' serio?"


translate italian suitecours_cf27c58a:


    dpense "Potrebbe essere una trappola..."


translate italian rusolve_d3e412b3:


    ruby "Signor Orushi?"


translate italian rusolve_e494fdfd:


    orushi "SÌ?"


translate italian rusolve_a932588e:


    ruby "Potremmo lasciare che il prossimo giocatore prenda il nostro posto? Vogliamo dare al giocatore successivo la possibilità di estrarre una palla per nostro conto e poi estrarre la nostra palla..."


translate italian rusolve_28cfd01c:


    orushi "Hmmm... Dato che Emerick è andato prima di Steven... non vedo alcun problema con questo..."


translate italian rusolve_6a1566d3:


    emerick "Cosa sta facendo?"


translate italian rusolve_fe395a9a:


    d "Perché glielo chiedi?"


translate italian rusolve_142f5df4:


    ruby "Fidati di me!"


translate italian rusolve_59837f76:


    ruby "Dimmi... Quale pallina avresti estratto?"


translate italian rusolve_51808edd:


    d "Non lo so, ho una possibilità su tre di scegliere quello giusto!"


translate italian rusolve_3a450a96:


    ruby "Questo è il principio... 33%%..."


translate italian rusolve_72987282:


    d "Quello di sinistra..."


translate italian rusolve_30508101:


    d "Quello centrale..."


translate italian rusolve_578f2da0:


    d "Il primo a destra..."


translate italian rusolve_8c4cb72b:


    ji "Sceglierò quello centrale!"


translate italian rusolve_7bcc50f4:


    d "Va bene..."


translate italian rusolve_170fc44d:


    ruby "Aspetta..."


translate italian rusolve_5f484a7a:


    ji "Bianco..."


translate italian rusolve_8fdce6a4:


    orushi "Squadra eliminata!"


translate italian rusolve_f8af79d9:


    ji "Sceglierò quello di sinistra!"


translate italian rusolve_7bcc50f4_1:


    d "Va bene..."


translate italian rusolve_170fc44d_1:


    ruby "Aspetta..."


translate italian rusolve_5f484a7a_1:


    ji "Bianco..."


translate italian rusolve_8fdce6a4_1:


    orushi "Squadra eliminata!"


translate italian rusolve_f8af79d9_1:


    ji "Sceglierò quello di sinistra!"


translate italian rusolve_7bcc50f4_2:


    d "Va bene..."


translate italian rusolve_170fc44d_2:


    ruby "Aspetta..."


translate italian rusolve_5f484a7a_2:


    ji "Bianco..."


translate italian rusolve_8fdce6a4_2:


    orushi "Squadra eliminata!"


translate italian centerright_ee586e7e:


    mad "Oh mio Dio... avrei fatto come tutti gli altri e avrei estratto la palla in ordine..."


translate italian centerright_158bc8fd:


    grace "Sì, avrei fatto lo stesso..."


translate italian centerright_7e9b8995:


    julia "Ma perché l'hai fatto, Ruby?"


translate italian centerright_ef6e87dc:


    ruby "Un'intuizione..."


translate italian centerright_a3f17df4:


    d "Ma cosa facciamo adesso? Ho cinquanta e cinquanta possibilità di perdere!"


translate italian centerright_072df15c:


    ruby "No... è lì che sbagli!"


translate italian centerright_dd5d68f3:


    d "Eh?"


translate italian centerright_c13ab685:


    ruby "Quando hai iniziato avevi una possibilità su tre che la pallina nera fosse quella che avevi scelto, giusto?"


translate italian centerright_d1523116:


    d "Beh si..."


translate italian centerright_46b44aa9:


    ruby "Bene, ora hai due possibilità su tre che sia quello che non hai scelto!"


translate italian centerright_dd5d68f3_1:


    d "Eh?"


translate italian centerright_5625102b:


    ruby "Fidati di me e prendi l'altra palla..."


translate italian centerright_f4379931:


    d "Cos'è questa follia?"


translate italian centerright_bf9a1fbc:


    d "È completamente pazza..."


translate italian centerright_59e62df4:


    d "Va bene... andiamo..."


translate italian centerright_81959ae4:


    dpense "Non voglio vedere..."


translate italian centerright_02be2d4e:


    orushi "Palla nera! Squadra qualificata!"


translate italian centerright_85a51d50:


    d "Eh???"


translate italian centerright_871f33af:


    ruby "Vedi te l'avevo detto!"


translate italian centerright_f542d5d6:


    mad "Sei pazza!"


translate italian centerright_a508db31:


    ruby "Ho avuto una sensazione! Grazie per aver creduto in me!"


translate italian lefttable_f31fcf7b:


    d "Cosa facciamo adesso? Ho cinquanta e cinquanta possibilità di perdere!"


translate italian lefttable_072df15c:


    ruby "No... è lì che sbagli!"


translate italian lefttable_dd5d68f3:


    d "Eh?"


translate italian lefttable_c13ab685:


    ruby "Quando hai iniziato avevi una possibilità su tre che la pallina nera fosse quella che avevi scelto, giusto?"


translate italian lefttable_d1523116:


    d "Beh si..."


translate italian lefttable_46b44aa9:


    ruby "Bene, ora hai due possibilità su tre che sia quello che non hai scelto!"


translate italian lefttable_dd5d68f3_1:


    d "Eh?"


translate italian lefttable_5625102b:


    ruby "Fidati di me e prendi l'altra palla..."


translate italian lefttable_f4379931:


    d "Cos'è questa follia?"


translate italian lefttable_bf9a1fbc:


    d "È completamente pazza..."


translate italian lefttable_59e62df4:


    d "Va bene... andiamo..."


translate italian lefttable_81959ae4:


    dpense "Non voglio vedere..."


translate italian lefttable_02be2d4e:


    orushi "Palla nera! Squadra qualificata!"


translate italian lefttable_85a51d50:


    d "Eh???"


translate italian lefttable_871f33af:


    ruby "Vedi te l'avevo detto!"


translate italian lefttable_f542d5d6:


    mad "Sei pazza!"


translate italian lefttable_a508db31:


    ruby "Ho avuto una sensazione! Grazie per aver creduto in me!"


translate italian bluesolve_3b040379:


    d "E se avesse torto?"


translate italian bluesolve_bf9a1fbc:


    d "È completamente pazza..."


translate italian bluesolve_59e62df4:


    d "Va bene... andiamo..."


translate italian bluesolve_81959ae4:


    dpense "Non voglio vedere..."


translate italian bluesolve_02be2d4e:


    orushi "Palla nera! Squadra qualificata!"


translate italian bluesolve_85a51d50:


    d "Eh???"


translate italian bluesolve_f542d5d6:


    mad "Sei pazza!"


translate italian resulttable_28601e80:


    orushi "Ora che sono state designate tutte le squadre del torneo, inizieremo le prime partite..."


translate italian resulttable_af173a75:


    orushi "Le partite saranno così:"


translate italian resulttable_ae065467:


    orushi "A contro C"


translate italian resulttable_6f7c934f:


    orushi "B contro E"


translate italian resulttable_d0f1a017:


    orushi "D contro H"


translate italian resulttable_da9dba80:


    orushi "F contro G"


translate italian resulttable_04d36dc5:


    orushi "Per favore, andate negli spogliatoi a recuperare le vostre divise e preparatevi per le partite..."


translate italian resulttable_ac7ab3c8:


    mad "Va bene! Andiamo tutti!"

translate italian strings:


    old "Sit with Madison and Ruby [TEMP1!t]"
    new "Siediti con Madison e Ruby [TEMP1!t]"


    old "Sit with Grace and Julia [TEMP2!t]"
    new "Siediti con Grace e Julia [TEMP2!t]"


    old "Sit with the twins [TEMP3!t]"
    new "Siediti con le gemelle [TEMP3!t]"


    old "Take the last one !!!"
    new "Prendi l'ultimo!!!"


    old "What ?"
    new "Che cosa ?"


    old "Do as I say if you want to continue !!!"
    new "Fai come ti dico se vuoi continuare!!!"


    old "Trust Blue [TEMP1!t]"
    new "Fidati del Blu [TEMP1!t]"


    old "Do not trust Blue [TEMP2!t]"
    new "Non fidarti di Blu [TEMP2!t]"


    old "Center"
    new "Centro"


    old "Thank you!!!"
    new "Grazie!!!"


    old "You owe me one..."
    new "Mi sei debitore..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
