

translate italian e2s2_699705df:


    d "Perché indossi un berretto di maglia?"


translate italian e2s2_2651da73:


    julia "Beh... A dire il vero adoro il colore dei miei capelli, ma non voglio incontrare persone che potrebbero vedermi da lontano... Quindi preferisco restare in incognito..."


translate italian e2s2_a09a9275:


    d "Hai problemi?"


translate italian e2s2_747f24b1:


    julia "Ehm... Non proprio..."


translate italian e2s2_81710995:


    julia "Allora, stai iniziando ad abituarti alla vita qui?"


translate italian e2s2_a69974f7:


    d "Oh, sai, sono qui solo da 2 giorni... non ho avuto molto tempo per vedere niente!"


translate italian e2s2_f013355a:


    d "Ma mi piacerebbe davvero esplorare un po', e approfittare del fatto che ho un po' di tempo per orientarmi..."


translate italian e2s2_649f8856:


    d "Con tutta la competizione, le lezioni che stanno per iniziare e tutte le persone che incontro... riesco a malapena a capire dove mi trovo!"


translate italian e2s2_0ddb529d:


    julia "Posso immaginare! Deve essere uno shock per te..."


translate italian e2s2_4194debf:


    d "Sì, beh... A dire il vero, ero venuto solo per studiare..."


translate italian e2s2_2e7a7210:


    d "E ora sono preso dal programma BEST, sono in un dormitorio universitario che non avevo richiesto, ho già conosciuto la preside, sua figlia, te e gli altri..."


translate italian e2s2_2d9dc3c5:


    d "Non so nemmeno da dove cominciare e le lezioni non sono ancora iniziate!"


translate italian e2s2_60da1eec:


    julia "Ahah! E non è ancora finita! A fine settimana c'è la festa dell'integrazione."


translate italian e2s2_1b8d5ee7:


    julia "È come una grande festa con giochi, tanta gente ovunque... che spesso finisce in una festa sfrenata... in tutti i sensi... spero che tu abbia lo stomaco forte!"


translate italian e2s2_ec991449:


    d "Finché ho gente con me, va bene! E non sono nemmeno il tipo che esagera!"


translate italian e2s2_4e3f7e5b:


    d "Fondamentalmente, mi piacciono questo tipo di feste quando ci divertiamo!"


translate italian e2s2_170cdd76:


    julia "Sono totalmente d'accordo! Non è proprio il mio genere di festa... sono un po' solitaria..."


translate italian e2s2_fdd47e50:


    julia "Ma mi impegno e ogni anno vengo a vedere come va e come si stanno integrando i nuovi arrivati..."


translate italian e2s2_1bae9f5e:


    d "Oh, sai, a queste feste devi solo evitare di esagerare... altrimenti il ​​giorno dopo avrai i postumi di una sbornia enorme e le cattive abitudini potrebbero formarsi rapidamente..."


translate italian e2s2_1c7dbdcc:


    d "E questo influisce sui tuoi voti..."


translate italian e2s2_a42f6436:


    julia "Prendi le lezioni molto sul serio, eh?"


translate italian e2s2_ef6e3ce0:


    d "Beh, sì... non ho scelta... Inoltre, se i miei voti non sono buoni, non potrò restare, e tutto quello che ho fatto finora sarebbe stato inutile, quindi..."


translate italian e2s2_a4b21c2c:


    julia "Capisco..."


translate italian e2s2_ddeb79fb:


    d "Bevo pochissimo alcol per mantenermi in buona forma fisica... Lo sport prima di tutto! Dannazione!"


translate italian e2s2_528a694f:


    julia "Oh wow! Quindi il signorino è già un atleta di alto livello?"


translate italian e2s2_2abccca6:


    d "No, ma attribuisco grande importanza a mantenere il mio corpo in buona forma per ottenere la migliore prestazione possibile."


translate italian e2s2_f5bfadf3:


    d "Se potessi, mangerei ogni giorno solo riso; tacchino e olio d'oliva per i grassi buoni... Ma qui, ho paura che passerei da Blastoise a Muk..."


translate italian e2s2_04da4eb4:


    julia "Ahah! Per ora, direi che sei più simile a un Machop!"


translate italian e2s2_2f84c3bb:


    d "EHI!"


translate italian e2s2_0ff2a046:


    d "Bevande e belle ragazze? Questo è tutto ciò di cui ho bisogno! Si preannuncia una serata fantastica!"


translate italian e2s2_2a1cca83:


    julia "Non esagerare, Don Giovanni! Solo perché ti presenti non significa che tutte le ragazze saranno ai tuoi piedi!"


translate italian e2s2_210ff254:


    julia "E devi ancora trattenere l'alcol... e non dimenticare che il giorno dopo ci sono lezioni!"


translate italian e2s2_e1c58ffa:


    d "Ci vuole ben altro per spaventarmi! Mostrerò loro chi è il re della pista da ballo! Rimarranno tutti abbagliati dal mio Tocco Francese!"


translate italian e2s2_ac2e69c2:


    julia "Si, come no..."


translate italian e2s2_f6cfd155:


    julia "Comunque, quasi tutti saranno a questa festa! Di solito è Madison a organizzare l'evento, ma quest'anno non me ne ha parlato..."


translate italian e2s2_e4720c4a:


    julia "Penso che per lei sia più difficile con sua figlia in questo momento... Quindi non so nemmeno dove si svolgerà... Forse avrai più informazioni dagli altri!"


translate italian e2s2_ad3f6506:


    d "Ma verrai lo stesso, vero?"


translate italian e2s2_a34dcd03:


    julia "SÌ! È quasi obbligatorio fare almeno una comparsa, altrimenti vieni visto come un asociale... Ma probabilmente non mi fermerò a lungo..."


translate italian e2s2_9d401a52:


    d "Vedremo... scommetto che Ruby sarà di nuovo completamente coinvolta!"


translate italian e2s2_b389601e:


    julia "Oh, certo! Ogni anno organizza dei giochini con le bambine... Di solito è lei a rendere divertenti queste feste..."


translate italian e2s2_a97e81c6:


    julia "Altrimenti dovremo vederci con i ragazzi odiosi che vengono a provarci con te..."


translate italian e2s2_f1b6f7a1:


    d "Ragazzi odiosi?"


translate italian e2s2_73733c8a:


    julia "Sì, c'è la banda di Steven... i ragazzi del football... Ad ogni festa, vengono e cercano di superarsi a vicenda con stupide sfide per dimostrare chi è il maschio alfa..."


translate italian e2s2_2c2249c6:


    julia "E, naturalmente, diventiamo i loro bersagli... ma ogni anno ci provano... e ogni anno vengono respinti!"


translate italian e2s2_198ee8a3:


    d "Ma prima nel parco hai detto che non hai mai baciato nessuno..."


translate italian e2s2_4e619f92:


    julia "SÌ..."


translate italian e2s2_ff8f5d14:


    d "Quindi non hai mai avuto un fidanzato?"


translate italian e2s2_a59c2be9:


    julia "Non proprio... non ho mai provato affetto per un ragazzo, anzi... Beh... non ne sono sicura..."


translate italian e2s2_f96d060b:


    d "Allora preferisci le ragazze?"


translate italian e2s2_cbc0a567:


    julia "Che cosa? NO! È solo che non ho incontrato qualcuno che possa davvero interessarmi... Beh, non ancora! Ma arriverà quando arriverà, onestamente, non è proprio un problema."


translate italian e2s2_2154c2d6:


    julia "Dopotutto, voglio esplorare questa parte di me con qualcuno di cui mi fido e che mi aiuterà a scoprirla nel migliore dei modi..."


translate italian e2s2_f515507e:


    d "E le altre ragazze? Sono riluttanti anche quando si tratta di essere avvicinate?"


translate italian e2s2_5609f7b7:


    julia "Hmm... A Grace piace essere avvicinata senza esagerare... È una ragazza dolce..."


translate italian e2s2_17d1ebbd:


    julia "Non dice direttamente di no a qualcuno che le chiede di ballare o le parla... Ma non appena le cose cominciano a scaldarsi, scappa..."


translate italian e2s2_063a254d:


    d "Lei scappa?"


translate italian e2s2_2f7bba62:


    julia "SÌ! O chiama un'amica per tenere occupato il ragazzo mentre trova un altro posto dove andare, oppure se ne va direttamente senza alcuna spiegazione... Quindi sì... è sfuggente!"


translate italian e2s2_1ef78c01:


    d "Ahah! E che mi dici di Ruby?"


translate italian e2s2_31bb772d:


    julia "Oh, Ruby è diversa! Non ha tempo per uscire con i ragazzi perché vuole occuparsi di tutto..."


translate italian e2s2_76e1c2af:


    julia "Giocherà con noi, controllando che non manchi nulla in cucina, a volte preparerà anche un sacchetto con preservativi e altre piccole cose per i partecipanti alla festa..."


translate italian e2s2_a0507f21:


    julia "Ma per questo motivo non si diverte quanto dovrebbe..."


translate italian e2s2_cd5b7cef:


    d "Capisco cosa intendi!"


translate italian e2s2_4b92c7e2:


    julia "E poi, invece, avrai delle ragazze molto meno... schizzinose... Ma ti lascio avere l'opportunità di scoprirlo da solo... se vuoi!"


translate italian e2s2_5c581896:


    d "Vedrò come va..."


translate italian e2s2_7c2f365c:


    julia "Prima nel parco, le ragazze stavano parlando di qualcosa... riguardo alle gemelle... Di cosa stavano parlando?"


translate italian e2s2_f37455ff:


    d "Mi piace molto Blu..."


translate italian e2s2_101332d7:


    julia "Eh?"


translate italian e2s2_c5609e2e:


    d "Sì! Lei è speciale, non so cosa dire..."


translate italian e2s2_8d85d16f:


    julia "Hmm... capisco perché Madison lo disse allora... Sarà più difficile per te essere accettato da Maddie adesso!"


translate italian e2s2_5bc0ea87:


    d "Vedremo come va..."


translate italian e2s2_40ea1b9b:


    d "Beh, ho la gemella blu che si è avvicinata a me... ma non mi interessa..."


translate italian e2s2_1ee38eaf:


    julia "Oh veramente?"


translate italian e2s2_bdb8233e:


    d "Già... Non è il mio tipo, quel tipo di ragazze... Lasciala andare con i ragazzi del football e quelli antipatici, come dici tu!"


translate italian e2s2_da81affe:


    julia "Ahah! Bene, stai segnando punti con Maddie lì! Sarà più facile per te essere accettato da lei se non stai con le gemelle! Ancora di più se le spazzoli via!"


translate italian e2s2_5bc0ea87_1:


    d "Vedremo come va..."


translate italian e2s2_045838c2:


    d "Mi piace molto rosso..."


translate italian e2s2_101332d7_1:


    julia "Eh?"


translate italian e2s2_c5609e2e_1:


    d "Sì! Lei è speciale, non so cosa dire..."


translate italian e2s2_8ae374e1:


    julia "Hmm... capisco perché Ruby l'ha detto allora... Sarà più difficile per te essere accettato da Maddie adesso!"


translate italian e2s2_5bc0ea87_2:


    d "Vedremo come va..."


translate italian e2s2_6b7da03e:


    d "Ebbene, ho la gemella vestita di rosso che si è avvicinata a me... ma non mi interessa..."


translate italian e2s2_1ee38eaf_1:


    julia "Oh veramente?"


translate italian e2s2_bdb8233e_1:


    d "Già... Non è il mio tipo, quel tipo di ragazze... Lasciala andare con i ragazzi del football e quelli antipatici, come dici tu!"


translate italian e2s2_da81affe_1:


    julia "Ahah! Bene, stai segnando punti con Maddie lì! Sarà più facile per te essere accettato da lei se non stai con le gemelle! Ancora di più se le spazzoli via!"


translate italian e2s2_5bc0ea87_3:


    d "Vedremo come va..."


translate italian e2s2_97eb4ac6:


    julia "Comunque c'è la piscina del campus! Grace trascorre lì la maggior parte dei suoi pomeriggi ad allenarsi."


translate italian e2s2_2c11e212:


    julia "Se non sai dove si trova... beh, vai lì, probabilmente la troverai!"


translate italian e2s2_f36a5ff4:


    d "Va bene!"


translate italian e2s2_597f2c85:


    julia "Accanto c'è la palestra... Siamo passati di lì prima per cambiarci. È lì che troverai principalmente Madison..."


translate italian e2s2_39b61a84:


    julia "Si allena lì regolarmente. Probabilmente incontrerai anche Steven e gli altri... Ma beh..."


translate italian e2s2_16c75a70:


    d "E tu non ci vai?"


translate italian e2s2_a4696a89:


    julia "Veramente... Tra una lezione e l'altra... Beh, no, non ho proprio tempo..."


translate italian e2s2_43b49e4c:


    d "Va bene."


translate italian e2s2_58a7c153:


    julia "Lì c'è il Grand Theatre e i negozi... Troverai tutto ciò di cui hai bisogno se hai bisogno di vestiti o hai voglia di andare al pub vicino."


translate italian e2s2_360c3a8e:


    d "Wow, è come una mini città, non è vero?"


translate italian e2s2_aeb44433:


    julia "Sì, puoi vederlo in questo modo! Ma devo avvisarti... La maggior parte delle aziende sono di proprietà della famiglia Emerick o delle Gemelle..."


translate italian e2s2_c5e72fc1:


    d "Hanno così tanti soldi?"


translate italian e2s2_a55c01fd:


    julia "Ehm... Già, anche più di quanto tu possa immaginare... Ma i loro genitori li fanno lavorare per imparare il valore del denaro, da quello che ho capito..."


translate italian e2s2_69793ab9:


    julia "Quindi Red si prende cura del negozio di abbigliamento che gestisce e dà buoni consigli... Quanto a Emerick... Vedrai presto i suoi piccoli schemi..."


translate italian e2s2_b651150d:


    d "E che dire di Blu?"


translate italian e2s2_ccd58cdf:


    julia "Oh, è molto meno interessata ai soldi e più interessata a... beh, ai rapporti umani, diciamo!"


translate italian e2s2_df522c84:


    julia "Ma è spesso al cinema o al bowling! E si allena anche per la squadra... Almeno di questo nessuno può biasimarla..."


translate italian e2s2_0aae168a:


    d "E tu cosa fai in tutto questo?"


translate italian e2s2_08822955:


    julia "Me? Ehm..."


translate italian e2s2_f526b9a7:


    julia "Oh, beh, siamo arrivati ​​in biblioteca e si sta già facendo tardi!"


translate italian e2s2_ebd88aab:


    julia "Devo lasciarti qui! Se hai domande, non esitate a mandarmi un messaggio!"


translate italian e2s2_02fcf1f9:


    julia "E poi ci vediamo domani a lezione di economia!"


translate italian e2s2_c372f1a0:


    d "Uh... sì... okay!"


translate italian e2s2_09f84ac2:


    julia "Ci vediamo domani allora!"


translate italian e2s2_df3539f1:


    d "Ci vediamo!"


translate italian e2s2_f49e8424:


    dpense "Stranamente non ha risposto alle mie domande su cosa fa..."

translate italian strings:


    old "Ask about her love life [TEMP1!t]"
    new "Chiedi della sua vita amorosa [TEMP1!t]"


    old "Ask about the others [TEMP2!t]"
    new "Chiedi degli altri [TEMP2!t]"


    old "I like Blue [TEMP1!t]"
    new "Mi piace il blu [TEMP1!t]"


    old "I don't like Blue [TEMP2!t]"
    new "Non mi piace il Blu [TEMP2!t]"


    old "I like Red [TEMP1!t]"
    new "Mi piace il rosso [TEMP1!t]"


    old "I don't like Red [TEMP2!t]"
    new "Non mi piace il rosso [TEMP2!t]"


    old "Visit the swimming pool [TEMP1!t]"
    new "Visita la piscina [TEMP1!t]"


    old "Return to my room [TEMP2!t]"
    new "Ritorna nella mia stanza [TEMP2!t]"






















translate italian e2s2_134e56cd:


    d "Sì, beh... In realtà, sono venuto solo per studiare..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
