

translate italian pool_72637706:


    dpense "Vediamo cosa abbiamo qui."


translate italian pool_7a1baaf2:


    ji "Ehi ragazzo... Non ti è permesso entrare qui con i tuoi vestiti civili!"


translate italian pool_279f9a91:


    dpense "Che..."


translate italian pool_b85af03c:


    dpense "Cosa... Ok..."


translate italian pool_e1b9209f:


    ji "È possibile acquistare il costume da bagno all'ingresso..."


translate italian pool_204f2638:


    d "Oh... Hum... Sì... Grazie!"


translate italian pool_0b4cdda2:


    ji "Non c'è di che... Buon divertimento!"


translate italian pool_bd97412f:


    d "Si... Si..."


translate italian pool_68ef2048:


    dpense "Quella donna era un razzo! No... un razzo spaziale!..."


translate italian pool_26d4b995:


    dpense "Cosa sto dicendo? Una bomba atomica!"


translate italian pool_c303edbb:


    dpense "Meglio andare a comprare un costume da bagno..."


translate italian pool_2858ce6f:


    dpense "Ora siamo pronti!"


translate italian pool_c7cc1930:


    sofia "Vieni con me... Volevi vedermi evolvere... Sono già tutta bagnata..."


translate italian pool_4ed86741:


    d "Dove vuoi andare ?"


translate italian pool_e12af768:


    sofia "Conosco un posto dove possiamo nasconderci..."


translate italian pool_5036ca42:


    d "Ok andiamo !"


translate italian pool_140612ac:


    d "No grazie! Ho una bellissima sirena che mi aspetta!"


translate italian pool_7ea2f9dd:


    sofia "Non sai cosa ti perdi..."


translate italian pool_f36c14c5:


    sofia "Cosa ci fai qui, francesino? Non hai niente di meglio da fare che fare il voyeur in piscina?"


translate italian pool_e90456c6:


    d "Non preoccuparti! Non sono qui per te... comunque non vedo cosa farei con te..."


translate italian pool2_d9572a1c:


    d "Allora è qui che ti alleni?"


translate italian pool2_fa3467c8:


    grace "OH ? Ehm... sì..."


translate italian pool2_f66455b4:


    d "Julia mi ha fatto fare un giro e ho pensato che venire a rilassarsi in piscina sarebbe stato il modo migliore per riposarsi dopo questi due giorni pazzi..."


translate italian pool2_b8e2fee2:


    grace "Non conosco niente di meglio della sensazione dell'acqua sul mio corpo per ricaricarmi..."


translate italian pool2_c670f8b1:


    d "Ti alleni qui tutte le sere?"


translate italian pool2_7dd0a2f8:


    grace "Sì, mi aiuta a mantenermi in forma e in buone condizioni per le partite."


translate italian pool2_7f1e4dbe:


    d "Hai una routine di allenamento specifica?"


translate italian pool2_2ccaf0b5:


    grace "Beh, prima mi rilasso, poi nuoto, e qualche volta provo a prendere un po' di velocità..."


translate italian pool2_d5462bbf:


    d "Questo perché non hai mai provato i miei massaggi!"


translate italian pool2_275ce8d3:


    grace "Sembri abbastanza sicuro di te stesso!"


translate italian pool2_3ba1bae1:


    d "Ovviamente! Rispetto all'acqua, le mie mani sono più agili e riescono a rilassare tutto il corpo con un semplice tocco..."


translate italian pool2_76c08320:


    grace "O si ? Mi piacerebbe vederlo!"


translate italian pool2_0e0f6b87:


    d "Vedremo... se te lo meriti!"


translate italian pool2_46bc144d:


    grace "E tu ti alleni un po'?"


translate italian pool2_b1500910:


    d "Non proprio..."


translate italian pool2_67a8763d:


    dpense "Che dea..."


translate italian pool2_6f4442f4:


    grace "Non fai sport al di fuori delle lezioni?"


translate italian pool2_7937cad2:


    d "Beh, non ho avuto molte opportunità qui..."


translate italian pool2_2bc3d50b:


    d "In Francia giocavo a calcio e facevo arrampicata su roccia..."


translate italian pool2_45a97532:


    grace "Arrampicata?"


translate italian pool2_2059714a:


    d "Sì! Nella natura, su scogliere, piccole montagne..."


translate italian pool2_413052f1:


    grace "Ciò richiede resistenza! È super pericoloso!"


translate italian pool2_3c7caf13:


    d "Devi avere una buona presa ma, soprattutto, devi sempre dare priorità alla tua sicurezza..."


translate italian pool2_a897be39:


    d "E sì, richiede un po' di resistenza... Ma giocare a calcio mi ha dato un po' di cardio, quindi mi va bene!"


translate italian pool2_feb3be0c:


    grace "Sei bravo?"


translate italian pool2_79d25a85:


    d "Ehm... sì..."


translate italian pool2_72618b93:


    grace "Va bene, signor. Sto bene... propongo un accordo!"


translate italian pool2_5dda0f88:


    d "Hmm?"


translate italian pool2_58f2204f:


    grace "Due giri in piscina, il perdente deve un favore al vincitore, sempre e ovunque..."


translate italian pool2_ad924887:


    d "Che tipo di favore?"


translate italian pool2_2a17a6fb:


    grace "Hmm... Diciamo solo che ci penserò..."


translate italian pool2_f427102d:


    d "Ok... quindi se vinco..."


translate italian pool2_53d303bf:


    grace "Non vincerai!"


translate italian pool2_4e58cc80:


    d "Ahah! Quindi, quando vinco... posso chiederti quasi tutto?"


translate italian pool2_3c81889e:


    grace "Più o meno sì... ma funziona in entrambi i sensi!"


translate italian pool2_6967de82:


    d "In entrambi i sensi?"


translate italian pool2_fddacfe2:


    grace "Visto che vincerò... posso chiederti qualsiasi cosa anch'io!"


translate italian pool2_5e16e0f2:


    d "Certo certo..."


translate italian pool2_26544772:


    grace "Vedremo a riguardo!"


translate italian pool2_48ff1ed8:


    d "Bene!"


translate italian pool2_7bc9d103:


    grace "Ai vostri posti!"


translate italian pool2_ecef2909:


    dpense "Non posso rovinare tutto!"


translate italian pool2_f6390a0e:


    grace "Alle 3, vai!"


translate italian pool2_3314f8cb:


    d "Pronto!"


translate italian pool2_b8466fb7:


    grace "1..."


translate italian pool2_67424511:


    grace "2..."


translate italian pool2_542ac620:


    grace "3!"


translate italian nage2_226132c8:


    dpense "Devo andare più veloce di lei!"


translate italian nage3_58c7f260:


    dpense "È lo sprint finale!"


translate italian nage3_8278132c:


    d "VITTORIA !!!"


translate italian nage3_8278132c_1:


    d "VITTORIA !!!"


translate italian nage3_09c9d4b2:


    grace "IMBARAZZANTE!!!"


translate italian nage3_3ed7a701:


    grace "VITTORIA !!!"


translate italian victory_a3e3783a:


    grace "Oh! Mi hai impressionato! Non sono riuscito a starti dietro!"


translate italian victory_c991dce0:


    d "Sei stata bravissima! Pensavo che alla fine non avrei vinto!"


translate italian victory_4fa8f8ce:


    grace "Sì... quindi ti devo un favore..."


translate italian victory_c5e4f86c:


    d "Ahah! Sei stata tu a proporlo, vero?"


translate italian victory_1be0c3fd:


    grace "Già, beh, non mi aspettavo una concorrenza così agguerrita!"


translate italian victory_7961d703:


    d "Ti ho avvertita!"


translate italian victory_3de0ddee:


    grace "Nanaaa! Signor, sono troppo orgoglioso!"


translate italian victory_f44767f2:


    d "Cosa ti chiederò...?"


translate italian victory_92628f4c:


    grace "Non essere troppo duro con me, però..."


translate italian victory_c5c89714:


    d "Hmm..."


translate italian victory_9e5421b0:


    dpense "Se solo sapessi quanto è difficile in questo momento..."


translate italian victory_6e81e294:


    d "Riserverò questo favore per dopo, va bene?"


translate italian victory_9a03811a:


    grace "Va bene...!"


translate italian cheater_d760c5d6:


    grace "Hai barato !!!"


translate italian cheater_e4bc3bdd:


    d "Non era scritto nelle regole che dobbiamo toccare il muro!"


translate italian cheater_41767841:


    grace "Senza senso!"


translate italian cheater_06713c9c:


    d "Quindi cosa?"


translate italian cheater_2b33e359:


    grace "Ok... diciamo che ENTRAMBI abbiamo il diritto di chiederci un favore a vicenda... ok?"


translate italian cheater_40ab082c:


    d "Per me va bene!"


translate italian cheater_92628f4c:


    grace "Non essere troppo duro con me, però..."


translate italian cheater_c5c89714:


    d "Hmm..."


translate italian cheater_9e5421b0:


    dpense "Se solo sapessi quanto è difficile in questo momento..."


translate italian cheater_6e81e294:


    d "Riserverò questo favore per dopo, va bene?"


translate italian cheater_9a03811a:


    grace "Va bene...!"


translate italian defeat_5978fda4:


    grace "Ho vinto! Ah ah ah!"


translate italian defeat_8654b90d:


    d "Non c'era niente che potessi fare, eri davvero troppo forte!"


translate italian defeat_af31fc61:


    grace "Si lo so!"


translate italian defeat_278f39a6:


    d "Comunque ho combattuto bene!"


translate italian defeat_4a38dc42:


    grace "Sì, certo... Allora, cosa ti chiederò?"


translate italian defeat_058f48b4:


    dpense "Chiedimi tutto quello che vuoi..."


translate italian defeat_7141816a:


    grace "Lo conservo per dopo, se non ti dispiace..."


translate italian defeat_3813ec2e:


    d "Nessun problema!"


translate italian endpool_feb0a042:


    d "Però avevi ragione... è bello stare in piscina così... anche dopo una gara, è molto rilassante..."


translate italian endpool_7d7eae2f:


    grace "Te l'avevo detto! Mi aiuta ad alleviare lo stress e a non pensare alle preoccupazioni quotidiane..."


translate italian endpool_2983d61f:


    d "Tua madre ti stressa?"


translate italian endpool_c459a192:


    grace "Sì... Fondamentalmente devo essere la figlia perfetta per Madame la direttrice dell'Università..."


translate italian endpool_08e82bfc:


    grace "È super travolgente..."


translate italian endpool_875ad268:


    d "Si Capisco..."


translate italian endpool_3f8b6f6a:


    grace "Se non ho i voti migliori, se non sono il capitano della squadra di calcio..."


translate italian endpool_91740a1a:


    grace "Se non ho un fidanzato di una famiglia rispettata..."


translate italian endpool_9c7f54c9:


    d "Oh, ti sta facendo pressione anche per questo?"


translate italian endpool_ceb17858:


    grace "Sì... Fondamentalmente devo essere perfetta in ogni ambito e pronta a sposare un ragazzo della migliore famiglia in circolazione per stringere alleanze tra famiglie..."


translate italian endpool_5950ee26:


    grace "Ecco come funziona qui..."


translate italian endpool_80818372:


    d "E tu hai già un corteggiatore?"


translate italian endpool_77603962:


    grace "Parecchi! Ma non ho ancora trovato quello giusto..."


translate italian endpool_1f36b29c:


    grace "E mia madre continua a spingermi a scegliere qualcuno come Emerick o altri provenienti da famiglie come gli Orushi..."


translate italian endpool_657cfc1d:


    d "E se qualcuno..."


translate italian endpool_ca5ed8b2:


    d "Ero interessato a te..."


translate italian endpool_d12ba1aa:


    d "Ma non proveniva da quel tipo di background..."


translate italian endpool_c4cf4b82:


    grace "Mia madre sarebbe..."


translate italian endpool_26b66551:


    grace "Davvero dispiaciuta..."


translate italian endpool_49cfcdc9:


    d "Ma vorresti..."


translate italian endpool_36cff508:


    d "Essere?"


translate italian endpool_9ff13fac:


    ji "Ehm, ehm..." with hpunch


translate italian endpool_4981c72d:


    drew "Grace! Per favore, potresti uscire dall'acqua e unirti a me velocemente... stasera ceniamo!"


translate italian endpool_754ea95c:


    grace "Si Mamma..."


translate italian endpool_0d1f41a3:


    dpense "Uff, c'era mancato poco..."


translate italian endpool_1297fb29:


    drew "E tu, [name]... Non dimenticare che ti osservo... Hai capito?"


translate italian endpool_df4aea3a:


    d "Sì, signora Drew..."


translate italian endpool_d191e4f0:


    dpense "Non sarà facile..."


translate italian endpool_bdc6204a:


    grace "Ehi, [name]!"


translate italian endpool_5dda0f88:


    d "Hmm?"


translate italian endpool_8a8583e7:


    grace "Hai un telefono?"


translate italian endpool_63ba9085:


    d "Ehm... sì..."


translate italian endpool_77be5b7d:


    grace "Ecco, aggiungimi ai tuoi contatti più tardi!"


translate italian endpool_cd0a4421:


    d "EHI ! Sai qualcosa di una festa alla fine della settimana?"


translate italian endpool_d1605dea:


    grace "Sì ! La ospiterò! Nella mia casa !"


translate italian endpool_3130185e:


    grace "Verrai?"


translate italian endpool_de9778f4:


    d "Ovviamente !"


translate italian endpool_62becd20:


    grace "Va bene ! Allora... a domani!"


translate italian endpool_df3539f1:


    d "Ci vediamo!"


translate italian sofiapool_7474e0b0:


    d "Dove siamo ?"


translate italian sofiapool_46856e57:


    sofia "Quello è il vecchio anfiteatro..."


translate italian sofiapool_075af965:


    sofia "Nessuno lo usa più... a volte il consiglio studentesco..."


translate italian sofiapool_d90a9ae5:


    sofia "Come membro del consiglio ho la chiave..."


translate italian sofiapool_4c3c7b1f:


    sofia "Allora... mi mostrerai cosa sai fare?"


translate italian sofiapool_4d46038d:


    d "Non sei pronta..."


translate italian sofiapool_5b20eac3:


    sofia "OH ? E pensi di potermi gestire facilmente?"


translate italian sofiapool_6b59357b:


    d "Ti farò squirtare finché non mi implorerai di scoparti..."


translate italian sofiapool_47c38ad4:


    sofia "Si fallo..."


translate italian sofiapool_9b670c10:


    sofia "Fai quello che vuoi con me..."


translate italian sofiapool_3f55375c:


    d "Sdraiati sulla scrivania!"


translate italian sofiapool_bab69aa7:


    sofia "Uhmmm...."


translate italian sofiapool_7cb0a8e4:


    sofia "Non vedo l'ora di sentire il tuo tocco..."


translate italian sofiapool_af039036:


    sofia "Per favore... Gioca con me.... sono il tuo giocattolo..."


translate italian sofiapool_0664179c:


    sofia "Ahhhhhhhhhhh...."


translate italian sofiapool_f99d8985:


    dpense "È totalmente sotto il mio controllo..."


translate italian sofiapool_de8ff332:


    dpense "Mi ha lasciato fare esattamente quello che voglio..."


translate italian sofiapool_38c92066:


    dpense "Penso che provi molto piacere a essere sotto il mio dominio..."


translate italian sofiapool_8a6010a7:


    sofia "Oh... sto già venendo! Non fermarti!"


translate italian sofiapool_9abed53e:


    sofia "Ahhhhh!!!!"


translate italian sofiapool_5aee8d42:


    sofia "Fammi venire, mio ​​signore..."


translate italian sofiapool_d8e4cc07:


    dpense "Diventa totalmente pazza..."


translate italian sofiapool_636b8efc:


    sofia "Ohhhhh! Sto per venire !!!!"


translate italian sofiapool_5b80429a:


    d "Ti farò diventare la mia puttana e urlerai il mio nome finché non avrò finito con te..."


translate italian sofiapool_f1a71605:


    sofia "Ahhh..."


translate italian sofiapool_6b59357b_1:


    d "Ti farò squirtare finché non mi implorerai di scoparti..."


translate italian sofiapool_47c38ad4_1:


    sofia "Si fallo..."


translate italian sofiapool_72d38011:


    d "Ti farò diventare la mia troia e tu ingoierai tutto il mio sperma direttamente in gola..."


translate italian sofiapool_55bbb5fd:


    sofia "Oh sì... lo farò!"


translate italian sofiapool_ce0d59cb:


    d "Ti tratterò come la mia puttana personale... Risponderai a tutti i miei desideri..."


translate italian sofiapool_9b670c10_1:


    sofia "Fai quello che vuoi con me..."


translate italian sofiapool_3f55375c_1:


    d "Sdraiati sulla scrivania!"


translate italian sofiapool_bab69aa7_1:


    sofia "Uhmmm...."


translate italian sofiapool_7cb0a8e4_1:


    sofia "Non vedo l'ora di sentire il tuo tocco..."


translate italian sofiapool_af039036_1:


    sofia "Per favore... Gioca con me.... sono il tuo giocattolo..."


translate italian sofiapool_0664179c_1:


    sofia "Ahhhhhhhhhhh...."


translate italian sofiapool_f99d8985_1:


    dpense "È totalmente sotto il mio controllo..."


translate italian sofiapool_de8ff332_1:


    dpense "Mi ha lasciato fare esattamente quello che voglio..."


translate italian sofiapool_38c92066_1:


    dpense "Penso che provi molto piacere a essere sotto il mio dominio..."


translate italian sofiapool_8a6010a7_1:


    sofia "Oh... sto già venendo! Non fermarti!"


translate italian sofiapool_aecb242a:


    sofia "Ahhhhh!!!!"


translate italian sofiapool_cbb4b371:


    sofia "Dammi il tuo cazzo!"


translate italian sofiapool_5aee8d42_1:


    sofia "Fammi venire, mio ​​signore..."


translate italian sofiapool_e43ef0da:


    sofia "E vieni su di me quando lo faccio..."


translate italian sofiapool_f9449b96:


    sofia "Voglio sentirti sul mio viso"


translate italian sofiapool_d8e4cc07_1:


    dpense "Diventa totalmente pazza..."


translate italian sofiapool_0295c7cd:


    sofia "Adoro il tuo cazzo!! Uhmmmmmmm...."


translate italian sofiapool_26ee886c:


    sofia "Oh sì, continua così!"


translate italian sofiapool_3078de21:


    sofia "Mi piace così ! Mi piace così ! Mi piace così !"


translate italian sofiapool_636b8efc_1:


    sofia "Ohhhhh! Sto per venire !!!!"


translate italian sofiapool_bb354e6f:


    sofia "Ahhhh! AHHHHHHHHH! ......"


translate italian sofiapool_038daf43:


    sofia "Miiiiiiiiiooooooooo DDDDDDDDDIIIIIIIIOOOOOOOOO !!!"


translate italian sofiapool_8fe1a030:


    d "Vengo anch'io !!!"


translate italian sofiapool_70345f51:


    d "Ahhhhhhhhh...."


translate italian sofiapool_6ca2c9d6:


    sofia "Viscido ma soddisfacente!"


translate italian finblueep2_64eaab9a:


    d "Te l'avevo detto che ti avrei fatto squirtare!"


translate italian finblueep2_1dc39c06:


    sofia "Sì..."


translate italian finblueep2_4dc3c5ca:


    d "Sei stato brava..."


translate italian finblueep2_efc0c1d6:


    sofia "Anche tu non eri poi così male..."


translate italian finblueep2_6be327d6:


    sofia "Hai un telefono ?"


translate italian finblueep2_a22554f8:


    d "Certo... Perché?"


translate italian finblueep2_1f77f57e:


    sofia "È più facile restare in contatto..."


translate italian finblueep2_2c98ee9b:


    sofia "Bene ci vediamo dopo ?"


translate italian finblueep2_11f964e5:


    d "Si certo..."


translate italian finblueep2_9e894c95:


    dpense "Spero che Blue non fosse troppo rumoroso..."

translate italian strings:


    old "5 MINUTES LATER"
    new "5 MINUTI PIÙ TARDI"


    old "Follow her. [TEMP1!t]"
    new "Segui lei. [TEMP1!t]"


    old "Reject her. [TEMP2!t]"
    new "Rifiutala. [TEMP2!t]"


    old "Sport [TEMP1!t]"
    new "Sport [TEMP1!t]"


    old "Temperament [TEMP2!t]"
    new "Temperamento [TEMP2!t]"


    old "Go faster [TEMP1!t]"
    new "Vai più veloce [TEMP1!t]"


    old "Watch her [TEMP2!t]"
    new "Osservatela [TEMP2!t]"


    old "Swim normally [TEMP3!t]"
    new "Nuota normalmente [TEMP3!t]"


    old "Go even faster [TEMP1!t]"
    new "Vai ancora più veloce [TEMP1!t]"


    old "Cheat [TEMP2!t]"
    new "Imbroglio [TEMP2!t]"


    old "Sprint [TEMP1!t]"
    new "Scatto [TEMP1!t]"


    old "Win [TEMP2!t]"
    new "Vinci [TEMP2!t]"


    old "Let her win [TEMP3!t]"
    new "Lasciala vincere [TEMP3!t]"


















translate italian sofiapool_6b9d811b:


    sofia "Quello è il vecchio auditorium..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
