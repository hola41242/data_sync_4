


translate italian save1_285f8ea7:


    "Per favore salva il gioco qui..."

translate italian strings:


    old "SAVE NOW"
    new "SALVA ORA"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
