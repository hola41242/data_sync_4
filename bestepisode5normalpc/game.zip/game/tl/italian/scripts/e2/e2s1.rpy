

translate italian e2s1_03ecf3cb:


    dpense "Whaaaaa... Che giornata!"


translate italian e2s1_e3368f91:


    dpense "È incredibile... Questa competizione venuta fuori dal nulla, tutte queste ragazze, era il mio primo giorno e non avevo nemmeno lezione..."


translate italian e2s1_981aa673:


    dpense "Ma mi ha davvero stancato... devo ancora rimettere ordine in tutto questo casino!"


translate italian e2s1_a576b045:


    dpense "Il mio telefono! Beh, non ho contatti qui... devo chiedere i numeri alle ragazze..."


translate italian e2s1_d23f0865:


    dpense "Ok andiamo !"


translate italian e2s1_96a9da0e:


    d " {i} Eccoci qui. Nati per essere re. {/i} "


translate italian e2s1_055fcf24:


    d " {i} Siamo i principi dell'universo. {/i} "


translate italian e2s1_c247cc91:


    d " {i} Sono immortale. Ho dentro di me il sangue dei re. {/i} "


translate italian e2s1_e19559ea:


    d " {i} Non ho rivali. Nessun uomo può essere mio pari. {/i} "


translate italian e2s1_d16b1e74:


    d " {i} Portami nel futuro del tuo mondo. {/i} "


translate italian e2s1_ab629bc0:


    ruby "Che spettacolo! Quindi adesso devo chiamarti Highlander?"


translate italian e2s1_2f797be5:


    d "Na..."


translate italian e2s1_553923c3:


    ruby "Vedremo! Forza, prendi la tua roba, gli altri ci aspettano..."


translate italian e2s1_b2842d1b:


    d "SÌ..."


translate italian e2s1_5949d107:


    ruby "OH? Hai un telefono?"


translate italian e2s1_b3a81635:


    d "Ah, sì... Beh, non ho contatti perché non conosco nessuno qui, ma sì... ho un telefono..."


translate italian e2s1_d2c08699:


    ruby "Forte!!! Aspetta, ti mando il mio contatto tramite scansione!"


translate italian e2s1_44b10ff2:


    d "Ehm... ok."


translate italian e2s1_054790de:


    ruby "Bene... Lo proveremo più tardi per vedere se funziona!"


translate italian e2s1_da01005d:


    ruby "Forza, andiamo a unirci agli altri!"


translate italian e2s1_c71a801b:


    d "Sto arrivando..."


translate italian e2s1_7abb44d8:


    emerick "Hai chiesto di vedermi, zio?"


translate italian e2s1_bec82cb9:


    orushi "Sì... ho visto i risultati del primo test..."


translate italian e2s1_474b3cf8:


    orushi "Hai fatto bene..."


translate italian e2s1_0de5a8e8:


    emerick "Ovviamente! Non avevo intenzione di uscire sconfitto contro quel gruppo di perdenti!"


translate italian e2s1_fa66421e:


    orushi "Basta!"


translate italian e2s1_b14aabed:


    rufus "FSHHHHHHHHHHHHHHHH"


translate italian e2s1_d933fc72:


    orushi "So che una delle tue vipere è scappata per prepararti la borsa, quindi dovevi solo prenderla senza cercarla!"


translate italian e2s1_24ab3896:


    orushi "Sei fortunato che la tigre fosse impegnata a cercare la sua!"


translate italian e2s1_2aaf9bb0:


    orushi "La prossima volta non la lascerò scappare!"


translate italian e2s1_cf4435e1:


    emerick "Sì, zio..."


translate italian e2s1_35a7916f:


    orushi "E quel ragazzo francese? Non era affatto male..."


translate italian e2s1_9512b329:


    emerick "Lui è solo un debole rispetto a me..."


translate italian e2s1_76552bd6:


    orushi "Debole o meno, bisogna diffidare di lui..."


translate italian e2s1_cd9cde25:


    emerick "Mi prenderò cura di lui..."


translate italian e2s1_e51d9fe2:


    orushi "Faresti meglio a vincere il prossimo torneo..."


translate italian e2s1_6d3040d9:


    emerick "E' già fatto..."


translate italian e2s1_af86760f:


    ruby "Beh, ci manca solo Madison... sarà qui presto..."


translate italian e2s1_7cc5e482:


    julia "Va bene se non viene, sai..."


translate italian e2s1_f02b1c50:


    grace "Julia! Dai, dalle un po' di tregua! È impegnata a prendersi cura di sua figlia! Sai che è difficile per lei gestire tutto!"


translate italian e2s1_7ee5c516:


    grace "E in più suo fratello sta facendo chissà cosa..."


translate italian e2s1_f12f82c3:


    grace "E i suoi genitori le chiedono sempre qualcosa... Ho lo stesso problema con mia madre..."


translate italian e2s1_d579fcfd:


    grace "Mi diceva sempre: 'Grace, non farlo!' Grace, tu sei il capitano, devi dare l'esempio!'"


translate italian e2s1_19e030da:


    grace "'Grace, devi prendere i voti migliori!' Grace, Grace, Grace..."


translate italian e2s1_69d97443:


    julia "Dev'essere dura per te affrontarlo..."


translate italian e2s1_c35ce243:


    grace "No!!! Finché ho la squadra, voi ragazze, e qualcosa che mi aiuti a fuggire un po', va tutto bene!"


translate italian e2s1_9f2c3adf:


    grace "A proposito, ho comprato del buon vino francese... Lo adorerai!!!"


translate italian e2s1_b47d10ff:


    ruby "Cosa stai pensando? Siamo al campus!!!"


translate italian e2s1_e8410113:


    grace "Oh, andiamo, Ruby, non fare la guastafeste!"


translate italian e2s1_93b521a5:


    ruby "Sul serio, Grace, se vuoi bere, fai pure... Ma non qui..."


translate italian e2s1_7ef21552:


    grace "Cosa ne pensi, [name]?"


translate italian e2s1_669f4ba0:


    d "Non dovresti bere qui... Potrebbe causare problemi."


translate italian e2s1_6eba75e1:


    grace "Ok, lo metto via..."


translate italian e2s1_a933aa2c:


    d "A dire il vero non sono un grande fan delle donne che bevono..."


translate italian e2s1_5e9c212e:


    grace "Sì, immagino che non sia molto sexy... Okay, vediamoci stasera, bella bottiglia..."


translate italian e2s1_639b4fca:


    d "Non fa bene alla tua prestazione fisica, lo sai?"


translate italian e2s1_83df6de2:


    grace "Haha, sembri il mio allenatore! Ok, ciao ciao vino delle vigne... Ciao bevanda proteica!"


translate italian e2s1_ed8c99c0:


    d "Non ti dirò cosa fare... Ma a volte è bello alleviare un po' la pressione!"


translate italian e2s1_2d9406be:


    grace "Ora c'è qualcuno che capisce come funziona questo mondo! Ma Ruby ha ragione... non dovrei tenere questa bottiglia qui..."


translate italian e2s1_5a82890d:


    d "Chi è... ?"


translate italian e2s1_1bb364fc:


    dpense "Um... Non è la stessa donna senza la coda di cavallo... Whaaa!"


translate italian e2s1_deca88bf:


    mad "Perché mi guardate in quel modo? Ho qualcosa sul mio outfit?"


translate italian e2s1_db67b519:


    grace "NO!!! Sei stupenda Maddie... non capisco come tu sia ancora single..."


translate italian e2s1_d4a4d528:


    mad "Parlate per voi ragazze! Ho un figlio di cui occuparmi, una famiglia da evitare e gare da vincere..."


translate italian e2s1_21e11beb:


    mad "Non c'è spazio per nessun altro... E poi a questa età i ragazzi non vogliono avere a che fare con tutti questi problemi... Giusto [name]?"


translate italian e2s1_b6cd12ff:


    d "Se hai bisogno di aiuto, possiamo assisterti anche nella gestione di tutto questo... Non sei sola!"


translate italian e2s1_53066af2:


    mad "È carino da parte tua..."


translate italian e2s1_694d95bd:


    ruby "Ovviamente è gentile! Cosa ne pensate?"


translate italian e2s1_9d81cd20:


    mad "Non lo so..."


translate italian e2s1_a114d9b6:


    d "Se vuoi consigli su qualsiasi cosa sono a disposizione..."


translate italian e2s1_378658d6:


    mad "Perché sai dell'educazione dei bambini?"


translate italian e2s1_340fa348:


    mad "O la gestione della crisi negli anni Quaranta per genitori assetati di potere e ricchezza?"


translate italian e2s1_7bc8a915:


    ruby "EHI! Non ti ha aggredita!!!"


translate italian e2s1_dbd14366:


    mad "Sì, lo so... Perdonami [name]..."


translate italian e2s1_71f3cdde:


    d "Dobbiamo concentrarci sulla concorrenza, il resto non deve pesarci."


translate italian e2s1_9bb66f10:


    mad "Hai ragione... Il MIGLIORE.. La squadra... Questo è l'importante..."


translate italian e2s1_5865f53d:


    ruby "E se il peggio dovesse accadere, hai noi se hai bisogno! Sai che sono qui per te!"


translate italian e2s1_30bbab5f:


    mad "Piccola... so che sei lì per me quando ho bisogno di te..."


translate italian e2s1_f1baba71:


    d "Non avrei problemi ad affrontare tutti questi inconvenienti..."


translate italian e2s1_f5eabbd4:


    d "Dopotutto, se vuoi stare con qualcuno, prendi tutto ciò che rende quella persona quello che è!"


translate italian e2s1_b0cb56e3:


    mad "Hmm... sembri sicuro di te stesso... mi chiedo come affronteresti tutto questo..."


translate italian e2s1_9aba7878:


    d "Non puoi saperlo finché non lo provi."


translate italian e2s1_c7579901:


    mad "È vero..."


translate italian e2s1_dc5b375f:


    ruby "È pazzesco tutto quello che ci sta succedendo!"


translate italian e2s1_68ae02f5:


    julia "Cosa intendi?"


translate italian e2s1_4acc53b4:


    ruby "Beh, non so voi, ragazzi, ma sento che stiamo vivendo qualcosa di speciale..."


translate italian e2s1_73fda96c:


    ruby "Come se fossimo parte di qualcosa di grande... Con storie, confronti... Prove..."


translate italian e2s1_9e26ec3f:


    ruby "Anche il nostro incontro con [name] è speciale! Lo incontriamo su un aereo e finisce per essere il mio coinquilino, dorme da Grace la prima notte..."


translate italian e2s1_61df0e42:


    ruby "Fa il primo test MIGLIORE con [chosen] e alla fine è quasi vicino a vincere! È come se fosse l'eroe di una visual novel!"


translate italian e2s1_d3bb40de:


    julia "Che cos'è?"


translate italian e2s1_6541b6d1:


    ruby "Un eroe di Visual Novel!"


translate italian e2s1_85ec0c6b:


    grace "Eh?"


translate italian e2s1_9b5f314f:


    ruby "Un eroe VI-SU-AL-NO-VEL!"


translate italian e2s1_6e7805f2:


    mad "UN ?"


translate italian e2s1_8805bde7:


    ruby "Racconto illustrato! Un romanzo d'avventura in cui scegli la tua!"


translate italian e2s1_c1835389:


    d "Ah! Un romanzo Vizoual!"


translate italian e2s1_e9754cba:


    ruby "..."


translate italian e2s1_2fef4c63:


    ruby "Sì, forse un VN per adulti in realtà..."


translate italian e2s1_2736e21d:


    d "Cos'è esattamente un VN per adulti?"


translate italian e2s1_262a0855:


    ruby "Oh mio Dio, davvero non sai niente?"


translate italian e2s1_6443aa2f:


    mad "Bene, vai avanti e spiega!"


translate italian e2s1_5f285438:


    ruby "Va bene!!!"


translate italian e2s1_cfb4ca65:


    ruby "Una visual novel è un gioco in cui fai delle scelte che influenzano la storia..."


translate italian e2s1_60191ee4:


    ruby "Tipo se andare a sinistra..."


translate italian e2s1_d15659ac:


    ruby "Oppure destra... E ogni scelta crea un ramo che può portare la storia in una direzione..."


translate italian e2s1_da182dc0:


    ruby "Oppure un'altra!"


translate italian e2s1_f491c4c0:


    ruby "Da non confondere con un romanzo cinetico che è una linea retta in termini di eventi. In sostanza, con un Romanzo Cinetico si segue un'avventura..."


translate italian e2s1_ff85cb50:


    ruby "Con un romanzo visivo, sei un attore a tutti gli effetti poiché decidi cosa vuoi fare con ogni scelta offerta!"


translate italian e2s1_bec58da1:


    ruby "E nelle visual novel per adulti, alcune cose sono più..."


translate italian e2s1_ce194798:


    ruby "Sexy..."


translate italian e2s1_4f9373b1:


    ruby "E vengono affrontati argomenti un po' più difficili come l'alcolismo... Dipendenze... Domande sulla sessualità..."


translate italian e2s1_8222f50e:


    ruby "Argomenti a volte anche più contorti... Ma non entreremo oltre in questi dettagli!!!"


translate italian e2s1_311c7ed2:


    ruby "Ci sono 7 regole da seguire in una visual novel per adulti!"


translate italian e2s1_81b67b85:


    d "Cosa intendi con 7 regole?"


translate italian e2s1_1a6dede1:


    ruby "Beh, in realtà ce ne sono altri, ma a me piace il numero 7, quindi... COMUNQUE! Sono io che spiego, quindi decido io!"


translate italian e2s1_012699c5:


    ruby "Regola numero 1: l'eroe deve essere carismatico! Deve avere carattere! Non dovrebbe diventare uno zerbino davanti a tutti quelli che incontra e dire sì a tutto..."


translate italian e2s1_69f1461a:


    ruby "Si adatta bene a [name], non credi?"


translate italian e2s1_c679b986:


    mad "Perché deve essere lui l'eroe? Perché non può essere una ragazza?" with hpunch


translate italian e2s1_b9868f46:


    julia "Sì, perché l'eroe è sempre un ragazzo?"


translate italian e2s1_2942cb63:


    ruby "Non è sempre così! Conosco molti giochi in cui l'eroe è in realtà un'eroina..."


translate italian e2s1_8cadab8e:


    ruby "ma visto che siamo nel settore adulti, la maggioranza dei giocatori sono... uomini..."


translate italian e2s1_9d1ff317:


    mad "Questo non spiega perché [name] è l'eroe della tua storia..."


translate italian e2s1_567e0472:


    ruby "Maddie..."


translate italian e2s1_9ea61dc5:


    mad "Ok, va bene... Continua!"


translate italian e2s1_b8d61786:


    ruby "Regola n.2: L'eroe deve avere Lis a cui aggrapparsi, come il giocatore che si affezionerà a lui."


translate italian e2s1_f2334755:


    julia "Lis?"


translate italian e2s1_5850cbe3:


    ruby "Li... Interessi amorosi!!!! Insomma conquiste!"


translate italian e2s1_041b7546:


    grace "E come fanno a sapere di essere Lis?"


translate italian e2s1_5eab819b:


    ruby "Non lo sanno! Incontrano l'eroe in modo naturale! Come quando abbiamo incontrato [name] sull'aereo!"


translate italian e2s1_386f66a6:


    grace "Quindi ogni ragazza che l'eroe incontra diventa una Li?"


translate italian e2s1_004af490:


    ruby "NO! E non ho detto che dovevano essere ragazze! Ci sono giochi in cui l'eroe è gay o meno..."


translate italian e2s1_d772cdb6:


    ruby "Ma qui, per esempio, [name] ha conosciuto parecchie ragazze da quando è qui!"


translate italian e2s1_e2297a88:


    ruby "Forse ha già una connessione con alcuni di loro! E poi alcune delle conoscenze dell'eroe possono diventare 'casuali' o 'ragazze secondarie'..."


translate italian e2s1_5a63cb46:


    ruby "Come una delle gemelle nello spogliatoio..."


translate italian e2s1_505f342d:


    julia "Uuuu?"


translate italian e2s1_e1cf0ec0:


    mad "Già...come una delle gemelle sotto la doccia..."


translate italian e2s1_505f342d_1:


    julia "Uuuu?"


translate italian e2s1_a4ae5c62:


    grace "[name], se avessi occhi per qualcuno dopo solo un giorno qui, chi sarebbe?"


translate italian e2s1_b1dc201a:


    d "Uhm..."


translate italian chosenkiss_c0c7ea31:


    chosen "Oh, che carino!!!"


translate italian chosenkiss_c1d00fb4:


    "Ma io non sono Blu quindi... Torna dalla tua vipera!"


translate italian chosenkiss_29561989:


    ruby "Bene, va tutto bene, ma passiamo alla regola numero 3!"


translate italian chosenkiss_8b5643a9:


    ruby "Gli interessi amorosi possono avere un passato, ma è ancora meglio se sono vergini!"


translate italian chosenkiss_fb631fdc:


    mad "Che cosa???"


translate italian chosenkiss_370788c5:


    ruby "Sì... Ovviamente non puoi dire di esselo... Hai una figlia, quindi..."


translate italian chosenkiss_134961cf:


    mad "Quindi non posso avere un interesse amoroso?"


translate italian chosenkiss_7e7e2e62:


    ruby "Volevi diventarlo?"


translate italian chosenkiss_bc824b1a:


    mad "No, ma mi hai vista? Se fossi in quel tipo di gioco, lo spero proprio! Non sarei solo una 'ragazza secondaria'!"


translate italian chosenkiss_f653a44a:


    grace "Hahaha!"


translate italian chosenkiss_8af8bebb:


    ruby "No, ma non è che non puoi avere un interesse amoroso se non sei vergine! È solo che i giocatori preferiscono le ragazze 'pure' alle ragazze che sono state in giro..."


translate italian chosenkiss_c7db646b:


    mad "È ridicolo... non mi piace il tuo gioco..."


translate italian chosenkiss_99cbf7ae:


    ruby "Ad esempio qui non se la passiamo poi tanto male! [name] avrebbe quattro ragazze, e tre di loro sono vergini!"


translate italian chosenkiss_42486048:


    julia "Ok, non c'è bisogno che ce lo ricordi, Ruby..."


translate italian chosenkiss_36cccf90:


    grace "Già... A volte mi chiedo se dovrei 'aprirmi' un po' di più..."


translate italian chosenkiss_aede0390:


    ruby "Non è un grosso problema, ragazze! E' ancora meglio per i giocatori... E almeno non saremo incolpati della 4a regola!!!"


translate italian chosenkiss_bdfd47df:


    mad "E qual è la quarta regola? Non è consentito avere figli?"


translate italian chosenkiss_894769a1:


    ruby "NO!!!"


translate italian chosenkiss_835b305a:


    ruby "La quarta regola è: No TMI!!!"


translate italian chosenkiss_29ac5843:


    d "Che cosa?"


translate italian chosenkiss_ce2d5e47:


    ruby "TMI! Troppe informazioni!!! Troppo passato uccide il presente!"


translate italian chosenkiss_6d3dab99:


    grace "Non capisco proprio..."


translate italian chosenkiss_24160dd1:


    ruby "Fondamentalmente, il giocatore che gioca a questo gioco... non vuole sapere quanti ragazzi hai baciato..."


translate italian chosenkiss_c5257780:


    ruby "O meglio... prima di incontrarlo... Non gli interessa! È come dire: Oh wow, il tuo è più grande di quello di Edward."


translate italian chosenkiss_8258fe0c:


    ruby "Non è interessante! O sentire... ho avuto 100 ragazzi, ma tu sei il migliore che ho avuto..."


translate italian chosenkiss_ce93967e:


    ruby "Oltre a sembrare una troia, non aggiunge nulla al giocatore tranne un certo sentimento verso la ragazza!"


translate italian chosenkiss_392c2d22:


    ruby "A volte si arriva al punto di abbandonare il gioco perché il giocatore non ne vuole assolutamente sentir parlare! Quindi, niente TMI, nessun problema!"


translate italian chosenkiss_5ce70a32:


    mad "Ma ho comunque il diritto di aver avuto una vita?"


translate italian chosenkiss_4b1161c1:


    ruby "Ovviamente! Ma la tua storia d'amore con l'eroe non dovrebbe entrare in conflitto con una storia d'amore precedente che potrebbe essere esistita!"


translate italian chosenkiss_58c738d5:


    ruby "Dopotutto, nella vita reale, nessuno vuole essere paragonato a qualcun altro durante una relazione o un atto sessuale... Ancor meno in un gioco..."


translate italian chosenkiss_16d76ed1:


    julia "Beh, è ​​più facile quando sei vergine!"


translate italian chosenkiss_f48f8f08:


    ruby "Sì, ma non dovresti dire qualcosa del tipo: 'Oh, ho già baciato altri ragazzi, ma con te è diverso'"


translate italian chosenkiss_a9acb29d:


    julia "Mah... Beh, non l'ho fatto neanche io!!"


translate italian chosenkiss_188cc25b:


    ruby "Comunque, quinta regola!!!"


translate italian chosenkiss_939fccd4:


    d "Sembra che stiamo per dare alla luce un Gremlin... Non si può allattare dopo mezzanotte... Non si può mettere in acqua... Non si può esporre alla luce del sole..."


translate italian chosenkiss_a29cc547:


    ruby "OH!!! Conosci i Gremlins??? E' un film di Steven Spielberg!!! E lo sapevi che..."


translate italian chosenkiss_e38298e5:


    d "Ruby!!!" with hpunch


translate italian chosenkiss_c1826e34:


    ruby "Oh scusa... Va bene, la quinta regola: devi avere una MILF!"


translate italian chosenkiss_5eefb60e:


    grace "Ahahahahahah! Maddie, quello è per te!"


translate italian chosenkiss_91afb2d6:


    mad "Non sono una MILF!" with hpunch


translate italian chosenkiss_a393b1dd:


    julia "Tecnicamente... potresti esserlo!"


translate italian chosenkiss_e593a657:


    mad "Ma piantala, ho 22 anni, non sono una MILF... Gabriella potrebbe esserlo se vuoi!"


translate italian chosenkiss_a6936512:


    grace "L'insegnante?"


translate italian chosenkiss_b01b9536:


    mad "Sì!"


translate italian chosenkiss_e453b0a8:


    d "Non la conosco!"


translate italian chosenkiss_3377260b:


    ruby "Oh non preoccuparti, la vedrai domani!!!"


translate italian chosenkiss_4035bba9:


    mad "Allora come dovrebbe essere la tua MILF?"


translate italian chosenkiss_d6b663b2:


    ruby "È meglio se viene trascurata dal marito... Se non viene toccata da un po'..."


translate italian chosenkiss_afde39b0:


    ruby "se è un'anima perduta che l'eroe salverà..."


translate italian chosenkiss_30d62a1a:


    grace "E [name] salverà Gabriella? Voglio dire, potrebbe rientrare in quella categoria, ma non vedo [name] con una donna di 35 anni!"


translate italian chosenkiss_1df83774:


    grace "Te l'avevo detto!"


translate italian chosenkiss_8ca883d5:


    julia "Detto così è bello... è romantico!"


translate italian chosenkiss_4dcee382:


    mad "Non guardarmi quando dici questo!!!!"


translate italian chosenkiss_daafaac8:


    ruby "Ad ogni modo, abbiamo bisogno di una MILF... perché crea altre dinamiche con il giocatore, spesso con tabù o altre cose che solleticano la sua immaginazione..."


translate italian chosenkiss_2a5dc559:


    mad "Mah...allo stesso tempo, l'immaginazione dei ragazzi è per lo più localizzata all'altezza della vita...e non molto di più..."


translate italian chosenkiss_93e11265:


    ruby "Questo ci porta alla penultima regola: non tutti i feticci sono per tutti!"


translate italian chosenkiss_18ee35c4:


    grace "Feticci?"


translate italian chosenkiss_c1d261d7:


    ruby "Sì..."


translate italian chosenkiss_c8aa12cf:


    julia "Che cos'è?"


translate italian chosenkiss_d9cecfb7:


    ruby "Uh... per esempio, alcuni giocatori sono feticisti dei piedi... adorano le scene con piedi, calze o altre parti del corpo..."


translate italian chosenkiss_c735661d:


    ruby "Ad altri piace il BDSM... Altri non sopportano le scene lesbo... E non fatemi nemmeno iniziare con NTR..."


translate italian chosenkiss_305242eb:


    d "NTR?"


translate italian chosenkiss_29470446:


    ruby "Sì, NTR... Viene da 'netorare'... Fondamentalmente il principio di barare, o essere traditi nel gioco..."


translate italian chosenkiss_4f6772e8:


    ruby "Ad alcuni piace... Altri lo odiano... E crea conflitti tra due team che discutono su cosa sia meglio secondo loro..."


translate italian chosenkiss_334f2a21:


    ruby "Quindi, per evitare tutto ciò: tutto ciò che riguarda il feticismo o un'opinione un po' più personale o specifica per la personalità del giocatore deve essere FACOLTATIVO!"


translate italian chosenkiss_a548b7ad:


    grace "Non capisco davvero come fai a farlo..."


translate italian chosenkiss_2bc88dcb:


    ruby "Uh... Ok, un esempio: Grace, alzati!"


translate italian chosenkiss_a3493863:


    grace "Va bene!"


translate italian chosenkiss_ecde9d6a:


    ruby "Ora baciami!"


translate italian chosenkiss_0dafd5f9:


    grace "Eh???"


translate italian chosenkiss_01eb2f6a:


    ruby "Avanti, baciami! Solo un piccolo bacio!"


translate italian chosenkiss_ef85cac4:


    grace "Beh, se vuoi, ma non vedo come possa dare l'esempio!"


translate italian chosenkiss_ef037255:


    ruby "Stop!"


translate italian chosenkiss_38c5cdf2:


    ruby "[name], vorresti vederci baciare?"


translate italian chosenkiss_e80a0892:


    mad "Ovviamente ha detto di sì... Due ragazze che si baciano e lui è duro in pochi secondi!"


translate italian chosenkiss_def43184:


    ruby "Non era male..."


translate italian chosenkiss_6a4f23ef:


    grace "Sì..."


translate italian chosenkiss_d60a073d:


    ruby "Vedi, gli abbiamo dato una scelta! Questo è il principio. Se non avesse voluto vederci baciarci, avrebbe potuto dire di no e sarebbe stato fatto."


translate italian chosenkiss_b79a1c45:


    ruby "Vedi, gli abbiamo dato una scelta! Questo è il principio. Se avesse voluto vederci baciarci avrebbe potuto dire di sì e lo avremmo fatto."


translate italian chosenkiss_841cf19e:


    ruby "Ma almeno rispettiamo quello che gli piace e vuole vedere quando gioca!"


translate italian chosenkiss_b6788b9d:


    grace "Adesso capisco meglio!"


translate italian chosenkiss_b4359a05:


    ruby "E infine l'ultima regola: la più importante di tutte!"


translate italian chosenkiss_45f140c1:


    mad "Scommetto che sarà TUTTO SESSO, ovunque, sempre, con chiunque!"


translate italian chosenkiss_e1aa72bf:


    grace "No, io dico che i personaggi dovrebbero avere tette enormi, un sedere ultra rotondo e labbra carnose..."


translate italian chosenkiss_cd7a880b:


    julia "Oppure dovrebbero esserci dei drammi! Cose che spaventano, cose che ti fanno piangere..."


translate italian chosenkiss_9f40f626:


    ruby "POOOOOOOOOOOOTTTTTTTTTT….Sei l'anello più debole… arrivederci!"


translate italian chosenkiss_dd5d68f3:


    d "Eh?"


translate italian chosenkiss_d5ab8d28:


    ruby "Il sesso dovrebbe essere integrato e supportare la storia, non il contrario!"


translate italian chosenkiss_2c3a63c7:


    d "Cosa intendi?"


translate italian chosenkiss_1a514c11:


    ruby "Fondamentalmente, la storia dovrebbe venire prima. Il sesso dovrebbe essere solo un aspetto del gioco e non diventare l’elemento principale."


translate italian chosenkiss_476ab487:


    ruby "Altrimenti tutto il resto perde significato."


translate italian chosenkiss_600af04a:


    ruby "In tal caso, potresti anche creare un gioco in cui l'eroe è un affetto da amnesia che entra nella casa di sua zia/vicino/padrone di casa (scegline uno) e vede 2-3-4 ragazze all'interno..."


translate italian chosenkiss_e8625ea9:


    ruby "E ha un harem senza mai uscire di casa, con scene di sesso ogni 5 secondi e nessuna storia dietro..."


translate italian chosenkiss_a9cca5de:


    ruby "Certo, potrebbe essere bello per il giocatore del fast food, ma per un giocatore coinvolto nella storia è ripugnante."


translate italian chosenkiss_705eeb93:


    ruby "L'eroe diventa una macchina senza sentimenti e le ragazze diventano carne..."


translate italian chosenkiss_9d7730bf:


    ruby "In breve, possiamo riassumere questa regola così: i giocatori non vogliono il realismo... vogliono la magia!"


translate italian chosenkiss_28d95fb6:


    julia "OH..."


translate italian chosenkiss_a8699778:


    d "BENE..."


translate italian chosenkiss_d3559afb:


    ruby "Ma tutto questo era solo uno scenario ipotetico di come sarebbe se fossimo in una visual novel per adulti!"


translate italian chosenkiss_1e5dfb0e:


    mad "Già, perché [name] è l'eroe e io la MILF..."


translate italian chosenkiss_44699cd8:


    grace "Non riesce a superare questa cosa della MILF!!!"


translate italian chosenkiss_c02f63b0:


    julia "Bene, ragazze, per quanto mi piacerebbe restare a chiacchierare, devo ancora andare in biblioteca a prendere i miei libri di testo..."


translate italian chosenkiss_b8c86f42:


    grace "Ed io devo andare in piscina..."


translate italian chosenkiss_dd120e78:


    d "Julia..."


translate italian chosenkiss_3fb1de81:


    julia "SÌ?"


translate italian chosenkiss_df802e86:


    d "Avevi detto che mi avresti fatto fare un giro del campus questo pomeriggio... Hai ancora tempo?"


translate italian chosenkiss_3989a49b:


    julia "Oh, vieni con me! Ti mostrerò il percorso verso la biblioteca, così potrai vedere le diverse parti dell'Università!"


translate italian chosenkiss_34c55b1f:


    d "Grazie mille..."


translate italian chosenkiss_3fcacb3d:


    julia "A più tardi, ragazze!"


translate italian chosenkiss_8f1df40c:


    grace "A dopo! Divertiti e, [name], non approfittarti troppo di lei!"


translate italian chosenkiss_c4897051:


    grace "Solo perché tu sei l'eroe e lei è vergine, non significa che dovresti saltarle addosso!"


translate italian chosenkiss_ef579692:


    julia "Grace..."


translate italian chosenkiss_38715887:


    grace "Sono qui fuori!!!"


translate italian chosenkiss_3896858a:


    julia "Hum... Hai un telefono?"


translate italian chosenkiss_21922934:


    d "Sì, l'ho appena preso dalla borsa..."


translate italian chosenkiss_8121b812:


    julia "Permettimi di aggiungerti !"


translate italian chosenkiss_ce7133ef:


    julia "Ok andiamo..."

translate italian strings:


    old "EPISODE 2 {p} \n Double Trouble"
    new "EPISODIO 2 {p} \n Doppio guaio"


    old "NEW CONTACT ADDED"
    new "NUOVO CONTATTO AGGIUNTO"


    old "Buddy [TEMP1!t]"
    new "Amico [TEMP1!t]"


    old "Education [TEMP2!t]"
    new "Istruzione [TEMP2!t]"


    old "Sport [TEMP3!t]"
    new "Sport [TEMP3!t]"


    old "Temperament [TEMP4!t]"
    new "Temperamento [TEMP4!t]"


    old "I'm not a fan of older women."
    new "Non sono un fan delle donne anziane."


    old "Age has nothing to do with feelings. [TEMP1!t]"
    new "L’età non ha nulla a che fare con i sentimenti. [TEMP1!t]"


    old "Milfs are life! [TEMP2!t]"
    new "Le MILF sono la vita! [TEMP2!t]"


    old "Yes, definitely! [TEMP1!t]"
    new "Sì, sicuramente! [TEMP1!t]"


    old "No, I don't like it. [TEMP2!t]"
    new "No, non mi piace. [TEMP2!t]"






translate italian chosenkiss_80e6294b:


    mad "Ma io non sono Blu quindi... Torna dalla tua vipera!"
















translate italian e2s1_fe0698a3:


    cr "Ruby spiegherà alle ragazze cos'è una Visual Novel."


translate italian e2s1_9630385f:


    cr "Tieni presente che se non segui questa conversazione potresti perdere alcuni contenuti in seguito."


translate italian e2s1_05f0b011:


    cr "Vuoi vedere la sua spiegazione?"


translate italian finrubyvn_c02f63b0:


    julia "Bene, ragazze, per quanto mi piacerebbe restare e chiacchierare, devo comunque andare in biblioteca a prendere i miei libri di testo..."


translate italian finrubyvn_b8c86f42:


    grace "E devo andare in piscina..."


translate italian finrubyvn_dd120e78:


    d "Julia..."


translate italian finrubyvn_3fb1de81:


    julia "SÌ?"


translate italian finrubyvn_df802e86:


    d "Avevi detto che mi avresti fatto fare un giro del campus questo pomeriggio... Hai ancora tempo?"


translate italian finrubyvn_3989a49b:


    julia "Oh, vieni con me! Ti faccio un giro sulla strada per la biblioteca, così puoi vedere le diverse parti dell'Università!"


translate italian finrubyvn_34c55b1f:


    d "Grazie mille..."


translate italian finrubyvn_3fcacb3d:


    julia "Ci vediamo dopo, ragazze!"


translate italian finrubyvn_8f1df40c:


    grace "Ci vediamo dopo! Divertitevi e [name] non approfittate troppo di lei!"


translate italian finrubyvn_c4897051:


    grace "Solo perché tu sei l'eroe e lei è vergine, non significa che dovresti saltarle addosso!"


translate italian finrubyvn_ef579692:


    julia "Grace..."


translate italian finrubyvn_38715887:


    grace "Me ne vado!!!"


translate italian finrubyvn_3896858a:


    julia "Hum... Hai un telefono?"


translate italian finrubyvn_21922934:


    d "Sì, l'ho appena preso dalla mia borsa..."


translate italian finrubyvn_8121b812:


    julia "Lascia che ti aggiunga!"


translate italian finrubyvn_ce7133ef:


    julia "Ok... andiamo..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
