

translate italian e2s3_8cbd665b:


    d "Chi potrebbe essere?"


translate italian e2s3_86bd34e7:


    d "OH ? Un altro messaggio!"


translate italian e2s3_a25d3f67:


    d "Ok... devo essere riposato per domani..."


translate italian e2s3_90146086:


    d "Ancora ?"


translate italian e2s3_4768f182:


    d "Adesso... Riposa!"


translate italian e2s3_5b2d794b:


    julia " {i} Ehi, ti ho appena incontrato... {/i} "


translate italian e2s3_d255241c:


    julia " {i} E questo è pazzesco... {/i} "


translate italian e2s3_d7f51766:


    julia " {i} Ma ecco il mio numero... {/i} "


translate italian e2s3_fb89d37b:


    julia " {i} Allora chiamami, forse? {/i} "


translate italian e2s3_f2f3c377:


    ji "Questa è la prima volta che ti sento cantare così!"


translate italian e2s3_d314bb4d:


    julia "Eh? Ehm... sì..."


translate italian e2s3_180aa646:


    ji "C'è un ragazzo dietro tutto questo, vero?"


translate italian e2s3_4d6deba1:


    julia "Cosa?... No, per niente... Cosa stai immaginando?"


translate italian e2s3_8aa0c3dd:


    ji "Dai, smettila... non ti ho mai vista così allegra e vivace!"


translate italian e2s3_af5b50d7:


    ji "Posso dire quando un amica è entusiasta di un ragazzo!"


translate italian e2s3_d6003cdf:


    julia "Beh, non è niente... è solo un ragazzo che ho conosciuto..."


translate italian e2s3_b00a0896:


    ji "Allora, com'è?"


translate italian e2s3_74703c30:


    julia "Charlotte!!!"


translate italian e2s3_66671b48:


    cha "Cosa c'è che non va??? Deve essere davvero bello per aver attirato la tua attenzione!"


translate italian e2s3_1f425e96:


    julia "Beh... non proprio... non lo so... è solo che mi piace, tutto qui..."


translate italian e2s3_dcdc0b5a:


    cha "Sai cosa pensa di te?"


translate italian e2s3_a02e67e4:


    julia "Penso che gli piaccio... ma non ne sono proprio sicura..."


translate italian e2s3_22afcde9:


    cha "Eccezionale! Bene, ecco qua... La signorina sta entrando nella grande lega!"


translate italian e2s3_68ae02f5:


    julia "Cosa intendi?"


translate italian e2s3_4f013c56:


    cha "Vuoi che te lo spieghi???"


translate italian e2s3_dfd7962c:


    cha "Un ragazzo... una ragazza... innamorata..."


translate italian e2s3_23330d4b:


    julia "Oh, smettila... non ci siamo ancora..."


translate italian e2s3_67660424:


    cha "Sarei davvero curiosa di incontrarlo, sai..."


translate italian e2s3_81c2222a:


    cha "Per essere in questo stato, deve valerne la pena..."


translate italian e2s3_c66bfef3:


    julia "Probabilmente lo incontrerai prima o poi..."


translate italian e2s3_0c163247:


    cha "Sì... beh, vai tu a occuparti del tavolo dei ragazzi laggiù; Vado a contare i soldi!"


translate italian e2s3_6fd36bef:


    julia "Bene..."


translate italian e2s3_6c28afa2:


    julia "Penso che mi veda semplicemente come un amica..."


translate italian e2s3_a5f1e4b2:


    cha "Oh cavolo... beh, non è un buon inizio..."


translate italian e2s3_8e8b945d:


    julia "Beh, non è proprio un inizio, a dire il vero..."


translate italian e2s3_d76c7bb5:


    cha "Comunque, se è eccezionale come dici, mi piacerebbe incontrarlo!"


translate italian e2s3_81c2222a_1:


    cha "Per essere in questo stato, deve valerne la pena..."


translate italian e2s3_c66bfef3_1:


    julia "Probabilmente lo incontrerai prima o poi..."


translate italian e2s3_0c163247_1:


    cha "Sì... beh, vai tu a occuparti del tavolo dei ragazzi laggiù; Vado a contare i soldi!"


translate italian e2s3_6fd36bef_1:


    julia "Bene..."


translate italian e2s3_87bd76d0:


    julia "Per favore, signori, stiamo chiudendo..."


translate italian e2s3_7fc2e979:


    ji "Il cliente ha sempre ragione, non è così che dicono?"


translate italian e2s3_68ae02f5_1:


    julia "Cosa intendi?"


translate italian e2s3_13e15321:


    ji "Se decido che resteremo qui, allora resteremo, giusto ragazzi?"


translate italian e2s3_7cf02106:


    ji "Sì!!!"


translate italian e2s3_97b1d9f0:


    julia "Ascolta, ti sto solo chiedendo di andartene così posso andare a casa..."


translate italian e2s3_ca5bec71:


    ji "Non ci frega niente di quello che vuoi!"


translate italian e2s3_d67f447b:


    ji "Forse potreste mostrarci il vostro piccolo didietro, e forse vi lasceremo in pace... Giusto, ragazzi?"


translate italian e2s3_7cf02106_1:


    ji "Sì!!!"


translate italian e2s3_ffae4ead:


    s "Ragazzi, fuori... avete sentito la signora..."


translate italian e2s3_8d0a4594:


    ji "Ma, amico! È lei che flirta con noi..."


translate italian e2s3_8be1c017:


    s "Ho detto fuori!"


translate italian e2s3_f5928430:


    ji "Va bene, Capitano! Non c'è bisogno di sgridarci!!!"


translate italian e2s3_87ed5711:


    ji "E tu, non hai sentito l'ultima cosa di questo..."


translate italian e2s3_70b956e4:


    s "Mi dispiace, Julia... Questi ragazzi sono nervosi..."


translate italian e2s3_4e619f92:


    julia "SÌ..."


translate italian e2s3_d5176ae5:


    s "Non avercela con loro... E se ti danno ancora fastidio, dimmelo..."


translate italian e2s3_d1f70c04:


    julia "..."


translate italian e2s3_35115fe7:


    cha "Cosa ci fa qui?"


translate italian e2s3_9f36931f:


    julia "È venuto a prendere la sua banda... immagino che stiano andando ad allenarsi..."


translate italian e2s3_4344ba5b:


    cha "A quest'ora?"


translate italian e2s3_683a7314:


    julia "Già... hanno avuto scarsi risultati a fine stagione, quindi vogliono rifarsi..."


translate italian e2s3_7bdd87db:


    cha "Alcuni di loro potrebbero perdere la borsa di studio!"


translate italian e2s3_ff51750b:


    julia "E' possibile..."


translate italian e2s3_52b4eed6:


    cha "Quei nuovi outfit rivelano così tanto..."


translate italian e2s3_6a2ae747:


    julia "Non possiamo usare quelli più vecchi?"


translate italian e2s3_fc9ea268:


    cha "Hai sentito il capo... Dobbiamo indossarlo per attirare nuovi clienti..."


translate italian e2s3_81e60c5f:


    julia "Si ma..."


translate italian e2s3_b092efff:


    cha "Dai, andiamo..."


translate italian e2s3_51e8bb06:


    julia "Va bene..."


translate italian e2s3_1b483561:


    cha "Mi terrai aggiornata su quel misterioso sconosciuto, vero?"


translate italian e2s3_d2da4b5a:


    julia "Uhm... sì, non preoccuparti..."


translate italian e2s3_0c4885c6:


    cha "E domani sarai sola all'inizio del tuo turno! Sarò lì verso metà serata."


translate italian e2s3_aa414997:


    cha "Ho un po' di contabilità da finire prima di domani sera..."


translate italian e2s3_5713d02d:


    julia "Va bene... sarò qui..."


translate italian e2s3_d1651a03:


    cha "Ci vediamo domani!"


translate italian e2s3_6dcbeedd:


    julia "Ci vediamo."


translate italian e2s3_8c94c5fe:


    julia "Deve essere freddo ormai..."


translate italian e2s3_a116ebc2:


    julia "E il mio caffè..."


translate italian e2s3_ef9f765d:


    julia "Maledetti tacchi alti..."


translate italian e2s3_0e1e2253:


    julia "Beh, domani dovrò destreggiarmi tra le lezioni, il ristorante..."


translate italian suitejuliatel_20ab69a7:


    julia "Non mi ha mandato un messaggio..."


translate italian suitejuliatel_2a8582c3:


    julia "Dovrei mandargli un messaggio?"


translate italian suitejuliatel_5a09cb73:


    julia "Cavolo, non so nemmeno cosa fare in questi casi..."


translate italian suitejuliatel_63632687:


    julia "Sono davvero all'oscuro..."


translate italian suitejuliatel_aa8e4281:


    julia "Bene, proviamoci..."


translate italian suitejuliatel_5dcbb5c3:


    julia "CIAO !"


translate italian suitejuliatel_d247e240:


    julia "Ciao... non c'è un modo più stupido per iniziare..."


translate italian suitejuliatel_593e1a4d:


    julia "Merda, ha risposto!"


translate italian suitejuliatel_6e99c3a2:


    julia "Cosa devo fare? Cosa devo fare? Cosa devo fare?"


translate italian suitejuliatel_14b367ef:


    d "Hey ciao!"


translate italian suitejuliatel_c57e2904:


    julia "Beh... anche lui usa i cliché..."


translate italian suitejuliatel_edd120a3:


    julia "Cosa gli devo dire?... 'Come stai?' No, è una cosa noiosa..."


translate italian suitejuliatel_3d5456ee:


    julia "Hai avuto una buona giornata?"


translate italian suitejuliatel_2c0993bb:


    julia "No, non va meglio... Sembra che sia sua madre a parlare..."


translate italian suitejuliatel_3f4f3e80:


    julia "Oh mio Dio..."


translate italian suitejuliatel_3e3f740c:


    julia "Ahhh! Un altro messaggio!"


translate italian suitejuliatel_dbb0af3a:


    d "Sono stanco dalla giornata... Grazie comunque per il tour!"


translate italian suitejuliatel_bbf54d60:


    julia "Prego."


translate italian suitejuliatel_fa6876e2:


    julia "Spero di non aver dimenticato nulla."


translate italian suitejuliatel_cca72ab6:


    d "Non preoccuparti, sei stata perfetta! E se avrò bisogno di informazioni, saprò a chi chiedere!"


translate italian suitejuliatel_d6f16a8e:


    julia "Sì..."


translate italian suitejuliatel_f8f06dc3:


    d "Va bene, ti lascio dormire! Devi essere stanca di passare tutto il tempo in biblioteca..."


translate italian suitejuliatel_40340f5e:


    julia "Non puoi nemmeno immaginare..."


translate italian suitejuliatel_5769e4a9:


    d "Buonanotte, Julia."


translate italian suitejuliatel_5dfa7b90:


    julia "Buonanotte, [name]."


translate italian suitejuliatel_358c7e0e:


    julia "No, non gli interessa..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
