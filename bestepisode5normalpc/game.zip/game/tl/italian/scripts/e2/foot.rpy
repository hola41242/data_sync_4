

translate italian foot_edf3fa74:


    dpense "Nello spogliatoio è sempre la stessa routine..."


translate italian foot_77a4fd1a:


    dpense "Prima la gamba sinistra... sempre..."


translate italian foot_92ec1830:


    dpense "Poi la gamba destra... sempre..."


translate italian foot_f25f54f9:


    dpense "E dopo è il momento di concentrarsi sull'obiettivo."


translate italian foot_55095236:


    mad "Spostati!" with hpunch


translate italian foot_dd5d68f3:


    d "Eh?"


translate italian foot_1c4a0bf9:


    d "Cosa stai facendo qui?"


translate italian foot_43d53e49:


    mad "Beh, le gemelle sono arrivate nello spogliatoio delle ragazze, quindi ho bisogno di un posto tranquillo... E sembra che tu abbia trovato uno spogliatoio solo per te..."


translate italian foot_b782ec56:


    mad "Comunque..."


translate italian foot_0b9463d0:


    dpense "Sta davvero cambiandosi qui? Davanti a me?"


translate italian foot_8b891988:


    mad "Che cosa? Non hai mai visto una donna prima o qualcosa del genere?"


translate italian foot_79d25a85:


    d "Ehm... sì..."


translate italian madivestfin_ca733686:


    mad "Ti stai godendo la vista, vero?"


translate italian madivestfin_19e56d79:


    d "Beh, sei appena arrivata qui e hai iniziato a cambiarti proprio davanti ai miei occhi..."


translate italian madivestfin_86840f36:


    mad "Siamo nella stessa squadra..."


translate italian madivestfin_3d0ab973:


    mad "Quindi non ho nulla da nasconderti..."


translate italian madivestfin_9e7fc475:


    dpense "Beh, di certo non nasconde nulla adesso..."


translate italian madivestfin_e98c80dd:


    dpense "È davvero bella..."


translate italian madivestfin_97bbdea9:


    dpense "E così atletica... non vorrei giocare contro di lei..."


translate italian madivestfin_8ebf33b9:


    mad "Va bene, andiamo..."


translate italian madivestfin_b1351d09:


    mad "A proposito, chi è la bomba adesso?"


translate italian madivestfin_dd5d68f3:


    d "Eh?"


translate italian madivestfin_315b4afb:


    mad "..."


translate italian madivestfin_cc1af243:


    dpense "Ah, capisco! È stato il confronto con Ruby che l'ha fatta venire da me... È competitiva e la cosa la sta dando fastidio..."


translate italian madivestfin_f64c111a:


    dpense "Non preoccuparti, Madison... Sei tu la bomba... Su questo non ci sono dubbi..."


translate italian madivestfin_49c50de8:


    d "Andiamo..."


translate italian madivestfin_b7bc84a3:


    d "C'è una partita da vincere..."


translate italian madivestfin_d5ab1f7c:


    mad "Ok ragazze! Spero che voi siate pronte!"


translate italian madivestfin_ed845cf0:


    ruby "Sicuro !!!"


translate italian madivestfin_b7fd8669:


    mad "Sembra che le prime partite siano finite..."


translate italian madivestfin_a571c092:


    julia "Sì, Steven ha vinto la sua prima partita."


translate italian madivestfin_591e2cd8:


    grace "Sembra che anche Emerick abbia vinto."


translate italian madivestfin_acf1a1cf:


    d "Conosci la squadra avversaria?"


translate italian madivestfin_06aad2a0:


    mad "No... chi se ne frega?"


translate italian madivestfin_193370d4:


    mad "Un solo obiettivo: vincere!"


translate italian madivestfin_248a945d:


    mad "Fai come ti dico e sarà un gioco da ragazzi."


translate italian madivestfin_2ea87172:


    mad "Rimaniamo dietro e risaliamo non appena riceviamo la palla..."


translate italian madivestfin_7bcc50f4:


    d "Va bene..."


translate italian madivestfin_9a0db5cc:


    orushi "Cari partecipanti, le regole sono semplici..." with hpunch


translate italian madivestfin_7a5e14ed:


    orushi "Vince la prima squadra che segna 3 punti..."


translate italian madivestfin_95a00a65:


    orushi "Nessun portiere..."


translate italian madivestfin_69b2f6c3:


    orushi "Giocherai su metà del campo da calcio."


translate italian madivestfin_0d205797:


    orushi "Prende il via la prima squadra in ordine alfabetico."


translate italian madivestfin_b2a4838f:


    orushi "Che vinca la squadra migliore."


translate italian madivestfin_af49f050:


    d "Eccoci qui..."


translate italian madivestfin_84270059:


    dpense "Julia la carica..."


translate italian madivestfin_7889bc98:


    dpense "Che cosa ????"


translate italian madivestfin_8c16a232:


    dpense "Lei non si è trattenuta..."


translate italian madivestfin_2d685b93:


    dpense "Ok, Madison ha detto: una volta che abbiamo la palla, tu vai avanti..."


translate italian madivestfin_eee1b7c6:


    dpense "COSÌ..."


translate italian madivestfin_271b982b:


    dpense "vado avanti..."


translate italian madivestfin_9e7f43f3:


    dpense "Passa la palla a Ruby..."


translate italian madivestfin_0eb8144f:


    dpense "Bel controllo..."


translate italian madivestfin_51704437:


    dpense "Me la sta passando..."


translate italian madivestfin_b23ca261:


    dpense "È il mio turno di giocare..."


translate italian solofoot1_0582ace2:


    dpense "Destra..."


translate italian solofoot1_91496986:


    dpense "Sinistra..."


translate italian solofoot1_0582ace2_1:


    dpense "Destra..."


translate italian solofoot1_3730c4c4:


    dpense "E sinistra !!!!"


translate italian solofoot1_de6164a3:


    dpense "Forza, dobbiamo segnare il primo!"


translate italian solofoot1_b3487855:


    d "Fallo!" with hpunch


translate italian solofoot1_753e42ba:


    d "SÌ !"


translate italian solofoot1_e67fad0e:


    ruby "Ben fatto [name]!"


translate italian solofoot1_974b328e:


    orushi "0 - 1 per la squadra H..."


translate italian solofoot1_a6cdb1f6:


    orushi "Squadra H, tocca a voi ingaggiare..."


translate italian solofoot1_717cf009:


    d "Merda..."


translate italian solofoot1_c13d8579:


    d "Eh ???"


translate italian solofoot1_b2eece69:


    mad "Hyaaaaaaaa..."


translate italian solofoot1_761a446b:


    mad "SÌ !"


translate italian solofoot1_16f3fcc2:


    mad "E questo è 1!"


translate italian solofoot1_974b328e_1:


    orushi "0 - 1 per la squadra H..."


translate italian solofoot1_a6cdb1f6_1:


    orushi "Squadra H, tocca a voi ingaggiare..."


translate italian juliafoot1_47bd8943:


    d "Julia! Per te !"


translate italian juliafoot1_f832f206:


    dpense "Sta saltando ???"


translate italian juliafoot1_66f71455:


    julia "Salto !"


translate italian juliafoot1_66f71455_1:


    julia "Salto !"


translate italian juliafoot1_ce3a9306:


    dpense "È alto!"


translate italian juliafoot1_74847b12:


    dpense "Proverò una rovesciata!"


translate italian juliafoot1_a636450b:


    d "Fallo !" with hpunch


translate italian juliafoot1_753e42ba:


    d "SÌ !"


translate italian juliafoot1_e67fad0e:


    ruby "Ben fatto [name]!"


translate italian juliafoot1_974b328e:


    orushi "0 - 1 per la squadra H..."


translate italian juliafoot1_a6cdb1f6:


    orushi "Squadra H, tocca a voi impegnarvi..."


translate italian juliafoot1_6706606d:


    d "Troppo alto !!!"


translate italian juliafoot1_9d037827:


    ruby "Han!!!!"


translate italian juliafoot1_753e42ba_1:


    d "SÌ !"


translate italian juliafoot1_ec038a82:


    d "Brava Ruby!"


translate italian juliafoot1_fe9c6c78:


    ruby "Hai visto che?"


translate italian juliafoot1_974b328e_1:


    orushi "0 - 1 per la squadra H..."


translate italian juliafoot1_a6cdb1f6_1:


    orushi "Squadra H, tocca a voi impegnarvi..."


translate italian juliafoot1_c710da6e:


    mad "E questo è il primo!!!"


translate italian juliafoot1_753e42ba_2:


    d "SÌ !"


translate italian juliafoot1_4f3fd317:


    d "Brava Madison!"


translate italian juliafoot1_e84315d6:


    ruby "Sei troppo forte Maddie!"


translate italian juliafoot1_974b328e_2:


    orushi "0 - 1 per la squadra H..."


translate italian juliafoot1_a6cdb1f6_2:


    orushi "Squadra H, tocca a voi impegnarvi..."


translate italian madisonfoot1_c710da6e:


    mad "E questo è il primo!!!"


translate italian madisonfoot1_753e42ba:


    d "SÌ !"


translate italian madisonfoot1_4f3fd317:


    d "Brava Madison!"


translate italian madisonfoot1_e84315d6:


    ruby "Sei troppo forte Maddie!"


translate italian madisonfoot1_974b328e:


    orushi "0 - 1 per la squadra H..."


translate italian madisonfoot1_a6cdb1f6:


    orushi "Squadra H, tocca a voi impegnarvi..."


translate italian footpart2_8c14bc76:


    mad "È il nostro turno di impegnarci, quindi... Andiamo tutti dentro !"


translate italian footpart2_8dde1283:


    grace "Va bene !"


translate italian footpart2_7840c8ac:


    mad "Andiamo al secondo gol!!!"


translate italian footpart2_a3adb02b:


    dpense "È uno tsunami che avanza in campo..."


translate italian solofoot2_0582ace2:


    dpense "Destra..."


translate italian solofoot2_91496986:


    dpense "Sinistra..."


translate italian solofoot2_0582ace2_1:


    dpense "Destra..."


translate italian solofoot2_3730c4c4:


    dpense "E sinistra !!!!"


translate italian solofoot2_27457a03:


    dpense "Forza, dobbiamo segnare ancora!"


translate italian solofoot2_b3487855:


    d "Fallo!" with hpunch


translate italian solofoot2_753e42ba:


    d "SÌ !"


translate italian solofoot2_e67fad0e:


    ruby "Ben fatto [name]!"


translate italian solofoot2_3d5b715b:


    orushi "0 - 2 per la squadra H..."


translate italian solofoot2_3dca3269:


    orushi "Squadra D, tocca a voi impegnarvi..."


translate italian solofoot2_717cf009:


    d "Merda..."


translate italian solofoot2_c13d8579:


    d "Eh ???"


translate italian solofoot2_b2eece69:


    mad "Hyaaaaaaaa..."


translate italian solofoot2_761a446b:


    mad "SÌ !"


translate italian solofoot2_8a0891ca:


    mad "E sono 2!"


translate italian solofoot2_3d5b715b_1:


    orushi "0 - 2 per la squadra H..."


translate italian solofoot2_3dca3269_1:


    orushi "Squadra D, tocca a voi impegnarvi..."


translate italian juliafoot2_47bd8943:


    d "Julia! Per te !"


translate italian juliafoot2_f832f206:


    dpense "Sta saltando ???"


translate italian juliafoot2_66f71455:


    julia "Salto !"


translate italian juliafoot2_66f71455_1:


    julia "Salto !"


translate italian juliafoot2_ce3a9306:


    dpense "È alto!"


translate italian juliafoot2_74847b12:


    dpense "Proverò una rovesciata!"


translate italian juliafoot2_a636450b:


    d "Fallo !" with hpunch


translate italian juliafoot2_753e42ba:


    d "SÌ !"


translate italian juliafoot2_e67fad0e:


    ruby "Ben fatto [name]!"


translate italian juliafoot2_3d5b715b:


    orushi "0 - 2 per la squadra H..."


translate italian juliafoot2_3dca3269:


    orushi "Squadra D, tocca a voi impegnarvi..."


translate italian juliafoot2_6706606d:


    d "Troppo alto !!!"


translate italian juliafoot2_9d037827:


    ruby "Han!!!!"


translate italian juliafoot2_753e42ba_1:


    d "SÌ !"


translate italian juliafoot2_ec038a82:


    d "Brava Ruby!"


translate italian juliafoot2_fe9c6c78:


    ruby "Hai visto che?"


translate italian juliafoot2_3d5b715b_1:


    orushi "0 - 2 per la squadra H..."


translate italian juliafoot2_3dca3269_1:


    orushi "Squadra D, tocca a voi impegnarvi..."


translate italian juliafoot2_4fffecae:


    mad "E questo è il secondo!!!"


translate italian juliafoot2_753e42ba_2:


    d "SÌ !"


translate italian juliafoot2_4f3fd317:


    d "Brava Madison!"


translate italian juliafoot2_e84315d6:


    ruby "Sei troppo forte Maddie!"


translate italian juliafoot2_3d5b715b_2:


    orushi "0 - 2 per la squadra H..."


translate italian juliafoot2_3dca3269_2:


    orushi "Squadra D, tocca a voi impegnarvi..."


translate italian madisonfoot2_a6e1b431:


    mad "E questo è il secondo!!!"


translate italian madisonfoot2_753e42ba:


    d "SÌ !"


translate italian madisonfoot2_4f3fd317:


    d "Brava Madison!"


translate italian madisonfoot2_e84315d6:


    ruby "Sei troppo forte Maddie!"


translate italian madisonfoot2_3d5b715b:


    orushi "0 - 2 per la squadra H..."


translate italian madisonfoot2_3dca3269:


    orushi "Squadra D, tocca a voi impegnarvi..."


translate italian footpart3_d03c73aa:


    mad "E' l'ultimo..."


translate italian footpart3_8cbe0101:


    d "Sì !"


translate italian footpart3_a5e72e2d:


    mad "[name]?"


translate italian footpart3_9e4ecabd:


    d "Sì ?"


translate italian footpart3_bc560022:


    mad "Quando hai la palla..."


translate italian footpart3_fb8a0316:


    mad "Passamela!"


translate italian footpart3_7bcc50f4:


    d "Va bene..."


translate italian footpart3_bcb5c60f:


    mad "Andiamo per la vittoria!!!"


translate italian footpart3_431e2f0e:


    ruby "Sì !!!"


translate italian footpart3_d85731c5:


    d "Buon lavoro Grace!"


translate italian footpart3_5218b90d:


    dpense "Tunnel!"


translate italian footpart3_7bba1598:


    d "Super Grace!"


translate italian Supermad_633b9d24:


    mad "Mostrerò loro perché mi chiamano la tigre!"


translate italian Supermad_b707d65c:


    mad "Ciaoooooooooo!!!!"


translate italian Supermad_b0b7239e:


    mad "Vittoria !"


translate italian Supermad_013aaa82:


    orushi "0 - 3 per la squadra H..."


translate italian Supermad_94a591b5:


    orushi "Squadra D, siete eliminati..."


translate italian juliafoot3_47bd8943:


    d "Julia! Per te !"


translate italian juliafoot3_f832f206:


    dpense "Sta saltando ???"


translate italian juliafoot3_66f71455:


    julia "Salto !"


translate italian juliafoot3_66f71455_1:


    julia "Salto !"


translate italian juliafoot3_ce3a9306:


    dpense "È alto!"


translate italian juliafoot3_74847b12:


    dpense "Proverò una rovesciata!"


translate italian juliafoot3_a636450b:


    d "Fallo !" with hpunch


translate italian juliafoot3_753e42ba:


    d "SÌ !"


translate italian juliafoot3_e67fad0e:


    ruby "Ben fatto [name]!"


translate italian juliafoot3_013aaa82:


    orushi "0 - 3 per la squadra H..."


translate italian juliafoot3_94a591b5:


    orushi "Squadra D, siete eliminati..."


translate italian juliafoot3_6706606d:


    d "Troppo alto !!!"


translate italian juliafoot3_9d037827:


    ruby "Han!!!!"


translate italian juliafoot3_753e42ba_1:


    d "SÌ !"


translate italian juliafoot3_ec038a82:


    d "Bravo Ruby!"


translate italian juliafoot3_fe9c6c78:


    ruby "Hai visto che?"


translate italian juliafoot3_013aaa82_1:


    orushi "0 - 3 per la squadra H..."


translate italian juliafoot3_94a591b5_1:


    orushi "Squadra D, siete eliminati..."


translate italian juliafoot3_558b89c4:


    mad "E questo è il terzo!!!"


translate italian juliafoot3_753e42ba_2:


    d "SÌ !"


translate italian juliafoot3_4f3fd317:


    d "Brava Madison!"


translate italian juliafoot3_e84315d6:


    ruby "Sei troppo forte Maddie!"


translate italian juliafoot3_013aaa82_2:


    orushi "0 - 3 per la squadra H..."


translate italian juliafoot3_94a591b5_2:


    orushi "Squadra D, siete eliminati..."


translate italian solofoot3_0582ace2:


    dpense "Destra..."


translate italian solofoot3_91496986:


    dpense "Sinistra..."


translate italian solofoot3_0582ace2_1:


    dpense "Destra..."


translate italian solofoot3_3730c4c4:


    dpense "E sinistra !!!!"


translate italian solofoot3_27457a03:


    dpense "Forza, dobbiamo segnare ancora!"


translate italian solofoot3_b3487855:


    d "Fallo!" with hpunch


translate italian solofoot3_753e42ba:


    d "SÌ !"


translate italian solofoot3_e67fad0e:


    ruby "Ben fatto [name]!"


translate italian solofoot3_013aaa82:


    orushi "0 - 3 per la squadra H..."


translate italian solofoot3_94a591b5:


    orushi "Squadra D, siete eliminati..."


translate italian solofoot3_717cf009:


    d "Merda..."


translate italian solofoot3_c13d8579:


    d "Eh ???"


translate italian solofoot3_b2eece69:


    mad "Hyaaaaaaaa..."


translate italian solofoot3_761a446b:


    mad "SÌ !"


translate italian solofoot3_c114d736:


    mad "E sono 3!"


translate italian solofoot3_013aaa82_1:


    orushi "0 - 3 per la squadra H..."


translate italian solofoot3_94a591b5_1:


    orushi "Squadra D, siete eliminati..."


translate italian rubyfoot3_0eb8144f:


    dpense "Bel controllo..."


translate italian rubyfoot3_51704437:


    dpense "Me la sta passando..."


translate italian rubyfoot3_671485ee:


    d "E questo è per il terzo gol!!!" with hpunch


translate italian rubyfoot3_013aaa82:


    orushi "0 - 3 per la squadra H..."


translate italian rubyfoot3_94a591b5:


    orushi "Squadra D, siete eliminati..."


translate italian finfoot1_6ad6f3b2:


    ruby "Siamo i vincitori!!!"


translate italian finfoot1_2ab5c4c9:


    ruby "Ahahahahah!"


translate italian finfoot1_44bcfc57:


    ruby "Sono così orgoglioso di te..."


translate italian finfoot1_c4e84b13:


    ruby "Anche se non hai segnato nessun goal!"


translate italian finfoot1_b7adf193:


    grace "Segna anche un gol!"


translate italian finfoot1_7e3496d9:


    julia "E altro ancora..."


translate italian finfoot1_6468fcae:


    orushi "Bene, questa è la fine di questa partita..."


translate italian finfoot1_e26c5fd2:


    orushi "Il miglior marcatore è:"


translate italian finfoot1_58254362:


    orushi "Studente [name]!"


translate italian finfoot1_ecde1b4d:


    orushi "Studente Madison!"


translate italian finfoot1_6f88b953:


    orushi "La prossima partita si svolgerà lunedì..."


translate italian finfoot1_ec91a1bf:


    orushi "Fino ad allora... Siete liberi..."


translate italian finfoot1_3d52e4e0:


    orushi "Fine della trasmissione..."


translate italian finfoot1_602db608:


    dpense "Una buona cosa fatta..."


translate italian finfoot1_5b12d403:


    dpense "È stata una partita facile e le ragazze sono state fantastiche..."


translate italian finfoot1_4e366d50:


    dpense "I passaggi di Grace, il gioco di gambe di Julia, i colpi di Madison... non avevo quasi niente da fare."


translate italian finfoot1_9fea8065:


    dpense "La prossima partita sarà sicuramente più impegnativa..."


translate italian finfoot1_f6727475:


    dpense "Nel frattempo torniamo negli spogliatoi..."


translate italian finfoot1_04e96e05:


    grace "[name] !!!"


translate italian finfoot1_7a2450db:


    grace "[name] aspetta!!!"


translate italian finfoot1_66d23871:


    d "Uhm?"


translate italian finfoot1_b4ae2579:


    grace "Sei stato fantastico oggi..."


translate italian finfoot1_6066fac0:


    grace "Tra la sfida della scelta..."


translate italian finfoot1_c8e72772:


    d "Non ho fatto molto; è stata soprattutto Blue ad aiutarmi... Sapeva dov'era l'ultima palla..."


translate italian finfoot1_e74e7001:


    d "Non so come, ma qualcosa mi dice che sua sorella non è estranea a tutto questo..."


translate italian finfoot1_0dceca55:


    grace "OH..."


translate italian finfoot1_b6e71a4b:


    grace "Sei vicino a Blue..."


translate italian finfoot1_4d01480f:


    grace "La piscina, e ora questo..."


translate italian finfoot1_7407154a:


    d "Non ho fatto molto; è stata soprattutto Ruby ad aiutarmi."


translate italian gracekiss_3852d8e4:


    grace "Per favore chiudi gli occhi!"


translate italian gracekiss_dd5d68f3:


    d "Eh?"


translate italian gracekiss_c6e0575b:


    grace "Chiudi gli occhi..."


translate italian gracekiss_7bcc50f4:


    d "Va bene..."


translate italian gracekiss_92b2ae06:


    grace "C'è qualcosa che vorrei fare, ma non ho il coraggio..."


translate italian gracekiss_92268307:


    d "Vai avanti, fallo!"


translate italian gracekiss_c1f4c969:


    d "Non dovremmo..."


translate italian gracekiss2_47a2537c:


    grace "Sarà più facile se avrai gli occhi chiusi..."


translate italian gracekiss2_7c99e43d:


    d "Se lo dici tu..."


translate italian gracekiss2_f091ef9d:


    grace "Da quando sei arrivato, Ruby è stata felice..."


translate italian gracekiss2_6260bdfe:


    grace "Julia ha già cambiato pettinatura tre volte..."


translate italian gracekiss2_a0646cad:


    grace "Anche Madison è più... piacevole..."


translate italian gracekiss2_f338cc08:


    d "Ehm..."


translate italian gracekiss2_546e33a9:


    grace "Shh..."


translate italian gracekiss2_bdf56354:


    grace "Sei stato un gentiluomo a casa mia..."


translate italian gracekiss2_b96a1cba:


    grace "Sono felice che ci siamo incontrati..."


translate italian gracekiss2_bd4d4f9e:


    grace "E come risultato..."


translate italian gracekiss2_13938477:


    d "Mi hai appena baciato..."


translate italian gracekiss2_1c603af5:


    grace "Sì... ed è stato fantastico..."


translate italian gracekiss2_1f9ac873:


    grace "Sono così felice !!! Non avrei mai pensato di poterlo fare..."


translate italian gracekiss2_6413d69a:


    d "Sai che volevo farlo da quando ti ho visto?"


translate italian gracekiss2_e287c813:


    grace "OH ?"


translate italian gracekiss2_6bb9c921:


    grace "Ora puoi farlo quando vuoi..."


translate italian gracekiss2_95aeacb1:


    d "In quel caso..."


translate italian gracekiss2_cd952255:


    dpense "Posso sentire il suo cuore battere così forte..."


translate italian gracekiss2_59e2f283:


    dpense "Non preoccuparti, Grace, mi prenderò cura di te..."


translate italian gracekiss2_50c94879:


    dpense "Sei la donna più bella che abbia mai incontrato..."


translate italian gracekiss2_e81a6af4:


    dpense "E pensi così tanto agli altri che ti dimentichi di te stesso..."


translate italian gracekiss2_eaf4b947:


    dpense "Sarò lì per te..."


translate italian gracekiss2_aa15d993:


    grace "È stato... inaspettato..."


translate italian gracekiss2_06891b96:


    grace "Ma anche molto piacevole!"


translate italian gracekiss2_ac69ed09:


    grace "Devo andare... Ci vediamo domani? In classe ?"


translate italian gracekiss2_729e449c:


    d "Sì ! Sicuro !"


translate italian gracekiss2_75e8238f:


    grace "OH ! Non dimenticare la mia festa di domani!"


translate italian gracekiss2_93c9e4c4:


    d "Non preoccuparti ! Non lo farò!"


translate italian gracekiss2_27aa1aac:


    dpense "Non posso credere di essere con questa dea..."


translate italian gracekiss2_3161a1f9:


    dpense "Quanto sono fortunato..."


translate italian gracekiss2_b1ca8c29:


    dpense "Bene... Torniamo allo spogliatoio..."


translate italian gracekiss2_f738d3eb:


    beth "Merda..."


translate italian graceleave_42f3466f:


    grace "Ohhh... Hummm... dovrei uscire, ho delle commissioni da fare per la festa di domani..."


translate italian graceleave_f0404ad6:


    grace "Ci vediamo a lezione domattina!"


translate italian graceleave_32a25851:


    d "Oh ok ! Ci vediamo domani !"


translate italian graceleave_9ab62b43:


    beth "Buon lavoro sorella..."


translate italian vestiairesfinep21_78c32f4b:


    d "Accidenti, glielo abbiamo davvero mostrato!"


translate italian vestiairesfinep21_50a8bffb:


    d "E voi ragazze siete state davvero fantastiche!"


translate italian vestiairesfinep21_9686d4b0:


    mad "Mah..."


translate italian vestiairesfinep21_92a2ff53:


    d "Ma sul serio... Non mi avevi detto che eri così bravo!"


translate italian vestiairesfinep21_c8be3d53:


    mad "Era un gioco... Beh, non lo definirei nemmeno un gioco, in realtà..."


translate italian vestiairesfinep21_8fb1935d:


    mad "La prossima volta sarà completamente diverso..."


translate italian vestiairesfinep21_4775cd63:


    d "Già, ma non possiamo festeggiare comunque?"


translate italian vestiairesfinep21_e7a937db:


    mad "Vai avanti, sii mio ospite!"


translate italian madinocalin_60533d2e:


    mad "Eh??? Cosa stai facendo qui?"


translate italian madinocalin_ce1c3eb9:


    d "Beh, una festa!"


translate italian madinocalin_8a203556:


    mad "Sì, sì... ci vediamo più tardi..."


translate italian madinocalin_8b684304:


    d "EHI !!!"


translate italian madinocalin_20da34d0:


    d "Non è facile con lei..."


translate italian madicalin_60533d2e:


    mad "Eh??? Cosa stai facendo qui?"


translate italian madicalin_c4470e54:


    d "Bene, una festa di squadra?"


translate italian madicalin_750fd072:


    mad "E hai bisogno di attaccarti a me in quel modo?"


translate italian madicalin_465fafd7:


    d "Lascia andare per una volta... Madison..."


translate italian madicalin_5e6bf0de:


    mad "No, scusa... preferirei andarmene prima che arrivi una delle gemelle e mi suggerisca qualcosa che coinvolga più persone..."


translate italian madicalin_29ac5843:


    d "Che cosa?"


translate italian madicalin_ab00b208:


    mad "Sì, sì... A più tardi..."


translate italian madicalin_20da34d0:


    d "Non è facile con lei..."


translate italian madicalin_c181cb06:


    mad "Non posso lasciar andare come voglio, [name]..."


translate italian madicalin_de693696:


    mad "La mia vita è un tale caos che non posso permettere a niente e nessuno di entrarci in questo momento..."


translate italian madicalin_5bc827e8:


    mad "Ho mia figlia, i miei studi, la competizione... Niente potrà disturbare il mio..."


translate italian madicalin_b8eee199:


    d "Non sei solo..."


translate italian madicalin_f741ec0e:


    d "E non intendo sconvolgere la tua vita..."


translate italian madicalin_94ca423a:


    d "Ma posso migliorarlo..."


translate italian madicalin_c17d8f33:


    mad "SÌ..."


translate italian madicalin_fdaf3f91:


    mad "NO..."


translate italian madicalin_c5fd0efd:


    mad "IO..."


translate italian madicalin_c03bb58e:


    mad "Non posso..."


translate italian madicalin_7bcf0972:


    d "Non preoccuparti..."


translate italian madicalin_090f161d:


    d "Abbiamo tempo..."


translate italian madicalin_81715ab7:


    mad "Scusa..."


translate italian madicalin_19ce0e7d:


    d "Va bene, vado a farmi la doccia... Ci vediamo dopo?"


translate italian madicalin_81d27177:


    mad "Hmm? Oh, sì, certo..."


translate italian madicalin_11ca4429:


    mad "Oh, al diavolo!"


translate italian finmadi1_c822e579:


    d "No... è uno scherzo?"


translate italian finmadi1_6ff07c76:


    mad "Shh! Ascolta, ho avuto una mattinata stressante e, dopo tutto questo, io..."


translate italian finmadi1_6693d960:


    mad "Ho bisogno di scaricare un po' di tensione..."


translate italian finmadi1_0d3b5304:


    mad "Sai cosa voglio dire?"


translate italian finmadi1_b615c5d1:


    mad "Quindi hai una scelta, o me ne vado, e finiamo qui..."


translate italian finmadi1_2673ba73:


    mad "Oppure ci divertiamo un po' insieme... Tu ed io..."


translate italian finmadi1_810f749f:


    mad "E ovviamente... Nessuno deve sapere nulla di questo... E questo non accadrà più..."


translate italian finmadi2_9f8bc5ee:


    mad "COSÌ ?"


translate italian madifin3_b270a0dd:


    mad "Che delusione..."


translate italian madifinep2_2f645723:


    mad "Non perdere tempo..."


translate italian madifinep2_078053e8:


    mad "Ehm? Sei già pronto per partire, bello!"


translate italian madifinep2_b95efa92:


    d "IO..."


translate italian madifinep2_f4645ac0:


    mad "Shhhh..."


translate italian madifin4_d89d51b4:


    mad "Vai avanti [name]! Mostrami cosa sai fare!"


translate italian madifin4_32d6db02:


    dpense "Questa ragazza..."


translate italian madifin4_6c713e31:


    mad "E provaci! Non sono fatto di zucchero!"


translate italian madifin4_927f3cd3:


    dpense "Wah... è stretta!"


translate italian madifin4_49060b46:


    dpense "E bagnato da morire!"


translate italian madifin4_3d93f24b:


    mad "Vai avanti [name]! Più forte !"


translate italian madifin4_c17d8f33:


    mad "SÌ..."


translate italian madifin4_416ec5fe:


    mad "Più profondo..."


translate italian madifin4_acad3ae3:


    mad "Uhm..."


translate italian madifin4_9e1bdebf:


    mad "Così... Continua..."


translate italian madifin4_f1befcce:


    mad "Hum... Non sei davvero male..."


translate italian madifin4_17fb853f:


    mad "E se mi mostrassi le tue capacità atletiche?"


translate italian madifin4_3e6ca67f:


    d "Come ?"


translate italian madifin4_422353fa:


    mad "Reggimi !"


translate italian madifin4_bab45b3d:


    mad "Oh cazzo... Sì!!!"


translate italian madifin4_1777b9bc:


    dpense "Quella figa... mi succhia sempre di più..."


translate italian madifin4_83b4bb13:


    mad "Ancora [name]... Che bello!!!"


translate italian madifin4_1684842c:


    dpense "Sta tremando..."


translate italian madifin4_2c3d8a59:


    mad "Oh mio Dio... sono molto vicino a..."


translate italian madifin4_25f65b46:


    dpense "Non sono molto indietro..."


translate italian madifin4_4a3e4891:


    mad "Humpfff... Continua [name] !"


translate italian madifin4_acb8f6a1:


    mad "Non osare fermarti adesso!"


translate italian madifin4_245419c3:


    mad "Ancora ! SÌ ! Ancora !"


translate italian madifin4_79ea7920:


    mad "Voglio di più ! Voglio..."


translate italian madifin4_f56eba72:


    mad "Ahhhhhhh!"


translate italian madifin4_01a01d80:


    mad "Sììììììììììììììììììììì!"


translate italian madifin4_4a3f086d:


    mad "Oh cazzo... [name]!"


translate italian madifin4_b1bb593b:


    mad "Tu... Humpff..."


translate italian madifin4_ebf39002:


    mad "Io... Fshhhhh..."


translate italian madifin4_00957e17:


    d "Muto ?"


translate italian madifin4_afde25b0:


    mad "Shhh!!!"


translate italian madifin4_ebaedda5:


    mad "Non hai finito?"


translate italian madifin4_30073e1f:


    d "NO..."


translate italian madifin4_e95eef45:


    mad "Va bene..."


translate italian madifin4_65a9f185:


    mad "Fallo sulle mie tette..."


translate italian madifin4_2461ad76:


    mad "Andiamo... Rilascia il tuo carico caldo sulle mie tette!"


translate italian madifin4_2c536cc9:


    d "Fanculo..."


translate italian madifin4_a0f73616:


    mad "Wow... che carico..."


translate italian madifin4_1789fa85:


    mad "Erkk..."


translate italian madifin4_9f65972f:


    mad "Dovrei andare a lavarlo..."


translate italian madifin4_4d84113c:


    d "Puoi farmi la doccia... ho finito..."


translate italian madifin4_c7ec2d67:


    mad "No... odora... di sesso..."


translate italian madifin5_2c0f470e:


    mad "Grazie [name]..."


translate italian madifin5_eec57c4e:


    d "Hummm... Prego?"


translate italian madifin5_d3fe6a33:


    mad "Oh e..."


translate italian madifin5_08958e67:


    mad "Naturalmente... Questa è una cosa da fare una volta sola!"


translate italian madifin5_bb54c687:


    mad "Non farti venire idee..."


translate italian madifin5_595996da:


    d "Ovviamente..."


translate italian chambrefinep2_98fa4014:


    d "Un messaggio ?"


translate italian chambrefinep2_084c58a1:


    d "Non resta che aspettare..."


translate italian chambrefinep2_9ddb6277:


    eli "Mi vedi ?"


translate italian chambrefinep2_753e42ba:


    d "SÌ !"


translate italian chambrefinep2_d3d73219:


    eli "Bene !"


translate italian chambrefinep2_d4678439:


    eli "È così bello vederti!"


translate italian chambrefinep2_887162e1:


    d "Haha... anch'io non sono cambiato da una settimana, lo sai!"


translate italian chambrefinep2_92bc22ab:


    eli "Ma mi mancano le nostre chiamate!"


translate italian chambrefinep2_76cbae2d:


    d "Bene sì..."


translate italian chambrefinep2_fa662e80:


    eli "Allora, come va in America?"


translate italian chambrefinep2_c28f2eeb:


    dpense "Le racconto tutto dell'Accademia e del BEST Tutto quello che è successo dall'inizio."


translate italian chambrefinep2_7f489c26:


    eli "Wahhh.... Che storia!"


translate italian chambrefinep2_2c010a8b:


    eli "Aspetta un attimo, mi metto a letto!"


translate italian chambrefinep2_1c33c8d8:


    eli "Hai conosciuto qualche ragazza?"


translate italian chambrefinep2_19b0c6a9:


    d "Ho conosciuto delle ragazze sull'aereo..."


translate italian chambrefinep2_84caaeb8:


    d "Ne ho palpato una... Julia... non so perché ma quando era davanti a me... La mia mano era attratta dal suo sedere..."


translate italian chambrefinep2_7be37bab:


    d "Il primo giorno le gemelle mi hanno parlato... Una è Blu e l'altra è Rosso..."


translate italian chambrefinep2_7f66895f:


    d "Quello blu ha cercato di impressionarmi..."


translate italian chambrefinep2_37ba556f:


    d "Quello Rosso ha provato a sfidarmi..."


translate italian chambrefinep2_f25609de:


    d "Poi ho fatto la prima prova del BEST con:"


translate italian chambrefinep2_474f9baa:


    d "Ruby..."


translate italian chambrefinep2_dd120e78:


    d "Julia..."


translate italian chambrefinep2_b59160c0:


    d "Grace..."


translate italian chambrefinep2_362c6bb7:


    d "Madison..."


translate italian chambrefinep2_1e1a4d94:


    d "È stato un percorso a ostacoli nel lavoro di squadra..."


translate italian chambrefinep2_05518b79:


    d "Ho quasi vinto la sfida..."


translate italian chambrefinep2_d5d4cd8f:


    d "Durante la mia doccia nello spogliatoio... La gemella Blu è venuta e mi ha fatto un pompino come ricompensa..."


translate italian elisechoix1_3f8b2dfe:


    eli "NO !!!! Sei serio ???"


translate italian elisechoix1_fb0ebc6a:


    d "Sì ! Avevo appena finito di farmi la doccia quando è arrivata!"


translate italian elisechoix1_4cf39263:


    eli "Che troia!"


translate italian elisechoix1_1be7b02e:


    d "Ehm... Sì e no..."


translate italian elisechoix1_9e7b4d66:


    eli "OH ?"


translate italian elisechoix1_d109ff97:


    d "Sì... penso che voglia aiutarmi durante la competizione..."


translate italian elisechoix1_338d1bf8:


    d "Non so perché, ma..."


translate italian elisechoix1_dd3f6e7e:


    d "Durante la mia doccia nello spogliatoio... La gemella Rossa è arrivata ed era fottutamente focosa nel provare un bacio alla francese..."


translate italian elisechoix1_f80dcac7:


    eli "NO !!!! Stai scherzando ???"


translate italian elisechoix1_fb0ebc6a_1:


    d "Sì ! Avevo appena finito di farmi la doccia quando è arrivata!"


translate italian elisechoix1_4cf39263_1:


    eli "Che troia!"


translate italian elisechoix1_1be7b02e_1:


    d "Ehm... Sì e no..."


translate italian elisechoix1_9e7b4d66_1:


    eli "OH ?"


translate italian elisechoix1_800edf68:


    d "Sì... penso che voglia dominarmi durante la competizione..."


translate italian elisechoix1_495acc95:


    d "Per avere un vantaggio o qualcosa del genere..."


translate italian elisechoix1_5d359f5f:


    d "Poi sono andato al parco con le ragazze..."


translate italian elisechoix1_91070114:


    d "Mi hanno chiesto chi fosse il mio preferito tra loro..."


translate italian elisechoix1_42f94226:


    d "Conosci le chiacchiere tra ragazze come al solito..."


translate italian elisechoix1_f55bccd2:


    d "Quindi ho detto loro che [chosen] è il mio preferito..."


translate italian elisechoix1_3bcb4400:


    eli "OH ! Cosa ha detto ?"


translate italian elisechoix1_fbda1389:


    d "Lei era felice..."


translate italian elisechoix1_4f9791c5:


    d "Ho detto loro che ho un debole per le MILF..."


translate italian elisechoix1_c4db2015:


    eli "Wow wow wow... Come sei arrivato a questo tipo di discussione?"


translate italian elisechoix1_2e3da88b:


    d "Bene, Ruby ci ha organizzato una conferenza sulle Visual Novels..."


translate italian elisechoix1_79eea45f:


    eli "Che cosa ?"


translate italian elisechoix1_54910736:


    d "Sì... No... Beh... L'argomento riguardava i gusti dei giocatori e lei ha detto qualcosa sulle MILF..."


translate italian elisechoix1_3ffd0020:


    eli "Uhm... va bene..."


translate italian elisechoix1_ecd08031:


    d "Poi hanno parlato della loro insegnante che è una donna molto bella ma sembra che sia sola... o qualcosa del genere..."


translate italian elisechoix1_49a107c8:


    d "E hanno deciso che sarà lei la mia MILF..."


translate italian elisechoix1_8ea2ff1f:


    eli "Sono pazzi?"


translate italian elisechoix1_22f739b2:


    d "Si un pò..."


translate italian elisechoix1_2c7d82fe:


    d "Poi in piscina ho conosciuto Gabriella...L'insegnante..."


translate italian elisechoix1_8098008c:


    d "E ho incontrato la gemella Blu e le ho fatto una sorta di introduzione alla dominazione..."


translate italian elisechoix2_1bcb5e64:


    eli "Stai scherzando ?"


translate italian elisechoix2_aa10cf4e:


    d "NO ! Lo giuro ! Le avevo promesso che l'avrei fatta squirtare e..."


translate italian elisechoix2_33642f58:


    eli "L'hai fatto???"


translate italian elisechoix2_f7ccf4f5:


    d "SÌ ! Solo con le dita!"


translate italian elisechoix2_21ea0582:


    eli "Ohhh...."


translate italian elisechoix2_f3ed2fab:


    d "Le è piaciuto e penso che adesso le piaccio perché ha cercato di aiutarmi durante l'ultima prova..."


translate italian elisechoix2_fb014fc8:


    eli "Va bene..."


translate italian elisechoix2_709280ee:


    d "Ho vinto una gara in piscina contro Grace... Adesso mi deve un favore..."


translate italian elisechoix2_a1807d52:


    d "Ho perso una gara in piscina contro Grace... Adesso le devo un favore..."


translate italian elisechoix2_0facb3c9:


    d "Ruby mi ha chiesto se mi piace Julia così le ho detto che è una ragazza interessante..."


translate italian elisechoix2_deca89d1:


    d "Poi ieri sera ho ricevuto alcuni messaggi da Julia e penso che andiamo davvero d'accordo..."


translate italian elisechoix2_9b985cdd:


    d "Anche oggi è stata dura..."


translate italian elisechoix2_5ae3d40d:


    d "Ero in squadra con Ruby, Madison, Julia e Grace..."


translate italian elisechoix2_2dfaa29b:


    d "E dovevamo giocare una partita di calcio..."


translate italian elisechoix2_a5b05574:


    d "Ma prima c'era un gioco per sapere quale squadra parteciperà e quale no..."


translate italian elisechoix2_703a2543:


    d "Ho ascoltato il consiglio di Blu e ho vinto la partita... le devo un favore..."


translate italian elisechoix2_18693a93:


    d "Ho ascoltato il consiglio di Ruby e ho vinto la partita..."


translate italian elisechoix2_9dbeee40:


    d "Poi abbiamo giocato la partita..."


translate italian elisechoix2_2554cdce:


    d "Abbiamo vinto 3-0..."


translate italian elisechoix2_f23ee1c6:


    eli "OH ! Congratulazioni!"


translate italian elisechoix2_11e5e078:


    d "È stata una partita facile..."


translate italian elisechoix2_dae60f7e:


    d "Non so chi saranno i nostri prossimi avversari..."


translate italian elisechoix2_70a656e9:


    d "Dopo il match Grace è venuta da me e ci siamo baciati..."


translate italian elisechoix2_3dfc3e36:


    d "È stato fantastico..."


translate italian elisechoix2_5c8d2710:


    eli "Qualcuno è già innamorato?"


translate italian elisechoix2_0f25a809:


    d "No... Ma... È fantastica..."


translate italian elisechoix2_7d68cce8:


    d "Sotto la doccia Madison era emozionata dopo la partita e... E, per alleviare un po' lo stress..."


translate italian elisechoix4_23afa93c:


    d "Mi ha chiesto di scoparla..."


translate italian elisechoix4_1fb9e0ec:


    eli "Nooooooooo!"


translate italian elisechoix4_30f1c327:


    d "Sì... è stato fantastico, ma ha detto che sarebbe stata una cosa che avveniva una sola volta, quindi..."


translate italian elisechoix4_b4755b6b:


    eli "Hummm... Era brava quanto me?"


translate italian elisechoix4_cec9ca0d:


    d "Era... diverso... Non preoccuparti, non ti ho dimenticato!"


translate italian elisechoix4_11fe92e0:


    eli "Oh mio Dio... sei lì da 4 giorni e stai già scherzando con un sacco di ragazze..."


translate italian elisechoix4_fc6dea88:


    d "Sì..."


translate italian elisechoix4_3b9f9c32:


    eli "Stai attento Casanova... Altrimenti finirà male..."


translate italian elisechoix4_a04fa141:


    d "Non preoccuparti! Ci penso io!"


translate italian elisechoix4_8f00470f:


    eli "Sì sì... Ogni volta che lo dici... Era peggio..."


translate italian elisechoix4_dc91fc7c:


    eli "Beh... qui sono le 23, quindi ho bisogno di dormire un po'..."


translate italian elisechoix4_8f59a387:


    eli "Mi manchi amico mio..."


translate italian elisechoix4_ecbb90b9:


    d "Mi manchi anche tu..."


translate italian elisechoix4_a5d0bb79:


    eli "Ti chiamo presto!"


translate italian elisechoix4_07f26224:


    d "Sto aspettando la tua chiamata!"


translate italian elisechoix4_1f9b6d8c:


    eli "Ci vediamo ! Bacio !"


translate italian elisechoix4_1680b1bf:


    d "Buonanotte Elisa..."


translate italian finep2_4c9fc634:


    emerick "Voglio che tu ti prenda cura di lui..."


translate italian finep2_a202e2f9:


    ji "Non preoccupatevi... lascerà quel campo in barella..."


translate italian finep2_27c03ada:


    sofia "Oh no..."


translate italian finep2_1cfb8569:


    sofia "[name]..."

translate italian strings:


    old "Play solo [TEMP1!t]"
    new "Gioca da solo [TEMP1!t]"


    old "Pass it to Julia [TEMP2!t]"
    new "Passalo a Julia [TEMP2!t]"


    old "Pass it to Madison [TEMP3!t]"
    new "Passalo a Madison [TEMP3!t]"


    old "Play with Madison [TEMP1!t]"
    new "Gioca con Madison [TEMP1!t]"


    old "Play with Julia [TEMP2!t]"
    new "Gioca con Julia [TEMP2!t]"


    old "Play solo [TEMP3!t]"
    new "Gioca da solo [TEMP3!t]"


    old "Play with Ruby [TEMP4!t]"
    new "Gioca con Ruby [TEMP4!t]"


    old "You mean more to me [TEMP1!t]"
    new "Tu significhi di più per me [TEMP1!t]"


    old "I like her, yes... [TEMP2!t]"
    new "Mi piace, sì... [TEMP2!t]"


    old "Let her continue [TEMP1!t]"
    new "Lasciala continuare [TEMP1!t]"


    old "Give her a hug [TEMP1!t]"
    new "Dalle un abbraccio [TEMP1!t]"


    old "Leave her alone [TEMP2!t]"
    new "Lasciala in pace [TEMP2!t]"


    old "Accept [TEMP1!t]"
    new "Accetta [TEMP1!t]"


    old "Ahah ! So funny !"
    new "Ah ah ! Così divertente !"


    old ":) So how are you ?"
    new ":) Allora, come stai ?"


    old "Oh wait I will call you !"
    new "Oh aspetta, ti chiamo!"


    old "?"
    new "?"


















translate italian elisechoix1_7f7c490c:


    d "Ho detto loro che ho una fissazione per le MILF..."


translate italian elisechoix1_6e07921b:


    d "Bene, Ruby ci ha fornito le regole delle Visual Novel..."


translate italian elisechoix2_4985cd2f:


    d "Poi abbiamo giocato la partita..."


translate italian elisechoix4_5cd3c30f:


    eli "Sì sì... Ogni volta che dici così... Era peggio..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
