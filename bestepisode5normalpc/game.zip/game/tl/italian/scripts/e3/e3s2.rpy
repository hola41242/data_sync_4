


translate italian e3s2_1127c8b7:


    dpense "Questa città è abbastanza grande, in realtà."


translate italian e3s2_921070ae:


    dpense "Potrei facilmente perdermi."


translate italian e3s2_af8cb32c:


    dpense "Comincio ad avere una certa fame..."


translate italian e3s2_628dd100:


    d "Fanculo!!!"


translate italian e3s2_8c797edf:


    ji "[name]!"


translate italian e3s2_9a5a998a:


    ji "Attento! Avrei potuto investirti!"


translate italian e3s2_141331e8:


    d "Gabriella?"


translate italian e3s2_6ad75cf1:


    gaby "SÌ?"


translate italian e3s2_e3f41e12:


    d "Quando ho detto che dovresti essere orgoglioso del tuo corpo.."


translate italian e3s2_154ba855:


    gaby "Cosa stai insinuando?"


translate italian e3s2_360b7017:


    d "Oh, non è niente..."


translate italian e3s2_3b4d6953:


    gaby "Cosa ti porta qui tutto solo?"


translate italian e3s2_c9a1e7db:


    d "Beh, stavo andando a casa..."


translate italian e3s2_e1a3f444:


    d "ma ho iniziato ad avere molta fame, quindi stavo cercando un posto dove prendere qualcosa da mangiare."


translate italian e3s2_bf70937f:


    gaby "Oh... umm, c'è un'incantevole gelateria dietro l'angolo e servono cibo."


translate italian e3s2_fd5a6c65:


    d "E tu?"


translate italian e3s2_7e55ce1d:


    gaby "Cosa intendi con me?"


translate italian e3s2_a948d4c0:


    d "Dove sei diretta così?"


translate italian e3s2_808c3229:


    gaby "OH! Beh, devo incontrare degli amici al pub un po' più giù."


translate italian e3s2_a03f3ec8:


    gaby "Prendere una boccata d'aria fresca. Sto cercando di schiarirmi la mente."


translate italian e3s2_cfca72a0:


    d "E divertirci?"


translate italian e3s2_ea659a8f:


    gaby "Cosa stai suggerendo?"


translate italian e3s2_e083016a:


    d "Spesso sembri così seria. Dovresti divertirti di più."


translate italian e3s2_0a9cfc2b:


    d "Ancora una volta, signora, con tutto il rispetto, ha tutta la vita davanti a sé."


translate italian e3s2_40639949:


    d "Dovresti apprezzarlo e permetterti di vivere un po'."


translate italian e3s2_edb73cb4:


    gaby "Più facile a dirsi che a farsi!"


translate italian e3s2_1dd96015:


    d "Forse potrei essere d'aiuto."


translate italian e3s2_66b194e0:


    gaby "Scusami?"


translate italian e3s2_db8727cf:


    d "No, voglio dire... se mai avessi voglia di sperimentare qualcosa di nuovo, di uscire, di esplorare..."


translate italian e3s2_09fdfeb6:


    d "Potresti farmelo sapere e sarei più che disposto ad accompagnarti!"


translate italian e3s2_854ec0fe:


    gaby "Ci penserò un po'."


translate italian e3s2_40e6a329:


    gaby "Beh, non dovrei far aspettare i miei amici..."


translate italian e3s2_c5662bab:


    gaby "Troverai la tua strada?"


translate italian e3s2_17918988:


    d "Hai detto che è alla fine di questa strada, giusto? Dietro l'angolo?"


translate italian e3s2_f9ad3300:


    gaby "Sì, è corretto."


translate italian e3s2_b457e59a:


    d "Bene allora andrò da quella parte e vedrò se trovo quella gelateria."


translate italian e3s2_7fd3646a:


    gaby "Hmm... Non conosci la città, vero?"


translate italian e3s2_33aadc58:


    gaby "Ecco, prendi il mio numero. Se mai dovessi avere dei problemi, non esitare a chiamarmi."


translate italian e3s2_9ea04bdb:


    gaby "Solo in caso di emergenza, va bene?"


translate italian e3s2_a5966752:


    d "Uh, sì... capisco."


translate italian e3s2_9cd3569b:


    gaby "Oh, comunque, non darlo a nessuno..."


translate italian e3s2_6fc56de8:


    gaby "Mi fido di te."


translate italian e3s2_a611fd9b:


    d "È una promessa."


translate italian e3s2_2d1a777c:


    gaby "Va bene, buona serata, [name]."


translate italian e3s2_fca7b125:


    dpense "Anche a te, Gabriella."


translate italian e3s2_0b836494:


    dpense "Eccellente! Ho il numero dell'insegnante!!!"


translate italian e3s2_a9dbaa79:


    dpense "Ahahaha!"


translate italian e3s2_0e9f075b:


    dpense "Se solo Ruby lo sapesse."


translate italian e3s2_6f01d825:


    dpense "Va bene, ora andiamo all'angolo della strada..."


translate italian e3s2_4d58dae6:


    hec "Hey ragazzi! Il capo è fuori!"


translate italian e3s2_fb38d61b:


    hec "Vuoi cenare e correre? Darà una lezione a quell'idiota..."


translate italian e3s2_32390969:


    "Sì!"


translate italian e3s2_ff71161a:


    julia "EHI!!!"


translate italian e3s2_3db33b00:


    julia "Torna qui! Devi pagare!"


translate italian e3s2_f24da56c:


    hec "Lasciami andare, Pinkie!"


translate italian e3s2_18c56c61:


    hec "Avrai ciò che meriti!"


translate italian e3s2_4987099d:


    hec "Che cosa?"


translate italian e3s2_3cacebcc:


    d "Cos'hai che non va? Attaccare una donna in quel modo?"


translate italian e3s2_49e8c780:


    hec "Lasciami andare! Non sono affari tuoi!"


translate italian e3s2_ed275116:


    d "Lei è mia amica, quindi sono affari miei."


translate italian e3s2_2ac61999:


    hec "E cosa hai intenzione di fare, eh? Non l'ho toccata. Se mi colpisci ci saranno dei testimoni. Se finisci nei guai con la polizia..."


translate italian e3s2_3e77ba36:


    hec "Puoi dire addio all'università. Francese."


translate italian e3s2_fbe4d78d:


    julia "Lascia perdere, [name]... Non ne vale la pena."


translate italian e3s2_7896dad8:


    hec "Giusto. Ci vedremo sul campo, idioti."


translate italian e3s2_67b527e6:


    hec "E poi vedremo chi picchierà più forte."


translate italian e3s2_f9c7f0b0:


    d "Stai bene?"


translate italian e3s2_c63680a9:


    julia "Uh, sì... Non dovevi farti coinvolgere."


translate italian e3s2_e967c7b8:


    d "Non avrei permesso che ti colpisse."


translate italian e3s2_2d39ae6d:


    julia "Bene grazie..."


translate italian e3s2_73abd97c:


    cha "Julia? Stai bene?"


translate italian e3s2_51ae6b1b:


    cha "Ho visto la scena da fuori. Mio Dio."


translate italian e3s2_5f7f804f:


    julia "Sì, sì, non devi preoccuparti."


translate italian e3s2_1ba20f5d:


    cha "Grazie, giovanotto, per averla aiutata... Signor???"


translate italian e3s2_fbf269c6:


    d "[name]"


translate italian e3s2_acca40b4:


    cha "Grazie ancora, [name]. Non avrei dovuto lasciarla sola a gestire il turno serale."


translate italian e3s2_e01c9248:


    d "Tu lavori qui?"


translate italian e3s2_4e619f92:


    julia "SÌ..."


translate italian e3s2_48ce23ad:


    d "Perchè non me lo hai detto?!"


translate italian e3s2_bd49eff6:


    cha "Aspetta, entriamo. Farà bene a tutti prendere una cioccolata calda..."


translate italian e3s2_6f6f00e8:


    cha "Bello, forte e coraggioso! Capisco perché stavi cantando. Se non fai una mossa presto con lui, lo farò io stessa!"


translate italian e3s2_15d9b8f0:


    julia "Per favore sentiti libera."


translate italian e3s2_2387a6fc:


    cha "Sul serio?"


translate italian e3s2_cccd82e6:


    julia "Sì, è tutto tuo."


translate italian e3s2_ec0ae24c:


    julia "Pensi che dovrei?"


translate italian e3s2_e6a9aec8:


    cha "Un tipo così... credimi, non ne troverai dieci in tutta la città. Dovresti assolutamente fare una mossa."


translate italian e3s2_d1f70c04:


    julia "..."


translate italian e3s2_36ccb686:


    cha "Mi dispiace davvero, Julia. Sono venuta il più velocemente possibile dopo aver finito con la contabilità, ma ci vuole tempo."


translate italian e3s2_d62322d6:


    julia "Non è colpa tua."


translate italian e3s2_22478a66:


    cha "Beh, non ti lascerò più aprire da sola."


translate italian e3s2_7d9739b4:


    julia "Non puoi farci niente. Ci saranno sempre dei cretini che cercheranno di non pagare o di darci del filo da torcere... soprattutto con questi vestiti. Ahia!"


translate italian e3s2_b4f06701:


    d "Ti sei fatta male?"


translate italian e3s2_f446ab7a:


    julia "Credo di essermi stirato la schiena. Deve essere per la caduta di prima."


translate italian e3s2_4d7dd868:


    cha "Ascolta, Julia. Prenditi il ​​resto della serata libera. Non preoccuparti, ti pagherò l'intero turno e tu mi farai sapere come stai lunedì, ok?"


translate italian e3s2_dc1b71b4:


    julia "Uh, sei sicura..."


translate italian e3s2_00d9f982:


    cha "Sì, naturalmente! Vai!"


translate italian e3s2_737c091e:


    julia "Bene, ci vediamo domani a lezione?"


translate italian e3s2_4395d1e1:


    cha "Aspetta, non tornerai a casa da sola dopo tutto questo?"


translate italian e3s2_101332d7:


    julia "Eh?"


translate italian e3s2_b07c4bd4:


    cha "[name]... Puoi accompagnarla a casa nel caso in cui quei ragazzi siano ancora in giro? Anche lei soffre, poverina..."


translate italian e3s2_c86d76cd:


    d "Assolutamente!"


translate italian e3s2_98ee41e1:


    julia "Grazie, Charlotte, e grazie, [name]..."


translate italian e3s2_3d6f8fcc:


    d "Non c'è di che, non potevo lasciarti così."


translate italian e3s2_cb310aad:


    cha "Oh, Julia! Fai attenzione! Almeno sono sicura che sei in buone mani!"


translate italian e3s2_5f93d507:


    julia "Ehm... sì. Ci vediamo lunedì!"


translate italian e3s2_c429c485:


    d "Scusa, Julia. È stata una lunga giornata e sono venuto qui solo per mangiare. Ho appena finito di allenarmi e..."


translate italian e3s2_64959bcf:


    julia "Oh... Sì, certo, nessun problema."


translate italian e3s2_737c091e_1:


    julia "Bene, ci vediamo domani a lezione?"


translate italian e3s2_bdc6126b:


    d "Sì! Ci vediamo domani!"


translate italian e3s2_28ec6028:


    julia "Ci vediamo..."


translate italian e3s2_c429f4fb:


    cha "Beh, meno male che eri lì."


translate italian e3s2_dbed8808:


    cha "Povera Julia..."


translate italian e3s2_4fdbb733:


    d "Sì."


translate italian e3s2_7d3fd540:


    cha "E oltre a questo. Non ti ho mai visto da queste parti!"


translate italian e3s2_4e2cab3e:


    cha "Mi sarei ricordata di uno come te!"


translate italian e3s2_9764bddd:


    d "Sono appena arrivato negli Stati Uniti. Vengo dalla Francia."


translate italian e3s2_12aafb8a:


    cha "Ah. La tua prima volta negli States?"


translate italian e3s2_fc6dea88:


    d "Sì..."


translate italian e3s2_03dd73c2:


    d "Bene, grazie!"


translate italian e3s2_f06a7085:


    cha "Non essere timido! Non mordo! Beh, forse, se lo chiedi gentilmente..."


translate italian e3s2_84242d48:


    d "È solo che non mi sento ancora del tutto a mio agio nel parlare con le persone qui. Non è niente di personale."


translate italian e3s2_e89828e2:


    cha "Si Capisco. Incontrare così tante persone diverse e perdere l'orientamento."


translate italian e3s2_bec77bc1:


    d "Esattamente."


translate italian e3s2_b3d1e3a6:


    cha "Ciò non ti ha impedito di metterti in pericolo per una ragazza che conosci solo da pochi giorni."


translate italian e3s2_9ce586db:


    d "Beh... detto così sembra un po' sciocco. Ho semplicemente agito d'istinto, però."


translate italian e3s2_2085f4f1:


    cha "Sciocco? Forse. Direi che è stato impressionante. Non capita tutti i giorni di vedere qualcuno avere il coraggio di intervenire e difendere una signora."


translate italian e3s2_853db437:


    cha "Quindi stuzzichi la mia curiosità."


translate italian e3s2_aa5d264e:


    d "Oh veramente?"


translate italian e3s2_28ead7f2:


    cha "Ovviamente! Mi fa venir voglia di sapere di più su di te. Da dove vieni, com'è stata la tua vita, il tuo viaggio..."


translate italian e3s2_28985498:


    d "Non è così interessante, lo sai."


translate italian e3s2_a124aa82:


    cha "Per me lo è! Hai aiutato Julia, quindi sei un eroe! Puoi rilassarti con me!"


translate italian e3s2_f338cc08:


    d "Ehm..."


translate italian e3s2_8d96a0f5:


    cha "Ehi, non ho sessant'anni, lo sai! Pensi che sembro vecchia?"


translate italian e3s2_973b12eb:


    d "Con tutto il rispetto, ma... non sei proprio il mio tipo. Preferisco lasciare le cose così."


translate italian e3s2_c3e5e858:


    cha "Eh?"


translate italian e3s2_9df72a84:


    d "Grazie ancora per la cioccolata calda."


translate italian e3s2_497f2de3:


    cha "Uhm... okay."


translate italian e3s2_3a27a1c5:


    cha "Che ragazzo strano."


translate italian e3s2_1e387d97:


    d "Vecchia? Non c'è modo! L'età non conta comunque, vero?"


translate italian e3s2_174c156d:


    cha "Avanti, dimmi di più..."


translate italian e3s2_e8c8cd80:


    d "Se dovessi uscire con una donna più grande, come amica o forse di più, penso che sarei orgoglioso di averti al mio fianco. Quindi non penso che l'età abbia importanza qui."


translate italian e3s2_5e85b9f6:


    cha "Orgoglioso?"


translate italian e3s2_3223290c:


    d "Sì! Avere una donna attiva che gestisce la propria attività,"


translate italian e3s2_7180550b:


    d "una donna attraente con cui esplorare la città,"


translate italian e3s2_d0ed1b72:


    d "una donna esperta con la quale posso esplorare molte possibilità..."


translate italian e3s2_d7e45884:


    cha "Ok, ok, ho capito..."


translate italian e3s2_a55a49c7:


    cha "Ascolta, si sta facendo tardi. Ho del lavoro da fare."


translate italian e3s2_861c4633:


    cha "Domani sera vai alla festa?"


translate italian e3s2_60d6331e:


    d "SÌ."


translate italian e3s2_48972c73:


    cha "Allora fermati prima di andare. Starò qui tutto il pomeriggio a fare l'inventario."


translate italian e3s2_3566bcd4:


    cha "Perfetto. Allora, ci vediamo domani?"


translate italian e3s2_d20a6f4a:


    d "Ci vediamo allora, Charlotte."


translate italian e3s2_c19b505a:


    cha "Ci vediamo, [name]."


translate italian e3s2_973b12eb_1:


    d "Con tutto il rispetto, ma... non sei proprio il mio tipo. Preferisco lasciare le cose così."


translate italian e3s2_c3e5e858_1:


    cha "Eh?"


translate italian e3s2_4e34c614:


    d "Grazie ancora per la cioccolata calda..."


translate italian e3s2_ddc779e8:


    cha "Uhm, okay."


translate italian e3s2_e9f5a102:


    cha "Che ragazzo strano..."

translate italian strings:


    old "Yes, of course."
    new "Sì, naturalmente."


    old "I'd rather not..."
    new "Preferirei di no..."


    old "Okay, I'll stop in."
    new "Ok, mi fermo."


    old "Uh... no, thanks!"
    new "Ehm... no, grazie!"




translate italian e3s2_804023bd:


    "Ah ah ah ah !"


translate italian e3s2_b235ac9e:


    julia "Bastardi!"


translate italian e3s2_2302240e:


    julia "Humpff..."


translate italian e3s2_95b1505d:


    hec "Vai via, sporca troia!"


translate italian e3s2_70d11f38:


    julia "Fermati!"


translate italian e3s2_e2fbc6f9:


    julia "Devi pagare!"


translate italian e3s2_769b2c2f:


    julia "Fuori!"


translate italian e3s2_8f910df6:


    hec "Ti avevo detto di lasciarci andare, Pinkie!"


translate italian e3s2_77d23ef5:


    hec "Non è abbastanza?"


translate italian e3s2_a2431503:


    julia "NO! IO..."


translate italian e3s2_12cbfb5a:


    hec "Prendi quella stronza!"


translate italian e3s2_d1d296af:


    julia "Ciaoooo!"


translate italian e3s2_101332d7_1:


    julia "Eh?"


translate italian e3s2_b1807fea:


    julia "Cosa..."


translate italian e3s2_dc11a5bc:


    hec "Chi è?"


translate italian e3s2_f67fdb4c:


    julia "[name]!"


translate italian e3s2_5f341222:


    hec "E cosa hai intenzione di fare, eh? Non l'ho toccata. Se mi colpisci ci saranno dei testimoni. Se finisci nei guai con la polizia..."


translate italian e3s2_bc1784aa:


    cha "Ho visto la scena. Mio Dio."


translate italian e3s2_1604c1be:


    d "[name]."


translate italian e3s2_33b7d50d:


    cha "Torniamo al negozio."


translate italian e3s2_93e168f1:


    ji "Interessante..."


translate italian e3s2_4bc03d25:


    cha "Un tipo così... Credimi, non ne troverai dieci in tutta la città. Dovresti assolutamente fare una mossa."


translate italian e3s2_6d3fade6:


    julia "Non puoi farci niente. Ci saranno sempre dei cretini che cercheranno di non pagare o di darci del filo da torcere... Soprattutto con questi vestiti."


translate italian e3s2_bccda825:


    julia "Ahia!"


translate italian e3s2_101332d7_2:


    julia "Eh?"


translate italian e3s2_00c88aec:


    d "Esattamente. E cosa succede ai tuoi occhiali? Alcune volte li indossi, altre volte no."


translate italian e3s2_1adcfb1a:


    cha "OH? Li uso solo al lavoro per leggere e sembrare più... Matura! Ma per un ragazzo che non parla con gli altri..."


translate italian e3s2_22466bae:


    d "Con tutto il rispetto, ma... non sei proprio il mio tipo. Preferisco lasciare le cose così."





translate italian strings:


    old "Yes, of course.[TEMP1!t]"
    new "Sì, certo.[TEMP1!t]"


    old "I'd rather not...[TEMP2!t]"
    new "Preferirei non...[TEMP2!t]"


    old "Okay, I'll stop in.[TEMP1!t]"
    new "Va bene, mi fermo qui.[TEMP1!t]"


    old "Uh... no, thanks![TEMP2!t]"
    new "Uh... no, grazie! [TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
