


translate italian e3s1a_913c1b8d:


    ruby "Dai! Non essere così! Vedrai, sarà divertente!"


translate italian e3s1a_df808924:


    d "Uhm, non ne sono molto sicuro..."


translate italian e3s1a_fe425094:


    ruby "Lo sarà! Red è super professionale! Sono sicura che ci troverà delle cose davvero carine per la festa di domani!"


translate italian e3s1a_2a6ac8ac:


    d "Ci?"


translate italian e3s1a_5f3fc3b6:


    ruby "Ovviamente! Domani c'è una festa a tema. Non te l'ha detto nessuno?"


translate italian e3s1a_2940ea0e:


    d "Ehm... no?"


translate italian e3s1a_979fa522:


    ruby "È una festa chic e provocatoria!"


translate italian e3s1a_41d1ae04:


    d "Che cosa significa?"


translate italian e3s1a_90556121:


    ruby "Beh, spesso si tratta di vestirsi in modo elegante e sexy, o con qualcosa che risalti."


translate italian e3s1a_5cadcfe2:


    d "E come ti aspetti che io sia chic e provocante?"


translate italian e3s1a_470e5aa3:


    beth "Non preoccuparti, sono qui per aiutarti."


translate italian e3s1a_29ac5843:


    d "Che cosa?"


translate italian e3s1a_bfc79f9d:


    ruby "Grazie, Elizabeth!"


translate italian e3s1a_20ab99ea:


    beth "Prego. È il mio lavoro, lo sai."


translate italian e3s1a_a83292d0:


    beth "Ruby, sai che stile stai cercando?"


translate italian e3s1a_25a5ce6d:


    ruby "In realtà, per una volta, non ne ho proprio idea."


translate italian e3s1a_4f1ceddc:


    beth "Vedrò cosa ho per te, nel frattempo sentiti libera di dare un'occhiata in giro."


translate italian e3s1a_ea7bcd1b:


    ruby "Va bene!"


translate italian e3s1a_890030aa:


    ruby "Vedi te l'avevo detto! Quando siamo nel suo negozio, cambia completamente!"


translate italian e3s1a_e48c9cb0:


    d "Hmm..."


translate italian e3s1a_f890b9d6:


    ruby "Bene, dobbiamo ancora trovare qualcosa. Qualche idea?"


translate italian e3s1a_3bf529d7:


    d "Qualunque cosa indossi ti starà benissimo. Ne sono sicuro!"


translate italian e3s1a_859f0f2e:


    ruby "OH! Sei troppo dolce!"


translate italian e3s1a_3ee9764b:


    d "Vorrei che indossassi qualcosa che metta in risalto il tuo corpo. Sei stupenda ma non lo dimostri abbastanza!"


translate italian e3s1a_8cc00336:


    ruby "OH? Uh, ci proverò..."


translate italian e3s1a_7e930183:


    beth "Vieni qui, ho trovato un bel po' di cose da farti provare!"


translate italian e3s1a_c05087df:


    ruby "Sto arrivando!"


translate italian e3s1a_a1a21cfb:


    beth "Tieni, Ruby, puoi usare questo camerino."


translate italian e3s1a_1efbcfae:


    ruby "Va bene! Grazie, Elizabeth!"


translate italian e3s1a_7248ffa2:


    beth "Vieni qui [name], ho alcune cose da farti provare anche per te!"


translate italian rubyshop_ed1da845:


    ruby "Puoi guardare, non mi dà fastidio!"


translate italian rubyshop_2c3a63c7:


    d "Cosa intendi?"


translate italian rubyshop_952add76:


    ruby "Ti sei cambiato davanti a me nella tua stanza e io non ho chiuso occhio... Quindi è giusto!"


translate italian rubyshop_f338cc08:


    d "Ehm..."


translate italian rubyshop_cc0022e7:


    ruby "Guarda chi è timido adesso..."


translate italian rubyshop_9e0087a7:


    d "Non sono timido!"


translate italian rubyshop_ec40631d:


    ruby "Allora vieni ad aiutarmi a togliermi il vestito.."


translate italian rubyshop_29ac5843:


    d "Che cosa?"


translate italian rubyshop_1bb724e6:


    ruby "Il mio vestito. La cerniera è bloccata e non riesco ad aprirla!"


translate italian rubyshop_8d0a4a6e:


    d "Oh ok!"


translate italian rubyshop_e2889d3c:


    ruby "Ahh"


translate italian rubyshop_8ae3f02b:


    ruby "Grazie."


translate italian rubyshop_23b2f656:


    ruby "Vai a sederti. Ti mostrerò i miei preferiti e tu dimmi quale ti piace!"


translate italian rubyshop_40ab082c:


    d "Per me va bene!"


translate italian rubyshop2_18748a7f:


    ruby "Cosa ne pensi?"


translate italian rubyshop2_6366f041:


    d "Non male, ma non sono sicuro che sia quello che chiami chic e provocatorio."


translate italian rubyshop2_56516992:


    ruby "Sì. Probabilmente hai ragione."


translate italian rubyshop2_c2881933:


    d "Oh..."


translate italian rubyshop2_f9611e40:


    d "Sbalorditivo!"


translate italian rubyshop2_57fa5bbe:


    d "Com'è possibile? Ti sta bene tutto!"


translate italian rubyshop2_7034f0b6:


    ruby "Quale preferisci?"


translate italian rubyshop2_0bfcc6ba:


    d "Onestamente... non riesco a decidere. Sei stupenda con tutti loro!"


translate italian rubyshop2_53917e62:


    ruby "Ok... allora scelgo io e domani sera avrai una sorpresa!"


translate italian rubyshop2_e0a25cf5:


    d "Mi piace come suona!"


translate italian redshop_43398bf1:


    d "Cosa..."


translate italian redshop_12681d03:


    beth "shhhhh"


translate italian redshop_146362be:


    ruby "Che è successo?"


translate italian redshop_7d28839c:


    d "Niente, sono rimasto semplicemente sorpreso da alcuni outfit!"


translate italian redshop_60c4b680:


    ruby "OH! Va bene! Sai che non devi indossare qualcosa di strano. Proprio tu, ma chic e provocante!"


translate italian redshop_c6f2cd3d:


    d "Fanculo, va in profondità!"


translate italian redshop_2307991b:


    ruby "Che cosa?"


translate italian redshop_bcd68d7a:


    d "Hum... ho detto che i tuoi pensieri sono profondi!"


translate italian redshop_e6fa808c:


    ruby "Oh... Lo pensi?"


translate italian redshop_731e5fce:


    d "Io... io... non posso..."


translate italian redshop_b4af70db:


    ruby "Non preoccuparti. Puoi condividere quello che stai pensando con me!"


translate italian redshop_64f0d24d:


    d "Condividere? Non ti dispiace?"


translate italian redshop_1c0a8c41:


    beth "Hum hum..."


translate italian redshop_94364417:


    ruby "Ovviamente!"


translate italian redshop_8fc1ec88:


    d "Ahhhhhh! È così bello!"


translate italian redshop_8c5e2da6:


    ruby "Non avevo capito che avrebbe avuto questo effetto."


translate italian redshop_c665f1b6:


    d "Mi sento svuotato!"


translate italian redshop_e47ecb4c:


    ruby "Questo è il principio! Svuota te stesso per rilassarti!"


translate italian redshop_8655210a:


    d "Non sai niente, Jon Snow."


translate italian redshop_af29a28e:


    ruby "EHI! Questa è la mia frase!"


translate italian redshop_f5f0c740:


    d "Ebbene... mi accontento di niente!"


translate italian redshop_219a4a36:


    d "E tu?"


translate italian mcshop_92592ec0:


    ruby "E tu?"


translate italian mcshop_0beb0af8:


    beth "Non preoccuparti per lui. Porterò il suo outfit direttamente alla festa! So esattamente di cosa ha bisogno!"


translate italian mcshop_dee5c425:


    d "Ehm... sei sicura?"


translate italian mcshop_19e14c97:


    ruby "Ah, lo adoro! Possiamo rimanere entrambi sorpresi!"


translate italian mcshop_e81f6775:


    d "Non sono sicuro di..."


translate italian mcshop_1d773b28:


    beth "Si si! Fidati di me! Anche Emerick non sarà bello come te domani sera!"


translate italian mcshop_7662c915:


    d "Ma cosa succede se..."


translate italian mcshop_fb897691:


    ruby "Per me va bene! Dobbiamo mostrare adeguatamente il mio Cortex. Ha bisogno di essere ipnotizzante!"


translate italian mcshop_a774e662:


    beth "Lo prometto, Ruby!"


translate italian mcshop_84464bc4:


    ruby "Grande! Bene devo andare. Si sta facendo tardi e voglio essere ben riposata per domani!"


translate italian mcshop_58cf6d6d:


    ruby "[name], vieni?"


translate italian mcshop_0cde5eaa:


    d "Hmm, avevo intenzione di mangiare qualcosa da qualche parte prima di tornare indietro."


translate italian mcshop_055b97ca:


    ruby "OH? Beh, se vai in fondo all'isolato, ci sono alcuni ristoranti."


translate italian mcshop_fbc4a3b1:


    d "Perfetto! Grazie per avermi informato."


translate italian mcshop_a40b363d:


    ruby "Allora, posso aspettarmi un messaggio quando torni a casa?"


translate italian mcshop_320e0c8a:


    d "Uh... sì, se vuoi..."


translate italian mcshop_5ab4406d:


    ruby "So di sembrare un po' iperprotettiva, ma non mi piace lasciare sole le persone a cui tengo la notte."


translate italian mcshop_02721b20:


    d "OH? È carino da parte tua! Non devi preoccuparti per me, starò bene."


translate italian mcshop_beb57c11:


    ruby "Ok, allora. Ci vediamo domani!"


translate italian mcshop_0eaf48fc:


    d "Ci vediamo domani!"


translate italian mcshop_c645839b:


    d "Non hai un vestito per me, vero?"


translate italian mcshop_701a8840:


    beth "Certo che ce l'ho. Lo porterò domani!"


translate italian mcshop_134c20f9:


    d "Sul serio?"


translate italian mcshop_c313eee8:


    beth "Assolutamente! Te l'avevo detto che se mi avessi soddisfatta saresti stato ricompensato."


translate italian mcshop_291126b8:


    beth "Certamente l'hai fatto... dandomi tutto prima."


translate italian mcshop_ce4e4abc:


    beth "Allora ci vediamo domani prima della festa e poi te lo darò."


translate italian mcshop_4b78c937:


    d "Per me va bene! A domani, Elizabeth!"


translate italian mcshop_79e0c399:


    beth "Ci vediamo domani!"


translate italian mcshop_c8810e50:


    beth "Ovviamente no. Scoprilo tu stesso."


translate italian mcshop_b7ff5f06:


    d "Sei seria?"


translate italian mcshop_82668fcd:


    beth "Non sai contro chi hai a che fare, Francesino. Lo capirai presto."


translate italian mcshop_06e7f82f:


    d "Ehm... okay. Ci vediamo domani, suppongo."


translate italian mcshop_054b635f:


    beth "Ci vediamo domani."

translate italian strings:


    old "Buddy"
    new "Compagno"


    old "Temperament"
    new "Temperamento"


    old "Follow Red"
    new "Segui Rosso"


    old "Stay with Ruby"
    new "Resta con Ruby"




translate italian e3s1a_53611aa8:


    d "Adesso arriva la parte divertente!"


translate italian rubyshop_ad43ddfc:


    ruby "Uhm...."


translate italian rubyshop_75127a40:


    ruby "Ohhh..."


translate italian rubyshop_492766ce:


    ruby "Uhhhh"


translate italian rubyshop_a905bd37:


    ruby "Eh...."








translate italian redshop_2e748302:


    beth "Dovrò occuparmene se voglio che tu sia veloce..."


translate italian redshop_9d9f175f:


    beth "E non voglio che tu rovini la mia cabina... Quindi..."

translate italian strings:


    old "Follow Red[TEMP1!t]"
    new "Segui Rosso[TEMP1!t]"


    old "Stay with Ruby[TEMP2!t]"
    new "Rimani con Ruby[TEMP2!t]"












translate italian rubyshop_95230105:


    ruby "Il mio vestito. La cerniera è bloccata e non riesco ad arrivare ad aprirla!"


translate italian mcshop_a829e67e:


    d "Mmm, avevo intenzione di mangiare un boccone da qualche parte prima di tornare indietro."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
