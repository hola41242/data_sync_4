


translate italian coming2_2c7a6b72:


    mad "Papà... Perché vuoi incontrarlo?"


translate italian coming2_315b4afb:


    mad "..."


translate italian coming2_9f07be60:


    mad "Lo farò..."


translate italian coming2_7a29416a:


    ji "Vai alla festa stasera?"


translate italian coming2_aee41bbd:


    ji "Mamma..."


translate italian coming2_7a16ee9c:


    grace "Sei l'unica persona che voglio stasera..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
