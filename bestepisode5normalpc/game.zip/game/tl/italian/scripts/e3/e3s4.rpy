


translate italian e3s4_43b49e4c:


    d "Va bene."


translate italian e3s4_2764ca10:


    d "Ho promesso a Ruby che le avrei mandato un messaggio quando sarei tornato a casa."


translate italian e3s4_fb7cad08:


    d "Finalmente... posso riposarmi un po'. Qualcosa mi dice che domani non sarà una giornata normale."


translate italian e3s4_cecbb726:


    dpense "Lascia che arrivino le sorprese. Dopotutto, è nell'inaspettato che risiede la vera avventura."

translate italian strings:


    old "Minus... you awake?"
    new "Meno... sei sveglia?"


    old "Of course! I was worried about you!"
    new "Ovviamente! Ero preoccupata per te!"


    old "You're so sweet!"
    new "Sei così dolce!"


    old "You think so?"
    new "Tu la pensi così?"


    old "Absolutely! I couldn't ask for a better friend!"
    new "Assolutamente! Non potrei chiedere un' amica migliore!"


    old "I know I'm the B.E.S.T !"
    new "So di essere il MIGLIORE!"


    old "Ahah! For sure!"
    new "Ah ah! Di sicuro!"


    old "Good night, my acolyte! "
    new "Buonanotte, mia ​​accolita!"


    old "Sweet dreams, my partner!"
    new "Sogni d'oro, compagno mio!"




translate italian e3s4_9f40912c:


    d "???" with hpunch


translate italian e3s4_6eb69ed4:


    d "Un altro messaggio?"


translate italian e3s4_db4f6715:


    d "Nessuna risposta..."

translate italian strings:


    old "Ahah! For sure! So... I'm back in my room."
    new "Ah ah! Di sicuro! Quindi... sono tornato nella mia stanza."


    old "Great! I'm relieved!"
    new "Grande! Sono sollevata!"


    old "Good night, my acolyte!"
    new "Buonanotte, mia ​​accolita!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
