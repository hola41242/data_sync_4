


translate italian e3intro_0be561b1:


    ruby "Hmpffff"


translate italian e3intro_95eb778b:


    ruby "Non so davvero cosa indossare. Con la festa da Grace..."


translate italian e3intro_35c89622:


    ruby "e la serata al cinema con [name]..."


translate italian e3intro_fc09bfd6:


    ruby "Dovrò fare tutto il possibile."


translate italian e3intro_7156630f:


    ruby "Dovrei indossare qualcosa di più sexy..."


translate italian e3intro_b924fffa:


    ruby "o di classe?"


translate italian e3intro_7fcb6cfe:


    ruby "E voi ragazze?"


translate italian e3intro_18748a7f:


    ruby "Cosa ne pensate?"


translate italian e3intro_d2eebdc0:


    ruby "Qualcosa..."


translate italian e3intro_902e1a01:


    ruby "Un po' cyber?"


translate italian e3intro_c4cb47c6:


    ruby "O qualcosa di più elegante?"


translate italian e3intro_41ca40a0:


    ruby "Ohhh... dovrei andare a comprare dei vestiti nuovi!"


translate italian e3intro_d0053bde:


    ruby "Forse [name] vorrebbe venire con me?"


translate italian e3intro_79bde7bc:


    ruby "Mi farebbe davvero piacere se mi aiutasse a scegliere."


translate italian e3intro_6d6299b3:


    ruby "Scommetto che sta dormendo."





translate italian e3intro_2d24ae24:


    ruby "Dovrei indossare qualcosa di più sexy..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
