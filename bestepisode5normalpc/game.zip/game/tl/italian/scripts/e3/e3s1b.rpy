


translate italian e3s1b_3e99e6fe:


    d "Devo lavorare di più per raggiungere gli altri."


translate italian e3s1b_e0b40846:


    d "Ho bisogno di migliorare."


translate italian e3s1b_02909704:


    d "La prossima partita sarà più impegnativa."


translate italian e3s1b_4d6de57e:


    d "Devo dare il massimo e lasciare tutto là fuori."


translate italian e3s1b_a2c0471f:


    ji "Non male."


translate italian e3s1b_19e694e7:


    ji "Sarebbe meglio se fosse nella gabbia."


translate italian e3s1b_675025bd:


    ji "Devi lavorare sul gioco di gambe."


translate italian e3s1b_85a51d50:


    d "Eh???"


translate italian e3s1b_ca5c561e:


    gaby "Il tuo gioco di gambe. Il modo in cui muovi i piedi."


translate italian e3s1b_0bafbbe5:


    gaby "Pianta il piede anteriore quando tiri e piegati in avanti il ​​più possibile in modo da poter trasferire tutta la forza sulla palla."


translate italian e3s1b_4539f447:


    d "Trasferire tutta la forza?"


translate italian e3s1b_8fa50577:


    gaby "SÌ. Se ti inclini all'indietro, la palla volerà in alto. Se ti pieghi in avanti, la palla prenderà tutta la potenza e potrai darle più effetto."


translate italian e3s1b_be887b2f:


    d "Uh, non lo sapevo."


translate italian e3s1b_54134b7b:


    gaby "Vai avanti, prova!"


translate italian e3s1b_1523fe20:


    d "..."


translate italian e3s1b_fef6c142:


    d "Non riesco proprio a capirlo. Non riesco a connettermi in modo abbastanza pulito sulla palla."


translate italian e3s1b_2ce8734d:


    gaby "Lo prenderai."


translate italian e3s1b_01d6fdfd:


    d "Come fai a sapere tutto questo?"


translate italian e3s1b_5939427c:


    gaby "Sono un allenatore, sai... E c'è stato un tempo in cui giocavo tanto anch'io..."


translate italian e3s1b_7441657c:


    gaby "Ero giovane allora."


translate italian e3s1b_192e17bc:


    d "Sei ancora giovane però."


translate italian e3s1b_e93a360f:


    gaby "Beh, immagino di sì. Non è più la stessa cosa."


translate italian e3s1b_f22eeffc:


    gaby "Non ho lo stesso corpo di prima."


translate italian e3s1b_17d5107e:


    gaby "Il passare del tempo, come si suol dire..."


translate italian e3s1b_8c82d0dd:


    d "Se posso, penso che ti sottovaluti."


translate italian e3s1b_80e32e55:


    d "Sei assolutamente stupenda. Anche il tempo sarebbe troppo stordito per passarti accanto."


translate italian e3s1b_5b7cd72d:


    d "Qualunque uomo sarebbe pazzo a non notare una donna adorabile come te."


translate italian e3s1b_525161b0:


    d "Scusa, non avrei dovuto dire niente."


translate italian e3s1b_5ec68acb:


    gaby "Devo ammettere che non me lo aspettavo da uno dei miei studenti..."


translate italian e3s1b_8bddce5e:


    gaby "È molto lusinghiero. Però non credo che sia molto appropriato dirlo al tuo allenatore."


translate italian e3s1b_024817af:


    gaby "Anche se mi piacerebbe che tutti la pensassero come te."


translate italian e3s1b_ac0eb531:


    d "Non stavo cercando di lusingarti. Ti sto solo dicendo quello che penso."


translate italian e3s1b_718af70d:


    gaby "Tienilo per te allora. Potrebbe causare problemi se qualcuno ti sentisse dire queste cose a un insegnante. Nessuno di noi lo vorrebbe, vero?"


translate italian e3s1b_2c6e3916:


    d "Eri più in forma?! Ti ho intravisto in costume da bagno l'altro giorno e lascia che te lo dica, hai un corpo incredibile!"


translate italian e3s1b_070198d1:


    gaby "Di cosa stai parlando?"


translate italian e3s1b_cdbfaf2a:


    d "Voglio dire, sul serio! Sei una bomba! Non so come altro dirlo."


translate italian e3s1b_9c8bdb3b:


    d "Se fossi abbastanza fortunato da essere il tuo uomo, vorrei che il mondo lo sapesse! E credimi, non perderei l'occasione di apprezzare ed esplorare il tuo splendido corpo."


translate italian e3s1b_db0ae612:


    gaby "Non credo che questa conversazione sia molto opportuna, signor [name]."


translate italian e3s1b_40493fb5:


    d "Lo so, non è così, ma è la verità! Voglio dire, guardati! Se ti guardi allo specchio e non vedi una bellezza assoluta, devi essere cieco! Non so cosa possa essere successo prima per farti pensare in questo modo."


translate italian e3s1b_7f87e2f2:


    d "Ma è assurdo!"


translate italian e3s1b_2071d2fd:


    d "Se qualche idiota ti ha maltrattato in passato, devi lasciarlo andare. Tieni la testa alta e vai avanti perché sei chiaramente troppo bella per pensare in questo modo!"


translate italian e3s1b_ca335262:


    gaby "Uhm... penso che dovrei andare."


translate italian e3s1b_b02ad822:


    gaby "Bene, torna al tuo allenamento. Sei sulla strada giusta."


translate italian e3s1b_d3c7b6ea:


    d "Darò il massimo."


translate italian e3s1b_4d2be1f1:


    d "Un ultimo consiglio per la prossima partita?"


translate italian e3s1b_31a27688:


    gaby "OH? Hmm... Gioca con la barra."


translate italian e3s1b_0db8c8d0:


    d "Il bar?"


translate italian e3s1b_21784a96:


    gaby "Ci vediamo dopo, giovanotto."


translate italian e3s1b_bcf01860:


    d "Uh, sì... ci vediamo più tardi."


translate italian e3s1b_7c9441d9:


    d "Cosa intendeva con giocare con la sbarra?"


translate italian e3s1b_a132824f:


    d "Beh, per prima cosa, posiziona il mio corpo più in avanti..."


translate italian e3s1b_2ad9be58:


    gaby "È piuttosto audace, ma quel ragazzo ha ragione."


translate italian e3s1b_154f3cbd:


    gaby "Devo smetterla di pensare in questo modo..."


translate italian e3s1b_ea375fba:


    gaby "Tuttavia era da molto tempo che qualcuno non mi parlava in quel modo."


translate italian e3s1b_3ea324e1:


    gaby "Andiamo, Gaby. Rimettiti in sesto. È solo uno studente..."

translate italian strings:


    old "Education"
    new "Formazione scolastica"




translate italian e3s1b_c7644af0:


    d "Se fossi abbastanza fortunato da essere il tuo uomo, vorrei che il mondo lo sapesse! E credimi, non perderei l'occasione di apprezzare ed esplorare il tuo splendido corpo."







translate italian strings:


    old "Education[TEMP1!t]"
    new "Educazione[TEMP1!t]"


    old "Temperament[TEMP2!t]"
    new "Temperamento[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
