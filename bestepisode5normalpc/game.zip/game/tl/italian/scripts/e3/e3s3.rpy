


translate italian e3s3_12ad8469:


    julia "Bene, eccoci qui. Questo è il mio posto!"


translate italian e3s3_0edccaa4:


    d "È carino!"


translate italian e3s3_3700f2d6:


    julia "Oh, non è niente di speciale, ma è tutto ciò di cui ho bisogno ed è conveniente."


translate italian e3s3_6a1c010e:


    julia "D'altra parte, non è nei quartieri più eleganti, come avrai notato..."


translate italian e3s3_bf939523:


    d "Non conosco ancora bene i quartieri, ma sì, il vicolo che abbiamo attraversato era un po' losco."


translate italian e3s3_9ced4376:


    julia "Beh, pensa che ci passo tutti i giorni dopo il mio turno!"


translate italian e3s3_74e3136e:


    d "Non sembra molto sicuro..."


translate italian e3s3_6fa84a8a:


    d "Perché non mi hai detto che avevi un lavoro?"


translate italian e3s3_56073172:


    julia "Diciamo solo che non sono nella stessa situazione finanziaria degli altri."


translate italian e3s3_a15dd700:


    julia "Ho una borsa di studio che mi permette di continuare i miei studi all'università."


translate italian e3s3_df4731e9:


    julia "Tra l'affitto e... gli altri problemi che devo affrontare, devo lavorare per pagare tutto."


translate italian e3s3_d5e1b526:


    julia "Non sono come Madison o le gemelle, non ho i miei genitori che mi sostengono."


translate italian e3s3_682e4e49:


    d "Dove sono i tuoi genitori?"


translate italian e3s3_93efd31f:


    julia "Uh... non so dove sia mio padre. Non l'ho mai incontrato."


translate italian e3s3_e53c2952:


    julia "Mia madre è molto malata."


translate italian e3s3_cd177145:


    julia "Ha un cancro alle ossa e non le resta molto tempo..."


translate italian e3s3_ad0f2283:


    d "Mi dispiace tantissimo, le mie scuse."


translate italian e3s3_e3457991:


    julia "Dato che non ha un'assicurazione, devo aiutarla a pagare le sue cure."


translate italian e3s3_6ec795c1:


    d "È molto da avere sulle tue spalle."


translate italian e3s3_2c8ea51b:


    julia "Sì, è per questo che mi tengo un po' per conto mio. Ne ho già abbastanza di tutto questo."


translate italian e3s3_040c5935:


    julia "Quando sento gli altri lamentarsi di cose banali..."


translate italian e3s3_584369bb:


    julia "o quando Madison mi sgrida senza motivo, ammetto che trovo difficile mantenere la calma."


translate italian e3s3_f9fbb463:


    d "Capisco."


translate italian e3s3_09de03e3:


    julia "Ma non lascerò che questo mi impedisca di vivere e... Ahi!"


translate italian e3s3_2baafa95:


    d "Cosa c'è che non va?"


translate italian e3s3_d8f13f9a:


    julia "Il mal di schiena è ancora piuttosto forte! Devo aver davvero fatto un numero quando sono caduto."


translate italian e3s3_b99a2b3b:


    d "Aspetta, sdraiati sul letto."


translate italian e3s3_101332d7:


    julia "Eh?"


translate italian e3s3_7ae3d8a2:


    d "Ti farò un massaggio. Aiuterà."


translate italian e3s3_f1e67029:


    julia "Sai come farlo?"


translate italian e3s3_9976359d:


    d "Sì, ho seguito un corso di terapia sportiva e prometto che allevierà il dolore."


translate italian e3s3_b217ed72:


    julia "Uhm, okay, possiamo provare..."


translate italian e3s3_641e6172:


    d "Sdraiarsi."


translate italian e3s3_690aeb67:


    d "Sarà più facile se ti togli la maglietta."


translate italian e3s3_933436bb:


    julia "Uh... sì, ha senso."


translate italian e3s3_aea36d69:


    d "Non preoccuparti. Fai del tuo meglio per sciogliere e rilassare i muscoli."


translate italian e3s3_dc0f59ff:


    julia "Ci proverò."


translate italian e3s3_f790c5fe:


    julia "Ah, mi fa sentire bene..."


translate italian e3s3_61e25695:


    d "Te l'avevo detto."


translate italian e3s3_2b836df5:


    d "Adesso rilassati."


translate italian e3s3_561cd9b9:


    julia "Ehm, sì, ecco..."


translate italian e3s3_d1923521:


    julia "Un po' più in basso... Lì..."


translate italian e3s3_8eea2814:


    julia "È perfetto."


translate italian e3s3_ca0cc37f:


    d "Vuoi che ti massaggi la metà inferiore mentre sono qui?"


translate italian e3s3_53c79c86:


    julia "Penso che tu abbia già massaggiato abbastanza la mia metà inferiore sull'aereo."


translate italian e3s3_7875d62f:


    d "Oh mi dispiace. Era fuori luogo da parte mia."


translate italian e3s3_f479b588:


    julia "Ma grazie comunque."


translate italian e3s3_3a32d93a:


    julia "Non so se..."


translate italian e3s3_e6a490a3:


    julia "Ah, mi fa davvero sentire bene..."


translate italian e3s3_a3222942:


    d "Sai, hai un bel corpo."


translate italian e3s3_9cb2fb4a:


    julia "Ehm... Grazie?"


translate italian e3s3_cb6df9e9:


    d "Sei muscoloso, hai delle belle curve e la tua pelle è morbida."


translate italian e3s3_5e76aabf:


    julia "Ah..."


translate italian e3s3_93d6639c:


    d "Lascia che mi prenda cura di te, Julia."


translate italian e3s3_ebeb14c7:


    julia "Hmm..."


translate italian e3s3_990aa0aa:


    d "Voglio che tu abbia fiducia in me, che sia qualcuno su cui puoi contare."


translate italian e3s3_d11ffcb2:


    d "Fammi scoprire la vera Julia. Il fiore che aspetta solo di fiorire."


translate italian e3s3_28d95fb6:


    julia "OH..."


translate italian e3s3_5242d378:


    d "Sarò qui per te se hai bisogno di me."


translate italian e3s3_5698db07:


    julia "IO..."


translate italian e3s3_6584bc6c:


    julia "Ah!"


translate italian finjuliaep2_b8dc5ea9:


    julia "Grazie. Penso che sia abbastanza per stasera. Mi sento già molto meglio."


translate italian finjuliaep2_486de3ba:


    d "Non esitare a dirmi quando avrai bisogno delle mie mani esperte!"


translate italian finjuliaep2_23dd4e9a:


    julia "Si Grazie. Veramente."


translate italian finjuliaep2_36ff4f70:


    d "Allora esco. Devo ancora tornare a casa e ho promesso a Ruby che le avrei mandato un messaggio al mio ritorno. Non voglio che si preoccupi!"


translate italian finjuliaep2_c2b6bb98:


    julia "Oh si! Puoi star certo che non dormirà finché non avrà tue notizie."


translate italian finjuliaep2_4ce986cd:


    julia "È così con le persone a cui tiene."


translate italian finjuliaep2_0a780817:


    d "Dovrei sbrigarmi a casa allora."


translate italian finjuliaep2_95fa21dd:


    julia "Sì, è meglio."


translate italian finjuliaep2_841b0d8a:


    d "Ci vediamo domani, Julia."


translate italian finjuliaep2_79f08374:


    julia "Ci vediamo domani... [name]."




translate italian e3s3_9d3ce74c:


    julia "E mia madre è molto malata."


translate italian e3s3_2bc4c54e:


    julia "O quando Madison mi sgrida senza motivo, ammetto che trovo difficile mantenere la calma."


translate italian e3s3_eb7a265c:


    julia "Ma non lascerò che questo mi impedisca di vivere e..."


translate italian e3s3_bccda825:


    julia "Ahia!"


translate italian e3s3_a5c86f5a:


    julia "Va bene."


translate italian e3s3_0551ca4c:


    d "Sinceramente... sembri un cadavere in quella posizione!"


translate italian e3s3_3d5f9e28:


    julia "EHI!" with hpunch


translate italian e3s3_50424d17:


    julia "Ti farò sapere che fa davvero male!"


translate italian e3s3_77e66e95:


    d "Si scusa. Lasciamelo fare e poi ti sentirai meglio, vedrai."


translate italian e3s3_89966ef2:


    julia "Lo spero..."


translate italian e3s3_ab68d771:


    d "Sei davvero teso!"


translate italian e3s3_733bbbb6:


    julia "Non sono molto abituato a sdraiarmi con qualcuno sul mio letto..."


translate italian e3s3_29a8225a:


    julia "Penso che starei più a mio agio seduto."


translate italian e3s3_04a6c5de:


    d "Fai quello che vuoi. Voglio solo che ti rilassi."


translate italian e3s3_9d672ec7:


    julia "Questo è molto meglio."


translate italian e3s3_2cbde8fa:


    d "Se lo dici tu."


translate italian e3s3_8dcc9644:


    julia "Un po' più in basso..."


translate italian e3s3_d6f16a8e:


    julia "Sì..."


translate italian e3s3_de861bdc:


    julia "Proprio così"


translate italian e3s3_69ad8ab5:


    julia "Uh... Sì, ha senso."


translate italian e3s3_10487543:


    d "Vuoi che continui ulteriormente?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
