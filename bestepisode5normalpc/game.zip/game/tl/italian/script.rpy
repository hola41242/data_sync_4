

translate italian before_main_menu_0888dd09:


    ji "Ciao bello... ti sei perso???"


translate italian before_main_menu_59c2a0d0:


    ji "Occhi qui ragazzo!!!"


translate italian before_main_menu_bcb0d6ab:


    ji "Hmmmm..."


translate italian before_main_menu_261c3b79:


    ji "Prima di tutto, hai 18 anni o più?"


translate italian suitepres_f99b1c93:


    ji "Ok, è perfetto! Bene, andiamo in un posto più intimo!"


translate italian suitepres_d5e7ada9:


    ji "Innanzitutto, questa Visual Novel ha molte scene che contengono contenuti sessuali, linguaggio volgare e alcuni argomenti delicati come la droga e l'alcol... Forse anche... Sesso?"


translate italian suitepres_78b7a38d:


    ji "Potrebbe non essere adatto a tutti i lettori."


translate italian suitepres_38165d90:


    ji "Così sei pronto?"


translate italian suitepres2_71fd6753:


    ji "Se sei ancora qui, cercherò di rendere il tuo tempo trascorso qui piacevole e possibilmente... Molto piacevole, eheh!"


translate italian suitepres2_aab9f523:


    cr "Scusate, sono lo sviluppatore di questo gioco, il grande capo!"


translate italian suitepres2_af0bf494:


    cr "Vedo che hai conosciuto la mia ragazza. Lasciami parlare con lei solo per un minuto, per favore..."


translate italian suitepres2_5d1f2386:


    cr "Tesoro! Hai già mostrato loro la maggior parte del tuo corpo... e guarda che outfit!!! È normale comportarsi così?"


translate italian suitepres2_dfcdecc4:


    ji "In questo tipo di gioco... Sì!!! Mi hai chiesto di presentare il gioco... Per favore, lasciamelo fare!"


translate italian suitepres2_fa65479d:


    ji "Guarda il giocatore. È così timido... già mi piace!"


translate italian suitepres2_edddd53b:


    ji "Allora, giocatore, il gatto ti ha mangiato la lingua?"


translate italian suitepres2_e4d27473:


    ji "Spero che adorerai questo gioco perché è stato realizzato da una coppia di francesi che adorano i romanzi visivi..."


translate italian suitepres2_b4f250c1:


    ji "Vi chiedo solo di essere tolleranti e di non esitare a dare consigli o segnalare miglioramenti che possono apportare per rendere questo gioco migliore!"


translate italian suitepres2_56dc38b0:


    cr "Tesoro... Mio.. Amore.. FORZA, vogliono già giocare... Parli troppo!!!"


translate italian suitepres2_97160162:


    ji "OK, signor sviluppatore!!! Uff!!"


translate italian suitepres2_a8bece05:


    cr "Oh sì, gli hai detto che più tardi vedrà le tue tette?"


translate italian suitepres2_dade9dd7:


    ji "Forse... se gioca bene le sue carte..."


translate italian suitepres2_4c16d8a9:


    ji "Quindi buon divertimento! Forse ci rivedremo!"


translate italian suitepres2_dade9dd7_1:


    ji "Forse... se gioca bene le sue carte..."


translate italian suitepres2_4c16d8a9_1:


    ji "Quindi buon divertimento! Forse ci rivedremo!"


translate italian start_440c063c:


    centered "{size=+10}{color=#1e90ff}Essere competitivi...{/color}{/size}"


translate italian start_7f136763:


    centered "{size=+10}{color=#1e90ff}Non era la mia priorità fino ad ora...{/color}{/size}"


translate italian start_1f3237c5:


    centered "{size=+10}{color=#1e90ff}Diventare il numero 1 dei 100...{/color}{/size}"


translate italian start_78d2440b:


    centered "{size=+10}{color=#1e90ff}Non posso fallire... devo essere...{/color}{/size}"


translate italian start_510cdb0b:


    centered "{size=+20}{color=#1e90ff}Il MIGLIORE{/color}{/size}"


translate italian personalize_9f250a0a:


    grace "EHI !"


translate italian personalize_f9746723:


    grace "Hummm.... Qual è il tuo nome?"


translate italian personalize_ab9d0756:


    grace "Ok [name]..."


translate italian personalize_0452e6be:


    grace "OH !!! Vedo che hai acquistato la mod Walkthrough!"


translate italian personalize_f658dbf2:


    grace "Ti ringrazio per il tuo supporto e spero che apprezzerai l'esperienza completa di BEST!"


translate italian personalize_7945cae0:


    grace "Se è la prima volta che vieni qui ti consiglio di spegnerlo e di fare le scelte che vuoi..."


translate italian personalize_b252f0e1:


    grace "Ma è il tuo gioco, le tue scelte!"


translate italian personalize_f1f8fdf0:


    grace "Prima di iniziare, vorrei sapere che tipo di MC sei..."


translate italian personalize_1d84f494:


    grace "Ok, Ruby non vede l'ora di incontrarti!"


translate italian personalize_288577ac:


    grace "Bene, ho tutto ciò di cui ho bisogno!"


translate italian personalize_3edd6ed2:


    grace "Arrivederci !"


translate italian personalize_a2e34685:


    grace "Devi incontrare Gabriella, adora avere bravi studenti nella sua classe..."


translate italian personalize_288577ac_1:


    grace "Bene, ho tutto ciò di cui ho bisogno!"


translate italian personalize_3edd6ed2_1:


    grace "Arrivederci !"


translate italian personalize_7198e88c:


    grace "Hummm... Vieni con me in piscina, voglio vederlo!"


translate italian personalize_288577ac_2:


    grace "Bene, ho tutto ciò di cui ho bisogno!"


translate italian personalize_3edd6ed2_2:


    grace "Arrivederci !"


translate italian personalize_e7275600:


    grace "OH ? Beh, forse le gemelle avranno qualche lavoro con te..."


translate italian personalize_288577ac_3:


    grace "Bene, ho tutto ciò di cui ho bisogno!"


translate italian personalize_3edd6ed2_3:


    grace "Ci vediamo dopo !"


translate italian intro_6bd1d991:


    ji "Fanculo ! Ushhh... mi mancherai!"


translate italian intro_fb8a1e5a:


    "Questa è Elisa..."


translate italian intro_98e35350:


    "Amico mio... Con benefici come diciamo..."


translate italian intro_88e66fc8:


    "Ci frequentiamo da diversi mesi, ora..."


translate italian intro_8915e2ac:


    "Ma con una sola regola in mente..."


translate italian intro_87dc8d9b:


    "Senza obblighi..."


translate italian intro_484019c5:


    "Accidenti... mi mancherà quel culo..."


translate italian intro_f598880b:


    eli "Faresti meglio a tornare da me, presto..."


translate italian intro_5864ee29:


    eli "Lo giuro, [name], faresti meglio a tornare in fretta, Mmmm..."


translate italian intro_23f7ffe5:


    eli "Altrimenti verrò a prenderti io stessa."


translate italian intro_6c259796:


    eli "E spero che troverai delle ragazze lì per... Ahhh... Allenarti !!!"


translate italian intro_5c0e76f8:


    d "Che cosa ?"


translate italian intro_a805da84:


    eli "Vedrai altre ragazze che... Ahhhh... ti daranno delle esperienze...."


translate italian intro_5e07a779:


    eli "E io... Ahhhhhh.... Voglio sperimentare i risultati non appena torni!"


translate italian intro_274d889e:


    eli "Ushhh.... Sei il migliore..."


translate italian intro_0ff4aa8e:


    ji "Fanculo ! Ushhh... mi mancherà il tuo cazzo!"


translate italian intro_0ae9bcd0:


    ""


translate italian intro_fb8a1e5a_1:


    "Questa è Elisa..."


translate italian intro_98e35350_1:


    "Amico mio... Con benefici come diciamo..."


translate italian intro_88e66fc8_1:


    "Ci vediamo ormai da diversi mesi..."


translate italian intro_8915e2ac_1:


    "Ma con una sola regola in mente..."


translate italian intro_87dc8d9b_1:


    "Senza obblighi..."


translate italian intro_484019c5_1:


    "Accidenti... mi mancherà quel culo..."


translate italian intro_f598880b_1:


    eli "Faresti meglio a tornare da me, presto..."


translate italian intro_5864ee29_1:


    eli "Lo giuro, [name], faresti meglio a tornare in fretta, Mmmm..."


translate italian intro_23f7ffe5_1:


    eli "Altrimenti verrò a prenderti io stessa."


translate italian intro_6c259796_1:


    eli "E spero che troverai delle ragazze lì per... Ahhh... Allenarti !!!"


translate italian intro_5c0e76f8_1:


    d "Che cosa ?"


translate italian intro_a805da84_1:


    eli "Vedrai altre ragazze che... Ahhhh... ti daranno delle esperienze...."


translate italian intro_5e07a779_1:


    eli "E io... Ahhhhhh.... Voglio sperimentare i risultati non appena torni!"


translate italian intro_9bf13e71:


    eli "Ah... Ahhhh... Ahhh..."


translate italian intro_f2d0e4ee:


    eli "Hummmmmm..."


translate italian intro_ba92a9c5:


    d "Ahhhhhhh!!!!! Così buono!!!"


translate italian intro_274d889e_1:


    eli "Ushhh.... Sei il migliore..."


translate italian presentation_29b2cf68:


    dpense "E questo sono io..."


translate italian presentation_7f0d6adc:


    dpense "Vengo dalla Francia e andrò negli Stati Uniti..."


translate italian presentation_394d75ae:


    dpense "Non sono poi così male in inglese ma sono tutt'altro che perfetto... faccio alcuni errori e altri non si preoccupano di dirmelo quando lo faccio..."


translate italian presentation_59049871:


    dpense "Inizialmente verrò negli Stati Uniti per un programma di scambio di sei mesi tra Francia e Stati Uniti"


translate italian presentation_e4e86c7f:


    dpense "Sto studiando Marketing ed Economia"


translate italian presentation_8ca20e6f:


    dpense "Ho fatto domanda per il programma per migliorare il mio inglese."


translate italian presentation_294714e5:


    dpense "Il programma prevedeva di andare negli Stati Uniti per sei mesi, partecipare allo stile di vita dell'Accademia e tornare con un certificato. Sembrava abbastanza semplice."


translate italian presentation_84607db8:


    dpense "Tutto è iniziato così..."


translate italian presentation_16d55cb7:


    dpense "Un giorno ero in Francia con i miei amici e la mia famiglia..."


translate italian presentation_57251b7a:


    dpense "E il giorno dopo..."


translate italian presentation_fe665c28:


    dpense "Ero su un aereo per fare il viaggio dalla Francia..."


translate italian presentation_f9f78803:


    dpense "In America !!!!"

translate italian strings:


    old "You"
    new "Voi"


    old "Press click to continue"
    new "Premere clic per continuare"


    old "Do you want to activate the Streamer mode ? Streamer mode will hide explicit content to let you stream or watch the game without problems..."
    new "Vuoi attivare la modalità Streamer? La modalità streamer nasconderà i contenuti espliciti per consentirti di trasmettere in streaming o guardare la partita senza problemi..."


    old "Yes, activate the streaming mode"
    new "Sì, attiva la modalità streaming"


    old "No, I want the full-experience !"
    new "No, voglio l'esperienza completa!"


    old "Yes, of course I'm in!!!"
    new "Sì, certo che ci sto!!!"


    old "So boring... Ciao!"
    new "Così noioso... Ciao!"


    old "Your First Name?"
    new "Il tuo nome?"


    old "Enable Walkthrough"
    new "Abilita la procedura dettagliata"


    old "Disable Walkthrough"
    new "Disabilita la procedura dettagliata"


    old "I'm a good friend, always there for others...[TEMP1!t]"
    new "Sono un buon amico, sempre presente per gli altri...[TEMP1!t]"


    old "I'm a good student, serious and calm...[TEMP2!t]"
    new "Sono un bravo studente, serio e tranquillo...[TEMP2!t]"


    old "I'm a sport addict, DAMN![TEMP3!t]"
    new "Sono un fanatico dello sport, DANNAZIONE![TEMP3!t]"


    old "I'm a Don Juan, girls everywhere, everytime...[TEMP4!t]"
    new "Sono un Don Giovanni, ragazze ovunque, ogni volta...[TEMP4!t]"


    old "New Scene Gallery added"
    new "Aggiunta la nuova Galleria scene"





translate italian before_main_menu_d78d088e:


    ji "Ciao bello! Ti sei perso?"


translate italian before_main_menu_5a53566a:


    ji "I miei occhi sono quassù, amico!"


translate italian suitepres_f9826a8e:


    ji "Innanzitutto, questa Visual Novel contiene numerose scene con contenuti sessuali, linguaggio volgare e argomenti delicati come droga e alcol."


translate italian suitepres_0e21fab0:


    ji "Sei pronto?"


translate italian suitepres2_ce3307b7:


    ji "Sei ancora qui? Cercherò di fare in modo che il tempo trascorso qui sia divertente e, si spera... molto piacevole!"


translate italian suitepres2_da58db29:


    cr "Mi scusi, sono lo sviluppatore di questo gioco."


translate italian suitepres2_2682ba1a:


    cr "Vedo che hai incontrato la mia ragazza. Lasciami parlare con lei solo per un minuto, per favore."


translate italian suitepres2_ddd41a39:


    cr "Tesoro! Hai già mostrato loro la maggior parte del tuo corpo e guarda quell'outfit! È normale comportarsi così?"


translate italian suitepres2_70eedada:


    ji "In questo tipo di gioco... sì! Mi hai chiesto di presentare il gioco, quindi per favore lasciami farlo!"


translate italian suitepres2_254932e8:


    ji "Guarda il giocatore. È così timido. Mi piace già!"


translate italian suitepres2_cac004cf:


    ji "Spero che questo gioco vi piaccia perché è stato creato da una coppia di francesi amanti delle visual novel."


translate italian suitepres2_f868e8c5:


    ji "Il gioco è ancora in fase di sviluppo, quindi non esitate a dare consigli o a segnalare miglioramenti che potrebbero apportare per renderlo ancora migliore!"


translate italian suitepres2_6ae30e92:


    cr "Tesoro... Amore mio. DAI! Vogliono già giocare. Stai parlando troppo!"


translate italian suitepres2_26d958df:


    ji "Okay, signor Sviluppatore! Bene!"


translate italian suitepres2_71aeb4ea:


    ji "Forse. Se gioca bene le sue carte..."


translate italian suitepres2_f4f514d6:


    ji "Quindi divertitevi! Forse ci rivedremo!"


translate italian suitepres2_71aeb4ea_1:


    ji "Forse. Se gioca bene le sue carte..."


translate italian suitepres2_d666e21a:


    ji "Divertitevi! Forse ci rivedremo!"


translate italian personalize_ed074dc1:


    grace "Mmm. Come ti chiami?"


translate italian personalize_3feba10d:


    grace "Va bene [name]."


translate italian personalize_87cd1f22:


    grace "Oh! Vedo che hai acquistato la mod Walkthrough!"


translate italian personalize_b411b168:


    grace "Voglio ringraziarvi per il vostro supporto e spero che possiate godere appieno dell'esperienza BEST!"


translate italian personalize_90c2145d:


    grace "Se è la prima volta che entri qui, ti consiglio di disattivarlo e di fare le scelte che preferisci."


translate italian personalize_ed2ea51d:


    grace "Ma il gioco è tuo, quindi le scelte sono tue!"


translate italian personalize_ea3f8080:


    grace "Prima di iniziare, vorrei sapere che tipo di persona sei, [name]."


translate italian personalize_d86da4f2:


    grace "Ok, Ruby non vede l'ora di incontrarti!"


translate italian personalize_ac389665:


    grace "Bene, ho tutto ciò di cui ho bisogno."


translate italian personalize_e554c344:


    grace "Dovresti conoscere Gabriella! Le piace avere buoni studenti nella sua classe."


translate italian personalize_ac389665_1:


    grace "Bene, ho tutto ciò di cui ho bisogno."


translate italian personalize_a8616aea:


    grace "Hmmm... dovresti venire con me in piscina. Voglio vedere le tue mosse!"


translate italian personalize_ac389665_2:


    grace "Bene, ho tutto ciò di cui ho bisogno."


translate italian personalize_c3c37204:


    grace "Arrivederci!"


translate italian personalize_5af586fe:


    grace "Oh? Beh, forse tu e le gemelle andrete d'accordo..."


translate italian personalize_ac389665_3:


    grace "Bene, ho tutto ciò di cui ho bisogno."


translate italian personalize_c3c37204_1:


    grace "Arrivederci!"


translate italian intro_ea6a1d93:


    ji "Cazzo! Umm... mi mancherai!"


translate italian intro_7c65b928:


    "Questa è Elise."


translate italian intro_bcafb91f:


    "Lei è la mia amica... con dei benefici, come si dice."


translate italian intro_c41004be:


    "Ci vediamo ormai da diversi mesi."


translate italian intro_064e378f:


    "In realtà c'è una sola regola."


translate italian intro_89ca4f05:


    "Senza obblighi."


translate italian intro_1f193dfc:


    "Accidenti... mi mancherà quel culo."


translate italian intro_305a78d2:


    eli "Sarebbe meglio che tornassi presto da me..."


translate italian intro_8cab892c:


    eli "Lo giuro, [name], faresti meglio a tornare in fretta, mmmm..."


translate italian intro_eac5df1a:


    eli "Spero che troverai qualche ragazza con cui... ahhh... esplorare!"


translate italian intro_ad43f96e:


    eli "Incontrerai nuove ragazze e... ahhhh... vivrai nuove esperienze...."


translate italian intro_1aea961b:


    eli "E io... ahhhhhh.... voglio vedere i risultati non appena tornerai!"


translate italian intro_6c492beb:


    eli "Unhh.... sei il migliore..."


translate italian intro_1de5010f:


    ji "Cazzo! Unhh... Mi mancherà il tuo cazzo!"


translate italian intro_7c65b928_1:


    "Questa è Elise."


translate italian intro_bcafb91f_1:


    "Lei è la mia amica... con dei benefici, come si dice."


translate italian intro_6d670d0e:


    "Ci vediamo ormai da diversi mesi."


translate italian intro_064e378f_1:


    "In realtà c'è una sola regola."


translate italian intro_89ca4f05_1:


    "Senza obblighi."


translate italian intro_1f193dfc_1:


    "Accidenti... mi mancherà quel culo."


translate italian intro_305a78d2_1:


    eli "Sarebbe meglio che tornassi presto da me..."


translate italian intro_8cab892c_1:


    eli "Lo giuro, [name], faresti meglio a tornare in fretta, mmmm..."


translate italian intro_eac5df1a_1:


    eli "Spero che troverai qualche ragazza con cui... ahhh... esplorare!"


translate italian intro_ad43f96e_1:


    eli "Incontrerai nuove ragazze e... ahhhh... vivrai nuove esperienze...."


translate italian intro_1aea961b_1:


    eli "E io... ahhhhhh.... voglio vedere i risultati non appena tornerai!"


translate italian intro_6c492beb_1:


    eli "Unhh.... sei il migliore..."


translate italian intro_f1f9f153:


    eli "Ah... ahhhh... ahhh..."


translate italian intro_477f6abf:


    eli "Hnghhhh..."


translate italian intro_90929d09:


    d "Ahhhhhhhh! Così buono!"


translate italian intro_73f7f8be:


    eli "Unhhh.... sei il migliore..."


translate italian presentation_712108b3:


    dpense "Questo sono io."


translate italian presentation_17f39f37:


    dpense "Vengo dalla Francia e andrò negli Stati Uniti per studiare."


translate italian presentation_f0b7f0a4:


    dpense "Il mio inglese è accettabile, ma sono ben lungi dall'essere perfetto. Faccio qualche errore e gli altri non si preoccupano di dirmelo quando lo faccio..."


translate italian presentation_d7cb2ac4:


    dpense "Verrò negli Stati Uniti per un programma di scambio di sei mesi."


translate italian presentation_bae9b014:


    dpense "Studio Marketing ed Economia presso una prestigiosa accademia."


translate italian presentation_20aadd2e:


    dpense "Ho fatto domanda per il programma sperando di migliorare il mio inglese."


translate italian presentation_b64a060f:


    dpense "Il programma prevede di andare negli USA per sei mesi, partecipare allo stile di vita dell'accademia e tornare con un certificato. Sembrava abbastanza semplice."


translate italian presentation_e5e4c3cb:


    dpense "È successo tutto così in fretta."


translate italian presentation_43721bcf:


    dpense "Un giorno ero in Francia con i miei amici e la mia famiglia."


translate italian presentation_65a1e9f9:


    dpense "E il giorno dopo,"


translate italian presentation_8103b4af:


    dpense "Verso l'America!"

translate italian strings:


    old "Yes, of course I'm in!"
    new "Sì, certo che ci sono!"


    old "Not for me, thanks. Ciao!"
    new "Non per me, grazie. Ciao!"


    old "I'm a good friend, always there for others.[TEMP1!t]"
    new "Sono un buon amico, sempre disponibile per gli altri.[TEMP1!t]"


    old "I'm a good student, serious and calm.[TEMP2!t]"
    new "Sono un bravo studente, serio e calmo.[TEMP2!t]"


    old "I'm a sports junkie, and I'm always hitting the gym![TEMP3!t]"
    new "Sono un fanatico dello sport e vado sempre in palestra![TEMP3!t]"


    old "I'm a ladies man, a regular Don Juan or Casanova. [TEMP4!t]"
    new "Sono un dongiovanni, un vero Don Giovanni o Casanova. [TEMP4!t]"







translate italian personalize_e50176b2:


    grace "Durante la partita, con la mod attivata, vedrai alcune icone come questa:"





translate italian personalize_33cf37a1:


    grace "Ciò significa che è l'opzione \"migliore\" da scegliere."





translate italian personalize_c294014b:


    grace "Vedrai altre icone come questa:"





translate italian personalize_78f90f44:


    grace "Ciò significa che guadagnerai un punto in questa statistica."





translate italian personalize_ead4d56d:


    grace "Infine vedrete alcune icone di ragazze come la mia:"





translate italian personalize_a6c03977:


    grace "Ciò significa che questa scelta è necessaria per proseguire il cammino di questa ragazza."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
