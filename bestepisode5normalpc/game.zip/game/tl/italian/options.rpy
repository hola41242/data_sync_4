
translate italian strings:


    old "B.E.S.T"
    new "B.E.S.T"









translate italian strings:


    old "Credits for music : (Source: https://soundcloud.com //Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nCredits for Scripts :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio // Italian Translation : Eagle1900 // Russian Translation : Pretender // Chinese Translation : V\n\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
    new "Crediti per la musica: (Fonte: https://soundcloud.com //Licenza: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):  \n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Frammenti NovaNoma - Gaia Pachyderm - Non mi conoscevo affatto PhilippWeigl - Suddivisione delle masse PunchDeck - Rexlambo destabilizzato - Resta con me Sacrificio - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\n Crediti per gli script:\n\nBadMustard per salvataggi e gallerie // Elckarow per il telefono // Angel Seraph per i risultati\n\nTraduzione inglese: SaintBlackMoor // Traduzione spagnola: Mustadio // Traduzione italiana: Eagle1900 / / Traduzione russa: Pretender // Traduzione cinese: V\n\nCon i preziosi consigli di Drooskati, UncleNanard e SecretGame"



translate italian strings:


    old "Credits for music : (Source: https://soundcloud.com //Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nCredits for Scripts :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio // Italian Translation : Eagle1900 // Russian Translation : Pretender // Chinese Translation : V // Portuguese Translation : Heathens\n\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
    new "Crediti per la musica: (Fonte: https://soundcloud.com //Licenza: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com): \n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Frammenti NovaNoma - Gaia Pachyderm - Non mi conoscevo affatto PhilippWeigl - Suddivisione delle masse PunchDeck - Rexlambo destabilizzato - Resta con me Sacrificio - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\n Crediti per gli script:\n\nBadMustard per salvataggi e gallerie // Elckarow per il telefono // Angel Seraph per i risultati\n\nTraduzione inglese: SaintBlackMoor // Traduzione spagnola: Mustadio // Traduzione italiana: Eagle1900 / / Traduzione russa: Pretender // Traduzione cinese: V // Traduzione portoghese: Heathens\n\nCon i preziosi consigli di Drooskati, UncleNanard e SecretGame"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
