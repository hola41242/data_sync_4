
translate italian strings:


    old "Hidden Achievement"
    new "Obiettivo nascosto"





translate italian strings:


    old "Achievements | {:01d}/{}"
    new "Risultati | {:01d}/{}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
