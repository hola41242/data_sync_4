

translate italian strings:


    old "Self-voicing disabled."
    new "Self-voicing disabilitata."


    old "Clipboard voicing enabled. "
    new "Votazione degli appunti attivata."


    old "Self-voicing enabled. "
    new "Self-voicing abilitata."


    old "bar"
    new "barra"


    old "selected"
    new "selezionato"


    old "viewport"
    new "finestra di visualizzazione"


    old "horizontal scroll"
    new "scorrimento orizzontale"


    old "vertical scroll"
    new "scorrimento verticale"


    old "activate"
    new "attivato"


    old "deactivate"
    new "disattivato"


    old "increase"
    new "aumenta"


    old "decrease"
    new "diminuisci"


    old "Font Override"
    new "Sovrascrittura dei caratteri"


    old "Default"
    new "Predefinito"


    old "DejaVu Sans"
    new "DejaVu Sans"


    old "Opendyslexic"
    new "Opendyslexic"


    old "Text Size Scaling"
    new "Dimensione testo in scala"


    old "Reset"
    new "Azzeramento"


    old "Line Spacing Scaling"
    new "Scala dell'interlinea"


    old "High Contrast Text"
    new "Testo ad alto contrasto"


    old "Enable"
    new "Abilitato"


    old "Self-Voicing"
    new "Self-voicing"


    old "Off"
    new "Disattivato"


    old "Text-to-speech"
    new "Testo a voce alta"


    old "Clipboard"
    new "Appunti"


    old "Debug"
    new "Debug"


    old "Self-Voicing Volume Drop"
    new "Volume Self-Voicing"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Le opzioni di questo menu hanno lo scopo di migliorare l'accessibilità. Potrebbero non funzionare con tutti i giochi e alcune combinazioni di opzioni potrebbero rendere il gioco ingiocabile. Non si tratta di un problema del gioco o del motore. Per ottenere i migliori risultati quando si cambiano i font, cerca di mantenere le dimensioni del testo uguali a quelle originarie."


    old "{#weekday}Monday"
    new "{#weekday}Lunedì"


    old "{#weekday}Tuesday"
    new "{#weekday}Martedì"


    old "{#weekday}Wednesday"
    new "{#weekday}Mercoledì"


    old "{#weekday}Thursday"
    new "{#weekday}Giovedì"


    old "{#weekday}Friday"
    new "{#weekday}Venerdì"


    old "{#weekday}Saturday"
    new "{#weekday}Sabato"


    old "{#weekday}Sunday"
    new "{#weekday}Domenica"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Lun"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Mar"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Mer"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Gio"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Ven"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Sab"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"


    old "{#month}January"
    new "{#month}Gennaio"


    old "{#month}February"
    new "{#month}Febbraio"


    old "{#month}March"
    new "{#month}Marzo"


    old "{#month}April"
    new "{#month}Aprile"


    old "{#month}May"
    new "{#month}Maggio"


    old "{#month}June"
    new "{#month}Giugno"


    old "{#month}July"
    new "{#month}Luglio"


    old "{#month}August"
    new "{#month}Agosto"


    old "{#month}September"
    new "{#month}Settembre"


    old "{#month}October"
    new "{#month}Ottobre"


    old "{#month}November"
    new "{#month}Novembre"


    old "{#month}December"
    new "{#month}Dicembre"


    old "{#month_short}Jan"
    new "{#month_short}Gen"


    old "{#month_short}Feb"
    new "{#month_short}Feb"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Apr"


    old "{#month_short}May"
    new "{#month_short}Mag"


    old "{#month_short}Jun"
    new "{#month_short}Giu"


    old "{#month_short}Jul"
    new "{#month_short}Lug"


    old "{#month_short}Aug"
    new "{#month_short}Ago"


    old "{#month_short}Sep"
    new "{#month_short}Set"


    old "{#month_short}Oct"
    new "{#month_short}Ott"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dic"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "Salva lo slot %s: [text]"


    old "Load slot %s: [text]"
    new "Carica lo slot %s: [text]"


    old "Delete slot [text]"
    new "Elimina lo slot [text]"


    old "File page auto"
    new "Pagina file automatica"


    old "File page quick"
    new "Pagina file veloce"


    old "File page [text]"
    new "Pagina file [text]"


    old "Next file page."
    new "Pagina del file successivo."


    old "Previous file page."
    new "Pagina precedente del file."


    old "Quick save complete."
    new "Salvataggio rapido completo."


    old "Quick save."
    new "Salvataggio rapido."


    old "Quick load."
    new "Caricamento rapido."


    old "Language [text]"
    new "Lingua [text]"


    old "Open [text] directory."
    new "Apri la directory [text]."


    old "The interactive director is not enabled here."
    new "La regia interattiva non è abilitata qui."


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "Fatto"


    old "(statement)"
    new "(dichiarazione)"


    old "(tag)"
    new "(tag)"


    old "(attributes)"
    new "(attributi)"


    old "(transform)"
    new "(trasformazione)"


    old "(transition)"
    new "(transizione)"


    old "(channel)"
    new "(canale)"


    old "(filename)"
    new "(nome del file)"


    old "Change"
    new "Modifica"


    old "Add"
    new "Aggiungi"


    old "Cancel"
    new "Annulla"


    old "Remove"
    new "Rimuovi"


    old "Statement:"
    new "Dichiarazione:"


    old "Tag:"
    new "Tag:"


    old "Attributes:"
    new "Attributi:"


    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Clicca per attivare l'attributo, clicca con il tasto destro per attivare l'attributo negativo."


    old "Transforms:"
    new "Trasformazioni:"


    old "Click to set transform, right click to add to transform list."
    new "Clicca per impostare la trasformazione, clicca con il tasto destro per aggiungerla all'elenco delle trasformazioni."


    old "Behind:"
    new "Dietro:"


    old "Click to set, right click to add to behind list."
    new "Clicca per impostare, clicca con il tasto destro per aggiungere all'elenco dei dietro."


    old "Transition:"
    new "Transizione:"


    old "Channel:"
    new "Canale:"


    old "Audio Filename:"
    new "Nome file audio:"


    old "Are you sure?"
    new "Sei sicuro?"


    old "Are you sure you want to delete this save?"
    new "Sei sicuro di voler cancellare questo salvataggio?"


    old "Are you sure you want to overwrite your save?"
    new "Sei sicuro di voler sovrascrivere il tuo salvataggio?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Il caricamento perderà i progressi non salvati.  \nSei sicuro di volerlo fare?"


    old "Are you sure you want to quit?"
    new "Sei sicuro di voler uscire?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Sei sicuro di voler tornare al menu principale? \nQuesto perderà i progressi non salvati."


    old "Are you sure you want to end the replay?"
    new "Sei sicuro di voler terminare il replay?"


    old "Are you sure you want to begin skipping?"
    new "Sei sicuro di voler iniziare a saltare?"


    old "Are you sure you want to skip to the next choice?"
    new "Sei sicuro di voler saltare alla scelta successiva?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Sei sicuro di voler saltare il dialogo non visto alla scelta successiva?"


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Questo salvataggio è stato creato su un altro dispositivo. I file di salvataggio creati male possono danneggiare il tuo computer. Ti fidi del creatore di questo salvataggio e di tutti coloro che potrebbero aver modificato il file?"


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Ti fidi del dispositivo su cui è stato creato il salvataggio? Dovresti scegliere sì solo se sei l'unico utente del dispositivo."


    old "Failed to save screenshot as %s."
    new "Impossibile salvare lo screenshot come %s."


    old "Saved screenshot as %s."
    new "Salvata schermata come %s."


    old "Skip Mode"
    new "Modalità Salto"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Questo programma contiene software libero sotto diverse licenze, tra cui la MIT License e la GNU Lesser General Public License. Un elenco completo del software, con i link al codice sorgente completo, è disponibile {a=https://www.renpy.org/l/license}qui{/a}."


    old "display"
    new "visualizzazione"


    old "transitions"
    new "transizioni"


    old "skip transitions"
    new "saltare le transizioni"


    old "video sprites"
    new "sprite video"


    old "show empty window"
    new "mostra finestra vuota"


    old "text speed"
    new "velocità del testo"


    old "joystick"
    new "joystick"


    old "joystick..."
    new "joystick..."


    old "skip"
    new "salta"


    old "skip unseen [text]"
    new "salta il testo non visto [text]"


    old "skip unseen text"
    new "salta il testo non visto"


    old "begin skipping"
    new "inizia a saltare"


    old "after choices"
    new "dopo le scelte"


    old "skip after choices"
    new "salta dopo le scelte"


    old "auto-forward time"
    new "Avanzamento automatico"


    old "auto-forward"
    new "auto-avanzamento"


    old "Auto forward"
    new "Avanzamento automatico"


    old "auto-forward after click"
    new "avanzamento automatico dopo il clic"


    old "automatic move"
    new "spostamento automatico"


    old "wait for voice"
    new "aspetta la voce"


    old "voice sustain"
    new "voce sostenuta"


    old "self voicing"
    new "self voicing"


    old "self voicing volume drop"
    new "calo del volume con auto-voto"


    old "clipboard voicing"
    new "voicing degli appunti"


    old "debug voicing"
    new "debug voicing"


    old "emphasize audio"
    new "enfatizzare l'audio"


    old "rollback side"
    new "rollback laterale"


    old "gl powersave"
    new "gl powersave"


    old "gl framerate"
    new "gl framerate"


    old "gl tearing"
    new "gl tearing"


    old "font transform"
    new "trasformazione dei caratteri"


    old "font size"
    new "dimensione del carattere"


    old "font line spacing"
    new "interlinea del font"


    old "system cursor"
    new "cursore di sistema"


    old "renderer menu"
    new "menu del renderer"


    old "accessibility menu"
    new "menu accessibilità"


    old "high contrast text"
    new "testo ad alto contrasto"


    old "audio when minimized"
    new "audio quando è ridotto a icona"


    old "audio when unfocused"
    new "audio quando non viene messo a fuoco"


    old "web cache preload"
    new "precaricamento della cache web"


    old "voice after game menu"
    new "voce dopo il menu di gioco"


    old "main volume"
    new "volume principale"


    old "music volume"
    new "volume della musica"


    old "sound volume"
    new "volume del suono"


    old "voice volume"
    new "volume della voce"


    old "mute main"
    new "Disattiva l'audio principale"


    old "mute music"
    new "Disattiva la musica"


    old "mute sound"
    new "Disattiva il suono"


    old "mute voice"
    new "Disattiva la voce"


    old "mute all"
    new "Disattiva tutto"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Appunti vocali abilitati. Premi 'shift+C' per disabilitarla."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Self-voicing direbbe '[renpy.display.tts.last]'. Premi 'alt+shift+V' per disattivarla."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Self-voicing attivata. Premi 'v' per disabilitarla."


    old "Speech Bubble Editor"
    new "Editor delle bolle vocali"


    old "(hide)"
    new "(nascondi)"


    old "Sync downloaded."
    new "Sincronizzazione scaricata."


    old "Could not connect to the Ren'Py Sync server."
    new "Impossibile connettersi al server Ren'Py Sync."


    old "The Ren'Py Sync server timed out."
    new "Il server Ren'Py Sync è scaduto."


    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Si è verificato un errore sconosciuto durante la connessione al server Ren'Py Sync."


    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "Il server Ren'Py Sync non ha una copia di questo sync. L'ID di sincronizzazione potrebbe non essere valido o potrebbe essere scaduto."


    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Inserisci l'ID di sincronizzazione che hai generato. \nNon inserire mai un ID di sincronizzazione che non hai creato tu stesso."


    old "The sync ID is not in the correct format."
    new "L'ID di sincronizzazione non è nel formato corretto."


    old "The sync could not be decrypted."
    new "Non è stato possibile decifrare la sincronizzazione."


    old "The sync belongs to a different game."
    new "La sincronizzazione appartiene a un altro gioco."


    old "The sync contains a file with an invalid name."
    new "La sincronizzazione contiene un file con un nome non valido."


    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Questa operazione caricherà i tuoi salvataggi sul {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nVuoi continuare?"


    old "Enter Sync ID"
    new "Inserisci l'ID di sincronizzazione"


    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "In questo modo contatterai il {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."


    old "Sync Success"
    new "Successo della sincronizzazione"


    old "The Sync ID is:"
    new "L'ID di sincronizzazione è:"


    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Puoi usare questo ID per scaricare i tuoi salvataggi su un altro dispositivo.\nQuesta sincronizzazione scadrà tra un'ora.\nRen'Py Sync è supportato dagli {a=https://www.renpy.org/sponsors.html}Sponsor di Ren'Py{/a}."


    old "Continue"
    new "Continua"


    old "Sync Error"
    new "Errore di sincronizzazione"


    old "Contacting App Store\nPlease Wait..."
    new "Contatto con l'App Store\nPer favore aspetta..."


    old "The Ren'Py Updater is not supported on mobile devices."
    new "L'Updater di Ren'Py non è supportato dai dispositivi mobili."


    old "An error is being simulated."
    new "È stato simulato un errore."


    old "Either this project does not support updating, or the update status file was deleted."
    new "Questo progetto non supporta l'aggiornamento oppure il file di stato dell'aggiornamento è stato cancellato."


    old "This account does not have permission to perform an update."
    new "Questo account non ha i permessi per eseguire un aggiornamento."


    old "This account does not have permission to write the update log."
    new "Questo account non ha i permessi per scrivere il registro degli aggiornamenti."


    old "Could not verify update signature."
    new "Impossibile verificare la firma dell'aggiornamento."


    old "The update file was not downloaded."
    new "Il file di aggiornamento non è stato scaricato."


    old "The update file does not have the correct digest - it may have been corrupted."
    new "Il file di aggiornamento non ha il digest corretto: potrebbe essere stato danneggiato."


    old "While unpacking {}, unknown type {}."
    new "Durante la decompressione di {}, tipo sconosciuto {}."


    old "Updater"
    new "Aggiornamenti"


    old "An error has occured:"
    new "Si è verificato un errore:"


    old "Checking for updates."
    new "Verifica aggiornamenti."


    old "This program is up to date."
    new "Questo programma è aggiornato."


    old "[u.version] is available. Do you want to install it?"
    new "[u.version] è disponibile. Vuoi installarlo?"


    old "Preparing to download the updates."
    new "Preparazione al download degli aggiornamenti."


    old "Downloading the updates."
    new "Scaricare gli aggiornamenti."


    old "Unpacking the updates."
    new "Scompattare gli aggiornamenti."


    old "Finishing up."
    new "Conclusione."


    old "The updates have been installed. The program will restart."
    new "Gli aggiornamenti sono stati installati. Il programma si riavvia."


    old "The updates have been installed."
    new "Gli aggiornamenti sono stati installati."


    old "The updates were cancelled."
    new "Gli aggiornamenti sono stati annullati."


    old "Proceed"
    new "Procedere"


    old "Image [index] of [count] locked."
    new "Immagine [index] di [count] bloccata."


    old "prev"
    new "precedente"


    old "next"
    new "successivo"


    old "slideshow"
    new "slideshow"


    old "return"
    new "ritorno"


    old "Renderer"
    new "Renderer"


    old "Automatically Choose"
    new "Scegliere automaticamente"


    old "Force GL Renderer"
    new "Forza il rendering GL"


    old "Force ANGLE Renderer"
    new "Forza il rendering ANGLE"


    old "Force GLES Renderer"
    new "Forza il rendering GLES"


    old "Force GL2 Renderer"
    new "Rendering Forza GL2"


    old "Force ANGLE2 Renderer"
    new "Rendering Force ANGLE2"


    old "Force GLES2 Renderer"
    new "Forza il rendering GLES2"


    old "Enable (No Blocklist)"
    new "Abilita (senza lista di blocco)"


    old "Powersave"
    new "Powersave"


    old "Framerate"
    new "Framerate"


    old "Screen"
    new "Schermo"


    old "60"
    new "60"


    old "30"
    new "30"


    old "Tearing"
    new "Strappo"


    old "Changes will take effect the next time this program is run."
    new "Le modifiche avranno effetto alla successiva esecuzione del programma."


    old "Performance Warning"
    new "Avviso sulle prestazioni"


    old "This computer is using software rendering."
    new "Questo computer utilizza il rendering software."


    old "This game requires use of GL2 that can't be initialised."
    new "Questo gioco richiede l'uso di GL2 che non può essere inizializzato."


    old "This computer has a problem displaying graphics: [problem]."
    new "Questo computer ha un problema di visualizzazione della grafica: [problem]."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "I driver grafici potrebbero non essere aggiornati o non funzionare correttamente. Questo può portare a una visualizzazione lenta o non corretta della grafica."


    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "Il file {a=edit:1:log.txt}log.txt{/a} può contenere informazioni che ti aiutano a determinare il problema del computer."


    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Maggiori dettagli su come risolvere il problema sono disponibili nella {a=[url]}documentazione{/a}."


    old "Continue, Show this warning again"
    new "Continua, Mostra di nuovo questo avviso"


    old "Continue, Don't show warning again"
    new "Continua, Non mostrare di nuovo l'avviso"


    old "Change render options"
    new "Cambia le opzioni di rendering"


    old "Select Gamepad to Calibrate"
    new "Seleziona il Gamepad da calibrare"


    old "No Gamepads Available"
    new "Nessun Gamepad disponibile"


    old "Calibrating [name] ([i]/[total])"
    new "Calibrazione di [name] ([i]/[total])"


    old "Press or move the '[control!s]' [kind]."
    new "Premi o sposta il tasto '[control!s]' [kind]."


    old "Skip (A)"
    new "Salta (A)"


    old "Back (B)"
    new "Indietro (B)"


    old "Open"
    new "Aprire"


    old "Opens the traceback.txt file in a text editor."
    new "Apre il file traceback.txt in un editor di testo."


    old "Copy BBCode"
    new "Copia il codice BBC"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia il file traceback.txt negli appunti come BBcode per i forum come https://lemmasoft.renai.us/."


    old "Copy Markdown"
    new "Copia Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia il file traceback.txt negli appunti come Markdown per Discord."


    old "An exception has occurred."
    new "Si è verificata un'eccezione."


    old "Rollback"
    new "Rollback"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Tenta un rollback a un momento precedente, consentendoti di salvare o di scegliere un'altra opzione."


    old "Ignore"
    new "Ignora"


    old "Ignores the exception, allowing you to continue."
    new "Ignora l'eccezione e ti permette di continuare."


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora l'eccezione e ti permette di continuare. Questo spesso porta a ulteriori errori."


    old "Reload"
    new "Ricarica"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Ricarica il gioco dal disco, salvando e ripristinando lo stato del gioco, se possibile."


    old "Console"
    new "Console"


    old "Opens a console to allow debugging the problem."
    new "Apre una console per consentire il debug del problema."


    old "Quits the game."
    new "Abbandona il gioco."


    old "Parsing the script failed."
    new "L'analisi dello script non è riuscita."













translate italian strings:


    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Menù di accessibilità. Utilizza le frecce su e giù per navigare e Invio per attivare pulsanti e barre."


    old "Customize director.transforms to add more transforms."
    new "Personalizza director.transforms per aggiungere più trasformazioni."


    old "Click to set."
    new "Fare clic per impostare."


    old "Customize director.transitions to add more transitions."
    new "Personalizza director.transitions per aggiungere più transizioni."


    old "Customize director.audio_channels to add more channels."
    new "Personalizza director.audio_channels per aggiungere più canali."


    old "Are you sure you want to continue where you left off?"
    new "Sei sicuro di voler continuare da dove avevi interrotto?"


    old "self voicing enable"
    new "abilitare l'auto-voce"


    old "self voicing disable"
    new "disabilitazione della voce automatica"


    old "clipboard voicing enable"
    new "abilitazione della voce negli appunti"


    old "clipboard voicing disable"
    new "disabilitazione della voce negli appunti"


    old "debug voicing enable"
    new "abilitare il debug della voce"


    old "debug voicing disable"
    new "eseguire il debug della disabilitazione della voce"


    old "restore window position"
    new "ripristinare la posizione della finestra"


    old "reset"
    new "Ripristina"


    old "(clear retained bubbles)"
    new "(bolle trasparenti trattenute)"


    old "No update methods found."
    new "Nessun metodo di aggiornamento trovato."


    old "Could not download file list: "
    new "Impossibile scaricare l'elenco dei file:"


    old "File list digest does not match."
    new "Il digest dell'elenco dei file non corrisponde."


    old "Preparing to download the game data."
    new "Preparazione al download dei dati di gioco."


    old "Downloading the game data."
    new "Download dei dati di gioco."


    old "The game data has been downloaded."
    new "I dati del gioco sono stati scaricati."


    old "An error occured when trying to download game data:"
    new "Si è verificato un errore durante il tentativo di scaricare i dati di gioco:"


    old "This game cannot be run until the game data has been downloaded."
    new "Questo gioco non può essere eseguito finché i dati del gioco non sono stati scaricati."


    old "Retry"
    new "Riprova"







translate italian strings:


    old "Self-voicing support is limited when using a touch screen."
    new "Il supporto della voce automatica è limitato quando si utilizza un touch screen."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
