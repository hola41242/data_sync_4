

translate italian strings:

    old "Back"
    new "Indietro"

    old "History"
    new "Storia"

    old "{size=+20}{color=#f00}Auto{/color}{/size}"
    new "{size=+20}{color=#f00}Auto{/color}{/size}"

    old "Save"
    new "Salva"

    old "Q.Save"
    new "Q.Salva"

    old "Q.Load"
    new "Q.Carica"

    old "Prefs"
    new "Prefs"

    old "Start"
    new "Inizio"

    old "Load"
    new "Carica"

    old "Preferences"
    new "Preferenze"

    old "End Replay"
    new "Fine Replay"

    old "Main Menu"
    new "Menù principale"

    old "About"
    new "Info"

    old "Help"
    new "Aiuto"

    old "Quit"
    new "Esci"

    old "Version [config.version!t]\n"
    new "Versione [config.version!t]\n"

    old "Page {}"
    new "Page {}"

    old "Automatic saves"
    new "Salvataggi automatici"

    old "Quick saves"
    new "Salvataggi rapidi"

    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    old "empty slot"
    new "slot vuoto"

    old "<"
    new "<"

    old "{#auto_page}A"
    new "{#auto_page}A"

    old "{#quick_page}Q"
    new "{#quick_page}Q"

    old ">"
    new ">"

    old "Display"
    new "Visualizza"

    old "Window"
    new "Finestra"

    old "Fullscreen"
    new "Schermo intero"

    old "Rollback Side"
    new "Rollback laterale"

    old "Disable"
    new "Disabilitato"

    old "Left"
    new "Sinistra"

    old "Right"
    new "Destra"

    old "Unseen Text"
    new "Testo non visto"

    old "After Choices"
    new "Dopo le scelte"

    old "Transitions"
    new "Transizioni"

    old "Language"
    new "Lingua"

    old "Text Speed"
    new "Velocità del testo"

    old "Auto-Forward Time"
    new "Avanzamento automatico"

    old "Music Volume"
    new "Volume della musica"

    old "Sound Volume"
    new "Volume del suono"

    old "Test"
    new "Test"

    old "Voice Volume"
    new "Volume della voce"

    old "Mute All"
    new "Disattiva tutti"

    old "The dialogue history is empty."
    new "La cronologia dei dialoghi è vuota."

    old "Keyboard"
    new "Tastiera"

    old "Mouse"
    new "Mouse"

    old "Gamepad"
    new "Gamepad"

    old "Enter"
    new "Invio"

    old "Advances dialogue and activates the interface."
    new "Fa avanzare il dialogo e attiva l'interfaccia."

    old "Space"
    new "Spazio"

    old "Advances dialogue without selecting choices."
    new "Fa avanzare il dialogo senza selezionare le scelte."

    old "Arrow Keys"
    new "Tasti freccia"

    old "Navigate the interface."
    new "Navigano nell'interfaccia."

    old "Escape"
    new "Esc"

    old "Accesses the game menu."
    new "Accede al menu di gioco."

    old "Ctrl"
    new "Ctrl"

    old "Skips dialogue while held down."
    new "Salta i dialoghi quando viene tenuto premuto."

    old "Tab"
    new "Tab"

    old "Toggles dialogue skipping."
    new "Alterna il salto dei dialoghi."

    old "Page Up"
    new "Pagina su"

    old "Rolls back to earlier dialogue."
    new "Torna al dialogo precedente."

    old "Page Down"
    new "Pagina giù"

    old "Rolls forward to later dialogue."
    new "Passa al dialogo successivo."

    old "Hides the user interface."
    new "Nasconde l'interfaccia utente."

    old "Takes a screenshot."
    new "Fa uno screenshot."

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Attiva/disattiva l'{a=https://www.renpy.org/l/voicing}assistente vocale{/a}."

    old "Left Click"
    new "Clic sinistro"

    old "Middle Click"
    new "Clic medio"

    old "Right Click"
    new "Clic destro"

    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rotella del mouse su\nClick Rollback laterale"

    old "Mouse Wheel Down"
    new "Rotella del mouse verso il basso"

    old "Right Trigger\nA/Bottom Button"
    new "Pulsante destro\nA/Tasto inferiore"

    old "Left Trigger\nLeft Shoulder"
    new "Pulsante sinistro\nSpalla sinistra"

    old "Right Shoulder"
    new "Spalla destra"

    old "D-Pad, Sticks"
    new "D-Pad, Stick"

    old "Start, Guide"
    new "Avvio, Guida"

    old "Y/Top Button"
    new "Pulsante Y/Alto"

    old "Calibrate"
    new "Calibra"

    old "Yes"
    new "Si"

    old "No"
    new "No"

    old "Skipping"
    new "Saltare"

    old "Auto"
    new "Auto"

    old "Menu"
    new "Menù"




translate italian strings:


    old "Achievements"
    new "Risultati"


    old "Gallery"
    new "Galleria"


    old "Return"
    new "Ritorno"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Realizzato con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"


    old "Save Name"
    new "Salva nome"


    old "{u}Save the Game{/u}"
    new "{u}Salva la partita{/u}"


    old "Skip"
    new "Salta"


    old "English"
    new "Inglese"


    old "Français"
    new "Francese"


    old "Streaming Mode"
    new "Modalità di streaming"


    old "ON"
    new "ON"


    old "OFF"
    new "OFF"


    old "Walkthrough"
    new "Procedura dettagliata"


    old "Textbox Transparency"
    new "Trasparenza della casella di testo"


    old "Opens the accessibility menu."
    new "Apre il menu di accessibilità."




translate italian strings:


    old "Espanol"
    new "Espanol"


    old "Russian"
    new "Russian"


    old "Italian"
    new "Italiano"



translate italian strings:


    old "S.Chinese"
    new "S.Cinese"


    old "T.Chinese"
    new "T.Cinese"







translate italian strings:


    old "Portuguese"
    new "portoghese"











translate italian strings:


    old "Name Save ?"
    new "Nome Salva ?"


    old "Save game names"
    new "Salva i nomi dei giochi"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
