


translate korean before_main_menu_0888dd09:


    ji ""


translate korean before_main_menu_59c2a0d0:


    ji ""


translate korean before_main_menu_bcb0d6ab:


    ji ""


translate korean before_main_menu_261c3b79:


    ji ""


translate korean suitepres_f99b1c93:


    ji ""


translate korean suitepres_d5e7ada9:


    ji ""


translate korean suitepres_78b7a38d:


    ji ""


translate korean suitepres_38165d90:


    ji ""


translate korean suitepres2_71fd6753:


    ji ""


translate korean suitepres2_aab9f523:


    cr ""


translate korean suitepres2_af0bf494:


    cr ""


translate korean suitepres2_5d1f2386:


    cr ""


translate korean suitepres2_dfcdecc4:


    ji ""


translate korean suitepres2_fa65479d:


    ji ""


translate korean suitepres2_edddd53b:


    ji ""


translate korean suitepres2_e4d27473:


    ji ""


translate korean suitepres2_b4f250c1:


    ji ""


translate korean suitepres2_56dc38b0:


    cr ""


translate korean suitepres2_97160162:


    ji ""


translate korean suitepres2_a8bece05:


    cr ""


translate korean suitepres2_dade9dd7:


    ji ""


translate korean suitepres2_4c16d8a9:


    ji ""


translate korean suitepres2_dade9dd7_1:


    ji ""


translate korean suitepres2_4c16d8a9_1:


    ji ""


translate korean start_440c063c:


    centered ""


translate korean start_7f136763:


    centered ""


translate korean start_1f3237c5:


    centered ""


translate korean start_78d2440b:


    centered ""


translate korean start_510cdb0b:


    centered ""


translate korean personalize_9f250a0a:


    grace ""


translate korean personalize_f9746723:


    grace ""


translate korean personalize_ab9d0756:


    grace ""


translate korean personalize_0452e6be:


    grace ""


translate korean personalize_f658dbf2:


    grace ""


translate korean personalize_7945cae0:


    grace ""


translate korean personalize_b252f0e1:


    grace ""


translate korean personalize_f1f8fdf0:


    grace ""


translate korean personalize_1d84f494:


    grace ""


translate korean personalize_288577ac:


    grace ""


translate korean personalize_3edd6ed2:


    grace ""


translate korean personalize_a2e34685:


    grace ""


translate korean personalize_288577ac_1:


    grace ""


translate korean personalize_3edd6ed2_1:


    grace ""


translate korean personalize_7198e88c:


    grace ""


translate korean personalize_288577ac_2:


    grace ""


translate korean personalize_3edd6ed2_2:


    grace ""


translate korean personalize_e7275600:


    grace ""


translate korean personalize_288577ac_3:


    grace ""


translate korean personalize_3edd6ed2_3:


    grace ""


translate korean intro_6bd1d991:


    ji ""


translate korean intro_fb8a1e5a:


    ""


translate korean intro_98e35350:


    ""


translate korean intro_88e66fc8:


    ""


translate korean intro_8915e2ac:


    ""


translate korean intro_87dc8d9b:


    ""


translate korean intro_484019c5:


    ""


translate korean intro_f598880b:


    eli ""


translate korean intro_5864ee29:


    eli ""


translate korean intro_23f7ffe5:


    eli ""


translate korean intro_6c259796:


    eli ""


translate korean intro_5c0e76f8:


    d ""


translate korean intro_a805da84:


    eli ""


translate korean intro_5e07a779:


    eli ""


translate korean intro_274d889e:


    eli ""


translate korean intro_0ff4aa8e:


    ji ""


translate korean intro_0ae9bcd0:


    ""


translate korean intro_fb8a1e5a_1:


    ""


translate korean intro_98e35350_1:


    ""


translate korean intro_88e66fc8_1:


    ""


translate korean intro_8915e2ac_1:


    ""


translate korean intro_87dc8d9b_1:


    ""


translate korean intro_484019c5_1:


    ""


translate korean intro_f598880b_1:


    eli ""


translate korean intro_5864ee29_1:


    eli ""


translate korean intro_23f7ffe5_1:


    eli ""


translate korean intro_6c259796_1:


    eli ""


translate korean intro_5c0e76f8_1:


    d ""


translate korean intro_a805da84_1:


    eli ""


translate korean intro_5e07a779_1:


    eli ""


translate korean intro_9bf13e71:


    eli ""


translate korean intro_f2d0e4ee:


    eli ""


translate korean intro_ba92a9c5:


    d ""


translate korean intro_274d889e_1:


    eli ""


translate korean presentation_29b2cf68:


    dpense ""


translate korean presentation_7f0d6adc:


    dpense ""


translate korean presentation_394d75ae:


    dpense ""


translate korean presentation_59049871:


    dpense ""


translate korean presentation_e4e86c7f:


    dpense ""


translate korean presentation_8ca20e6f:


    dpense ""


translate korean presentation_294714e5:


    dpense ""


translate korean presentation_84607db8:


    dpense ""


translate korean presentation_16d55cb7:


    dpense ""


translate korean presentation_57251b7a:


    dpense ""


translate korean presentation_fe665c28:


    dpense ""


translate korean presentation_f9f78803:


    dpense ""

translate korean strings:


    old "You"
    new ""


    old "Press click to continue"
    new ""


    old "Yes"
    new ""


    old "No"
    new ""


    old "Yes, of course I'm in!!!"
    new ""


    old "So boring... Ciao!"
    new ""


    old "Your First Name?"
    new ""


    old "Enable Walkthrough"
    new ""


    old "Disable Walkthrough"
    new ""


    old "I'm a good friend, always there for others...[TEMP1!t]"
    new ""


    old "I'm a good student, serious and calm...[TEMP2!t]"
    new ""


    old "I'm a sport addict, DAMN![TEMP3!t]"
    new ""


    old "I'm a Don Juan, girls everywhere, everytime...[TEMP4!t]"
    new ""


    old "New Scene Gallery added"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
