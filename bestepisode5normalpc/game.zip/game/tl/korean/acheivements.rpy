

translate korean strings:


    old "You have entered the B.E.S.T Game"
    new "당신은 B.E.S.T 게임에 입장했습니다"


    old "Start the game"
    new ""


    old "What an ass!"
    new ""


    old "Grope Julia"
    new ""


    old "Cotton Eye Joe !"
    new ""


    old "Don't touch Julia"
    new ""


    old "Catch them all!"
    new ""


    old "Catch Grace"
    new ""


    old "Life in redhead !"
    new ""


    old "You've put Grace on her bed"
    new ""


    old "Show must go on !"
    new ""


    old "Finish the Prologue"
    new ""


    old "Pinky and the Braid!"
    new ""


    old "Play the Minus and Cortex game"
    new ""


    old "You are the winner!"
    new ""


    old "Finish First with Madison ?"
    new ""


    old "You deserve it!"
    new ""


    old "Accept the reward"
    new ""


    old "You're not first meh!"
    new ""


    old "Accept the Special Reward"
    new ""


    old "First !!!"
    new ""


    old "Finish the First Episode"
    new ""


    old "Outstanding!"
    new ""


    old "Get all achievements."
    new ""


    old "Victory !!!"
    new ""


    old "Win versus Grace"
    new ""


    old "Cheater !!!"
    new ""


    old "Cheat versus Grace"
    new ""


    old "Day of Defeat !!!"
    new ""


    old "You let Grace win... Right ?"
    new ""


    old "Evolution !!!"
    new ""


    old "From Squirtle to Squirter"
    new ""


    old "Her hero!!!"
    new ""


    old "You're Ruby's Hero..."
    new ""


    old "Hat Trick !!!"
    new ""


    old "All for Madison !"
    new ""


    old "Harem Vibes!!!"
    new ""


    old "Women likes you..."
    new ""


    old "First Kiss!!!"
    new ""


    old "Grace for ever !"
    new ""


    old "Of course!!!"
    new ""


    old "Madison..."
    new ""


    old "Just the Beginning!"
    new ""


    old "Finish the Second Episode"
    new ""


    old "You tried..."
    new ""


    old "Meh..."
    new ""


    old "You're a genius!!!"
    new ""


    old "But unknown..."
    new ""


    old "Milfs are life!!!"
    new ""


    old "Better with experience..."
    new ""


    old "Like a virgin!"
    new ""


    old "Touch for the very first time..."
    new ""


    old "You switched!"
    new ""


    old "From Blue to Red..."
    new ""


    old "Road to Victory!"
    new ""


    old "Finish the Third Episode"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
