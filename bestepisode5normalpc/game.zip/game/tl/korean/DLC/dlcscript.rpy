

translate korean strings:


    old "{size=-5}{color=#2b33b5}\nBUDDY+1"
    new ""


    old "{size=-5}{color=#2b33b5}EDUC+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nSPORT+1"
    new ""


    old "{size=-5}{color=#2b33b5}TEMP+1\nELISE's SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\nTEMP+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nEDUC+1\nRED's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nMADISON's PATH\nBLUE's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nRED's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nTEMP+1"
    new ""


    old "{size=-5}{color=#2b33b5}\nTEMP +1"
    new ""


    old "{size=-5}{color=#2b33b5}EDUC +1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nSPORT+1\nGRACE SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\nGRACE's PATH COMPROMISED"
    new ""


    old "{size=-5}{color=#2b33b5}SPORT+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}"
    new ""


    old "{size=-5}{color=#2b33b5}\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nRUBY's PATH COMPROMISED"
    new ""


    old "{size=-5}{color=#2b33b5}\nSPORT+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nEDUC+1"
    new ""


    old "{size=-5}{color=#2b33b5}\nBUDDY+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nSPORT+1\nBETTER ON MADISON's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nEDUC+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nMADISON's AND BLUE's PATHS COMPROMISED"
    new ""


    old "{size=-5}{color=#2b33b5}\nBLUE's PATH OPEN\nMADISON'S PATH COMPROMISED"
    new ""


    old "{size=-5}{color=#2b33b5}\nBLUE's PATH CLOSED"
    new ""


    old "{size=-5}{color=#2b33b5}\nRED's PATH OPEN"
    new ""


    old "{size=-5}{color=#2b33b5}\nRED's PATH CLOSED"
    new ""


    old "{size=-5}{color=#2b33b5}+1"
    new ""


    old "{size=-5}{color=#2b33b5}+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nBETTER FOR GABY'S PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nBETTER FOR GABY'S PATH "
    new ""


    old "{size=-5}{color=#2b33b5}\nENABLE LESBIAN/BI CONTENT"
    new ""


    old "{size=-5}{color=#2b33b5}\nDISABLE LESBIAN/BI CONTENT "
    new ""


    old "{size=-5}{color=#2b33b5}\nLET BLUE's PATH OPEN"
    new ""


    old "{size=-5}{color=#2b33b5}\nCLOSE BLUE's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nLET RED's PATH OPEN"
    new ""


    old "{size=-5}{color=#2b33b5}\nCLOSE RED's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nGRACE's AND/OR BLUE's PATHs"
    new ""


    old "{size=-5}{color=#2b33b5}\nBLUE's PATH OPEN"
    new ""


    old "{size=-5}{color=#2b33b5}\nVICTORY !\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nCHEATER !"
    new ""


    old "{size=-5}{color=#2b33b5}\nLOSER !"
    new ""


    old "{size=-5}{color=#2b33b5}\nMADISON's PATH IMPORTANT CHOICE !"
    new ""


    old "{size=-5}{color=#2b33b5}\nBETTER FOR GRACE's PATH !"
    new ""


    old "{size=-5}{color=#2b33b5}\nBLUE's OR RED's PATH REQUIRED !"
    new ""


    old "{size=-5}{color=#2b33b5}\nGRACE's PATH COMPROMISED\nBLUE PATH OPEN"
    new ""


    old "{size=-5}{color=#2b33b5}\nIf SPORT>8 MC GOAL OTHERWISE IT'S MADISON"
    new ""


    old "{size=-5}{color=#2b33b5}\nDEPENDING ON MADISON's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nMADISON's PATH REQUIRED"
    new ""


    old "{size=-5}{color=#2b33b5}\nBEST CHOICE IF NOT ON MADISON's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nLEAVE GRACE's PATH OPEN"
    new ""


    old "{size=-5}{color=#2b33b5}\nCLOSE GRACE's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nBEST CHOICE\nMADISON SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\nClOSE MADISON's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}BUDDY+1"
    new ""


    old "{size=-5}{color=#2b33b5}\nBUDDY+1\nCOMMON DRESS"
    new ""


    old "{size=-5}{color=#2b33b5}\nTEMP+1\nSEXY DRESS"
    new ""


    old "{size=-5}{color=#2b33b5}\nRED's SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\nEDUCATION+1\nBEST CHOICE"
    new ""


    old "{size=-5}{color=#2b33b5}\nBUDDY+1\nJULIA's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nTEMP+1\nCHARLOTTE's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nCHARLOTTE's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nCLOSE CHARLOTTE's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nGOOD ANSWER"
    new ""


    old "{size=-5}{color=#2b33b5}\nGABRIELLA's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nCLOSE GABRIELLA's PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nCHARLOTTE's SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\n"
    new ""


    old "{size=-5}{color=#2b33b5}\nSEX SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\nPREGNANCY ACTIVATED"
    new ""


    old "{size=-5}{color=#2b33b5}\nOPEN POKER PATH"
    new ""


    old "{size=-5}{color=#2b33b5}\nGRACE's SCENE"
    new ""


    old "{size=-5}{color=#2b33b5}\nRED's SCENE \nCLOSE ALL OTHER PATHS"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
