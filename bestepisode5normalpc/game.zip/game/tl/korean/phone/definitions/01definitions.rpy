

translate korean strings:


    old "Ruby"
    new ""


    old "Minus"
    new ""


    old "Grace"
    new ""


    old "Sofia"
    new ""


    old "Elise"
    new ""


    old "???"
    new ""


    old "Julia"
    new ""


    old "Madison"
    new ""


    old "Gabriella"
    new ""


    old "Can you hear me, now ?"
    new ""


    old "Yes ! You know this is only text, right ?"
    new ""


    old "Good ! Of course , mister serious, haha !"
    new ""


    old "Are you ready for tomorrow ?"
    new ""


    old "For what ?"
    new ""


    old "Economics class !"
    new ""


    old "Oh ! Yeah ! Sure..."
    new ""


    old "Don't worry... Gabriella is an angel..."
    new ""


    old "Gabriella... The Milf ?"
    new ""


    old "Ahah ! Yeah... But don't tell her that please..."
    new ""


    old "I'm not sure she would be pleased by that..."
    new ""


    old "No I won't ! I'm not stupid !"
    new ""


    old "And with Julia ???"
    new ""


    old "What's about Julia ?"
    new ""


    old "Come on !!! You two were all around the campus together this afternoon !"
    new ""


    old "How do you know that ?"
    new ""


    old "I've got my eyes everywhere"
    new ""


    old "You are crazy !"
    new ""


    old "I know !"
    new ""


    old "So ???"
    new ""


    old "So... what ?"
    new ""


    old "Julia !!!"
    new ""


    old "I'm not interested by her..."
    new ""


    old "I'm not interested in her..."
    new ""


    old "Oh..."
    new ""


    old "She's cute..."
    new ""


    old "Great ! I think she likes you too !"
    new ""


    old "Told you... I'm everywhere !"
    new ""


    old "Okay... time to sleep !"
    new ""


    old "See ya Cortex !"
    new ""


    old "See you... Minus..."
    new ""


    old "Hey !"
    new ""


    old "Hey... ! "
    new ""


    old "Sorry for my mom..."
    new ""


    old "Don't worry ! there's really no problem..."
    new ""


    old "May I ask you a question ?"
    new ""


    old "Sure you can !"
    new ""


    old "Okay..."
    new ""


    old "Were you trying to kiss me ?"
    new ""


    old "Yes..."
    new ""


    old "I couldn't resist..."
    new ""


    old "Even if you just spent time with Blue ?"
    new ""


    old "Oh you heard that ?"
    new ""


    old "How could I miss it... I could hear her moans all around the pool !"
    new ""


    old "Sorry..."
    new ""


    old "Sorry if it was too pushy..."
    new ""


    old "NO ! I mean..."
    new ""


    old "No..."
    new ""


    old "Oh ?"
    new ""


    old "I should sleep... It's late..."
    new ""


    old "Yeah me too..."
    new ""


    old "See you tomorrow !"
    new ""


    old "Sure ! See you tomorrow !"
    new ""


    old "Good night Grace..."
    new ""


    old "Good night [name]"
    new ""


    old "Hey my lord !"
    new ""


    old "I didn't think you would text me tonight ! "
    new ""


    old "Yeah I know..."
    new ""


    old "I can't forget what you did to me earlier..."
    new ""


    old "My pussy is so sore..."
    new ""


    old "I told you ! "
    new ""


    old "I know... I know..."
    new ""


    old "But I need more..."
    new ""


    old "Well, I think I need rest..."
    new ""


    old "Will you come to the party Friday ?"
    new ""


    old "Of course ! You ?"
    new ""


    old "Sure !"
    new ""


    old "Seems we might spend some time together..."
    new ""


    old "Can't wait..."
    new ""


    old "Can't wait !"
    new ""


    old "Me neither..."
    new ""


    old "Take this for your waiting time !"
    new ""


    old "I don't care..."
    new ""


    old "I don't care... "
    new ""


    old "Oh ? Okay..."
    new ""


    old "..."
    new ""


    old "See you ! Handsome..."
    new ""


    old "See you, my slutty one..."
    new ""


    old "Hey the american ! Tell me when you're here !"
    new ""


    old "Yes ? Leonardo speaking ?"
    new ""


    old "Hey! Are you asleep?"
    new ""


    old "Nah, I was about to go do a little training at the stadium."
    new ""


    old "Oh...."
    new ""


    old "Why? What's up?"
    new ""


    old "Well, I don't have anything to wear to the party."
    new ""


    old "I was thinking of going to Red's Store to try on some nice dresses."
    new ""


    old "Uh, yeah... and?"
    new ""


    old "Well, I wanted your opinion on what you think looks good on me!"
    new ""


    old "Oh, okay. Well..."
    new ""


    old "Sure. I'll come with.[TEMP1!t]"
    new ""


    old "I would happy to help"
    new ""


    old "Really? You're coming for real?"
    new ""


    old "Yeah. I said I was. I'll be there."
    new ""


    old "Ohhh, that's awesome!!!"
    new ""


    old "Give me ten minutes and I'll meet you in front of the store?"
    new ""


    old "Sounds good, see you in a bit."
    new ""


    old "I have to workout first.[TEMP2!t]"
    new ""


    old "I'm sorry, I really need to focus on my training. Maybe next time?"
    new ""


    old "No? Pretty please with a cherry on top? "
    new ""


    old "Okay, okay. You win. We can go when I am done training."
    new ""


    old "Ohhh, that's awesome! Thank you!"
    new ""


    old "We'll meet in front of the store, okay?"
    new ""


    old "Okay, see ya!"
    new ""


    old "I'll be waiting!"
    new ""


    old "Continue like that [name], you're doing great."
    new ""


    old "Who are you?"
    new ""


    old "Someone that can help you... or not..."
    new ""


    old "All will depend on you."
    new ""


    old "where did you get my phone number?"
    new ""


    old "This question isn't relevant..."
    new ""


    old "Do as I say and you will win this contest."
    new ""


    old "Don't and..."
    new ""


    old "You won't... And your girls neither"
    new ""


    old "What? My girls?"
    new ""


    old "You will have some fresh news soon."
    new ""


    old "Keep the good work [name]"
    new ""


    old "But what's your name?"
    new ""


    old "Hey! How's it going?"
    new ""


    old "Hi! My back's still a bit sore..."
    new ""


    old "Oh... Hope you're up for the next game!"
    new ""


    old "Yeah... I'm gonna stay in today."
    new ""


    old "I already called the academy to let them know I got hurt yesterday."
    new ""


    old "Oh... okay."
    new ""


    old "What about Grace's party?"
    new ""


    old "I'll be there, but I won't stay late."
    new ""


    old "Ah..."
    new ""


    old "So... see you there?"
    new ""


    old "Definitely! See ya!"
    new ""


    old "Hi Madison, it's [name]!"
    new ""


    old "Just a quick message to check if this is the right number..."
    new ""


    old "It is."
    new ""


    old "How was your afternoon?"
    new ""


    old "Apart from the kilo of modeling clay on my fingers..."
    new ""


    old "It's fine!"
    new ""


    old "I'm running late though..."
    new ""


    old "Okay, I won't bother you any longer! See you later!"
    new ""


    old "++"
    new ""


    old "Hi Gabriella, it's [name]!"
    new ""


    old "I told you only in case of emergency!"
    new ""


    old "Uh... Yes, but how do I know if it's the right number?"
    new ""


    old "In an emergency, I might not have time to check!"
    new ""


    old "Fair point..."
    new ""


    old "Enjoy your evening!"
    new ""


    old "And be on time tomorrow!"
    new ""


    old "No worries!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
