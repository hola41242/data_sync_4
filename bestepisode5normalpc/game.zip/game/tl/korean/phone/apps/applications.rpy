

translate korean strings:


    old "message"
    new ""


    old "calendar"
    new ""


    old "call"
    new ""


    old "Discussions"
    new ""


    old "Stats"
    new ""


    old "Settings"
    new ""


    old "Wallpaper"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
