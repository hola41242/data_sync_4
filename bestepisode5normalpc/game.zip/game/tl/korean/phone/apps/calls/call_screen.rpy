

translate korean strings:


    old "Facetime - [phone.calls._current_caller.name!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
