

translate korean strings:


    old "Monday"
    new ""


    old "Tuesday"
    new ""


    old "Wednesday"
    new ""


    old "Thursday"
    new ""


    old "Friday"
    new ""


    old "Saturday"
    new ""


    old "Sunday"
    new ""


    old "January"
    new ""


    old "February"
    new ""


    old "March"
    new ""


    old "April"
    new ""


    old "May"
    new ""


    old "June"
    new ""


    old "July"
    new ""


    old "August"
    new ""


    old "September"
    new ""


    old "October"
    new ""


    old "November"
    new ""


    old "December"
    new ""


    old "Calendar"
    new ""


    old "[calendar.month_name]-[calendar.year]"
    new ""


    old "Notes:"
    new ""


    old "No description provided."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
