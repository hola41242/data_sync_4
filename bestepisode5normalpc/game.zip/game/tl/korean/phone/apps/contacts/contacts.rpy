

translate korean strings:


    old "Messages"
    new ""


    old "No group chats"
    new ""


    old "The [group_chat._date_text] at [group_chat._hour_text]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
