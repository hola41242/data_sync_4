

translate korean strings:


    old "B.E.S.T RANK"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
