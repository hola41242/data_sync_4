

translate korean strings:


    old "Contacts"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
