

translate korean strings:


    old "Calls"
    new ""


    old "No recent calls"
    new ""


    old "The {date} at {time}"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
