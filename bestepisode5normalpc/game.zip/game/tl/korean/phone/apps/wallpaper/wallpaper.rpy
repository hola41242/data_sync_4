

translate korean strings:


    old "Your wallpaper was changed!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
