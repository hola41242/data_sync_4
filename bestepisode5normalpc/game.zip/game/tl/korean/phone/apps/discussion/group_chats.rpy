

translate korean strings:


    old "Empty group chat"
    new ""


    old "Image sent"
    new ""


    old "Audio sent"
    new ""


    old "Video sent"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
