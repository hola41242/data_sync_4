

translate korean strings:


    old "[sender.short_name!t] is typing..."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
