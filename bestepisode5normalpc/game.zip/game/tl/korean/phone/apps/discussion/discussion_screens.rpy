

translate korean strings:


    old "Type a message."
    new ""


    old "Send"
    new ""


    old "Load More"
    new ""


    old "{u}{i}Loading Image...{i}{/u}"
    new ""


    old "{u}{i}Loading Audio...{i}{/u}"
    new ""


    old "{u}{i}Loading Video...{i}{/u}"
    new ""


    old "Go Back"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
