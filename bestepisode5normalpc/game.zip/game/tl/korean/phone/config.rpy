

translate korean strings:


    old "%H:%M"
    new ""


    old "%m/%d/%Y"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
