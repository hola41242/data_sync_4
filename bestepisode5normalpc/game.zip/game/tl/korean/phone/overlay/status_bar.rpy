

translate korean strings:


    old "LTE"
    new ""


    old "Screen\nMirroring"
    new ""


    old "Music"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
