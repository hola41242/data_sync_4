

translate korean strings:


    old "Achievements | {:01d}/{}"
    new ""


    old "Hidden Achievement"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
