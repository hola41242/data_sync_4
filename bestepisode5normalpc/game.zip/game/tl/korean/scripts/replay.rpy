

translate korean strings:


    old "Replayer"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
