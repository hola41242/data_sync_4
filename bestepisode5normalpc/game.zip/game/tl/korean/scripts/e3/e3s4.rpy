


translate korean e3s4_43b49e4c:


    d ""


translate korean e3s4_2764ca10:


    d ""


translate korean e3s4_9f40912c:


    d "" with hpunch


translate korean e3s4_6eb69ed4:


    d ""


translate korean e3s4_db4f6715:


    d ""


translate korean e3s4_fb7cad08:


    d ""


translate korean e3s4_cecbb726:


    dpense ""

translate korean strings:


    old "Minus... you awake?"
    new ""


    old "Of course! I was worried about you!"
    new ""


    old "You're so sweet!"
    new ""


    old "You think so?"
    new ""


    old "Absolutely! I couldn't ask for a better friend!"
    new ""


    old "I know I'm the B.E.S.T !"
    new ""


    old "Ahah! For sure! So... I'm back in my room."
    new ""


    old "Great! I'm relieved!"
    new ""


    old "Good night, my acolyte!"
    new ""


    old "Sweet dreams, my partner!"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
