


translate korean e1s4_db02abfd:


    dpense ""


translate korean e1s4_3fa91343:


    dpense ""


translate korean e1s4_98a88ee3:


    dpense ""


translate korean e1s4_9a15f8ed:


    dpense ""


translate korean e1s4_2ead2b4e:


    dpense ""


translate korean e1s4_1bab997e:


    dpense ""


translate korean e1s4_c9218e91:


    dpense ""


translate korean e1s4_0ed28279:


    d ""


translate korean e1s4_1b095f4a:


    dpense ""


translate korean e1s4_9d966740:


    d ""


translate korean e1s4_81359d8a:


    mad ""


translate korean e1s4_d08d7bd8:


    d ""


translate korean e1s4_1cee3c7b:


    mad ""


translate korean e1s4_0277facd:


    ruby ""


translate korean e1s4_db9355e4:


    d ""


translate korean e1s4_fdfcc728:


    ruby ""


translate korean e1s4_e1eac1fe:


    d ""


translate korean e1s4_15b19890:


    ruby ""


translate korean e1s4_58b90a37:


    d ""


translate korean e1s4_62d07dbf:


    ruby ""


translate korean e1s4_474f9baa:


    d ""


translate korean e1s4_af65d736:


    ruby ""


translate korean e1s4_54658857:


    julia ""


translate korean e1s4_5631dc25:


    d ""


translate korean e1s4_3077b247:


    julia ""


translate korean e1s4_f85d2bb0:


    d ""


translate korean e1s4_d07ece43:


    grace ""


translate korean e1s4_df8f2fbb:


    d ""


translate korean e1s4_b0b96245:


    grace ""


translate korean e1s4_ff44cb0f:


    d ""


translate korean e1s4_5dba12c1:


    grace ""


translate korean e1s4_3f58bfa9:


    d ""


translate korean e1s4_c41a91e8:


    grace ""


translate korean e1s4_5470ffc5:


    d ""


translate korean e1s4_40f16f49:


    ruby ""


translate korean e1s4_b2b5a412:


    ruby ""


translate korean e1s4_4f399a57:


    d ""


translate korean e1s4_5048dc99:


    ruby ""


translate korean e1s4_f097499a:


    ruby ""


translate korean e1s4_85a51d50:


    d ""


translate korean e1s4_dacec8f6:


    dpense ""


translate korean e1s4_5a7f4942:


    dpense ""


translate korean e1s4_e3de31ff:


    dpense ""


translate korean e1s4_e5d68ef1:


    dpense ""


translate korean e1s4_3afc310b:


    dpense ""


translate korean e1s4_bef27060:


    dpense ""


translate korean e1s4_11722e7d:


    julia ""


translate korean e1s4_fb09c47b:


    julia ""


translate korean e1s4_1d8d941c:


    d ""


translate korean e1s4_ef7f41a7:


    julia ""


translate korean e1s4_392c0bca:


    julia ""


translate korean e1s4_d1328c7d:


    d ""


translate korean e1s4_c45d2021:


    julia ""


translate korean e1s4_3287f850:


    dpense ""


translate korean e1s4_fb09c47b_1:


    julia ""


translate korean e1s4_1d8d941c_1:


    d ""


translate korean e1s4_ef7f41a7_1:


    julia ""


translate korean e1s4_392c0bca_1:


    julia ""


translate korean e1s4_d1328c7d_1:


    d ""


translate korean e1s4_c45d2021_1:


    julia ""


translate korean e1s4_3287f850_1:


    dpense ""


translate korean e1s4_ec5f501a:


    d ""


translate korean e1s4_d2ca9147:


    grace ""


translate korean e1s4_861f2793:


    ruby ""


translate korean trial2_55085e54:


    d ""


translate korean trial3_d9e39fb2:


    d ""


translate korean trial3_125278f2:


    mad ""


translate korean trial3_5e6cd201:


    d ""


translate korean trial3_4c002cd5:


    d ""


translate korean trial3_3427b926:


    julia ""


translate korean trial3_c14b1157:


    julia ""


translate korean trial3_b0c2fcfb:


    julia ""


translate korean trial3_2a135b5e:


    dpense ""


translate korean trial3_f400f290:


    d ""


translate korean trial3_f400f290_1:


    d ""


translate korean trial4_d9f3189b:


    drew ""


translate korean trial4_1e17d9fa:


    d ""


translate korean trial4_fc9b9b9d:


    mad ""


translate korean trial4_93a57ae7:


    d ""


translate korean trial4_ef3a2b6b:


    mad ""


translate korean trial4_c3051f60:


    mad ""


translate korean trial4_29a24172:


    mad "" with hpunch


translate korean trial4_01f455e7:


    emerick ""


translate korean trial4_3ff9bc88:


    mad ""


translate korean trial4_0646d43a:


    dpense ""


translate korean trial4_7c86948c:


    mad ""


translate korean trial4_84bf4ca9:


    d ""


translate korean trial4_e46aa47d:


    mad ""


translate korean trial4_731b6dfa:


    d ""


translate korean trial4_213cb8be:


    dpense ""


translate korean trial4_cc180ec8:


    dpense ""


translate korean trial4_b3db403f:


    drew ""


translate korean trial4_8b86fe0d:


    d ""


translate korean trial4_ab1a0815:


    drew ""


translate korean trial4_a2ee175d:


    d ""


translate korean trial4_ad3c3345:


    mad ""


translate korean trial4_f0986419:


    d ""


translate korean trial4_b42bbe57:


    mad ""


translate korean trial4_94831b94:


    d ""


translate korean trial4_2684ce6d:


    d ""


translate korean trial4_4c50fb8d:


    mad ""


translate korean trial4_225df61f:


    d ""


translate korean trial4_169a4c34:


    mad ""


translate korean trial4_eda8436c:


    mad ""


translate korean trial4_9879eab6:


    mad ""


translate korean trial4_bdd2cfd3:


    d ""


translate korean trial4_d7ead446:


    grace ""


translate korean trial4_c6beaf67:


    grace ""


translate korean trial4_bf736dcc:


    d ""


translate korean trial4_11db95ef:


    grace ""


translate korean trial4_213cb8be_1:


    dpense ""


translate korean trial4_82b91c50:


    dpense ""


translate korean trial4_b3db403f_1:


    drew ""


translate korean trial4_8b86fe0d_1:


    d ""


translate korean trial4_ab1a0815_1:


    drew ""


translate korean trial4_20d845c7:


    d ""


translate korean trial4_a206b243:


    d ""


translate korean trial4_d0a982ec:


    ruby ""


translate korean trial4_6e7ff7a1:


    grace ""


translate korean trial4_0c4da74e:


    grace ""


translate korean trial4_c6beaf67_1:


    grace ""


translate korean trial4_bf736dcc_1:


    d ""


translate korean trial4_11db95ef_1:


    grace ""


translate korean trial4_213cb8be_2:


    dpense ""


translate korean trial4_82b91c50_1:


    dpense ""


translate korean trial4_b3db403f_2:


    drew ""


translate korean trial4_8b86fe0d_2:


    d ""


translate korean trial4_ab1a0815_2:


    drew ""


translate korean trial4_20d845c7_1:


    d ""


translate korean trial4_3df96114:


    grace ""


translate korean trial4_c17f7d6d:


    ruby ""


translate korean trial4_58f59dc6:


    julia ""


translate korean trial5_27b88c6d:


    mad ""


translate korean trial5_78e34d14:


    d ""


translate korean trial5_a1ac5cc2:


    mad ""


translate korean trial5_0413c8be:


    d ""


translate korean trial5_66ae6200:


    mad ""


translate korean trial5_09de3f57:


    d ""


translate korean trial5_f2708063:


    mad ""


translate korean trial5_da52e09c:


    d ""


translate korean trial5_6933428f:


    mad ""


translate korean trial5_6bc83719:


    d ""


translate korean trial5_94d0ff02:


    mad ""


translate korean trial5_ec79c7cd:


    d ""


translate korean trial5_30f5bf78:


    dpense ""


translate korean trial5_c1a3e6e6:


    d ""


translate korean trial5_42add1f3:


    dpense ""


translate korean trial5_09f48158:


    mad ""


translate korean trial5_9f153aac:


    dpense ""


translate korean trial5_75ca9fd9:


    mad ""


translate korean trial5_873f2806:


    mad ""


translate korean trial5_1466bf93:


    emerick ""


translate korean trial5_5aa65267:


    emerick ""


translate korean trial5_d7bc0bc2:


    emerick ""


translate korean trial5_a796af6c:


    mad ""


translate korean trial5_9e386227:


    d ""


translate korean trial5_02c64f73:


    emerick ""


translate korean trial5_2f2a683b:


    emerick ""


translate korean trial5_a324b55d:


    mad ""


translate korean trial5_dd115bf5:


    d ""


translate korean trial5_7b361f19:


    mad ""


translate korean trial5_67022165:


    mad ""


translate korean trial5_e3320973:


    d ""


translate korean trial5_407e6732:


    sofia ""


translate korean trial5_3aa92f61:


    emerick ""


translate korean trial5_83d40bd8:


    mad ""


translate korean trial5_abb65a9e:


    emerick ""


translate korean trial5_0cc73e4b:


    grace ""


translate korean trial5_4702d6a8:


    emerick ""


translate korean trial5_166c3d90:


    mad ""


translate korean trial5_94c5f187:


    grace ""


translate korean trial5_f07c88c7:


    d ""


translate korean trial5_0390dffa:


    grace ""


translate korean trial5_3aa92f61_1:


    emerick ""


translate korean trial5_83d40bd8_1:


    mad ""


translate korean trial5_abb65a9e_1:


    emerick ""


translate korean trial5_0cc73e4b_1:


    grace ""


translate korean trial5_4702d6a8_1:


    emerick ""


translate korean trial5_166c3d90_1:


    mad ""


translate korean trialfin_7361b1fc:


    ""


translate korean trialfin_a3f82246:


    orushi ""


translate korean trialfin_6f496e2c:


    orushi ""


translate korean trialfin_ce43e569:


    orushi ""


translate korean trialfin_9dd369ee:


    cr ""


translate korean trialfin_c61cc570:


    cr ""


translate korean trialfin_3bbf030e:


    cr ""


translate korean trialfin_e5a61280:


    cr ""


translate korean trialfin_25799538:


    cr ""


translate korean trialfin_c793ee1f:


    cr ""


translate korean trialfin_ccc055be:


    cr ""


translate korean trialfin_331e6b8a:


    cr ""


translate korean trialfin_1ca94d08:


    cr ""


translate korean trialfin_c6beee0f:


    orushi ""


translate korean trialfin_1962243b:


    orushi ""


translate korean trialfin_0ad95992:


    orushi ""


translate korean trialfin_12447cbb:


    orushi ""


translate korean trialfin_14f60090:


    orushi ""


translate korean trialfin_f4d45d06:


    rufus ""


translate korean trialfin_238811a2:


    grace ""


translate korean trialfin_dd3be176:


    d ""


translate korean trialfin_17d82854:


    dpense ""


translate korean reward_273dcdfc:


    julia ""


translate korean reward_3f69cd63:


    d ""


translate korean reward_3bcca2d1:


    julia ""


translate korean reward_250f7ffa:


    grace ""


translate korean reward_7c4ebb9b:


    d ""


translate korean reward_41d76fca:


    ruby ""


translate korean reward_16fd5bdd:


    d ""


translate korean final1_1c9356b0:


    dpense ""


translate korean final1_6cab8d90:


    dpense ""


translate korean final1_d050ec5e:


    dpense ""


translate korean final1_8bfacc8f:


    cr ""


translate korean final1_dbf8cd2e:


    cr ""


translate korean sofiabj_9c5ddf66:


    d ""


translate korean sofiabj_36c8ebe5:


    sofia ""


translate korean sofiabj_65c5b248:


    sofia ""


translate korean sofiabj_e57aa0b9:


    sofia ""


translate korean sofiabj_c67bd742:


    sofia ""


translate korean sofiabj_0ace3fae:


    sofia ""


translate korean sofiabj_a44e81b1:


    sofia ""


translate korean sofiabj_2384fcb7:


    sofia ""


translate korean sofiabj_d2275832:


    sofia ""


translate korean sofiabj_5cd1ddff:


    sofia ""


translate korean sofiabj_5ab2b6e7:


    d ""


translate korean sofiabj_6413fc68:


    d ""


translate korean sofiabj_45991d45:


    sofia ""


translate korean sofiabj_5b05403c:


    d ""


translate korean sofiabj_ba6905d9:


    sofia ""


translate korean sofiabj_25ed2fde:


    sofia ""


translate korean sofiabj_59892900:


    d ""


translate korean sofiabj_45991d45_1:


    sofia ""


translate korean sofiabj_5b05403c_1:


    d ""


translate korean sofiabj_ba6905d9_1:


    sofia ""


translate korean sofiabj_25ed2fde_1:


    sofia ""


translate korean sofiabj_59892900_1:


    d ""


translate korean bluejob_221e359c:


    d ""


translate korean bluejob_b31d7ba7:


    d ""


translate korean bluejob_9864ef2f:


    sofia ""


translate korean bluejob_dff221f1:


    sofia ""


translate korean bluejob_fe933c48:


    sofia ""


translate korean bluejob_d7394d4d:


    sofia ""


translate korean bluejob_2ad66fc4:


    sofia ""


translate korean bluejob_bbf61877:


    sofia ""


translate korean bluejob_e4a37cb5:


    sofia ""


translate korean bluejob_8a63b182:


    d ""


translate korean bluejob_caddeb77:


    sofia ""


translate korean bluejob_35e464ec:


    sofia ""


translate korean bluejob_6839384e:


    sofia ""


translate korean bluejob_8ce2bde3:


    sofia ""


translate korean bluejob_8405f452:


    sofia ""


translate korean bluejob_e75e0f01:


    sofia ""


translate korean bluejob_01d20d04:


    d ""


translate korean bluejob_93f7f7d7:


    sofia ""


translate korean bluejob_1ac0edce:


    sofia ""


translate korean bluejob_2bb9fb81:


    mad ""


translate korean bluejob_7c871c87:


    mad ""


translate korean bluejob_bbf61877_1:


    sofia ""


translate korean bluejob_e4a37cb5_1:


    sofia ""


translate korean bluejob_8a63b182_1:


    d ""


translate korean bluejob_caddeb77_1:


    sofia ""


translate korean bluejob_35e464ec_1:


    sofia ""


translate korean bluejob_6839384e_1:


    sofia ""


translate korean bluejob_8ce2bde3_1:


    sofia ""


translate korean bluejob_8405f452_1:


    sofia ""


translate korean bluejob_e75e0f01_1:


    sofia ""


translate korean bluejob_01d20d04_1:


    d ""


translate korean bluejob_93f7f7d7_1:


    sofia ""


translate korean bluejob_a399e704:


    sofia ""


translate korean bluejob_1ac0edce_1:


    sofia ""


translate korean bluejob_2bb9fb81_1:


    mad ""


translate korean bluejob_7c871c87_1:


    mad ""


translate korean bluejob_2b2db848:


    d ""


translate korean bluejob_4f004b7d:


    sofia ""


translate korean bluejob_b49239f2:


    d ""


translate korean bluejob_71957600:


    sofia ""


translate korean bluejob_e8006c39:


    sofia ""


translate korean bluejob_4dbe7388:


    sofia ""


translate korean bluejob_248c587d:


    sofia ""


translate korean bluejob_92442ef8:


    d ""


translate korean bluejob_768930d5:


    sofia ""


translate korean bluejob_c30f547e:


    d ""


translate korean bluejob_882be446:


    sofia ""


translate korean bluejob_cb3c584d:


    sofia ""


translate korean bluejob_d088a656:


    d ""


translate korean bluejob_42db099b:


    sofia ""


translate korean bluejob_07d235c4:


    d ""


translate korean bluejob_1908f85f:


    sofia ""


translate korean bluejob_122c476a:


    d ""


translate korean bluejob_1abffde1:


    sofia ""


translate korean bluejob_f529413b:


    d ""


translate korean bluejob_483b7906:


    sofia ""


translate korean bluejob_b6797206:


    dpense ""


translate korean bluejob_c15f7194:


    dpense ""


translate korean bluejob_38e37bbd:


    d ""


translate korean bluejob_320e7128:


    sofia ""


translate korean bluejob_fadae4f3:


    dpense ""


translate korean bluejob_dad3c95e:


    d ""


translate korean bluejob_d9e8a884:


    d ""


translate korean bluejob_7fb3f60d:


    d ""


translate korean bluejob_d3db81d2:


    sofia ""


translate korean bluejob_7e015a72:


    sofia ""


translate korean bluejob_a2ca227f:


    sofia ""


translate korean finchoixblue_cbc2a050:


    sofia ""


translate korean finchoixblue_2f2dd27a:


    d ""


translate korean finchoixblue_e68d49c9:


    sofia ""


translate korean finchoixblue_876533ea:


    d ""


translate korean finchoixblue_6ece4bdc:


    sofia ""


translate korean finchoixblue_0e4e8906:


    sofia ""


translate korean finchoixblue_c81eac44:


    d ""


translate korean finchoixblue_637a238f:


    dpense ""


translate korean finchoixblue_a9ef37dd:


    d ""


translate korean finchoixblue_a81b1440:


    sofia ""


translate korean finchoixblue_41ab0038:


    d ""


translate korean finchoixblue_3b22e690:


    sofia ""


translate korean finchoixblue_93c9e4c4:


    d ""


translate korean finchoixblue_c81977b0:


    mad ""


translate korean finchoixblue_223a7be2:


    mad ""


translate korean bethfk_22fa6fd0:


    dpense ""


translate korean bethfk_63f75c72:


    dpense ""


translate korean bethfk_a4645742:


    dpense ""


translate korean bethfk_6ade56ff:


    dpense ""


translate korean bethfk_949548e4:


    dpense ""


translate korean bethfk_e939f4bf:


    dpense ""


translate korean bethfk_a98aac7a:


    dpense ""


translate korean bethfk_3120a8c0:


    dpense ""


translate korean bethfk_9130a1ec:


    d ""


translate korean bethfk_855006e5:


    beth ""


translate korean bethfk_8d3edbc7:


    beth ""


translate korean bethfk_b6632a8b:


    beth ""


translate korean bethfk_d543fc81:


    beth ""


translate korean bethfk_fe2e0e36:


    d ""


translate korean bethfk_2573a943:


    beth ""


translate korean bethfk_bbcedabb:


    beth ""


translate korean bethfk_4a3e4292:


    beth ""


translate korean bethfk_be75ee24:


    beth ""


translate korean bethfk_dc08f865:


    beth ""


translate korean bethfk_9f04486c:


    beth ""


translate korean bethfk_184c3e0d:


    beth ""


translate korean bethfk_89669174:


    beth ""


translate korean bethfk_04bad0c3:


    beth ""


translate korean bethfk_fdba8dbe:


    beth ""


translate korean bethfk_35864525:


    beth ""


translate korean bethfk_e271c468:


    beth ""


translate korean redkiss_3800def7:


    dpense ""


translate korean redkiss_ae82b41a:


    dpense ""


translate korean redkiss_60123473:


    dpense ""


translate korean redkiss_08da671f:


    beth ""


translate korean redkiss_39d96f0d:


    beth ""


translate korean redkiss_d62019b2:


    beth ""


translate korean redkiss_16d05a4b:


    beth ""


translate korean redkiss_7b56213b:


    d ""


translate korean redkiss_9a65c14b:


    beth ""


translate korean redkiss_a695e7ba:


    beth ""


translate korean redkiss_0786e21b:


    beth ""


translate korean redkiss_e96e2b0e:


    dpense ""


translate korean redkiss_da1a2c02:


    beth ""


translate korean redkiss_2413472c:


    beth ""


translate korean redkiss_26d97def:


    d ""


translate korean redkiss_637a238f:


    dpense ""


translate korean redkiss_ef4b9cad:


    ruby ""


translate korean redkiss_0581bacf:


    d ""


translate korean redkiss_5e5295e8:


    d ""


translate korean redkiss_1b0fd802:


    beth ""


translate korean redkiss_d2d7e74c:


    beth ""


translate korean redkiss_73b76202:


    d ""


translate korean redkiss_0a4b4b2c:


    ruby ""


translate korean final_4a598229:


    ""


translate korean final_aec9e18d:


    ""


translate korean final_b10b320a:


    ""


translate korean final_8bda4787:


    ""


translate korean final_894d2571:


    ""


translate korean final_b2ae06ee:


    ""


translate korean final_9669528e:


    ""


translate korean final_4a598229_1:


    ""


translate korean final_aec9e18d_1:


    ""


translate korean final_b10b320a_1:


    ""


translate korean final_8bda4787_1:


    ""


translate korean final_894d2571_1:


    ""


translate korean final_b2ae06ee_1:


    ""


translate korean final_9669528e_1:


    ""

translate korean strings:


    old "2 minutes before the race starts..."
    new ""


    old "1 minute before the race starts..."
    new ""


    old "Help Julia [TEMP1!t]"
    new ""


    old "Continue [TEMP2!t]"
    new ""


    old "Help the girls [TEMP1!t]"
    new ""


    old "Do it like Madison [TEMP1!t]"
    new ""


    old "Help the girls [TEMP2!t]"
    new ""


    old "Join Madison [TEMP1!t]"
    new ""


    old "Encourage Madison [TEMP2!t]"
    new ""


    old "Join Julia [TEMP1!t]"
    new ""


    old "Encourage Girls [TEMP2!t]"
    new ""


    old "Remember [TEMP1!t]"
    new ""


    old "Wait for girls [TEMP2!t]"
    new ""


    old "YOUR NEW RANK IS [Rank] !"
    new ""


    old "Provoke her [TEMP1!t]"
    new ""


    old "Tell her to go away [TEMP2!t]"
    new ""


    old "Go for the kiss [TEMP1!t]"
    new ""


    old "Refuse [TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
