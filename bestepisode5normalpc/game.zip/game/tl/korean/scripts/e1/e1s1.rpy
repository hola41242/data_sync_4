


translate korean e1s1_e5c597fd:


    dpense ""


translate korean e1s1_a70be8a3:


    dpense ""


translate korean e1s1_b545e893:


    dpense ""


translate korean e1s1_c92b4616:


    dpense ""


translate korean e1s1_e121c6a0:


    d ""


translate korean e1s1_8665f3d9:


    "" with vpunch


translate korean e1s1_40668af7:


    d ""


translate korean e1s1_42198499:


    ""


translate korean e1s1_79a98cf6:


    d ""


translate korean e1s1_371dcb1d:


    d ""


translate korean e1s1_e6a3617d:


    d ""


translate korean e1s1_d8b3be19:


    dpense ""


translate korean e1s1_c5e69234:


    dpense ""


translate korean e1s1_9106fdeb:


    ""


translate korean e1s1_6f4899e6:


    d ""


translate korean e1s1_d6d5b2b2:


    ""


translate korean e1s1_295d0fd1:


    drew ""


translate korean e1s1_ec77f0b1:


    drew ""


translate korean e1s1_d64d0926:


    d ""


translate korean e1s1_ab50beb6:


    drew ""


translate korean e1s1_7eeb58f1:


    drew ""


translate korean e1s1_b3db403f:


    drew ""


translate korean e1s1_8b86fe0d:


    d ""


translate korean e1s1_e1b74faa:


    drew ""


translate korean e1s1_bc25ba71:


    drew ""


translate korean e1s1_8fd1e978:


    drew ""


translate korean e1s1_e714ec0e:


    drew ""


translate korean e1s1_06bd448a:


    drew "" with hpunch


translate korean e1s1_e8290730:


    drew ""


translate korean e1s1_e350ad45:


    grace ""


translate korean e1s1_67eae1bf:


    drew ""


translate korean e1s1_3dbeaa27:


    grace ""


translate korean e1s1_c1eff7a6:


    grace ""


translate korean e1s1_d7ec0052:


    grace ""


translate korean e1s1_8bb9bfa2:


    grace ""


translate korean e1s1_2f61cd1f:


    grace ""


translate korean e1s1_7149415c:


    grace ""


translate korean drewsuite_c214990b:


    drew ""


translate korean drewsuite_e1aae156:


    grace ""


translate korean drewsuite_f9ed221e:


    drew ""


translate korean drewsuite_d584d61f:


    drew ""


translate korean drewsuite_3f3108a6:


    drew ""


translate korean drewsuite_51b54e3f:


    drew ""


translate korean drewsuite_0cb358b4:


    grace ""


translate korean drewsuite_db71b97f:


    grace ""


translate korean drewsuite_4523b2d5:


    drew ""


translate korean drewsuite_696a8742:


    drew ""


translate korean drewsuite_4f707c1b:


    grace "" with vpunch


translate korean drewsuite_24e2b9f5:


    drew ""


translate korean drewsuite_981fef1c:


    drew ""


translate korean drewsuite_89842c29:


    drew ""


translate korean drewangry_30cf94b3:


    drew ""


translate korean drewangry_bff2d64d:


    d ""


translate korean drewangry_f64c1619:


    drew ""


translate korean drewangry_6ed0d999:


    d ""


translate korean drewok_e22ffbfe:


    drew ""


translate korean drewok_12b3f958:


    d ""


translate korean drewok_792664f7:


    drew ""


translate korean drewok_6ed0d999:


    d ""


translate korean gracetip_2181f854:


    cr ""


translate korean gracetip_9674208e:


    cr ""


translate korean gracetip_216f0561:


    cr ""


translate korean gracetip_ac943f4c:


    cr ""


translate korean gracetip_6a85a930:


    cr ""


translate korean gracetip_e4bf9eaf:


    cr ""


translate korean gracetip_666e6ece:


    cr ""


translate korean gracetip_858181c8:


    cr ""


translate korean gracetip_737ef232:


    cr ""


translate korean gracetip_7d746e81:


    cr ""


translate korean gracetip_6c4282e7:


    d ""


translate korean gracetip_8a13d7b7:


    grace ""


translate korean gracetip_2a9d73d8:


    d ""


translate korean gracetip_2e0cb4e0:


    grace ""


translate korean gracetip_d298f5af:


    d ""


translate korean gracetip_9430e9e5:


    grace "" with vpunch


translate korean gracetip_f09681f9:


    grace ""


translate korean gracetip_ab50bccd:


    d ""


translate korean gracetip_d692729b:


    grace ""


translate korean gracetip_6155d7c2:


    grace ""


translate korean gracetip_b91aafb4:


    cr ""


translate korean gracetip_4b67e7da:


    cr ""


translate korean gracetip_79574a66:


    cr ""


translate korean gracetip_bdaabba9:


    grace ""


translate korean gracetip_fde4e366:


    d ""


translate korean gracetip_62ef3f60:


    grace ""


translate korean gracetip_d7d0f724:


    d ""


translate korean sitcouch_2e864f0f:


    grace ""


translate korean sitcouch_5e1e37ee:


    d ""


translate korean sitcouch_9556c425:


    grace ""


translate korean roomgrace_bee99c83:


    grace ""


translate korean roomgrace_ef94450c:


    d ""


translate korean roomgrace_c95d349c:


    grace ""


translate korean roomgrace_e9b720f7:


    d ""


translate korean roomgrace_45538cff:


    grace ""


translate korean roomgrace_1678ca47:


    dpense ""


translate korean roomgrace_d0c6195d:


    dpense ""


translate korean roomgrace_14601ec4:


    dpense ""


translate korean roomgrace_5015de77:


    dpense ""


translate korean roomgrace_d4648271:


    dpense ""


translate korean roomgrace_19a6086b:


    dpense ""


translate korean roomgrace_3789c9b9:


    dpense ""


translate korean roomgrace_44d8ac77:


    grace ""


translate korean roomgrace_15696b9a:


    dpense ""


translate korean roomgrace_7e765a2f:


    grace ""


translate korean roomgrace_20a391a1:


    dpense ""


translate korean roomgrace_0e0b4bc1:


    dpense ""


translate korean roomgrace_3f712c16:


    dpense ""


translate korean roomgrace_e9a7858f:


    dpense ""


translate korean roomgrace_3e2f8822:


    dpense ""


translate korean couch_d5603e5f:


    dpense ""


translate korean couch_109f25a8:


    dpense ""


translate korean couch_4003f62c:


    dpense ""

translate korean strings:


    old "EPISODE 1 {p} \n Natural Selection"
    new ""


    old "You think I'm a babysitter ? [TEMP1!t]"
    new ""


    old "Sure Mrs Drew ! I'll take care of her. [TEMP2!t]"
    new ""


    old "Catch her [TEMP1!t]"
    new ""


    old "Don't [TEMP2!t]"
    new ""


    old "Do you want me to help you to your room ? [TEMP3!t]"
    new ""


    old "Oh ! Yes ! Sure ! [TEMP4!t]"
    new ""


    old "YOUR SPORT HAS INCREASED"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
