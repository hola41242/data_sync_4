


translate korean e1s2_34ad7e5c:


    ""


translate korean e1s2_5db95835:


    ""


translate korean e1s2_41cf68f1:


    ""


translate korean e1s2_24bb8b8a:


    ""


translate korean e1s2_9237b6e9:


    ""


translate korean e1s2_09695720:


    ""


translate korean e1s2_2f271829:


    ""


translate korean e1s2_c73588b3:


    "" with hpunch


translate korean e1s2_67b0fbce:


    d ""


translate korean e1s2_8614e399:


    ruby ""


translate korean e1s2_be15c680:


    d ""


translate korean e1s2_4ad557e3:


    ruby ""


translate korean e1s2_a250c6af:


    d ""


translate korean e1s2_1c28c67e:


    grace ""


translate korean e1s2_a76605d6:


    grace ""


translate korean e1s2_0226421c:


    ruby ""


translate korean e1s2_c71a801b:


    d ""


translate korean e1s2_72e488c4:


    d ""


translate korean e1s2_b6638c06:


    ruby ""


translate korean e1s2_be0b1d53:


    d ""


translate korean e1s2_53942f8e:


    ruby ""


translate korean e1s2_74616e87:


    ruby ""


translate korean e1s2_5d969260:


    d ""


translate korean e1s2_07929c8d:


    ruby ""


translate korean e1s2_287a87b4:


    d ""


translate korean e1s2_6f407893:


    ruby ""


translate korean e1s2_414a8171:


    ruby ""


translate korean propcineruby_3634a7f3:


    d ""


translate korean propcineruby_99e540a3:


    ruby ""


translate korean propcineruby_6287fda8:


    d ""


translate korean propcineruby_c43add9f:


    ruby ""


translate korean propcineruby_d8d89651:


    d ""


translate korean propcineruby_41df4702:


    ruby ""


translate korean propcineruby_37851153:


    d ""


translate korean propcineruby_47d453f2:


    ruby ""


translate korean propcineruby_e0d30fc1:


    d ""


translate korean fincineruby_c945114a:


    ruby ""


translate korean discoverroom_1a237ef5:


    ruby ""


translate korean discoverroom_e7861de8:


    d ""


translate korean discoverroom_f963a737:


    d ""


translate korean discoverroom_a6338c52:


    d ""


translate korean discoverroom_64e98b03:


    d ""


translate korean discoverroom_a6338c52_1:


    d ""


translate korean discoverroom_64e98b03_1:


    d ""


translate korean discoverroom_64e98b03_2:


    d ""


translate korean discoverroom_2bd4d989:


    d ""


translate korean discoverroom_cd4fae71:


    d ""


translate korean discoverroom_6dbb1ebc:


    d ""


translate korean discoverroom_c656e65a:


    d ""


translate korean discoverroom_da8c427f:


    d ""


translate korean rubychambre_5b47cd33:


    d ""


translate korean rubychambre_138d5fe3:


    d ""


translate korean rubychambre_af3ce623:


    d ""


translate korean rubychambre_508037ac:


    ruby ""


translate korean rubychambre_a5e75010:


    ruby ""


translate korean rubychambre_182f01ea:


    ruby ""


translate korean rubychambre_450849eb:


    d ""


translate korean rubychambre_7d7560a5:


    ruby ""


translate korean rubychambre_bfcede80:


    d ""


translate korean rubychambre_e4dc2b71:


    ruby ""


translate korean rubychambre_ddbc3bea:


    ruby ""


translate korean rubychambre_dd5d68f3:


    d ""


translate korean rubychambre_06b04368:


    ruby ""


translate korean rubychambre_794a94d7:


    d ""


translate korean rubychambre_04593aa2:


    d ""


translate korean rubychambre_fa34f206:


    ruby ""


translate korean rubychambre_d83c8599:


    d ""


translate korean rubychambre_16f08f36:


    ruby ""


translate korean rubychambre_7bcc50f4:


    d ""


translate korean tenuefier_d419757e:


    ruby ""


translate korean tenuefier_da447aff:


    d ""


translate korean tenuefier_0954f056:


    ruby ""


translate korean tenuefier_474f9baa:


    d ""


translate korean tenuefier_4016e5f2:


    ruby ""


translate korean tenuefier_474f9baa_1:


    d ""


translate korean tenuefier_5d647fc8:


    ruby ""


translate korean tenuefier_dbf049bf:


    d "" with vpunch


translate korean tenuefier_8fe3ea01:


    ruby ""


translate korean tenuefier_ff81dc7d:


    d ""


translate korean tenuefier_aa02d9c8:


    ruby ""


translate korean tenuefier_cf05acac:


    ruby ""


translate korean tenueshy_ff81dc7d:


    d ""


translate korean tenueshy_aa02d9c8:


    ruby ""


translate korean tenueshy_b2766e52:


    ruby ""


translate korean rubydepart_f3a9f496:


    d ""


translate korean rubydepart_74e895dc:


    ruby ""


translate korean rubydepart_75fcdfb3:


    d ""


translate korean rubydepart_fb3f392c:


    ruby ""


translate korean rubydepart_ac6d9b74:


    ruby ""


translate korean rubydepart_05244633:


    d ""


translate korean rubydepart_0fdce267:


    ruby ""


translate korean rubydepart_8ec775d3:


    ruby ""


translate korean rubydepart_992e6eaa:


    d ""


translate korean rubydepart_0a4c4274:


    ruby ""


translate korean rubydepart_f74d81d3:


    d ""


translate korean rubydepart_e28cd635:


    ruby ""


translate korean rubydepart_44c0877a:


    ruby ""

translate korean strings:


    old "Invite her someday to cinema [TEMP1!t]"
    new ""


    old "Not interested [TEMP2!t]"
    new ""


    old "Do push-ups [TEMP1!t]"
    new ""


    old "Go to the bathroom [TEMP2!t]"
    new ""


    old "Wait for Ruby"
    new ""


    old "30 push-ups later..."
    new ""


    old "Undress in front of her [TEMP1!t]"
    new ""


    old "Ask her to turn [TEMP2!t]"
    new ""


    old "Yes Minus ! [TEMP1!t]"
    new ""


    old "Nope [TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
