

translate korean strings:


    old "What is the only Wonder of the ancient world still visible?"
    new ""


    old "In a traditional deck of cards,\nwhich queen holds her scepter with both hands?"
    new ""


    old "Who wrote '1984'?"
    new ""


    old "What is the missing number?\n16 06 68 88 ?? 98"
    new ""


    old "What was the name of the first widely available web browser?"
    new ""


    old "What is the capital of Australia?"
    new ""


    old "Who is hidden behind this image?"
    new ""


    old "If you mix red and blue,\nwhat color do you get?"
    new ""


    old "Press the POINT"
    new ""


    old "The answer is obvious"
    new ""


    old "The Colossus of Rhodes"
    new ""


    old "The Great Pyramid of Giza[TEMP1!t]"
    new ""


    old "The Lighthouse of Alexandria"
    new ""


    old "The Temple of Artemis"
    new ""


    old "The Queen of Clubs[TEMP1!t]"
    new ""


    old "The Queen of Spades"
    new ""


    old "The Queen of Hearts"
    new ""


    old "The Queen of Diamonds"
    new ""


    old "J. R. R. Tolkien"
    new ""


    old "George R. R. Martin"
    new ""


    old "George Orwell[TEMP1!t]"
    new ""


    old "Stephen King"
    new ""


    old "Internet Explorer"
    new ""


    old "Mosaic[TEMP1!t]"
    new ""


    old "Netscape Navigator"
    new ""


    old "Google Chrome"
    new ""


    old "Canberra[TEMP1!t]"
    new ""


    old "Sydney"
    new ""


    old "Melbourne"
    new ""


    old "Perth"
    new ""


    old "Mona Lisa"
    new ""


    old "Aya Brea"
    new ""


    old "Lara Croft[TEMP1!t]"
    new ""


    old "Katniss Everdeen"
    new ""


    old "Violet[TEMP1!t]"
    new ""


    old "Orange"
    new ""


    old "Green"
    new ""


    old "Pink"
    new ""


    old "You finished on time! Your score is [score] / 10."
    new ""


    old "You did not finish on time. Your score is [score] / 10."
    new ""


    old "Your new rank is :"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
