


translate korean free20main_b9817b1b:


    dpense ""


translate korean free20poker_e46e10c0:


    emerick ""


translate korean free20poker_166fb7af:


    d ""


translate korean free20poker_e3a21349:


    emerick ""


translate korean free20poker_09774e7f:


    d ""


translate korean free20poker_caffb51d:


    emerick ""


translate korean julia20_e9b667af:


    julia ""


translate korean julia20_7b0543b1:


    d ""


translate korean julia20_90f7916e:


    julia ""


translate korean julia20_e01785b9:


    julia ""


translate korean julia20_d303c45f:


    d ""


translate korean julia20_0a194220:


    julia ""


translate korean julia20_a676d5f9:


    d ""


translate korean julia20_91ae47cb:


    d ""


translate korean julia20_ebb81cf3:


    julia ""


translate korean julia20_f36a5ff4:


    d ""


translate korean julia20_12d28bf4:


    d ""


translate korean julia20_d5c0dba2:


    julia ""


translate korean julia20_c37e26a1:


    d ""


translate korean julia20_27255f05:


    julia ""


translate korean julia20_ba9103a5:


    d ""


translate korean julia20_4811f618:


    julia ""


translate korean julia20_f4bcc054:


    julia ""


translate korean julia20_58878192:


    d ""


translate korean julia20_8b665ac1:


    d ""


translate korean julia20_c4520b4a:


    d ""


translate korean julia20_c2c84d9a:


    julia ""


translate korean julia20_d3bc2521:


    d ""


translate korean julia20_c9b9f09a:


    julia ""


translate korean julia20_b4e7c55d:


    d ""


translate korean julia20_8deff805:


    julia ""


translate korean julia20_ddf64e4d:


    d ""


translate korean julia20_122dc49a:


    julia ""


translate korean ruby20_54e9eef5:


    ruby ""


translate korean ruby20_2d1667b9:


    d ""


translate korean ruby20_47838d55:


    ruby ""


translate korean ruby20_55bd9a0f:


    d ""


translate korean ruby20_5624a2c3:


    ruby ""


translate korean ruby20_fb37dec8:


    ruby ""


translate korean ruby20_ddd135eb:


    ruby ""


translate korean ruby20_a220d848:


    ruby ""


translate korean ruby20_2a344a80:


    d ""


translate korean ruby20_c6e7417e:


    d ""


translate korean gracemadison20_22e7c1e7:


    mad ""


translate korean gracemadison20_ec0774f0:


    mad ""


translate korean gracemadison20_929b3308:


    grace ""


translate korean gracemadison20_5fb85e30:


    mad ""


translate korean gracemadison20_2e4b2f5d:


    mad ""


translate korean gracemadison20_5813eb09:


    grace ""


translate korean gracemadison20_0f959e66:


    mad ""


translate korean gracemadison20_bb8a7268:


    grace ""


translate korean gracemadison20_aaae4443:


    mad ""


translate korean gracemadison20_dd6aca0e:


    grace ""


translate korean gracemadison20_47e7ef71:


    grace ""


translate korean gracemadison20_2c8fb2dd:


    mad ""


translate korean gracemadison20_9e3164dd:


    d ""


translate korean gracemadison20_e0fa34d0:


    mad ""


translate korean gracemadison20_21c07e24:


    mad ""


translate korean gracemadison20_833b1ae7:


    grace ""


translate korean gracemadison20_31236522:


    d ""


translate korean gracemadison20_7babe025:


    mad ""


translate korean gracemadison20_ab07cfa9:


    grace ""


translate korean gracemadison20_cae75794:


    d ""


translate korean gracemadison20_ae441c39:


    mad ""


translate korean gracemadison20_e1929ec1:


    grace ""


translate korean gracemadison20_a68fb151:


    d ""


translate korean gracemadison20_00c8df40:


    mad ""


translate korean gracemadison20_70f6dc22:


    grace ""


translate korean gracemadison20_4bf8646f:


    d ""


translate korean gracemadison20_e7caeca7:


    grace ""


translate korean gracemadison20_0179b026:


    mad ""


translate korean gracemadison20_3996a386:


    mad ""


translate korean gracemadison20_8c9ae968:


    grace ""


translate korean gracemadison20_9a1573c3:


    mad ""


translate korean gracemadison20_ceddc600:


    grace ""


translate korean gracemadison20_66edb94c:


    grace ""


translate korean gracemadison20_996828a8:


    d ""


translate korean gracemadison20_281c814d:


    grace ""


translate korean gracemadison20_6860a799:


    "" with hpunch


translate korean kira20_76978961:


    kira ""


translate korean kira20_11b6e570:


    d ""


translate korean kira20_63270a58:


    kira ""


translate korean kira20_c9f48e51:


    d ""


translate korean kira20_cbac991e:


    kira ""


translate korean kira20_dd5d68f3:


    d ""


translate korean kira20_090957fb:


    kira ""


translate korean kira20_b2fb687f:


    d ""


translate korean kira20_714495ac:


    kira ""


translate korean kira20_67a82fd5:


    kira ""


translate korean kira20_25b067eb:


    kira ""


translate korean kira20_9fca5bb8:


    kira ""


translate korean kira20_23c22a5e:


    d ""


translate korean kira20_822c4b60:


    kira ""


translate korean kira20_2540386d:


    d ""


translate korean kira20_0d95348d:


    kira ""


translate korean kira20_87fc9282:


    d ""


translate korean kira20_7caab17d:


    kira ""


translate korean kira20_470a0ba6:


    kira ""


translate korean kira20_c9052c34:


    kira ""


translate korean kira20_bec902dc:


    d ""


translate korean kira20_f0c1cba5:


    kira ""


translate korean kira20_36c8d6dc:


    kira ""


translate korean kira20_7a54482d:


    kira ""


translate korean kira20_a4a39f55:


    d ""


translate korean kira20_f1dc0a9e:


    kira ""


translate korean kira20_9d72dc9f:


    kira ""


translate korean kira20_1bda52ce:


    d ""


translate korean kira20_d26751e5:


    kira ""


translate korean kira20_4e452bbd:


    d ""


translate korean kira20_4dba9ffa:


    kira ""


translate korean kira20_8f92cc28:


    d ""


translate korean kira20_7afac9f9:


    kira ""


translate korean kira20_d912e36d:


    d ""


translate korean kira20_bda08395:


    kira ""


translate korean kira20_a1cb4e30:


    d ""


translate korean kira20_db2aa7b3:


    kira ""


translate korean kira20_85110e9c:


    d ""


translate korean kira20_778d6ef8:


    kira ""


translate korean kira20_9feafa6e:


    kira ""


translate korean kira20_6d7a39b0:


    d ""


translate korean kira20_bc15f278:


    kira ""


translate korean kira20_cadb9a4f:


    d ""


translate korean kira20_f695fe29:


    kira ""


translate korean kira20_a6c2d4ec:


    kira ""


translate korean kira20_f0657274:


    ""


translate korean kira20_d7331970:


    kira ""


translate korean kira20_9a3fd59f:


    kira ""


translate korean kira20_e099747a:


    d ""


translate korean kira20_edceb7aa:


    kira ""


translate korean kira20_65fdf5f6:


    d ""


translate korean debiles20_ee280869:


    mac ""


translate korean debiles20_0b75be13:


    ben ""


translate korean debiles20_8cf98d22:


    mac ""


translate korean debiles20_0b75be13_1:


    ben ""


translate korean debiles20_d3c96603:


    mac ""


translate korean debiles20_ea8b6fa1:


    mac ""


translate korean debiles20_0b75be13_2:


    ben ""


translate korean debiles20_1300bd7d:


    mac ""


translate korean debiles20_a01646a5:


    ben ""


translate korean debiles20_e9adca6b:


    "" with hpunch


translate korean debiles20_dd5d68f3:


    d ""


translate korean debiles20_983ef4f8:


    s ""


translate korean debiles20_5ee1a6cf:


    "" with hpunch


translate korean debiles20_27a3722f:


    s ""


translate korean debiles20_5ee1a6cf_1:


    "" with hpunch


translate korean debiles20_825642f5:


    d ""


translate korean debiles20_84f4497b:


    sofia ""


translate korean debiles20_dd5d68f3_1:


    d ""


translate korean debiles20_7bdad836:


    sofia ""


translate korean debiles20_18000c7a:


    sofia ""


translate korean debiles20_a99b3fad:


    sofia ""


translate korean debiles20_9e386227:


    d ""


translate korean debiles20_d6f6da9b:


    s ""


translate korean debiles20_5ee1a6cf_2:


    "" with hpunch


translate korean blue20_5eee312c:


    d ""


translate korean blue20_9d28e022:


    sofia ""


translate korean blue20_baffc8cb:


    d ""


translate korean blue20_5e9e01cf:


    sofia ""


translate korean blue20_efd9aaae:


    d ""


translate korean blue20_ef5e272b:


    sofia ""


translate korean blue20_3655435f:


    d ""


translate korean blue20_08958f33:


    sofia ""


translate korean blue20_4876fdd7:


    dpense ""


translate korean blue20_6fb8f6cb:


    dpense ""


translate korean blue20_4b57eba2:


    d ""


translate korean blue20_36f6f4f8:


    sofia ""


translate korean blue20_75efb952:


    d ""


translate korean blue20_08809f48:


    sofia ""


translate korean blue20_b7ba2ada:


    d ""


translate korean blue20_165ba7f8:


    sofia ""


translate korean blue20_0e1ed2f6:


    d ""


translate korean blue20_e69d927e:


    sofia ""


translate korean blue20_1ecede8d:


    d ""


translate korean blue20_4f768d0a:


    sofia ""


translate korean blue20_fba1bb14:


    sofia ""


translate korean blue20_1cda50cf:


    d ""


translate korean blue20_97785a33:


    d ""


translate korean blue20_231069d2:


    sofia ""


translate korean blue20_2476d037:


    dpense ""


translate korean blue20_d6acb73c:


    dpense ""


translate korean red20_b983e6dc:


    beth ""


translate korean red20_49f5c417:


    d ""


translate korean red20_55418a01:


    beth ""


translate korean red20_b7783d6e:


    beth ""


translate korean red20_48ae9e3d:


    d ""


translate korean red20_655febea:


    beth ""


translate korean red20_5731001e:


    beth ""


translate korean red20_b836592c:


    beth ""


translate korean red20_f36a5ff4:


    d ""


translate korean red20_f26b2c0b:


    beth ""


translate korean red20_c6b71068:


    d ""


translate korean red20_1e03c0a4:


    d ""


translate korean red20_9d3c5279:


    beth ""


translate korean red20_f337b71d:


    d ""


translate korean red20_b811790e:


    beth ""


translate korean emerick20_bdd5c9e4:


    emerick ""


translate korean emerick20_cd4e2af9:


    emerick ""


translate korean emerick20_56454df3:


    emerick ""


translate korean emerick20_6b777721:


    emerick ""


translate korean emerick20_80bb8032:


    d ""


translate korean emerick20_8cbc8217:


    emerick ""


translate korean emerick20_d86ce540:


    d ""


translate korean emerick20_d598134a:


    d ""


translate korean emerick20_0093a926:


    emerick ""


translate korean kira20poker_3feab173:


    d ""


translate korean kira20poker_271d1f62:


    kira ""


translate korean kira20poker_148ff3e5:


    d ""


translate korean kira20poker_afa7eb49:


    kira ""


translate korean kira20poker_e0facd95:


    kira ""


translate korean kira20poker_b7378a12:


    kira ""


translate korean kira20poker_227865d4:


    d ""


translate korean kira20poker_9b0d0415:


    kira ""


translate korean kira20poker_b01d0032:


    d ""

translate korean strings:


    old "Meet me in the bathroom up there"
    new ""


    old "Um... Why?"
    new ""


    old "Hurry up... We don't have much time..."
    new ""


    old "Accept[TEMP1!t]"
    new ""


    old "Decline[TEMP2!t]"
    new ""


    old "Okay... I'll be right there."
    new ""


    old "I'm not sure if that's a good idea..."
    new ""


    old "I understand... Maybe some other time then."
    new ""


    old "Yes (Advance time and ends free-roam)"
    new ""


    old "No, maybe later..."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
