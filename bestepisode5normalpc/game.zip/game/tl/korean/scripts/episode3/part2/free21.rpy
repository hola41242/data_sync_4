


translate korean bluebathsequence_bfc258f4:


    sofia ""


translate korean bluebathsequence_640cb0b2:


    sofia ""


translate korean bluebathsequence_39a0fffb:


    sofia ""


translate korean bluebathsequence_eaf3c1ee:


    d ""


translate korean bluebathsequence_5b2496bc:


    dpense ""


translate korean bluebathsequence_e5f0d377:


    sofia ""


translate korean bluebathsequence_50fca145:


    sofia ""


translate korean bluebathsequence_99fba79e:


    sofia ""


translate korean bluebathsequence_65a81c4a:


    sofia ""


translate korean bluebathsequence_6ef36208:


    sofia ""


translate korean bluebathsequence_3b78e516:


    dpense ""


translate korean bluebathsequence_c50c170c:


    d ""


translate korean bluebathsequence_d9512405:


    sofia ""


translate korean bluebathsequence_c48e54c4:


    sofia ""


translate korean bluebathsequence_5b26181d:


    d ""


translate korean bluebathsequence_5a262f9a:


    dpense ""


translate korean bluebathsequence_2f26ac84:


    sofia ""


translate korean bluebathsequence_cf4f776b:


    d ""


translate korean bluebathsequence_0b8370ab:


    sofia ""


translate korean bluebathsequence_74d543c4:


    sofia ""


translate korean bluebathsequence_abc5915a:


    sofia ""


translate korean bluebathsequence_5707bfa6:


    sofia ""


translate korean bluebathsequence_6c2ebf4b:


    d ""


translate korean bluebathsequence_b7c5a512:


    sofia ""


translate korean bluebathsequence_56afc663:


    dpense ""


translate korean bluebathsequence_2f26ac84_1:


    sofia ""


translate korean bluebathsequence_79cf69e9:


    sofia ""


translate korean bluebathsequence_ebb813c0:


    sofia ""


translate korean bluebathsequence_47efd07c:


    sofia ""


translate korean bluebathsequence_0bd2f923:


    dpense ""


translate korean bluebathsequence_56849dc7:


    sofia ""


translate korean bluebathsequence_a26bcf05:


    sofia ""


translate korean bluebathsequence_fc4c4d59:


    sofia ""


translate korean bluebathsequence_021156c2:


    sofia ""


translate korean bluebathsequence_33fabc63:


    sofia ""


translate korean bluebathsequence_eb8f7bf6:


    dpense ""


translate korean bluebathsequence_56d2001c:


    sofia ""


translate korean bluebathsequence_312c0410:


    d ""


translate korean bluebathsequence_944ded0c:


    sofia ""


translate korean bluebathsequence_420528c9:


    sofia ""


translate korean bluebathsequence_d75056be:


    sofia ""


translate korean bluebathsequence_dad3c95e:


    d ""


translate korean bluebathsequence_6a936112:


    dpense ""


translate korean bluebathsequence_3eb7df3c:


    sofia ""


translate korean bluebathsequence_fb6a33b0:


    sofia ""


translate korean bluebathsequence_541b1006:


    sofia ""


translate korean bluebathsequence_925c17d4:


    sofia ""


translate korean bluebathsequence_4971b75a:


    sofia ""


translate korean bluebathsequence_24a08cec:


    dpense ""


translate korean bluebathsequence_1774c03c:


    sofia ""


translate korean bluebathsequence_2aa95cae:


    sofia ""


translate korean bluebathsequence_d5fa7ba5:


    dpense ""


translate korean freepokersequence_c2938bd3:


    emerick ""


translate korean freepokersequence_cf8678ec:


    emerick ""


translate korean freepokersequence_24dcd6cc:


    emerick ""


translate korean freepokersequence_32415610:


    emerick ""


translate korean freepokersequence_e8a73106:


    emerick ""


translate korean freepokersequence_04aa1bf5:


    emerick ""


translate korean freepokersequence_07fcd65a:


    d ""


translate korean freepokersequence_36279863:


    emerick ""


translate korean freepokersequence_a9c4bc36:


    beth ""


translate korean freepokersequence_ec5fc430:


    d ""


translate korean freepokersequence_54d07f02:


    emerick ""


translate korean firsthand_e86a8a7a:


    dpense ""


translate korean firsthand_ceb191ba:


    beth ""


translate korean firsthand_212cc397:


    beth ""


translate korean firsthand_4d9cec0f:


    beth ""


translate korean raisefirst_4af3fef4:


    d ""


translate korean raisefirst_da6cdede:


    d ""


translate korean raisefirst_a8f7e65c:


    emerick ""


translate korean raisefirst_dee9a1f0:


    hec ""


translate korean raisefirst_73612da1:


    ben ""


translate korean raisefirst_e963ac4e:


    mac ""


translate korean raisefirst_cbfb1f43:


    beth ""


translate korean raisefirst_360c9b51:


    beth ""


translate korean raisefirst_ac0535ba:


    dpense ""


translate korean raisefirst_27738fbb:


    dpense ""


translate korean raisefirst_cd216665:


    emerick ""


translate korean raisefirst_04e21e0e:


    mac ""


translate korean raisefirst_bb544eb2:


    dpense ""


translate korean foldfirst_86a9bfaa:


    d ""


translate korean foldfirst_42175e86:


    emerick ""


translate korean foldfirst_6ac4b55b:


    d ""


translate korean foldfirst_e75f4463:


    emerick ""


translate korean betfirst_507e59b5:


    d ""


translate korean betfirst_a8f7e65c:


    emerick ""


translate korean betfirst_e963ac4e:


    mac ""


translate korean betfirst_1ca60585:


    beth ""


translate korean betfirst_efb4200a:


    beth ""


translate korean betfirst_85a67f5b:


    dpense ""


translate korean betfirst_84464fb5:


    emerick ""


translate korean betfirst_d30b2f3d:


    mac ""


translate korean betfirst_d6926074:


    emerick ""


translate korean betfirst_92675bce:


    mac ""


translate korean betfirstturn_507e59b5:


    d ""


translate korean betfirstturn_bf39ee43:


    emerick ""


translate korean betfirstturn_01952dec:


    mac ""


translate korean callraiseturnfirst_d4af3017:


    d ""


translate korean callraiseturnfirst_7312aa2f:


    dpense ""


translate korean callraiseturnfirst_43774c19:


    beth ""


translate korean callraiseturnfirst_86e388f5:


    beth ""


translate korean callraiseturnfirst_72054f19:


    dpense ""


translate korean callraiseturnfirst_cf34f265:


    dpense ""


translate korean betfirstriver_507e59b5:


    d ""


translate korean betfirstriver_bf39ee43:


    emerick ""


translate korean betfirstriver_4857b6aa:


    mac ""


translate korean betfirstriver_6aae5fac:


    emerick ""


translate korean betfirstriver_98b0aa51:


    mac ""


translate korean betfirstriver_3f18fd8f:


    emerick ""


translate korean betfirstriver_5c342d8e:


    emerick ""


translate korean endfirst_585c495f:


    d ""


translate korean endfirst_1ddc9ab4:


    emerick ""


translate korean endfirst_0123b601:


    beth ""


translate korean endfirst_9af984ce:


    emerick ""


translate korean endfirst_a9039faa:


    d ""


translate korean endfirst_57a20cf5:


    hec ""


translate korean endfirst_855e48ca:


    ben ""


translate korean endfirst_29ac5843:


    d ""


translate korean endfirst_a44c39cf:


    mac ""


translate korean endfirst_d866667e:


    emerick ""


translate korean secondhand_a25952de:


    ben "" with hpunch


translate korean secondhand_71235bca:


    emerick ""


translate korean secondhand_7bdb1b2e:


    ben ""


translate korean secondhand_53648650:


    mac ""


translate korean secondhand_f6ff6b04:


    hec ""


translate korean secondhand_5617520a:


    emerick ""


translate korean secondhand_dcb8ab17:


    hec ""


translate korean secondhand_7607269e:


    dpense ""


translate korean secondhand_723b2ccf:


    dpense ""


translate korean secondhand_92d4ec21:


    d ""


translate korean secondhand_bfb72c89:


    emerick ""


translate korean secondhand_7af6f01b:


    mac ""


translate korean secondhand_51a2c941:


    emerick ""


translate korean secondhand_acb6662d:


    dpense ""


translate korean secondhand_309b2606:


    dpense ""


translate korean secondhand_cfb4069e:


    beth ""


translate korean secondhand_d2c68232:


    beth ""


translate korean secondhand_9ffa980a:


    beth ""


translate korean secondhand_29aafa4e:


    emerick ""


translate korean secondhand_534589df:


    hec ""


translate korean secondhand_2abf8722:


    mac ""


translate korean secondhand_4a9c96af:


    beth ""


translate korean callsecond_d4af3017:


    d ""


translate korean callsecond_a0eff481:


    beth ""


translate korean foldsecond_5853f4b8:


    d ""


translate korean foldsecond_8cd9bc60:


    beth ""


translate korean foldsecond_29ac5843:


    d ""


translate korean foldsecond_0d45e5bf:


    beth ""


translate korean raisesecond_5449efcb:


    d ""


translate korean raisesecond_72f87a6e:


    beth ""


translate korean raisesecond_b2b546ab:


    emerick ""


translate korean raisesecond_534589df:


    hec ""


translate korean raisesecond_2abf8722:


    mac ""


translate korean boardsecond_71d323cf:


    beth ""


translate korean boardsecond_8c073ec8:


    beth ""


translate korean boardsecond_4eadc122:


    dpense ""


translate korean boardsecond_5b5e5b81:


    beth ""


translate korean boardsecond_18a9af10:


    beth ""


translate korean boardsecond_1a210212:


    beth ""


translate korean boardsecond_29aafa4e:


    emerick ""


translate korean boardsecond_d222b261:


    hec ""


translate korean boardsecond_f0146759:


    emerick ""


translate korean boardsecond_0b44c64a:


    mac ""


translate korean boardsecond_a170c960:


    dpense ""


translate korean boardsecond_8a805c56:


    beth ""


translate korean boardsecond_f487f85b:


    beth ""


translate korean boardsecond_130fe238:


    beth ""


translate korean boardsecond_7bf7d14d:


    beth ""


translate korean boardsecond_bdc68931:


    d ""


translate korean boardsecond_585c495f:


    d ""


translate korean boardsecond_9cff1cb6:


    emerick ""


translate korean boardsecond_bdc68931_1:


    d ""


translate korean boardsecond_5449efcb:


    d ""


translate korean boardsecond_9cff1cb6_1:


    emerick ""


translate korean boardsecond_7404b6d9:


    d ""


translate korean boardsecond_f7de9063:


    emerick ""


translate korean boardsecond_1d55aa40:


    hec ""


translate korean boardsecond_c2596d04:


    emerick ""


translate korean boardsecond_8b385b22:


    emerick ""


translate korean boardsecond_d95b091a:


    sofia ""


translate korean boardsecond_2e8a73d2:


    sofia ""


translate korean boardsecond_9eeb175e:


    emerick ""


translate korean boardsecond_ebe96f90:


    hec ""


translate korean boardsecond_65c54f8c:


    emerick ""


translate korean boardsecond_25e4f758:


    sofia ""


translate korean boardsecond_70ddf0f2:


    sofia ""


translate korean boardsecond_ff4ed839:


    emerick "" with vpunch


translate korean boardsecond_58145255:


    emerick "" with hpunch


translate korean boardsecond_cfed94d4:


    hec ""


translate korean boardsecond_7426dcb3:


    emerick ""


translate korean boardsecond_9a3c3b3d:


    hec ""


translate korean boardsecond_a21e69bd:


    emerick ""


translate korean turnsecond_5b45644b:


    emerick ""


translate korean turnsecond_1d55aa40:


    hec ""


translate korean turnsecond_09efb43f:


    d ""


translate korean turnsecond_c2596d04:


    emerick ""


translate korean turnsecond_8b385b22:


    emerick ""


translate korean turnsecond_d95b091a:


    sofia ""


translate korean turnsecond_2e8a73d2:


    sofia ""


translate korean turnsecond_9eeb175e:


    emerick ""


translate korean turnsecond_ebe96f90:


    hec ""


translate korean turnsecond_08723f2a:


    dpense ""


translate korean turnsecond_65c54f8c:


    emerick ""


translate korean turnsecond_25e4f758:


    sofia ""


translate korean turnsecond_9a610ffe:


    sofia ""


translate korean turnsecond_ff4ed839:


    emerick "" with vpunch


translate korean turnsecond_58145255:


    emerick "" with hpunch


translate korean turnsecond_cfed94d4:


    hec ""


translate korean turnsecond_7426dcb3:


    emerick ""


translate korean turnsecond_9a3c3b3d:


    hec ""


translate korean turnsecond_78561908:


    emerick ""


translate korean turnsecond_d95b091a_1:


    sofia ""


translate korean turnsecond_2e8a73d2_1:


    sofia ""


translate korean turnsecond_29aafa4e:


    emerick ""


translate korean turnsecond_bdc68931:


    d ""


translate korean turnsecond_d4af3017:


    d ""


translate korean turnsecond_bdc68931_1:


    d ""


translate korean turnsecond_5449efcb:


    d ""


translate korean turnsecond_9cff1cb6:


    emerick ""


translate korean turnsecond_7404b6d9:


    d ""


translate korean turnsecond_f7de9063:


    emerick ""


translate korean turnsecond_1d55aa40_1:


    hec ""


translate korean turnsecond_c2596d04_1:


    emerick ""


translate korean turnsecond_8b385b22_1:


    emerick ""


translate korean turnsecond_9eeb175e_1:


    emerick ""


translate korean turnsecond_ebe96f90_1:


    hec ""


translate korean turnsecond_65c54f8c_1:


    emerick ""


translate korean turnsecond_25e4f758_1:


    sofia ""


translate korean turnsecond_9a610ffe_1:


    sofia ""


translate korean turnsecond_ff4ed839_1:


    emerick "" with vpunch


translate korean turnsecond_58145255_1:


    emerick "" with hpunch


translate korean turnsecond_cfed94d4_1:


    hec ""


translate korean turnsecond_7426dcb3_1:


    emerick ""


translate korean turnsecond_9a3c3b3d_1:


    hec ""


translate korean turnsecond_a21e69bd:


    emerick ""


translate korean riversecond_5b45644b:


    emerick ""


translate korean riversecond_1d55aa40:


    hec ""


translate korean riversecond_09efb43f:


    d ""


translate korean riversecond_c2596d04:


    emerick ""


translate korean riversecond_8b385b22:


    emerick ""


translate korean riversecond_9eeb175e:


    emerick ""


translate korean riversecond_ebe96f90:


    hec ""


translate korean riversecond_08723f2a:


    dpense ""


translate korean riversecond_65c54f8c:


    emerick ""


translate korean riversecond_25e4f758:


    sofia ""


translate korean riversecond_9a610ffe:


    sofia ""


translate korean riversecond_ff4ed839:


    emerick "" with vpunch


translate korean riversecond_58145255:


    emerick "" with hpunch


translate korean riversecond_cfed94d4:


    hec ""


translate korean riversecond_7426dcb3:


    emerick ""


translate korean riversecond_9a3c3b3d:


    hec ""


translate korean riversecond_78561908:


    emerick ""


translate korean riversecond_25e4f758_1:


    sofia ""


translate korean riversecond_9a610ffe_1:


    sofia ""


translate korean riversecond_29aafa4e:


    emerick ""


translate korean riversecond_d4af3017:


    d ""


translate korean riversecond_bdc68931:


    d ""


translate korean riversecond_bdc68931_1:


    d ""


translate korean riversecond_5449efcb:


    d ""


translate korean riversecond_9cff1cb6:


    emerick ""


translate korean riversecond_7404b6d9:


    d ""


translate korean riversecond_f7de9063:


    emerick ""


translate korean riversecond_1d55aa40_1:


    hec ""


translate korean riversecond_c2596d04_1:


    emerick ""


translate korean riversecond_a405345e:


    emerick ""


translate korean riversecond_ff4ed839_1:


    emerick "" with vpunch


translate korean riversecond_58145255_1:


    emerick "" with hpunch


translate korean riversecond_cfed94d4_1:


    hec ""


translate korean riversecond_7426dcb3_1:


    emerick ""


translate korean riversecond_9a3c3b3d_1:


    hec ""


translate korean riversecond_a21e69bd:


    emerick ""


translate korean finalsecond_f7de9063:


    emerick ""


translate korean finalsecond_1d55aa40:


    hec ""


translate korean finalsecond_c2596d04:


    emerick ""


translate korean finalsecond_a405345e:


    emerick ""


translate korean finalsecond_ff4ed839:


    emerick "" with vpunch


translate korean finalsecond_58145255:


    emerick "" with hpunch


translate korean finalsecond_cfed94d4:


    hec ""


translate korean finalsecond_7426dcb3:


    emerick ""


translate korean finalsecond_9a3c3b3d:


    hec ""


translate korean finalsecond_78561908:


    emerick ""


translate korean finalsecond_a21e69bd:


    emerick ""


translate korean twistersequence_b12cdd7a:


    ruby ""


translate korean twistersequence_a255f487:


    ruby ""


translate korean twistersequence_605daa46:


    kira ""


translate korean twistersequence_207bcd32:


    s ""


translate korean twistersequence_70936eb4:


    ruby ""


translate korean twistersequence_b5432fd9:


    ruby ""


translate korean twister1_854f7ed7:


    mad ""


translate korean twister1_dc165b3b:


    ruby ""


translate korean twister1_738560b4:


    ruby ""


translate korean twister1_705961f2:


    ruby ""


translate korean twister1_58455e31:


    dpense ""


translate korean twister1_3afbfedb:


    dpense ""


translate korean twister1_8867adec:


    dpense ""


translate korean twister1_b12cdd7a:


    ruby ""


translate korean twister1_1adf77ff:


    ruby "" with hpunch


translate korean twister1_122f3e71:


    kira ""


translate korean twister1_b8a9c191:


    s ""


translate korean twister1_e3c1a095:


    d ""


translate korean twister1_6a6f3496:


    mad ""


translate korean twister1_aeac2c84:


    ruby "" with hpunch


translate korean twister1_c1382146:


    kira ""


translate korean twister1_4201ad80:


    s ""


translate korean twister1_55b0f2bb:


    d ""


translate korean twister1_354fbd29:


    mad ""


translate korean twister1_fd2ab163:


    dpense ""


translate korean twister1_12ecdece:


    dpense ""


translate korean twister1_16e4c677:


    ruby "" with hpunch


translate korean twister1_759345ef:


    kira ""


translate korean twister1_ba2f3a28:


    s ""


translate korean twister1_9ac46c0a:


    d ""


translate korean twister1_37961fdb:


    mad ""


translate korean twister1_ff6edbf5:


    ruby "" with hpunch


translate korean twister1_d8dca636:


    kira ""


translate korean twister1_a0d6dc23:


    s ""


translate korean twister1_830b4098:


    d ""


translate korean twister1_310bd1e1:


    mad ""


translate korean twister1_9dcbc0e8:


    ruby ""


translate korean twister1_dcd39989:


    s ""


translate korean twister1_6e17f083:


    ruby ""


translate korean twister1_86063441:


    s ""


translate korean twister1_3239e163:


    s ""


translate korean twister1_0c843431:


    s ""


translate korean twister1_ee4baf21:


    ""


translate korean twister1_b7b6e9ac:


    ruby ""


translate korean twister1_65aec8b5:


    ruby ""


translate korean twister1_d897c9d7:


    ruby "" with hpunch


translate korean twister1_5986ca7c:


    kira ""


translate korean twister1_5b657902:


    d ""


translate korean twister1_76175d7e:


    mad ""


translate korean twister1_f8247d44:


    dpense ""


translate korean twister1_d229fb74:


    dpense ""


translate korean twister1_43358402:


    ruby "" with hpunch


translate korean twister1_bd6057c8:


    kira ""


translate korean twister1_5d3a4772:


    d ""


translate korean twister1_3efe91a9:


    mad ""


translate korean twister1_87f0e3b4:


    ruby "" with hpunch


translate korean twister1_818e5609:


    kira ""


translate korean twister1_4dd5f4c3:


    d ""


translate korean twister1_1b2e41c7:


    mad ""


translate korean twister1_8feb4af2:


    dpense ""


translate korean twister1_2e19129d:


    ruby ""


translate korean twister1_c4fb4f4c:


    kira ""


translate korean twister1_1a37fe6d:


    ruby ""


translate korean twister1_d2a489e9:


    ruby ""


translate korean twister1_f9115114:


    kira ""


translate korean twister1_7a77e836:


    kira ""


translate korean twister1_d9649ae4:


    mad ""


translate korean twister1_71db9840:


    mad ""


translate korean twister1_99102486:


    kira ""


translate korean twister1_d9d3c314:


    mad ""


translate korean twister1_b38549e6:


    mad ""


translate korean twister1_42fe5f0e:


    dpense ""


translate korean twister1_5c6118f1:


    dpense ""


translate korean twister1_26fbc773:


    ruby ""


translate korean twister1_c95a5382:


    ruby ""


translate korean twister1_f5469193:


    ruby "" with hpunch


translate korean twister1_7959b43b:


    mad ""


translate korean twister1_610f5201:


    d ""


translate korean twister1_3ff0b1af:


    dpense ""


translate korean twister1_59bb579b:


    ruby "" with hpunch


translate korean twister1_0fbf0d2a:


    mad ""


translate korean twister1_2ea85ac8:


    d ""


translate korean twister1_8e5eb314:


    dpense ""


translate korean twister1_a0fb982d:


    ruby "" with hpunch


translate korean twister1_a637c946:


    mad ""


translate korean twister1_b14c35cd:


    d ""


translate korean twister1_8d6b1f6e:


    dpense ""


translate korean twister1_17b1529b:


    ruby ""


translate korean twister1_8e509e5b:


    ruby "" with hpunch


translate korean twister1_85c61c22:


    mad ""


translate korean twister1_f153692d:


    d ""


translate korean twister1_7d81ee16:


    dpense ""


translate korean twister1_61a8520a:


    dpense ""


translate korean twister1_462c5f1d:


    dpense ""


translate korean twister1_dc8bad59:


    mad ""


translate korean twister1_5b62eedd:


    d ""


translate korean twister1_8de7275b:


    dpense ""


translate korean twister1_74637e05:


    ruby ""


translate korean twister1_26e90d0a:


    mad ""


translate korean twister1_36cd59a5:


    d ""


translate korean twister1_9021a01e:


    ruby ""


translate korean twister1_283935f2:


    mad ""


translate korean twister1_9a10d66c:


    ruby ""


translate korean twister1_16fcf0c7:


    dpense ""


translate korean twister1_562e58ec:


    ruby ""


translate korean twister1_0b8cbe55:


    mad ""


translate korean twister1_e9f9d80b:


    ruby ""


translate korean twister1_224206c9:


    mad ""


translate korean twister1_9be3f4e8:


    mad ""


translate korean twister1_ae94e9b1:


    dpense ""


translate korean twister1_51930a95:


    mad ""


translate korean twister1_ca820d31:


    dpense ""


translate korean twister1_9b7b30a4:


    ruby ""


translate korean twister1_2fd3cfa8:


    dpense ""

translate korean strings:


    old "9:00 PM"
    new ""


    old "Go play Poker"
    new ""


    old "Go play Twister"
    new ""


    old "I need a refresher"
    new ""


    old "No, I'm good"
    new ""


    old "Bet[TEMP1!t]"
    new ""


    old "Fold[TEMP2!t]"
    new ""


    old "Bet"
    new ""


    old "Call"
    new ""


    old "A few hands later..."
    new ""


    old "Raise"
    new ""


    old "Yeah, I'm in[TEMP1!t]"
    new ""


    old "No, thanks"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
