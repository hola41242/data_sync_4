


translate korean free00_6b4b0cf1:


    grace ""


translate korean free00_679a2306:


    grace ""


translate korean free00_98a03685:


    ruby ""


translate korean free00_fc5d43b7:


    grace ""


translate korean free00_34d48dad:


    ruby ""


translate korean free00_45282a81:


    grace ""


translate korean free00_aa7a6ace:


    d ""


translate korean free00_6ff5bfb7:


    ruby ""


translate korean free00_9cab7c01:


    d ""


translate korean free00_dc303eb0:


    ruby ""


translate korean free00_5fb753fe:


    ruby ""


translate korean free00_a6a8874f:


    mad ""


translate korean free00_0eaf48fc:


    d ""


translate korean free00_c47afec2:


    grace ""


translate korean free00_ac896290:


    d ""


translate korean free00_0dceca55:


    grace ""


translate korean free00_13a7d26b:


    ruby ""


translate korean free00_a6a8874f_1:


    mad ""


translate korean free00_0eaf48fc_1:


    d ""


translate korean free00_c47afec2_1:


    grace ""


translate korean free00_6ff5bfb7_1:


    ruby ""


translate korean free00_a6a8874f_2:


    mad ""


translate korean free00_0eaf48fc_2:


    d ""


translate korean free00_c47afec2_2:


    grace ""

translate korean strings:


    old "00:00 AM"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
