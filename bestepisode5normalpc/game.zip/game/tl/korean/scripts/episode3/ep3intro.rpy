


translate korean ep3intro_6a95f5af:


    ""


translate korean ep3intro_d52a2d2f:


    ""


translate korean ep3intro_17e52c09:


    ""


translate korean ep3intro_5155ce6b:


    ""


translate korean ep3intro_d059f665:


    ""


translate korean ep3intro_db1f4100:


    ""


translate korean ep3intro_63a49d35:


    ""


translate korean ep3intro_ae6a403c:


    sofia ""


translate korean ep3intro_1abbf48a:


    ""


translate korean ep3intro_26f7887d:


    sofia ""


translate korean ep3intro_525bb56e:


    ""


translate korean ep3intro_c5f6d561:


    ""


translate korean ep3intro_4433515c:


    ""


translate korean ep3intro_4433515c_1:


    ""


translate korean ep3intro_6b34e089:


    beth ""


translate korean ep3intro_14fabf4a:


    sofia ""

translate korean strings:


    old "EPISODE 3 {p} \n Let's get it started!"
    new ""


    old "8:00 AM"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
