


translate korean Training2_2314b734:


    dpense ""


translate korean Training2_6a4e888c:


    dpense ""


translate korean Training2_dbd94726:


    ji "" with vpunch


translate korean Training2_62e760ef:


    ji ""


translate korean Training2_f7499b79:


    ji ""


translate korean Training2_cba91d2b:


    ji ""


translate korean Training2_43398bf1:


    d ""


translate korean Training2_0144d7f9:


    d ""


translate korean Training2_d83c8599:


    d ""


translate korean Training2_62ecd993:


    d ""


translate korean Training2_c2e66dfd:


    ji ""


translate korean Training2_5e4b894c:


    ji ""


translate korean Training2_8926922d:


    ji ""


translate korean Training2_9d7f15ed:


    ji ""


translate korean Training2_e8e8e63a:


    d ""


translate korean Training2_7994d614:


    dpense ""


translate korean Training2_08535ece:


    dpense ""


translate korean Training2_ce2cd1a5:


    dpense ""


translate korean Training2_86048621:


    dpense ""


translate korean Chambreep3_7d909d2f:


    dpense ""


translate korean Chambreep3_cb1c8beb:


    dpense ""


translate korean Chambreep3_2aa2e6be:


    dpense ""


translate korean Chambreep3_ed39d6a5:


    dpense ""


translate korean Chambreep3_37e64b70:


    dpense ""


translate korean Chambreep3_6f5ea18e:


    dpense ""


translate korean Chambreep3_5284f567:


    dpense ""


translate korean Chambreep3_9c2712db:


    dpense ""


translate korean Chambreep3_68c57ca6:


    dpense ""


translate korean Chambreep3_0d47971e:


    dpense ""


translate korean Chambreep3_3a83ddfa:


    dpense ""


translate korean Chambreep3_5e298433:


    dpense ""


translate korean Chambreep3_ec2c1d7a:


    dpense ""


translate korean gracephoneep3s4_7cd0dad9:


    dpense ""


translate korean gracephoneep3s4_40bf0c88:


    dpense ""


translate korean juliaphoneep3s4_bffc964b:


    dpense ""


translate korean madphoneep3s4_4c58dcba:


    dpense ""


translate korean madphoneep3s4_fda3813c:


    dpense ""


translate korean madphoneep3s4_99f61674:


    dpense ""


translate korean bluephoneep3s4_28c2d9c9:


    dpense ""


translate korean bluephoneep3s4_02a7ab74:


    dpense ""


translate korean gabyphoneep3s4_d5bafb7c:


    dpense ""


translate korean gabyphoneep3s4_6ba6c89d:


    dpense ""


translate korean gabyphoneep3s4_f008a47b:


    dpense ""


translate korean departsoiree_bd5a3951:


    dpense ""


translate korean departsoiree_2a7b2a88:


    dpense ""


translate korean ArriveeFete_d10b0838:


    d ""


translate korean ArriveeFete_af385284:


    d ""


translate korean Charlottetime_44050cec:


    dpense ""


translate korean Charlottetime_f423db45:


    dpense ""


translate korean Charlottetime_37b557c2:


    dpense ""


translate korean Charlottetime_5df73d10:


    dpense ""


translate korean Charlottetime_8b1242bd:


    dpense ""


translate korean Charlottetime_a3d61da9:


    dpense ""


translate korean Charlottetime_017bee57:


    d ""


translate korean Charlottetime_c3e5e858:


    cha ""


translate korean Charlottetime_641b24ec:


    cha ""


translate korean Charlottetime_b31d7873:


    d ""


translate korean Charlottetime_bfd3fd79:


    cha ""


translate korean Charlottetime_99c90c60:


    cha ""


translate korean Charlottetime_c8863a0d:


    d ""


translate korean Charlottetime_fca708e0:


    cha ""


translate korean Charlottetime_2c3a63c7:


    d ""


translate korean Charlottetime_0ebfde79:


    cha ""


translate korean Charlottetime_a2a9798e:


    d ""


translate korean Charlottetime_2e1075ac:


    cha ""


translate korean Charlottetime_d93e0955:


    d ""


translate korean Charlottetime_cfa70a59:


    cha ""


translate korean Charlottetime_b82983f4:


    d ""


translate korean Charlottetime_46359b02:


    dpense ""


translate korean Charlottetime_3957d45a:


    dpense ""


translate korean Charlottetime_b4475d8b:


    dpense "" with hpunch


translate korean Charlottetime_e11f72be:


    dpense ""


translate korean Charlottetime_eafe9e61:


    cha ""


translate korean Charlottetime_e9fcb1fb:


    dpense ""


translate korean Charlottetime_9b0004ac:


    dpense ""


translate korean Charlottetime_53e24e7b:


    dpense ""


translate korean Charlottetime_bfd3fd79_1:


    cha ""


translate korean Charlottetime_e7fc63f0:


    cha ""


translate korean Charlottetime_385ef974:


    cha ""


translate korean Charlottetime_98998053:


    cha ""


translate korean Charlottetime_38e5071e:


    cha ""


translate korean Charlottetime_a1818eb0:


    cha ""


translate korean Charlottetime_215da4ac:


    cha ""


translate korean Charlottetime_a6aeabed:


    cha ""


translate korean Charlottetime_38954f7f:


    cha ""


translate korean Charlottetime_11bbaae7:


    cha ""


translate korean Charlottetime_64c167b7:


    cha ""


translate korean Charlottetime_4cd519e2:


    cha ""


translate korean Charlottetime_c4c6380f:


    dpense ""


translate korean Charlottetime_e5d1a0b8:


    dpense ""


translate korean Charlottetime_30c9594f:


    dpense ""


translate korean Charlottetime_5bd1f2d3:


    dpense ""


translate korean Charlottetime_38a2c2e0:


    dpense ""


translate korean Charlottetime_ace19207:


    cha ""


translate korean Charlottetime_bf324701:


    cha ""


translate korean Charlottetime_f7e912e8:


    cha ""


translate korean Charlottetime_d40c7883:


    cha ""


translate korean Charlottetime_f83572f2:


    cha ""


translate korean Charlottetime_f40ea147:


    cha ""


translate korean Charlottetime_602fd819:


    cha ""


translate korean Charlottetime_6b46261d:


    d ""


translate korean Charlottetime_139f3ef4:


    cha ""


translate korean Charlottetime_d0858423:


    cha ""


translate korean Charlottetime_df64e08e:


    d ""


translate korean Charlottetime_7627c9c7:


    d ""


translate korean Charlottetime_b04ed3cd:


    d ""


translate korean Charlottetime_c085c6c5:


    cha ""


translate korean Charlottetime_6d716f8d:


    d ""


translate korean Charlottetime_15b5a1b0:


    d ""


translate korean Charlottetime_eb5c5535:


    d ""


translate korean Charlottetime_fc3eeae2:


    cha ""


translate korean Charlottetime_8ee6bc76:


    cha ""


translate korean Charlottetime_a5dfa887:


    cha ""


translate korean Charlottetime_80e8641c:


    dpense ""


translate korean Charlottetime_44684764:


    cha ""


translate korean Charlottetime_1f3544ea:


    cha ""


translate korean Charlottetime_7eb1ed65:


    d ""


translate korean Charlottetime_be561219:


    cha ""


translate korean Charlottetime_f18aa612:


    d ""


translate korean Charlottetime_09fa1492:


    cha ""


translate korean Charlottetime_3951848a:


    d ""


translate korean Charlottetime_fac14cdd:


    cha ""


translate korean Charlottetime_fd6d20bb:


    d ""


translate korean Charlottetime_f8d931fa:


    cha ""


translate korean Charlottetime_85a345ef:


    cha ""


translate korean Charlottetime_b4461efb:


    d ""


translate korean Charlottetime_85f0a600:


    d ""


translate korean Charlottetime_87137957:


    cha ""


translate korean Charlottetime_d91aadfa:


    cha ""


translate korean Charlottetime_6e5b9427:


    d ""


translate korean Charlottetime_9b93c49a:


    cha "" with hpunch


translate korean Charlottetime_36f25c9c:


    cha ""


translate korean Charlottetime_18b75d90:


    cha ""


translate korean Charlottetime_4f482ae4:


    cha ""


translate korean Charlottetime_f9f78226:


    cha ""


translate korean Charlottetime_3271d50d:


    cha ""


translate korean Charlottetime_93db56f7:


    cha ""


translate korean Charlottetime_258c8329:


    cha ""


translate korean Charlottetime_7ab6f1b2:


    d ""


translate korean Charlottetime_3414f046:


    cha ""


translate korean Charlottetime_b78a309b:


    cha ""


translate korean Charlottetime_8c9fa616:


    d ""


translate korean Charlottetime_bf1e921f:


    cha ""


translate korean Charlottetime_933cc1f7:


    cha ""


translate korean Charlottetime_31a9b907:


    d ""


translate korean Charlottetime_f8e2e91c:


    cha ""


translate korean Charlottetime_6bba4eab:


    d ""


translate korean Charlottetime_dd5f6d96:


    cha ""


translate korean Charlottetime_17dba0b7:


    cha ""


translate korean Charlottetime_aee3450e:


    cha ""


translate korean Charlottetime_f1c77c07:


    d ""


translate korean Charlottetime_f272ff3b:


    cha ""

translate korean strings:


    old "14:30"
    new ""


    old "17:30"
    new ""


    old "Hey! Are you awake?"
    new ""


    old "Pass"
    new ""


    old "You guys doing okay?"
    new ""


    old "Yeah, we're good! We're almost done :)"
    new ""


    old "You need anything?"
    new ""


    old "Nope!"
    new ""


    old "Ruby thought of everything as usual!"
    new ""


    old "Okay... Well, see you later then!"
    new ""


    old "Yes! See you later!"
    new ""


    old "I can't wait to see you already!"
    new ""


    old "A wallpaper has been added"
    new ""


    old "Feeling better?"
    new ""


    old "Still a bit of back pain, but I'm okay..."
    new ""


    old "If you need massages, I'm here!"
    new ""


    old "Haha! No, it's okay!"
    new ""


    old "I'm getting ready for tonight..."
    new ""


    old "Well, don't hesitate if you need anything!"
    new ""


    old "I'll remember that!"
    new ""


    old "See you tonight!"
    new ""


    old "Are you ready for tonight?"
    new ""


    old "I'm not even dressed yet..."
    new ""


    old "Seriously?"
    new ""


    old "Stay like that, it works for me!"
    new ""


    old "If only I could..."
    new ""


    old "I won't bother you any longer then!"
    new ""


    old "Oh, you're not bothering me!"
    new ""


    old "Tease!"
    new ""


    old "You have no idea how much!"
    new ""


    old "Alright, see you later!"
    new ""


    old "See you later!"
    new ""


    old "Join her[TEMP1!t]"
    new ""


    old "Or not[TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
