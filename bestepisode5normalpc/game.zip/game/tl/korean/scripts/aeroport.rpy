


translate korean aeroport_f4a872b8:


    dpense ""


translate korean aeroport_b07237c8:


    dpense ""


translate korean aeroport_808acf6d:


    dpense ""


translate korean aeroport_555b6725:


    ""


translate korean aeroport_e4ca3e2d:


    mad ""


translate korean aeroport_b983271d:


    mad ""


translate korean aeroport_196a6471:


    d "" with hpunch


translate korean aeroport_60fb3963:


    mad ""


translate korean aeroport_80be1ed7:


    d ""


translate korean aeroport_ed1ba37f:


    mad ""


translate korean aeroport_33058132:


    mad ""


translate korean aeroport_f0452d08:


    d ""


translate korean aeroport_25e103b1:


    mad ""


translate korean aeroport_6723e0fa:


    dpense ""


translate korean aeroport_dc7b7945:


    d ""


translate korean aeroport_40bc89bc:


    mad ""


translate korean aeroport_1bf3f63c:


    d ""


translate korean aeroport_de3c83e7:


    mad ""


translate korean aeroport_b63493c8:


    d ""


translate korean aeroport_fd8e2ede:


    mad ""


translate korean aeroport_64483950:


    ""


translate korean aeroport_4352eddb:


    drew ""


translate korean aeroport_7116406b:


    orushi ""


translate korean aeroport_7844bdbe:


    orushi ""


translate korean aeroport_6e3b1b13:


    drew ""


translate korean aeroport_d5ab5b44:


    orushi ""


translate korean aeroport_41d0c460:


    orushi ""


translate korean aeroport_5ddfbed5:


    orushi ""


translate korean aeroport_533d812c:


    ""


translate korean aeroport_14d7b0f5:


    orushi ""


translate korean aeroport_897eabbe:


    mad ""


translate korean aeroport_c27801fc:


    d ""


translate korean aeroport_159a23f2:


    mad ""


translate korean aeroport_b8b1a077:


    d ""


translate korean aeroport_f4b1a052:


    dpense ""


translate korean aeroport_e19a32cd:


    d ""


translate korean aeroport_92c1c803:


    mad ""


translate korean aeroport_e9d9321a:


    d ""


translate korean aeroport_f351df9d:


    mad ""


translate korean aeroport_ed92ac6c:


    d ""


translate korean aeroport_21823f25:


    mad ""


translate korean aeroport_fe0cba53:


    d ""


translate korean aeroport_64483950_1:


    ""


translate korean aeroport_4352eddb_1:


    drew ""


translate korean aeroport_7116406b_1:


    orushi ""


translate korean aeroport_7844bdbe_1:


    orushi ""


translate korean aeroport_6e3b1b13_1:


    drew ""


translate korean aeroport_d5ab5b44_1:


    orushi ""


translate korean aeroport_41d0c460_1:


    orushi ""


translate korean aeroport_bb4cf1c0:


    orushi ""


translate korean aeroport_533d812c_1:


    ""


translate korean aeroport_14d7b0f5_1:


    orushi ""

translate korean strings:


    old "A NEW LIFE...."
    new ""


    old "Rrrrrrrrrrrrrrrrr..."
    new ""


    old "You've found a RUFUS !"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
