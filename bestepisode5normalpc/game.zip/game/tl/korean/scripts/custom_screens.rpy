

translate korean strings:


    old "Look at the numbers backwards"
    new ""


    old "Don't click on the image"
    new ""


    old "The answer is in the question"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
