

translate korean strings:


    old "Rufus Found : [persistent.rufusgame] / 9"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
