

translate korean strings:


    old "{color=#ffffffff}Taxi Drive{/color}"
    new ""


    old "{color=#ffffffff}Red is Dead{/color}"
    new ""


    old "{color=#ffffffff}Bed is Red{/color}"
    new ""


    old "{color=#ffffffff}Kitty{/color}"
    new ""


    old "{color=#ffffffff}Dirty{/color}"
    new ""


    old "{color=#ffffffff}Yummy{/color}"
    new ""


    old "{color=#ffffffff}Ice-Cream{/color}"
    new ""


    old "{color=#ffffffff}MotorButt{/color}"
    new ""


    old "{color=#ffffffff}Mystery{/color}"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
