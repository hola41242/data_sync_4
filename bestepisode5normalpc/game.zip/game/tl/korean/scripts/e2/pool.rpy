


translate korean pool_72637706:


    dpense ""


translate korean pool_7a1baaf2:


    ji ""


translate korean pool_279f9a91:


    dpense ""


translate korean pool_b85af03c:


    dpense ""


translate korean pool_e1b9209f:


    ji ""


translate korean pool_204f2638:


    d ""


translate korean pool_0b4cdda2:


    ji ""


translate korean pool_bd97412f:


    d ""


translate korean pool_68ef2048:


    dpense ""


translate korean pool_26d4b995:


    dpense ""


translate korean pool_c303edbb:


    dpense ""


translate korean pool_2858ce6f:


    dpense ""


translate korean pool_c7cc1930:


    sofia ""


translate korean pool_4ed86741:


    d ""


translate korean pool_e12af768:


    sofia ""


translate korean pool_5036ca42:


    d ""


translate korean pool_140612ac:


    d ""


translate korean pool_7ea2f9dd:


    sofia ""


translate korean pool_f36c14c5:


    sofia ""


translate korean pool_e90456c6:


    d ""


translate korean pool2_d9572a1c:


    d ""


translate korean pool2_fa3467c8:


    grace ""


translate korean pool2_f66455b4:


    d ""


translate korean pool2_b8e2fee2:


    grace ""


translate korean pool2_c670f8b1:


    d ""


translate korean pool2_7dd0a2f8:


    grace ""


translate korean pool2_7f1e4dbe:


    d ""


translate korean pool2_2ccaf0b5:


    grace ""


translate korean pool2_d5462bbf:


    d ""


translate korean pool2_275ce8d3:


    grace ""


translate korean pool2_3ba1bae1:


    d ""


translate korean pool2_76c08320:


    grace ""


translate korean pool2_0e0f6b87:


    d ""


translate korean pool2_46bc144d:


    grace ""


translate korean pool2_b1500910:


    d ""


translate korean pool2_67a8763d:


    dpense ""


translate korean pool2_6f4442f4:


    grace ""


translate korean pool2_7937cad2:


    d ""


translate korean pool2_2bc3d50b:


    d ""


translate korean pool2_45a97532:


    grace ""


translate korean pool2_2059714a:


    d ""


translate korean pool2_413052f1:


    grace ""


translate korean pool2_3c7caf13:


    d ""


translate korean pool2_a897be39:


    d ""


translate korean pool2_feb3be0c:


    grace ""


translate korean pool2_79d25a85:


    d ""


translate korean pool2_72618b93:


    grace ""


translate korean pool2_5dda0f88:


    d ""


translate korean pool2_58f2204f:


    grace ""


translate korean pool2_ad924887:


    d ""


translate korean pool2_2a17a6fb:


    grace ""


translate korean pool2_f427102d:


    d ""


translate korean pool2_53d303bf:


    grace ""


translate korean pool2_4e58cc80:


    d ""


translate korean pool2_3c81889e:


    grace ""


translate korean pool2_6967de82:


    d ""


translate korean pool2_fddacfe2:


    grace ""


translate korean pool2_5e16e0f2:


    d ""


translate korean pool2_26544772:


    grace ""


translate korean pool2_48ff1ed8:


    d ""


translate korean pool2_7bc9d103:


    grace ""


translate korean pool2_ecef2909:


    dpense ""


translate korean pool2_f6390a0e:


    grace ""


translate korean pool2_3314f8cb:


    d ""


translate korean pool2_b8466fb7:


    grace ""


translate korean pool2_67424511:


    grace ""


translate korean pool2_542ac620:


    grace ""


translate korean nage2_226132c8:


    dpense ""


translate korean nage3_58c7f260:


    dpense ""


translate korean nage3_8278132c:


    d ""


translate korean nage3_8278132c_1:


    d ""


translate korean nage3_09c9d4b2:


    grace ""


translate korean nage3_3ed7a701:


    grace ""


translate korean victory_a3e3783a:


    grace ""


translate korean victory_c991dce0:


    d ""


translate korean victory_4fa8f8ce:


    grace ""


translate korean victory_c5e4f86c:


    d ""


translate korean victory_1be0c3fd:


    grace ""


translate korean victory_7961d703:


    d ""


translate korean victory_3de0ddee:


    grace ""


translate korean victory_f44767f2:


    d ""


translate korean victory_92628f4c:


    grace ""


translate korean victory_c5c89714:


    d ""


translate korean victory_9e5421b0:


    dpense ""


translate korean victory_6e81e294:


    d ""


translate korean victory_9a03811a:


    grace ""


translate korean cheater_d760c5d6:


    grace ""


translate korean cheater_e4bc3bdd:


    d ""


translate korean cheater_41767841:


    grace ""


translate korean cheater_06713c9c:


    d ""


translate korean cheater_2b33e359:


    grace ""


translate korean cheater_40ab082c:


    d ""


translate korean cheater_92628f4c:


    grace ""


translate korean cheater_c5c89714:


    d ""


translate korean cheater_9e5421b0:


    dpense ""


translate korean cheater_6e81e294:


    d ""


translate korean cheater_9a03811a:


    grace ""


translate korean defeat_5978fda4:


    grace ""


translate korean defeat_8654b90d:


    d ""


translate korean defeat_af31fc61:


    grace ""


translate korean defeat_278f39a6:


    d ""


translate korean defeat_4a38dc42:


    grace ""


translate korean defeat_058f48b4:


    dpense ""


translate korean defeat_7141816a:


    grace ""


translate korean defeat_3813ec2e:


    d ""


translate korean endpool_feb0a042:


    d ""


translate korean endpool_7d7eae2f:


    grace ""


translate korean endpool_2983d61f:


    d ""


translate korean endpool_c459a192:


    grace ""


translate korean endpool_08e82bfc:


    grace ""


translate korean endpool_875ad268:


    d ""


translate korean endpool_3f8b6f6a:


    grace ""


translate korean endpool_91740a1a:


    grace ""


translate korean endpool_9c7f54c9:


    d ""


translate korean endpool_ceb17858:


    grace ""


translate korean endpool_5950ee26:


    grace ""


translate korean endpool_80818372:


    d ""


translate korean endpool_77603962:


    grace ""


translate korean endpool_1f36b29c:


    grace ""


translate korean endpool_657cfc1d:


    d ""


translate korean endpool_ca5ed8b2:


    d ""


translate korean endpool_d12ba1aa:


    d ""


translate korean endpool_c4cf4b82:


    grace ""


translate korean endpool_26b66551:


    grace ""


translate korean endpool_49cfcdc9:


    d ""


translate korean endpool_36cff508:


    d ""


translate korean endpool_9ff13fac:


    ji "" with hpunch


translate korean endpool_4981c72d:


    drew ""


translate korean endpool_754ea95c:


    grace ""


translate korean endpool_0d1f41a3:


    dpense ""


translate korean endpool_1297fb29:


    drew ""


translate korean endpool_df4aea3a:


    d ""


translate korean endpool_d191e4f0:


    dpense ""


translate korean endpool_bdc6204a:


    grace ""


translate korean endpool_5dda0f88:


    d ""


translate korean endpool_8a8583e7:


    grace ""


translate korean endpool_63ba9085:


    d ""


translate korean endpool_77be5b7d:


    grace ""


translate korean endpool_cd0a4421:


    d ""


translate korean endpool_d1605dea:


    grace ""


translate korean endpool_3130185e:


    grace ""


translate korean endpool_de9778f4:


    d ""


translate korean endpool_62becd20:


    grace ""


translate korean endpool_df3539f1:


    d ""


translate korean sofiapool_7474e0b0:


    d ""


translate korean sofiapool_46856e57:


    sofia ""


translate korean sofiapool_075af965:


    sofia ""


translate korean sofiapool_d90a9ae5:


    sofia ""


translate korean sofiapool_4c3c7b1f:


    sofia ""


translate korean sofiapool_4d46038d:


    d ""


translate korean sofiapool_5b20eac3:


    sofia ""


translate korean sofiapool_6b59357b:


    d ""


translate korean sofiapool_47c38ad4:


    sofia ""


translate korean sofiapool_9b670c10:


    sofia ""


translate korean sofiapool_3f55375c:


    d ""


translate korean sofiapool_bab69aa7:


    sofia ""


translate korean sofiapool_7cb0a8e4:


    sofia ""


translate korean sofiapool_af039036:


    sofia ""


translate korean sofiapool_0664179c:


    sofia ""


translate korean sofiapool_f99d8985:


    dpense ""


translate korean sofiapool_de8ff332:


    dpense ""


translate korean sofiapool_38c92066:


    dpense ""


translate korean sofiapool_8a6010a7:


    sofia ""


translate korean sofiapool_9abed53e:


    sofia ""


translate korean sofiapool_5aee8d42:


    sofia ""


translate korean sofiapool_d8e4cc07:


    dpense ""


translate korean sofiapool_636b8efc:


    sofia ""


translate korean sofiapool_5b80429a:


    d ""


translate korean sofiapool_f1a71605:


    sofia ""


translate korean sofiapool_6b59357b_1:


    d ""


translate korean sofiapool_47c38ad4_1:


    sofia ""


translate korean sofiapool_72d38011:


    d ""


translate korean sofiapool_55bbb5fd:


    sofia ""


translate korean sofiapool_ce0d59cb:


    d ""


translate korean sofiapool_9b670c10_1:


    sofia ""


translate korean sofiapool_3f55375c_1:


    d ""


translate korean sofiapool_bab69aa7_1:


    sofia ""


translate korean sofiapool_7cb0a8e4_1:


    sofia ""


translate korean sofiapool_af039036_1:


    sofia ""


translate korean sofiapool_0664179c_1:


    sofia ""


translate korean sofiapool_f99d8985_1:


    dpense ""


translate korean sofiapool_de8ff332_1:


    dpense ""


translate korean sofiapool_38c92066_1:


    dpense ""


translate korean sofiapool_8a6010a7_1:


    sofia ""


translate korean sofiapool_aecb242a:


    sofia ""


translate korean sofiapool_cbb4b371:


    sofia ""


translate korean sofiapool_5aee8d42_1:


    sofia ""


translate korean sofiapool_e43ef0da:


    sofia ""


translate korean sofiapool_f9449b96:


    sofia ""


translate korean sofiapool_d8e4cc07_1:


    dpense ""


translate korean sofiapool_0295c7cd:


    sofia ""


translate korean sofiapool_26ee886c:


    sofia ""


translate korean sofiapool_3078de21:


    sofia ""


translate korean sofiapool_636b8efc_1:


    sofia ""


translate korean sofiapool_bb354e6f:


    sofia ""


translate korean sofiapool_038daf43:


    sofia ""


translate korean sofiapool_8fe1a030:


    d ""


translate korean sofiapool_70345f51:


    d ""


translate korean sofiapool_6ca2c9d6:


    sofia ""


translate korean finblueep2_64eaab9a:


    d ""


translate korean finblueep2_1dc39c06:


    sofia ""


translate korean finblueep2_4dc3c5ca:


    d ""


translate korean finblueep2_efc0c1d6:


    sofia ""


translate korean finblueep2_6be327d6:


    sofia ""


translate korean finblueep2_a22554f8:


    d ""


translate korean finblueep2_1f77f57e:


    sofia ""


translate korean finblueep2_2c98ee9b:


    sofia ""


translate korean finblueep2_11f964e5:


    d ""


translate korean finblueep2_9e894c95:


    dpense ""

translate korean strings:


    old "5 MINUTES LATER"
    new ""


    old "Follow her. [TEMP1!t]"
    new ""


    old "Reject her. [TEMP2!t]"
    new ""


    old "Sport [TEMP1!t]"
    new ""


    old "Temperament [TEMP2!t]"
    new ""


    old "Go faster [TEMP1!t]"
    new ""


    old "Watch her [TEMP2!t]"
    new ""


    old "Swim normally [TEMP3!t]"
    new ""


    old "Go even faster [TEMP1!t]"
    new ""


    old "Cheat [TEMP2!t]"
    new ""


    old "Sprint [TEMP1!t]"
    new ""


    old "Win [TEMP2!t]"
    new ""


    old "Let her win [TEMP3!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
