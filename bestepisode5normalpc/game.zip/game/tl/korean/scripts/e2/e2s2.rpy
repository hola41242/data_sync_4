


translate korean e2s2_699705df:


    d ""


translate korean e2s2_2651da73:


    julia ""


translate korean e2s2_a09a9275:


    d ""


translate korean e2s2_747f24b1:


    julia ""


translate korean e2s2_81710995:


    julia ""


translate korean e2s2_a69974f7:


    d ""


translate korean e2s2_f013355a:


    d ""


translate korean e2s2_649f8856:


    d ""


translate korean e2s2_0ddb529d:


    julia ""


translate korean e2s2_4194debf:


    d ""


translate korean e2s2_2e7a7210:


    d ""


translate korean e2s2_2d9dc3c5:


    d ""


translate korean e2s2_60da1eec:


    julia ""


translate korean e2s2_1b8d5ee7:


    julia ""


translate korean e2s2_ec991449:


    d ""


translate korean e2s2_4e3f7e5b:


    d ""


translate korean e2s2_170cdd76:


    julia ""


translate korean e2s2_fdd47e50:


    julia ""


translate korean e2s2_1bae9f5e:


    d ""


translate korean e2s2_1c7dbdcc:


    d ""


translate korean e2s2_a42f6436:


    julia ""


translate korean e2s2_ef6e3ce0:


    d ""


translate korean e2s2_a4b21c2c:


    julia ""


translate korean e2s2_ddeb79fb:


    d ""


translate korean e2s2_528a694f:


    julia ""


translate korean e2s2_2abccca6:


    d ""


translate korean e2s2_f5bfadf3:


    d ""


translate korean e2s2_04da4eb4:


    julia ""


translate korean e2s2_2f84c3bb:


    d ""


translate korean e2s2_0ff2a046:


    d ""


translate korean e2s2_2a1cca83:


    julia ""


translate korean e2s2_210ff254:


    julia ""


translate korean e2s2_e1c58ffa:


    d ""


translate korean e2s2_ac2e69c2:


    julia ""


translate korean e2s2_f6cfd155:


    julia ""


translate korean e2s2_e4720c4a:


    julia ""


translate korean e2s2_ad3f6506:


    d ""


translate korean e2s2_a34dcd03:


    julia ""


translate korean e2s2_9d401a52:


    d ""


translate korean e2s2_b389601e:


    julia ""


translate korean e2s2_a97e81c6:


    julia ""


translate korean e2s2_f1b6f7a1:


    d ""


translate korean e2s2_73733c8a:


    julia ""


translate korean e2s2_2c2249c6:


    julia ""


translate korean e2s2_198ee8a3:


    d ""


translate korean e2s2_4e619f92:


    julia ""


translate korean e2s2_ff8f5d14:


    d ""


translate korean e2s2_a59c2be9:


    julia ""


translate korean e2s2_f96d060b:


    d ""


translate korean e2s2_cbc0a567:


    julia ""


translate korean e2s2_2154c2d6:


    julia ""


translate korean e2s2_f515507e:


    d ""


translate korean e2s2_5609f7b7:


    julia ""


translate korean e2s2_17d1ebbd:


    julia ""


translate korean e2s2_063a254d:


    d ""


translate korean e2s2_2f7bba62:


    julia ""


translate korean e2s2_1ef78c01:


    d ""


translate korean e2s2_31bb772d:


    julia ""


translate korean e2s2_76e1c2af:


    julia ""


translate korean e2s2_a0507f21:


    julia ""


translate korean e2s2_cd5b7cef:


    d ""


translate korean e2s2_4b92c7e2:


    julia ""


translate korean e2s2_5c581896:


    d ""


translate korean e2s2_7c2f365c:


    julia ""


translate korean e2s2_f37455ff:


    d ""


translate korean e2s2_101332d7:


    julia ""


translate korean e2s2_c5609e2e:


    d ""


translate korean e2s2_8d85d16f:


    julia ""


translate korean e2s2_5bc0ea87:


    d ""


translate korean e2s2_40ea1b9b:


    d ""


translate korean e2s2_1ee38eaf:


    julia ""


translate korean e2s2_bdb8233e:


    d ""


translate korean e2s2_da81affe:


    julia ""


translate korean e2s2_5bc0ea87_1:


    d ""


translate korean e2s2_045838c2:


    d ""


translate korean e2s2_101332d7_1:


    julia ""


translate korean e2s2_c5609e2e_1:


    d ""


translate korean e2s2_8ae374e1:


    julia ""


translate korean e2s2_5bc0ea87_2:


    d ""


translate korean e2s2_6b7da03e:


    d ""


translate korean e2s2_1ee38eaf_1:


    julia ""


translate korean e2s2_bdb8233e_1:


    d ""


translate korean e2s2_da81affe_1:


    julia ""


translate korean e2s2_5bc0ea87_3:


    d ""


translate korean e2s2_97eb4ac6:


    julia ""


translate korean e2s2_2c11e212:


    julia ""


translate korean e2s2_f36a5ff4:


    d ""


translate korean e2s2_597f2c85:


    julia ""


translate korean e2s2_39b61a84:


    julia ""


translate korean e2s2_16c75a70:


    d ""


translate korean e2s2_a4696a89:


    julia ""


translate korean e2s2_43b49e4c:


    d ""


translate korean e2s2_58a7c153:


    julia ""


translate korean e2s2_360c3a8e:


    d ""


translate korean e2s2_aeb44433:


    julia ""


translate korean e2s2_c5e72fc1:


    d ""


translate korean e2s2_a55c01fd:


    julia ""


translate korean e2s2_69793ab9:


    julia ""


translate korean e2s2_b651150d:


    d ""


translate korean e2s2_ccd58cdf:


    julia ""


translate korean e2s2_df522c84:


    julia ""


translate korean e2s2_0aae168a:


    d ""


translate korean e2s2_08822955:


    julia ""


translate korean e2s2_f526b9a7:


    julia ""


translate korean e2s2_ebd88aab:


    julia ""


translate korean e2s2_02fcf1f9:


    julia ""


translate korean e2s2_c372f1a0:


    d ""


translate korean e2s2_09f84ac2:


    julia ""


translate korean e2s2_df3539f1:


    d ""


translate korean e2s2_f49e8424:


    dpense ""

translate korean strings:


    old "Ask about her love life [TEMP1!t]"
    new ""


    old "Ask about the others [TEMP2!t]"
    new ""


    old "I like Blue [TEMP1!t]"
    new ""


    old "I don't like Blue [TEMP2!t]"
    new ""


    old "I like Red [TEMP1!t]"
    new ""


    old "I don't like Red [TEMP2!t]"
    new ""


    old "Visit the swimming pool [TEMP1!t]"
    new ""


    old "Return to my room [TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
