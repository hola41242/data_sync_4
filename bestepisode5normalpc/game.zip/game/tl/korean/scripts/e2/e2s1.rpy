


translate korean e2s1_03ecf3cb:


    dpense ""


translate korean e2s1_e3368f91:


    dpense ""


translate korean e2s1_981aa673:


    dpense ""


translate korean e2s1_a576b045:


    dpense ""


translate korean e2s1_d23f0865:


    dpense ""


translate korean e2s1_96a9da0e:


    d ""


translate korean e2s1_055fcf24:


    d ""


translate korean e2s1_c247cc91:


    d ""


translate korean e2s1_e19559ea:


    d ""


translate korean e2s1_d16b1e74:


    d ""


translate korean e2s1_ab629bc0:


    ruby ""


translate korean e2s1_2f797be5:


    d ""


translate korean e2s1_553923c3:


    ruby ""


translate korean e2s1_b2842d1b:


    d ""


translate korean e2s1_5949d107:


    ruby ""


translate korean e2s1_b3a81635:


    d ""


translate korean e2s1_d2c08699:


    ruby ""


translate korean e2s1_44b10ff2:


    d ""


translate korean e2s1_054790de:


    ruby ""


translate korean e2s1_da01005d:


    ruby ""


translate korean e2s1_c71a801b:


    d ""


translate korean e2s1_7abb44d8:


    emerick ""


translate korean e2s1_bec82cb9:


    orushi ""


translate korean e2s1_474b3cf8:


    orushi ""


translate korean e2s1_0de5a8e8:


    emerick ""


translate korean e2s1_fa66421e:


    orushi ""


translate korean e2s1_b14aabed:


    rufus ""


translate korean e2s1_d933fc72:


    orushi ""


translate korean e2s1_24ab3896:


    orushi ""


translate korean e2s1_2aaf9bb0:


    orushi ""


translate korean e2s1_cf4435e1:


    emerick ""


translate korean e2s1_35a7916f:


    orushi ""


translate korean e2s1_9512b329:


    emerick ""


translate korean e2s1_76552bd6:


    orushi ""


translate korean e2s1_cd9cde25:


    emerick ""


translate korean e2s1_e51d9fe2:


    orushi ""


translate korean e2s1_6d3040d9:


    emerick ""


translate korean e2s1_af86760f:


    ruby ""


translate korean e2s1_7cc5e482:


    julia ""


translate korean e2s1_f02b1c50:


    grace ""


translate korean e2s1_7ee5c516:


    grace ""


translate korean e2s1_f12f82c3:


    grace ""


translate korean e2s1_d579fcfd:


    grace ""


translate korean e2s1_19e030da:


    grace ""


translate korean e2s1_69d97443:


    julia ""


translate korean e2s1_c35ce243:


    grace ""


translate korean e2s1_9f2c3adf:


    grace ""


translate korean e2s1_b47d10ff:


    ruby ""


translate korean e2s1_e8410113:


    grace ""


translate korean e2s1_93b521a5:


    ruby ""


translate korean e2s1_7ef21552:


    grace ""


translate korean e2s1_669f4ba0:


    d ""


translate korean e2s1_6eba75e1:


    grace ""


translate korean e2s1_a933aa2c:


    d ""


translate korean e2s1_5e9c212e:


    grace ""


translate korean e2s1_639b4fca:


    d ""


translate korean e2s1_83df6de2:


    grace ""


translate korean e2s1_ed8c99c0:


    d ""


translate korean e2s1_2d9406be:


    grace ""


translate korean e2s1_5a82890d:


    d ""


translate korean e2s1_1bb364fc:


    dpense ""


translate korean e2s1_deca88bf:


    mad ""


translate korean e2s1_db67b519:


    grace ""


translate korean e2s1_d4a4d528:


    mad ""


translate korean e2s1_21e11beb:


    mad ""


translate korean e2s1_b6cd12ff:


    d ""


translate korean e2s1_53066af2:


    mad ""


translate korean e2s1_694d95bd:


    ruby ""


translate korean e2s1_9d81cd20:


    mad ""


translate korean e2s1_a114d9b6:


    d ""


translate korean e2s1_378658d6:


    mad ""


translate korean e2s1_340fa348:


    mad ""


translate korean e2s1_7bc8a915:


    ruby ""


translate korean e2s1_dbd14366:


    mad ""


translate korean e2s1_71f3cdde:


    d ""


translate korean e2s1_9bb66f10:


    mad ""


translate korean e2s1_5865f53d:


    ruby ""


translate korean e2s1_30bbab5f:


    mad ""


translate korean e2s1_f1baba71:


    d ""


translate korean e2s1_f5eabbd4:


    d ""


translate korean e2s1_b0cb56e3:


    mad ""


translate korean e2s1_9aba7878:


    d ""


translate korean e2s1_c7579901:


    mad ""


translate korean e2s1_dc5b375f:


    ruby ""


translate korean e2s1_68ae02f5:


    julia ""


translate korean e2s1_4acc53b4:


    ruby ""


translate korean e2s1_73fda96c:


    ruby ""


translate korean e2s1_9e26ec3f:


    ruby ""


translate korean e2s1_61df0e42:


    ruby ""


translate korean e2s1_d3bb40de:


    julia ""


translate korean e2s1_6541b6d1:


    ruby ""


translate korean e2s1_85ec0c6b:


    grace ""


translate korean e2s1_9b5f314f:


    ruby ""


translate korean e2s1_6e7805f2:


    mad ""


translate korean e2s1_8805bde7:


    ruby ""


translate korean e2s1_c1835389:


    d ""


translate korean e2s1_e9754cba:


    ruby ""


translate korean e2s1_2fef4c63:


    ruby ""


translate korean e2s1_2736e21d:


    d ""


translate korean e2s1_262a0855:


    ruby ""


translate korean e2s1_6443aa2f:


    mad ""


translate korean e2s1_5f285438:


    ruby ""


translate korean e2s1_cfb4ca65:


    ruby ""


translate korean e2s1_60191ee4:


    ruby ""


translate korean e2s1_d15659ac:


    ruby ""


translate korean e2s1_da182dc0:


    ruby ""


translate korean e2s1_f491c4c0:


    ruby ""


translate korean e2s1_ff85cb50:


    ruby ""


translate korean e2s1_bec58da1:


    ruby ""


translate korean e2s1_ce194798:


    ruby ""


translate korean e2s1_4f9373b1:


    ruby ""


translate korean e2s1_8222f50e:


    ruby ""


translate korean e2s1_311c7ed2:


    ruby ""


translate korean e2s1_81b67b85:


    d ""


translate korean e2s1_1a6dede1:


    ruby ""


translate korean e2s1_012699c5:


    ruby ""


translate korean e2s1_69f1461a:


    ruby ""


translate korean e2s1_c679b986:


    mad "" with hpunch


translate korean e2s1_b9868f46:


    julia ""


translate korean e2s1_2942cb63:


    ruby ""


translate korean e2s1_8cadab8e:


    ruby ""


translate korean e2s1_9d1ff317:


    mad ""


translate korean e2s1_567e0472:


    ruby ""


translate korean e2s1_9ea61dc5:


    mad ""


translate korean e2s1_b8d61786:


    ruby ""


translate korean e2s1_f2334755:


    julia ""


translate korean e2s1_5850cbe3:


    ruby ""


translate korean e2s1_041b7546:


    grace ""


translate korean e2s1_5eab819b:


    ruby ""


translate korean e2s1_386f66a6:


    grace ""


translate korean e2s1_004af490:


    ruby ""


translate korean e2s1_d772cdb6:


    ruby ""


translate korean e2s1_e2297a88:


    ruby ""


translate korean e2s1_5a63cb46:


    ruby ""


translate korean e2s1_505f342d:


    julia ""


translate korean e2s1_e1cf0ec0:


    mad ""


translate korean e2s1_505f342d_1:


    julia ""


translate korean e2s1_a4ae5c62:


    grace ""


translate korean e2s1_b1dc201a:


    d ""


translate korean chosenkiss_c0c7ea31:


    chosen ""


translate korean chosenkiss_80e6294b:


    mad ""


translate korean chosenkiss_29561989:


    ruby ""


translate korean chosenkiss_8b5643a9:


    ruby ""


translate korean chosenkiss_fb631fdc:


    mad ""


translate korean chosenkiss_370788c5:


    ruby ""


translate korean chosenkiss_134961cf:


    mad ""


translate korean chosenkiss_7e7e2e62:


    ruby ""


translate korean chosenkiss_bc824b1a:


    mad ""


translate korean chosenkiss_f653a44a:


    grace ""


translate korean chosenkiss_8af8bebb:


    ruby ""


translate korean chosenkiss_c7db646b:


    mad ""


translate korean chosenkiss_99cbf7ae:


    ruby ""


translate korean chosenkiss_42486048:


    julia ""


translate korean chosenkiss_36cccf90:


    grace ""


translate korean chosenkiss_aede0390:


    ruby ""


translate korean chosenkiss_bdfd47df:


    mad ""


translate korean chosenkiss_894769a1:


    ruby ""


translate korean chosenkiss_835b305a:


    ruby ""


translate korean chosenkiss_29ac5843:


    d ""


translate korean chosenkiss_ce2d5e47:


    ruby ""


translate korean chosenkiss_6d3dab99:


    grace ""


translate korean chosenkiss_24160dd1:


    ruby ""


translate korean chosenkiss_c5257780:


    ruby ""


translate korean chosenkiss_8258fe0c:


    ruby ""


translate korean chosenkiss_ce93967e:


    ruby ""


translate korean chosenkiss_392c2d22:


    ruby ""


translate korean chosenkiss_5ce70a32:


    mad ""


translate korean chosenkiss_4b1161c1:


    ruby ""


translate korean chosenkiss_58c738d5:


    ruby ""


translate korean chosenkiss_16d76ed1:


    julia ""


translate korean chosenkiss_f48f8f08:


    ruby ""


translate korean chosenkiss_a9acb29d:


    julia ""


translate korean chosenkiss_188cc25b:


    ruby ""


translate korean chosenkiss_939fccd4:


    d ""


translate korean chosenkiss_a29cc547:


    ruby ""


translate korean chosenkiss_e38298e5:


    d "" with hpunch


translate korean chosenkiss_c1826e34:


    ruby ""


translate korean chosenkiss_5eefb60e:


    grace ""


translate korean chosenkiss_91afb2d6:


    mad "" with hpunch


translate korean chosenkiss_a393b1dd:


    julia ""


translate korean chosenkiss_e593a657:


    mad ""


translate korean chosenkiss_a6936512:


    grace ""


translate korean chosenkiss_b01b9536:


    mad ""


translate korean chosenkiss_e453b0a8:


    d ""


translate korean chosenkiss_3377260b:


    ruby ""


translate korean chosenkiss_4035bba9:


    mad ""


translate korean chosenkiss_d6b663b2:


    ruby ""


translate korean chosenkiss_afde39b0:


    ruby ""


translate korean chosenkiss_30d62a1a:


    grace ""


translate korean chosenkiss_1df83774:


    grace ""


translate korean chosenkiss_8ca883d5:


    julia ""


translate korean chosenkiss_4dcee382:


    mad ""


translate korean chosenkiss_daafaac8:


    ruby ""


translate korean chosenkiss_2a5dc559:


    mad ""


translate korean chosenkiss_93e11265:


    ruby ""


translate korean chosenkiss_18ee35c4:


    grace ""


translate korean chosenkiss_c1d261d7:


    ruby ""


translate korean chosenkiss_c8aa12cf:


    julia ""


translate korean chosenkiss_d9cecfb7:


    ruby ""


translate korean chosenkiss_c735661d:


    ruby ""


translate korean chosenkiss_305242eb:


    d ""


translate korean chosenkiss_29470446:


    ruby ""


translate korean chosenkiss_4f6772e8:


    ruby ""


translate korean chosenkiss_334f2a21:


    ruby ""


translate korean chosenkiss_a548b7ad:


    grace ""


translate korean chosenkiss_2bc88dcb:


    ruby ""


translate korean chosenkiss_a3493863:


    grace ""


translate korean chosenkiss_ecde9d6a:


    ruby ""


translate korean chosenkiss_0dafd5f9:


    grace ""


translate korean chosenkiss_01eb2f6a:


    ruby ""


translate korean chosenkiss_ef85cac4:


    grace ""


translate korean chosenkiss_ef037255:


    ruby ""


translate korean chosenkiss_38c5cdf2:


    ruby ""


translate korean chosenkiss_e80a0892:


    mad ""


translate korean chosenkiss_def43184:


    ruby ""


translate korean chosenkiss_6a4f23ef:


    grace ""


translate korean chosenkiss_d60a073d:


    ruby ""


translate korean chosenkiss_b79a1c45:


    ruby ""


translate korean chosenkiss_841cf19e:


    ruby ""


translate korean chosenkiss_b6788b9d:


    grace ""


translate korean chosenkiss_b4359a05:


    ruby ""


translate korean chosenkiss_45f140c1:


    mad ""


translate korean chosenkiss_e1aa72bf:


    grace ""


translate korean chosenkiss_cd7a880b:


    julia ""


translate korean chosenkiss_9f40f626:


    ruby ""


translate korean chosenkiss_dd5d68f3:


    d ""


translate korean chosenkiss_d5ab8d28:


    ruby ""


translate korean chosenkiss_2c3a63c7:


    d ""


translate korean chosenkiss_1a514c11:


    ruby ""


translate korean chosenkiss_476ab487:


    ruby ""


translate korean chosenkiss_600af04a:


    ruby ""


translate korean chosenkiss_e8625ea9:


    ruby ""


translate korean chosenkiss_a9cca5de:


    ruby ""


translate korean chosenkiss_705eeb93:


    ruby ""


translate korean chosenkiss_9d7730bf:


    ruby ""


translate korean chosenkiss_28d95fb6:


    julia ""


translate korean chosenkiss_a8699778:


    d ""


translate korean chosenkiss_d3559afb:


    ruby ""


translate korean chosenkiss_1e5dfb0e:


    mad ""


translate korean chosenkiss_44699cd8:


    grace ""


translate korean chosenkiss_c02f63b0:


    julia ""


translate korean chosenkiss_b8c86f42:


    grace ""


translate korean chosenkiss_dd120e78:


    d ""


translate korean chosenkiss_3fb1de81:


    julia ""


translate korean chosenkiss_df802e86:


    d ""


translate korean chosenkiss_3989a49b:


    julia ""


translate korean chosenkiss_34c55b1f:


    d ""


translate korean chosenkiss_3fcacb3d:


    julia ""


translate korean chosenkiss_8f1df40c:


    grace ""


translate korean chosenkiss_c4897051:


    grace ""


translate korean chosenkiss_ef579692:


    julia ""


translate korean chosenkiss_38715887:


    grace ""


translate korean chosenkiss_3896858a:


    julia ""


translate korean chosenkiss_21922934:


    d ""


translate korean chosenkiss_8121b812:


    julia ""


translate korean chosenkiss_ce7133ef:


    julia ""

translate korean strings:


    old "EPISODE 2 {p} \n Double Trouble"
    new ""


    old "NEW CONTACT ADDED"
    new ""


    old "Buddy [TEMP1!t]"
    new ""


    old "Education [TEMP2!t]"
    new ""


    old "Sport [TEMP3!t]"
    new ""


    old "Temperament [TEMP4!t]"
    new ""


    old "I'm not a fan of older women."
    new ""


    old "Age has nothing to do with feelings. [TEMP1!t]"
    new ""


    old "Milfs are life! [TEMP2!t]"
    new ""


    old "Yes, definitely! [TEMP1!t]"
    new ""


    old "No, I don't like it. [TEMP2!t]"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
