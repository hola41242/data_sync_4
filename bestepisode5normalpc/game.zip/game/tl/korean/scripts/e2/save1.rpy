


translate korean save1_285f8ea7:


    ""

translate korean strings:


    old "SAVE NOW"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
