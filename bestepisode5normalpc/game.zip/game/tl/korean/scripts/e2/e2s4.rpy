


translate korean e2s4_5b6b04d6:


    ji ""


translate korean e2s4_c2c97b56:


    ted ""


translate korean e2s4_6d11133e:


    cassie ""


translate korean e2s4_a42216b5:


    ted ""


translate korean e2s4_692a2f61:


    cassie ""


translate korean e2s4_98a1471a:


    ted ""


translate korean e2s4_441c0783:


    mad ""


translate korean e2s4_d3ea60d5:


    mad ""


translate korean e2s4_32fabfce:


    mad ""


translate korean e2s4_34413095:


    mad ""


translate korean e2s4_15fa04e3:


    mad ""


translate korean e2s4_0db593f2:


    ted ""


translate korean e2s4_d1c52f83:


    mad ""


translate korean e2s4_0db593f2_1:


    ted ""


translate korean e2s4_a7500e50:


    mad ""


translate korean e2s4_0db593f2_2:


    ted ""


translate korean e2s4_c7abb2c6:


    mad ""


translate korean e2s4_699afde9:


    mad ""


translate korean e2s4_2f399ecc:


    cassie ""


translate korean e2s4_6ea8c9bd:


    mad ""


translate korean e2s4_e03d9c57:


    cassie ""


translate korean e2s4_3511f9dc:


    mad ""


translate korean e2s4_0c084aee:


    mad ""


translate korean e2s4_a512fbd7:


    mad ""


translate korean e2s4_cb7c44c2:


    mad ""


translate korean e2s4_8cca5e36:


    mad ""


translate korean e2s4_bc9e9ad6:


    mad ""


translate korean e2s4_90d878c6:


    beth ""


translate korean e2s4_04f3053e:


    sofia ""


translate korean e2s4_4a9669cc:


    mad ""


translate korean e2s4_26f6c27a:


    mad ""


translate korean e2s4_5cbb791c:


    ruby ""


translate korean e2s4_d215ddd0:


    mad ""


translate korean e2s4_b10d9f66:


    ruby ""


translate korean e2s4_9ec6269c:


    mad ""


translate korean e2s4_3edbc739:


    mad ""


translate korean e2s4_62205d67:


    ruby ""


translate korean e2s4_efde3ab7:


    mad ""


translate korean e2s4_24bb991b:


    mad ""


translate korean e2s4_595c80ce:


    mad ""


translate korean e2s4_31b16005:


    ruby ""


translate korean e2s4_8cbe499c:


    ruby ""


translate korean e2s4_94518faf:


    mad ""


translate korean e2s4_7dc72278:


    mad ""


translate korean e2s4_62e0c03b:


    ruby ""


translate korean e2s4_d19ecb96:


    mad ""


translate korean e2s4_77ba680b:


    ruby ""


translate korean e2s4_37f47a0b:


    d ""


translate korean e2s4_abda508c:


    d ""


translate korean madiruby_cb5052fe:


    d ""


translate korean madiruby_94364417:


    ruby ""


translate korean madiruby_93f7fde9:


    mad ""


translate korean madiruby_230cca25:


    d ""


translate korean madiruby_280960ba:


    ruby ""


translate korean madiruby_d22bf5e3:


    d ""


translate korean madiruby_b4f07fd2:


    mad ""


translate korean madiruby_fbef33c9:


    d ""


translate korean madiruby_28d87aa3:


    ruby ""


translate korean madiruby_bf8a9c0a:


    ruby ""


translate korean madiruby_3efb7af7:


    mad ""


translate korean madiruby_dbf9b320:


    d ""


translate korean madiruby_af9136f3:


    mad ""


translate korean madiruby_e55d32ad:


    d ""


translate korean madiruby_40e66c37:


    mad ""


translate korean madiruby_5f32c47f:


    ruby ""


translate korean gracejulia_cb5052fe:


    d ""


translate korean gracejulia_02600786:


    grace ""


translate korean gracejulia_e9b99907:


    julia ""


translate korean gracejulia_230cca25:


    d ""


translate korean gracejulia_1f1d00ef:


    julia ""


translate korean gracejulia_dbed4522:


    d ""


translate korean gracejulia_1ba870f0:


    julia ""


translate korean gracejulia_5e3e5401:


    julia ""


translate korean gracejulia_7bcc50f4:


    d ""


translate korean gracejulia_5b680b5d:


    grace ""


translate korean gracejulia_67acc6de:


    d ""


translate korean gracejulia_cef63d47:


    grace ""


translate korean gracejulia_f07527e5:


    d ""


translate korean gracejulia_d10a5469:


    grace ""


translate korean sittwins_bfce7842:


    d ""


translate korean sittwins_49293452:


    beth ""


translate korean sittwins_f9455265:


    sofia ""


translate korean sittwins_2686ee98:


    sofia ""


translate korean sittwins_dd8c52d3:


    d ""


translate korean sittwins_8b052222:


    beth ""


translate korean sittwins_56e443ac:


    beth ""


translate korean sittwins_b660916b:


    beth ""


translate korean sittwins_e78947be:


    sofia ""


translate korean sittwins_013dbb2f:


    d ""


translate korean sittwins_7d2ee7e5:


    beth ""


translate korean sittwins_ace3b8d4:


    beth ""


translate korean sittwins_10760d33:


    beth ""


translate korean sittwins_99c38ec9:


    beth ""


translate korean sittwins_ab131cde:


    beth ""


translate korean sittwins_6710910f:


    sofia ""


translate korean sittwins_9ca925ff:


    sofia ""


translate korean sittwins_9ea58198:


    sofia ""


translate korean sittwins_03cc4247:


    sofia ""


translate korean sittwins_590ce44c:


    sofia ""


translate korean sittwins_f338cc08:


    d ""


translate korean suitecours_46fb28ab:


    gaby ""


translate korean suitecours_883d9886:


    gaby ""


translate korean suitecours_fa87f52f:


    gaby ""


translate korean suitecours_ac5e6d6c:


    gaby ""


translate korean suitecours_58ff09da:


    gaby ""


translate korean suitecours_c9d37095:


    gaby ""


translate korean suitecours_34d67876:


    gaby ""


translate korean suitecours_6f2a997a:


    gaby ""


translate korean suitecours_85fcfaee:


    gaby ""


translate korean suitecours_2d1f1461:


    d ""


translate korean suitecours_5532afff:


    gaby ""


translate korean suitecours_11a49d80:


    gaby ""


translate korean suitecours_b2842d1b:


    d ""


translate korean suitecours_daf08564:


    gaby ""


translate korean suitecours_4f3652ea:


    d ""


translate korean suitecours_4debf90f:


    ruby ""


translate korean suitecours_27de816f:


    gaby ""


translate korean suitecours_df0cb0e4:


    gaby ""


translate korean suitecours_d88d27c1:


    d ""


translate korean suitecours_bf5156e3:


    gaby ""


translate korean suitecours_a1418d15:


    gaby ""


translate korean suitecours_596be531:


    d ""


translate korean suitecours_df0cb0e4_1:


    gaby ""


translate korean suitecours_4367836d:


    d ""


translate korean suitecours_6c000199:


    gaby ""


translate korean suitecours_531910ca:


    d ""


translate korean suitecours_df0cb0e4_2:


    gaby ""


translate korean suitecours_2df75f35:


    d ""


translate korean suitecours_a1699582:


    gaby ""


translate korean suitecours_a9642ea4:


    d ""


translate korean suitecours_9504acb6:


    gaby ""


translate korean suitecours_df0cb0e4_3:


    gaby ""


translate korean suitecours_63b979ab:


    gaby ""


translate korean suitecours_099834b3:


    gaby ""


translate korean suitecours_ae64f34d:


    d ""


translate korean suitecours_a7a44cf1:


    mad ""


translate korean suitecours_3f883698:


    d ""


translate korean suitecours_91da6cea:


    mad ""


translate korean suitecours_d38968bc:


    d ""


translate korean suitecours_57cbaadd:


    emerick "" with hpunch


translate korean suitecours_3df4aaa1:


    d ""


translate korean suitecours_2d6dad60:


    gaby ""


translate korean suitecours_ca813997:


    mad ""


translate korean suitecours_edf1868e:


    mad ""


translate korean suitecours_3f883698_1:


    d ""


translate korean suitecours_0a6ece95:


    mad ""


translate korean suitecours_244ef33c:


    mad ""


translate korean suitecours_36794003:


    gaby ""


translate korean suitecours_dc636991:


    emerick ""


translate korean suitecours_7e3ae4e5:


    gaby ""


translate korean suitecours_1bb5a634:


    emerick ""


translate korean suitecours_781a1cd8:


    mad ""


translate korean suitecours_26af0923:


    dpense ""


translate korean suitecours_57cbaadd_1:


    emerick "" with hpunch


translate korean suitecours_3df4aaa1_1:


    d ""


translate korean suitecours_2d6dad60_1:


    gaby ""


translate korean suitecours_087fee55:


    gaby ""


translate korean suitecours_af59083d:


    gaby ""


translate korean suitecours_916d515d:


    drew "" with hpunch


translate korean suitecours_6820b807:


    drew ""


translate korean suitecours_938fcc14:


    drew ""


translate korean suitecours_e6f31e6b:


    drew ""


translate korean suitecours_d7c1bae8:


    gaby ""


translate korean suitecours_aab8223d:


    gaby ""


translate korean suitecours_cb6abcd7:


    orushi ""


translate korean suitecours_04c60917:


    orushi ""


translate korean suitecours_7d3c0eb2:


    orushi ""


translate korean suitecours_2ac1c2b2:


    orushi ""


translate korean suitecours_0d63aeed:


    orushi ""


translate korean suitecours_118c8a2c:


    orushi ""


translate korean suitecours_fae9f837:


    orushi ""


translate korean suitecours_fac953e3:


    orushi ""


translate korean suitecours_d57d8af8:


    orushi ""


translate korean suitecours_29f0eedd:


    orushi ""


translate korean suitecours_7377b77c:


    orushi ""


translate korean suitecours_13d3ec80:


    orushi ""


translate korean suitecours_dea55d2d:


    orushi ""


translate korean suitecours_2bc2747c:


    orushi ""


translate korean suitecours_88d75d0b:


    orushi ""


translate korean suitecours_c42abb16:


    orushi ""


translate korean suitecours_72a3d47a:


    orushi ""


translate korean suitecours_c87ce251:


    orushi ""


translate korean suitecours_d32d8b03:


    orushi ""


translate korean suitecours_0a5480e5:


    orushi ""


translate korean suitecours_736785cb:


    orushi ""


translate korean suitecours_040186bf:


    orushi ""


translate korean suitecours_1e8bfa8c:


    orushi ""


translate korean suitecours_12414ce8:


    orushi ""


translate korean suitecours_48785378:


    orushi ""


translate korean suitecours_d09ce434:


    orushi ""


translate korean suitecours_11afa90a:


    s ""


translate korean suitecours_b2136f6a:


    orushi ""


translate korean suitecours_1a6f6865:


    s ""


translate korean suitecours_c282e467:


    orushi ""


translate korean suitecours_905cbf84:


    emerick ""


translate korean suitecours_59809014:


    orushi ""


translate korean suitecours_19945eb9:


    orushi ""


translate korean suitecours_90670405:


    mad ""


translate korean suitecours_acf02fcb:


    orushi ""


translate korean suitecours_c9f2c988:


    mad ""


translate korean suitecours_b31bba35:


    orushi ""


translate korean suitecours_cbab976a:


    s ""


translate korean suitecours_e8b0f8fe:


    emerick ""


translate korean suitecours_ebdc68c4:


    emerick ""


translate korean suitecours_2cfb5c45:


    beth ""


translate korean suitecours_cfc2ff6b:


    ji ""


translate korean suitecours_90146bcc:


    ji ""


translate korean suitecours_daeb8dcf:


    ji ""


translate korean suitecours_0f400b9e:


    ji ""


translate korean suitecours_b9695e43:


    ji ""


translate korean suitecours_37e3f6ae:


    mad ""


translate korean suitecours_355fdbbd:


    d ""


translate korean suitecours_eeebc711:


    mad ""


translate korean suitecours_ed398876:


    s ""


translate korean suitecours_75c8baf1:


    emerick ""


translate korean suitecours_ba6a93d7:


    mad ""


translate korean suitecours_a5120c1c:


    s ""


translate korean suitecours_c9eabda7:


    mad ""


translate korean suitecours_b6c17e44:


    mad ""


translate korean suitecours_42b56b32:


    mad ""


translate korean suitecours_ed398876_1:


    s ""


translate korean suitecours_75c8baf1_1:


    emerick ""


translate korean suitecours_c9eabda7_1:


    mad ""


translate korean suitecours_a5120c1c_1:


    s ""


translate korean suitecours_b6c17e44_1:


    mad ""


translate korean suitecours_b736ea3c:


    ruby ""


translate korean suitecours_636a4cae:


    mad ""


translate korean suitecours_8bb0774f:


    ruby ""


translate korean suitecours_77f04cb3:


    mad ""


translate korean suitecours_5d37a177:


    d ""


translate korean suitecours_1c7f72b8:


    mad ""


translate korean suitecours_4db55881:


    orushi ""


translate korean suitecours_4bb9c3da:


    orushi ""


translate korean suitecours_035d09f5:


    orushi ""


translate korean suitecours_3cb93f68:


    orushi ""


translate korean suitecours_6ef0da47:


    orushi ""


translate korean suitecours_9c47e601:


    orushi ""


translate korean suitecours_ec0627c7:


    orushi ""


translate korean suitecours_f16f89f9:


    mad ""


translate korean suitecours_584173a2:


    ruby ""


translate korean suitecours_494323f8:


    mad ""


translate korean suitecours_1dbf4149:


    ruby ""


translate korean suitecours_a647ab43:


    d ""


translate korean suitecours_c2c87464:


    d ""


translate korean suitecours_18ae2ed2:


    mad ""


translate korean suitecours_1856c7d4:


    d ""


translate korean suitecours_e0d5187b:


    mad ""


translate korean suitecours_f5e55f54:


    ruby ""


translate korean suitecours_c8aa12cf:


    julia ""


translate korean suitecours_1f45ebf6:


    ruby ""


translate korean suitecours_52b03409:


    julia ""


translate korean suitecours_5c99e476:


    ruby ""


translate korean suitecours_c320f17e:


    emerick ""


translate korean suitecours_4f781c37:


    emerick ""


translate korean suitecours_d42d80c6:


    orushi ""


translate korean suitecours_b416f0d3:


    s ""


translate korean suitecours_d42d80c6_1:


    orushi ""


translate korean suitecours_3988fd6d:


    ji ""


translate korean suitecours_d42d80c6_2:


    orushi ""


translate korean suitecours_3988fd6d_1:


    ji ""


translate korean suitecours_d42d80c6_3:


    orushi ""


translate korean suitecours_3988fd6d_2:


    ji ""


translate korean suitecours_d42d80c6_4:


    orushi ""


translate korean suitecours_3988fd6d_3:


    ji ""


translate korean suitecours_d42d80c6_5:


    orushi ""


translate korean suitecours_3988fd6d_4:


    ji ""


translate korean suitecours_d42d80c6_6:


    orushi ""


translate korean suitecours_a1d614f0:


    orushi ""


translate korean suitecours_5e014e97:


    orushi ""


translate korean suitecours_11df4754:


    orushi ""


translate korean suitecours_09dd397c:


    dpense ""


translate korean suitecours_dac16296:


    d ""


translate korean suitecours_0b442ff1:


    mad ""


translate korean suitecours_58018565:


    d ""


translate korean suitecours_4fa6cf9d:


    mad ""


translate korean suitecours_cf27c58a:


    dpense ""


translate korean rusolve_d3e412b3:


    ruby ""


translate korean rusolve_e494fdfd:


    orushi ""


translate korean rusolve_a932588e:


    ruby ""


translate korean rusolve_28cfd01c:


    orushi ""


translate korean rusolve_6a1566d3:


    emerick ""


translate korean rusolve_fe395a9a:


    d ""


translate korean rusolve_142f5df4:


    ruby ""


translate korean rusolve_59837f76:


    ruby ""


translate korean rusolve_51808edd:


    d ""


translate korean rusolve_3a450a96:


    ruby ""


translate korean rusolve_72987282:


    d ""


translate korean rusolve_30508101:


    d ""


translate korean rusolve_578f2da0:


    d ""


translate korean rusolve_8c4cb72b:


    ji ""


translate korean rusolve_7bcc50f4:


    d ""


translate korean rusolve_170fc44d:


    ruby ""


translate korean rusolve_5f484a7a:


    ji ""


translate korean rusolve_8fdce6a4:


    orushi ""


translate korean rusolve_f8af79d9:


    ji ""


translate korean rusolve_7bcc50f4_1:


    d ""


translate korean rusolve_170fc44d_1:


    ruby ""


translate korean rusolve_5f484a7a_1:


    ji ""


translate korean rusolve_8fdce6a4_1:


    orushi ""


translate korean rusolve_f8af79d9_1:


    ji ""


translate korean rusolve_7bcc50f4_2:


    d ""


translate korean rusolve_170fc44d_2:


    ruby ""


translate korean rusolve_5f484a7a_2:


    ji ""


translate korean rusolve_8fdce6a4_2:


    orushi ""


translate korean centerright_ee586e7e:


    mad ""


translate korean centerright_158bc8fd:


    grace ""


translate korean centerright_7e9b8995:


    julia ""


translate korean centerright_ef6e87dc:


    ruby ""


translate korean centerright_a3f17df4:


    d ""


translate korean centerright_072df15c:


    ruby ""


translate korean centerright_dd5d68f3:


    d ""


translate korean centerright_c13ab685:


    ruby ""


translate korean centerright_d1523116:


    d ""


translate korean centerright_46b44aa9:


    ruby ""


translate korean centerright_dd5d68f3_1:


    d ""


translate korean centerright_5625102b:


    ruby ""


translate korean centerright_f4379931:


    d ""


translate korean centerright_bf9a1fbc:


    d ""


translate korean centerright_59e62df4:


    d ""


translate korean centerright_81959ae4:


    dpense ""


translate korean centerright_02be2d4e:


    orushi ""


translate korean centerright_85a51d50:


    d ""


translate korean centerright_871f33af:


    ruby ""


translate korean centerright_f542d5d6:


    mad ""


translate korean centerright_a508db31:


    ruby ""


translate korean lefttable_f31fcf7b:


    d ""


translate korean lefttable_072df15c:


    ruby ""


translate korean lefttable_dd5d68f3:


    d ""


translate korean lefttable_c13ab685:


    ruby ""


translate korean lefttable_d1523116:


    d ""


translate korean lefttable_46b44aa9:


    ruby ""


translate korean lefttable_dd5d68f3_1:


    d ""


translate korean lefttable_5625102b:


    ruby ""


translate korean lefttable_f4379931:


    d ""


translate korean lefttable_bf9a1fbc:


    d ""


translate korean lefttable_59e62df4:


    d ""


translate korean lefttable_81959ae4:


    dpense ""


translate korean lefttable_02be2d4e:


    orushi ""


translate korean lefttable_85a51d50:


    d ""


translate korean lefttable_871f33af:


    ruby ""


translate korean lefttable_f542d5d6:


    mad ""


translate korean lefttable_a508db31:


    ruby ""


translate korean bluesolve_3b040379:


    d ""


translate korean bluesolve_bf9a1fbc:


    d ""


translate korean bluesolve_59e62df4:


    d ""


translate korean bluesolve_81959ae4:


    dpense ""


translate korean bluesolve_02be2d4e:


    orushi ""


translate korean bluesolve_85a51d50:


    d ""


translate korean bluesolve_f542d5d6:


    mad ""


translate korean resulttable_28601e80:


    orushi ""


translate korean resulttable_af173a75:


    orushi ""


translate korean resulttable_ae065467:


    orushi ""


translate korean resulttable_6f7c934f:


    orushi ""


translate korean resulttable_d0f1a017:


    orushi ""


translate korean resulttable_da9dba80:


    orushi ""


translate korean resulttable_04d36dc5:


    orushi ""


translate korean resulttable_ac7ab3c8:


    mad ""

translate korean strings:


    old "Sit with Madison and Ruby [TEMP1!t]"
    new ""


    old "Sit with Grace and Julia [TEMP2!t]"
    new ""


    old "Sit with the twins [TEMP3!t]"
    new ""


    old "Take the last one !!!"
    new ""


    old "What ?"
    new ""


    old "Do as I say if you want to continue !!!"
    new ""


    old "Trust Blue [TEMP1!t]"
    new ""


    old "Do not trust Blue [TEMP2!t]"
    new ""


    old "Left"
    new ""


    old "Center"
    new ""


    old "Right"
    new ""


    old "Thank you!!!"
    new ""


    old "You owe me one..."
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
