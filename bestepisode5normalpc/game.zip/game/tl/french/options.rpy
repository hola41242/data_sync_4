

translate french strings:


    old "B.E.S.T"
    new "B.E.S.T"



translate french strings:


    old "Credits for music : (Source: https://soundcloud.com //Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nCredits for Scripts :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio // Italian Translation : Eagle1900 // Russian Translation : Pretender // Chinese Translation : V\n\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
    new ""



translate french strings:


    old "Credits for music : (Source: https://soundcloud.com //Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nCredits for Scripts :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio // Italian Translation : Eagle1900 // Russian Translation : Pretender // Chinese Translation : V // Portuguese Translation : Heathens\n\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
    new "Credits for music : (Source: https://soundcloud.com //Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //Téléchargement: https://www.auboutdufil.com):\n\nAerocity - Stranger Amaria - Lovely Swindler Cjbeards - Fire And Thunder Jens East - Daybreak feat Henk KaiEngel - TheRun Keys of Moon - The Success Lyvo - Home Markvard - Desire MaxKoMusic - Ode To The Winners Meydan - Changes Niwel - Bad Love Nomyn - Fragments NovaNoma - Gaia Pachyderm - Never Knew Me at All PhilippWeigl - Subdivision Of The Masses PunchDeck - Destabilized Rexlambo - Stay With Me Sacrifice - EliLortomy Stellardrone - To The Great Beyond Vexento - Now Vexento - Spark\n\nCredits for Scripts :\n\nBadMustard for saves and galleries // Elckarow for the phone // Angel Seraph for achievements\n\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio // Italian Translation : Eagle1900 // Russian Translation : Pretender // Chinese Translation : V // Portuguese Translation : Heathens\n\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
