

translate french strings:


    old "Back"
    new "Retour"


    old "History"
    new "Historique"


    old "Skip"
    new "Avance Rapide"


    old "Auto"
    new "Auto"


    old "Save"
    new "Sauvegarde"


    old "Q.Save"
    new "Sauvegarde Rapide"


    old "Q.Load"
    new "Chargement Rapide"


    old "Prefs"
    new "Préfs"


    old "Start"
    new "Nouvelle partie"


    old "Load"
    new "Charger"


    old "Preferences"
    new "Préférences"


    old "End Replay"
    new "Fin de la rediffusion"


    old "Main Menu"
    new "Menu Principal"


    old "About"
    new "A propos"


    old "Help"
    new "Aide"


    old "Quit"
    new "Quitter"


    old "Return"
    new "Retour"


    old "Version [config.version!t]\n"
    new "Version [config.version!t]\n"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Conçu avec {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"


    old "Page {}"
    new "Page {}"


    old "Automatic saves"
    new "Sauvegardes Automatiques"


    old "Quick saves"
    new "Sauvegardes Rapides"


    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A %d %B %Y, %H:%M"


    old "empty slot"
    new "Emplacement Vide"


    old "<"
    new "<"


    old "{#auto_page}A"
    new "{#auto_page}A"


    old "{#quick_page}Q"
    new "{#quick_page}Q"


    old ">"
    new ">"


    old "Display"
    new "Affichage"


    old "Window"
    new "Fenêtre"


    old "Fullscreen"
    new "Plein Ecran"


    old "Unseen Text"
    new "Texte non vu"


    old "After Choices"
    new "Après les choix"


    old "Transitions"
    new "Transitions"


    old "Text Speed"
    new "Vitesse du texte"


    old "Auto-Forward Time"
    new "Avance Automatique"


    old "Music Volume"
    new "Volume de la musique"


    old "Sound Volume"
    new "Volume des sons"


    old "Test"
    new "Test"


    old "Voice Volume"
    new "Volume des voix"


    old "Mute All"
    new "Mute"


    old "The dialogue history is empty."
    new "L'historique des dialogues est vide."


    old "Keyboard"
    new "Clavier"


    old "Mouse"
    new "Souris"


    old "Gamepad"
    new "Manette"


    old "Enter"
    new "Entrée"


    old "Advances dialogue and activates the interface."
    new "Avance dans les dialogues et active l’interface (effectue un choix)."


    old "Space"
    new "Espace"


    old "Advances dialogue without selecting choices."
    new "Avance dans les dialogues sans effectuer de choix."


    old "Arrow Keys"
    new "Flèches directionnelles"


    old "Navigate the interface."
    new "Permet de se déplacer dans l’interface."


    old "Escape"
    new "Echap."


    old "Accesses the game menu."
    new "Ouvre le menu du jeu."


    old "Ctrl"
    new "Ctrl"


    old "Skips dialogue while held down."
    new "Fait défiler les dialogues tant que la touche est pressée."


    old "Tab"
    new "Tab"


    old "Toggles dialogue skipping."
    new "Active ou désactives les «sauts des dialogues»."


    old "Page Up"
    new "Page Haut"


    old "Rolls back to earlier dialogue."
    new "Retourne au précédent dialogue."


    old "Page Down"
    new "Page Down"


    old "Rolls forward to later dialogue."
    new "Avance jusqu'au prochain dialogue."


    old "Hides the user interface."
    new "Cache l’interface utilisateur."


    old "Takes a screenshot."
    new "Prend une capture d’écran."


    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Active la {a=https://www.renpy.org/l/voicing}{size=24}vocalisation automatique{/size}{/a}."


    old "Opens the accessibility menu."
    new "Ouvre le menu d'accessibilité"


    old "Left Click"
    new "Clic gauche"


    old "Middle Click"
    new "Clic du milieu ou Clic Molette"


    old "Right Click"
    new "Clic Droit"


    old "Mouse Wheel Up\nClick Rollback Side"
    new "Mouse Wheel Up\nClick Rollback Side"


    old "Mouse Wheel Down"
    new "Molette vers le bas"


    old "Right Trigger\nA/Bottom Button"
    new "Bouton R1\nA/Bouton du bas"


    old "Left Trigger\nLeft Shoulder"
    new "Left Trigger\nLeft Shoulder"


    old "Right Shoulder"
    new "Bouton R1"


    old "D-Pad, Sticks"
    new "Boutons directionnels, stick gauche"


    old "Start, Guide"
    new "Start, Guide"


    old "Y/Top Button"
    new "Y/Bouton du haut"


    old "Calibrate"
    new "Calibrage"


    old "Skipping"
    new "Avance en cours"


    old "Menu"
    new "Menu"



translate french strings:


    old "Language"
    new "Langage"


    old "English"
    new "Anglais"


    old "Français"
    new "Français"



translate french strings:


    old "{a=https://patreon.com/Best_the_game}Patreon{/a}"
    new "{a=https://patreon.com/Best_the_game}Patreon{/a}"


    old "{a=https://subscribestar.adult/best-the-game}Subscribestar{/a}"
    new "{a=https://subscribestar.adult/best-the-game}Subscribestar{/a}"



translate french strings:


    old "Save Name"
    new "Nom de la sauvegarde"


    old "{u}Save the Game{/u}"
    new "Sauvegarder"



translate french strings:


    old "Achievements"
    new "Trophées"



translate french strings:


    old "Scenes Gallery"
    new "Scènes Gallerie"



translate french strings:


    old "Textbox Transparency"
    new "Transparence de la Textbox"



translate french strings:


    old "Walkthrough"
    new "Mod d'aide"


    old "On"
    new "ON"



translate french strings:


    old "ON"
    new "ON"


    old "OFF"
    new "OFF"



translate french strings:


    old "Gallery"
    new "Gallerie"



translate french strings:


    old "Streaming Mode"
    new "Mode Streamer"



translate french strings:


    old "Espanol"
    new "Espagnol"



translate french strings:


    old "Italian"
    new "Italien"



translate french strings:


    old "Russian"
    new "Russe"


    old "S.Chinese"
    new "Chinois Simplifié"


    old "T.Chinese"
    new "Chinois Traditionnel"



translate french strings:


    old "Portuguese"
    new "Portugais"



translate french strings:


    old "Japanese"
    new "Japonais"



translate french strings:


    old "Name Save ?"
    new "Nommer sauv.?"


    old "Save game names"
    new "Nommer les sauv."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
