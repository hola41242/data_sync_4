

translate french strings:


    old "Hidden Achievement"
    new "Trophée Caché"



translate french strings:


    old "Achievements | {:01d}/{}"
    new "Trophées | {:01d}/{}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
