

translate french strings:


    old "You have entered the B.E.S.T Game"
    new "Vous êtes entré dans le B.E.S.T"


    old "Start the game"
    new "Commencer le jeu"


    old "Say my name, say my name !"
    new "Say my name, say my name !"


    old "Give your hero a name"
    new "Donner un prénom à votre héros"


    old "Outstanding!"
    new "C'est ouf !"


    old "Get all achievements."
    new "Obtenir tous les trophées"



translate french strings:


    old "Show must go on !"
    new "Show must go on !"


    old "Finish the Prologue"
    new "Finir le prologue"


    old "Finish him !"
    new "Finish him !"


    old "Finish the beta"
    new "Finir la bêta"



translate french strings:


    old "What an ass!"
    new "Oh ! La belle prise !"


    old "Grope Julia"
    new "Attraper Julia"


    old "Cotton Eye Joe !"
    new "Cotton Eye Joe !"


    old "Don't touch Julia"
    new "Ne pas toucher Julia"


    old "Catch them all!"
    new "Attrapez-les tous !"


    old "Catch Grace"
    new "Attraper Grace"


    old "Life in redhead !"
    new "La vie en rousse !"


    old "You've put Grace on her bed"
    new "Vous avez mis Grace dans son lit"



translate french strings:


    old "Pinky and the Braid!"
    new "Pinky and the Braid!"


    old "Play the Minus and Cortex game"
    new "Jouer le jeu de Minus et Cortex"


    old "You are the winner!"
    new "Vous avez gagné !"


    old "Finish First with Madison ?"
    new "Finir premier avec Madison ?"


    old "You deserve it!"
    new "Vous l'avez mérité !"


    old "Accept the reward"
    new "Accepter la récompense"


    old "You're not first meh!"
    new "Vous n'êtes pas premiers... pfff !"


    old "Accept the Special Reward"
    new "Accepter la récompense spéciale"



translate french strings:


    old "First !!!"
    new "Premier !!!"


    old "Finish the First Episode"
    new "Finir le Premier Episode"



translate french strings:


    old "Victory !!!"
    new "Victoire !!!"


    old "Win versus Grace"
    new "Gagner face à Grace"


    old "Cheater !!!"
    new "Tricheur !!!"


    old "Cheat versus Grace"
    new "Tricher contre Grace"


    old "Day of Defeat !!!"
    new "Day of Defeat !!!"


    old "You let Grace win... Right ?"
    new "Vous l'avez laissé gagner... Hein ?"


    old "Evolution !!!"
    new "Evolution !!!"


    old "From Squirtle to Squirter"
    new "Apprendre l'attaque Giclette !"



translate french strings:


    old "Her hero!!!"
    new "Son héros !!!"


    old "You're Ruby's Hero..."
    new "Vous êtes le héros de Ruby..."


    old "Hat Trick !!!"
    new "Hat Trick !!!"


    old "All for Madison !"
    new "Tout pour Madison !"


    old "Harem Vibes!!!"
    new "Harem Vibes !!!"


    old "Womens likes you..."
    new "Les femmes vous aiment..."



translate french strings:


    old "Women likes you..."
    new "Les femmes vous aiment..."



translate french strings:


    old "First Kiss!!!"
    new "Premier Baiser !!!"


    old "Grace for ever !"
    new "Grace pour la vie !"


    old "Of course!!!"
    new "Evidemment !!!"


    old "Madison..."
    new "Madison..."



translate french strings:


    old "Just the Beginning!"
    new "C'est juste le début !"


    old "Finish the Second Episode"
    new "Finir le deuxième épisode"



translate french strings:


    old "You tried..."
    new "Vous avez essayé..."


    old "Meh..."
    new "Mais..."


    old "You're a genius!!!"
    new "Vous êtes un génie!!!"


    old "But unknown..."
    new "Mais incompris..."


    old "Milfs are life!!!"
    new "Les Milfs c'est la vie !"


    old "Better with experience..."
    new "C'est mieux avec de l'expérience..."



translate french strings:


    old "Like a virgin!"
    new "Like a virgin!"


    old "Touch for the very first time..."
    new "Touch for the very first time..."


    old "You switched!"
    new "Echangées!"


    old "From Blue to Red..."
    new "Du Bleu au Rouge..."


    old "Road to Victory!"
    new "En route pour la Victoire!"


    old "Finish the Third Episode"
    new "Finir le troisième épisode"



translate french strings:


    old "Pet's Friend"
    new "30 millions d'ami"


    old "Mewww..."
    new "Miaouuuuuuu..."


    old "Opportunity Missed"
    new "Occasion manquée."


    old "You were on the right track..."
    new "Vous étiez sur le bon chemin..."


    old "You're the BEST!"
    new "Vous êtes le BEST!"


    old "A Star is born..."
    new "Une Star est née..."


    old "Madison is the BEST!"
    new "Madison est la BEST!"


    old "Ally or enemy???"
    new "Alliée ou ennemie???"



translate french strings:


    old "Man of the match!"
    new "Homme du match!"


    old "Play it like Beckham!"
    new "Joue-la comme Beckham!"



translate french strings:


    old "You finished Episode 4!"
    new "Vous avez fini l'épisode 4!"


    old "RUBYYYYYYYY!"
    new "RUBYYYYYYYY!"



translate french strings:


    old "Milfy City!"
    new "Milfy City!"


    old "You like it with experience"
    new "Vous les préférez avec de l'expérience!"


    old "You finished Episode 5!"
    new "Vous avez fini l'épisode5!"


    old "Elise?"
    new "Elise?"



translate french strings:


    old "Sacrifice!"
    new "Sacrifice!"


    old "She won't let you go..."
    new "Elle ne te laissera pas partir..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
