

translate french strings:


    old "%H:%M"
    new "%H:%M"


    old "%m/%d/%Y"
    new "%d/%m/%Y"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
