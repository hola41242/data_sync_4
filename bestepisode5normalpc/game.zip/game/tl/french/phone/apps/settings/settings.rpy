

translate french strings:


    old "Phone Theme"
    new "Theme:"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
