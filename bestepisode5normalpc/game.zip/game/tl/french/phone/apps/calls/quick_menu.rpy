

translate french strings:


    old "Settings"
    new "Paramètres"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
