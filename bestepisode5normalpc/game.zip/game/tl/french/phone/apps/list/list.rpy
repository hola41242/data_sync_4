

translate french strings:


    old "Contacts"
    new "Contacts"



translate french strings:


    old "Elizabeth"
    new "Elizabeth"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
