

translate french strings:


    old "A simple boy who just want to meet friends here :)"
    new "Un garçon simple qui veut juste rencontrer des amis ici :)"


    old "A simple girl who likes simple things"
    new "Une fille simple qui aime les choses basiques"


    old "Pretty girls out there!"
    new "Des jolies filles par ici !"


    old "Here to meet beautiful young girls 🤤!"
    new "Ici pour rencontrer de belles jeunes filles 🤤!"


    old "Just a flexible guy looking for fun!"
    new "Juste un gars flexible à la recherche d'amusement !"


    old "Feeling lonely, let's chat and share good vibes ❤️!"
    new "Je me sens seul, discutons et partageons de bonnes ondes ❤️!"


    old "Big dreams, small beginnings. Let's connect!"
    new "Grands rêves, petits débuts. Connectons-nous !"


    old "I bring the sass to OnlyStan 😎."
    new "Je mets du piquant sur OnlyStan 😎."


    old "Always here to support you 😉."
    new "Toujours là pour te soutenir 😉."


    old "Busy and bubbly, ready for fun! 💦"
    new "Occupée et pétillante, prête à m'amuser ! 💦"


    old "Just a guy with a big heart (and maybe more...) 😏."
    new "Juste un gars au grand cœur (et peut-être plus...) 😏."


    old "What can I say? I'm a cheeky kind of guy 😜!"
    new "Que dire ? Je suis un gars un peu coquin 😜!"


    old "Hello! My name is Fanny and I am new here. Tell me what you like in the comments ;)"
    new "Bonjour ! Je m'appelle Fanny et je suis nouvelle ici. Dites-moi ce que vous aimez dans les commentaires ;)"


    old "Hi everyone :)!"
    new "Salut tout le monde :)!"


    old "Beach dayy 🌴🏖️"
    new "Journée plage 🌴🏖️"


    old "Preparing for a party with my best friend 💕"
    new "Préparation pour une soirée avec ma meilleure amie 💕"


    old "Very beautiful! I'm very happy to meet you there 😊"
    new "Très belle ! Je suis ravi de te rencontrer ici 😊"


    old "Take me with you next time 😂! I love your outfit btw"
    new "Emmène-moi avec toi la prochaine fois 😂 ! J'adore ta tenue au fait"


    old "A party? Count me in! Just tell me where and when, I’ll bring the good vibes 🎉!"
    new "Une soirée ? Comptez sur moi ! Dites-moi juste où et quand, j'apporterai les bonnes vibes 🎉!"


    old "Pretty girl 🤤"
    new "Belle fille 🤤"


    old "Hey ! I love your body... Would you like to get to know each other 😉?"
    new "Hey ! J'adore ton corps... On pourrait apprendre à se connaître 😉?"


    old "My D is still so hard seeing you 🥵🥵"
    new "Tu me rends toujours aussi dur 🥵🥵"


    old "I am so honoured to breath the same air as you 🥵😍"
    new "Je suis tellement honoré de respirer le même air que toi 🥵😍"


    old "I'm bending over backwards just to comment here 😉"
    new "Je me plie en quatre juste pour commenter ici 😉"


    old "You look like someone who needs a hug 🥰"
    new "Tu as l'air de quelqu'un qui a besoin d'un câlin 🥰"


    old "Ben, you're always bending over for attention 🤦‍♀️"
    new "Ben, tu te plies toujours pour attirer l'attention 🤦‍♀️"


    old "Anita, don’t be so mean! Everyone deserves a little flexibility 😏"
    new "Anita, ne sois pas si méchante ! Tout le monde mérite un peu de flexibilité 😏"


    old "Wow, this is small talk at its finest 😏"
    new "Waouh, c'est de la conversation de haut vol 😏"


    old "This beach photo is making waves 🌊!"
    new "Cette photo de plage fait des vagues 🌊!"


    old "Hugh, you're just fishing for compliments again 🎣"
    new "Hugh, tu cherches encore des compliments 🎣"


    old "Seymour, let him enjoy the tide, it's not every day we get such views 😎"
    new "Seymour, laisse-le profiter de la marée, ce n'est pas tous les jours qu'on voit de tels paysages 😎"


    old "Party with friends? Save me a spot next time! 🎉"
    new "Soirée avec des amis ? Garde-moi une place la prochaine fois ! 🎉"


    old "Willie, you weren't invited last time for a reason... 😒"
    new "Willie, tu n'as pas été invité la dernière fois pour une raison... 😒"


    old "Ivana, don't be salty, we all know Willie likes to party hard 😉"
    new "Ivana, ne sois pas amère, on sait tous que Willie adore faire la fête 😉"


    old "Anita, you're the life of the party, admit it ❤️!"
    new "Anita, tu es l'âme de la fête, avoue-le ❤️!"


    old "Hard to resist such beauty 😏🔥"
    new "Difficile de résister à tant de beauté 😏🔥"


    old "Always here to have your back ❤️"
    new "Toujours là pour te soutenir ❤️"


    old "Cheeky post! Keep them coming 😜"
    new "Post coquin ! Continue comme ça 😜"


    old "This made me tinkle with laughter 💦"
    new "Ça m'a fait éclater de rire 💦"


    old "Welcome back, "
    new "Content de vous revoir, "


    old "See comments"
    new "Voir les commentaires"


    old "Comments"
    new "Commentaires"


    old "+ Add comment"
    new "+ Ajouter un commentaire"


    old "No posts"
    new "Aucune publication"


    old "Posts"
    new "Publications"



translate french strings:


    old "Welcome back, [onlystanProfiles[0].nickname!t]!"
    new "Content de vous revoir, [onlystanProfiles[0].nickname!t]!"



translate french strings:


    old "No comments"
    new "Pas de commentaires"



translate french strings:


    old "Beach day! 🌴🏖️"
    new "Jour de plage ! 🌴🏖️"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
