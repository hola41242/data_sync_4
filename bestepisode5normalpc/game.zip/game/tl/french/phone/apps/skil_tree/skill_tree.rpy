

translate french strings:


    old "Welcome to the B.E.S.T profile"
    new "Bienvenue dans le profil B.E.S.T"


    old "Once you reach 10 points in a stat, you can activate it"
    new "Une fois 10 points obtenus dans une statistique, vous pouvez l'activer"


    old "Your specialization will have effects during the B.E.S.T contest"
    new "Votre spécialisation aura des effets pendant la compétition"


    old "{i}Click to continue{/i}"
    new "{i}Cliquez pour continuer{/i}"


    old "You have unlocked the {color=#d90000}Buddy{/color} specialization! You can now enable it!"
    new "Vous avez débloqué la spécialisation {color=#d90000}Buddy{/color} ! Vous pouvez l'activer!"


    old "Click to continue"
    new "Cliquez pour continuer"


    old "You have unlocked the {color=#d90000}Temperament{/color} specialization! You can now enable it!"
    new "Vous avez débloqué la spécialisation {color=#d90000}Temperament{/color} ! Vous pouvez l'activer!"


    old "You have unlocked the {color=#d90000}Sport{/color} specialization! You can now enable it!"
    new "Vous avez débloqué la spécialisation {color=#d90000}Sport{/color} ! Vous pouvez l'activer!"


    old "You have unlocked the {color=#d90000}Education{/color} specialization! You can now enable it!"
    new "Vous avez débloqué la spécialisation {color=#d90000}Education{/color} ! Vous pouvez l'activer!"


    old "Buddy specialization enabled!"
    new "Spécialisation Buddy activée!"


    old "Temperament specialization enabled!"
    new "Spécialisation Tempérament activée!"


    old "Temp."
    new "Temp."


    old "Education specialization enabled!"
    new "Spécialisation Education activée!"


    old "Educ."
    new "Educ."


    old "Sport specialization enabled!"
    new "Spécialisation Sport activée!"


    old "Get at least {color=#d90000}10 points{/color} of a {color=#d90000}stat{/color} to unlock its {color=#d90000}specialization{/color}!"
    new "Obtenez au moins {color=#d90000}10 points{/color} dans une {color=#d90000}stat{/color} pour débloquer sa {color=#d90000}spécialisation{/color}  "
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
