

translate french strings:


    old "Replays"
    new "Replays"


    old "Extras"
    new "Extras"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
