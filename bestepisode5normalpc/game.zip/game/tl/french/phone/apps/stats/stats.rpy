

translate french strings:


    old "B.E.S.T RANK"
    new "Rang B.E.S.T"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
