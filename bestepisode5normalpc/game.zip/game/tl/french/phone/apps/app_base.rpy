

translate french strings:


    old "< Back"
    new "< Retour"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
