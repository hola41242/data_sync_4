

translate french strings:


    old "message"
    new "message"


    old "calendar"
    new "calendrier"


    old "call"
    new "appel"



translate french strings:


    old "Discussions"
    new "Discussions"


    old "Stats"
    new "Stats"


    old "Wallpaper"
    new "Wallpaper"



translate french strings:


    old "Bios"
    new "Bios"


    old "OnlyStan"
    new "OnlyStan"



translate french strings:


    old "Skills"
    new "Talents"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
