

translate french strings:


    old "Affair"
    new "Centre-ville"


    old "Bowling"
    new "Bowling"


    old "Dance"
    new "Salle de danse"


    old "Library"
    new "Bibliothèque"


    old "Auditorium"
    new "Amphithéatre"


    old "Museum"
    new "Musée"


    old "Port"
    new "Port"


    old "Gym"
    new "Salle de gym"


    old "Park"
    new "Parc"


    old "Minimap"
    new "Minimap"


    old "Hints"
    new "Indices"


    old "Mastermind"
    new "Mastermind"


    old "{b}Hint "
    new "{b}Indice "


    old "{/b}: "
    new "{/b}: "


    old "{s}{b}Hint "
    new "{s}{b}Indice "


    old "Found number: {b}"
    new "Chiffre trouvé: {b}"



translate french strings:


    old "A maze of glass and steel where dreams are priced and ambitions are signed."
    new "Un labyrinthe de verre et d'acier où les rêves ont un prix et les ambitions se signent."


    old "A place where every move strives to turn the unfinished into a spare."
    new "Un lieu où chaque geste tente de transformer l'inachevé en un spare."


    old "A space where every step composes a melody and every movement brings the rhythm to life."
    new "Un espace où chaque pas compose une mélodie et chaque mouvement donne vie au rythme."


    old "A sanctuary where words whisper secrets and pages keep time in memory."
    new "Un sanctuaire où les mots murmurent des secrets et les pages conservent le temps en mémoire."


    old "Tes connaissances s'accumulent ici"
    new "Tes connaissances s'accumulent ici."


    old "A vault where time stands still and every artifact whispers echoes of an immortal past."
    new "Un coffre où le temps s'arrête et chaque artefact murmure les échos d'un passé immortel."


    old "A theater where ropes sing in the wind and every departure promises an adventure to tell."
    new "Un théâtre où les cordes chantent au vent et chaque départ promet une aventure à raconter."


    old "A temple where every effort shapes determination and every drop of sweat writes perseverance."
    new "Un temple où chaque effort forge la détermination et chaque goutte de sueur écrit la persévérance."


    old "A haven where nature paints living pictures and the wind tells forgotten tales."
    new "Un havre où la nature peint des tableaux vivants et le vent raconte des récits oubliés."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
