

translate french strings:


    old "Monday"
    new "Lundi"


    old "Tuesday"
    new "Mardi"


    old "Wednesday"
    new "Mercredi"


    old "Thursday"
    new "Jeudi"


    old "Friday"
    new "Vendredi"


    old "Saturday"
    new "Samedi"


    old "Sunday"
    new "Dimanche"


    old "January"
    new "Janvier"


    old "February"
    new "Février"


    old "March"
    new "Mars"


    old "April"
    new "Avril"


    old "May"
    new "Mai"


    old "June"
    new "Juin"


    old "July"
    new "Juillet"


    old "August"
    new "Août"


    old "September"
    new "Septembre"


    old "October"
    new "Octobre"


    old "November"
    new "Novembre"


    old "December"
    new "Décembre"


    old "Calendar"
    new "Calendrier"


    old "[calendar.month_name]-[calendar.year]"
    new "[calendar.month_name]-[calendar.year]"


    old "Notes:"
    new "Notes:"


    old "No description provided."
    new "Pas de description"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
