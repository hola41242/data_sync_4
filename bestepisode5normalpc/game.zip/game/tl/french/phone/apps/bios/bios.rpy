

translate french strings:


    old "[name]:\n\nJust a regular guy trying to navigate through life and make sense of everything. Sometimes lucky, sometimes clumsy, but always trying to do the right thing... most of the time."
    new "[name]:\n\nJuste un gars simple essayant de s'en sortir dans la vie et dans ses études. Des fois chanceux, des fois maladroit, mais tentant de faire bien les choses... La plupart du temps."


    old "Ruby Suyin:\n\nPlayful and funny, Ruby charms everyone with her spontaneity and natural charisma. A bit scatterbrained but genuine, she lives in the moment and brightens the story with her joyful spirit."
    new "Ruby Suyin:\n\nDrôle et joueuse, Ruby charme tout le monde avec sa spontanéïté et son charisme naturel. Un peu cerveau de l'équipe, elle vit le moment présent et irradie les autres avec sa bonne humeur."


    old "Madison Forrester:\n\nHeiress of the powerful Forrester family, Madison juggles family duties, studies, and motherhood. Strong yet conflicted, she hides her doubts behind a polished facade."
    new "Madison Forrester:\n\nHéritière de la puissante famille Forrester, Madison jongle entre ses devoirs familiaux, ses études et son rôle de mère. Forte mais tiraillée, elle cache ses doutes derrière une façade impeccable."


    old "Grace Drew:\n\nGrace is kind and selfless, always striving to meet her mother’s high expectations. Her warmth hides the pressure she feels to balance duty and her own desires."
    new "Grace Drew:\n\nGentille et désintéressée, Grace s'efforce toujours de répondre aux attentes élevées de sa mère. Sa chaleur cache la pression qu'elle ressent pour équilibrer ses obligations et ses désirs personnels."


    old "Julia Carter:\n\nReserved and enigmatic, Julia carries a quiet strength that hints at untold stories. Her thoughtful gaze and calm demeanor conceal a world of emotions and secrets, making her both captivating and elusive."
    new "Julia Carter:\n\nRéservée et énigmatique, Julia porte une force tranquille qui laisse deviner des histoires non dites. Son regard réfléchi et son calme apparent dissimulent un monde d'émotions et de secrets, la rendant captivante et insaisissable."


    old "Elise Moreau:\n\nElise is the hero's steadfast friend, always ready with sharp wit and sound advice. Loyal and resourceful, she’s a reliable ally who values honesty and isn’t afraid to speak her mind."
    new "Elise Moreau:\n\nElise est l'amie fidèle du héros, toujours prête avec un esprit vif et des conseils avisés. Loyale et ingénieuse, elle est une alliée de confiance qui valorise l'honnêteté et n'a pas peur de dire ce qu'elle pense."


    old "Gabriella Fernandez:\n\nGabriella is a reserved and solitary professor, torn between her strict principles and her growing feelings for the protagonist. Her loneliness fuels her inner turmoil."
    new "Gabriella Fernandez:\n\nGabriella est une professeure réservée et solitaire, déchirée entre ses principes stricts et ses sentiments grandissants pour le protagoniste. Sa solitude alimente son trouble intérieur."


    old "Charlotte Sinclair:\n\nCharlotte is a free spirit with a rebellious streak, unafraid to challenge norms and live life on her own terms. Her boldness hides a deep desire for connection."
    new "Charlotte Sinclair:\n\nCharlotte est un esprit libre avec un côté rebelle, n'hésitant pas à défier les normes et à vivre selon ses propres termes. Son audace cache un profond désir de connexion."


    old "Elizabeth ‘Beth’ Da Fonseca:\n\nElisabeth, known as Red, is confident and assertive, always taking charge of any situation. Her dominant personality masks a softer side she rarely shows."
    new "Elizabeth ‘Beth’ Da Fonseca:\n\nElisabeth, surnommée Red, est confiante et affirmée, prenant toujours les choses en main. Sa personnalité dominante masque un côté plus doux qu'elle montre rarement."


    old "Sofia Da Fonseca:\n\nOutgoing and carefree, Sofia embraces life with a lighthearted charm. She’s known for her quick wit and an open mind, often breaking the tension with her humor and spontaneity."
    new "Sofia Da Fonseca:\n\nSociable et insouciante, Sofia aborde la vie avec un charme léger. Elle est connue pour son esprit vif et son ouverture d'esprit, souvent capable de détendre l'atmosphère avec son humour et sa spontanéité."


    old "Kira Orushi:\n\nAdventurous and headstrong, Kira thrives on independence and freedom. As an Orushi, she balances high expectations with her rebellious charm."
    new "Kira Orushi:\n\nAventureuse et déterminée, Kira s'épanouit dans l'indépendance et la liberté. En tant qu'Orushi, elle équilibre des attentes élevées avec son charme rebelle."


    old "Emerick Orushi:\n\nEmerick is cunning and arrogant, always scheming to maintain his status. As a member of the Orushi family, he wields influence but often underestimates those around him."
    new "Emerick Orushi:\n\nRusé et arrogant, Emerick élabore sans cesse des plans pour maintenir son statut. En tant que membre de la famille Orushi, il exerce une influence considérable, mais sous-estime souvent ceux qui l'entourent."


    old "Steven Johnson:\n\nThe captain of the men’s football team, Steven commands respect with his natural authority and calm demeanor. His leadership skills and steady presence make him a cornerstone for his team, both on and off the field."
    new "Steven Johnson:\n\nCapitaine de l'équipe masculine de football, Steven inspire le respect par son autorité naturelle et son calme. Ses compétences en leadership et sa présence constante font de lui un pilier pour son équipe, sur le terrain comme en dehors."


    old "Mac Harper:\n\nFriendly and easygoing, Mac is the type of guy who can get along with anyone. His laid-back attitude often hides his competitive spirit, which shines through when it comes to sports or a challenge he can’t resist."
    new "Mac Harper:\n\nAmical et décontracté, Mac est le genre de personne qui s'entend avec tout le monde. Son attitude détendue cache souvent un esprit compétitif, qui ressort dès qu'il s'agit de sport ou d'un défi qu'il ne peut pas refuser."


    old "Ben Carter:\n\nLoyal and hardworking, Ben is the kind of person who puts others before himself. Though he often downplays his own achievements, his determination and dedication make him a dependable friend and teammate."
    new "Ben Carter:\n\nLoyal et travailleur, Ben est le genre de personne qui privilégie les autres avant lui-même. Bien qu'il minimise souvent ses propres réussites, sa détermination et son dévouement font de lui un ami et coéquipier fiable."


    old "Hector Alvarez:\n\nRuthlessly ambitious, Hector is willing to do whatever it takes to get ahead. As Emerick’s loyal follower, he often finds himself executing questionable plans, putting his own morals aside to stay in his good graces."
    new "Hector Alvarez:\n\nD'une ambition implacable, Hector est prêt à tout pour avancer. En tant que fidèle d'Emerick, il se retrouve souvent à exécuter des plans douteux, mettant de côté ses propres principes pour rester dans ses bonnes grâces."


    old "Ted Forrester:\n\nTed is Madison's brother, loyal to the Forrester legacy but often clashing with her over family expectations. His sense of duty masks a more calculating side."
    new "Ted Forrester:\n\nTed est le frère de Madison, loyal à l'héritage des Forrester mais souvent en conflit avec elle sur les attentes familiales. Son sens du devoir cache un côté plus calculateur."


    old "Cassie Forrester:\n\nCassie is Madison’s young daughter, full of energy and curiosity. Her cheerful spirit brings light to Madison’s demanding life, even as she navigates the complexities of her family."
    new "Cassie Forrester:\n\nCassie est la jeune fille de Madison, pleine d'énergie et de curiosité. Son esprit joyeux illumine la vie exigeante de Madison, même au milieu des complexités familiales."


    old "Mrs. Drew:\n\nMrs. Drew is Grace’s demanding mother, holding her daughter to the highest standards. Behind her strictness lies a deep desire to see Grace succeed, even at the cost of personal warmth."
    new "Mrs. Drew:\n\nMme Drew est la mère exigeante de Grace, imposant à sa fille des normes très élevées. Derrière sa sévérité se cache un profond désir de voir Grace réussir, même au prix de la chaleur humaine."


    old "Mr. Orushi:\n\nMr. Orushi is the patriarch of the Orushi family, a calculating and authoritative figure who demands loyalty and excellence from everyone around him. His ambition and influence shape both his family and the city."
    new "Mr. Orushi:\n\nM. Orushi est le patriarche de la famille Orushi, une figure calculatrice et autoritaire qui exige loyauté et excellence de tous ceux qui l'entourent. Son ambition et son influence façonnent à la fois sa famille et la ville."


    old "Charles Forrester:\n\nCharles Forrester is the proud patriarch of the Forrester family. Ambitious and commanding, he strives to maintain his family’s dominance in the city, often at the expense of personal relationships"
    new "Charles Forrester:\n\nCharles Forrester est le fier patriarche de la famille Forrester. Ambitieux et autoritaire, il s'efforce de maintenir la domination de sa famille sur la ville, souvent au détriment des relations personnelles."


    old "Carmen Forrester:\n\nCarmen Forrester is the graceful matriarch of the Forrester family. Often acting as a peacemaker, she balances her loyalty to her husband with her compassion for her children."
    new "Carmen Forrester:\n\nCarmen Forrester est la matriarche gracieuse de la famille Forrester. Jouant souvent le rôle de médiatrice, elle équilibre sa loyauté envers son mari avec sa compassion pour ses enfants."


    old "She barely knows you..."
    new "Elle vous connaît à peine..."


    old "You're becoming friends."
    new "Vous devenez amis."


    old "You're starting to mean something to her."
    new "Vous commencez à compter pour elle."


    old "You shared a kiss."
    new "Vous avez échangé un baiser."


    old "A deep bond is forming between you."
    new "Un lien profond se forme entre vous."


    old "Madly in love."
    new "Fou amoureux."




translate french strings:


    old "Ben Baker:\n\nLoyal and hardworking, Ben is the kind of person who puts others before himself. Though he often downplays his own achievements, his determination and dedication make him a dependable friend and teammate."
    new "Ben Baker:\n\nLoyal et travailleur, Ben est le genre de personne qui privilégie les autres avant lui-même. Bien qu'il minimise souvent ses propres réussites, sa détermination et son dévouement font de lui un ami et coéquipier fiable."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
