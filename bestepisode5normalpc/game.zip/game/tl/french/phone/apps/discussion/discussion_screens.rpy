

translate french strings:


    old "Type a message."
    new "Ecrire un message"


    old "Send"
    new "Envoyer"


    old "Load More"
    new "Charger plus..."


    old "{u}{i}Loading Image...{i}{/u}"
    new "Chargement image..."


    old "{u}{i}Loading Audio...{i}{/u}"
    new "Chargement audio..."


    old "{u}{i}Loading Video...{i}{/u}"
    new "Chargement vidéo..."


    old "Go Back"
    new "Retour"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
