

translate french strings:


    old "[sender.short_name!t] is typing..."
    new "[sender.short_name!t] est en train d'écrire..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
