

translate french strings:


    old "Empty group chat"
    new "Groupe vide"


    old "Image sent"
    new "Image envoyée"


    old "Audio sent"
    new "Audio envoyé"


    old "Video sent"
    new "Vidéo envoyé"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
