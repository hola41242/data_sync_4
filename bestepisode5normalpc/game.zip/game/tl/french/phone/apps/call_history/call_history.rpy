

translate french strings:


    old "Calls"
    new "Appels"


    old "No recent calls"
    new "Pas d'appels récents"


    old "The {date} at {time}"
    new "Le {date} à {time}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
