

translate french strings:


    old "Messages"
    new "Messages"


    old "No group chats"
    new "Pas de groupes"


    old "The [group_chat._date_text] at [group_chat._hour_text]"
    new "Le [group_chat._date_text] à [group_chat._hour_text]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
