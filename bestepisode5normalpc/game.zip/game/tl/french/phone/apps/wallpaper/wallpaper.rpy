

translate french strings:


    old "Your wallpaper was changed!"
    new "Vous avez changé votre wallpaper!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
