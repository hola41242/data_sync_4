


translate french phone_call_test_f8ac15c7:


    phone_ruby ""


translate french phone_call_test_8a706c1c:


    phone_d ""


translate french phone_call_test_3c118f0d:


    ""


translate french phone_call_test_a20cefa7:


    "..."

translate french strings:


    old "Sofia"
    new "Sofia"


    old "Does it work ?"
    new "Ca marche ?"


    old "Yes !"
    new "Ouais !"


    old "Awesome !"
    new "Ah génial !"


    old "Are you ready for tomorrow ?"
    new "T'es prêt pour demain ?"


    old "For what ?"
    new "Prêt pour ?"


    old "Economics class !"
    new "Le cours d'éco !"


    old "Oh ! Yeah ! Sure..."
    new "Ah ! Ouais... "


    old "Don't worry... Gabriella is an angel..."
    new "T'inquiètes pas... Gabriella est un ange..."


    old "Gabriella... The Milf ?"
    new "Gabriella... La Milf ?"


    old "Ahah ! Yeah... But don't tell her that please..."
    new "Ahah ! Ouais... Mais ne lui dis surtout pas ça s'il te plaît..."


    old "I'm not sure she would be pleased by this..."
    new "Je ne suis pas sûre qu'elle apprécierait..."


    old "No I won't ! I'm not stupid !"
    new "Non t'inquiète ! Je suis pas con non plus..."


    old "And with Julia ???"
    new "Et avec Julia ???"


    old "What's about Julia ?"
    new "De quoi Julia ?"


    old "Come on !!! You two were all around the campus together this afternoon !"
    new "Allez !!! On vous a vus ensemble toute l'après midi à faire le tour du campus !"


    old "How do you know that ?"
    new "Comment tu sais ça ?"


    old "I've got my eyes everywhere"
    new "J'ai des yeux partout..."


    old "You are crazy !"
    new "T'es folle !"


    old "I know !"
    new "Je sais !"


    old "So ???"
    new "Alors ???"


    old "So... what ?"
    new "Alors... Quoi ?"


    old "Julia !!!"
    new "Julia !!!"


    old "I'm not interested by her..."
    new "Elle ne m'intéresse pas..."


    old "Oh..."
    new "Oh..."


    old "She's cute..."
    new "Elle est mignonne..."


    old "Great ! I think she likes you too !"
    new "Cool ! Je crois qu'elle t'aime bien aussi !"


    old "Told you... I'm everywhere !"
    new "Je te l'ai dit... Je suis partout !"


    old "Okay... time to sleep !"
    new "Okay... C'est l'heure de dormir ! "


    old "See ya Cortex !"
    new "A plus tard Cortex !"


    old "See you... Minus..."
    new "A plus tard... Minus..."


    old "Hey !"
    new "Hey !"


    old "Hey... ! "
    new "Hey... !"


    old "Sorry for my mom..."
    new "Désolée pour ma mère tout à l'heure..."


    old "Don't worry ! there's really no problem..."
    new "T'inquiète pas ! Y'a pas de problème..."


    old "May I ask you a question ?"
    new "Est ce que je peux te poser une question ?"


    old "Sure you can !"
    new "Bien sûr !"


    old "Okay..."
    new "Okay..."


    old "Were you trying to kissing me ?"
    new "Est ce que tu voulais m'embrasser ?"


    old "Yes..."
    new "Oui..."


    old "I couldn't resist..."
    new "Je n'ai pas pu résister..."


    old "Even if you just had your time with Blue ?"
    new "Alors même que tu as passé du bon temps avec Blue ?"


    old "Oh you heard that ?"
    new "Oh tu as entendu ?"


    old "How i could miss it... sound was all around the pool !"
    new "Comment râter ça... Y'avait le son en Dolby Surround dans la piscine !"


    old "Sorry if it was too pushy..."
    new "Désolé si ça fait un peu dragueur..."


    old "NO ! I mean..."
    new "NON ! Enfin je veux dire..."


    old "No..."
    new "Non..."


    old "Oh ?"
    new "Oh ?"


    old "I should sleep... It's late..."
    new "Je devrais aller dormir... Il se fait tard..."


    old "Yeah me too..."
    new "Ouais moi aussi..."


    old "See you tomorrow !"
    new "On se voit demain !"


    old "Sure ! See you tomorrow !"
    new "Oui ! A demain !"


    old "Good night Grace..."
    new "Bonne nuit Grace..."


    old "Good night [name]"
    new "Bonne nuit [name]"


    old "Hey my lord !"
    new "Hey mon dresseur !"


    old "I didn't think you would text me tonight ! "
    new "Je ne pensais pas avoir de tes news dès ce soir !"


    old "Yeah I know..."
    new "Ouais je sais..."


    old "I can't forget what you did to me later..."
    new "J'arrive pas à oublier ce que tu m'as fait tout à l'heure..."


    old "My pussy is so sore..."
    new "Ma chatte est toute gonflée..."


    old "I told you ! "
    new "Je te l'avais dit !"


    old "I know... I know..."
    new "Je sais... Je sais..."


    old "But I need more..."
    new "Mais j'en veux plus..."


    old "Well I think I must rest..."
    new "Bon je crois qu'il faut que j'aille me coucher..."


    old "Will you come to the party Friday ?"
    new "Tu viens à la soirée Vendredi ?"


    old "Of course ! You ?"
    new "Evidemment ! Et toi ?"


    old "Sure !"
    new "Pareil !"


    old "Seems we might spend some time together..."
    new "On dirait qu'on va pouvoir passer un peu de temps ensemble..."


    old "Can't wait..."
    new "J'ai déjà hâte..."


    old "Can't wait !"
    new "J'ai déjà hâte !"


    old "Me neither..."
    new "Moi aussi..."


    old "Take this for your waiting time !"
    new "Tiens, prends ça en attendant..."


    old "I don't care..."
    new "Bof, je m'en fous..."


    old "I don't care... "
    new "Bof, je m'en fous..."


    old "Oh ? Okay..."
    new "Ah ? D'accord..."


    old "..."
    new "..."


    old "See you ! Handsome..."
    new "A plus tard ! Mignon..."


    old "See you, my slutty one..."
    new "A plus tard ma petite cochonne..."



translate french strings:


    old "Were you trying to kiss me ?"
    new "Est ce que tu voulais m'embrasser ?"


    old "How could I miss it... I could hear her moans all around the pool !"
    new "Comment j'aurais pu le rater ? Je pouvais entendre ses gémissements à 10 kilomètres à la ronde !"


    old "Sorry..."
    new "Désolé..."



translate french strings:


    old "Elise"
    new "Elise"


    old "Hey the american ! Tell me when you're here !"
    new "Hey l'américain ! Dis-moi quand t'es par là !"


    old "Yes ? Leonardo speaking ?"
    new "Oui ? Leonardo speaking ?"



translate french strings:


    old "Can you hear me, now ?"
    new "Ca fonctionne ?"


    old "Yes ! You know this is only text, right ?"
    new "Ouais !"


    old "Good ! Of course , mister serious, haha !"
    new "Cool !!!"


    old "I'm not sure she would be pleased by that..."
    new "Je suis pas sûre qu'elle aimerait ça..."


    old "I'm not interested in her..."
    new "Elle ne m'intéresse pas..."


    old "Even if you just spent time with Blue ?"
    new "Même si t'as passé du bon temps avec Blue ?"


    old "I can't forget what you did to me earlier..."
    new "J'arrive pas à zapper ce que tu m'as fait tout à l'heure..."


    old "Well, I think I need rest..."
    new "Bon, je pense qu'il faut que je me repose..."



translate french strings:


    old "Minus"
    new "Minus"


    old "Hey! Are you asleep?"
    new "Hey ! Tu dors ?"


    old "Nah, I was about to go do a little training at the stadium."
    new "Nan, j'allais partir m'entraîner au stade."


    old "Oh...."
    new "Oh..."


    old "Why? What's up?"
    new "Pourquoi? Qu'est ce qui se passe?"


    old "Well, I don't have anything to wear to the party."
    new "Ben... J'ai rien à me mettre pour la soirée."


    old "I was thinking of going to Red's Store to try on some nice dresses."
    new "Je pensais aller au magasin de Rouge essayer de jolies robes."


    old "Uh, yeah... and?"
    new "Ah, ouais... et?"


    old "Well, I wanted your opinion on what you think looks good on me!"
    new "Ben, je voulais ton opinion, savoir comment tu me trouvais avec ces robes..."


    old "Oh, okay. Well..."
    new "Oh, okay... Euh..."


    old "Sure. I'll come with."
    new "T'inquiètes. Je vais venir avec toi."


    old "I would happy to help"
    new "Ce serait avec plaisir."


    old "Really? You're coming for real?"
    new "Sérieux? Tu vas vraiment venir?"


    old "Yeah. I said I was. I'll be there."
    new "Ben oui. Si je te le dis."


    old "Ohhh, that's awesome!!!"
    new "Ohhh! Trop génial!!!"


    old "Give me ten minutes and I'll meet you in front of the store?"
    new "Donne-moi 10 minutes et on se rejoint devant le magasin?"


    old "Sounds good, see you in a bit."
    new "Ca me va, à tout de suite."


    old "I have to workout first."
    new "Il faut que j'aille m'entraîner d'abord."


    old "I'm sorry, I really need to focus on my training. Maybe next time?"
    new "Je suis désolé... Je dois vraiment me focaliser sur l'entraînement. Une prochaine fois?"


    old "No? Pretty please with a cherry on top? "
    new "S'il te plaîiiiiiiiiiiiit!"


    old "Okay, okay. You win. We can go when I am done training."
    new "Bon, okay. T'as gagné. Je viendrai après m'être entraîné."


    old "Ohhh, that's awesome! Thank you!"
    new "Ohhh! Trop génial!!! Merci!"


    old "We'll meet in front of the store, okay?"
    new "On se rejoint devant le magasin, d'accord?"


    old "Okay, see ya!"
    new "Okay, à toute!"


    old "I'll be waiting!"
    new "Je t'attendrai!"



translate french strings:


    old "???"
    new "???"


    old "Continue like that [name], you're doing great."
    new "Continue comme ça [name], tu t'en sors bien."


    old "Who are you?"
    new "Qui êtes-vous?"


    old "Someone that can help you... or not..."
    new "Quelqu'un qui peut t'aider... ou pas..."


    old "All will depend on you."
    new "Tout dépendra de toi."


    old "where did you get my phone number?"
    new "Où avez-vous eu mon numéro?"


    old "This question isn't relevant..."
    new "Cette question est inutile..."


    old "Do as I say and you will win this contest."
    new "Fais ce que je te dis et tu pourras gagner cette compétition."


    old "Don't and..."
    new "Ne le fais pas et..."


    old "You won't... And your girls neither"
    new "Tu échoueras... Et tes filles aussi."


    old "What? My girls?"
    new "Comment ça mes filles?"


    old "You will have some fresh news soon."
    new "Tu auras bientôt de mes nouvelles."


    old "Keep the good work [name]"
    new "Continue comme ça [name]"


    old "But what's your name?"
    new "C'est quoi votre nom?"



translate french strings:


    old "Sure. I'll come with.[TEMP1!t]"
    new "Bien sûr! Je vais venir.[TEMP1!t]"


    old "I have to workout first.[TEMP2!t]"
    new "Je dois aller m'entraîner d'abord.[TEMP2!t]"



translate french strings:


    old "Gabriella"
    new "Gabriella"


    old "Hey! How's it going?"
    new "Hey ! Comment ça va?"


    old "Hi! My back's still a bit sore..."
    new "Salut! Mon dos me fait toujours mal..."


    old "Oh... Hope you're up for the next game!"
    new "Oh... J'espère que tu seras remise pour le prochain match!"


    old "Yeah... I'm gonna stay in today."
    new "Ouais... Je vais rester tranquille aujourd'hui."


    old "I already called the academy to let them know I got hurt yesterday."
    new "J'ai déjà appelé l'académie pour leur faire savoir que j'ai été blessée hier."


    old "Oh... okay."
    new "Oh... Okay."


    old "What about Grace's party?"
    new "Et à propos de la soirée chez Grace?"


    old "I'll be there, but I won't stay late."
    new "Je serais là, mais je ne resterais pas tard."


    old "Ah..."
    new "Ah..."


    old "So... see you there?"
    new "Bon ben... On se voit là bas?"


    old "Definitely! See ya!"
    new "Absolument! A plus tard!"


    old "Hi Madison, it's [name]!"
    new "Salut Madison, c'est [name]!"


    old "Just a quick message to check if this is the right number..."
    new "Juste un petit message pour voir si j'ai bien le bon numéro..."


    old "It is."
    new "C'est le bon."


    old "How was your afternoon?"
    new "Ca a été ton après-midi?"


    old "Apart from the kilo of modeling clay on my fingers..."
    new "Vu le kilo de pâte à modeler que j'ai sur les doigts..."


    old "It's fine!"
    new "Ca va."


    old "I'm running late though..."
    new "Je suis à la bourre du coup..."


    old "Okay, I won't bother you any longer! See you later!"
    new "Okay, je t'embête pas plus! A ce soir!"


    old "++"
    new "++"


    old "Hi Gabriella, it's [name]!"
    new "Salut Gabriella, c'est [name]!"


    old "I told you only in case of emergency!"
    new "J'avais dit UNIQUEMENT en cas d'urgence!"


    old "Uh... Yes, but how do I know if it's the right number?"
    new "Heu... oui. Mais comment je sais que j'ai le bon numéro?"


    old "In an emergency, I might not have time to check!"
    new "SI y'à urgence, j'aurais pas le temps de vérifier le numéro!"


    old "Fair point..."
    new "C'est pas faux..."


    old "Enjoy your evening!"
    new "Profites de ta soirée!"


    old "And be on time tomorrow!"
    new "Et sois à l'heure demain!"


    old "No worries!"
    new "Pas de problèmes!"



translate french strings:


    old "Kira"
    new "Kira"


    old "Hey! Just got your contact info from OS!"
    new "Hey! J'ai récup tes infos sur OS!"


    old "Oh okay!"
    new "Oh okay!"


    old "We're heading to Palazio tomorrow night."
    new "On va au Palazio demain soir."


    old "Wanna come with us?"
    new "Tu veux venir avec nous?"


    old "Sure. I'll come along!"
    new "Carrément! Je vous suis!"


    old "That'd be awesome, yeah!"
    new "Ca serait génial, ouais!"


    old "I'll send you the address if you want."
    new "Je t'enverrais l'adresse si tu veux."


    old "Great!"
    new "Parfait!"


    old "No, thank you!"
    new "Non, merci!"


    old "Oh? Alright."
    new "Oh? D'accord."


    old "I'd rather rest up for the competition."
    new "Je préfère me reposer pour la compétition."


    old "No worries. I get it!"
    new "Pas de souci. Je comprends!"


    old "Hummm... Totally out of place but..."
    new "Hummm... Complètement hors de propos mais..."


    old "Do you have had an affair with Red at the party? "
    new "Il s'est passé un truc avec Red pendant la soirée chez Grace?"


    old "Yeah. Why?"
    new "Oui. Pourquoi?"


    old "Oh, just to know. I was curious if it was true!"
    new "Non, non rien rien! C'était juste pour savoir si ce qu'on dit était vrai."


    old "No. Why?"
    new "Non. Pourquoi?"


    old "Oh, just to know. I was just curious!"
    new "Juste pour savoir. Je suis curieuse!"


    old "Well, see you!"
    new "Allez, à plus tard!"


    old "See you!"
    new "A plus!"



translate french strings:


    old "Red"
    new "Rouge"


    old "We're heading to Palazio later in the week."
    new "On va au Palazio dans la semaine."


    old "Here’s the message you asked for!"
    new "Voilà le message que tu m'as demandé!"


    old "Perfect."
    new "Parfait."


    old "That’s it?"
    new "C'est tout?"


    old "What were you expecting?"
    new "Tu t'attendais à quoi ?"


    old "This way I don’t have to enter your info manually. It does everything by itself."
    new "Comme ça j'ai pas besoin d'entrer tes infos, ça fait tout seul."


    old "I mean, we could have used this as an excuse to talk... get to know each other..."
    new "Nan mais on aurait pu en profiter pour parler... apprendre à se connaître..."


    old "Right?"
    new "Nan?"


    old "No."
    new "Non."


    old "Well, I guess tonight’s not the night I’ll get a photo of you then?"
    new "Bon ben je suppose que c'est pas ce soir que j'aurais une photo de toi alors?"


    old "A photo? Why would I send you a photo?"
    new "Une photo? Pourquoi je t'enverrais une photo?"


    old "I don’t know. So I can have something of yours."
    new "Je sais pas. Que j'ai quelque chose de toi."


    old "Something of mine."
    new "QUelque chose de moi."


    old "Let me think about it."
    new "Laisse-moi réfléchir..."


    old "Take your time, I’m patient."
    new "Prend ton temps, je suis patient."


    old "Yeah, sure. Keep dreaming..."
    new "Ouais bien sûr... Rêve."


    old "This is all you will have from me."
    new "C'est tout ce que tu auras de moi."


    old "Wait, seriously? A cleavage shot... and a toilet in the background?"
    new "Attends, sérieux? Un décolleté avec les toilettes en fond?"


    old "You’re truly one of a kind, Beth."
    new "T'es vraiment..."


    old "Take it or leave it."
    new "Bah c'est déjà ça."


    old "Oh, I’m keeping it. It’ll be the highlight of my collection."
    new "Oh, mais je vais la garder. Ce sera un trophée de ma collection."


    old "Good night, [name]. Enjoy staring at your phone."
    new "Bonne nuit, [name]. Reste bien scotché sur ton tel."


    old "Good night, Beth."
    new "Bonne nuit, Beth."



translate french strings:


    old "We're heading to Palazio tomorrow."
    new "On va au Palazio demain."



translate french strings:


    old "Charlotte"
    new "Charlotte"


    old "Hey, you!"
    new "Hey, toi!"


    old "Yeah?"
    new "Oui?"


    old "You think I didn't see you spying on us at the Palazio earlier?"
    new "Tu crois que je t'ai pas vu nous écouter au Palazio tout à l'heure?"


    old "That's nonsense!"
    new "N'importe quoi!"


    old "Yeah, yeah..."
    new "Ouais, ouais..."


    old "I totally figured out that Gabriella was talking about you, you know!"
    new "J'ai bien compris que c'était de toi que Gabriella parlait hein!"


    old "I have no idea what you're talking about."
    new "J'ai aucune idée de quoi tu parles."


    old "Of course you don’t."
    new "Bien sûr..."


    old "I'm gonna set something up. You'll thank me later!"
    new "Je vais organiser quelque chose. Tu me remercieras plus tard!"


    old "What are you gonna do?"
    new "Qu'est ce que tu vas faire?"


    old "I have my little idea. Anyway, good night!"
    new "J'ai ma petite idée. Allez, Bonne nuit!"


    old "Good night!"
    new "Bonne nuit!"



translate french strings:


    old "Evelyn"
    new "Evelyn"


    old "Hi Evelyn, it's me from the Palazio. I just wanted to say you really caught my attention last night."
    new "Salut Evelyn, c’est moi, celui du Palazio. Je voulais juste te dire que tu as vraiment attiré mon attention hier soir."


    old "Well, well. I wasn’t sure if you’d actually message me."
    new "Eh bien, je n’étais pas certaine que tu m’enverrais vraiment un message."


    old "I almost didn’t, but then I thought, what’s life without a little risk?"
    new "J’ai failli ne pas le faire, mais je me suis dit : à quoi bon la vie sans un peu de risque ?"


    old "A bold move. I like that."
    new "Un geste audacieux. J’aime ça."


    old "And here I thought you might enjoy a little intrigue in your day."
    new "Et moi qui pensais que tu apprécierais un peu de mystère dans ta journée."


    old "Intrigue… and confidence. You might be onto something."
    new "Du mystère… et de l’assurance. Tu tiens peut-être quelque chose."


    old "Why don’t we see if you’re as bold in person as you are over text?"
    new "Et si on voyait si tu es aussi audacieux en vrai que par message ?"


    old "Sounds like a challenge. What do you have in mind?"
    new "Ça ressemble à un défi. Qu’est-ce que tu proposes ?"


    old "There’s a cozy café on River Street. Meet me there tomorrow night. 7 PM."
    new "Il y a un café sympa sur River Street. Retrouve-moi là-bas demain soir. 19h."


    old "I’ll be there."
    new "J’y serai."


    old "Good. I’ll see you then."
    new "Parfait. À demain alors."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
