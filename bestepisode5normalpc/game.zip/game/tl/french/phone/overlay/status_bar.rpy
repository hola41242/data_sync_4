

translate french strings:


    old "LTE"
    new "LTE"


    old "Screen\nMirroring"
    new "Miroir"


    old "Music"
    new "Musique"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
