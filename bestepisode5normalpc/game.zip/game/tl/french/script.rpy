


translate french before_main_menu_3478fbcf:


    ji "Hey beau gosse... Tu t'es perdu ???"


translate french before_main_menu_af960e99:


    ji "Dans les yeux mon gars !!!"


translate french before_main_menu_b046534a:


    ji "Hmmmmm..."


translate french before_main_menu_625c6cf0:


    ji "Premièrement as-tu plus de 18 ans ?"


translate french suitepres_b946024c:


    ji "Okay c'est parfait !"


translate french suitepres_6b16c31a:


    ji "Laisse moi t'expliquer"


translate french suitepres_37c8299f:


    ji "Tu vas jouer à un jeu qui parle de filles, de sports, de la vie et tout un tas de lignes de textes chiantes à mourir..."


translate french suitepres_9afb9d81:


    ji "Alors... es-tu prêt à faire face à des sujets sensibles comme les drogues.... l'alcool..."


translate french suitepres_89b4736c:


    ji "Peut être même... Le sexe ?"


translate french suitepres2_6176ecf8:


    ji "Si tu es toujours là, je vais essayer de ne pas te faire perdre ton temps..."


translate french suitepres2_7679271c:


    cr "Tu lui as déjà montré ton corps... et regarde tes vêtements !!!!! C'est normal de dire Bonjour de cette façon ?"


translate french suitepres2_1de0c188:


    ji "Dans ce genre de jeu... oui !!! Vous m'avez demandé de présenter le jeu.... alors laissez moi faire !"


translate french suitepres2_20286056:


    cr "Okay Okay... Mais s'il te saute dessus je ne bougerais pas le petit doigt pour toi !!!"


translate french suitepres2_3a92413c:


    ji "Il semble si timide... Je l'aime déjà beaucoup :)"


translate french suitepres2_f3fce131:


    ji "Tu as perdu ta langue ?"


translate french suitepres2_d9a6eda7:


    ji "J'espère vraiment que tu vas aimer ce jeu parce qu'il a été fait par un couple de français qui adorent jouer aux visual novels..."


translate french suitepres2_a2df8905:


    ji "Ce jeu est leur premier alors ... ça sera loin d'être parfait, peut être des erreurs de grammaire ou des rendus qui ne seront pas aussi beaux que dans d'autres jeux..."


translate french suitepres2_42c2eea9:


    ji "Je te demande juste d'être tolérant et de ne pas hésiter à donner des conseils ou/et indiquer les améliorations qui pourraient être apportées pour rendre ce jeu meilleur !"


translate french suitepres2_efe1f8f4:


    cr "T'es trop mignonne... Bon allez il attend pour le jeu là ! Tu parles trop !!!"


translate french suitepres2_eafcc31f:


    ji "D'accord... Bon si tu aimes le jeu, les filles, voir même les Créateurs, s'il te plaît, envisage de supporter le jeu !"


translate french suitepres2_74ce2bd0:


    ji "Pour ce faire dis moi ce que tu aimes, ce que tu aimerais voir dans le jeu, quel personnage est ton ou ta favori(te)..."


translate french suitepres2_191359f0:


    ji "Quand on lancera le jeu, on ouvrira un Patreon..."


translate french suitepres2_1d0cb18d:


    cr "Ouais je le ferais quand j'aurais compris comment ça fonctionne surtout ...."


translate french suitepres2_482cf9d7:


    ji "En donnant de l'argent via Patreon pour montrer ton soutien, les Créateurs peuvent m'acheter des vêtements et j'ADORE les vêtements !!!"


translate french suitepres2_2ed231f9:


    cr "Tu veux pas 100 balles et un mars aussi ???"


translate french suitepres2_0722afa7:


    ji "Bon... Ils pourront surtout acheter du nouveau matériel pour améliorer le processus de création et le rendre plus rapide.... plus d'argent c'est plus de contenus..."


translate french suitepres2_548c6fcc:


    cr "Sur ça tu as raison ! Un rendu ou une animation prend du temps, et on a pas un ordi de la NASA ^^"


translate french suitepres2_e878c34f:


    ji "Je te demande juste d'y penser..."


translate french suitepres2_ccc1565e:


    ji "Bon je vais pas te garder plus longtemps..."


translate french suitepres2_a4d5af8b:


    ji "J'espère vraiment que tu vas apprécier ce jeu"


translate french suitepres2_290da400:


    cr "Tu lui as dit qu'il verra tes seins plus tard ?"


translate french suitepres2_62afa6d2:


    ji "Peut être .... s'il fait les bons choix ..."


translate french suitepres2_3ae97e02:


    ji "Bon allez amuses toi bien ! Peut être qu'on se reverra bientôt Monsieur qui ne parle pas !"


translate french start_ffec1057:


    "Le Football..."


translate french start_d3b72452:


    "C'était pas ma priorité jusqu'à maintenant..."


translate french start_1e3a25e7:


    "Gagner le tournoi..."


translate french start_01972814:


    "Je ne peux pas rater..."


translate french start_23390470:


    "Je ne peux pas..."


translate french start_157ed9b5:


    dpense "Je m'appelle [name]"


translate french start_36375845:


    dpense "Je viens de France, arrivé récemment à l'Academy en Septembre..."


translate french start_d989ba8a:


    dpense "Je suis pas trop mauvais en Anglais mais je suis loin d'être parfait... Je fais des erreurs et les autres ne se gênent pas pour me le rappeler !"


translate french start_a9cd7e81:


    dpense "Mais quand je suis sur le terrain je donne tout !"


translate french start_32162281:


    dpense "C'est le foot qui m'a fait rester ici..."


translate french start_927f5551:


    dpense "Au début c'était juste pour six mois pour un échange linguistique entre la France et les USA"


translate french start_f9248499:


    dpense "J'étudie le Marketing et l'Economie"


translate french start_639f1fbf:


    dpense "Et pour améliorer mon anglais j'ai postulé à cet échange..."


translate french start_8f74f52e:


    dpense "Le programme était : Va aux USA pendant 6 mois, vis ta vie d'américain à l'Academy et reviens avec un diplôme... Rien de fou quoi..."


translate french start_f485be11:


    dpense "Mais tout ça a changé rapidement après avoir atterri dans ce nouveau pays "


translate french start_e7289712:


    dpense "Ca a commencé comme ça...."


translate french start_c7ef1af4:


    dpense "Un jour j'étais en France avec mes amis et ma famille..."


translate french start_eafe64f5:


    dpense "Et le jour d'après..."


translate french start_bff3b2ce:


    dpense "J'étais dans un avion pour faire le voyage de France..."


translate french start_f9f78803:


    dpense "vers l'Amérique !!!!"

translate french strings:


    old "Yes"
    new "Oui"


    old "No"
    new "Non"


    old "Yes, of course i'm in !!!"
    new "Oui, évidemment !!!"


    old "I have some problems in my life, i prefer go fap on other games less boring.... ciao !"
    new "Trop chiant... ciao !"




translate french before_main_menu_bcb0d6ab:


    ji "Hmmmm..."


translate french suitepres2_9584368a:


    cr "Excuse moi, je suis le développeur de ce jeu ... le big boss quoi !"


translate french suitepres2_d8c00c28:


    cr "Je vois que tu as rencontré une de mes filles. Laisse moi juste une minute avec elle s'il te plaît..."


translate french suitepres2_91b904b0:


    cr "TOI ! Tu lui as déjà montré ton corps... et regarde ces vêtemnts ! C'est normal de se présenter comme ça ?"




translate french suitepres_bcaea798:


    ji "Laisse moi t'expliquer..."


translate french suitepres_fc2a9ca4:


    ji "Tu vas jouer à un jeu qui parle de filles, de sport, de la vie et de tout un tas de lignes de textes ennuyantes..."


translate french suitepres2_1fd3304e:


    ji "Si tu es toujours là je vais faire en sorte que ton temps soit bien utilisé..."


translate french suitepres2_7ba08f3b:


    cr "Je vois que vous avez rencontré une de mes filles. Laissez moi lui parler une minute s'il vous plaît..."


translate french suitepres2_8fecf4f1:


    cr "Toi ! T'es déjà en train de montrer ton corps .... et regarde ces vêtements ! C'est normal de se présenter de cette façon ?"


translate french suitepres2_f5855cd6:


    ji "Dans ce genre de jeu...oui ! Vous m'avez demandé de présenter le jeu ... Laissez moi le faire !"


translate french suitepres2_7126ae72:


    ji "J'espère vraiment que vous allez aimer ce jeu parce qu'il a été fait par un couple de frenchies qui adorent faire des Visual Novels...."


translate french suitepres2_01690ab1:


    ji "C'est leur premier jeu, donc... ça va être loin d'être parfait, il va y avoir des erreurs en anglais et le rendu des images ne sera pas obligatoirement du même niveau que les plus grosses productions auxquelles vous avez joué..."


translate french suitepres2_7c6085c9:


    ji "Je vous demande juste d'être tolérant et de ne pas hésiter à donner des avis, des conseils ou des améliorations à ajouter pour faire de ce jeu quelque chose de plaisant à jouer !"


translate french suitepres2_a9f08678:


    cr "T'es trop mignonne... Allez, ils attendent pour jouer là ! Tu parles beaucoup trop !!!"


translate french suitepres2_5c5fc931:


    ji "Quand le jeu sera disponible, ils ouvriront un Patreon..."


translate french suitepres2_72680d31:


    cr "Ouais je le ferais dès que j'aurais compris comment tout ça fonctionne !"


translate french suitepres2_8b41fb06:


    ji "Okay, alors... Si vous aimez le jeu, les filles ou même les Créateurs, pensez à les soutenir !"


translate french suitepres2_d130ac7a:


    ji "Dites-leur ce que vous aimez, ce que vous voulez voir dans le jeu, quel personnage est votre favori..."


translate french suitepres2_9209e21a:


    cr "Oui tu as raison... Un rendu ou une animation prend du temps et on a pas un ordi de la NASA !"


translate french start_2d01670b:


    dpense "Je viens de France, je suis arrivé à l'Académie en septembre"


translate french start_40e8a57b:


    dpense "Mais quand je suis sur le terrain je donne tout !"


translate french start_eca0305e:


    dpense "Au début, je suis venu aux Etats-Unis pour 6 mois pendant un programme d'échange linguistique"


translate french start_8ca20e6f:


    dpense "J'ai postulé au programme pour améliorer mon anglais."


translate french start_5429a079:


    dpense "Le programme était simple : Tu vas aux Etats-Unis pour six mois, tu vis ta vie d'étudiant amérivain et tu sors avec un diplôme... rien de fou quoi !"


translate french start_1df5ed5b:


    dpense "Mais tout a changé rapidement une fois arrivé dans ce nouveau pays"


translate french start_6e0e7fb8:


    dpense "Tout a commencé comme ça :"


translate french start_fe665c28:


    dpense "J'étais dans un avion pour faire le voyage depuis la France"

translate french strings:


    old "So boring... ciao !"
    new "Trop chiant ... ciao !"




translate french suitepres_765fddca:


    ji "Okay c'est parfait alors ! Laisse moi t'emmener dans un endroit plus sympa ! "


translate french suitepres2_9ed41809:


    ji "Amuses-toi bien ! Peut être qu'on se reverra bientôt !"


translate french start_7c51b6bb:


    "La compétition..."


translate french start_6551398a:


    "Gagner face aux 100..."


translate french start_c99cf92e:


    "Je dois être..."


translate french start_5eb63514:


    "The B.E.S.T"


translate french start_5a862662:


    dpense "Mais il faut que je donne tout !"


translate french start_e05b501b:


    dpense "Le foot est une des raisons qui fait que je suis encore là..."


translate french start_4d4696ea:


    dpense "Le programme était : Tu vas aux Etats-Unis pour 6 mois, tu participes à la vie étudiante à l'américaine et tu reviens avec ton diplôme. Rien de fou quoi..."




translate french before_main_menu_c032868b:


    ji "Dans les yeux mon gars !"


translate french suitepres_6d1e1962:


    ji "Bon... Est ce que tu es prêt à faire face à certains sujets un peu durs comme les drogues...l'alcool..."


translate french suitepres2_ad184736:


    ji "Puisque tu es toujours là, je vais essayer de ne pas te faire perdre ton temps..."


translate french suitepres2_1b921c98:


    cr "Excusez-moi, Je suis le développeur de ce jeu, le BIG BOSS !"


translate french suitepres2_b958ba3c:


    cr "TOI ! T'es déjà en train de montrer ton corps au premier venu... et regarde ces vêtements !!! C'est normal de te montrer comme ça ?"


translate french suitepres2_2f34646b:


    cr "Okay okay... mais si il te saute dessus je ne bougerais pas le petit doigt pour toi !"


translate french suitepres2_8a00e96e:


    ji "Il paraît si timide... je l'aime déjà :)"


translate french suitepres2_1d05acc4:


    ji "Je te demande juste d'être tolérant et surtout n'hésite pas à donner des conseils ou demander des améliorations pour améliorer ce jeu !"


translate french suitepres2_4161e453:


    ji "Quand le jeu sera lancé, ils ouvriront un Patreon..."


translate french suitepres2_e6109cf4:


    cr "Ouais je le ferais quand j'aurais compris comment tout ça fonctionne..."


translate french suitepres2_459180bc:


    ji "En montrant votre soutien par vos dons sur Patreon ou SubscribeStar, Les Créateurs peuvent m'acheter des vêtements et J'ADORE les vêtements !!!"


translate french suitepres2_6155034b:


    cr "Tu veux pas 100 balles et un mars non plus ???"


translate french suitepres2_d1f2e7be:


    cr "Tu as raison... Les images et animations prennent du temps, et on n'a pas un ordinateur de la NASA à disposition donc..."


translate french suitepres2_2e1d206b:


    ji "Allez je vais pas vous garder plus longtemps..."


translate french start_394d75ae:


    dpense "Je suis pas mauvais en anglais mais c'est loin d'être parfait... Je fais des erreurs et les autres ne se gênent pas pour me les rappeler..."


translate french start_6b79d790:


    dpense "Le foot est une des raisons pour laquelle je suis encore ici..."


translate french start_e4e86c7f:


    dpense "J'étudie le Marketing et l'Economie..."


translate french start_16d55cb7:


    dpense "Un jour je suis en France avec mes amis et ma famille..."

translate french strings:


    old "Yes, of course I'm in !!!"
    new "Oui, évidemment !"



translate french strings:


    old "Your First Name?"
    new "Quel est votre prénom ?"



translate french strings:


    old "Press click to continue"
    new "Cliquez pour continuer"



translate french strings:


    old "You"
    new "Vous"




translate french before_main_menu_be6bd446:


    ji "Premièrement, as-tu plus de 18 ans ?"


translate french suitepres2_a22fecfa:


    ji "Si tu es toujours là, je vais essayer de ne pas te faire perdre ton temps..."


translate french suitepres2_e4d27473:


    ji "J'espère que tu vas aimer ce jeu parce qu'il a été fait par un couple de Français qui adorent jouer aux Visual Novels..."


translate french suitepres2_89797517:


    ji "C'est leur premier jeu, donc... Ca va être loin d'être parfait, il y aura sans doute des erreurs en anglais, ou un niveau de rendus n'atteignant pas celui de certains autres jeux du genre..."


translate french start_294714e5:


    dpense "Le programme était d'aller aux USA pour six mois, vivre ma vie d'étudiant à l'Academy et recevoir mon diplôme. Ca paraîssait simple."




translate french intro_0ff4aa8e:


    ji "Oh putain... Ushhhh... Cette bite va me manquer !"


translate french intro_fb8a1e5a:


    "Ca c'est Elise..."


translate french intro_98e35350:


    "Une amie... Avec bénéfices comme on dit..."


translate french intro_25e05fa5:


    "On se voit depuis plusieurs mois..."


translate french intro_1a0c5d8c:


    "Mais avec une seule règle en tête..."


translate french intro_87dc8d9b:


    "On s'attache pas..."


translate french intro_484019c5:


    "Merde... Ce cul va me manquer..."


translate french intro_4e03b261:


    eli "T'as intérêt à revenir vite..."


translate french intro_34325bce:


    eli "Je te jure, [name], t'as intérêt à revenir vite..."


translate french intro_fb6b37d8:


    eli "Sinon je viendrais moi-même te chercher s'il le faut..."


translate french intro_065e9a34:


    eli "Et j'espère que tu vas trouver des filles là-bas qui... Ahhh... Vont t'entraîner !!!"


translate french intro_5c0e76f8:


    d "De quoi ?"


translate french intro_a805da84:


    eli "Tu vas voir des filles qui... Hummmm.... Vont te donner de l'expérience ..."


translate french intro_96391aed:


    eli "Et je... ahhhh ... Veux voir les résultats dès que tu reviens !"


translate french intro_9bf13e71:


    eli "Ah... Ahhhh... Ahhh..."


translate french intro_274d889e:


    eli "Fiou.... T'es vraiment le meilleur..."


translate french intro_29b2cf68:


    dpense "Et ça c'est moi..."


translate french intro_7f0d6adc:


    dpense "Je suis de France, et je m'en vais aux US..."


translate french intro_394d75ae:


    dpense "Je suis pas trop mauvais en anglais mais c'est loin d'être parfait... Je fais des erreurs et les autres ne se gênent pas pour me faire la remarque..."


translate french intro_59049871:


    dpense "En fait, je vais aux US dans le cadre d'un échange linguistique entre les Etats-Unis et la France..."


translate french intro_e4e86c7f:


    dpense "J'étudie l'économie et le marketing..."


translate french intro_8ca20e6f:


    dpense "J'ai surtout postulé pour améliorer mon anglais..."


translate french intro_294714e5:


    dpense "Le programme était : Tu vas aux US pour 6 mois, tu vis ta vie là-bas et tu reviens avec un diplôme en poche... Facile quoi..."


translate french intro_84607db8:


    dpense "Ca a commencé comme ça..."


translate french intro_16d55cb7:


    dpense "Un jour je suis en France avec ma famille et mes amis..."


translate french intro_eafe64f5:


    dpense "Et le lendemain..."


translate french intro_fe665c28:


    dpense "Je suis dans un avion pour faire le trajet depuis la France..."


translate french intro_f9f78803:


    dpense "Vers l'Amérique !!!"




translate french intro_0ae9bcd0:


    ""




translate french intro_f2d0e4ee:


    eli "HUmmmmmmmmm...."


translate french intro_ba92a9c5:


    d "Ahhhhhhh ! Putainnnnnnnn........ Trop Bonnnnnnnnnn !!!!"




translate french personalize_9f250a0a:


    grace "Hey !"


translate french personalize_f9746723:


    grace "Hummmm.... C'est quoi ton prénom ?"


translate french personalize_ab9d0756:


    grace "Okay [name]..."


translate french personalize_f1f8fdf0:


    grace "Avant de commencer, j'aimerais savoir quel type de Héros tu es..."


translate french personalize_1d84f494:


    grace "Okay, Ruby a déjà hâte de te rencontrer !"


translate french personalize_288577ac:


    grace "Bon, ben j'ai tout ce qu'il me faut !"


translate french personalize_3edd6ed2:


    grace "On se voit bientôt !"


translate french personalize_a2e34685:


    grace "Tu dois aller voir Gabriella, elle adore les étudiants sérieux pendant ses cours..."


translate french personalize_288577ac_1:


    grace "Bon, ben j'ai tout ce qu'il me faut !"


translate french personalize_3edd6ed2_1:


    grace "On se voit bientôt !"


translate french personalize_7198e88c:


    grace "Hummmm.... Viens me voir à la piscine, j'ai hâte de voir ça !"


translate french personalize_288577ac_2:


    grace "Bon, ben j'ai tout ce qu'il me faut !"


translate french personalize_3edd6ed2_2:


    grace "On se voit bientôt !"


translate french personalize_e7275600:


    grace "Oh ? Bon ben les jumelles auront peut être du travail avec toi..."


translate french personalize_288577ac_3:


    grace "Bon, ben j'ai tout ce qu'il me faut !"


translate french personalize_3edd6ed2_3:


    grace "On se voit bientôt !"


translate french presentation_29b2cf68:


    dpense "Ca c'est moi..."


translate french presentation_7f0d6adc:


    dpense "Je viens de France et je vais aux USA..."


translate french presentation_394d75ae:


    dpense "Je suis pas trop mauvais en anglais mais je suis loin d'être parfait... Je fais des erreurs et les autres ne se gênent pas de me dire quand j'en fais..."


translate french presentation_59049871:


    dpense "Au début, je venais juste pour un programme d'échange linguistique entre la France et les USA..."


translate french presentation_e4e86c7f:


    dpense "J'étudie l'Economie et le Marketing..."


translate french presentation_8ca20e6f:


    dpense "J'ai postulé à ce programme pour améliorer mon anglais..."


translate french presentation_294714e5:


    dpense "Le programme du voyage était : Tu vas aux USA pour 6 mois, tu vis ta vie d'étudiant là-bas et tu reviens avec ta certification... Ca paraîssait simple..."


translate french presentation_84607db8:


    dpense "Et ça a commencé comme ça..."


translate french presentation_16d55cb7:


    dpense "Un jour j'étais en France avec mes amis et ma famille..."


translate french presentation_eafe64f5:


    dpense "Et le jour d'après..."


translate french presentation_fe665c28:


    dpense "J'étais dans un avion pour faire le voyage de France..."


translate french presentation_f9f78803:


    dpense "Vers l'Amérique !!!"

translate french strings:


    old "I'm a good friend, always there for others..."
    new "Je suis un bon copain, toujours là pour les autres..."


    old "I'm a good student, serious and calm..."
    new "Je suis un étudiant modèle, calme et sérieux..."


    old "I'm a sport addict, DAMN!"
    new "Je suis un addict du sport... DAMN !"


    old "I'm a Dom Juan, girls everywhere, everytime..."
    new "Je suis un Don Juan, les filles, partout, tout le temps..."



translate french strings:


    old "I'm a Don Juan, girls everywhere, everytime..."
    new "Je suis un Don Juan, des filles partout, tout le temps..."




translate french before_main_menu_0888dd09:


    ji "Hey salut toi... Tu t'es perdu ???"


translate french before_main_menu_59c2a0d0:


    ji "Dans les yeux mon gars !!!"


translate french before_main_menu_261c3b79:


    ji "Bon déjà... As-tu 18 ans ou plus ?"


translate french suitepres_f99b1c93:


    ji "Okay parfait ! Bon, allons dans un endroit plus intime !"


translate french suitepres_d5e7ada9:


    ji "Ce Visual Novel a plusieurs scènes avec du contenu sexuel, du langage cru, et traite de sujets sensibles comme les drogues, l'alcool... Ou même le sexe ?"


translate french suitepres_78b7a38d:


    ji "Cela pourrait ne pas être fait pour tous les lecteurs."


translate french suitepres_38165d90:


    ji "Alors... Es-tu prêt ?"


translate french suitepres2_71fd6753:


    ji "Si tu es toujours là, je vais essayer de te faire passer du bon temps ici et si possible... Que ce soit très plaisant, héhé ! "


translate french suitepres2_aab9f523:


    cr "Excusez-moi, je suis le développeur de ce jeu, le grand manitou !"


translate french suitepres2_af0bf494:


    cr "Je vois que vous avez rencontré une de mes filles. Laissez-moi lui parler juste une minute, s'il vous plaît..."


translate french suitepres2_5d1f2386:


    cr "Chérie ! T'es déjà en train de lui montrer ton corps... Et regarde ces vêtements !!! Est-ce que tu trouves ça normal de te montrer comme ça ? "


translate french suitepres2_dfcdecc4:


    ji "Dans ce genre de jeu... Oui !!! Tu m'as demandé de présenter le jeu... Laisse-moi le faire!"


translate french suitepres2_fa65479d:


    ji "Regarde notre joueur, il est si timide... Je l'aime déjà ! "


translate french suitepres2_edddd53b:


    ji "Eh, t'as perdu ta langue ?"


translate french suitepres2_b4f250c1:


    ji "Je te demande juste d'être tolérant et de ne pas hésiter à donner des conseils ou dire quelles améliorations les développeurs peuvent faire pour rendre le jeu meilleur !"


translate french suitepres2_56dc38b0:


    cr "Bon petit coeur... ALLEZ, il veut jouer... Tu parles beaucoup trop !!!"


translate french suitepres2_97160162:


    ji "Okay, okay Monsieur le Développeur !!! Humpf !"


translate french suitepres2_a8bece05:


    cr "Oh et... Tu lui as dit qu'il allait voir tes seins plus tard ?"


translate french suitepres2_dade9dd7:


    ji "Peut être... S'il fait les bons choix..."


translate french suitepres2_4c16d8a9:


    ji "Allez amuse-toi bien ! Et peut être à bientôt !"

translate french strings:


    old "Yes, of course I'm in!!!"
    new "Evidemment !"


    old "So boring... Ciao!"
    new "Oh la flemme... A plus !"




translate french start_c6d2ce5b:


    centered "{size=+10}{color=#1e90ff}{b}La compétition...{/b}{/color}{/size}"


translate french start_582ec739:


    centered "{size=+10}{color=#1e90ff}{b}C'était pas ma priorité jusqu'à présent......{/b}{/color}{/size}"


translate french start_cef0900c:


    centered "{size=+10}{color=#1e90ff}{b}Finir #1 sur les 100...{/b}{/color}{/size}"


translate french start_f593b9dc:


    centered "{size=+10}{color=#1e90ff}{b}Je ne peux pas me louper... Il faut que je sois...{/b}{/color}{/size}"


translate french start_0d4d00c7:


    centered "{size=+20}{color=#1e90ff}{b}The B.E.S.T{/b}{/color}{/size}"




translate french start_440c063c:


    centered "{size=+10}{color=#1e90ff}La compétition...{/color}{/size}"


translate french start_7f136763:


    centered "{size=+10}{color=#1e90ff}C'était pas ma priorité jusqu'à maintenant...{/color}{/size}"


translate french start_1f3237c5:


    centered "{size=+10}{color=#1e90ff}Finir #1 des 100...{/color}{/size}"


translate french start_78d2440b:


    centered "{size=+10}{color=#1e90ff}Je ne peux pas me louper... Il faut que je sois...{/color}{/size}"


translate french start_510cdb0b:


    centered "{size=+20}{color=#1e90ff}The B.E.S.T{/color}{/size}"


translate french personalize_0452e6be:


    grace "Oh !!! Je vois que tu as acheté le Mod d'aide à la décision !"


translate french personalize_f658dbf2:


    grace "J'aimerais sincèrement te remercier pour ton support et j'espère que tu vas apprécier l'expérience complète de B.E.S.T !!! "


translate french personalize_badf652e:


    grace "Si c'est ta première partie, je t'encourage vivement à désactiver le Mod pour que tu puisses faire tes propres choix..."


translate french personalize_b252f0e1:


    grace "Mais c'est ton jeu... Tes choix !!!"

translate french strings:


    old "Enable Walkthrough"
    new "Activer le Mod"


    old "Disable Walkthrough"
    new "Désactiver le Mod"


    old "I'm a good friend, always there for others...[TEMP1]"
    new "Je suis le bon copain, toujours là pour les autres...[TEMP1]"


    old "I'm a good student, serious and calm...[TEMP2]"
    new "Je suis un étudiant sérieux et calme...[TEMP2]"


    old "I'm a sport addict, DAMN![TEMP3]"
    new "Je suis un drogué du sport ! DAMN ![TEMP3]"


    old "I'm a Don Juan, girls everywhere, everytime...[TEMP4]"
    new "Je suis un Don Juan, des filles partout, tout le temps...[TEMP4]"



translate french strings:


    old "I'm a good friend, always there for others...[TEMP1!t]"
    new "Je suis le bon copain, toujours là pour les autres...[TEMP1!t]"


    old "I'm a good student, serious and calm...[TEMP2!t]"
    new "Je suis un étudiant sérieux et calme...[TEMP2!t]"


    old "I'm a sport addict, DAMN![TEMP3!t]"
    new "Je suis un drogué du sport ! DAMN ![TEMP3!t]"


    old "I'm a Don Juan, girls everywhere, everytime...[TEMP4!t]"
    new "Je suis un Don Juan, des filles partout, tout le temps...[TEMP4!t]"




translate french personalize_7945cae0:


    grace "Si c'est ta première partie, je t'encourage vivement à désactiver le Mod pour que tu puisses faire tes propres choix..."


translate french intro_88e66fc8:


    "On se voit depuis plusieurs mois maintenant..."


translate french intro_8915e2ac:


    "Mais avec une seule règle en tête..."


translate french intro_f598880b:


    eli "T'as intérêt à revenir vite..."


translate french intro_5864ee29:


    eli "Je te jure, [name] t'as vraiment intérêt à revenir vite, Mmmmm..."


translate french intro_23f7ffe5:


    eli "Sinon je viendrais te chercher moi-même..."


translate french intro_6c259796:


    eli "Et j'espère que tu trouveras des filles là-bas qui.... Ahhh... Vont t'entraîner !!!"


translate french intro_5e07a779:


    eli "Et je.... Ahhhh... Veux voir le résultat dès que t'es rentré !"


translate french presentation_57251b7a:


    dpense "Et le jour d'après...."




translate french suitepres2_dade9dd7_1:


    ji "Peut être... Ca ne dépend que de lui !"


translate french suitepres2_4c16d8a9_1:


    ji "Allez, amuse-toi bien ! On se voit peut être bientôt !"


translate french intro_6bd1d991:


    ji "Oh putain ! Ushhhh.... Ca va me manquer..."


translate french intro_fb8a1e5a_1:


    "Ca, c'est Elise..."


translate french intro_98e35350_1:


    "Mon amie... Avec bénéfices comme on dit..."


translate french intro_88e66fc8_1:


    "On se voit depuis quelques mois maintenant..."


translate french intro_8915e2ac_1:


    "Avec une seule règle en tête..."


translate french intro_87dc8d9b_1:


    "On s'attache pas..."


translate french intro_484019c5_1:


    "Putain... Ce cul aussi va me manquer..."


translate french intro_f598880b_1:


    eli "T'as intérêt à revenir vite..."


translate french intro_5864ee29_1:


    eli "Je te jure, [name], t'as intérêt à revenir... Hmmmm... Vite..."


translate french intro_23f7ffe5_1:


    eli "Sinon je viendrais te chercher moi-même..."


translate french intro_6c259796_1:


    eli "Et j'espère que tu trouveras des filles là-bas qui... Ahhhh... Vont t'entraîner !!!"


translate french intro_5c0e76f8_1:


    d "De quoi ?"


translate french intro_a805da84_1:


    eli "J'espère que des filles vont... Ahhhh ... Te donner de l'expérience...."


translate french intro_5e07a779_1:


    eli "Parce que je... Ohhhhhhhh.... Veux voir le résultat dès que tu reviens !!!"


translate french intro_274d889e_1:


    eli "Ahhhhhhhh.... T'es vraiment le meilleur..."

translate french strings:


    old "Do you want to activate the Streamer mode ? Streamer mode will hide explicit content to let you stream or watch the game without problems..."
    new "Voulez-vous activer le mode Streamer ? Ce mode cachera tout le contenu explicite pour vous laisser streamer ou profiter du jeu sans problèmes...."


    old "Yes, activate the streaming mode"
    new "Oui, activer le mode Streamer"


    old "No, I want the full-experience !"
    new "Non ! Je veux l'expérience complète !"




translate french presentation_803b81b2:


    dpense "C'est moi..."




translate french before_main_menu_d78d088e:


    ji "Hey mignon! Tu t'es perdu?"


translate french before_main_menu_5a53566a:


    ji "Mes yeux sont là mon gars!"


translate french suitepres_f9826a8e:


    ji "Tout d'abord, ce Visual Novel peut contenir des scènes sexy, du langage crû, et quelques sujets un peu sensibles comme les drogues ou l'alcool."


translate french suitepres_0e21fab0:


    ji "Est ce que tu es prêt?"


translate french suitepres2_ce3307b7:


    ji "Toujours là? Bon ben je vais essayer de te faire passer du bon temps et si possible... du très bon temps!"


translate french suitepres2_da58db29:


    cr "Excusez-moi, je suis le développeur de ce jeu!"


translate french suitepres2_2682ba1a:


    cr "Je vois que vous avez rencontré une de mes filles. Laissez-moi lui parler juste une minute s'il vous plaît."


translate french suitepres2_ddd41a39:


    cr "Chérie! T'es déjà en train de montrer ton corps! Est ce que c'est normal de se conduire ainsi?"


translate french suitepres2_70eedada:


    ji "Dans ce genre de jeu... Oui! Vous m'avez demandé de présenter le jeu alors laissez-moi faire!"


translate french suitepres2_254932e8:


    ji "Regardez-le. Il est tout timide. Je l'aime déjà!"


translate french suitepres2_cac004cf:


    ji "J'espère que vous allez aimer ce jeu parce qu'il a été fait par un couple de français qui adorent jouer aux Visual Novels."


translate french suitepres2_f868e8c5:


    ji "Le jeu est toujours en développement alors n'hésitez pas à donner des conseils ou votre avis sur ce qui ppourrait être amélioré!"


translate french suitepres2_6ae30e92:


    cr "Chérie... ALLEZ! Il veut jouer! Tu parles trop!"


translate french suitepres2_26d958df:


    ji "Okay, Môsieur le développeur! C'est parti!"


translate french suitepres2_71aeb4ea:


    ji "Peut être. S'il fait les bons choix..."


translate french suitepres2_f4f514d6:


    ji "Amuse-toi bien! Et à très bientôt!"


translate french suitepres2_71aeb4ea_1:


    ji "Peut être. S'il fait les bons choix..."


translate french suitepres2_d666e21a:


    ji "Amuse-toi bien! Et à très bientôt!"


translate french personalize_ed074dc1:


    grace "Hmmm. Comment t'appelles-tu?"


translate french personalize_3feba10d:


    grace "Okay [name]."


translate french personalize_87cd1f22:


    grace "Oh! Je vois que tu as acheté le mod!"


translate french personalize_b411b168:


    grace "Je te remercie pour ton soutien et j'espère que tu apprécieras l'expérience complète de B.E.S.T!"


translate french personalize_90c2145d:


    grace "Si c'est ta première fois ici, je te conseille de le laisser sur OFF et de faire les choix comme tu les sens."


translate french personalize_ed2ea51d:


    grace "Mais bon... C'est ton jeu, tes choix..."


translate french personalize_ea3f8080:


    grace "Avant que nous ne commencions, j'aimerais savoir quel genre de personne tu es, [name]."


translate french personalize_d86da4f2:


    grace "OKay, Ruby s'impatiente déjà!"


translate french personalize_ac389665:


    grace "Bon ben j'ai tout ce qu'il me faut."


translate french personalize_e554c344:


    grace "Tu devrais rencontrer Gabriella! Elle adore les élèves studieux dans sa classe!"


translate french personalize_ac389665_1:


    grace "Bon ben j'ai tout ce qu'il me faut."


translate french personalize_a8616aea:


    grace "Hmmm... Tu devrais me rejoindre à la piscine. Je veux voir ton niveau!"


translate french personalize_ac389665_2:


    grace "Bon ben j'ai tout ce qu'il me faut."


translate french personalize_c3c37204:


    grace "A plus tard!"


translate french personalize_5af586fe:


    grace "Oh? Alors les jumelles et toi vous entendrez sûrement très bien..."


translate french personalize_ac389665_3:


    grace "Bon ben j'ai tout ce qu'il me faut."


translate french personalize_c3c37204_1:


    grace "A plus tard!"


translate french intro_ea6a1d93:


    ji "Putain! Hummm... Cette bite va me manquer!"


translate french intro_7c65b928:


    "Ca, c'est Elise."


translate french intro_bcafb91f:


    "C'est ma... sexfriend comme on dirait?"


translate french intro_c41004be:


    "On se voit depuis plusieurs mois maintenant."


translate french intro_064e378f:


    "On a juste une règle."


translate french intro_89ca4f05:


    "Pas d'attaches."


translate french intro_1f193dfc:


    "Wah... Ce cul va me manquer."


translate french intro_305a78d2:


    eli "T'as intérêt à revenir vite quand même!"


translate french intro_8cab892c:


    eli "Je te jure, [name], t'as plutôt intérêt à revenir vite... Ahhhhh..."


translate french intro_eac5df1a:


    eli "Et j'espère que tu vas trouver des filles là-bas qui vont... Hmmmmm... t'entraîner!"


translate french intro_ad43f96e:


    eli "Tu vas rencontrer de nouvelles filles et... Hummmmm... avoir de l'expérience..."


translate french intro_1aea961b:


    eli "Et je.... Ahhhhhhhh.... veut être la première à en profiter quand tu rentres!"


translate french intro_6c492beb:


    eli "Hunghhhhh..... PU... TAIN... t'es le meilleur!"


translate french intro_1de5010f:


    ji "Putain! Hummm... Cette bite va me manquer!"


translate french intro_7c65b928_1:


    "Ca, c'est Elise."


translate french intro_bcafb91f_1:


    "C'est ma... sexfriend comme on dirait?"


translate french intro_6d670d0e:


    "On se voit depuis plusieurs mois maintenant."


translate french intro_064e378f_1:


    "On a juste une règle."


translate french intro_89ca4f05_1:


    "Pas d'attaches."


translate french intro_1f193dfc_1:


    "Wah... Ce cul va me manquer."


translate french intro_305a78d2_1:


    eli "T'as intérêt à revenir vite quand même!"


translate french intro_8cab892c_1:


    eli "Je te jure, [name], t'as plutôt intérêt à revenir vite... Ahhhhh..."


translate french intro_eac5df1a_1:


    eli "Et j'espère que tu vas trouver des filles là-bas qui vont... Hmmmmm... t'entraîner!"


translate french intro_ad43f96e_1:


    eli "Tu vas rencontrer de nouvelles filles et... Hummmmm... avoir de l'expérience..."


translate french intro_1aea961b_1:


    eli "Et je.... Ahhhhhhhh.... veut être la première à en profiter quand tu rentres!"


translate french intro_6c492beb_1:


    eli "Hunghhhhh..... PU... TAIN... t'es le meilleur!"


translate french intro_f1f9f153:


    eli "Ah... Ahhhhh... Ahhh..."


translate french intro_477f6abf:


    eli "Hnghhhhh..."


translate french intro_90929d09:


    d "Ahh! TROP BONNNNN!"


translate french intro_73f7f8be:


    eli "Unhhhh... T'es le meilleur..."


translate french presentation_712108b3:


    dpense "Ca c'est moi."


translate french presentation_17f39f37:


    dpense "Je viens de France et je vais étudier aux States."


translate french presentation_f0b7f0a4:


    dpense "Mon niveau d'anglais est pas mauvais mais je suis loin d'être parfait."


translate french presentation_d7cb2ac4:


    dpense "Je vais là bas pour un programme d'échange linguistique pour six mois."


translate french presentation_bae9b014:


    dpense "J'étudie l'Economie et le Marketing."


translate french presentation_20aadd2e:


    dpense "J'ai postulé pour ce programme afin de m'améliorer en langues étrangères."


translate french presentation_b64a060f:


    dpense "Le programme était : Partir six mois, profiter de la vie étudiante américaine et revenir avec un certificat. Ca semblait simple."


translate french presentation_e5e4c3cb:


    dpense "C'est arrivé si vite."


translate french presentation_43721bcf:


    dpense "Un jour j'étais en France avec ma famille et mes amis."


translate french presentation_65a1e9f9:


    dpense "Et le lendemain,"


translate french presentation_8103b4af:


    dpense "Vers l'Amérique!"

translate french strings:


    old "Yes, of course I'm in!"
    new "Ben ouais bien sûr que je suis partant!"


    old "Not for me, thanks. Ciao!"
    new "C'est pas pour moi tout ça. Ciao!"


    old "I'm a good friend, always there for others.[TEMP1!t]"
    new "Je suis le bon ami, toujours là pour les autres.[TEMP1!t]"


    old "I'm a good student, serious and calm.[TEMP2!t]"
    new "Je suis le bon étudiant, sérieux et calme.[TEMP2!t]"


    old "I'm a sports junkie, and I'm always hitting the gym![TEMP3!t]"
    new "Je suis énorme et sec! Toujours au temple! DAMN![TEMP3!t]"


    old "I'm a ladies man, a regular Don Juan or Casanova. [TEMP4!t]"
    new "Je suis un Casanova, des filles partout, tout le temps.[TEMP4!t]"




translate french personalize_e50176b2:


    grace "Durant le jeu, avec le mod activé, vous allez voir des icônes commes celle-ci:"


translate french personalize_33cf37a1:


    grace "Cela veut dire que c'est la 'meilleure' option à choisir."


translate french personalize_c294014b:


    grace "Vous verrez d'autres icônes comme celle-ci:"


translate french personalize_78f90f44:


    grace "Cela veut dire que vous allez gagner un point dans cette statistique."


translate french personalize_ead4d56d:


    grace "Enfin vous allez avoir des icônes avec les filles comme la mienne:"


translate french personalize_a6c03977:


    grace "Cela veut dire que le choix associé est nécessaire pour continuer l'histoire avec cette fille."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
