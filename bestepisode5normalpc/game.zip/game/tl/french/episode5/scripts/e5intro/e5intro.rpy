

translate french strings:


    old "EPISODE 5"
    new "EPISODE 5"


    old "ORIGINS"
    new "ORIGINES"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
