
translate french e5s4_f67fdb4c:


    julia "[name] !"


translate french e5s4_ec185663:


    d "Julia !"


translate french e5s4_f66d8d77:


    d "Je suis désolé... Ça va ?"


translate french e5s4_5698db07:


    julia "Je..."


translate french e5s4_1d4287af:


    julia "Je ne sais même pas ce que je suis censée faire..."


translate french e5s4_28738a97:


    julia "Je savais que ça finirait par arriver, mais..."


translate french e5s4_629cc342:


    julia "Maintenant que c’est réel, je... je ne sais pas comment gérer ça."


translate french e5s4_9ebde8b0:


    julia "Les papiers, les funérailles..."


translate french e5s4_50d9ab42:


    julia "Comment suis-je censée..."


translate french e5s4_cd6b97e7:


    d "Hé... Je suis là."


translate french e5s4_49d41ef1:


    d "Je vais t’aider, d'accord ?"


translate french e5s4_8fbf9556:


    d "Ne t’inquiète pas. On va s’en sortir ensemble."


translate french e5s4_34c78612:


    d "D’abord, il faut que tu respires."


translate french e5s4_d6f16a8e:


    julia "Ouais..."


translate french e5s4_23439b72:


    julia "Mais je ne sais pas comment je vais traverser ça..."


translate french e5s4_bf67669b:


    julia "Je ne sais même pas combien coûte un enterrement..."


translate french e5s4_3e3d52f9:


    julia "Et je..."


translate french e5s4_5698db07_1:


    julia "Je..."


translate french e5s4_29ccc355:


    d "Je suis juste là."


translate french e5s4_fd221f30:


    d "Tu n’es pas seule."


translate french e5s4_492a2071:


    julia "Merci..."


translate french e5s4_7da0825a:


    ji "Madame Carter ?"


translate french e5s4_bc97c9f8:


    d "Hm ?"


translate french e5s4_3fb1de81:


    julia "Oui ?"


translate french e5s4_314d5042:


    ji "Nous avons une lettre pour vous. Vous devez la lire seule. Elle contient des informations sensibles."


translate french e5s4_d573cabd:


    ji "Sachez que tout ce qui concerne votre mère a été pris en charge."


translate french e5s4_c0ea87f6:


    julia "Attendez... Quoi ?"


translate french e5s4_d9a48665:


    julia "Mais... qui a fait ça ?"


translate french e5s4_5da38dbf:


    julia "Qui êtes-vous ?"


translate french e5s4_a871997c:


    ji "Je ne suis pas autorisé à en dire plus."


translate french e5s4_039f4e17:


    ji "Suivez simplement ce qui est écrit dans la lettre."


translate french e5s4_f3656921:


    julia "[name] ?"


translate french e5s4_ace848dd:


    julia "C’est quoi ce bordel ?"


translate french e5s4_d461a700:


    d "Je n'en ai aucune idée..."


translate french e5s4_7fec0a9e:


    julia "Il a dit que je devais la lire seule."


translate french e5s4_54b177ed:


    d "Ouais... D'accord."


translate french e5s4_8cb51d10:


    d "Je vais te laisser un peu d’espace."


translate french e5s4_0b0d807e:


    d "Mais appelle-moi si tu as besoin de quelque chose, d'accord ?"


translate french e5s4_f35e0197:


    julia "Je vais... Je vais retourner auprès de ma mère un moment."


translate french e5s4_2c5d85d2:


    d "Merci de m’avoir appelé, Julia."


translate french e5s4_5df5ea6f:


    julia "J’aurais aimé te voir dans de meilleures circonstances..."


translate french e5s4_0dabc311:


    d "Hé. Tu fais ce qu’il y a de mieux pour elle."


translate french e5s4_7f1dab77:


    d "Et on va s’en sortir. Ensemble."


translate french e5s4_492a2071_1:


    julia "Merci..."


translate french e5s4_41dfeedb:


    julia "À demain."


translate french e5s4_c5072505:


    d "À plus."


translate french e5s4_0d61ad15:


    dpense "Julia..."


translate french e5s4_c37ac3d7:


    dpense "Elle a tenu bon jusqu'à la toute fin."


translate french e5s4_286ea794:


    dpense "Et maintenant, elle doit tout gérer seule."


translate french e5s4_2eb10f7c:


    dpense "J'aimerais pouvoir en faire plus..."


translate french e5s4_3b9ee1cc:


    dpense "Ce type... Marc."


translate french e5s4_982b997f:


    dpense "C'était quoi cette réunion ?"


translate french e5s4_bb85925e:


    dpense "Tout ce qu'il a dit résonne encore dans ma tête."


translate french e5s4_a1601672:


    dpense "Tout ça n’est-il vraiment qu’un show ? Un piège ?"


translate french e5s4_603617f4:


    dpense "Ruby ?"


translate french e5s4_c683ab53:


    ruby "Hé... Ça va ?"


translate french e5s4_04ba0593:


    d "Ouais... J'essaie juste de tout digérer."


translate french e5s4_4390ce19:


    ruby "J'ai entendu pour Julia..."


translate french e5s4_abe27dd9:


    d "Ouais. Je suis allé la voir."


translate french e5s4_77adc2bc:


    d "Elle essaie de tenir le coup mais... c’est difficile."


translate french e5s4_c79f6782:


    d "Elle a perdu sa mère aujourd'hui."


translate french e5s4_74bb3c80:


    d "...Attends. Quoi Julia ?"


translate french e5s4_dcd7a911:


    ruby "Oh. Tu ne savais pas ?"


translate french e5s4_f59e34d5:


    ruby "Sa mère est décédée aujourd'hui."


translate french e5s4_75fdf57c:


    d "Merde... Non, je n'avais pas entendu."


translate french e5s4_1cd391bf:


    d "Comment elle va ?"


translate french e5s4_0c999dd1:


    ruby "Pas bien, évidemment. Elle essaie de tenir bon, mais... ouais."


translate french e5s4_a9039faa:


    d "Merde..."


translate french e5s4_26979248:


    d "C’est beaucoup à digérer."


translate french e5s4_4b6212a6:


    ruby "Ouais. Tout est un peu bordélique ces derniers temps."


translate french e5s4_78e4e56a:


    ruby "Et avec ce qui m’est arrivé... et ce qui t’est arrivé..."


translate french e5s4_3b7ab98b:


    d "Ouais. Je voulais te parler de ça."


translate french e5s4_84aa0ed1:


    d "J’ai rencontré quelqu’un. Il s’appelle Marc."


translate french e5s4_37015eab:


    d "Il m’a dit des trucs. Des trucs fous."


translate french e5s4_7e8a656c:


    ruby "Attends. Ça a l’air important."


translate french e5s4_c40f4064:


    ruby "Laisse-moi appeler Madison et Grace. On doit toutes en parler."


translate french e5s4_2e4816fd:


    ruby "Je vais appeler Madison... et Grace..."


translate french e5s4_70a8750f:


    ji "Palazio Pizza, que puis-je vous servir ?"


translate french e5s4_a7091c0a:


    d "...Ruby ?"


translate french e5s4_010c8e4c:


    ruby "Oups ! Mauvais numéro !"


translate french e5s4_0de41c26:


    ji "Attendez ! Les nouveaux appelants bénéficient de 20 pour cent de réduction sur les pizzas pepperoni !"


translate french e5s4_ca32cdf5:


    ruby "AU REVOIR !"


translate french e5s4_39c3230b:


    ruby "D'accord ! J’ai eu la vraie Madison cette fois."


translate french e5s4_4820c91d:


    mad "Que se passe-t-il ?"


translate french e5s4_7908ae5f:


    grace "Wow, ça a l’air sérieux."


translate french e5s4_da7d5668:


    ruby "Je voulais vous parler à toutes. Parce que... les choses commencent à déraper."


translate french e5s4_98c3ec1f:


    ruby "Grace, tu n’étais pas là, donc je vais expliquer."


translate french e5s4_1e9d5276:


    ruby "Emerick m’a poussée. Il a complètement craqué. Je ne pense pas qu’il ait voulu que ça aille aussi loin, mais..."


translate french e5s4_f9ded3c8:


    ruby "J’ai été poussée dans la rue. Une voiture m’a presque renversée."


translate french e5s4_6839a591:


    ruby "[name] m’a rattrapée juste à temps."


translate french e5s4_b1974b0e:


    grace "Quoi ?! Tu es sérieuse ?"


translate french e5s4_d005625a:


    ruby "Ouais. Ça va maintenant, mais... c’était limite."


translate french e5s4_7725f489:


    mad "Quand je l’ai appris, j’étais furieuse."


translate french e5s4_09776ff3:


    mad "Emerick est incontrôlable."


translate french e5s4_63484afd:


    grace "Pourquoi diable il est encore autorisé à nous approcher ?"


translate french e5s4_4e7f2bec:


    ruby "Je ne sais pas. Il agit comme si de rien n’était."


translate french e5s4_5755b285:


    mad "Et puis Julia..."


translate french e5s4_ad61733b:


    d "Ouais. Je suis allé la voir aujourd’hui."


translate french e5s4_ec3da36e:


    d "Elle essaie de tenir le coup, mais... c’est difficile."


translate french e5s4_bf553881:


    d "Sa mère est décédée."


translate french e5s4_6aaccc2f:


    grace "Je sais... c’est horrible."


translate french e5s4_725c0812:


    ruby "Elle n’en parle pas beaucoup, mais on voit qu’elle est anéantie."


translate french e5s4_c811593d:


    d "Je ne l’ai pas vue, mais j’ai entendu ce qui s’est passé..."


translate french e5s4_c0efb8e2:


    d "C’est... c’est vraiment dûr."


translate french e5s4_2b4f2f00:


    grace "Ouais. Sa mère est décédée aujourd’hui."


translate french e5s4_dcd0fc0a:


    ruby "Elle garde tout pour elle. Comme d’habitude."


translate french e5s4_6ef35f4c:


    d "Et en plus de ça, j’ai rencontré quelqu’un aujourd’hui. Un gars nommé Marc."


translate french e5s4_6768b0ed:


    mad "C’est qui ce type ?"


translate french e5s4_a08e946d:


    d "Il prétend tout savoir sur le B.E.S.T."


translate french e5s4_dd8a418e:


    d "Il a dit que ce tournoi n’est pas ce que l’on croit."


translate french e5s4_ce38d77f:


    ruby "Tu veux dire que ce n’est pas juste pour gagner la maison ?"


translate french e5s4_e081b323:


    d "Exactement. Selon lui, on fait partie d’un système plus grand. Quelque chose de prévu."


translate french e5s4_ce54a2ac:


    d "On a été choisis. Testés. Observés."


translate french e5s4_c810dd52:


    grace "Qu’est-ce que c’est que ce bordel..."


translate french e5s4_0b6ddbfd:


    mad "Je savais que ce truc sentait l’escroquerie."


translate french e5s4_693ce52c:


    ruby "Qu’est-ce qu’il a encore dit ?"


translate french e5s4_09bbb130:


    d "Pas grand-chose. Mais il a dit que je commencerais à comprendre bientôt..."


translate french e5s4_0014d5db:


    d "...que le jeu... a déjà commencé."


translate french e5s4_47f431db:


    ruby "C'est bien plus que ce à quoi on s'attendait..."


translate french e5s4_30451cc7:


    grace "Attends, tu veux dire qu'on a été observés ? Depuis quand ?"


translate french e5s4_773f8271:


    d "Je ne sais pas. Il a dit que ça durait depuis un moment."


translate french e5s4_7e0a53c0:


    mad "Alors, on est quoi ? Des cobayes dans une expérience ?"


translate french e5s4_0d4f13f4:


    d "Je ne pense pas que ce soit aussi simple..."


translate french e5s4_1b07d801:


    ruby "Alors c'est quoi ? Un test ? Un piège ?"


translate french e5s4_1a76835e:


    d "Honnêtement ? Je n'ai pas encore toutes les informations."


translate french e5s4_e7cb1601:


    grace "Il a dit qui est derrière tout ça ?"


translate french e5s4_f0bf102d:


    d "Non. Juste que ça fait partie de quelque chose de bien plus grand. Que nous avons été choisis."


translate french e5s4_4c84a898:


    mad "Choisis pour quoi exactement ? Pour concourir ? Pour combattre ? Pour tout perdre ?"


translate french e5s4_28e28f81:


    ruby "Je savais qu'il y avait quelque chose qui clochait dès le début, mais ça..."


translate french e5s4_7d2acf2e:


    grace "Tu as dit qu'il sait tout ? Alors pourquoi il ne t'a pas dit plus ?"


translate french e5s4_2864f00d:


    d "Il a dit que je n'étais pas encore prêt. Que je comprendrais bientôt."


translate french e5s4_2246aae3:


    mad "Ugh. C'est tellement cryptique."


translate french e5s4_2fca0cd3:


    ruby "On dirait le début d'un discours pour recruter dans une secte..."


translate french e5s4_641fa8fe:


    grace "Ou le scénario d'une émission de télé-réalité bien tordue."


translate french e5s4_aab1be9e:


    d "Il a dit que nous faisions tous partie de quelque chose... de plus profond que le simple fait de gagner."


translate french e5s4_0016133e:


    ruby "Eh bien, c'est rassurant. Complètement apaisant."


translate french e5s4_8ffa9e0d:


    mad "Alors, qu'est-ce qu'on fait ? On continue de faire semblant qu'il ne se passe rien ?"


translate french e5s4_f54ee289:


    grace "Nous avons besoin de plus d'informations. On ne peut pas lutter contre quelque chose qu'on ne comprend même pas."


translate french e5s4_ccc9f612:


    d "Demain, j'essaierai d'en savoir plus. Je lui parlerai à nouveau si je peux."


translate french e5s4_67e061e3:


    ruby "Fais juste attention, d'accord ?"


translate french e5s4_d4fb4120:


    mad "Ouais. On ne sait pas à quoi on a affaire."


translate french e5s4_27b73db8:


    grace "Et si c'est vraiment plus grand que le tournoi... on va avoir besoin les uns des autres."


translate french e5s4_ee54b1de:


    ruby "On en a déjà besoin."


translate french e5s4_aed0c0fd:


    mad "D'accord... On devrait probablement se reposer."


translate french e5s4_0979b50c:


    mad "On a des cours demain, et probablement encore des conneries à gérer."


translate french e5s4_4db8fe42:


    grace "Ouais... Ma tête tourne."


translate french e5s4_75665dc5:


    ruby "Allons dormir. On en parlera plus demain."


translate french e5s4_daf14272:


    mad "Bonne nuit, tout le monde."


translate french e5s4_8065de9f:


    grace "Bonne nuit."


translate french e5s4_64dc9e96:


    ruby "Hé... euh, avant que je raccroche complètement..."


translate french e5s4_f7fe7a5c:


    ruby "Je peux te demander quelque chose de bizarre ?"


translate french e5s4_ac60fa45:


    d "Bien sûr."


translate french e5s4_ce0d0261:


    ruby "Ça te va si je te rejoins ce soir ?"


translate french e5s4_b1312370:


    ruby "Je... je ne veux juste pas être seule après tout ce qui s'est passé aujourd'hui."


translate french e5s4_0965e6eb:


    ruby "Emerick, le tournoi, le discours de Marc..."


translate french e5s4_094b1b4f:


    ruby "C'est juste... trop. Ma tête arrête pas de tourner."


translate french e5s4_a6d68059:


    ruby "Et je sais que je ne suis pas la seule à qui tu tiens."


translate french e5s4_9cfe6a2e:


    ruby "Je ne veux pas interférer avec ça, ni marcher sur les pieds de qui que ce soit."


translate french e5s4_3ecfbc5f:


    ruby "Mais ce soir... je ne veux pas avoir l'impression d'être toujours en second par rapport à quelqu'un d'autre."


translate french e5s4_de84ef76:


    ruby "Je ne demande rien de grand."


translate french e5s4_9dd34e12:


    ruby "Juste... laisse-moi me sentir en sécurité, juste pour une nuit."


translate french e5s4_474f9baa:


    d "Ruby..."


translate french e5s4_5e7830cb:


    ruby "S'il te plaît. J'en ai marre de faire semblant que ça va quand ce n'est pas le cas."


translate french e5s4_2859ae71:


    d "Ouais... viens. Tu n'as pas à traverser ça seule."


translate french e5s4_434d1abc:


    ruby "Merci..."


translate french e5s4_b930ba57:


    ruby "J'avais vraiment besoin d'entendre ça ce soir."


translate french e5s4_195d64bd:


    d "J’aimerais dire oui, mais... j’essaye de rester fidèle à Grace."


translate french e5s4_d645eb8e:


    d "Elle mérite ça."


translate french e5s4_0dd95e4c:


    ruby "...Oui. Elle le mérite."


translate french e5s4_3002dbb4:


    ruby "Merci d’être honnête."


translate french e5s4_f576134c:


    d "Tu comptes pour moi, Ruby. Vraiment."


translate french e5s4_5b14b936:


    d "Mais je suis avec Julia maintenant, et je veux rester fidèle à ça."


translate french e5s4_8c980e8f:


    ruby "C’est... bien de ta part."


translate french e5s4_4b4f83cf:


    ruby "Elle a de la chance."


translate french e5s4_2a4276d1:


    d "Madison et moi avons quelque chose... et je ne veux pas tout gâcher."


translate french e5s4_adadc0dd:


    ruby "Alors je ne compliquerai pas les choses."


translate french e5s4_7a5cf108:


    ruby "Ça ira. J'avais juste besoin de demander."


translate french e5s4_7da82755:


    d "Je ne suis pas sûr que ce soit une bonne idée ce soir..."


translate french e5s4_ad7efad5:


    d "Je ne veux pas embrouiller les choses entre nous."


translate french e5s4_1f0c1a1b:


    ruby "C’est compréhensible."


translate french e5s4_d3f8e7cd:


    ruby "Merci d’être sincère avec moi."


translate french e5s4_6d70222a:


    d "Toujours. Repose-toi, d’accord ?"


translate french e5s4_9b1f8f0e:


    d "Je suppose que j’ai quelques minutes avant qu’elle n’arrive."


translate french e5s4_6975dc98:


    d "Elle a compris... J’espère quand même qu’elle va bien ce soir."


translate french e5s4_f767a823:


    d "Je devrais probablement vérifier mon téléphone."


translate french e5s4_419a87f2:


    dpense "Un message de Grace ?"


translate french e5s4_1fd0f147:


    dpense "Elle a l’air vraiment heureuse ici..."


translate french e5s4_8ad5a773:


    dpense "Et honnêtement... moi aussi."


translate french e5s4_51c7130e:


    dpense "C’est un beau souvenir. Juste nous deux, sans pression..."


translate french e5s4_13fc833d:


    dpense "Ça devrait être génial sur mon OnlyStan..."


translate french e5s4_7a73f481:


    d "Belle photo."


translate french e5s4_ccdf9116:


    d "Nous avons l'air forts, confiants et radieux."


translate french e5s4_00e09755:


    d "Celle-ci est juste pour nous."


translate french e5s4_31e40bcd:


    d "Tout n'a pas besoin d'être exposé."


translate french e5s4_01878ec1:


    dpense "Mince... Elle est pleine de surprises."


translate french e5s4_4f70d01f:


    dpense "Charlotte ?"


translate french e5s4_f3c23a86:


    dpense "Maintenant je suis vraiment curieux..."


translate french e5s4_6eb69ed4:


    d "Un autre message ?"


translate french e5s4_d8219e99:


    dpense "...Whoa."


translate french e5s4_0e3304c8:


    dpense "Ok, c’est... définitivement pas ce à quoi je m’attendais avant de dormir."


translate french e5s4_a7578e9c:


    dpense "Qu'est-ce qu'elle prépare ?"


translate french e5s4_c3c1f016:


    dpense "Gabriella ?"


translate french e5s4_977cfae9:


    dpense "Pourquoi ai-je l'impression que ce massage ne va pas se passer comme prévu ?"


translate french bluephoneep5_61f19795:


    dpense "Mince... Même ses baisers sont coquins."


translate french fine5s4_95524d6a:


    dpense "Elise..."


translate french fine5s4_43c4fe17:


    dpense "Toujours pas de réponse."


translate french fine5s4_80dafe19:


    dpense "Tu réponds d'habitude tout de suite."


translate french fine5s4_19228ffc:


    dpense "J'espère que tout va bien."


translate french fine5s4_37e64b70:


    dpense "..."


translate french fine5s4_9126c2f0:


    dpense "Je vais juste envoyer un message. Peut-être qu'elle le verra plus tard."


translate french fine5s4_82a44376:


    dpense "Salut. Je voulais juste prendre de tes nouvelles. J'espère que ça va. Dis-moi si tu as besoin de quoi que ce soit."


translate french fine5s4_1e77a7f2:


    dpense "Je déteste ne pas savoir... Elise, où es-tu ?"


translate french fine5s4_68c6e8ec:


    ruby "Salut..."


translate french fine5s4_57d6c7f9:


    d "Hé. Entre."


translate french fine5s4_7271dc12:


    d "Tu es..."


translate french fine5s4_4e8b0497:


    d "Magnifique."


translate french fine5s4_7b1a680f:


    ruby "Merci..."


translate french fine5s4_09e8c19c:


    ruby "...et encore pour me laisser venir."


translate french fine5s4_7811c038:


    ruby "Je sais qu'il est tard. Je ne voulais juste pas être seule."


translate french fine5s4_651a15b8:


    d "Tu n'es pas seule ce soir."


translate french fine5s4_39aa7b90:


    ruby "Ça fait beaucoup... Emerick, le tournoi, le discours de Marc..."


translate french fine5s4_81cee369:


    ruby "Je ne sais même plus où j'en suis."


translate french fine5s4_43aeba9d:


    d "Ici. Avec moi."


translate french fine5s4_84084c39:


    ruby "Prudence... Tu continues à parler comme ça, je pourrais bien craquer."


translate french fine5s4_46951e3c:


    d "Peut-être que c'est ce dont tu as besoin."


translate french fine5s4_dbda7c19:


    ruby "Peut-être."


translate french fine5s4_cf7c937e:


    ruby "Tu peux t'approcher ? Genre... vraiment près ?"


translate french fine5s4_7ed84a97:


    d "Aussi près que tu veux."


translate french fine5s4_91f296cd:


    ruby "C'est... rassurant."


translate french fine5s4_79ae661e:


    ruby "Même si tu es proche de quelqu'un d'autre... ce soir, tu as fait de la place pour moi."


translate french fine5s4_3faf247b:


    ruby "Ça signifie beaucoup."


translate french fine5s4_67a0444c:


    d "Je te vois, Ruby. Je t'ai toujours vue."


translate french fine5s4_2f91314d:


    ruby "Tu sens bon..."


translate french fine5s4_f7e4daff:


    ruby "C'est dangereux quand je suis aussi vulnérable."


translate french fine5s4_ffdb82a9:


    d "Alors je vais essayer de ne pas en profiter..."


translate french fine5s4_8e992ec1:


    ruby "Je te fais confiance."


translate french fine5s4_63507eef:


    ruby "Je ressens... quelque chose changer. Entre nous."


translate french fine5s4_d7eb5bfa:


    d "Tu n'es pas la seule."


translate french fine5s4_c0931e2c:


    ruby "Merci d'être là."


translate french fine5s4_d79ba712:


    ruby "Bonne nuit, [name]..."


translate french fine5s4_cc1bfc17:


    d "Bonne nuit, Ruby."


translate french fine5s4_c0028710:


    dpense "Elle s'est endormie rapidement..."


translate french fine5s4_bcc36e54:


    dpense "Elle a l'air tellement paisible maintenant. Tellement... douce."


translate french fine5s4_1f9e783f:


    dpense "Son épaule est nue... la couverture a légèrement glissé."


translate french fine5s4_814b1353:


    dpense "Ma main repose sur son côté..."


translate french fine5s4_1096a323:


    dpense "Sans réfléchir, ma main glisse... juste un peu..."


translate french fine5s4_5f6783d6:


    dpense "Son sein."


translate french fine5s4_ff931967:


    dpense "À peine. La chaleur de sa peau sous mes doigts."


translate french fine5s4_f5cab973:


    dpense "Elle ne bouge pas. Respire... lentement. Calmement."


translate french fine5s4_c5eaa7ad:


    dpense "Elle est là, dans mes bras."


translate french fine5s4_6ffb99f3:


    dpense "Elle me fait confiance pour tout."


translate french fine5s4_db130c40:


    dpense "Son cœur bat... c'est rapide maintenant."


translate french fine5s4_1795db4e:


    dpense "Est-ce que je l'ai réveillée ?"


translate french fine5s4_8efb18eb:


    ruby "Ne bouge pas..."


translate french fine5s4_32e37ea9:


    dpense "Elle est réveillée."


translate french fine5s4_cae1a09f:


    dpense "Et elle laisse faire."


translate french fine5s4_2f17f88f:


    dpense "Et maintenant... je ne pense pas pouvoir revenir en arrière."


translate french fine5s4_ce5ea2b0:


    d "J'espère que Ruby va bien..."


translate french fine5s4_ce3f5fa9:


    d "Elle avait l'air vraiment bouleversée."


translate french fine5s4_b055f21c:


    d "C'est juste... difficile."


translate french fine5s4_eb56c68a:


    d "Peu importe combien je tiens à elle, je ne peux pas être partout à la fois."


translate french fine5s4_30f54b62:


    d "Et parfois, essayer de protéger tout le monde signifie laisser quelqu'un tomber."


translate french fine5s4_7ba031f2:


    d "J'ai fait mon choix."


translate french fine5s4_7f684aa6:


    d "Cela ne signifie pas que je ne me soucie pas d'elle... mais je dois être honnête avec moi-même."


translate french fine5s4_c06faaaf:


    d "Elle a demandé du réconfort et je l'ai repoussé..."


translate french fine5s4_398d8d31:


    d "J'espère juste qu'elle comprendra pourquoi."


translate french fine5s4_52f68f5b:


    d "Tout ça... le B.E.S.T, Emerick, Marc..."


translate french fine5s4_cc848cc7:


    d "C’est comme si tout se désintégrait et se reconstruisait en même temps."


translate french fine5s4_f969ee57:


    d "Et demain, ça ne sera probablement pas plus calme."


translate french fine5s4_ebf194fb:


    d "Un pas à la fois..."

translate french strings:


    old "Yeah, come over.[TEMP1!t]"
    new "Ouais, rejoins-moi.[TEMP1!t]"


    old "I don’t think that would be right..."
    new "Je ne pense pas que ce soit une bonne idée..."


    old "Hey... Just wanted to say good night :)"
    new "Salut... Je voulais juste te dire bonne nuit :)"


    old "Today was amazing. I'm still smiling from that climb. 💕"
    new "Aujourd’hui c’était génial. Je souris encore en pensant à cette ascension. 💕"


    old "Here’s my favorite photo of us from earlier!"
    new "Voici ma photo préférée de nous prise plus tôt !"


    old "Yeah, she looks amazing. Let people see that."
    new "Ouais, elle est magnifique. Laissons les gens voir ça."


    old "No, I’ll keep it for myself."
    new "Non, je vais la garder pour moi."


    old "Climbing Morning ;)"
    new "Matin d’escalade ;)"


    old "Best view with best girl!"
    new "Meilleure vue avec la meilleure fille !"


    old "Oh, and this one..."
    new "Oh, et celle-ci..."


    old "Don't you dare post it 😉"
    new "Ne pense même pas à la publier 😉"


    old "Good night, [name]. Sleep tight. 💤💗"
    new "Bonne nuit, [name]. Dors bien. 💤💗"


    old "Hey, handsome. Got any plans at 9 a.m. tomorrow?"
    new "Salut, beau gosse. Tu as des plans pour 9h demain ?"


    old "Hmm...No, why?"
    new "Hmm...Non, pourquoi ?"


    old "Because you should come by the massage parlor."
    new "Parce que tu devrais passer au salon de massage."


    old "No questions. Just trust me 😏"
    new "Aucune question. Fais-moi confiance 😏"


    old "Let’s just say... you won’t be disappointed."
    new "Disons juste que... tu ne seras pas déçu."


    old "Alright, I’ll be there."
    new "D’accord, je serai là."


    old "Good boy 😘"
    new "Bon garçon 😘"


    old "Sleep tight. You’re gonna need your energy."
    new "Dors bien. Tu vas avoir besoin de ton énergie."


    old "Hello [name]. I booked a recovery massage for you tomorrow at 9:30."
    new "Bonjour [name]. J'ai réservé un massage de récupération pour toi demain à 9h30."


    old "A proper massage will ease the tension you've built up."
    new "Un bon massage soulagera la tension que tu as accumulée."


    old "A professional will take care of it. Just show up rested."
    new "Un professionnel s’en chargera. Il suffit d’arriver reposé."


    old "Wait… not you?"
    new "Attends... Pas toi ?"


    old "I thought you’d prefer someone with qualified hands."
    new "Je pensais que tu préférais quelqu’un avec des mains qualifiées."


    old "Not sure anyone’s hands would beat yours..."
    new "Pas sûr que les mains de quelqu’un d’autre égalent les tiennes..."


    old "Flattering... and dangerous."
    new "Flatteur... et dangereux."


    old "Now rest. Tomorrow will be... instructive."
    new "Maintenant, repose-toi. Demain sera... instructif."


    old "You’re not making it easy to sleep, you know."
    new "Tu ne facilites pas le sommeil, tu sais."


    old "Good night, [name]."
    new "Bonne nuit, [name]."


    old "Good night, Gabriella..."
    new "Bonne nuit, Gabriella..."


    old "Long day of squats, sweat, and stretches... Time to give these legs a break. Good night, team. 💤🍑"
    new "Longue journée de squats, de sueur et d'étirements... Il est temps de donner un peu de repos à ces jambes. Bonne nuit, l'équipe. 💤🍑"


    old "Rest mode: activated 😴"
    new "Mode repos : activé 😴"


    old "Nighty night, muscle queen. May your dreams be less sore than your glutes."
    new "Bonne nuit, reine des muscles. Que tes rêves soient moins douloureux que tes fesses."


    old "Wait, you did legs today *and* you’re still standing? Teach me your ways. 😩"
    new "Attends, tu as fait des jambes aujourd’hui *et* tu tiens encore debout ? Apprends-moi tes secrets. 😩"


    old "Pretty sure your legs just bench-pressed my willpower."
    new "Je suis presque sûr que tes jambes viennent de soulever ma volonté."


    old "Sweet dreams, Fanny. Hope tomorrow’s workout is just lifting spoons to your mouth. 🥣😅"
    new "Fais de beaux rêves, Fanny. J'espère que l'entraînement de demain se résumera à lever des cuillères à ta bouche. 🥣😅"


    old "You work hard AND say good night like a goddess? That’s just unfair."
    new "Tu travailles dur ET tu dis bonne nuit comme une déesse ? C’est pas juste."


    old "Brb going to the gym so I can sleep like Fanny tonight."
    new "Je reviens, je vais à la salle de sport pour pouvoir dormir comme Fanny ce soir."


    old "You inspire me... but my couch says no."
    new "Tu m’inspires... mais mon canapé dit non."


    old "She looks so happy with you! Glad she had you by her side today.."
    new "Elle a l'air tellement heureuse avec toi ! Heureux qu'elle t'ait eu à ses côtés aujourd'hui.."


    old "Nice climb. Thought you’d need Grace to carry you up."
    new "Belle ascension. Je pensais que tu aurais besoin de Grace pour te porter."


    old "Sofia..."
    new "Sofia..."


    old "Just wanted to check in on you."
    new "Je voulais juste m'assurer que tu vas bien."


    old "It’s been a wild day. You okay?"
    new "Ça a été une journée folle. Ça va ?"


    old "Mmm... you thinking about me in bed, or just being sweet? 😉"
    new "Mmm... tu penses à moi dans ton lit, ou tu es juste mignon ? 😉"


    old "Can’t it be both?"
    new "Pourquoi pas les deux ?"


    old "Flirt."
    new "Flirt."


    old "I’m okay. Tired... but I'm glad you messaged me."
    new "Ça va. Fatiguée... mais contente que tu m’aies envoyé un message."


    old "I wish I could be with you right now."
    new "J’aimerais être avec toi en ce moment."


    old "Maybe next time I won’t let you leave so easily."
    new "Peut-être que la prochaine fois, je ne te laisserai pas partir aussi facilement."


    old "Looking forward to it."
    new "J'ai hâte."


    old "Sweet dreams, [name]. Don’t do anything I wouldn’t dream about."
    new "Fais de beaux rêves, [name]. Ne fais rien que je ne rêverais pas."


    old "Good night, Sofia."
    new "Bonne nuit, Sofia."


translate french e5s4_8a1461c3:


    ji "Mademoiselle Carter ?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
