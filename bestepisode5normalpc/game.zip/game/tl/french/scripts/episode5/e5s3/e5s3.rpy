

translate french e5s3_396d0192:

    dpense "Et... toujours aucune réponse..."


translate french e5s3_e3f5663e:

    dpense "Bon... je crois que je n’ai pas le choix."


translate french e5s3_e5c4ad3e:

    dpense "Peut-être que j’aurai enfin des réponses à tout ça..."


translate french e5s3_4ffc23de:

    dpense "Ce bâtiment fait peur."


translate french e5s3_382711d6:

    dpense "Qu’est-ce que c’est... ?"


translate french e5s3_f75c3263:

    ji "Bienvenue, [name]."


translate french e5s3_7d80e01f:

    ji "Tu peux t’asseoir ici."


translate french e5s3_4446e157:

    d "Je peux avoir ton nom ?"


translate french e5s3_d5a593df:

    ji "Tu n’as pas besoin de mon nom, mais... si tu insistes, tu peux m’appeler Marc."


translate french e5s3_28144102:

    d "D’accord…"


translate french e5s3_cfd044c8:

    marc "Alors... [name]. Je suis sûr que tu as beaucoup de questions et que tu attends des réponses."


translate french e5s3_70a2a024:

    marc "Mais soyons clairs. Je ne suis pas là pour y répondre. Pas directement."


translate french e5s3_a6d898e9:

    d "Quoi ? Alors pourquoi suis-je ici ?"


translate french e5s3_2314e146:

    marc "Parce que tu dois comprendre où tu mets les pieds… et parce que certaines personnes ont plaidé en ta faveur pour que tu reçoives un petit coup de main."


translate french e5s3_6555aa00:

    d "De l’aide ? Pourquoi aurais-je besoin d’aide ?"


translate french e5s3_59e124c3:

    marc "Encore une question inutile."


translate french e5s3_8180340e:

    marc "Tu n’es pas d’ici. Tu ne connais personne. On t’a jeté dans une compétition qui pourrait changer ta vie…"


translate french e5s3_d8fbc473:

    marc "Et tu me demandes pourquoi tu aurais besoin d’aide ?"


translate french e5s3_caf27d63:

    d "Je…"


translate french e5s3_8368f671:

    marc "Ne gaspille pas ta salive. Écoute attentivement à la place."


translate french e5s3_1b4ce3bd:

    marc "Quelqu’un pense que tu mérites une chance de comprendre le tableau d’ensemble avant d’y perdre pied."


translate french e5s3_98e83cac:

    marc "Dis-moi, [name]... que sais-tu vraiment du B.E.S.T ?"


translate french e5s3_18ba1390:

    d "C’est une compétition entre étudiants pour obtenir un bon poste chez Orushi Corp."


translate french e5s3_fac19c04:

    marc "Faux."


translate french e5s3_dd5d68f3:

    d "Hein ?"


translate french e5s3_c726c09d:

    marc "C’est ce qu’on t’a dit. Mais ce n’est pas du tout le véritable objectif."


translate french e5s3_389980e0:

    d "Alors c’est quoi ?"


translate french e5s3_3f2205d5:

    marc "Tu commences à poser de meilleures questions."


translate french e5s3_4d4d3497:

    d "C’est une loterie. 100 étudiants choisis au hasard pour concourir pour un seul poste."


translate french e5s3_7d6733b2:

    marc "Le hasard, ça n’existe pas, [name]."


translate french e5s3_2c3a63c7:

    d "Qu’est-ce que tu veux dire ?"


translate french e5s3_0d77b1b7:

    marc "Tu commences à comprendre. Continue."


translate french e5s3_e406ae20:

    d "C’est juste un divertissement pour un riche type qui veut voir des gens se battre pour son plaisir."


translate french e5s3_6453588e:

    marc "Pas loin de la vérité… mais tu passes quand même à côté de l’essentiel."


translate french e5s3_9010a74c:

    marc "Orushi n’est pas le vrai public ici."


translate french e5s3_55c9c860:

    d "Alors qui est-ce ?"


translate french e5s3_7ef99dd5:

    marc "Pose les bonnes questions, et je t’expliquerai."


translate french bestexplanation_715ebbc3:

    marc "Tu te souviens des gladiateurs de l’Empire romain ?"


translate french bestexplanation_aa785934:

    d "Hmm… oui."


translate french bestexplanation_08235dd6:

    marc "De grandes arènes, des foules rugissantes, des hommes qui affrontent des bêtes ou s’entre-tuent. Le spectacle dans toute sa splendeur."


translate french bestexplanation_3be96c82:

    marc "Mais dis-moi… qui payait pour tout ça ?"


translate french bestexplanation_1603dd57:

    d "L’empereur ?"


translate french bestexplanation_4615bff6:

    marc "Non. Sa richesse n’était pas infinie, malgré ce que les gens aimaient croire."


translate french bestexplanation_e99a02c7:

    d "Alors… l’Empire ?"


translate french bestexplanation_98b4de85:

    marc "Avec le coût des guerres constantes ? Peu probable. Tu ne vois toujours pas."


translate french bestexplanation_025df574:

    dpense "Où veut-il en venir… ?"


translate french bestexplanation_c663583e:

    marc "C’étaient les familles riches, les marchands, les élites puissantes. Ils finançaient les jeux, pas par charité… mais pour garder le contrôle."


translate french bestexplanation_59092df7:

    marc "Une population affamée et en colère est dangereuse. Mais donne-leur du pain… et des jeux, et ils oublieront leur misère."


translate french bestexplanation_58bd80c4:

    marc "Des héros à acclamer. Du sang pour étancher leur frustration. Des rêves de gloire pour les détourner de leurs chaînes."


translate french bestexplanation_0bcc902d:

    marc "Et maintenant, regarde autour de toi. Qu’est-ce que le B.E.S.T, sinon l’arène moderne ?"


translate french bestexplanation_0d141fe1:

    marc "À travers l’histoire, les gens ont ressenti l’existence d’une main cachée à l’œuvre."


translate french bestexplanation_eeaf8592:

    marc "Mais comme ils ne pouvaient pas la voir, ils lui ont donné des noms..."


translate french bestexplanation_3eef63f3:

    marc "Légendes. Mythes. Théories du complot."


translate french bestexplanation_274c8110:

    marc "Les Illuminati. Les Francs-Maçons. Les Templiers."


translate french bestexplanation_682c07e5:

    marc "Et aujourd’hui ? Le groupe Bilderberg, l’État profond, les soi-disant élites mondiales."


translate french bestexplanation_713e4e20:

    marc "Pendant des siècles, il suffisait de contrôler l’information. Décider quelles vérités devaient être racontées… et lesquelles devaient être enterrées."


translate french bestexplanation_7d652284:

    marc "Mais les temps ont changé. L’information circule trop vite maintenant."


translate french bestexplanation_017f95a9:

    marc "Une rumeur, un scandale, une vidéo virale… et des nations entières peuvent s’embraser avant même qu’on ait le temps de réagir."


translate french bestexplanation_b850f3b5:

    marc "Prenons un exemple récent... Tu crois vraiment que c’est un hasard si la télé-réalité a explosé au moment de la dernière grande crise économique ?"


translate french bestexplanation_1619c3d4:

    marc "Des millions de personnes perdaient leur emploi, leur maison, leur avenir..."


translate french bestexplanation_e988bc62:

    marc "Et qu’est-ce qu’ils retrouvaient chaque soir en rentrant chez eux ?"


translate french bestexplanation_833bb17c:

    marc "Des émissions sur la célébrité instantanée, l’argent facile, et des vies de luxe totalement inaccessibles."


translate french bestexplanation_23c827d5:

    marc "Les garder dans le rêve. Les garder distraits. Pendant que leur vraie vie s’effondrait, ils étaient trop occupés à regarder d’autres faire semblant de vivre parfaitement."


translate french bestexplanation_87ca8bf2:

    marc "Et quand les écrans de leur salon ne suffisaient plus... on a glissé le cirque directement dans leur poche."


translate french bestexplanation_84a021c4:

    marc "Les réseaux sociaux ont pris le relais. Défilement sans fin, indignation sans fin, shoots de dopamine sans fin."


translate french bestexplanation_a0e52b4b:

    marc "Une indignation perpétuelle pour les distraire, pendant que les vraies décisions concernant leur vie se prenaient en secret."


translate french bestexplanation_a5dcf4d8:

    marc "Du pain et des jeux, [name]. C’est tout ce qu’il faut. Des écrans plus petits. Le même jeu."


translate french bestexplanation_9d4ddd03:

    marc "Le contrôle ne passe plus par des chaînes. Il passe par ce qui capte leur attention. Et celui qui contrôle ça... contrôle tout."


translate french bestexplanation_bd71ec79:

    marc "Mais cette fois, c’est encore plus efficace. Pourquoi contrôler l’information quand on peut devenir l’information ?"


translate french bestexplanation_2e24d673:

    marc "Dans un monde où les nouvelles vont plus vite que la vérité, quoi de mieux pour façonner la réalité que de faire de ton jeu le centre de tout ?"


translate french bestexplanation_c0e48e60:

    marc "Alors que les gens devraient s’inquiéter pour leur emploi, leur liberté, leur avenir…"


translate french bestexplanation_829eb3a5:

    marc "De quoi parlent-ils à la place ? DE TOI. Tes victoires. Tes échecs. Tes scandales. Ta vie est devenue l’actualité."


translate french bestexplanation_72934bfc:

    marc "Des héros et des méchants, des histoires d’amour et des trahisons… tout parfaitement emballé pour un monde avide de distraction."


translate french bestexplanation_b2f5c003:

    marc "Et le plus beau ? Cette fois, tout est réel. Pas de script. Pas de mensonge. Juste toi… vivant l’histoire qu’ils veulent tous consommer."


translate french bestexplanation_2c94123f:

    marc "Tu ne fais pas que jouer le jeu, [name]. Tu ES le jeu."


translate french bestexplanation_93630f24:

    dpense "C’est… c’est pas possible… Ma vie… un spectacle pour le monde entier ?"


translate french bestexplanation_194eef8f:

    d "Pourquoi moi ? Pourquoi nous ? Qu’est-ce qui nous rend si spéciaux ?"


translate french bestexplanation_18d15a00:

    marc "Ah… la question la plus prévisible de toutes."


translate french bestexplanation_b5dd47e7:

    marc "Tu crois vraiment aux coïncidences, [name] ?"


translate french bestexplanation_6a19f320:

    marc "Chaque participant a été choisi pour une raison. Pas pour ce qu’il est… mais pour ce qu’il représente."


translate french bestexplanation_7032949a:

    d "Alors, quel est mon rôle dans tout ça ? Pourquoi je suis là ?"


translate french bestexplanation_9523f34b:

    marc "Tu es l’inconnu. L’élément imprévisible. La variable qui ne rentre pas dans l’équation."


translate french bestexplanation_e70abc86:

    marc "Tu n’as aucun héritage, aucun nom célèbre, aucune ficelle cachée qui te pousse en avant."


translate french bestexplanation_2816d66d:

    marc "Tu es celui qui ne devrait pas être ici… et pourtant, tu y es."


translate french bestexplanation_c9739e4d:

    marc "Et c’est ce qui te rend dangereux."


translate french bestexplanation_74fe7708:

    marc "Tu portes quelque chose de rare, d’incontrôlable : l’ESPOIR."


translate french bestexplanation_5437e331:

    marc "Pour chaque visage sans nom dans l’ombre, pour chaque âme oubliée à qui on a dit qu’elle ne comptait pas… tu es la preuve qu’ils avaient tort."


translate french bestexplanation_8552631c:

    marc "Tu es le rêve impossible."


translate french bestexplanation_5a38659a:

    marc "Celui qui pourrait gagner..."


translate french bestexplanation_8c10b855:

    marc "...alors que tout était conçu pour que tu échoues."


translate french chooseexplanation_effff65f:

    d "Et Grace ? Pourquoi elle a été choisie ?"


translate french chooseexplanation_5ebdefac:

    marc "Grace est l’image parfaite d’une vie déjà écrite avant même d’avoir commencé."


translate french chooseexplanation_7e280618:

    marc "Fille du Doyen, éduquée, raffinée… son chemin était tracé dès sa naissance."


translate french chooseexplanation_c0f77d45:

    marc "Bien se marier, renforcer les alliances familiales, mener une vie d’obéissance tranquille."


translate french chooseexplanation_6414e87b:

    marc "Mais au fond, elle incarne chaque fille enfermée dans une cage dorée, rêvant de s’échapper."


translate french chooseexplanation_08d8f426:

    marc "Pour le monde, elle est le symbole d’une rébellion silencieuse contre un destin imposé par le sang et le devoir."


translate french chooseexplanation_233ba0a3:

    d "Et Madison ?"


translate french chooseexplanation_5ac0b015:

    marc "Madison est un paradoxe. Une rebelle née dans le pouvoir, une héritière qui refuse de plier devant son propre héritage."


translate french chooseexplanation_a807e804:

    marc "Elle porte le poids du nom de sa famille, mais elle se bat chaque jour pour prouver qu’elle est plus que ça."


translate french chooseexplanation_cf0cd827:

    marc "Et sa fille… sa plus grande faiblesse et sa plus grande force."


translate french chooseexplanation_64a40d1a:

    marc "Elle incarne toutes ces femmes qui essaient de tout concilier : mère, compétitrice, meneuse."


translate french chooseexplanation_8d5ca34a:

    marc "Tandis que le monde regarde… et juge."


translate french chooseexplanation_7b57f102:

    d "Et Ruby ? Pourquoi fait-elle partie de tout ça ?"


translate french chooseexplanation_28231b1f:

    marc "Ruby, c’est le chaos pur… et le charme incarné."


translate french chooseexplanation_4821a228:

    marc "Maligne, aventureuse, toujours en quête de la prochaine montée d’adrénaline, sans aucune peur."


translate french chooseexplanation_44c3d1e8:

    marc "Elle est l’étincelle dans un monde d’ombres, l’aventurière innocente qui ne réalise même pas le poids de l’histoire qu’elle porte."


translate french chooseexplanation_1fa85134:

    marc "Et parfois, [name]… ce sont ceux qui semblent les plus insouciants qui cachent les plus grands secrets."


translate french chooseexplanation_bb64f688:

    marc "Quand ses vérités éclateront… le monde entier aura les yeux rivés sur elle."


translate french chooseexplanation2_1c3079b9:

    d "Et Julia ?"


translate french chooseexplanation2_ae2c4634:

    marc "Julia est l’oubliée. L’intruse."


translate french chooseexplanation2_0fb35fb3:

    marc "La fille à qui on n’a jamais rien donné et qui se bat pour chaque centimètre qu’elle conquiert."


translate french chooseexplanation2_6211ff91:

    marc "Elle est l’espoir des oubliés, le symbole des travailleurs de l’ombre qui servent les puissants mais rêvent de liberté."


translate french chooseexplanation2_69202705:

    marc "Mais souviens-toi, [name]... ceux qui s’élèvent à partir de rien ont parfois des racines plus profondes qu’ils ne le pensent."


translate french chooseexplanation2_859a3502:

    marc "Et quand ces racines refont surface… elles peuvent ébranler les fondations mêmes de ce monde."


translate french chooseexplanation2_3da51ed6:

    d "Et les jumelles ? Pourquoi sont-elles ici ?"


translate french chooseexplanation2_35059758:

    marc "Ah… Sofia et Elisabeth. Deux corps, un lien, mais deux destins totalement opposés."


translate french chooseexplanation2_97175f08:

    marc "Sofia… c’est un oiseau qui découvre le ciel. Insouciante, curieuse, elle poursuit chaque horizon sans la moindre peur."


translate french chooseexplanation2_dcf6707e:

    marc "Elle vit pour l’euphorie de la liberté, insensible au poids des conséquences."


translate french chooseexplanation2_e8c3c973:

    marc "Elle incarne l’innocence et l’émerveillement… et les gens ne peuvent s’empêcher de la suivre là où elle vole."


translate french chooseexplanation2_cba1f8fa:

    marc "Elisabeth est l’exact opposé. Calculatrice. Introspective. Elle ne vagabonde pas au hasard : elle observe, planifie, et attend le moment parfait pour frapper."


translate french chooseexplanation2_c2bdea88:

    marc "Elle est le pouvoir dissimulé derrière un sourire, une lionne en gants de velours. Elle ne chasse pas sa proie… elle s’assure qu’elle vienne à elle."


translate french chooseexplanation2_a856700f:

    marc "À elles deux, elles obligent le monde à se poser la plus vieille des questions : faut-il courir après la liberté… ou s’emparer du pouvoir ?"


translate french chooseexplanation2_bc44d1ad:

    d "Et Kira ?"


translate french chooseexplanation2_d6d6e0c1:

    marc "Kira ne fait pas semblant. Elle ne se cache pas derrière l’innocence ou la retenue."


translate french chooseexplanation2_089cab24:

    marc "Elle sait exactement qui elle est, et de quoi elle est capable."


translate french chooseexplanation2_a8b7567f:

    marc "Là où les autres hésitent, elle agit. Là où les autres suivent les règles, elle les réécrit."


translate french chooseexplanation2_8ca29b9f:

    marc "Elle est le pouvoir dans sa forme la plus pure."


translate french chooseexplanation2_4d999085:

    marc "Non hérité, non donné… mais CONQUIS par la seule force de sa volonté."


translate french chooseexplanation2_bd8c6903:

    marc "Certains l’admirent. D’autres la craignent. Mais personne ne l’ignore."


translate french chooseexplanation2_ee9574b3:

    marc "Quand Kira entre dans une pièce, tout le monde sait… que la partie a déjà commencé."


translate french chooseexplanation2_f16412bc:

    d "Stop… Je ne veux plus entendre ça."


translate french chooseexplanation2_01dfbcae:

    marc "Que tu veuilles l’entendre ou non ne change rien à la réalité, [name]."


translate french chooseexplanation2_5f87c28e:

    marc "Tu fais déjà partie du spectacle. La seule question qui reste, c’est… COMMENT vas-tu jouer ?"


translate french endexplanation_abf69470:

    marc "Une dernière chose, [name]."


translate french endexplanation_b846e833:

    marc "La différence entre un joueur… et un pion sur l’échiquier…"


translate french endexplanation_fa02ec0d:

    marc "C’est de savoir quand on te déplace… et quand c’est à toi de jouer."


translate french endexplanation_a29e294e:

    marc "La plupart des gens vivent toute leur vie sans jamais savoir lequel ils sont."


translate french endexplanation_a3d9b648:

    marc "Ne fais pas la même erreur."


translate french endexplanation_91760533:

    dpense "J’ai quitté cet endroit avec plus de questions que de réponses… mais une chose était sûre."


translate french endexplanation_e182c802:

    dpense "Rien de tout ça n’était un jeu, plus maintenant."


translate french endexplanation_d92e8b06:

    dpense "Et pourtant… je jouais déjà."


translate french endexplanation_bc0637c8:

    dpense "Tiens ? Un appel de Julia ?"


translate french endexplanation_139a594e:

    d "Julia ? Tout va bien ?"


translate french endexplanation_638653d2:

    julia "[name]..."


translate french endexplanation_3e7f2b81:

    julia "C’est ma mère..."


translate french endexplanation_52ef2f00:

    julia "Elle…"


translate french endexplanation_f234fa5f:

    julia "C’est fini…"

translate french strings:


    old "Come to 21st Upper Street in an hour."
    new "Rends-toi au 21st Upper Street dans une heure."


    old "Huh? Why?"
    new "Hein ? Pourquoi ?"


    old "Stop asking questions and just do it."
    new "Arrête de poser des questions et fais-le."


    old "And if I don’t want to?"
    new "Et si j’en ai pas envie ?"


    old "It’s a competition"
    new "C’est une compétition"


    old "It’s a lottery"
    new "C’est une loterie"


    old "It’s entertainment"
    new "C’est du divertissement"


    old "Grace?"
    new "Grace ?"


    old "Madison?"
    new "Madison ?"


    old "Ruby?"
    new "Ruby ?"


    old "More..."
    new "Encore..."


    old "Julia?"
    new "Julia ?"


    old "The Twins?"
    new "Les jumelles ?"


    old "Why Kira?"
    new "Pourquoi Kira ?"


    old "Enough. I don’t want to hear more."
    new "Ça suffit. Je ne veux plus en entendre."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
