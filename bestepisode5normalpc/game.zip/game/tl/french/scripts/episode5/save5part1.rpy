


translate french save5part1_285f8ea7:


    "Veuillez sauvegarder votre partie ici..."


translate french save5part1_f029d6e4:


    "Toutes mes condoléances."


translate french save5part1_c3393239:


    orushi "En raison des événements récents, je pense qu’il est temps pour les duels !"


translate french save5part1_fcba8ba6:


    mad "Je vais entrer dans la tour d’Orushi et découvrir ce qui s’y passe !!!"


translate french save5part1_80081324:


    orushi "Le premier duel sera [name]..."


translate french save5part1_c1c27e01:


    orushi "contre Grace !"

translate french strings:


    old "To all the beloved mothers in this world"
    new "À toutes les mères que l'on aime dans ce monde"


    old "Cherish them while they're still there"
    new "Chérissez-les tant qu'elles sont encore là"


    old "To Mom, 1963-2025"
    new "À maman, 1963-2025"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
