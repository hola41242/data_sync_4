


translate french e5s6_3fb2abb2:


    orushi "Mes chers candidats..."


translate french e5s6_ff4534d8:


    orushi "Vous êtes encore vingt."


translate french e5s6_6b430812:


    orushi "Vingt vies. Vingt parcours. Vingt histoires entremêlées."


translate french e5s6_d91dcc73:


    orushi "Mais aujourd'hui... seuls quelques-uns continueront."


translate french e5s6_266e4fc3:


    orushi "Devant chacun de vous se trouve une boîte scellée."


translate french e5s6_b65d1e21:


    orushi "Certaines de ces boîtes contiennent un jeton de sélection."


translate french e5s6_998449ef:


    orushi "D’autres sont vides."


translate french e5s6_ea1631bc:


    orushi "Je ne vous dirai pas combien de jetons il y a."


translate french e5s6_97ca7c04:


    orushi "Ce que je vous offre, c’est un choix. Un seul."


translate french e5s6_1f277e8c:


    orushi "Chacun de vous aura l’occasion de regarder secrètement à l’intérieur d’une boîte..."


translate french e5s6_0e53d205:


    orushi "...n’importe laquelle, sauf la vôtre."


translate french e5s6_4cc4a23d:


    orushi "Vous ne pouvez le faire qu’une seule fois."


translate french e5s6_381bae70:


    orushi "Ensuite, chacun de vous prendra une décision :"


translate french e5s6_f326ea5b:


    orushi "Garder votre boîte et faire confiance à votre chance,"


translate french e5s6_8b46f9ac:


    orushi "ou échanger votre boîte avec un autre joueur."


translate french e5s6_24201288:


    orushi "Mais souvenez-vous..."


translate french e5s6_1a15c350:


    orushi "Une boîte échangée perd toute certitude."


translate french e5s6_bcb0b2a5:


    orushi "Et une boîte conservée... pourrait n’être qu’un mirage."


translate french e5s6_dea039ff:


    orushi "Réfléchissez bien. Car ceci n’est pas seulement une épreuve de sélection..."


translate french e5s6_89c37bde:


    orushi "C’est le reflet de tout ce que vous avez appris depuis votre arrivée ici."


translate french e5s6_4f24f925:


    dpense "Je dois choisir une boîte à vérifier... mais pas la mienne."


translate french e5s6_observation_ac26ecd3:


    dpense "Tout le monde fixe sa boîte... sans vraiment savoir quoi en faire."


translate french e5s6_observation_810d625f:


    dpense "Personne ne sait combien de jetons il y a."

translate french e5s6_observation_27801cb9:


    dpense "On dirait qu’ils essaient tous de trouver une règle cachée derrière tout ça."


translate french e5s6_observation_e657325b:


    mad "Alors... on est censés regarder une boîte pour nous aider à décider ?"


translate french e5s6_observation_75b7e148:


    s "Ou peut-être que c’est juste pour nous embrouiller. Ça pourrait être un piège total..."


translate french e5s6_observation_f72e8743:


    grace "Je n’aime pas ça. Trop vague. On dirait qu’on se moque de nous."


translate french e5s6_observation_5d544f10:


    dpense "Ruby ne dit rien."


translate french e5s6_observation_38f0c86d:


    dpense "Elle observe. Comme toujours."


translate french e5s6_observation_4fc8cc42:


    ruby "Tout est une question de perception. Ce n’est pas un casse-tête logique cette fois."


translate french e5s6_observation_538ff4e2:


    ruby "La vraie question, ce n’est pas ce qu’on voit. C’est ce que les autres pensent avoir vu."


translate french e5s6_observation_fcd6c3eb:


    dpense "Elle a raison. Mais je peux voir qu’elle réfléchit plus loin que ça..."


translate french e5s6_observation_3c9bb22b:


    ruby "Tu as choisi une boîte à vérifier ?"


translate french e5s6_observation_3f2cdd4d:


    d "Pas encore. Je veux récolter les infos les plus utiles."


translate french e5s6_observation_4057739d:


    ruby "Pareil. Si on combine ce qu’on voit avec ce que font les autres, on pourra peut-être repérer un schéma."


translate french e5s6_observation_437737f7:


    d "Comme une logique comportementale ? Instinct contre raisonnement ?"


translate french e5s6_observation_27bf0648:


    ruby "Exactement. Ce n’est pas la boîte qui compte. C’est ce qu’ils croient qu’il y a dedans... et ce qu’ils feront ensuite."


translate french e5s6_observation_a57c028f:


    dpense "Là, mon cerveau se met en marche. Je comprends ce qu’elle vise."


translate french e5s6_observation_6957997a:


    d "Alors on fait équipe. Discrètement."


translate french e5s6_observation_b196b7bf:


    ruby "Discrètement."


translate french e5s6_observation_5a3b9d43:


    d "Et ceux qu’on ne connaît pas ?"


translate french e5s6_observation_e50286b8:


    ruby "On ne les connaît pas. On ne peut pas se fier à leurs actions car on ne sait pas comment ils fonctionnent..."


translate french e5s6_observation_2095c829:


    ruby "On ne sait pas combien seront qualifiés à la fin donc..."


translate french e5s6_observation_e0ba5112:


    ruby "Autant les ignorer pour rester simple."


translate french e5s6_observation_ed6d2f04:


    ruby "On doit rester concentrés. On n’a pas beaucoup d’infos, mais ceux qui agissent trop vite... ce sont eux qui vont se planter."


translate french e5s6_observation_294017f1:


    dpense "Elle a ce ton calme et analytique que je commence à bien connaître. Elle a déjà un plan."


translate french e5s6_observation_5a3b9d43_1:


    d "Et ceux qu’on ne connaît pas ?"


translate french e5s6_observation_e50286b8_1:


    ruby "On ne les connaît pas. On ne peut pas se fier à leurs actions car on ne sait pas comment ils fonctionnent..."


translate french e5s6_observation_2095c829_1:


    ruby "On ne sait pas combien seront qualifiés à la fin donc..."


translate french e5s6_observation_47cd4a00:


    ruby "autant les ignorer pour rester simple."

translate french e5s6_observation_9badd16e:


    dpense "Tout le monde observe. Évalue. Calcule."


translate french e5s6_observation_eaf92f49:


    dpense "Ruby est plongée dans ses pensées. Ses yeux balaient la salle, puis se posent sur moi."


translate french e5s6_observation_a9a53a3f:


    ruby "Tu remarques comme certains tiennent leur boîte fermement, même sans l’avoir ouverte ?"


translate french e5s6_observation_f2d439ff:


    d "Peut-être qu’ils jouent la sécurité. Ou qu’ils bluffent."


translate french e5s6_observation_68d0c586:


    ruby "Ou qu’ils essaient de faire croire aux autres qu’ils savent déjà quoi faire."


translate french e5s6_observation_f4e1452b:


    d "Donc, un bluff."


translate french e5s6_observation_4132040c:


    ruby "Ou un excès de confiance. Mais c’est dans les premiers coups que se font les erreurs les plus bêtes."


translate french e5s6_observation_71bf35f5:


    dpense "Je surprends un léger sourire sur ses lèvres. Elle décode les comportements. Moi aussi."


translate french e5s6_observation_5bd18ff2:


    ruby "Qu’est-ce que tu penses de la posture de Steven ?"


translate french e5s6_observation_3ded11ad:


    d "Soit il a peur de faire le mauvais choix, soit il attend que quelqu’un bouge en premier."


translate french e5s6_observation_8f485c95:


    ruby "C’est aussi ce que je me dis..."


translate french e5s6_observation_e915c292:


    dpense "On ne parle pas beaucoup. Mais on s’observe. On réfléchit. Ensemble."


translate french e5s6_observation_13770013:


    emerick "Vous vous foutez de moi ?!"


translate french e5s6_observation_ef379675:


    emerick "Ils chuchotent depuis cinq minutes et personne ne dit rien ?!"


translate french e5s6_observation_0c8161c2:


    emerick "C’est un putain de test et vous les laissez mijoter un petit plan romantique ou je ne sais quoi ?!"


translate french e5s6_observation_750b2f38:


    ruby "C’est toi qui cries, Emerick. Peur de perdre ou quoi ?"


translate french e5s6_observation_211ec9af:


    emerick "Au moins, moi je triche pas ! Je joue en SOLO. Comme on est censés le faire !"


translate french e5s6_observation_37ba782e:


    dpense "Il perd les pédales, mais au fond je crois qu’il perd surtout le contrôle."


translate french e5s6_observation_de527c80:


    orushi "Assez."


translate french e5s6_observation_2dfe950f:


    orushi "Joueur Emerick, soyez rassuré : j’entends et je vois tout."


translate french e5s6_observation_c89c0bc6:


    orushi "Et croyez-moi : je saurai exactement qui mérite d’avancer."


translate french e5s6_observation_5cc5d10c:


    orushi "Je n’ai jamais interdit aux candidats de se parler."


translate french e5s6_observation_ae49718d:


    orushi "Ce qui est interdit, c’est de partager des informations sur le contenu des boîtes : celles qu’ils ont ouvertes ou celles qu’ils ont vérifiées."


translate french e5s6_observation_db73bb00:


    orushi "Mais parler stratégie, impressions ou comportement ?"


translate french e5s6_observation_4d64c97d:


    orushi "Non seulement c’est autorisé... mais c’est révélateur."

translate french e5s6_observation_72e35eab:


    orushi "Et je vous rappelle que c’est une épreuve individuelle."


translate french e5s6_observation_e1efcdb2:


    orushi "Vous pouvez parler autant que vous le voulez, mais n’espérez pas être sauvés ensemble."


translate french e5s6_observation_c1150fb8:


    orushi "Certains parleront, d’autres mentiront. Et parfois... tout le monde perd."


translate french e5s6_observation_3787fbaf:


    orushi "Puisque vous semblez si impatient de donner le ton, Emerick..."


translate french e5s6_observation_96383100:


    orushi "Vous commencerez."


translate french e5s6_observation_b9c2f3ff:


    emerick "Enfin."


translate french e5s6_observation_6b3e59a8:


    emerick "Je vais vérifier..."


translate french e5s6_observation_3b1c981c:


    emerick "La boîte de Ruby."


translate french e5s6_observation_ee17831d:


    dpense "Il la provoque."


translate french e5s6_observation_ea3dd448:


    emerick "Mhhhh. Fascinant."


translate french e5s6_observation_d2c80a33:


    dpense "Il laisse volontairement planer le doute. Il ne peut pas s’en empêcher."


translate french e5s6_observation_599e0fed:


    orushi "Joueuse Madison. À vous."


translate french e5s6_observation_bb118b62:


    mad "Très bien, j’y vais."


translate french e5s6_observation_ea76f770:


    dpense "Je peux sentir sa tension."


translate french e5s6_observation_1965421c:


    ruby "Elle est sur les nerfs. Trop tendue pour risquer un bluff."


translate french e5s6_observation_bfd462c5:


    ruby "Elle va vérifier la boîte de quelqu’un d’autre pour se rassurer."


translate french e5s6_observation_58193e62:


    mad "Je vais... vérifier une boîte. Celle de Steven."


translate french e5s6_observation_da7e21f9:


    dpense "Elle s’avance prudemment vers le pupitre de Steven, soulève légèrement la boîte, puis la repose aussitôt."


translate french e5s6_observation_0a716f94:


    dpense "Pas un mot. Même pas un regard vers lui."


translate french e5s6_observation_413b4e4d:


    orushi "Joueur Steven. À vous."


translate french e5s6_observation_fe589a7d:


    dpense "Il n’aime pas perdre de temps."


translate french e5s6_observation_0af6d3e4:


    dpense "Il fait le tour du cercle et s’arrête devant le pupitre de Madison."


translate french e5s6_observation_ab0d797a:


    d "Il va vérifier sa boîte ?"


translate french e5s6_observation_5529a69b:


    ruby "C’est une forme de représailles. Selon ce qu’elle fera avec sa boîte, il veut recouper les infos."


translate french e5s6_observation_39cc181d:


    ruby "Il a l’avantage de choisir après elle."


translate french e5s6_observation_59acf03b:


    dpense "Steven soulève lentement le couvercle... puis le referme tout aussi vite."

translate french e5s6_observation_270d2683:


    dpense "Pas un mot. Pas un regard. Il retourne à sa place."


translate french e5s6_observation_73397bdd:


    s "C’est tout ce qu’il me faut."


translate french e5s6_observation_0dfaa844:


    ruby "Il bluffe. Ou alors il est sûr de sa lecture."


translate french e5s6_observation_92239153:


    d "Ou peut-être qu’il veut juste perturber Madison."


translate french e5s6_observation_f61ca382:


    orushi "Joueuse Sofia. À vous."


translate french e5s6_observation_2eff792a:


    dpense "Blue s’avance calmement. Aucun signe de stress."


translate french e5s6_observation_c1e009d5:


    dpense "Elle entre dans le cercle, ses yeux balayant lentement chaque pupitre."


translate french e5s6_observation_7ecb088b:


    dpense "Puis elle s’arrête devant le mien."


translate french e5s6_observation_c407ce85:


    ruby "Oh."


translate french e5s6_observation_d08b77f3:


    d "Elle va... vérifier ma boîte ?"


translate french e5s6_observation_c2a8c7bc:


    dpense "Elle se penche en avant. Soulève lentement le couvercle..."


translate french e5s6_observation_ef7b11e8:


    dpense "...puis le referme, sans un mot."


translate french e5s6_observation_371e844a:


    dpense "Elle ne dit rien. Mais pendant une demi-seconde, ses yeux croisent les miens."


translate french e5s6_observation_340770b4:


    dpense "Elle me sourit. Subtilement. Légèrement. Mais il est bien là."


translate french e5s6_observation_a4022d3c:


    ruby "Tu crois que c’est un message ?"


translate french e5s6_observation_62a604ab:


    d "Aucune idée. Elle est toujours difficile à lire."


translate french e5s6_observation_6d29929a:


    ruby "Ou peut-être qu’elle veut que tu comprennes sans rien dire."


translate french e5s6_observation_a51faf27:


    dpense "Elle retourne à sa place, toujours aussi calme."


translate french e5s6_observation_c790e247:


    orushi "Joueur Hector. À vous."


translate french e5s6_observation_7f24b98b:


    dpense "Il ricane en regardant autour de lui."


translate french e5s6_observation_f5d54b81:


    hec "Bon... faut bien jouer le jeu."


translate french e5s6_observation_ec149967:


    dpense "Il traverse le cercle tranquillement, en prenant son temps."


translate french e5s6_observation_a90e38aa:


    dpense "Il s’arrête devant le pupitre de Julia."


translate french e5s6_observation_0c545453:


    d "Il va vérifier sa boîte ?"

translate french e5s6_observation_82db18bb:


    ruby "Peut-être qu’il veut la déstabiliser. Ou juste lui rappeler qu’il la surveille."


translate french e5s6_observation_0ef07917:


    dpense "Il soulève le couvercle, prend un instant pour regarder, puis le referme avec désinvolture."


translate french e5s6_observation_31cf088f:


    dpense "Puis il repart avec un sourire narquois sur le visage."


translate french e5s6_observation_5e717452:


    hec "Intéressant..."


translate french e5s6_observation_fd6f595a:


    dpense "Julia ne bronche pas."


translate french e5s6_observation_e827eecb:


    dpense "Mais elle garde les yeux rivés sur lui."


translate french e5s6_observation_e8667989:


    orushi "Joueuse Kira. À vous."


translate french e5s6_observation_048b202a:


    dpense "Kira est silencieuse. Son visage, comme toujours, est impassible."


translate french e5s6_observation_96962f07:


    dpense "Elle ne regarde pas Emerick. Ne me regarde pas non plus. Elle se dirige vers Ben."


translate french e5s6_observation_125f4494:


    ruby "Classique. Une cible facile."


translate french e5s6_observation_7ce813bd:


    d "Tu crois qu’elle joue la sécurité ?"


translate french e5s6_observation_6702fa5c:


    ruby "Ou alors elle sait exactement ce qu’elle fait."


translate french e5s6_observation_dc7ec2e7:


    dpense "Kira se penche, ouvre la boîte de Ben, l’examine calmement..."


translate french e5s6_observation_92f236ad:


    dpense "Puis la referme d’un seul geste net."


translate french e5s6_observation_dab9380a:


    dpense "Pas la moindre émotion sur son visage. Elle retourne à sa place sans un mot."


translate french e5s6_observation_f77cc5d4:


    orushi "Joueur Mac. À vous."


translate french e5s6_observation_99fb4c28:


    dpense "Mac jette un coup d’œil autour de lui, l’air un peu ailleurs."


translate french e5s6_observation_b75228ec:


    mac "D’accord… restons simple."


translate french e5s6_observation_7152bc37:


    dpense "Il se dirige vers le pupitre de Ben et jette rapidement un coup d’œil à l’intérieur."


translate french e5s6_observation_85d5655c:


    dpense "Puis retourne à sa place sans rien dire."


translate french e5s6_observation_86216c3d:


    ruby "Il doit sûrement penser que Ben est trop idiot pour garder un jeton."


translate french e5s6_observation_15df2888:


    d "Ou trop idiot pour même savoir ce qu’il a vu."


translate french e5s6_observation_5a13be4e:


    orushi "Joueur Ben. À vous."


translate french e5s6_observation_028daeab:


    dpense "Ben regarde Mac, puis affiche un sourire idiot."


translate french e5s6_observation_a6cd2453:


    ben "Pareil, frérot."


translate french e5s6_observation_1ca31caf:


    dpense "Il va directement à la boîte de Mac et y jette un œil comme si c’était une blague entre eux."


translate french e5s6_observation_da8b37ca:


    dpense "Il retourne à sa place, visiblement content de lui, même si personne ne sait pourquoi."

translate french e5s6_observation_ea8cbfb9:


    ruby "Impasse."


translate french e5s6_observation_040a0511:


    d "Zéro cerveau, fausse alliance."


translate french e5s6_observation_c48f2526:


    orushi "Joueuse Elizabeth. À vous."


translate french e5s6_observation_68cfe16d:


    dpense "Red se replace sans un mot. Toujours avec ce calme glacé... mais tout chez elle semble calculé."


translate french e5s6_observation_0d9ef439:


    dpense "Elle tourne lentement la tête vers Hector. Son choix en surprend plus d’un."


translate french e5s6_observation_b961d1e8:


    beth "Je vais vérifier la boîte d’Hector."


translate french e5s6_observation_645e996e:


    dpense "Elle avance calmement, soulève le couvercle, vérifie le contenu sans montrer la moindre émotion, puis retourne à sa place."


translate french e5s6_observation_a02b9a4f:


    ruby "Hector ? Elle attaque son propre groupe ?"


translate french e5s6_observation_332b3b1b:


    d "C’est risqué..."


translate french e5s6_observation_3c12f12d:


    ruby "Ou brillant. Frapper l’un des pions d’Emerick pour affaiblir la structure sans engager un combat direct."


translate french e5s6_observation_775d2b2b:


    ruby "Ce que je ne comprends pas, c’est... pourquoi ?"


translate french e5s6_observation_6bfc2d3e:


    dpense "Red frappe sans bruit... mais chaque coup est parfaitement placé."


translate french e5s6_observation_5fc4ea0c:


    dpense "Elle fixe Grace pendant un long moment — presque comme si elle la méprisait."


translate french e5s6_observation_a6eb1408:


    beth "Je vais jeter un œil à la boîte de Grace."


translate french e5s6_observation_3451a2af:


    dpense "Elle s’avance, regarde dans la boîte de Grace, puis repart sans dire un mot."


translate french e5s6_observation_efd26043:


    ruby "Elle cible Grace..."


translate french e5s6_observation_22cc5438:


    dpense "Red ne montre jamais ses cartes. Elle joue en solo, à sa manière. Et parfois, c’est tout ce qu’il faut."


translate french e5s6_observation_815d5c0f:


    orushi "Joueuse Julia. À vous."


translate french e5s6_observation_250197d6:


    dpense "Ses yeux balayent la pièce comme si elle essayait de lire les pensées de chacun."


translate french e5s6_observation_5f263a93:


    dpense "Pas de précipitation. Elle avance, concentrée."


translate french e5s6_observation_957f3dc7:


    julia "Je vais vérifier la boîte de Ben."


translate french e5s6_observation_4b1a57a5:


    dpense "Elle jette un rapide coup d’œil, referme doucement la boîte et retourne à sa place."


translate french e5s6_observation_5551f768:


    ruby "Intéressant."


translate french e5s6_observation_9a9172ac:


    d "Tu t’attendais à ce qu’elle choisisse Ben ?"


translate french e5s6_observation_ad3c63ea:


    ruby "Il est discret. Se fond dans le décor. Exactement le genre de personne qu’on ignore. Ce qui en fait une source d’informations parfaite."


translate french e5s6_observation_f2362b94:


    ruby "Et puisque Ben a regardé Mac, elle suit peut-être une chaîne. Elle obtient une vision plus large que les autres."


translate french e5s6_observation_bab9be02:


    dpense "Julia est toujours calme… mais elle sait exactement où elle met les pieds."


translate french e5s6_observation_37d8e615:


    orushi "Joueuse Ruby. À vous."


translate french e5s6_observation_bdaa9598:


    dpense "Ruby reste immobile un instant. Comme si elle calculait une dernière variable avant de bouger."


translate french e5s6_observation_87fb0482:


    d "Tu sais déjà qui tu vas choisir ?"


translate french e5s6_observation_84766a69:


    ruby "Presque. Je veux juste vérifier quelque chose."


translate french e5s6_observation_5910b51b:


    d "Tu penses à Kira ?"


translate french e5s6_observation_677385f2:


    ruby "Elle a regardé Ben. Le choix le plus sûr possible dans la pièce."


translate french e5s6_observation_090f49ec:


    d "Tu veux comprendre pourquoi elle l’a choisi ?"


translate french e5s6_observation_f0c09d26:


    ruby "Peut-être. Avec Kira… même les gestes simples peuvent faire partie de quelque chose de plus profond."


translate french e5s6_observation_a83de9ab:


    dpense "Elle se lève sans un mot et se dirige vers le pupitre de Kira."


translate french e5s6_observation_94cb22f1:


    dpense "Elle ouvre la boîte avec précaution, l’observe longuement, puis la referme."


translate french e5s6_observation_3b3f1873:


    dpense "Elle ne laisse rien paraître, mais je sais qu’elle grave ces infos dans sa mémoire."


translate french e5s6_observation_6744b0d6:


    ruby "Très bien."


translate french e5s6_observation_ca66aafa:


    dpense "Un seul mot. Ton neutre. Mais je peux dire qu’elle vient de trouver la pièce qui lui manquait."


translate french e5s6_observation_8768f6ed:


    orushi "Joueur [name]. À vous."


translate french e5s6_observation_f05fbf9a:


    dpense "C’est mon tour."


translate french e5s6_observation_44642eca:


    dpense "Un seul coup. Une seule boîte à vérifier. Et pas la mienne."


translate french e5s6_observation_2aef89b8:


    dpense "Je dois faire le bon choix."


translate french e5s6_observation_525eb106:


    ruby "Tu sais ce qu’on cherche. Comportement, connexions, recoupements. Choisis avec ta tête, pas avec ton cœur."


translate french e5s6_observation_d935a521:


    d "Ne t’en fais pas. J’ai retenu la leçon."


translate french observebox_77664c99:


    dpense "Je me lève calmement et m’approche de la boîte de [chosenbox]."


translate french observebox_989aee24:


    dpense "Je soulève doucement le couvercle…"


translate french observebox_2288c22f:


    dpense "...Je regarde attentivement."


translate french observebox_dfc06a98:


    dpense "Puis je la referme. Rien ne doit filtrer."

translate french observebox_f05d166d:


    dpense "J’ai ce qu’il me faut. Pour l’instant."


translate french observebox_c38e4058:


    orushi "Grace. À vous."


translate french observebox_658e3be4:


    ruby "Elle ne perdra pas de temps. Elle ira vers un gars qu’elle juge instable."


translate french observebox_917fb4dc:


    d "Mac, tu crois ?"


translate french observebox_6e20a2d6:


    ruby "Pas beaucoup de cerveau. Et toujours dans l’ombre de Steven ou d’Emerick."


translate french observebox_4226a24e:


    dpense "Elle se dirige directement vers la boîte de Mac."


translate french observebox_3348cbd3:


    dpense "Elle soulève le couvercle, regarde à l’intérieur, puis le referme aussitôt."


translate french observebox_a24f5d94:


    dpense "Pas un mot. Elle retourne à sa place, l’expression fermée."


translate french observebox_866951a7:


    ruby "Elle cherche des infos solides. Et elle ne les partagera pas."


translate french observebox_6b29c0bb:


    d "Elle joue en solo… mais toujours avec un sens de l’honneur."


translate french observebox_16f332a0:


    dpense "Je peux dire qu’elle a vu exactement ce qu’il lui fallait."


translate french observebox_23140c05:


    orushi "Candidats…"


translate french observebox_804938c3:


    orushi "Vous avez tous eu le temps d’observer. D’analyser."


translate french observebox_a0ebc701:


    orushi "Il est maintenant temps de prendre votre décision."


translate french observebox_6b0be950:


    orushi "Chacun de vous jouera à son tour."


translate french observebox_89d8e2cd:


    orushi "Quand votre tour viendra, vous aurez deux options :"


translate french observebox_5edf0a7b:


    orushi "Soit garder la boîte devant vous..."


translate french observebox_63f29e78:


    orushi "Soit échanger deux boîtes visibles."


translate french observebox_9785ac7e:


    orushi "Mais gardez ceci à l’esprit :"


translate french observebox_3227b1eb:


    orushi "Une fois qu’un joueur échange sa boîte avec celle de quelqu’un d’autre, cette boîte devient intouchable pour le prochain tour."


translate french observebox_0c685453:


    orushi "En d’autres termes… vous ne pouvez pas prendre une boîte que quelqu’un vient de prendre au tour précédent."


translate french observebox_77633d3e:


    orushi "Et vous ne pouvez pas non plus reprendre votre propre boîte après un échange."


translate french observebox_42c239e2:


    orushi "Réfléchissez bien. Les apparences sont souvent trompeuses..."


translate french observebox_c3e81c73:


    orushi "Et parfois, une bonne décision peut être ruinée par une seule hésitation."

translate french observebox_bdbce856:


    orushi "Joueur Emerick. À vous."


translate french observebox_b989a26c:


    dpense "C’est au tour d’Emerick. Il se lève avec cette arrogance habituelle, comme une eau de Cologne bon marché qu’il ne quitte jamais."


translate french observebox_b3d683ba:


    dpense "Il balaye le cercle du regard, scrutant chaque visage comme s’il cherchait la moindre faiblesse."


translate french observebox_a987d25e:


    emerick "Très bien… je ne vais pas tourner autour du pot."


translate french observebox_29ada277:


    dpense "Il se dirige vers Madison… puis change de trajectoire à la dernière seconde."


translate french observebox_eede833e:


    dpense "Il marche droit vers Ruby."


translate french observebox_5e506b55:


    dpense "Il s’arrête devant elle avec un sourire suffisant."


translate french observebox_627dc3c7:


    emerick "Voyons si ton calme cache quelque chose d’intéressant."


translate french observebox_c8a399c1:


    dpense "Emerick tend sa boîte à Ruby sans un mot et prend la sienne en échange."


translate french observebox_fc9f6b21:


    dpense "Ruby ne bronche pas. Elle accepte l’échange sans montrer la moindre émotion."


translate french observebox_e9ab0fe7:


    dpense "Mais je sens que quelque chose s’enclenche dans son esprit. Elle analyse déjà."


translate french observebox_cba3c434:


    dpense "Il repart avec la boîte de Ruby comme s’il venait de remporter un duel silencieux."


translate french observebox_599e0fed:


    orushi "Joueuse Madison. À vous."


translate french observebox_c13cba8f:


    dpense "Elle se lance rapidement. Trop rapidement pour quelqu’un qui aurait un plan parfaitement établi."


translate french observebox_6be5b99f:


    dpense "Mais elle ne tremble pas. Elle avance avec la même détermination que toujours dans les épreuves."


translate french observebox_c36c10e6:


    ruby "Elle agit à l’instinct. Mais elle sait que tous les regards sont braqués sur elle."


translate french observebox_e4be989b:


    dpense "Elle jette un regard à Steven, puis à sa propre boîte."


translate french observebox_4e2838a8:


    mad "Je garde la mienne."


translate french observebox_72f07918:


    dpense "C’est un choix audacieux. Presque un défi. Comme si elle prouvait qu’elle n’a besoin de personne."


translate french observebox_ee5fc84f:


    ruby "Fière, impulsive… mais pas imprudente. Elle essaie de garder le contrôle à tout prix."


translate french observebox_412e3851:


    ruby "Mais ça veut aussi dire qu’elle n’a pas aimé ce qu’elle a vu dans la boîte de Steven."


translate french observebox_6d8f6f7f:


    orushi "Joueur Steven. À vous."


translate french observebox_401632f6:


    dpense "Steven est sûr de lui comme toujours."


translate french observebox_83e6273c:


    dpense "Il fixe sa propre boîte un instant… puis tourne la tête vers Madison."


translate french observebox_2236a400:


    d "Tu crois qu’il va… ?"


translate french observebox_413119fd:


    ruby "Il a vu sa boîte. Il sait exactement ce qu’il y a dedans."

translate french observebox_2a6337b9:


    dpense "Il avance sans hésiter. Droit vers elle."


translate french observebox_5a81e0fe:


    s "Désolé, Madison."


translate french observebox_44297608:


    dpense "Il attrape la boîte devant elle et l’échange avec la sienne, sans lui laisser le temps de réagir."


translate french observebox_c0039868:


    mad "Quoi ?!"


translate french observebox_96d59479:


    s "C’est le jeu."


translate french observebox_ade58ffd:


    dpense "Steven s’éloigne avec la boîte de Madison. Sans un regard en arrière."


translate french observebox_57b7099a:


    mad "Merde..."


translate french observebox_94393724:


    dpense "Elle serre la mâchoire. Mais elle encaisse."


translate french observebox_63b20ae4:


    d "Tu crois qu’il bluffe ?"


translate french observebox_211642e4:


    ruby "Non. Il joue en fonction de ce qu’il a vu."


translate french observebox_72229415:


    d "Elle a regardé sa boîte, non ?"


translate french observebox_d2e01c1e:


    ruby "Exactement. Et après ça, elle a décidé de garder la sienne."


translate french observebox_9a8af104:


    ruby "Donc Steven a forcément vu un jeton."


translate french observebox_f61ca382:


    orushi "Joueuse Sofia. À vous."


translate french observebox_31deb386:


    dpense "Blue reste calme. Son regard balaie brièvement la salle, puis se fixe droit devant."


translate french observebox_b936dcd0:


    dpense "Elle marche avec grâce, sans se presser. Chaque pas semble réfléchi."


translate french observebox_729e1a7a:


    dpense "Elle vient vers moi."


translate french observebox_07dcdb93:


    dpense "Sans détour. Sans un regard pour les autres boîtes."


translate french observebox_13e72a78:


    dpense "Elle s’arrête devant mon pupitre. Me regarde une seconde."


translate french observebox_6fcaa1ce:


    sofia "Je garde la mienne..."


translate french observebox_167f365c:


    sofia "...mais je voulais que tu le saches."


translate french observebox_e2ff0077:


    dpense "Sa voix est douce. Presque intime."


translate french observebox_976665f6:


    dpense "Ni un ordre, ni une demande. Une affirmation. Simple et directe."


translate french observebox_3197e801:


    ruby "Elle envoie un message. C’est clair."


translate french observebox_993daf80:


    d "Elle veut que je devine ce qu’elle a vu. Ou ce qu’elle croit avoir vu."

translate french observebox_571c632a:


    dpense "Blue retourne à sa place sans se retourner. Mais ses mots résonnent encore."


translate french observebox_04ba7eb9:


    dpense "Elle marque une pause, incertaine."


translate french observebox_11641847:


    dpense "Puis elle marche vers sa propre boîte."


translate french observebox_ddbe835d:


    dpense "Pas un mot. Pas un regard vers moi. Rien."


translate french observebox_83dc8a5f:


    dpense "Elle pose une main sur son pupitre, ferme les yeux un instant..."


translate french observebox_7e0ec825:


    dpense "Puis elle s’assoit."


translate french observebox_4bc5e1f8:


    ruby "Elle garde la sienne."


translate french observebox_6936d7e2:


    d "Mais elle n’a parlé à personne."


translate french observebox_225e24fb:


    ruby "Ce silence fait peut-être partie de sa stratégie."


translate french observebox_d1f02b5d:


    dpense "Le silence retombe, un peu plus lourd cette fois."


translate french observebox_e2133619:


    dpense "Ruby plisse les yeux. Elle réfléchit. Elle relie les indices."


translate french observebox_b4b02729:


    ruby "Alors…"


translate french observebox_acb63775:


    ruby "Emerick a échangé sa boîte avec la mienne. Un geste assuré."


translate french observebox_40f0e2e3:


    ruby "Madison a regardé celle de Steven. Puis a gardé la sienne."


translate french observebox_ef4a94fe:


    ruby "Steven a vu celle de Madison. Et a échangé."


translate french observebox_270f06e7:


    ruby "Blue a vérifié ta boîte... et a choisi de garder la sienne."


translate french observebox_636083ef:


    ruby "Et maintenant, c’est Hector."


translate french observebox_8c74fffe:


    dpense "Ruby inspire doucement, comme si elle recalculait tout."


translate french observebox_1ad285c6:


    ruby "Il a regardé dans la boîte de Julia. Il sait ce qu’il y a dedans."


translate french observebox_4870c84b:


    ruby "Il a trois options :"


translate french observebox_d098fb47:


    ruby "Soit Julia a un jeton, et il va le prendre."


translate french observebox_89c3fa55:


    ruby "Soit elle n’en a pas, et il pense qu’il vaut mieux garder la sienne."


translate french observebox_dddf5678:


    ruby "Ou… il pense qu’une des boîtes déjà échangées est désormais plus intéressante."


translate french observebox_e4a4650a:


    d "Comme celle que Steven a prise à Madison."

translate french observebox_c31975d7:


    ruby "Exactement. Il pourrait penser qu’il y avait un jeton, et que Steven l’a repéré."


translate french observebox_09f2bc2c:


    ruby "Dans ce cas, s’il échange avec Steven, il obtiendrait l’ancienne boîte de Madison."


translate french observebox_69873bef:


    ruby "Et le jeton à l’intérieur. S’il y en avait un."


translate french observebox_ab5187e7:


    dpense "Mais oserait-il vraiment faire ça ?"


translate french observebox_e1ed004a:


    ruby "C’est Hector. Prendre de gros risques ne lui fait pas peur."


translate french observebox_8ceac7af:


    dpense "Je regarde Hector. C’est à lui de jouer."


translate french observebox_4a1733e2:


    orushi "Joueur Hector. Faites votre choix."


translate french observebox_cf0266c1:


    dpense "Il prend son temps, l’air décontracté."


translate french observebox_c7992f91:


    dpense "Il jette un coup d’œil à Steven, puis à Julia, puis à moi…"


translate french observebox_efa82178:


    dpense "Mais son regard revient toujours vers Julia."


translate french observebox_02979c6a:


    ruby "Logique."


translate french observebox_6963eb50:


    d "Tu penses qu’il va prendre sa boîte ?"


translate french observebox_82e64c6b:


    ruby "Il a déjà regardé à l’intérieur. Il sait ce qu’il y a."


translate french observebox_a76ae010:


    ruby "Et je doute qu’il s’en prenne à Steven. Julia est le choix évident."


translate french observebox_9a3405af:


    dpense "Hector avance les bras croisés, comme pour montrer qu’il maîtrise la situation."


translate french observebox_273de67e:


    hec "Pas besoin de calculs ni de plans. Je prends juste la boîte que je veux."


translate french observebox_8d7868f2:


    dpense "Il pose sa boîte devant Julia. Prend la sienne sans un mot."


translate french observebox_3321e440:


    dpense "Puis il retourne à sa place, visiblement satisfait de lui."


translate french observebox_fb40cf92:


    ruby "Direct. Du Hector tout craché."


translate french observebox_32d8d6b8:


    d "Tu crois qu’il a vu un jeton ?"


translate french observebox_f2806587:


    ruby "S’il ne bluffe pas, alors oui."


translate french observebox_9ddc0e31:


    dpense "Julia ne réagit pas. Mais je vois sa mâchoire se crisper légèrement."


translate french observebox_e8667989:


    orushi "Joueuse Kira. À vous."


translate french observebox_64a10e80:


    dpense "Kira est silencieuse comme toujours."


translate french observebox_642a5ab9:


    dpense "Elle évite tout contact visuel avec qui que ce soit."

translate french observebox_0f16e36c:


    dpense "Pas un mot. Juste un mouvement direct et précis."


translate french observebox_fb184ad6:


    d "Tu penses qu’elle va prendre la boîte de Ben ?"


translate french observebox_089ab758:


    ruby "Elle l’a vérifié. Si elle pense qu’il a un jeton, elle n’hésitera pas."


translate french observebox_2b2e17a9:


    ruby "Mais avec Kira, impossible de savoir avant qu’elle agisse."


translate french observebox_93d9ef9a:


    dpense "Elle s’avance vers Ben. Il la regarde, visiblement confus et un peu anxieux."


translate french observebox_ce69e237:


    dpense "Sans hésiter, elle échange sa boîte avec la sienne."


translate french observebox_3624db6f:


    ben "Euh… d’accord ?"


translate french observebox_912e1fa9:


    dpense "Pas de réponse. Kira retourne à sa place, impassible."


translate french observebox_b3606a65:


    ruby "Elle suit un plan. Et elle sait que Ben ne s’en rendra même pas compte."


translate french observebox_9301699d:


    d "Tu penses qu’elle bluffe ?"


translate french observebox_8740463c:


    ruby "Non. Elle ne bluffe jamais. Elle agit quand elle est sûre d’avoir l’avantage."


translate french observebox_34733ba8:


    orushi "Joueur Mac. À vous."


translate french observebox_885a1765:


    dpense "Mac se lève lentement, les mains dans les poches."


translate french observebox_1865563a:


    dpense "Il regarde autour de lui, puis fixe Ben avec un sourire en coin."


translate french observebox_2c791c35:


    mac "J’espère que tu ne m’en voudras pas pour ça, mon pote… Je prends ta boîte !"


translate french observebox_6e69f05e:


    dpense "Il se dirige tranquillement vers le pupitre de Ben..."


translate french observebox_18845cd4:


    dpense "...prend la boîte sans hésitation et retourne à sa place."


translate french observebox_f88d009d:


    ruby "Il a fait une erreur."


translate french observebox_29ac5843:


    d "Quoi ?"


translate french observebox_6c82acdc:


    ruby "Il a regardé dans la boîte de Ben tout à l’heure."


translate french observebox_669c4a61:


    d "Oui… et ?"


translate french observebox_72899aee:


    ruby "Kira l’a échangée. La boîte qu’il a vue est maintenant devant elle."


translate french observebox_1713d740:


    d "Donc il vient juste de prendre la boîte de Kira à la place…"


translate french observebox_2cf6da97:


    ruby "Exactement. Et il n’a même pas remarqué l’échange."


translate french observebox_15f94f1a:


    dpense "Je vois Ruby secouer la tête, visiblement déçue."


translate french observebox_a340fa6a:


    orushi "Joueur Ben. À vous."

translate french observebox_044fdd94:


    dpense "Ben saute sur ses pieds, beaucoup trop enthousiaste."


translate french observebox_5575fb41:


    ben "Eh bien alors, je garde la tienne !"


translate french observebox_817b1883:


    dpense "Il pointe la boîte devant lui."


translate french observebox_127b8362:


    dpense "Il ricane comme si c’était une blague entre initiés, mais personne ne rit."


translate french observebox_cafb54ab:


    ruby "C’est du grand n’importe quoi."


translate french observebox_eb044607:


    d "Donc il a gardé la boîte de Mac."


translate french observebox_c706e221:


    ruby "Ouais. Mais comme Mac a peut-être échangé juste pour embrouiller son pote..."


translate french observebox_4581777d:


    ruby "On n’a aucune idée de ce qu’il y a vraiment dedans."


translate french observebox_8b87781d:


    dpense "Je vois Ruby rayer leurs noms dans sa tête."


translate french observebox_70306ccc:


    ruby "Deux tours gaspillés. Et aucun des deux ne s’en rend compte."


translate french observebox_fa7e1ee5:


    ruby "Seule Kira détient la clé de ce foutoir ridicule."


translate french observebox_a5d50b4b:


    ruby "Soit elle a fait un coup malin en sachant que les deux allaient se planter..."


translate french observebox_4f25693e:


    ruby "Soit elle a tout risqué, en espérant qu’au moins un des deux ne serait pas stupide."


translate french observebox_1578061c:


    ruby "Mais à ce stade, on ne peut pas savoir..."


translate french observebox_0104b540:


    orushi "Joueuse Elizabeth, fais ton choix."


translate french observebox_5e80f2b4:


    beth "Je vais échanger ma boîte avec celle d’Hector."


translate french observebox_d3e3843e:


    dpense "Elle marche droit vers Hector, comme si tout avait été prévu à l’avance."


translate french observebox_f6525f16:


    ruby "Elle s’en prend à Hector. Je ne m’attendais pas à ça."


translate french observebox_ea69dd94:


    d "Tu crois qu’elle veut le bloquer ?"


translate french observebox_f7fa6f24:


    ruby "Peut-être. Il a pris la boîte de Julia après l’avoir vérifiée."


translate french observebox_151dd19b:


    ruby "Mais c’est surprenant… elle trahit son propre groupe, non ?"


translate french observebox_524f53ec:


    d "Ou peut-être qu’elle se protège juste pour ce qui arrive..."


translate french observebox_548cb47b:


    beth "Je vais échanger ma boîte avec celle de Grace."


translate french observebox_3d901c49:


    dpense "Elle avance lentement, les yeux rivés sur Grace."


translate french observebox_2689dc96:


    ruby "Elle s’en prend à Grace. Un coup direct."

translate french observebox_50da0e5e:


    d "Tu crois qu’elle a vu quelque chose dans sa boîte ?"


translate french observebox_869911db:


    ruby "Elle l’a vérifiée au premier tour."


translate french observebox_5c02eddf:


    ruby "Ou… elle pourrait bluffer et juste essayer de déstabiliser notre équipe."


translate french observebox_03922bd1:


    d "Ce serait risqué."


translate french observebox_1ce324f2:


    ruby "Exactement. Ce qui en ferait une diversion potentielle."


translate french observebox_815d5c0f:


    orushi "Joueuse Julia. À vous."


translate french observebox_e113da56:


    dpense "Julia prend une inspiration lente, les yeux calmes mais concentrés."


translate french observebox_e6ad5521:


    ruby "Elle a vérifié la boîte de Ben au début. Mais trop de choses ont changé depuis."


translate french observebox_7d077aa8:


    ruby "On ne sait pas vraiment ce que Kira avait en tête, sachant que trois personnes ont vu la boîte de Ben..."


translate french observebox_86ef9a80:


    ruby "Mais s’il y avait un jeton dedans... elle devrait aller le récupérer à Kira maintenant."


translate french observebox_ef7bec1c:


    ruby "Il nous manque des éléments. Mais elle devra décider quand même."


translate french observebox_b002e034:


    dpense "Elle jette un regard appuyé à Steven."


translate french observebox_ae94392f:


    d "Tu crois qu’elle pense qu’il a pris quelque chose de précieux ?"


translate french observebox_f8ab3945:


    ruby "Il a pris la boîte de Madison."


translate french observebox_b594f079:


    ruby "Coup risqué, mais ça se tient. Hector avait vu la boîte de Julia."


translate french observebox_21c132d9:


    d "Mais comme elle ne peut pas reprendre sa propre boîte..."


translate french observebox_f7c14dd5:


    ruby "Elle ne peut pas récupérer ce qu’Hector lui a pris..."


translate french observebox_6f2fdbf9:


    dpense "Julia avance en silence et échange sa boîte avec celle de Steven."


translate french observebox_49c15850:


    dpense "Julia observe Blue un instant."


translate french observebox_37b2a3e3:


    d "Tu crois qu’elle ne fait pas confiance à Blue ?"


translate french observebox_54568809:


    ruby "Peut-être. Blue a vérifié ta boîte puis a décidé de garder la sienne."


translate french observebox_485e2ab4:


    ruby "Julia pourrait penser qu’elle essaie de jouer la sécurité."


translate french observebox_6c78b4ee:


    dpense "Et comme personne n’a encore attaqué Blue, elle reste une cible relativement sûre."


translate french observebox_7675980e:


    dpense "Julia avance et échange calmement sa boîte avec celle de Blue."


translate french observebox_dabe3c58:


    dpense "Aucune tension dans ses mouvements. Juste de la logique froide."


translate french observebox_c90be0da:


    dpense "Elle retourne à sa place, un peu à l’écart des autres. Mais ses yeux continuent de balayer la salle."

translate french observebox_0d05e656:


    ruby "Elle prend un risque. Mais au moins, elle ne reste pas figée."


translate french observebox_14e4d56f:


    d "Tu penses qu’elle a flairé un bon coup ?"


translate french observebox_429b79ba:


    ruby "Elle joue avec ce qu’elle a. Comme nous tous."


translate french observebox_0fded406:


    orushi "Joueuse Ruby. À vous."


translate french observebox_9bcd2f94:


    dpense "Ruby reste silencieuse alors que tous les regards se tournent vers elle."


translate french observebox_93afc8c1:


    dpense "Elle fixe sa boîte un instant, mais ses yeux dérivent. Elle réfléchit."


translate french observebox_e52a9cbd:


    ruby "Attendez."


translate french observebox_bf2a25a9:


    dpense "Elle relève la tête vers Orushi."


translate french observebox_24ca5c61:


    ruby "Je… j’aimerais poser une question."


translate french observebox_ee1a2f3b:


    orushi "Je vous écoute."


translate french observebox_6a611e78:


    ruby "Vous avez dit qu’on pouvait échanger deux boîtes entre joueurs tant qu’elles sont visibles, n’est-ce pas ?"


translate french observebox_8b953aea:


    orushi "Excellente question, Mademoiselle."


translate french observebox_1247e3c0:


    orushi "Les règles interdisent seulement de prendre une boîte échangée au tour précédent ou de manipuler sa propre boîte plus d’une fois."


translate french observebox_a5e70cd2:


    orushi "Mais vous pouvez proposer à deux autres joueurs d’échanger leurs boîtes, tant que cela ne viole pas ces conditions."


translate french observebox_dd5d68f3:


    d "Hein ?"


translate french observebox_3a6a8dfe:


    ruby "Très bien. Donc, si je veux échanger les boîtes de deux autres joueurs, je peux ?"


translate french observebox_b42d5274:


    orushi "Astucieux…"


translate french observebox_c3592c58:


    orushi "Vous pouvez le demander, et l’échange sera effectué en conséquence."


translate french observebox_dcd25429:


    d "Tu vas vraiment faire ça ?"


translate french observebox_c766f9be:


    ruby "Très bien. Alors je fais la demande officiellement."


translate french observebox_48143662:


    ruby "Je veux échanger la boîte d’Hector… avec celle de Madison."


translate french observebox_4a17ea6f:


    mad "Ruby… ?"


translate french observebox_ccb6903a:


    ruby "Je ne sais pas ce qu’il y a dans ma boîte."


translate french observebox_61abab49:


    ruby "Mais vu la faible confiance que j’ai en Emerick, je ne peux pas miser sur cette boîte en particulier."

translate french observebox_e615cae3:


    ruby "Steven a pris la boîte de Madison. Mais leur rendre leurs boîtes d’origine irait à l’encontre des règles, je suppose ?"


translate french observebox_c7901d2d:


    orushi "Exact."


translate french observebox_6046889d:


    ruby "Si le jeton était dans la boîte de Kira... Julia l’aurait prise, puisqu’elle a vu la boîte de Ben au premier tour."


translate french observebox_e4001d75:


    ruby "Hector a pris la boîte de Julia de la même manière."


translate french observebox_6a123181:


    ruby "Et avec Elizabeth, elle fait partie des rares qui détiennent actuellement une boîte susceptible de contenir un jeton."


translate french observebox_6f9bee03:


    ruby "Donc si je fais ça, j’ai la meilleure chance de sauver Madison."


translate french observebox_02d84031:


    dpense "Ruby prend une profonde inspiration."


translate french observebox_9a628144:


    ruby "Je ne peux pas rester là sans rien faire."


translate french observebox_9afa24c5:


    ruby "Et je suis prête à perdre pour ça."


translate french observebox_19cbd0fe:


    orushi "Votre demande est… peu conventionnelle."


translate french observebox_8e3f076a:


    orushi "Mais elle respecte les règles. Approuvée."


translate french observebox_8e2f27e9:


    dpense "Ruby avance calmement, prend la boîte d’Hector, puis celle de Madison, et les échange devant tout le monde."


translate french observebox_443611cc:


    dpense "Hector la fusille du regard. Madison semble trop choquée pour parler."


translate french observebox_c956f893:


    mad "Mais... Ruby... Tu..."


translate french observebox_a1503ba2:


    emerick "C’est complètement absurde."


translate french observebox_e2a55e6b:


    emerick "Maintenant, elle invente carrément des règles !"


translate french observebox_60dbd188:


    orushi "Joueur Emerick, vous n’êtes pas autorisé à juger les règles de ce jeu."


translate french observebox_6a04ba9f:


    ruby "Voilà."


translate french observebox_d525f880:


    ruby "Maintenant, au moins, elle a une chance."


translate french observebox_46adb172:


    dpense "Ruby retourne à sa place, les yeux baissés."


translate french observebox_6222564e:


    dpense "Elle a tout donné… pour Madison."


translate french observebox_c3884886:


    ruby "J’ai fait tout ce que je pouvais."


translate french observebox_49cff7fa:


    ruby "Maintenant, tout repose sur la chance."


translate french observebox_84827799:


    orushi "À vous, [name]."


translate french observebox_d414f5b7:


    ruby "Écoute... d’après ce que j’ai vu, Emerick a peut-être pris un énorme risque dès le départ."

translate french observebox_dae896d1:


    d "Tu veux dire... qu'il bluffait ?"


translate french observebox_ac6ec22d:


    ruby "C’est possible. Il est resté bien trop calme, trop sûr de lui. Et il a échangé avec moi immédiatement."


translate french observebox_9165ff32:


    d "Alors, qu’est-ce que tu en penses ?"


translate french observebox_21f8b7e7:


    ruby "Je ne peux pas l’affirmer, mais c’est le seul que personne n’a attaqué. Ça en dit long."


translate french observebox_132d903d:


    ruby "Les autres ont peur et n’oseront pas le défier."


translate french observebox_f573f78c:


    ruby "Et je n’ai aucune idée de ce qu’il y avait à l’origine dans ma boîte ou la sienne."


translate french observebox_20bf63df:


    d "Et si je garde simplement la mienne ?"


translate french observebox_db2421bf:


    ruby "Tu as toujours ta boîte d’origine. C’est ton choix. Mais souviens-toi, certaines décisions peuvent tout changer."


translate french observebox_8e682e31:


    dpense "Elle me laisse sur ces mots. Un dernier regard, puis elle se redresse comme si nous n’avions jamais parlé."


translate french observebox_14ecd1da:


    dpense "Je lève les yeux vers Orushi. C’est mon tour."


translate french observebox_46e9b526:


    orushi "[name], à vous de jouer."


translate french observebox_2d4de5c9:


    dpense "Tous les regards sont braqués sur moi. La tension est palpable."


translate french observebox_913e11b3:


    dpense "Je ne peux pas choisir les boîtes d’Hector ou de Madison puisqu’elles viennent d’être échangées."


translate french observebox_13773ee9:


    dpense "Je resserre ma prise sur ma boîte."


translate french observebox_a83cc689:


    dpense "Je vais prendre le risque. J’y crois."


translate french observebox_33c410d7:


    dpense "Je jette un coup d’œil à Ruby. Elle me fixe en silence."


translate french observebox_eb2bc0fa:


    dpense "Je me lève et échange calmement ma boîte avec la sienne."


translate french observebox_552a2159:


    dpense "Je jette un coup d’œil à Kira. Elle me fixe en silence."


translate french observebox_eb2bc0fa_1:


    dpense "Je me lève et échange calmement ma boîte avec la sienne."


translate french observebox_7cc12e13:


    dpense "Je jette un coup d’œil à Julia. Elle me fixe en silence."


translate french observebox_eb2bc0fa_2:


    dpense "Je me lève et échange calmement ma boîte avec la sienne."


translate french observebox_a2455dfe:


    dpense "Je regarde Grace. Elle ne dit rien, mais je perçois une hésitation dans ses yeux."


translate french observebox_614d323f:


    dpense "J’avance et fais l’échange sans dire un mot."


translate french observebox_6fe136ad:


    dpense "Red fronce légèrement les sourcils en me voyant approcher."


translate french observebox_f60a68a1:


    dpense "Elle tend sa boîte sans un mot. J’échange."


translate french observebox_d10389c1:


    dpense "Je marche vers Blue. Elle me regarde calmement, comme si elle savait que je viendrais."

translate french observebox_3f0b66ea:


    dpense "Je prends sa boîte. Elle ne bronche pas."


translate french observebox_6585548e:


    dpense "Ben me regarde, surpris, presque amusé."


translate french observebox_3e04ce27:


    dpense "Je prends sa boîte. Voyons si son attitude détendue cache quelque chose."


translate french observebox_500e43c2:


    dpense "Mac hausse les sourcils."


translate french observebox_b55ec828:


    dpense "Je prends sa boîte."


translate french observebox_9a0c0a4b:


    dpense "Emerick esquisse un sourire en coin alors que je m'approche. Presque trop confiant."


translate french observebox_53cf4db2:


    dpense "Je lui tends ma boîte. Il la prend sans dire un mot."


translate french observebox_d52c6b75:


    dpense "Je remarque le malaise de Ruby..."


translate french observebox_038794b2:


    blue "Tu... Tu penses vraiment que c'était une bonne idée ?"


translate french observebox_e33af6f5:


    dpense "Son regard me transperce. Pas de la colère — juste une incrédulité blessée."


translate french observebox_d7287a2b:


    blue "Tu aurais pu me faire confiance."


translate french observebox_3b8b4697:


    dpense "Ai-je fait une erreur ?"


translate french observebox_fabd831a:


    dpense "Je retourne m'asseoir. Mon cœur bat plus fort que je ne veux l’admettre."


translate french observebox_e4da9d25:


    orushi "Très bien. Grace ? À vous."


translate french observebox_4e9cd4a5:


    dpense "Elle avance avec assurance, mais ses yeux cherchent brièvement les miens."


translate french observebox_ec10dc98:


    dpense "Elle ne dit rien. Juste un regard concentré sur sa boîte."


translate french observebox_87a9f53c:


    grace "Je garde la mienne."


translate french observebox_31227e7c:


    dpense "Aucun doute. Elle est confiante."


translate french observebox_7e1415e0:


    dpense "Dernier tour terminé."


translate french observebox_56ae23ff:


    orushi "Très bien."


translate french observebox_e131215e:


    orushi "Vous avez tous eu l’opportunité de vérifier. D’agir. De trahir."


translate french observebox_fb44ccf8:


    orushi "Chaque geste a été noté. Chaque hésitation est révélatrice."


translate french observebox_31e89f22:


    orushi "Mais maintenant, le temps de la stratégie est terminé."


translate french observebox_19da0fa9:


    orushi "Ce qu’il y a dans vos boîtes déterminera la suite."


translate french observebox_f86ad1e4:


    orushi "Souvenez-vous : seuls ceux qui possèdent un jeton passeront à la prochaine épreuve."

translate french observebox_7612ad25:


    orushi "Et pour les autres… le voyage s’arrête ici."


translate french observebox_0d45be32:


    dpense "Un lourd silence tombe sur la pièce."


translate french observebox_fda72d86:


    dpense "Tout le monde fixe sa boîte. Certains avec confiance, d’autres avec une anxiété à peine dissimulée."


translate french observebox_f91235b9:


    orushi "Nous allons les ouvrir. Une par une."


translate french observebox_cfb3751c:


    orushi "Joueur Emerick. Nous commençons par toi."


translate french observebox_974ba520:


    orushi "Jeton confirmé."


translate french observebox_9a845405:


    ruby "Il avait vraiment un jeton. Je ne m’étais pas trompée..."


translate french observebox_952daa01:


    emerick "Bien sûr que j’avais un jeton."


translate french observebox_481b1855:


    emerick "Et tu as été maline de ne pas te mêler de mes affaires."


translate french observebox_930dd552:


    emerick "Peut-être que tu mérites de passer à la suite."


translate french observebox_37771d92:


    orushi "Le bluff peut être une arme redoutable..."


translate french observebox_a2c85619:


    orushi "Mais la vraie compétence, c’est de ne pas tomber dans le piège."


translate french observebox_cad105a2:


    ruby "Non… non non non…"


translate french observebox_4a31fccb:


    ruby "Je me suis trompée…"


translate french observebox_474f9baa:


    d "Ruby..."


translate french observebox_a0066e41:


    ruby "Je pensais qu’il bluffait…"


translate french observebox_93b51ce3:


    ruby "Il a pris ma boîte parce qu’il savait qu’elle était vide…"


translate french observebox_3e244d8a:


    ruby "Et il a tout fait pour que tu veuilles la récupérer…"


translate french observebox_ba4d9261:


    ruby "Tout était un piège. Et j’y ai foncé droit dedans."


translate french observebox_9401799d:


    ruby "Je t’ai fait perdre ton jeton…"


translate french observebox_e0b0d250:


    d "Tu ne m’as rien fait perdre, Ruby. C’est moi qui ai fait ce choix."


translate french observebox_46bbe90c:


    emerick "Trop tard pour les excuses, les tourtereaux."


translate french observebox_8ba239ca:


    emerick "Vous avez joué, et vous avez perdu."


translate french observebox_910e4247:


    emerick "Pendant que vous étiez occupés à me suspecter, j’ai pris votre place."


translate french observebox_329dfa00:


    emerick "Vous pensiez vraiment que je tenais à mon jeton ?"

translate french observebox_5f1da96a:


    emerick "Tout ce que je voulais, c’était t’avoir."


translate french observebox_1ea28260:


    emerick "Je savais que, par principe, tu ne toucherais pas à la boîte de Ruby !"


translate french observebox_06cce23c:


    emerick "Et tu as mordu à l’hameçon. Pathétique."


translate french observebox_7be61e20:


    orushi "Un geste rare, en effet. Mettre en péril sa propre victoire uniquement pour éliminer un adversaire. Risqué… mais efficace."


translate french observebox_e9754cba:


    ruby "..."


translate french observebox_4f50ea4b:


    orushi "L’art de la manipulation, appliqué avec adresse."


translate french observebox_f4581a68:


    orushi "À trop se concentrer sur l’intention, on en oublie la conséquence."


translate french observebox_508c25d5:


    orushi "Et d’autres révélations restent à venir…"


translate french observebox_f156f9d9:


    orushi "Joueuse Madison. À vous."


translate french observebox_974ba520_1:


    orushi "Jeton confirmé."


translate french observebox_28d58a31:


    orushi "Joueuse Madison. Votre boîte."


translate french observebox_62e0e823:


    mad "Merci, Ruby…"


translate french observebox_b0a89566:


    mad "Je ne sais pas comment te remercier…"


translate french observebox_88e218a6:


    ruby "Elle est en sécurité…"


translate french observebox_97edf630:


    d "Tu l’as sauvée, Ruby."


translate french observebox_398d812b:


    ruby "C’est le minimum que je pouvais faire."


translate french observebox_f13f6513:


    orushi "La stratégie peut mener à un bon choix, même si ce n’est pas la vôtre."


translate french observebox_3ff30284:


    orushi "À présent… continuons."


translate french observebox_e8527e4f:


    orushi "Joueur Steven. Voyons ce que contient votre boîte…"


translate french observebox_974ba520_2:


    orushi "Jeton confirmé."


translate french observebox_c961a606:


    s "Évidemment."


translate french observebox_e944a555:


    s "Il y a une raison si je suis capitaine."


translate french observebox_577552c1:


    ruby "Donc Madison avait bien un jeton au départ…"


translate french observebox_9d5b49f0:


    d "Steven avait un avantage de position."


translate french observebox_13c6e254:


    orushi "Stratégie, sang-froid ou pur instinct… Au final, c’est un point pour vous, Steven."

translate french observebox_f61ca382_1:


    orushi "Joueuse Sofia. À vous."


translate french observebox_974ba520_3:


    orushi "Jeton confirmé."


translate french observebox_fa8ccb8a:


    sofia "..."


translate french observebox_c16a8868:


    d "Je ne sais pas pourquoi, mais je ressens une pointe de culpabilité."


translate french observebox_e6dcb139:


    dpense "Attends… pourquoi j’ai soudain un mauvais pressentiment ?"


translate french observebox_8fccd52b:


    dpense "Comme si quelque chose clochait."


translate french observebox_3f6c7933:


    sofia "Ouf… au moins, c’est fait."


translate french observebox_d8de9c70:


    orushi "Joueur Hector. À vous."


translate french observebox_6f4ae617:


    orushi "Boîte vide."


translate french observebox_d6e9b6e5:


    hec "Quoi ?!"


translate french observebox_52249f1b:


    hec "Mais j’ai respecté les règles !"


translate french observebox_fd3898fd:


    hec "Comment ça peut être vide ?!"


translate french observebox_a7bc9564:


    hec "Attends… C’est Ruby ! Tu m’as piégé !"


translate french observebox_e5890989:


    hec "Quand tu as échangé ma boîte et que tu l’as donnée à Madison !"


translate french observebox_4cc575e6:


    ruby "J’ai fait ce que je devais faire."


translate french observebox_a4f3ffe8:


    hec "Tu crois que c’est à toi de décider qui mérite de rester ?!"


translate french observebox_ad601622:


    hec "Tout ce jeu, c’est de la connerie !"


translate french observebox_af735833:


    hec "Vous êtes tous des hypocrites !"


translate french observebox_268aaefe:


    orushi "La décision est définitive."


translate french observebox_fb9e53a4:


    hec "Allez vous faire foutre."


translate french observebox_c80184b8:


    orushi "Joueuse Kira. Voyons ce que contient votre boîte."


translate french observebox_974ba520_4:


    orushi "Jeton confirmé."


translate french observebox_869f53e1:


    kira "Parfait."


translate french observebox_7de0f032:


    orushi "Joueur Mac. Voyons maintenant ce que contient votre boîte."


translate french observebox_c7696248:


    orushi "...Pas de jeton."

translate french observebox_f80dea7d:


    mac "Quoi ?!"


translate french observebox_60c7519a:


    ben "Bien joué, mec… Je *t’avais* dit que c’était l’autre."


translate french observebox_d92fd476:


    mac "Non, on s’est emmêlé les pinceaux ! Je croyais que *toi* tu prenais celle de Red !"


translate french observebox_4e249041:


    ruby "Voilà. Deux demi-cerveaux ne font pas un cerveau entier."


translate french observebox_0c2120c1:


    orushi "Il semble qu’une alliance sans réflexion soit vouée à l’échec."


translate french observebox_cd2893ad:


    orushi "Joueur Ben. Il est temps de révéler ce que contient votre boîte."


translate french observebox_ac36ddb9:


    orushi "…Votre boîte est vide."


translate french observebox_72ed8d85:


    ben "Sérieusement ?!"


translate french observebox_f1d5bc35:


    mac "T’as pris celle de Kira, abruti…"


translate french observebox_c3600366:


    ben "Non ! C’était celle de Mac, pas celle de Kira !"


translate french observebox_f5b77199:


    beth "On devrait leur donner un jeton par pitié."


translate french observebox_e6242f29:


    orushi "Inattention. Confusion. Peu importe comment on l’appelle, le résultat est toujours le même."


translate french observebox_c48f2526:


    orushi "Joueuse Elizabeth. À vous."


translate french observebox_e8ed82ca:


    orushi "…Il y a un jeton dans votre boîte."


translate french observebox_ecf3d79e:


    beth "Évidemment."


translate french observebox_b72c5297:


    ruby "Tu as vérifié Hector au début. Tu as compris ce qu’il se passait ?"


translate french observebox_f353fcf0:


    beth "J’ai vite vu qu’il y avait un problème dans notre groupe. Alors je l’ai corrigé."


translate french observebox_7ef400cc:


    d "(Elle s’est retournée contre sa propre équipe. Froid. Calculé.)"


translate french observebox_9cf9f448:


    emerick "Traîtresse."


translate french observebox_18712cea:


    beth "Disons que je préfère miser sur l’intelligence plutôt que sur l’arrogance."


translate french observebox_ecf3d79e_1:


    beth "Évidemment."


translate french observebox_44a16e27:


    ruby "Tu avais vérifié Grace..."


translate french observebox_5e0488cd:


    beth "Oui. Toujours miser sur le rouge."


translate french observebox_f5a4af3c:


    dpense "Toujours aussi égocentrique. Mais efficace."

translate french observebox_f58573e9:


    orushi "Joueuse Julia. C’est votre tour."


translate french observebox_e8ed82ca_1:


    orushi "...Il y a un jeton dans votre boîte."


translate french observebox_5bfa8e2b:


    ruby "Tu avais vérifié Ben, non ?"


translate french observebox_d1e1e790:


    julia "Oui."


translate french observebox_4b52c79e:


    ruby "Alors pourquoi tu n’es pas allée après Kira ?"


translate french observebox_d1f70c04:


    julia "..."


translate french observebox_f31b8708:


    dpense "Il y a un truc qui cloche..."


translate french observebox_24a95c57:


    ruby "Donc tu as pris la boîte de Steven…"


translate french observebox_3f0dd858:


    julia "Exactement. Je pensais que c’était le meilleur choix, vu les circonstances."


translate french observebox_ba15dbc5:


    dpense "Steven avait la boîte de Madison… mais Kira avait celle de Ben…"


translate french observebox_0952e2a6:


    ruby "Donc tu as choisi la boîte de Blue ?"


translate french observebox_69e3e0f8:


    julia "Oui. J’ai hésité… mais à ce moment-là, ça me paraissait l’option la plus sûre."


translate french observebox_2d8371f9:


    dpense "Elle aurait pu prendre celle de Steven… ou mieux encore, celle de Kira."


translate french observebox_37d8e615:


    orushi "Joueuse Ruby. C’est votre tour."


translate french observebox_3197b306:


    orushi "...Il y a un jeton dans votre boîte."


translate french observebox_e9754cba_1:


    ruby "..."


translate french observebox_8e9ab4e7:


    dpense "Elle semble figée… comme si elle s’attendait au pire."


translate french observebox_3193c932:


    mad "Tu l’as fait !"


translate french observebox_0f2c1293:


    ruby "J… j’ai réussi ?"


translate french observebox_85ff042c:


    d "Oui. Tu avais la boîte d’Emerick, non ?"


translate french observebox_7c8879d6:


    ruby "C’est lui qui a pris la mienne… Mais j’ai gardé la sienne. Et je n’ai jamais su si…"


translate french observebox_94b8d948:


    ruby "Quand j’ai aidé Madison, j’ai juste accepté mon sort. Je pensais que ça ne serait pas moi."


translate french observebox_87ad4670:


    mad "Tu as tout déchiré, Ruby."


translate french observebox_c270dc58:


    ruby "J’arrive pas à y croire..."


translate french observebox_9013017e:


    ruby "J’ai vraiment réussi à…"

translate french observebox_18b51f9b:


    orushi "Une joueuse altruiste, et perspicace. Mais même les meilleurs choix reposent parfois sur un peu de chance."


translate french observebox_1b038fdd:


    orushi "Joueur [name]. C’est votre tour."


translate french observebox_3197b306_1:


    orushi "…Il y a un jeton dans votre boîte."


translate french observebox_11b6e570:


    d "Oui !"


translate french observebox_b1934d1a:


    ruby "Tu l’as fait !"


translate french observebox_31063061:


    orushi "Parfois, le coup le plus intelligent… est de ne pas trop jouer."


translate french observebox_ac36ddb9_1:


    orushi "…Votre boîte est vide."


translate french observebox_717cf009:


    d "Merde..."


translate french observebox_1c2eed96:


    ruby "Tu… tu avais un jeton dans ta boîte au départ. Pourquoi l’as-tu échangée ?"


translate french observebox_520730bb:


    d "Je pensais que peut-être Mac ou Ben avaient de meilleures chances..."


translate french observebox_b0cd8174:


    sofia "Non... !"


translate french observebox_88a75c4d:


    sofia "NON !"


translate french observebox_70206759:


    sofia "Je ne le laisserai pas partir comme ça !"


translate french observebox_5dced416:


    orushi "Hmm ?"


translate french observebox_c94f114d:


    sofia "J’ai un jeton spécial… le jeton du Sacrifice."


translate french observebox_f852caa8:


    sofia "Je veux lui donner ma place."


translate french observebox_5d296f3e:


    orushi "..."


translate french observebox_71eb5446:


    orushi "Je m’y attendais. Ce jeton n’a été donné qu’à un seul joueur."


translate french observebox_07cb4710:


    orushi "Le jeton du Sacrifice. Il peut être utilisé une fois, pour donner votre place à un autre joueur éliminé."


translate french observebox_f452c162:


    orushi "C’est un acte final. Est-ce vraiment votre souhait ?"


translate french observebox_a5cda67b:


    sofia "S’il te plaît… reste avec moi."


translate french observebox_53155274:


    dpense "Sofia..."


translate french observebox_a0b873b8:


    dpense "Elle… elle pleure pour moi ?"


translate french observebox_f195c7ff:


    d "Tu te rends compte de ce que ça signifie ?"


translate french observebox_d0eb6209:


    sofia "Oui. Mais je me fiche d’être la meilleure si ça veut dire être seule."


translate french observebox_6a9670cd:


    dpense "Je la serre dans mes bras…"


translate french observebox_f4288911:


    d "Merci. Je te revaudrai ça un jour."

translate french observebox_5d296f3e_1:


    orushi "..."


translate french observebox_2bf1f1d9:


    orushi "Joueuse Sofia, vous avez montré une forme rare de dévouement."


translate french observebox_998c5c67:


    orushi "Ce jeu ne se résume pas à l’intelligence ou à la stratégie. C’est aussi un test de ce que vous êtes prête à sacrifier pour les autres."


translate french observebox_114ae86f:


    orushi "Aujourd’hui, vous avez montré que vous n’êtes pas tentée par les récompenses…"


translate french observebox_56ed9463:


    orushi "Mais plutôt que vous souhaitez élever et aider ceux qui vous entourent."


translate french observebox_815a0bb9:


    orushi "Vous êtes immédiatement qualifiée pour la prochaine épreuve. L’immunité est la récompense pour cet acte."


translate french observebox_df4d3d01:


    ruby "Waouh."


translate french observebox_325e86c7:


    dpense "Je suis encore ici grâce à elle."


translate french observebox_25bb462a:


    dpense "Et ça aurait pu lui coûter tout."


translate french observebox_2774b746:


    orushi "Vous êtes éliminé."


translate french observebox_ac36ddb9_2:


    orushi "…Votre boîte est vide."


translate french observebox_2c536cc9:


    d "Merde..."


translate french observebox_7ea8f2bd:


    ruby "Je… je me suis trompée…"


translate french observebox_16b3b1d0:


    ruby "Je pensais qu’il bluffait, mais il a pris exprès une boîte sans jeton pour te piéger."


translate french observebox_72a7b667:


    ruby "Je t’ai fait perdre…"


translate french observebox_82292ffe:


    d "Tu ne pouvais pas savoir…"


translate french observebox_a81f7dcc:


    emerick "On ne gagne pas à ce jeu en suivant son cœur."


translate french observebox_ecb0e7fe:


    emerick "Il faut penser un coup à l’avance."


translate french observebox_b0cd8174_1:


    sofia "Non...!"


translate french observebox_88a75c4d_1:


    sofia "NON !"


translate french observebox_d93cefbd:


    sofia "Je ne le laisserai pas partir comme ça !"


translate french observebox_5dced416_1:


    orushi "Hmm ?"


translate french observebox_c94f114d_1:


    sofia "J’ai un jeton spécial… le jeton du Sacrifice."


translate french observebox_f852caa8_1:


    sofia "Je veux lui donner ma place."


translate french observebox_5d296f3e_2:


    orushi "..."

translate french observebox_71eb5446_1:


    orushi "Je m’y attendais. Ce jeton n’a été donné qu’à une seule joueuse."


translate french observebox_781dbb01:


    orushi "Le jeton du Sacrifice. Il ne peut être utilisé qu’une seule fois, pour donner votre place à un autre joueur éliminé."


translate french observebox_f452c162_1:


    orushi "C’est un acte définitif. Est-ce vraiment votre souhait ?"


translate french observebox_a5cda67b_1:


    sofia "S’il te plaît… reste avec moi."


translate french observebox_53155274_1:


    dpense "Sofia..."


translate french observebox_a0b873b8_1:


    dpense "Elle… elle pleure pour moi ?"


translate french observebox_cd3b6bc1:


    d "Tu comprends ce que ça veut dire ?"


translate french observebox_4744e459:


    sofia "Oui. Mais je me fiche d’être la meilleure si je suis seule."


translate french observebox_81607533:


    dpense "Je la serre fort dans mes bras..."


translate french observebox_f4288911_1:


    d "Merci. Je te revaudrai ça un jour."


translate french observebox_5d296f3e_3:


    orushi "..."


translate french observebox_5f088be5:


    orushi "Joueuse Sofia, vous avez montré un dévouement rare."


translate french observebox_8a126ae0:


    orushi "Ce jeu n’est pas seulement un test d’intelligence ou de stratégie. Il teste aussi ce que vous êtes prête à sacrifier pour les autres."


translate french observebox_6a5a7c8b:


    orushi "Aujourd’hui, vous avez montré que vous n’êtes pas tentée par l’attrait de la victoire..."


translate french observebox_9accf929:


    orushi "Mais plutôt que vous souhaitez soutenir et élever ceux qui vous entourent."


translate french observebox_815a0bb9_1:


    orushi "Vous êtes immédiatement qualifiée pour la prochaine épreuve. L’immunité est la récompense pour cet acte."


translate french observebox_df4d3d01_1:


    ruby "Waouh."


translate french observebox_93f9a021:


    dpense "Je suis encore ici grâce à elle."


translate french observebox_25bb462a_1:


    dpense "Et ça aurait pu lui coûter tout."


translate french observebox_2774b746_1:


    orushi "Vous êtes éliminé."


translate french observebox_3197b306_2:


    orushi "…Il y a un jeton dans votre boîte."


translate french observebox_23148e2c:


    d "Ouf... ça a marché."


translate french observebox_00153084:


    ruby "Bien joué !"


translate french observebox_bf6e0ecb:


    orushi "Votre choix était le bon. Vous passez à l’étape suivante."


translate french e5s6_reveal_grace_dd66b7b6:


    orushi "Dernière boîte à révéler… Joueuse Grace."


translate french e5s6_reveal_grace_3a0afec6:


    dpense "Elle se tient droite, les yeux fixés..."


translate french e5s6_reveal_grace_2460a778:


    dpense "Soit elle n’a pas hésité, soit elle l’a très bien caché."


translate french e5s6_reveal_grace_3197b306:


    orushi "…Il y a un jeton dans ta boîte."


translate french e5s6_reveal_grace_4da47427:


    grace "J... J’ai réussi ?!"


translate french e5s6_reveal_grace_0b300a7d:


    ruby "Oui ! Bien joué !"


translate french e5s6_reveal_grace_79b24103:


    mad "Je savais qu’elle s’en sortirait."


translate french e5s6_reveal_grace_ef1b0c25:


    dpense "La dernière à se qualifier… merci mon dieu."


translate french e5s6_reveal_grace_2490cefd:


    orushi "L’épreuve est à présent terminée."


translate french e5s6_reveal_grace_4006ce28:


    orushi "Tous les jetons ont été révélés."


translate french e5s6_reveal_grace_4276c690:


    orushi "Il est temps de conclure… et de parler de ce qui vient ensuite."


translate french e5s6_reveal_grace_394e93a6:


    d "Ensuite ?"

translate french strings:


    old "Observe Madison’s box"
    new "Observer la boîte de Madison"


    old "Observe Steven’s box"
    new "Observer la boîte de Steven"


    old "Observe Hector’s box"
    new "Observer la boîte d’Hector"


    old "Observe Julia’s box"
    new "Observer la boîte de Julia"


    old "Observe Grace’s box"
    new "Observer la boîte de Grace"


    old "Observe Ben’s box"
    new "Observer la boîte de Ben"


    old "Observe Mac’s box"
    new "Observer la boîte de Mac"


    old "Observe Sofia (Blue)’s box"
    new "Observer la boîte de Sofia (Blue)"


    old "Observe Elisabeth (Red)’s box"
    new "Observer la boîte d’Elisabeth (Red)"


    old "Observe Kira’s box"
    new "Observer la boîte de Kira"


    old "Observe Emerick’s box"
    new "Observer la boîte d’Emerick"


    old "Observe Ruby’s box"
    new "Observer la boîte de Ruby"


    old "Keep my box[TEMP1!t]"
    new "Garder ma boîte[TEMP1!t]"


    old "Trade with Ruby"
    new "Échanger avec Ruby"


    old "Trade with Kira"
    new "Échanger avec Kira"


    old "Trade with Julia"
    new "Échanger avec Julia"


    old "Trade with Grace"
    new "Échanger avec Grace"


    old "Trade with Elizabeth (Red)"
    new "Échanger avec Elizabeth (Red)"


    old "Trade with Sofia (Blue)"
    new "Échanger avec Sofia (Blue)"


    old "Trade with Ben"
    new "Échanger avec Ben"


    old "Trade with Mac"
    new "Échanger avec Mac"


    old "Trade with Emerick"
    new "Échanger avec Emerick"




translate french e5s6_63be2349:


    d "Que..."


translate french e5s6_8d826c96:


    d "Qu'est-ce que..."


translate french e5s6_43dd0ffe:


    d "C'est quoi cet endroit ?"


translate french e5s6_7671f49d:


    d "On dirait le dernier podium disponible."


translate french e5s6_971c59f9:


    orushi "Le podium que vous avez choisi a scellé votre destin."


translate french e5s6_a0031c50:


    orushi "Chaque emplacement correspond à une boîte."


translate french e5s6_d4759873:


    orushi "Chacun de vous aura l’occasion de regarder secrètement à l’intérieur d’une boîte."


translate french e5s6_ba297538:


    orushi "Grâce à la tablette présente sur votre podium."


translate french e5s6_observation_348067d8:


    dpense "Tout le monde fixe son podium... sans vraiment savoir quoi en faire."


translate french e5s6_observation_e0ba5112_1:


    ruby "Mieux vaut les ignorer pour rester simple."


translate french e5s6_observation_3284c8da:


    dpense "Ruby est plongée dans ses pensées. Ses yeux balaient la salle."


translate french e5s6_observation_49af70de:


    ruby "Que penses-tu de la posture de Steven ?"


translate french e5s6_observation_314c767a:


    ruby "Elle est sur les nerfs."


translate french e5s6_observation_ebcf2176:


    mad "Je vais... vérifier une boîte. Celle de Steven."


translate french e5s6_observation_95f5ec4a:


    s "Celle de Madison."


translate french e5s6_observation_e329c1fd:


    dpense "Pas un mot. Pas un regard."


translate french e5s6_observation_80e94fc0:


    dpense "Blue est calme. Aucun signe visible de stress."


translate french e5s6_observation_4e4bb857:


    dpense "Elle me regarde..."


translate french e5s6_observation_0388a167:


    dpense "Elle reste calme... C’est étrange."


translate french e5s6_observation_4ddefbcd:


    hec "Celle de Julia."


translate french e5s6_observation_d4fb69e8:


    dpense "Son visage, comme toujours, est impénétrable."


translate french e5s6_observation_240f57a3:


    dpense "Elle ne regarde personne."


translate french e5s6_observation_89a54bb2:


    kira "Celle de Ben."


translate french e5s6_observation_d66ee7fe:


    dpense "Pas la moindre émotion sur son visage."


translate french e5s6_observation_99603abd:


    mac "Celle de Ben !"


translate french e5s6_observation_ebef6679:


    ruby "Action inutile."


translate french e5s6_observation_45f96703:


    dpense "C’est... pour moi ?"


translate french e5s6_observation_8379d5b0:


    dpense "Elle fixe Grace longuement... comme si elle la méprisait."


translate french e5s6_observation_a3026be4:


    ruby "Puisque Ben a regardé Mac, elle suit peut-être une chaîne. Elle obtient une vision plus large que les autres."


translate french e5s6_observation_cf9bdec6:


    dpense "Hum..."


translate french e5s6_observation_b21bc917:


    dpense "Elle ne dit rien."


translate french e5s6_observation_354038e0:


    dpense "Elle l’observe longuement."


translate french e5s6_observation_4a3f2c65:


    dpense "Juste une boîte à vérifier. Et pas la mienne."


translate french observebox_76b98c9b:


    dpense "J’ai choisi la boîte de [chosenbox]."


translate french observebox_3f819674:


    dpense "Voyons ce qu’il y a dedans..."


translate french observebox_37abc764:


    ruby "Elle ne va pas perdre de temps."


translate french observebox_ad5ca45e:


    grace "Celle de Mac."


translate french observebox_9bec83be:


    d "Elle semble... froide."


translate french observebox_cfa5dd14:


    emerick "Je vais prendre celle de Ruby."


translate french observebox_043e9f57:


    dpense "Elle ne tremble pas."


translate french observebox_21d3d23c:


    dpense "Elle jette un coup d’œil à Steven, puis à son propre podium."


translate french observebox_f892ddd4:


    dpense "Steven, confiant comme toujours."


translate french observebox_42dd5504:


    ruby "Il a vu sa boîte. Il sait exactement ce qu’il y a dedans."


translate french observebox_8bd60aeb:


    ruby "Donc Steven a dû voir un jeton à l’intérieur."


translate french observebox_38368806:


    dpense "Son regard balaie brièvement la salle, puis se fixe droit devant."


translate french observebox_bc3c2b19:


    dpense "Elle me regarde une seconde."


translate french observebox_6fcaa1ce_1:


    sofia "Je garde la mienne..."


translate french observebox_f5a58c6f:


    d "Mais elle a vu ma boîte..."


translate french observebox_d84d7e95:


    ruby "Ça fait peut-être partie de sa stratégie."


translate french observebox_668b2336:


    dpense "Je regarde Hector. C’est son tour."


translate french observebox_4ddefbcd:


    hec "Celle de Julia."


translate french observebox_dd2a4560:


    dpense "Il est clairement satisfait de lui."


translate french observebox_c1e18fbb:


    kira "Ben..."


translate french observebox_2eafc64b:


    dpense "Il prend aussi celle de Ben ?"


translate french observebox_47487229:


    ruby "Ou elle a juste tout risqué, en espérant que l’un d’eux serait stupide."


translate french observebox_490c8399:


    julia "Celle de Steven..."


translate french observebox_d6520aff:


    ruby "Et avec Elizabeth, il fait partie des rares à détenir actuellement une boîte ayant de fortes chances de contenir un jeton."


translate french observebox_c0bb2703:


    ruby "Je veux échanger les boîtes d’Hector et de Madison."


translate french observebox_0401e78a:


    orushi "[name] ?"


translate french observebox_cd3a2992:


    dpense "Est-ce que j’échange ma boîte ou est-ce que je la garde ?"


translate french observebox_a9c69f39:


    dpense "Je vais échanger avec quelqu’un..."


translate french observebox_2bfa840a:


    dpense "Mais la question est... avec qui ?"


translate french observebox_218eb14c:


    d "Je garde la mienne."


translate french herochosenbox_15c8431d:


    d "Je prends celle de [herofinalbox]."


translate french herochosenbox_175acb31:


    sofia "Tu... tu penses vraiment que c’était une bonne idée ?"


translate french herochosenbox_c45efa37:


    dpense "Son regard me transperce. Pas de la colère... juste une incrédulité blessée."


translate french herochosenbox_78e93c48:


    sofia "Tu aurais pu me faire confiance."


translate french herochosenbox_3b8b4697:


    dpense "Est-ce que j’ai fait une erreur ?"


translate french revealtrial_e4da9d25:


    orushi "Très bien. Grace ? À toi."


translate french revealtrial_ec10dc98:


    dpense "Elle ne dit rien. Juste un regard concentré sur sa boîte."


translate french revealtrial_87a9f53c:


    grace "Je garde la mienne."


translate french revealtrial_31227e7c:


    dpense "Aucun doute. Elle est sûre d’elle."


translate french revealtrial_7e1415e0:


    dpense "Dernier tour terminé."


translate french revealtrial_56ae23ff:


    orushi "Très bien."


translate french revealtrial_e131215e:


    orushi "Vous avez tous eu l’occasion de vérifier. D’agir. De trahir."


translate french revealtrial_fb44ccf8:


    orushi "Chaque mouvement a été noté. Chaque hésitation a parlé."


translate french revealtrial_31e89f22:


    orushi "Mais à présent, le temps de la stratégie est terminé."


translate french revealtrial_19da0fa9:


    orushi "Ce qui se trouve dans vos boîtes déterminera la suite."


translate french revealtrial_f86ad1e4:


    orushi "Souvenez-vous : seuls ceux qui ont un jeton passeront à l’épreuve suivante."


translate french revealtrial_7612ad25:


    orushi "Et pour les autres… le voyage s’arrête ici."


translate french revealtrial_0d45be32:


    dpense "Un lourd silence tombe sur la pièce."


translate french revealtrial_fda72d86:


    dpense "Tout le monde fixe sa boîte. Certains avec assurance, d’autres avec une anxiété à peine dissimulée."


translate french revealtrial_f91235b9:


    orushi "Nous allons les ouvrir. Une par une."


translate french revealtrial_203b5f14:


    orushi "Joueur Emerick. Nous commencerons par vous."


translate french revealtrial_974ba520:


    orushi "Jeton confirmé."


translate french revealtrial_9a845405:


    ruby "Il avait vraiment un jeton. Je ne m’étais pas trompée..."


translate french revealtrial_952daa01:


    emerick "Bien sûr que j’avais un jeton."


translate french revealtrial_481b1855:


    emerick "Et tu as été maline de ne pas te mêler de mes affaires."


translate french revealtrial_930dd552:


    emerick "Peut-être que tu mérites de passer à la suite."


translate french revealtrial_37771d92:


    orushi "Le bluff peut être une arme redoutable..."


translate french revealtrial_a2c85619:


    orushi "Mais la véritable habileté consiste à ne pas tomber dans le piège."


translate french revealtrial_cad105a2:


    ruby "Non… non non non…"


translate french revealtrial_4a31fccb:


    ruby "Je me suis trompée…"


translate french revealtrial_474f9baa:


    d "Ruby..."


translate french revealtrial_a0066e41:


    ruby "Je pensais qu’il bluffait…"


translate french revealtrial_93b51ce3:


    ruby "Il a pris ma boîte parce qu’il savait qu’elle était vide…"


translate french revealtrial_3e244d8a:


    ruby "Et il a tout fait pour être sûr que tu veuilles la récupérer…"


translate french revealtrial_ba4d9261:


    ruby "C’était un piège. Et j’ai foncé dedans."


translate french revealtrial_9401799d:


    ruby "Je t’ai fait perdre ton jeton…"


translate french revealtrial_e0b0d250:


    d "Tu ne m’as rien fait perdre, Ruby. C’est moi qui ai fait ce choix."


translate french revealtrial_46bbe90c:


    emerick "Trop tard pour les excuses, les tourtereaux."


translate french revealtrial_8ba239ca:


    emerick "Vous avez joué, et vous avez perdu."


translate french revealtrial_910e4247:


    emerick "Pendant que vous étiez occupés à me soupçonner, j’ai pris votre place."


translate french revealtrial_329dfa00:


    emerick "Vous pensiez vraiment que je tenais à mon jeton ?"


translate french revealtrial_5f1da96a:


    emerick "Tout ce que je voulais, c’était t’avoir."


translate french revealtrial_1ea28260:


    emerick "Je savais que tu ne toucherais pas à la boîte de Ruby par principe !"


translate french revealtrial_06cce23c:


    emerick "Et tu as mordu à l’hameçon. Pathétique."


translate french revealtrial_7be61e20:


    orushi "Un geste rare, en effet. Mettre en péril sa propre victoire juste pour abattre un adversaire. Risqué. Mais efficace."


translate french revealtrial_e9754cba:


    ruby "..."


translate french revealtrial_4f50ea4b:


    orushi "L’art de la manipulation, appliqué avec habileté."


translate french revealtrial_f4581a68:


    orushi "Quand on se concentre trop sur l’intention, on oublie la conséquence."


translate french revealtrial_508c25d5:


    orushi "Et il reste encore bien des révélations à venir..."


translate french revealtrial_f156f9d9:


    orushi "Joueuse Madison. À vous."


translate french revealtrial_974ba520_1:


    orushi "Jeton confirmé."


translate french revealtrial_62e0e823:


    mad "Merci, Ruby..."


translate french revealtrial_b0a89566:


    mad "Je ne sais pas comment te remercier..."


translate french revealtrial_88e218a6:


    ruby "Elle est en sécurité..."


translate french revealtrial_97edf630:


    d "Tu l’as sauvée, Ruby."


translate french revealtrial_398d812b:


    ruby "C’est le minimum que je pouvais faire."


translate french revealtrial_f13f6513:


    orushi "La stratégie peut mener à un bon choix, même si ce n’est pas la vôtre."


translate french revealtrial_3ff30284:


    orushi "Maintenant… continuons."


translate french revealtrial_e8527e4f:


    orushi "Joueur Steven. Voyons ce qu’il y a dans votre boîte..."


translate french revealtrial_974ba520_2:


    orushi "Jeton confirmé."


translate french revealtrial_c961a606:


    s "Évidemment."


translate french revealtrial_e944a555:


    s "Il y a une raison pour laquelle je suis le capitaine."


translate french revealtrial_9d5b49f0:


    d "Steven avait un avantage de position."


translate french revealtrial_13c6e254:


    orushi "Stratégie, sang-froid ou pur instinct… En fin de compte, c’est un point pour vous, Steven."


translate french revealtrial_f61ca382:


    orushi "Joueuse Sofia. À vous."


translate french revealtrial_974ba520_3:


    orushi "Jeton confirmé."


translate french revealtrial_2d609d6b:


    sofia "Je... j’ai..."


translate french revealtrial_4e4fec28:


    orushi "Chut..."

translate french revealtrial_3f6c7933:


    sofia "Ouf... Au moins, c’est fait."


translate french revealtrial_d8de9c70:


    orushi "Joueur Hector. À vous."


translate french revealtrial_6f4ae617:


    orushi "Boîte vide."


translate french revealtrial_c16e21b8:


    hec "Quoi ?!" with hpunch


translate french revealtrial_52249f1b:


    hec "Mais j’ai respecté les règles !"


translate french revealtrial_fd3898fd:


    hec "Comment ça peut être vide ?!"


translate french revealtrial_a7bc9564:


    hec "Attends... C’est Ruby ! Tu m’as piégé !"


translate french revealtrial_e5890989:


    hec "Quand tu as échangé ma boîte et que tu l’as donnée à Madison !"


translate french revealtrial_4cc575e6:


    ruby "J’ai fait ce que je devais faire."


translate french revealtrial_a4f3ffe8:


    hec "Tu crois que c’est à toi de décider qui mérite de rester ?!"


translate french revealtrial_ad601622:


    hec "Tout ce jeu, c’est de la connerie !"


translate french revealtrial_af735833:


    hec "Vous êtes tous des hypocrites !"


translate french revealtrial_268aaefe:


    orushi "La décision est définitive."


translate french revealtrial_fb9e53a4:


    hec "Allez vous faire foutre."


translate french revealtrial_c80184b8:


    orushi "Joueuse Kira. Voyons ce que contient votre boîte."


translate french revealtrial_974ba520_4:


    orushi "Jeton confirmé."


translate french revealtrial_869f53e1:


    kira "Parfait."


translate french revealtrial_7de0f032:


    orushi "Joueur Mac. Voyons maintenant ce que contient votre boîte."


translate french revealtrial_c7696248:


    orushi "...Aucun jeton."


translate french revealtrial_f80dea7d:


    mac "Quoi ?!"


translate french revealtrial_460a57b3:


    ben "Bien joué, mec... Je t’avais dit que c’était l’autre."


translate french revealtrial_fad285ea:


    mac "Non, on s’est mal compris ! Je croyais que tu prenais celle de Red !"


translate french revealtrial_4e249041:


    ruby "Voilà. Deux demi-cerveaux ne font pas un cerveau entier."


translate french revealtrial_0c2120c1:


    orushi "Il semble qu’une alliance sans réflexion soit vouée à l’échec."


translate french revealtrial_cd2893ad:


    orushi "Joueur Ben. Il est temps de révéler ce que vous tenez."


translate french revealtrial_ac36ddb9:


    orushi "...Votre boîte est vide."


translate french revealtrial_72ed8d85:


    ben "Sérieusement ?!"


translate french revealtrial_f1d5bc35:


    mac "T’as pris celle de Kira, espèce d’idiot..."


translate french revealtrial_2b2d5a4b:


    ben "Non ! C’était la tienne, pas celle de Kira !"


translate french revealtrial_f5b77199:


    beth "On devrait leur donner un jeton par pitié."


translate french revealtrial_e6242f29:


    orushi "Inattention. Confusion. Peu importe comment vous l’appelez, le résultat est toujours le même."


translate french revealtrial_c48f2526:


    orushi "Joueuse Elizabeth. À vous."


translate french revealtrial_9e1e3719:


    orushi "Qualifiée."


translate french revealtrial_ecf3d79e:


    beth "Évidemment."


translate french revealtrial_b72c5297:


    ruby "Tu as vérifié Hector au début. Tu as compris ce qu’il se passait ?"


translate french revealtrial_f353fcf0:


    beth "J’ai vite vu qu’il y avait un problème dans notre groupe. Alors je l’ai corrigé."


translate french revealtrial_71bc0f38:


    dpense "Elle s’est retournée contre sa propre équipe. Froid. Calculé."


translate french revealtrial_9cf9f448:


    emerick "Traîtresse."


translate french revealtrial_18712cea:


    beth "Disons que je préfère miser sur l’intelligence plutôt que sur l’arrogance."


translate french revealtrial_ecf3d79e_1:


    beth "Évidemment."


translate french revealtrial_44a16e27:


    ruby "Tu avais vérifié Grace…"


translate french revealtrial_5e0488cd:


    beth "Oui. Toujours miser sur le rouge."


translate french revealtrial_f5a4af3c:


    dpense "Toujours aussi égocentrique. Mais efficace."


translate french revealtrial_f58573e9:


    orushi "Joueuse Julia. C’est à vous."


translate french revealtrial_e8ed82ca:


    orushi "…Il y a un jeton dans votre boîte."


translate french revealtrial_5bfa8e2b:


    ruby "Tu avais vérifié Ben, non ?"


translate french revealtrial_d1e1e790:


    julia "Oui."


translate french revealtrial_4b52c79e:


    ruby "Alors pourquoi tu n’es pas allée contre Kira ?"


translate french revealtrial_d1f70c04:


    julia "..."


translate french revealtrial_f31b8708:


    dpense "Il y a quelque chose qui cloche…"


translate french revealtrial_37d8e615:


    orushi "Joueuse Ruby. À vous."


translate french revealtrial_2dc2021c:


    orushi "Vous êtes qualifiée."


translate french revealtrial_e9754cba_1:


    ruby "..."


translate french revealtrial_8e9ab4e7:


    dpense "Elle semble figée… comme si elle s’attendait au pire."


translate french revealtrial_3193c932:


    mad "Tu l’as fait !"


translate french revealtrial_0f2c1293:


    ruby "J… j’ai réussi ?"


translate french revealtrial_85ff042c:


    d "Oui. Tu avais la boîte d’Emerick, non ?"


translate french revealtrial_7c8879d6:


    ruby "C’est lui qui a pris la mienne… Mais j’ai gardé la sienne. Et je n’ai jamais su si…"


translate french revealtrial_94b8d948:


    ruby "Quand j’ai aidé Madison, j’ai juste accepté mon sort. Je pensais que ça ne serait pas moi."


translate french revealtrial_87ad4670:


    mad "Tu as tout déchiré, Ruby."

translate french revealtrial_c270dc58:


    ruby "Je n’arrive pas à y croire..."


translate french revealtrial_9013017e:


    ruby "J’ai vraiment réussi à…"


translate french revealtrial_cd027434:


    orushi "Une joueuse altruiste, et perspicace."


translate french revealtrial_aa20706b:


    orushi "Mais même les meilleurs choix reposent parfois sur un peu de chance."


translate french revealtrial_1b038fdd:


    orushi "Joueur [name]. À vous."


translate french revealtrial_d0a04df4:


    dpense "Nous y voilà."


translate french revealtrial_2b78399e:


    dpense "J’espère que je n’ai pas fait une erreur."


translate french revealtrial_46aadbcb:


    dpense "Ils me regardent tous..."


translate french revealtrial_05392ae5:


    dpense "Je ne peux pas échouer maintenant..."


translate french revealtrial_3197b306:


    orushi "…Il y a un jeton dans votre boîte."


translate french revealtrial_11b6e570:


    d "Oui !"


translate french revealtrial_b1934d1a:


    ruby "Tu l’as fait !"


translate french revealtrial_31063061:


    orushi "Parfois, le coup le plus intelligent… c’est de ne pas trop jouer."


translate french revealtrial_ac36ddb9_1:


    orushi "…Votre boîte est vide."


translate french revealtrial_717cf009:


    d "Merde..."


translate french revealtrial_24b7c379:


    ruby "Toi… Pourquoi tu l’as échangée avec lui ?"


translate french revealtrial_520730bb:


    d "Je pensais que Mac ou Ben avaient peut-être plus de chances..."


translate french revealtrial_b0cd8174:


    sofia "Non… !"


translate french revealtrial_88a75c4d:


    sofia "NON !"


translate french revealtrial_70206759:


    sofia "Je ne le laisserai pas partir comme ça !"


translate french revealtrial_5dced416:


    orushi "Hmm ?"


translate french revealtrial_69d62481:


    sofia "J’ai une option de Sacrifice inscrite sur mon jeton."


translate french revealtrial_5d296f3e:


    orushi "..."

translate french revealtrial_71eb5446:


    orushi "Je m’y attendais. Ce jeton n’a été donné qu’à un seul joueur."


translate french revealtrial_07cb4710:


    orushi "Le jeton de Sacrifice. Il peut être utilisé une fois, pour donner votre place à un autre joueur éliminé."


translate french revealtrial_f452c162:


    orushi "C’est un acte définitif. Est-ce vraiment votre souhait ?"


translate french revealtrial_a7f852ab:


    sofia "S’il te plaît… Je veux que tu restes avec moi."


translate french revealtrial_e2ac8e66:


    d "Sofia..."


translate french revealtrial_f195c7ff:


    d "Tu te rends compte de ce que ça implique ?"


translate french revealtrial_d0eb6209:


    sofia "Oui. Mais je me fiche d’être la meilleure si c’est pour être seule."


translate french revealtrial_5d296f3e_1:


    orushi "..."


translate french revealtrial_2bf1f1d9:


    orushi "Joueuse Sofia, vous avez fait preuve d’un dévouement rare."


translate french revealtrial_9debc0ee:


    orushi "Ce jeu ne repose pas uniquement sur l’intelligence ou la stratégie."


translate french revealtrial_bad6979e:


    orushi "C’est aussi un test de ce que vous êtes prêt à sacrifier pour les autres."


translate french revealtrial_114ae86f:


    orushi "Aujourd’hui, vous avez montré que les récompenses ne vous tentent pas…"


translate french revealtrial_56ed9463:


    orushi "Mais plutôt que vous souhaitez soutenir et aider ceux qui vous entourent."


translate french revealtrial_09d1ab31:


    orushi "Vous êtes immédiatement qualifiée et l’immunité est votre récompense pour cet acte."


translate french revealtrial_df4d3d01:


    ruby "Wow."


translate french revealtrial_3a43fcc0:


    orushi "Mais il y a toujours une contrepartie."


translate french revealtrial_b279dc41:


    orushi "Je vous l’expliquerai plus tard."


translate french revealtrial_f5996909:


    orushi "[name]..."


translate french revealtrial_357a3333:


    orushi "Vous continuez."


translate french revealtrial_325e86c7:


    dpense "Je suis encore là grâce à elle."


translate french revealtrial_25bb462a:


    dpense "Et ça aurait pu lui coûter tout."


translate french revealtrial_2774b746:


    orushi "Vous êtes éliminé."


translate french revealtrial_ac36ddb9_2:


    orushi "…Votre boîte est vide."


translate french revealtrial_2c536cc9:


    d "Merde..."


translate french revealtrial_7ea8f2bd:


    ruby "Je… Je me suis trompée…"


translate french revealtrial_16b3b1d0:


    ruby "Je pensais qu’il bluffait, mais il a choisi exprès une boîte sans jeton pour te piéger."


translate french revealtrial_72a7b667:


    ruby "Je t’ai fait perdre…"

translate french revealtrial_82292ffe:


    d "Tu ne pouvais pas savoir…"


translate french revealtrial_a81f7dcc:


    emerick "On ne gagne pas à ce jeu en suivant son cœur."


translate french revealtrial_ecb0e7fe:


    emerick "Il faut toujours penser un coup d’avance."


translate french revealtrial_b0cd8174_1:


    sofia "Non...!"


translate french revealtrial_88a75c4d_1:


    sofia "NON !"


translate french revealtrial_70206759_1:


    sofia "Je ne le laisserai pas partir comme ça !"


translate french revealtrial_5dced416_1:


    orushi "Hmm ?"


translate french revealtrial_69d62481_1:


    sofia "J’ai une option Sacrifice inscrite sur mon jeton."


translate french revealtrial_5d296f3e_2:


    orushi "..."


translate french revealtrial_71eb5446_1:


    orushi "Je m’y attendais. Ce jeton n’a été donné qu’à un seul joueur."


translate french revealtrial_07cb4710_1:


    orushi "Le jeton Sacrifice. Il peut être utilisé une fois, pour donner ta place à un autre joueur éliminé."


translate french revealtrial_f452c162_1:


    orushi "C’est un acte final. Est-ce vraiment ton souhait ?"


translate french revealtrial_a7f852ab_1:


    sofia "S’il te plaît… Je veux que tu restes avec moi."


translate french revealtrial_e2ac8e66_1:


    d "Sofia..."


translate french revealtrial_f195c7ff_1:


    d "Tu réalises ce que ça signifie ?"


translate french revealtrial_d0eb6209_1:


    sofia "Oui. Mais je me fiche d’être la meilleure si c’est pour être seule."


translate french revealtrial_5d296f3e_3:


    orushi "..."


translate french revealtrial_2bf1f1d9_1:


    orushi "Joueuse Sofia, tu as montré une forme de dévouement rare."


translate french revealtrial_9debc0ee_1:


    orushi "Ce jeu ne se résume pas à l’intelligence ou à la stratégie."


translate french revealtrial_bad6979e_1:


    orushi "C’est aussi un test de ce que tu es prête à sacrifier pour les autres."


translate french revealtrial_114ae86f_1:


    orushi "Aujourd’hui, tu as montré que tu n’es pas tentée par les récompenses…"


translate french revealtrial_56ed9463_1:


    orushi "Mais plutôt que tu veux élever et aider ceux qui t’entourent."


translate french revealtrial_09d1ab31_1:


    orushi "Tu es immédiatement qualifiée et ton immunité est la récompense pour cet acte."


translate french revealtrial_df4d3d01_1:


    ruby "Wow."


translate french revealtrial_3a43fcc0_1:


    orushi "Mais il y a toujours une contrepartie."


translate french revealtrial_b279dc41_1:


    orushi "Je t’expliquerai plus tard."

translate french revealtrial_f5996909_1:


    orushi "[name]..."


translate french revealtrial_357a3333_1:


    orushi "Tu continues."


translate french revealtrial_325e86c7_1:


    dpense "Je suis encore ici grâce à elle."


translate french revealtrial_25bb462a_1:


    dpense "Et ça aurait pu lui coûter tout."


translate french revealtrial_2774b746_1:


    orushi "Tu es éliminé."


translate french revealtrial_3197b306_1:


    orushi "…Il y a un jeton dans ta boîte."


translate french revealtrial_23148e2c:


    d "Ouf... ça a marché."


translate french revealtrial_00153084:


    ruby "Bien joué !"


translate french revealtrial_bf6e0ecb:


    orushi "Ton choix était le bon. Tu passes à l’étape suivante."

translate french strings:


    old "Exchange"
    new "Échanger"


    old "She will remember that."
    new "Elle s’en souviendra."


translate french strings:


    old "NOTHING..."
    new "RIEN..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
