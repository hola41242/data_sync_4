


translate french e5s1_8637f884:


    d "RUBYYYYYYYYYYYYYY !"


translate french e5s1_920afafe:


    ruby "AHHHHH !"


translate french e5s1_4b54f67f:


    ruby "AÏE !"


translate french e5s1_038c54a1:


    ruby "Quoi ? Qu’est-ce qui vient de se passer ?!"


translate french e5s1_f9c7f0b0:


    d "Tu vas bien ?"


translate french e5s1_c7a35f1f:


    ruby "Euh... Oui, je crois."


translate french e5s1_c3641176:


    d "Tu allais te faire renverser par cette voiture. Je devais intervenir."


translate french e5s1_fe53a24b:


    ruby "Tu... tu as risqué ta vie pour moi ?"


translate french e5s1_b58b165f:


    d "Je pouvais pas rester là à te regarder."


translate french e5s1_55a5a4af:


    ruby "Je comprends pas… t’es sorti de nulle part. C’est comme si le temps s’était arrêté."


translate french e5s1_7fd570da:


    d "Je ne veux pas qu'il t'arrives quoi que ce soit."


translate french e5s1_8899f6e3:


    ruby "Mais… tu aurais pu être blessé. Pourquoi prendre un tel risque ?"


translate french e5s1_f5688640:


    d "Parce que tu comptes pour moi, Ruby."


translate french e5s1_f8bebc6f:


    ruby "…"


translate french e5s1_1e1258b6:


    d "Attends... Où est Emerick ?"


translate french e5s1_30ab2173:


    ruby "Je sais pas..."


translate french e5s1_825fa3a7:


    d "Enfoiré..."


translate french e5s1_b63f180b:


    d "Viens, je te raccompagne à ta chambre. Je veux m’assurer que tu es en sécurité."


translate french e5s1_8ae3f02b:


    ruby "Merci."


translate french e5s1_e8b6b321:


    emerick "Tu les as ratés !!!"


translate french e5s1_6c99bf40:


    hec "Je pouvais pas lui rouler dessus !"


translate french e5s1_1264cc36:


    emerick "Putain de Frenchy..."


translate french e5s1_3d7614a7:


    ruby "Merci de m’avoir raccompagnée. Je… je n’arrive pas à oublier ce qui s’est passé. J’étais si proche de..."


translate french e5s1_f11fc35f:


    d "Hé, hé… respire. Tu es en sécurité maintenant. C’est tout ce qui compte."


translate french e5s1_432a0fd3:


    ruby "Mais si je ne l’avais pas été ? Si tu n’étais pas arrivé à temps…"


translate french e5s1_d4906513:


    d "Ne pense pas à ça. J’étais là. J’ai vu ce qui se passait, et je n’allais pas te laisser être blessée."


translate french e5s1_e1af90f3:


    ruby "Tu sembles toujours savoir quand j’ai besoin de toi. Comment tu… comment tu fais ça ?"


translate french e5s1_70fe1779:


    d "C’est pas une question de savoir. C’est juste…"


translate french e5s1_8206e8f8:


    d "Tu comptes pour moi, Ruby. Je pouvais pas rester là à te regarder en danger."


translate french e5s1_81c69a08:


    d "Aïe !"


translate french e5s1_71b81e18:


    ruby "Tu as mal ?"


translate french e5s1_2d514ee4:


    d "Juste un petit bleu dans le dos. T’en fais pas. C’est rien."


translate french e5s1_11d44732:


    d "Tu es importante pour moi. Je suis content que tu sois en sécurité maintenant."


translate french e5s1_a2169b7c:


    ruby "Tu ne sais pas ce que ça représente pour moi. Vraiment. Je…"


translate french e5s1_3e72968c:


    mad "Qu’est-ce qui s’est passé ?!"


translate french e5s1_907147a6:


    ruby "Madison !"


translate french e5s1_0fb8a98c:


    mad "Qu’est-ce que t’as foutu ?! Qu’est-ce qui lui est arrivé ?!"


translate french e5s1_eabb95e2:


    ruby "Arrête ! Il m’a rien fait."


translate french e5s1_83e0d8d4:


    mad "Alors pourquoi t’es dans cet état ? Je vois bien que t’es secouée."


translate french e5s1_1728ff72:


    ruby "C’était Emerick. Il m’a poussée sur la route… et [name] m’a sauvée."


translate french e5s1_3cab6c49:


    ruby "S’il n’avait pas été là…"


translate french e5s1_12cc4401:


    mad "Emerick ? T’es sérieuse ? Quel enfoiré !"


translate french e5s1_2570fab1:


    mad "Je le crois pas. À chaque fois, il trouve un moyen de nous pourrir la vie, de blesser les gens que j’aime."


translate french e5s1_2e1eba66:


    ruby "Madison, calme-toi. C’est fini maintenant…"


translate french e5s1_37657869:


    mad "Non, c’est pas fini. J’en ai marre qu’il pense pouvoir faire tout ce qu’il veut."


translate french e5s1_b517a095:


    mad "Marre qu’il nous traite comme si on était rien."


translate french e5s1_470b72d8:


    d "Je sais que tu es en colère, Madison, mais prends une seconde…"


translate french e5s1_ac434fb3:


    mad "Une seconde pour quoi ? Pour le laisser encore nous écraser ? Non. Plus maintenant."


translate french e5s1_5e7a1a65:


    mad "Je le laisserai plus blesser qui que ce soit."


translate french e5s1_fd8fbac7:


    ruby "Madi, t’as pas besoin de..."


translate french e5s1_bad2ad5b:


    mad "Non. Je trouverai un moyen. J’irai jusqu’à la Tour Orushi s’il le faut. Je déterrerai quelque chose sur lui, n’importe quoi pour le faire payer."


translate french e5s1_66cfc5ef:


    mad "C’est juste que… je suis tellement soulagée que tu ailles bien. Quand j’ai vu ton message, j’ai cru que…"


translate french e5s1_c405af79:


    mad "Je peux pas te perdre, Ruby. Je peux pas."


translate french e5s1_ed939cdf:


    ruby "Tu ne me perdras pas. Je suis là. Je vais bien, grâce à lui."


translate french e5s1_ed6663f6:


    mad "[name]... Merci infiniment. De l’avoir sauvée."


translate french e5s1_a030f1cc:


    d "Je pouvais pas la laisser se faire blesser."


translate french e5s1_be37c700:


    d "Je vais vous laisser un moment. Faites-moi signe si vous avez besoin de quoi que ce soit."


translate french e5s1_9ccfef56:


    ruby "Merci encore. Pour tout."


translate french e5s1_55428f52:


    mad "Oui. Merci."


translate french e5s1_65f68525:


    d "Qu’est-ce qui s’est passé, bordel ?"


translate french e5s1_f22927de:


    d "Emerick... Cette fois, il est allé trop loin. Il a poussé Ruby sur la route…"


translate french e5s1_dc85aaa9:


    d "Rien que d’y penser, ça me rend malade."


translate french e5s1_6c0648a2:


    d "Et Madison... elle était furieuse, et je la comprends."


translate french e5s1_d52744de:


    d "Elle tient autant à Ruby que moi. Je dois l’aider à s’en occuper."


translate french e5s1_bc37c3ae:


    d "Emerick ne peut pas s’en sortir comme ça."


translate french e5s1_67fd8c9a:


    d "Mais ce moment-là…"


translate french e5s1_63201803:


    d "Quand j’ai vu Ruby en danger, quelque chose s’est passé en moi. J’ai ressenti un élan…"


translate french e5s1_319f03eb:


    d "Comme si tout mon corps s’était réveillé, plus rapide que je ne l’aurais jamais cru."


translate french e5s1_ab6a92fc:


    d "Mon esprit était complètement clair, sans hésitation, sans doute."


translate french e5s1_60d891a3:


    d "J’ai eu l’impression… de ne pas être totalement moi-même. Comme si j’avais puisé dans quelque chose que j’ignorais."


translate french e5s1_5c347b7d:


    d "Mais quoi que ce soit, ça m’a permis de la sauver."


translate french e5s1_865436fc:


    d "Et c’est tout ce qui compte maintenant."


translate french e5s1_51325e82:


    d "Ruby… Je crois que j’avais jamais réalisé à quel point elle comptait pour moi."


translate french e5s1_45049fa3:


    d "Avant, c’était juste quelqu’un que je connaissais, qui était là. Mais maintenant… c’est différent."


translate french e5s1_cf2a24fa:


    d "Comme si je commençais vraiment à la voir pour qui elle est."


translate french e5s1_f9e11963:


    d "Forte, gentille, quelqu’un en qui je peux avoir confiance. Elle devient plus qu’un visage familier."


translate french e5s1_e5f54a54:


    d "Elle devient…"


translate french e5s1_62fb39a8:


    d "Hum ?"


translate french e5s1_1f1620be:


    d "Ça va être amusant !"


translate french e5s1_7984b7ea:


    d "Encore ?"


translate french e5s1_866e135e:


    d "Je dois contacter cette mystérieuse femme du Palazio..."


translate french e5s1_25f6c8e6:


    d "Voyons un peu mon téléphone avant la nuit..."


translate french e5s1_366d00ed:


    d "Je pourrais envoyer un message à Julia et lui proposer d'aller boire un verre..."


translate french e5s1_ccda9b9f:


    d "Red est peut-être dispo..."


translate french fine5s1_084c58a1:


    d "Je n’ai plus qu’à attendre…"


translate french juliaphonep5intro_5545b2c5:


    d "Moment parfait pour passer un peu de bon temps avec elle."


translate french redphonep5intro_f0a39379:


    "La prochaine fois : parler directement d’Emerick..."


translate french redep5s1_bd5a25f2:


    beth "Alors c’est ici que tu te caches après avoir joué les héros ?"


translate french redep5s1_a1a48b13:


    dpense "Beth. Toujours prête à lancer des piques."


translate french redep5s1_3f224c48:


    d "Je ne me cache pas. Je me repose, c’est tout."


translate french redep5s1_0deb3c11:


    beth "Bien sûr. Un noble chevalier a toujours besoin de reprendre son souffle après avoir sauvé une demoiselle en détresse."


translate french redep5s1_64e6437c:


    d "Si tu es là juste pour te moquer, tu peux repartir."


translate french redep5s1_ffbb90f6:


    beth "Pourquoi partir alors que je peux profiter du spectacle ?"


translate french redep5s1_05179a5e:


    d "C’est ça, ta vision de la compassion ?"


translate french redep5s1_8b8dfbb6:


    beth "La compassion, c’est pour les faibles. Il te faut quelqu’un pour te rappeler comment jouer sans tomber dans les pièges les plus évidents."


translate french redep5s1_e8de084b:


    d "Et toi, tu es quoi ? Une stratège hors pair ? Une experte en jeux de pouvoir ?"


translate french redep5s1_5e26d9f6:


    beth "Je suis clairement meilleure que toi."


translate french redep5s1_d4785663:


    beth "Alors, qu’est-ce qui s’est vraiment passé là-bas ?"


translate french redep5s1_179aeac0:


    d "Emerick a poussé Ruby sur la route. Si je n’étais pas intervenu…"


translate french redep5s1_666292af:


    beth "Évidemment que tu t’es précipité pour la sauver. Mais Emerick n’agit jamais sans raison."


translate french redep5s1_0f4ff2fd:


    beth "Tu crois vraiment que ton petit acte héroïque suffira ? Emerick ne va pas laisser passer ça, tu sais."


translate french redep5s1_54274ac2:


    dpense "Elle semble le connaître mieux que je ne le pensais."


translate french redep5s1_2c3a63c7:


    d "Qu’est-ce que tu veux dire ?"


translate french redep5s1_2a80a354:


    beth "Emerick sait que ce genre de chose peut se retourner contre lui. Donc s’il a agi, c’est qu’il avait un plan."


translate french redep5s1_35959abf:


    beth "La question c’est : pourquoi maintenant ?"


translate french redep5s1_6427f2c4:


    d "Je ne sais pas. Je n’y ai pas pensé. Je voulais juste que Ruby soit en sécurité."


translate french redep5s1_43306920:


    beth "Et c’est exactement ce sur quoi il comptait : une réaction impulsive."


translate french redep5s1_419f2773:


    beth "Tu comprends pas, hein ? Emerick n’est pas juste un fauteur de troubles. Il calcule tout."


translate french redep5s1_4f90d58f:


    beth "Pendant les championnats d’athlétisme, il a falsifié des résultats, soudoyé des officiels, même intimidé d’autres concurrents."


translate french redep5s1_87dac044:


    beth "Tout pour gagner. Et maintenant, tu es devenu sa nouvelle cible."


translate french redep5s1_bc2e5f67:


    dpense "Falsifier des résultats ? Soudoyer des officiels ? Ce type recule devant rien."


translate french redep5s1_6d4a814f:


    dpense "Donc c’est ça, mon adversaire ? Un mec qui joue à un jeu dont je ne connais même pas les règles…"


translate french redep5s1_277cda4c:


    d "Et maintenant il me vise ? Pourquoi ? Je suis personne."


translate french redep5s1_7a238ca9:


    beth "Pas encore. Mais tu es nouveau, inattendu. Et Emerick déteste les surprises."


translate french redep5s1_e9e5081e:


    beth "Tu es une variable inconnue dans son petit plan."


translate french redep5s1_691bd06e:


    beth "C’est pour ça qu’il va tout faire pour te rendre prévisible, te mettre dans des situations où il contrôle toutes les pièces."


translate french redep5s1_cb07a3df:


    dpense "Prévisible… C’est donc ça son objectif. Il veut que je réagisse exactement comme il s’y attend."


translate french redep5s1_e272ec68:


    d "Donc si je comprends bien, je dois faire l’inverse de ce qu’il attend."


translate french redep5s1_5295505f:


    beth "Pas seulement. Tu dois le surprendre. Faire quelque chose qu’il n’a pas anticipé. C’est comme ça que tu le déstabiliseras."


translate french redep5s1_b8e76d53:


    d "Pourquoi il aurait fait ça ? Il n’avait rien à gagner ce soir."


translate french redep5s1_e7d5988c:


    beth "C’est bien le problème. Il ne fait jamais rien sans raison. Tout ce qu’il fait a un but."


translate french redep5s1_a7fe4640:


    beth "Et maintenant, il sait que tu es impulsif. Tu n’es qu’une pièce de plus qu’il peut manipuler."


translate french redep5s1_f1ffa118:


    dpense "Un pion ? Si c’est vrai, alors je suis déjà en retard."


translate french redep5s1_d7428c05:


    d "Qu’est-ce que je suis censé faire, alors ?"


translate french redep5s1_69262bbf:


    beth "Ouvre les yeux. Observe ses schémas. Emerick adore provoquer les gens, les faire réagir."


translate french redep5s1_3c3dd45b:


    beth "Si tu veux lui tenir tête, tu dois comprendre ses mouvements avant qu’il ne les fasse."


translate french redep5s1_2f536003:


    beth "Et surtout, arrête de foncer tête baissée. C’est exactement ce qu’il veut."


translate french redep5s1_c23626b7:


    beth "La prochaine fois, réfléchis avant d’agir. Recule d’un pas et demande-toi : qu’est-ce qu’il gagne à me faire bouger ?"


translate french redep5s1_b357f90b:


    d "Et si je vois qu’il prépare encore un coup, je fais quoi ?"


translate french redep5s1_63193259:


    beth "Une fois que tu comprends comment il fonctionne, tu peux le prendre de court avec quelque chose qu’il n’aura pas vu venir."


translate french redep5s1_0a365651:


    beth "Tu es frustrant à regarder parfois. Tu réalises même pas ton propre potentiel."


translate french redep5s1_ed007cdb:


    d "Et pourtant, c’est en étant frustrant que je suis encore là, à te tenir tête."


translate french redep5s1_83ad7adf:


    beth "Me tenir tête ? Tu te défends à peine. Mais c’est mignon de te voir essayer."


translate french redep5s1_f9db8479:


    d "Peut-être que je te laisse croire que tu as le dessus."


translate french redep5s1_3f8f506a:


    beth "Ah oui ? Dans ce cas, prouve-le. Montre-moi que tu peux me surprendre."


translate french redep5s1_ecadf76a:


    d "Et si je te disais que je suis prêt à te surprendre maintenant ?"


translate french redep5s1_ff86c84c:


    beth "Alors arrête de parler. Fais-le."


translate french redep5s1_1015556c:


    d "Si je joue selon tes règles… qu’est-ce que j’y gagne ?"


translate french redep5s1_5625aa6e:


    beth "Tu ne me surprendras jamais si tu respectes les règles."


translate french redep5s1_579d49d7:


    beth "Tu devrais plutôt te demander ce que tu risques… plutôt que ce que tu gagnes."


translate french redep5s1_d78e9edb:


    d "Et si je suis prêt à prendre ce risque ?"


translate french redep5s1_4e6027c9:


    beth "Alors prends-le. Tu attends toujours qu'on te dise quoi faire ?"


translate french redep5s1_f6aa457e:


    d "Alors laisse-moi te le prouver."


translate french redep5s1_b6d3aa81:


    beth "C'est ce que j'attends."


translate french redep5s1_e3319f89:


    d "Je peux faire bien plus que parler."


translate french redep5s1_6bf8e144:


    beth "Oh, je n’en doute pas. Mais ça ne veut pas dire que je vais te faciliter les choses."


translate french redep5s1_4723bed9:


    d "Je ne cherche pas la facilité."


translate french redep5s1_f1f0ba53:


    beth "Parfait. Parce que tu n’auras rien gratuitement. Si tu veux quelque chose, il faudra le mériter."


translate french redep5s1_0fc5a3c2:


    d "Et qu’est-ce que je dois faire pour ça ?"


translate french redep5s1_4eec1a25:


    beth "D’abord, montre-moi que tu peux garder ton sang-froid sous pression. Ensuite, prouve que tu peux me suivre, peu importe où je t’emmène."


translate french redep5s1_fdd23a56:


    d "Peu importe où ?"


translate french redep5s1_54180c37:


    beth "Exactement. Et souviens-toi, je n’attends rien de moins que le meilleur de toi."


translate french redep5s1_6570101e:


    beth "Tu penses vraiment être prêt à tout pour me surprendre ?"


translate french redep5s1_43cf3130:


    d "Oui. Et je vais te le prouver."


translate french redep5s1_d3696ed0:


    beth "Hmm… intéressant. Penser que tu peux le faire, c’est une chose. Le faire, c’en est une autre."


translate french redep5s1_4629cd14:


    d "Alors donne-moi une chance."


translate french redep5s1_1ee273de:


    beth "Et si tu échoues ? Es-tu prêt à en payer le prix ?"


translate french redep5s1_cc118cbe:


    d "Je n’échouerai pas."


translate french redep5s1_04bb258a:


    beth "Vraiment ? Tu as l’air sûr de toi. Mais je vois une lueur de doute. Juste là."


translate french redep5s1_40e44cbd:


    d "Regarde de plus près. Je n’hésite pas."


translate french redep5s1_cb9c376f:


    beth "C’est ce qu’on va découvrir."


translate french redep5s1_5d7e26e7:


    beth "Tu pensais vraiment pouvoir me surprendre ? Regarde-toi maintenant… complètement à ma merci."


translate french redep5s1_90848652:


    d "Peut-être que c’est exactement là où je voulais être."


translate french redep5s1_c38e04e4:


    beth "Ce n’est pas vraiment une surprise."


translate french redep5s1_4b505b9c:


    beth "C’est moi qui contrôle ici. Le rythme, l’intensité… et tu vas suivre."


translate french redep5s1_43b49e4c:


    d "D'accord."


translate french redep5s1_89fd0caf:


    beth "Pas 'd'accord'. Dis 'Oui, madame.'"


translate french redep5s1_7f92de3e:


    d "Oui, madame."


translate french redep5s1_508e1423:


    beth "Bien. Maintenant, montre-moi."


translate french redep5s1_367faa66:


    beth "Tu dis que tu es prêt à prendre des risques. Mais les mots ne suffisent pas. Dis-le autrement."


translate french redep5s1_c835d103:


    d "Je suis prêt."


translate french redep5s1_3ac72b58:


    beth "Faux. Dis-le correctement."


translate french redep5s1_7f92de3e_1:


    d "Oui, madame."


translate french redep5s1_2929943c:


    beth "Bien. Maintenant, prouve-le."


translate french redep5s1_0ae9bcd0:


    ""


translate french redep5s1_63e6442b:


    beth "Pas mal… mais tu peux faire mieux."


translate french redep5s1_49b0745e:


    d "Je vais te montrer que je peux gérer ça."


translate french redep5s1_7fd37676:


    beth "Je te donne une chance. Ne la gâche pas."


translate french redep5s1_0ae9bcd0_1:


    ""


translate french redep5s1_bfae3d79:


    beth "Reste avec moi. Maintenant."


translate french redep5s1_a19cd18e:


    beth "Pas mal… pour un début."


translate french redep5s1_7ffab912:


    beth "Souviens-toi de ce que j’ai dit : rien n’est jamais garanti. Pas avec moi."


translate french redep5s1_b6f416e6:


    d "Elle joue un jeu différent… et je ne sais toujours pas si je gagne ou si je perds."


translate french juliaep5s1_4d6f6272:


    d "Salut, Julia ! J’espère que je ne t’ai pas fait trop attendre."


translate french juliaep5s1_ab7fe98c:


    julia "Pas du tout. Je viens juste d’arriver. Assieds-toi."


translate french juliaep5s1_a720956f:


    d "Merci. Cet endroit est sympa. Je suis passé devant plusieurs fois, mais je ne suis jamais rentré."


translate french juliaep5s1_f626e85d:


    julia "J’y viens de temps en temps. C’est chaleureux, pas trop bruyant, et ils ont de très bonnes bières. Et en plus, c’est proche du boulot."


translate french juliaep5s1_3fbe4498:


    d "Parfait. Qu’est-ce qui est bon ici ?"


translate french juliaep5s1_3786780c:


    julia "Je te conseille la pression de la maison !"


translate french juliaep5s1_ea3bf1c0:


    d "D’accord, je te fais confiance. Je vais essayer."


translate french juliaep5s1_d0682263:


    julia "Alors, quoi de neuf ? Encore des histoires folles dont je devrais être au courant ?"


translate french juliaep5s1_672e8d69:


    d "Eh bien, il s’est passé quelque chose récemment qui me trotte dans la tête."


translate french juliaep5s1_098aaba0:


    julia "Oh ? Qu’est-ce qu’il se passe ?"


translate french juliaep5s1_3197a1bb:


    d "C’est à propos d’Emerick. Il a poussé Ruby sur la route. C’était vraiment limite."


translate french juliaep5s1_c28cc0bf:


    julia "Ruby ? Elle va bien, j’espère ?"


translate french juliaep5s1_d528fd6b:


    d "Oui, elle va bien maintenant. Mais ça m’a vraiment fait réaliser jusqu’où il est prêt à aller."


translate french juliaep5s1_9ee238f4:


    julia "C’est horrible. J’arrive pas à croire que quelqu’un puisse aller aussi loin."


translate french juliaep5s1_dcc960b9:


    julia "Et toi ? Tu vas bien après tout ça ?"


translate french juliaep5s1_82e390d5:


    d "Je vais bien. C’est juste que… ça m’a fait réfléchir à comment gérer les choses la prochaine fois."


translate french juliaep5s1_2b47c55c:


    julia "Tu ne devrais pas avoir à gérer quelqu’un comme ça tout seul. On pourrait peut-être trouver une solution ensemble."


translate french juliaep5s1_aacfe805:


    julia "Bon, on a parlé un peu de mon boulot. Mais toi, alors ?"


translate french juliaep5s1_0e905200:


    d "Moi ? Quoi ?"


translate french juliaep5s1_7a0cb300:


    julia "Ben, je suis curieuse. Tu restes encore un peu un mystère pour moi."


translate french juliaep5s1_16c33588:


    julia "Comment est ta famille ? J’ai l’impression de ne pas savoir grand-chose sur d’où tu viens."

translate french juliaep5s1_9b6770e7:


    d "Ma famille est surtout militaire. Discipline, entraînement et ne jamais reculer. Voilà les leçons qu’on m’a apprises en grandissant."


translate french juliaep5s1_b3756bb1:


    julia "Ça ne devait pas être facile. Toujours devoir être à la hauteur de ces attentes."


translate french juliaep5s1_e7a3c9e3:


    d "Ce n’était pas toujours facile, mais ça m’a vraiment appris à affronter les difficultés."


translate french juliaep5s1_a74bd090:


    d "Des enseignants. L’éducation était primordiale chez moi. Ils valorisaient le savoir et m’encourageaient toujours à poser des questions."


translate french juliaep5s1_93891e8b:


    julia "C’est impressionnant. Ça devait être agréable d’avoir des gens qui croyaient en ton potentiel."


translate french juliaep5s1_f1ac7016:


    d "Il y avait de bons moments, mais la pression pour réussir était bien réelle."


translate french juliaep5s1_42dc9c2c:


    d "Je ne vois pas vraiment la famille de façon traditionnelle. Mes amis ont toujours été ma vraie famille."


translate french juliaep5s1_5caf3c73:


    julia "Je comprends. Parfois, ce sont les gens qu’on choisit qui comptent le plus."


translate french juliaep5s1_f8311687:


    d "Exactement. Ils ont toujours été là pour moi."


translate french juliaep5s1_70e7243c:


    d "J’ai dû tout apprendre par moi-même. Ma famille ne m’a pas vraiment donné d’avance, alors j’ai dû compter sur moi seul."


translate french juliaep5s1_d27239ad:


    julia "Ça a dû être difficile, mais on dirait que ça t’a rendu plus fort."


translate french juliaep5s1_0edfa3b6:


    d "Oui, ça m’a renforcé. Je suis reconnaissant pour les leçons que j’ai apprises en chemin."


translate french juliaep5s1_f48d95b7:


    julia "C’est intéressant d’en apprendre plus sur toi. J’ai l’impression de mieux te comprendre."


translate french juliaep5s1_a6186baf:


    d "Eh bien, je ne suis plus un si grand mystère alors."


translate french juliaep5s1_03f6cf39:


    julia "Peut-être pas, mais tu restes assez intrigant."


translate french juliaep5s1_cbac6963:


    d "Je pourrais dire la même chose de toi."


translate french juliaep5s1_8063219d:


    julia "Je suppose qu’on va devoir continuer à apprendre à se connaître, une conversation après l’autre."


translate french juliaep5s1_37df8703:


    julia "Tu penses vraiment qu’on peut tout gagner ? Le tournoi, la maison… tout ?"


translate french juliaep5s1_f148a045:


    d "C’est possible. Gagner, ce n’est pas seulement une question de talent. C’est aussi notre progression en tant qu’équipe."


translate french juliaep5s1_ed620926:


    d "Et j’ai l’impression que chaque match nous a rapprochés."


translate french juliaep5s1_e579b0fc:


    julia "C’est vrai. On voit vraiment à quel point tout le monde a progressé avec le temps."


translate french juliaep5s1_9a92dac8:


    julia "Cette maison… on dirait presque que c’est trop beau pour être vrai, non ? Comme un rêve inaccessible."


translate french juliaep5s1_10690dd7:


    d "Peut-être. Mais c’est le genre de rêve qui nous pousse à nous dépasser. Parfois, ce n’est pas juste la récompense qui compte."


translate french juliaep5s1_1c85033f:


    d "C’est aussi ce que ça fait de nous en chemin."


translate french juliaep5s1_84120d2a:


    julia "Et si on gagne… vivre tous ensemble dans un endroit comme ça… ce serait bizarre au début, non ?"


translate french juliaep5s1_913c6ae7:


    d "Au début, il faudra sûrement s’adapter. Mais je pense que ça nous apprendra à surmonter les défis ensemble."


translate french juliaep5s1_1225bdcc:


    julia "C’est rassurant d’entendre ça. Ça me rend plus confiante sur l’idée en général."


translate french juliaep5s1_0c5889f4:


    d "Ce sera une occasion d’apprendre les uns des autres. On vivra sous le même toit, on partagera nos idées et nos expériences."


translate french juliaep5s1_b704632a:


    julia "J’aime cette idée. On pourrait tous évoluer de façons inattendues."


translate french juliaep5s1_efecca29:


    d "Ce sera comme avoir un centre d’entraînement personnel. On aura tout ce qu’il faut pour rester au top et bien préparés."


translate french juliaep5s1_b5769240:


    julia "Tu penses toujours performance, hein ? Mais tu as raison. Ce serait un énorme avantage."


translate french juliaep5s1_f6a5f7f1:


    d "Ce sera fun. Il y aura des hauts et des bas, mais je pense que ça nous rapprochera comme jamais."


translate french juliaep5s1_55071f19:


    julia "Oui, je vois ce que tu veux dire. Ce sera peut-être un peu chaotique parfois, mais aussi vraiment spécial."


translate french juliaep5s1_77611e7a:


    d "Hey, Julia, je peux te poser une question un peu bizarre ?"


translate french juliaep5s1_e97b18ed:


    julia "Bien sûr. Qu’est-ce que tu as en tête ?"


translate french juliaep5s1_bf9b1e2f:


    d "Euh… je viens de créer une page OnlyStan. Et comme t’es là, je me suis dit que ce serait cool qu’on prenne une petite photo ensemble. Histoire de bien commencer."


translate french juliaep5s1_a9f49b0b:


    julia "Ta première photo ? Je ne te voyais pas du genre à faire ça. Elle parle de quoi, ta page ?"


translate french juliaep5s1_19e6c134:


    d "Pour être honnête, je l’ai surtout faite par curiosité. Fanny et Kira y sont, alors je voulais voir de quoi il s’agissait."


translate french juliaep5s1_2b14ba8c:


    d "Mais je me suis dit, pourquoi pas l’utiliser pour mes propres trucs ? Un truc plus décontracté."


translate french juliaep5s1_9c438131:


    julia "Donc, aucun contenu pour l’instant ? Ce serait ton tout premier post ?"


translate french juliaep5s1_3a725bb7:


    d "Ouais. Je tâtonne encore un peu, mais une photo avec toi, ce serait un super début. Un truc simple, sans pression."


translate french juliaep5s1_c4887bf8:


    julia "Pourquoi pas, après tout ?"


translate french juliaep5s1_a57d0efc:


    d "Faisons-en une belle."


translate french juliaep5s1_886abaf6:


    d "Wow !"


translate french juliaep5s1_1863f5f9:


    dpense "Parfait. Ça va rendre super bien sur ma page."


translate french juliaep5s1_4d155d2a:


    julia "Eh bien, tu commences fort. Tu penses continuer ?"


translate french juliaep5s1_6cf2bb35:


    d "On verra bien. Qui sait ? Peut-être que toi aussi, tu vas t’y mettre."


translate french juliaep5s1_d9dfa20b:


    julia "Pas si vite. On va déjà voir si la tienne vaut le coup d’être suivie."


translate french juliaep5s1_8b1d5c54:


    julia "Il est déjà tard. Je dois y aller."


translate french juliaep5s1_dd72b008:


    d "Je t’accompagne. Je n’ai pas envie que tu tombes sur un problème."


translate french juliaep5s1_5ac0d64c:


    julia "D’accord. Merci."


translate french juliaep5s1_231f5bec:


    julia "Merci de m’avoir raccompagnée. Ça faisait longtemps que je n’avais pas passé une soirée comme ça."


translate french juliaep5s1_c51ede48:


    d "C’était super de passer du temps avec toi. J’espère qu’on pourra refaire ça bientôt."


translate french juliaep5s1_2d141c15:


    julia "Moi aussi. Je me sens beaucoup plus détendue, grâce à toi."


translate french juliaep5s1_5cc17a98:


    d "C’était agréable de discuter. J’ai l’impression de mieux te comprendre maintenant."


translate french juliaep5s1_f6e0d13e:


    julia "C’est gentil. Moi aussi, j’ai appris plein de choses sur toi ce soir."


translate french juliaep5s1_e8be2aee:


    d "J’ai hâte d’être au prochain match. C’est génial de se dire qu’on vise quelque chose d’aussi grand tous ensemble."


translate french juliaep5s1_be275e87:


    julia "C’est rassurant de voir que tu es si concentré. Je vais essayer de suivre le rythme !"


translate french juliaep5s1_687f426a:


    d "Ça faisait longtemps que je ne m’étais pas senti aussi bien. Je suis vraiment content qu’on ait fait ça."


translate french juliaep5s1_e0e6383d:


    julia "Moi aussi. Je ressens la même chose."


translate french juliaep5s1_e424cf81:


    d "Ça me paraît juste..."


translate french juliaep5s1_60e205e5:


    julia "Oui... Ce n’est pas un volé cette fois."


translate french juliaep5s1_5769e4a9:


    d "Bonne nuit, Julia."


translate french juliaep5s1_5dfa7b90:


    julia "Bonne nuit, [name]."


translate french strings:


    old "Hey you!"
    new "Hey toi !"


    old "Hey, babe."
    new "Hey, bébé."


    old "What are you doing tomorrow morning?"
    new "Tu fais quoi demain matin ?"


    old "Not sure yet. Why? You planning something?"
    new "Je sais pas encore. Pourquoi ? Tu prévois un truc ?"


    old "I remember you saying you’d done some climbing before, right?"
    new "Je me souviens que tu avais déjà fait de l'escalade, non ?"


    old "Yeah, I have. Thinking of trying it too?"
    new "Oui, c’est vrai. Tu veux t’y mettre toi aussi ?"


    old "Mmhmm. I found this amazing climbing spot. I thought it might be fun for us to go together."
    new "Mmhmm. J’ai trouvé un super endroit pour grimper. Je me suis dit que ce serait sympa d’y aller ensemble."


    old "Climbing with you? That sounds pretty good."
    new "Grimper avec toi ? Ça me tente bien."


    old "So, what do you say?"
    new "Alors, qu’est-ce que t’en dis ?"


    old "Sure, let’s do it."
    new "Carrément, allons-y."


    old "Alright, I’m in. What time?"
    new "OK, je suis partant. À quelle heure ?"


    old "How about 7 a.m.? I’ll have everything ready for us."
    new "Disons 7h ? Je m’occupe de tout préparer."


    old "Sounds perfect. Looking forward to spending the morning with you."
    new "Parfait. Hâte de passer la matinée avec toi."


    old "Same here. Miss you."
    new "Moi aussi. Tu me manques."


    old "Miss you too, Grace."
    new "Toi aussi, tu me manques, Grace."


    old "Sorry, I’m not free."
    new "Désolé, je ne suis pas dispo."


    old "Sorry, babe, I’ve got something tomorrow morning."
    new "Désolé, bébé, j’ai un truc demain matin."


    old "Oh… okay. Another time then?"
    new "Oh… d’accord. Une autre fois alors ?"


    old "Of course. Let’s plan it soon."
    new "Bien sûr. On se cale ça bientôt."


    old "Hey there!"
    new "Salut !"


    old "Hey Grace."
    new "Salut Grace."


    old "I was wondering if you’d like to come climbing with me tomorrow morning."
    new "Je me demandais si tu voulais venir grimper avec moi demain matin."


    old "Climbing? I haven’t done that in a while."
    new "De l’escalade ? Ça fait un moment que je n’en ai pas fait."


    old "Didn’t you mention you’ve done some climbing before?"
    new "Tu n’as pas dit que tu en avais déjà fait ?"


    old "Yeah, I’ve gone a few times. What’s up?"
    new "Oui, j’y suis allé quelques fois. Pourquoi ?"


    old "There’s a great spot I’ve been wanting to check out, and I thought we could give it a try together."
    new "Il y a un super endroit que je veux essayer, je me suis dit qu’on pourrait y aller ensemble."


    old "Sounds interesting. Where is it?"
    new "Ça a l’air intéressant. Il est où ?"


    old "It’ll be a nice change of pace, and I could use the company."
    new "Ça nous changera un peu, et j’aimerais bien avoir de la compagnie."


    old "What do you think?"
    new "Qu’est-ce que t’en penses ?"


    old "Sure, I’m in."
    new "Oui, je suis partant."


    old "Sure, I’d like that. When should we meet?"
    new "Oui, j’aimerais bien. On se retrouve à quelle heure ?"


    old "7 a.m. I’ll have everything ready."
    new "7h. Je m’occuperai de tout."


    old "Got it, see you then."
    new "Ça marche, à demain."


    old "I don’t think I can."
    new "Je pense pas que je puisse."


    old "I’m not available tomorrow, sorry."
    new "Je suis pas dispo demain, désolé."


    old "No worries. Maybe next time."
    new "Pas de souci. Une prochaine fois peut-être."


    old "Sounds good."
    new "Ça me va."


    old "Good evening, [name]."
    new "Bonsoir, [name]."


    old "Good evening, Gabriella."
    new "Bonsoir, Gabriella."


    old "I’ve been reviewing your performance on the field, and I believe there are areas we could refine before the final match."
    new "J’ai revu ta performance sur le terrain et je pense qu’on pourrait peaufiner certains aspects avant le match final."


    old "Ah, so you’re saying I need more practice?"
    new "Ah, donc tu dis que j’ai besoin de plus d'entraînement ?"


    old "I’m saying you have potential, and I’d like to help you make the most of it."
    new "Je dis que tu as du potentiel, et j’aimerais t’aider à en tirer le meilleur."


    old "So, you want to give me a private training session?"
    new "Donc tu veux me faire un entraînement privé ?"


    old "If you’re available tomorrow afternoon, I can show you a few techniques that might give you an edge."
    new "Si tu es dispo demain après-midi, je peux te montrer quelques techniques qui pourraient te donner l’avantage."


    old "Just the two of us? That sounds… intense."
    new "Juste tous les deux ? Ça a l’air… intense."


    old "It’s strictly for your development as a player, [name]."
    new "C’est strictement pour ton développement en tant que joueur, [name]."


    old "Oh, I wouldn’t dream of it being anything else."
    new "Oh, je n’imaginerais jamais autre chose."


    old "I’m glad we’re on the same page. So, what do you say?"
    new "Je suis content qu’on soit sur la même longueur d’onde. Alors, qu’en dis-tu ?"


    old "Sounds good, I’ll be there."
    new "Ça me va, je serai là."


    old "Sure, I’ll come by. What time should I meet you?"
    new "Oui, je passerai. À quelle heure je dois te retrouver ?"


    old "Let’s start at 2 p.m. sharp. Don’t be late."
    new "On commence à 14h pile. Ne sois pas en retard."


    old "Wouldn’t miss it for the world."
    new "Je ne manquerais ça pour rien au monde."


    old "Sorry, I’m busy tomorrow."
    new "Désolé, je suis occupé demain."


    old "Sorry, I have other plans tomorrow evening."
    new "Désolé, j’ai déjà quelque chose demain soir."


    old "That’s unfortunate. I suppose we’ll have to work with what we have."
    new "C’est dommage. On devra faire avec ce qu’on a."


    old "Next time, professor."
    new "La prochaine fois, professeur."


    old "Damn, dude, you hit the jackpot! 🎉"
    new "Putain mec, t’as décroché le gros lot ! 🎉"


    old "Seriously, this is like every guy’s dream. Well played! 😉"
    new "Sérieusement, c’est le rêve de tous les mecs. Bien joué ! 😉"


    old "How do you even get this lucky? I need some tips. 😏"
    new "Comment tu fais pour avoir autant de chance ? Je veux des conseils. 😏"


    old "Bro, I’d trade my left shoe to be in your place. 🥲"
    new "Frérot, je donnerais ma chaussure gauche pour être à ta place. 🥲"


    old "Lucky guy… some guys have all the luck! 👏"
    new "Petit veinard… certains ont vraiment toute la chance ! 👏"


    old "Just finished an intense core workout! Can’t wait to hear what you think. 💪🔥"
    new "Je viens de finir un entraînement intensif pour les abdos ! Hâte d’avoir vos avis. 💪🔥"


    old "Core Power! 💥"
    new "Puissance abdominale ! 💥"


    old "Looking strong, Fanny! I might need a few tips to keep up. 💪"
    new "Tu as la forme, Fanny ! Va falloir que tu me files des conseils pour suivre le rythme. 💪"


    old "I tried this workout, and now I can’t walk up the stairs. 😅"
    new "J’ai testé cet entraînement et maintenant je peux plus monter les escaliers. 😅"


    old "Maybe you should start with sitting on a couch first. 🤷"
    new "Tu devrais peut-être commencer par t’asseoir sur un canapé d’abord. 🤷"


    old "Oh, so now you’re a fitness expert, Ben? Let’s see you touch your toes. 😏"
    new "Ah, donc maintenant t’es un expert en fitness, Ben ? Montre-moi comment tu touches tes orteils. 😏"


    old "Guys, it’s not about touching toes, it’s about reaching for the snacks on the top shelf. 🥨"
    new "Les gars, le but c’est pas de toucher ses pieds, c’est d’attraper les snacks tout en haut de l’étagère. 🥨"


    old "Pat’s got a point. The real workout starts when the bag of chips is just out of reach. 💪"
    new "Pat a raison. Le vrai sport commence quand le paquet de chips est juste hors de portée. 💪"


    old "Fanny, I need a video on the snack-reach drill. That’s my fitness level. 😂"
    new "Fanny, il me faut une vidéo de l’exercice pour atteindre les snacks. C’est ça mon niveau de fitness. 😂"


    old "Hey! What are you doing tonight?"
    new "Hé ! Qu’est-ce que tu fais ce soir ?"


    old "I finish work in an hour."
    new "Je finis le travail dans une heure."


    old "Oh? Still working?"
    new "Oh ? T’es encore au boulot ?"


    old "Yep! But I'm available after."
    new "Oui ! Mais je suis dispo après."


    old "What do you have in mind?"
    new "Tu as une idée derrière la tête ?"


    old "You could show me a pub you like?"
    new "Tu pourrais me montrer un bar que tu aimes bien ?"


    old "Okay! Got one not far from my work!"
    new "Okay ! J’en connais un pas loin de mon boulot !"


    old "I’ll text you the address. 21:30 ok?"
    new "Je t’envoie l’adresse par message. 21h30, ça te va ?"


    old "Cool, see you there."
    new "Cool, à tout à l’heure là-bas."


    old "Nothing. Why?"
    new "Rien. Pourquoi ?"


    old "Wanna come to my room?"
    new "Tu veux venir dans ma chambre ?"


    old "What for?"
    new "Pour quoi faire ?"


    old "Play Scrabble with me?"
    new "Jouer au Scrabble avec moi ?"


    old "Are you serious?"
    new "Tu es sérieux ?"


    old "Come on! Having a hard time with Emerick and I could use some advice..."
    new "Allez ! J’ai du mal avec Emerick et j’aurais bien besoin de quelques conseils..."


    old "You should have opened with that!"
    new "Tu aurais dû commencer par ça !"


    old "I'll be there in 10 minutes."
    new "J’arrive dans 10 minutes."


    old "Oh okay. Perfect."
    new "Ah ok. Parfait."


    old "I come from a military family.[TEMP1!t]"
    new "Je viens d’une famille militaire.[TEMP1!t]"


    old "I come from a family of teachers.[TEMP2!t]"
    new "Je viens d’une famille d’enseignants.[TEMP2!t]"


    old "My family has always been my friends.[TEMP3!t]"
    new "Ma famille, ça a toujours été mes amis.[TEMP3!t]"


    old "I’m self-made. My family never helped me much.[TEMP4!t]"
    new "Je me suis fait tout seul. Ma famille ne m’a jamais vraiment aidé.[TEMP4!t]"


    old "We’ll adjust and make it work.[TEMP1!t]"
    new "On s’adaptera et ça marchera.[TEMP1!t]"


    old "It’ll be a chance to grow.[TEMP2!t]"
    new "Ce sera une chance de progresser.[TEMP2!t]"


    old "We’ll have a dedicated training base.[TEMP3!t]"
    new "On aura une base d'entraînement dédiée.[TEMP3!t]"


    old "Living together will bring us closer.[TEMP4!t]"
    new "Vivre ensemble va nous rapprocher.[TEMP4!t]"


    old "My first post made with a new friend ;)"
    new "Mon premier post avec une nouvelle amie ;)"


    old "A good evening in good company:)!"
    new "Une belle soirée en bonne compagnie :) !"


    old "It was great spending time with you.[TEMP1!t]"
    new "C’était génial de passer du temps avec toi.[TEMP1!t]"


    old "I feel like I know you better now.[TEMP2!t]"
    new "J’ai l’impression de mieux te connaître maintenant.[TEMP2!t]"


    old "I’m looking forward to the next match.[TEMP3!t]"
    new "J’ai hâte au prochain match.[TEMP3!t]"


    old "It’s nice to feel at ease with you.[TEMP4!t]"
    new "C’est agréable de se sentir aussi à l’aise avec toi.[TEMP4!t]"





translate french juliaep5s1_012b7a2a:


    d "Eh bien, quelque chose s’est produit plus tôt et cela m’a occupé l’esprit."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
