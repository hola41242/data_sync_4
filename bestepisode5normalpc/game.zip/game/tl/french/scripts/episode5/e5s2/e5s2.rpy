


translate french kira_vs_emerick_430a38c0:

    kira "À quoi tu pensais ? Qu’est-ce que tu cherchais à prouver avec Ruby ?"


translate french kira_vs_emerick_60e88850:

    emerick "Je ne cherchais rien à prouver. Elle s’est mise en travers de mon chemin, c’est tout. J’ai perdu mon sang-froid."


translate french kira_vs_emerick_9974e51e:

    kira "Perdu ton sang-froid ? Tu as failli l’envoyer à l’hôpital !"


translate french kira_vs_emerick_0c89150d:

    kira "Tu te rends compte de la gravité de ce que tu as fait ?"


translate french kira_vs_emerick_86f3cd68:

    emerick "Et pourquoi ça t’importe, Kira ? Pourquoi tu te mêles de ça ?"


translate french kira_vs_emerick_ea9cbdc9:

    emerick "Tu as déjà tout ! Le statut, les privilèges, l’héritage."


translate french kira_vs_emerick_7febb490:

    emerick "Alors pourquoi tu participes à cette compétition ? Tu n’en as pas besoin."


translate french kira_vs_emerick_d74a1365:

    kira "Et tu crois que ça justifie ce que tu as fait ?"


translate french kira_vs_emerick_b892bef5:

    kira "Parce que je suis née avec des avantages, tu crois que ça te donne le droit de faire n’importe quoi ?"


translate french kira_vs_emerick_1dde4087:

    kira "Emerick, ce que tu fais, c’est de l’auto-sabotage. Et tu ne nuis pas qu’aux autres, tu te détruis toi-même."


translate french kira_vs_emerick_2a562568:

    emerick "Du sabotage ? Je me bats pour ce que je mérite, Kira."


translate french kira_vs_emerick_8d747f52:

    emerick "Toi, on t’a tout donné. Moi, je dois prouver ma valeur à chaque étape."


translate french kira_vs_emerick_b35ade4d:

    kira "Et tu penses que c’est la bonne façon ? T’en prendre à Ruby ou à qui que ce soit d’autre ne te rend pas plus fort."


translate french kira_vs_emerick_f356141e:

    kira "Ça te fait juste passer pour un sale gosse pourri-gâté."


translate french kira_vs_emerick_dadcee83:

    emerick "Un sale gosse ? Tu parles comme si tu savais tout, comme si tu étais au-dessus de tout ça."


translate french kira_vs_emerick_d4f971fb:

    emerick "Peut-être que toi oui, Kira. Mais pas moi. Moi, je dois jouer pour gagner, peu importe le prix."


translate french kira_vs_emerick_c20496a1:

    kira "Tu joues pour gagner ? Non, tu joues parce que tu as peur. Tu refuses de l’admettre, mais tu as peur de lui."


translate french kira_vs_emerick_26c92200:

    emerick "Lui ? [name] ? Tu crois vraiment que j’ai peur de ce type ?"


translate french kira_vs_emerick_80b55e77:

    emerick "Il n’est rien. Rien du tout !"


translate french kira_vs_emerick_3ecc51be:

    ben "Aïe !"


translate french kira_vs_emerick_9a9e3fee:

    emerick "Je n’ai pas peur de lui, et je ne laisserai personne dire le contraire."


translate french kira_vs_emerick_baa43a8e:

    kira "Et pourtant, tu réagis dès qu’on parle de lui."


translate french kira_vs_emerick_4d09adb1:

    kira "C’est trop facile de voir à quel point il t’irrite. Mais peu importe. Je ne suis pas là pour me disputer avec toi."


translate french kira_vs_emerick_ec295777:

    emerick "Alors pourquoi t’es là ? Pour encore me faire la morale ?"


translate french kira_vs_emerick_7b6d0751:

    kira "Non. Je suis là pour te dire de rester loin de Ruby."


translate french kira_vs_emerick_cc23a4dc:

    kira "C’est la dernière fois que tu fais un coup pareil. Et si tu continues, Emerick, c’est toi qui vas être éliminé du jeu."


translate french gracee5s2_5e53d018:

    d "Tu t’en sors super bien, Grace. Prends ton temps et concentre-toi sur tes appuis."


translate french gracee5s2_25a32f9d:

    grace "Je fais de mon mieux ! Mais on dirait que cette paroi ne finit jamais."


translate french gracee5s2_881e7db3:

    d "Tu t’en sors mieux que tu ne le crois. L’escalade demande de la patience et de la confiance. Garde ton poids proche de la paroi."


translate french gracee5s2_ce836b73:

    grace "Plus facile à dire qu’à faire… OK, je crois que j’y suis. Et maintenant ?"


translate french gracee5s2_2c06a82d:

    d "Tu vois cette corniche à deux mètres environ ? Encore un petit effort et on pourra faire une pause."


translate french gracee5s2_f6f41eba:

    grace "D’accord. Je peux le faire."


translate french gracee5s2_60a521fb:

    grace "Waouh… Je n’avais jamais réalisé à quel point ça demande de la force."


translate french gracee5s2_bd94a93b:

    d "C’est pour ça que c’est si gratifiant. Une fois au sommet, on a l’impression d’avoir conquis le monde."


translate french gracee5s2_9f9db109:

    grace "On y est ! Regarde cette vue..."


translate french gracee5s2_6bf8c336:

    d "Incroyable, hein ? C’est pour ça que j’aime l’escalade. On a l’impression que le reste du monde disparaît."


translate french gracee5s2_3a586080:

    grace "Je comprends pourquoi tu aimes ça. C’est si paisible ici… juste nous et l’horizon."


translate french gracee5s2_f6c9d445:

    d "Tu sais, Grace… être ici me fait me demander ce qui te pousse à tenter ce genre de choses ?"


translate french gracee5s2_dd25c71c:

    grace "Je suppose que c’est parce que j’ai raté plein de choses quand j’étais plus jeune."


translate french gracee5s2_cf93a16e:

    grace "Mon père était toujours en mission humanitaire, et ma mère…"


translate french gracee5s2_d618ca6c:

    grace "Elle ne jurait que par les notes et les réussites. Je n’ai jamais vraiment pu explorer ce que je voulais."


translate french gracee5s2_a0099d9f:

    d "Alors maintenant, tu essaies de rattraper le temps perdu ?"


translate french gracee5s2_9c28033b:

    grace "Exactement. J’essaie des choses auxquelles je n’aurais jamais pensé, juste pour voir ce qui me correspond."


translate french gracee5s2_236e6284:

    grace "Gravir une montagne, apprendre de nouvelles choses… c’est ma façon de découvrir qui je suis vraiment."


translate french gracee5s2_a6989932:

    d "C’est vraiment courageux. Beaucoup de gens n’oseraient même pas essayer."


translate french gracee5s2_793a9728:

    grace "Tu sais, avoir quelqu’un comme toi à mes côtés, ça aide. C’est plus facile de prendre des risques quand on n’est pas seul."


translate french sexygracee5s2_17ea1ead:

    grace "En parlant de risques…"


translate french sexygracee5s2_7cdaa598:

    grace "La vue est incroyable, mais tu sais ce qui est encore mieux ?"


translate french sexygracee5s2_9baa9c83:

    d "Quoi donc ?"


translate french sexygracee5s2_1bf2c142:

    grace "Tu sais, la dernière fois, c’était incroyable. Mais je n’arrête pas de penser à combien j’ai encore envie de toi."


translate french sexygracee5s2_9dff1a4f:

    d "Vraiment ? Ici, en pleine nature ?"


translate french sexygracee5s2_88aafb2e:

    grace "Pourquoi pas ? Il n’y a personne. Juste le vent et les arbres. C’est notre moment, non ?"


translate french sexygracee5s2_b96c9ffb:

    d "Grace… tu es pleine de surprises."


translate french sexygracee5s2_9fa4c060:

    grace "Et tu adores ça."


translate french sexygracee5s2_66f82310:

    grace "Il n’y a que nous. Aucune distraction. Je veux que tu me voies, moi seule."


translate french sexygracee5s2_03d8fcea:

    d "Je te vois. Bien plus que tu ne crois."


translate french sexygracee5s2_34f8b5b1:

    grace "Alors montre-le-moi."


translate french sexygracee5s2_0ae9bcd0:

    ""


translate french sexygracee5s2_22f9d196:

    grace "Oui... Comme ça ! C’est tellement bon !"


translate french sexygracee5s2_0b254e36:

    d "Grace, tu es si serrée !"


translate french sexygracee5s2_3cf4a0c1:

    grace "Il faudra qu’on fasse ça plus souvent !"


translate french sexygracee5s2_86cf3182:

    d "Je suis toujours heureux de te faire plaisir !"


translate french sexygracee5s2_a6949bdc:

    grace "Oui, plus profond... S’il te plaît..."


translate french sexygracee5s2_e3427569:

    grace "C’est si bon..."


translate french sexygracee5s2_0ae9bcd0_1:

    ""


translate french sexygracee5s2_f78c3eac:

    grace "Attends une seconde. Prends-moi par derrière !"


translate french sexygracee5s2_0ae9bcd0_2:

    ""


translate french sexygracee5s2_bf58cff1:

    grace "Oh ! Cet angle est encore meilleur !"


translate french sexygracee5s2_1cf81eb6:

    grace "Continue... S’il te plaît..."


translate french sexygracee5s2_44928221:

    d "Grace, je ne vais pas tenir longtemps !"


translate french sexygracee5s2_dc177f84:

    grace "Alors ne te retiens pas !"


translate french sexygracee5s2_b59160c0:

    d "Grace..."


translate french sexygracee5s2_0ae9bcd0_3:

    ""


translate french sexygracee5s2_7f563f32:

    grace "Ohhhhhhhhhhhhh ! Ouiiiiiii !!!!!"


translate french sexygracee5s2_bfc939b4:

    grace "Tu sais… toute cette expérience, je n’aurais jamais pensé vivre ça un jour."


translate french sexygracee5s2_34708511:

    d "Et je suis heureux que tu aies essayé. C’est dans ces moments-là que je me rappelle pourquoi j'en pince pour toi."


translate french sexygracee5s2_441200b6:

    grace "Eh bien, tu as su rendre ça inoubliable."


translate french endgracee5s2_c1b59b5c:

    d "Redescendons, voir quelles autres aventures nous attendent."


translate french endgracee5s2_80326d52:

    grace "J’ai l’impression d’avoir accompli quelque chose d’incroyable. Merci de m’avoir appris les bases, au sens propre."


translate french endgracee5s2_67ab4f3a:

    d "Pas de souci. Tu t’en es très bien sortie pour une première escalade."


translate french endgracee5s2_4c8911df:

    grace "Peut-être que je devrais recommencer un jour. Mais là, je crois qu’il est temps de redescendre."


translate french gabye5s2_b234501b:

    d "Ah, te voilà, Gabriella. J’ai presque cru que j’étais en avance."


translate french gabye5s2_954b7bc3:

    gaby "Tu es à l’heure, [name]. C’est déjà un bon début."


translate french gabye5s2_7c485d36:

    d "Tu es toujours pleine de surprises, mais je suis prêt pour ce que tu as prévu."


translate french gabye5s2_fb6d37b0:

    gaby "Avant de commencer, comment tu te sens après le dernier match ?"


translate french gabye5s2_ebad0537:

    d "J’ai connu mieux, pour être honnête. Mon dos me fait souffrir depuis... cet incident avec Ruby."


translate french gabye5s2_c4d1eb46:

    gaby "Quel incident ?"


translate french gabye5s2_e7942129:

    d "Je… enfin, elle allait se blesser et j’ai dû intervenir. C’était un peu… intense."


translate french gabye5s2_59625d19:

    gaby "Tu t’es mis en danger pour elle ? Je ne pensais pas que tu en étais capable."


translate french gabye5s2_bbcf6a2f:

    d "Je ne pouvais pas rester là sans rien faire. Mais maintenant… j’en paie le prix."


translate french gabye5s2_ae2363fb:

    gaby "Un héros qui a besoin d’un peu de récupération, donc ?"


translate french gabye5s2_5db421a6:

    d "Quelque chose comme ça."


translate french gabye5s2_94e0ebe2:

    gaby "Je connais un endroit. Un petit salon de massage pas loin d’ici. Des spécialistes en thérapie sportive. J’ai même appris quelques trucs avec eux."


translate french gabye5s2_078dcf7d:

    d "Tu proposes de t’occuper du massage toi-même ?"


translate french gabye5s2_e5cc8d38:

    gaby "Je crois que tu apprécierais un peu trop ça."


translate french gabye5s2_d788de3e:

    d "On ne peut pas m’en vouloir d’essayer, non ?"


translate french gabye5s2_9c8316b7:

    gaby "Allez, assez parlé. Place à l'entraînement."


translate french gabye5s2_a4e1ec70:

    d "Un entraînement pour quoi exactement ?"


translate french gabye5s2_e0ffdaa0:

    gaby "Tu verras. Prépare-toi juste à bosser tes compétences."


translate french gabye5s2_7dc7fb28:

    d "OK, mais pourquoi j’ai l’impression que tu me caches quelque chose ?"


translate french gabye5s2_68703f1b:

    gaby "Si je te le disais maintenant, ce ne serait pas aussi amusant de voir ta réaction."


translate french gabye5s2_b40f9c8d:

    dpense "Attends… quoi ?"


translate french gabye5s2_2f84c3bb:

    d "Hé !"


translate french gabye5s2_8757c10b:

    mad "Il t’en a fallu du temps pour me remarquer, [name]."


translate french gabye5s2_d1447287:

    d "Madison ? Qu’est-ce que tu fais là ?"


translate french gabye5s2_fd76949c:

    mad "Gaby a dit que tu avais besoin d’un vrai entraînement. Alors… me voilà."


translate french gabye5s2_245c1805:

    d "Oh, tu vas voir !"


translate french gabye5s2_35142fea:

    gaby "L’exercice d’aujourd’hui est simple. Je veux que vous vous renvoyiez la balle avec toute la force que vous pouvez supporter."


translate french gabye5s2_6b535cba:

    d "Quoi ???" with hpunch


translate french gabye5s2_7e644d50:

    mad "Ahah ! Je vais ADORER ça !"


translate french gabye5s2_5c041625:

    gaby "Et souvenez-vous… vous devez renvoyer la balle avec autant de force qu’elle vous arrive. Simple, non ?"


translate french gabye5s2_0732ddf4:

    d "Attends, t’es sérieuse ?!"


translate french gabye5s2_f60ff0bc:

    mad "Regarde la balle, [name] !"


translate french gabye5s2_74e1ee21:

    d "J’étais pas prêt !"


translate french gabye5s2_29d4ac8e:

    mad "Et maintenant ?"


translate french gabye5s2_cf0a6a24:

    d "Madison !!!!!"


translate french gabye5s2_10c440ff:

    d "T’es douée, Madison. Je te l’accorde."


translate french gabye5s2_05bb1173:

    mad "Toi aussi tu te débrouilles pas mal. On va devoir continuer à se pousser mutuellement."


translate french gabye5s2_9a9a9608:

    gaby "C’est l’esprit qu’il faut. Maintenant, reposez-vous. On aura besoin de vous deux au top pour le prochain match."


translate french gabye5s2_546f6774:

    d "Merci, Gaby. Et Madison… beau boulot."


translate french gabye5s2_fc01931e:

    mad "Toi aussi, [name]. Mais la prochaine fois…"


translate french gabye5s2_f464664f:

    mad "Essaie de ne pas avoir l’air aussi terrifié quand la balle fonce sur ta tête !"


translate french evelyne5s2_a650529a:

    d "Wow... Chic comme endroit."


translate french evelyne5s2_becac631:

    d "Elle a dit qu’elle m’attendrait à l’intérieur."


translate french evelyne5s2_423e9317:

    ji "Jeune homme."


translate french evelyne5s2_62fb39a8:

    d "Hum ?"


translate french evelyne5s2_c5e3e443:

    d "Evelyn, ravi de vous voir."


translate french evelyne5s2_ff7aaf80:

    evelyn "Tu es à l’heure. Je commençais à me demander si tu pouvais être à la fois audacieux et ponctuel."


translate french evelyne5s2_72e57299:

    d "Je vise à impressionner."


translate french evelyne5s2_a44f4722:

    evelyn "Impressionner ? Attention, jeune homme. Les premières impressions ne vont pas bien loin."


translate french evelyne5s2_25feb380:

    d "Peut-être, mais c’est honnête. Ça compte, non ?"


translate french evelyne5s2_8532cb87:

    evelyn "Voyons si tu peux rester comme ça."


translate french evelyne5s2_8e674de3:

    d "Je n’étais même pas sûr que vous veuillez vraiment me voir après notre appel."


translate french evelyne5s2_fd2e5403:

    evelyn "Pourquoi pas ? Tu m’as surprise au Palazio. Le mystère et la confiance sont des choses rares de nos jours."


translate french evelyne5s2_2364e806:

    d "Alors j’ai passé le premier test ?"


translate french evelyne5s2_650b63e4:

    evelyn "Dire que tu l’as passé est un peu ambitieux. Disons que… tu es encore dans la course."


translate french evelyne5s2_c6ed178d:

    d "L’intrigue plutôt que l’échec ? Ça me va."


translate french evelyne5s2_18e2e1d8:

    evelyn "Bien. Mais souviens-toi… le mystère ne fonctionne que si tu n’en fais pas trop. L’équilibre, chéri, c’est la clé."


translate french evelyne5s2_e929b0ed:

    d "Et à quoi ressemble l’équilibre selon vous ?"


translate french evelyne5s2_6cad5637:

    evelyn "C’est savoir quand avancer… et quand faire en sorte que l’autre te suive."


translate french evelyne5s2_cd8ca222:

    evelyn "Quand parler, et quand laisser le silence en dire plus que les mots."


translate french evelyne5s2_70b3fb67:

    evelyn "Et surtout… il s’agit de confiance, pas d’arrogance. N’oublie jamais la différence."


translate french evelyne5s2_38f96d88:

    evelyn "Tu as du potentiel, [name]. Mais je ne suis pas là pour les mots creux. J’accorde de la valeur à l’action, la réflexion… et l’intention."


translate french evelyne5s2_aabab7a7:

    d "C’est peut-être pour ça que je suis venu. Pour vous montrer que je ne suis pas que des paroles."


translate french evelyne5s2_401a18a2:

    evelyn "Attention. Ça ressemble fortement à une promesse. Et les promesses… ont du poids."


translate french evelyne5s2_4ad67b83:

    evelyn "Avant de partir, j’ai quelque chose pour toi."


translate french evelyne5s2_463e2712:

    d "Qu’est-ce que c’est ?"


translate french evelyne5s2_777b6d4a:

    evelyn "Une clé vers un autre genre de jeu, [name]. Un jeu auquel la plupart ne savent même pas qu’ils participent déjà."


translate french evelyne5s2_de2a154e:

    evelyn "C’est un badge qui te permet d’entrer dans la section VIP du Palazio."


translate french evelyne5s2_59c7e9cb:

    d "Une invitation spéciale de la part de la dame en personne ?"


translate french evelyne5s2_3a658ded:

    evelyn "Ne t’emballe pas. Je fais simplement… une ouverture."


translate french evelyne5s2_34ceb768:

    evelyn "Avoir le courage de la franchir, c’est une toute autre affaire."


translate french evelyne5s2_cbf5225d:

    d "Je n’ai pas l’intention de laisser passer ma chance."


translate french evelyne5s2_5518e0eb:

    evelyn "Parfait. J’ai hâte de voir jusqu’où tu es prêt à aller."


translate french evelyne5s2_04857837:

    evelyn "Mais pour l’instant… je vais te laisser dans le doute."


translate french evelyne5s2_96cc6180:

    d "Alors je ne vous retiens pas."


translate french evelyne5s2_a1b3e397:

    evelyn "Sage décision. Et souviens-toi, [name]... quand le jeu commencera, prends des risques. Et ne me déçois pas."


translate french evelyne5s2_61b916eb:

    dpense "Un autre genre de jeu… ? Et cette section VIP… Dans quoi est-ce que je m’embarque ?"


translate french evelyne5s2_fcc1ba01:

    dpense "Elle n’est comme personne que j’ai rencontré. Confiante, mystérieuse… j’ai l’impression qu’elle me teste, qu’elle me défie de me surpasser."


translate french evelyne5s2_a0934412:

    dpense "Mais je ne suis pas du genre à reculer devant un défi."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
