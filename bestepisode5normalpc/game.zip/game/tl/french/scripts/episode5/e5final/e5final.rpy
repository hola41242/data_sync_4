
translate french e5final_cbd86156:


    orushi "L'épreuve est terminée."


translate french e5final_8e9a8d61:


    orushi "Les boîtes ont révélé leur vérité, et seuls dix d’entre vous ont obtenu un jeton."


translate french e5final_c086ea0b:


    orushi "Voici les dix joueurs qualifiés pour la suite du B.E.S.T. :"


translate french e5final_d41e48ec:


    orushi "Madison, Julia, Grace, Ruby, Sofia, Red, Kira, Steven, Emerick… et [name]."


translate french e5final_2b68b3c9:


    dpense "On l’a fait. Dix encore en lice. Dix pour le vrai combat."


translate french e5final_61b2ee07:


    orushi "Intéressant."


translate french e5final_4957490e:


    orushi "Très intéressant, même."


translate french e5final_13c153a6:


    orushi "Je dois admettre, certains d’entre vous ont montré... un potentiel inattendu."


translate french e5final_9f3a38d8:


    orushi "Vous avez traversé des épreuves. Vous vous êtes affrontés. Parfois trahis."


translate french e5final_72a35d67:


    orushi "Vous avez couru, sauté, résolu, combattu. Vous avez séduit, bluffé, survécu."


translate french e5final_3c5733bf:


    orushi "Mais avant tout... vous avez tous cru que cela avait un sens."


translate french e5final_060f387e:


    mad "Que voulez-vous dire ?"


translate french e5final_65ae2928:


    orushi "Ce que vous venez d’expérimenter... n’était qu’un échauffement."


translate french e5final_34927185:


    orushi "Ce n’était qu’une pré-sélection."


translate french e5final_f0b208fd:


    orushi "Un test, un tournoi de l’ombre, une série de qualifications pour... quelque chose de bien plus grand."


translate french e5final_0368b86e:


    beth "Tch. Je m’en doutais..."


translate french e5final_4187ee7b:


    orushi "Ce que vous avez affronté ici... n’était qu’un prélude."


translate french e5final_c8946c78:


    orushi "Un tournoi fermé. Local. Caché du monde extérieur."


translate french e5final_bbb2d66e:


    orushi "Mais le véritable B.E.S.T..."


translate french e5final_5e129c9e:


    orushi "...est une compétition mondiale."


translate french e5final_2c6aafb3:


    orushi "Diffusée en direct. Dans chaque pays, autour du monde..."


translate french e5final_ba04c124:


    orushi "...où chaque mouvement que vous ferez influencera la manière dont le monde vous perçoit."


translate french e5final_4c107ff4:


    dpense "Le monde entier... ?"


translate french e5final_18ee960f:


    ruby "C’est pas possible... C’est une blague ?"


translate french e5final_81d6844c:


    orushi "Oh, non. Je ne blague jamais."


translate french e5final_f3db7362:


    orushi "Vous pensiez que c’était la fin ? Ca ne fait que commencer."


translate french e5final_4db8fb6f:


    orushi "Très bientôt, vos noms, vos visages, vos défauts, vos ambitions..."


translate french e5final_224643b2:


    orushi "...seront exposés au grand jour."


translate french e5final_5e919ebb:


    orushi "Et qui vous êtes réellement… sera jugé par le monde entier."


translate french e5final_4b89b6d5:


    orushi "Des équipes venant des quatre coins du monde. Choisies avec soin. Entraînées pendant des mois."


translate french e5final_517f47bb:


    orushi "Certains ont échoué. D’autres sont prêts. Vous... avez franchi la première porte."


translate french e5final_64f7aadd:


    grace "Pourquoi nous ? Pourquoi tout ça ?"


translate french e5final_3ec31ebc:


    orushi "Ce que vous avez traversé n’était pas un jeu. C’était un filtre. Une révélation."


translate french e5final_59ea5225:


    orushi "Le B.E.S.T n’est pas une compétition pour enfants. C’est un catalyseur."


translate french e5final_1d7bdf66:


    orushi "Préparez-vous."


translate french e5final_b2411d5c:


    orushi "La scène est en train de grandir."


translate french e5final_676d021d:


    orushi "Le jeu... change de dimension."


translate french e5final_783ba284:


    orushi "Des équipes de partout dans le monde arrivent ici pour vous affronter."


translate french e5final_abe03b34:


    orushi "Et la première vient juste d’arriver de l’aéroport !"


translate french e5final_63be2349:


    d "Quoi..."


translate french e5final_f3a28e44:


    d "Le..."


translate french e5final_7543c4f0:


    d "Putain???"


translate french e5final_5c553fbe:


    d "Elise...?!"


translate french e5final_285f8ea7:


    "Veuillez enregistrer votre jeu ici..."


translate french e5final_b003f642:


    orushi "Ce n’est pas fini !"


translate french e5final_fcba8ba6:


    mad "Je vais entrer dans la tour d’Orushi et découvrir ce qui se passe !!!"


translate french e5final_d9821bcd:


    orushi "Cette épreuve nous dira qui sera le nouveau capitaine de l’équipe !"


translate french e5final_37648b20:


    orushi "Préparez-vous pour la finale !"




translate french e5final_d18ed18b:


    orushi "Dix d’entre vous ont obtenu un jeton."


translate french e5final_12a54177:


    orushi "Madison, Julia, Grace, Ruby, Sofia, Elizabeth, Kira, Steven, Emerick… et [name]."


translate french e5final_b834ee76:


    orushi "Des équipes de partout dans le monde..."


translate french e5final_ee3d0d5e:


    orushi "Viennent ici pour vous affronter."


translate french e5final_f50837a2:


    beth "Sérieusement ?"


translate french e5final_d91abf5f:


    mad "Qui sont..."


translate french e5final_b77f246c:


    grace "De nouveaux adversaires ?"


translate french e5final_87a80f3c:


    d "Attendez..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
