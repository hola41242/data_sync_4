
translate french e5s5_dc2c3852:


    dpense "Ruby dort encore..."


translate french e5s5_1d84e809:


    dpense "Elle a l'air paisible. Presque comme si tout le chaos s'était dissipé pendant la nuit."


translate french e5s5_6be8f3b2:


    dpense "Sa couverture a glissé..."


translate french e5s5_eb32bf38:


    dpense "Son sein est exposé, à peine couvert par le bord de sa chemise de nuit."


translate french e5s5_557bff10:


    dpense "Juste le va-et-vient de sa respiration, douce et chaude."


translate french e5s5_abd3a128:


    dpense "Je tends la main et ajuste doucement sa robe."


translate french e5s5_86c38cc5:


    dpense "Elle bouge un peu, mais ne se réveille pas."


translate french e5s5_110eafbd:


    dpense "Elle mérite cette dignité. Ce confort."


translate french e5s5_428112c6:


    dpense "Je ne serai pas une autre source de pression dans sa vie."


translate french e5s5_dc44a896:


    dpense "Je laisse faire."


translate french e5s5_de426a87:


    dpense "Elle est belle comme ça... mais plus que ça, elle me fait confiance."


translate french e5s5_644ff621:


    dpense "Et ça signifie quelque chose."


translate french e5s5_fe6609cf:


    dpense "Ce moment lui appartient."


translate french e5s5_075b8981:


    dpense "Il est temps d'y aller."


translate french e5s5_01e40ea8:


    dpense "Déjà le matin..."


translate french e5s5_3b9c765c:


    dpense "Difficile de croire que tout ce qui s'est passé hier était réel."


translate french e5s5_c5afb76f:


    dpense "Marc, Julia, Ruby... tout tourne dans ma tête."


translate french e5s5_f432cdb3:


    dpense "Un message de Sofia ?"


translate french e5s5_99adca09:


    dpense "Voyons ce que Charlotte préparait..."


translate french e5s5_b6e0b95a:


    dpense "Voyons quel genre de 'massage de récupération' Gabriella a réservé pour moi..."


translate french e5s5_6d68e0ba:


    dpense "Blue m'attend au centre commercial..."


translate french e5s5_be915c33:


    dpense "Je suppose que j'ai la matinée pour moi."


translate french e5s5_massage_chagaby_2001ee16:


    ji "Ah, vous devez être [name]. Bienvenue. Charlotte a dit que vous viendriez. Chambre 2. Voici votre serviette. Elles sont à l'intérieur."


translate french e5s5_massage_chagaby_d367964b:


    dpense "Chambre 2...? 'Elles'...? Elle a vraiment tout prévu. Je dois me changer avant d'entrer..."


translate french e5s5_massage_chagaby_c448096f:


    dpense "D'accord... Gabriella est déjà sur la table."


translate french e5s5_massage_chagaby_8d3bb645:


    dpense "Et Charlotte aussi..."


translate french e5s5_massage_chagaby_6c70e222:


    dpense "Elle me fixe... me disant de ne pas parler."


translate french e5s5_massage_chagaby_df24d594:


    gaby "Mmm... enfin. Mon dos me tue."


translate french e5s5_massage_chagaby_b48a6ef5:


    gaby "Cet endroit se réserve toujours rapidement, mais Charlotte a veillé à ce qu'on puisse entrer tôt."


translate french e5s5_massage_chagaby_85d25137:


    cha "Bien sûr. Je m'occupe de ce qui compte."


translate french e5s5_massage_chagaby_e8889756:


    dpense "Attends... elle veut que je la masse ?"


translate french e5s5_massage_chagaby_edf9bd97:


    dpense "Son visage est enfoui dans la table... elle n'a aucune idée que c'est moi."


translate french e5s5_massage_chagaby_7289d39e:


    cha "Sois gentil et aide avec ses épaules, d'accord ?"


translate french e5s5_massage_chagaby_5e8e88eb:


    dpense "Attends... Que fait Charlotte ?"


translate french e5s5_massage_chagaby_d540bdf7:


    dpense "Non, elle ne ferait pas ça..."


translate french e5s5_massage_chagaby_fe6190ab:


    gaby "Oh... Cette pression est parfaite..."


translate french e5s5_massage_chagaby_29d92251:


    gaby "C'est plus fort que d'habitude aujourd'hui. Ont-ils encore changé de personnel ?"


translate french e5s5_massage_chagaby_cb31e78a:


    dpense "Je ne peux pas réagir. Continue juste de masser."


translate french e5s5_massage_chagaby_da86f35d:


    dpense "Quoi..."


translate french e5s5_massage_chagaby_0ae9bcd0:


    ""


translate french e5s5_massage_chagaby_ce559f45:


    dpense "Elle n'a vraiment aucune limite..."


translate french e5s5_massage_chagaby_dcaadb50:


    dpense "Ou peut-être que c'est juste un jeu pour elle ?"


translate french e5s5_massage_chagaby_d29b7782:


    dpense "Et Gabriella..."


translate french e5s5_massage_chagaby_7aa7436c:


    gaby "Juste là... mmh... ce nœud me dérange depuis toute la semaine."


translate french e5s5_massage_chagaby_de315c09:


    cha "Il touche tous les bons endroits, n'est-ce pas ?"


translate french e5s5_massage_chagaby_3d4d34f3:


    gaby "Ugh... oui. Je ne sais pas ce qu'il fait, mais ça marche."


translate french e5s5_massage_chagaby_8e7fda38:


    gaby "Je ferme les yeux et j'imagine qui cela pourrait être..."


translate french e5s5_massage_chagaby_d5b8322d:


    cha "Cela demande une intuition spéciale... certaines personnes savent juste où appuyer."


translate french e5s5_massage_chagaby_73039866:


    cha "Mais je suis sûre que tu peux imaginer ton étudiant !"


translate french e5s5_massage_chagaby_f68665a9:


    gaby "Charlotte !"


translate french e5s5_massage_chagaby_f1576f4c:


    dpense "C'est de la folie..."


translate french e5s5_massage_chagaby_d45a79ad:


    dpense "Elle parle pendant que Charlotte..."


translate french e5s5_massage_chagaby_37cd8752:


    gaby "Plus profond, juste un peu... oui... c'est ça..."


translate french e5s5_massage_chagaby_cba41796:


    gaby "Je vais fondre si tu continues comme ça."


translate french e5s5_massage_chagaby_9d18feb0:


    cha "Ne le tente pas, Gaby."


translate french e5s5_massage_chagaby_fd51d7eb:


    gaby "Tenter ? Je dis juste ce que je ressens !"


translate french e5s5_massage_chagaby_b9a49a1a:


    dpense "Elle n'a aucune idée... et Charlotte ne s'arrête pas."


translate french e5s5_massage_chagaby_02bed8bf:


    gaby "Sérieusement, j'ai besoin de ça chaque semaine."


translate french e5s5_massage_chagaby_e8582554:


    gaby "Peu importe qui c'est, cette personne mérite une augmentation."


translate french e5s5_massage_chagaby_8cd9e86b:


    dpense "Reste concentré. Ne..."


translate french e5s5_massage_chagaby_dfc4dc6f:


    cha "Soulage la pression."


translate french e5s5_massage_chagaby_87872403:


    d "Elle me parle à moi ou... ?"


translate french e5s5_massage_chagaby_3b63fb1d:


    gaby "Ahhh..."


translate french e5s5_massage_chagaby_41603c23:


    gaby "[name]..."


translate french e5s5_massage_chagaby_c967607c:


    dpense "Quoi???" with hpunch


translate french e5s5_massage_chagaby_e6a3a3b1:


    dpense "Elle vient de dire mon nom ?"


translate french e5s5_massage_chagaby_6cb9f1a5:


    dpense "Je ne peux pas..."


translate french e5s5_massage_chagaby_ba532364:


    dpense "Fuuuuuckkkk !"


translate french e5s5_massage_chagaby_f9427bc8:


    cha "Mmm. Je suis prête pour la journée maintenant."


translate french e5s5_massage_chagaby_3b6714f3:


    dpense "Elle m'a vidé..."


translate french e5s5_massage_chagaby_251f5469:


    gaby "Tu as déjà fini ?"


translate french e5s5_massage_chagaby_1193d7cb:


    cha "Ouais. Et on dirait que toi aussi, Gaby."


translate french e5s5_massage_chagaby_ef7acd06:


    gaby "Ugh... Je pourrais rester comme ça pour toujours."


translate french e5s5_massage_chagaby_21b9efef:


    dpense "Elle ne sait toujours pas..."


translate french e5s5_massage_chagaby_75028c91:


    cha "Allez, [name]. Laisse la dame profiter de son plaisir."


translate french e5s5_massage_chagaby_09be68e5:


    cha "Tu as bien fait."


translate french e5s5_massage_chagaby_030147cd:


    d "Toi aussi."


translate french e5s5_massage_chagaby_b0f13d20:


    dpense "C'était... beaucoup."


translate french e5s5_massage_chagaby_f35bbe50:


    dpense "Charlotte a planifié chaque seconde de ça. Et Gabriella..."


translate french e5s5_massage_chagaby_fef6075d:


    dpense "Elle n'a toujours aucune idée."


translate french e5s5_massage_chagaby_40c298eb:


    dpense "C'était quoi, ça ?"


translate french e5s5_massage_gaby_main_926d4c1f:


    ji "Oh, tu es déjà de retour ? C'était rapide. La salle 3 est prête pour toi."


translate french e5s5_massage_gaby_main_2c096fcd:


    dpense "Elle se souvient de moi de tout à l'heure... Heureusement qu'elle ne pose pas de questions."


translate french e5s5_massage_gaby_main_76e2a70e:


    "Receptionist" "Bonjour ! Tu dois être [name], non ? Ta séance est prête. La salle 3, s'il te plaît."


translate french e5s5_massage_gaby_main_6784b11e:


    dpense "Oh. C'est cosy."


translate french e5s5_massage_gaby_main_99f02fbd:


    dpense "Pas mal... Je suis curieux de savoir qui va me masser..."


translate french e5s5_massage_gaby_main_e13226b5:


    gaby "Te voilà. Juste à l'heure."


translate french e5s5_massage_gaby_main_9d4ca66f:


    dpense "Hmm ?"


translate french e5s5_massage_gaby_main_767727ac:


    d "Je ne t'attendais pas ici, pour être honnête."


translate french e5s5_massage_gaby_main_fbbd8a7d:


    gaby "Tu as un match important qui arrive. Je veux que tu sois en pleine forme."


translate french e5s5_massage_gaby_main_a5e4cd0a:


    d "C'est juste."


translate french e5s5_massage_gaby_main_438e2467:


    dpense "Elle est tellement calme... comme si c'était juste une autre journée de travail."


translate french e5s5_massage_gaby_main_cf33235f:


    gaby "Allonge-toi sur le dos. On va se concentrer sur tes jambes."


translate french e5s5_massage_gaby_main_a0543308:


    dpense "C'est fou... Elle n'a aucune idée que c'était moi tout à l'heure."


translate french e5s5_massage_gaby_main_1d98e1ca:


    dpense "Et maintenant elle va me masser comme si rien ne s'était passé."


translate french e5s5_massage_gaby_main_915b1cd1:


    gaby "Dis-moi si la pression est trop forte."


translate french e5s5_massage_gaby_main_cf335fae:


    d "C'est parfait. Ferme, mais doux."


translate french e5s5_massage_gaby_main_235045f3:


    dpense "Ses mains sont confiantes. Précises. Elle sait exactement ce qu'elle fait."


translate french e5s5_massage_gaby_main_d39bef52:


    gaby "Tes quadriceps sont tendus. Je sens beaucoup de tension accumulée."


translate french e5s5_massage_gaby_main_44ff6795:


    d "Ça a du sens. J'ai beaucoup forcé ces derniers temps... et beaucoup pensé."


translate french e5s5_massage_gaby_main_f63e3072:


    gaby "Penser ?"


translate french e5s5_massage_gaby_main_5b65b87f:


    d "À propos du match. De rester concentré."


translate french e5s5_massage_gaby_main_4427b431:


    gaby "Garde cet état d'esprit. Tu dois être aiguisé."


translate french e5s5_massage_gaby_main_7c06ce06:


    dpense "Elle essaie de rester professionnelle. Mais elle ressent la tension."


translate french e5s5_massage_gaby_main_58db53c0:


    gaby "Je monte sur tes cuisses. Dis-moi si ça devient trop sensible."


translate french e5s5_massage_gaby_main_b4033f39:


    d "Tu veux dire physiquement, ou émotionnellement ?"


translate french e5s5_massage_gaby_main_c3a0d04f:


    gaby "Physiquement. Ne compliquons pas les choses."


translate french e5s5_massage_gaby_main_4ab0dab5:


    dpense "Je l'ai eue. Elle hésite maintenant."


translate french e5s5_massage_gaby_main_9737a6f6:


    gaby "Tu es très chaud. Les muscles réagissent bien."


translate french e5s5_massage_gaby_main_ccbf27d4:


    d "Peut-être que c'est juste ton toucher."


translate french e5s5_massage_gaby_main_4e6d2b64:


    gaby "...Gardons ça professionnel, d'accord ?"


translate french e5s5_massage_gaby_main_de3c485f:


    d "Bien sûr. Je dis juste… tu as des doigts magiques."


translate french e5s5_massage_gaby_main_08df85ac:


    dpense "Ses joues sont rouges maintenant. Elle est gênée."


translate french e5s5_massage_gaby_main_cd72dc97:


    gaby "Hanches maintenant. Essaie de respirer et de te détendre."


translate french e5s5_massage_gaby_main_12e0eed0:


    d "Assez difficile de se détendre avec toi si près."


translate french e5s5_massage_gaby_main_487ff192:


    gaby "Tu préférerais quelqu'un d'autre ?"


translate french e5s5_massage_gaby_main_aa04a66e:


    d "Pas du tout."


translate french e5s5_massage_gaby_main_d1a462be:


    gaby "...[name]. Ce n'est plus juste de la récupération."


translate french e5s5_massage_gaby_main_337b6dff:


    d "Peut-être pas. Mais ça me semble juste."


translate french e5s5_massage_gaby_main_cfd29dd2:


    gaby "Je suis ton coach. Je suis plus âgée. Ce n'est pas censé arriver."


translate french e5s5_massage_gaby_main_50b86890:


    d "Alors pourquoi tes mains sont encore sur moi ?"


translate french e5s5_massage_gaby_main_f3022391:


    gaby "Je..."


translate french e5s5_massage_gaby_main_d72157de:


    d "Dis-moi d'arrêter. Je m'arrêterai."


translate french e5s5_massage_gaby_main_afb8b1fb:


    gaby "...Non."


translate french e5s5_massage_gaby_main_7d997125:


    dpense "Sa garde tombe. Encore un peu..."

translate french e5s5_massage_gaby_main_f857082d:


    dpense "Sa voix est à peine un murmure. Mais ses mains... elles ne se sont pas éloignées."


translate french e5s5_massage_gaby_main_48984802:


    gaby "Je ne devrais pas faire ça..."


translate french e5s5_massage_gaby_main_fe5a5f9b:


    d "Alors dis-moi de retirer mes mains de toi."


translate french e5s5_massage_gaby_main_48876117:


    gaby "..."


translate french e5s5_massage_gaby_main_1c29f5d0:


    dpense "Elle ne dit rien."


translate french e5s5_massage_gaby_main_cd459cec:


    d "Tu es tendue aussi, tu sais. Toute cette pression... ce n’est pas juste sur le terrain."


translate french e5s5_massage_gaby_main_36fd47ae:


    gaby "Ce n'est pas la même chose."


translate french e5s5_massage_gaby_main_8484350c:


    d "Ce n’est pas le cas ? Tu donnes toujours. Toujours en contrôle. Peut-être que tu mérites de lâcher prise une fois."


translate french e5s5_massage_gaby_main_96dbd6e4:


    dpense "Sa respiration s’est bloquée un instant. Elle l’a ressenti."


translate french e5s5_massage_gaby_main_74527e74:


    gaby "Tu es mon élève..."


translate french e5s5_massage_gaby_main_d074f7df:


    d "Et tu es une magnifique femme, Gabriella, qui me touche comme si elle voulait oublier les règles, ne serait-ce qu'un instant."


translate french e5s5_massage_gaby_main_885010d3:


    gaby "...Juste un instant."


translate french e5s5_massage_gaby_main_aac0affb:


    dpense "Elle tremble. Pas de peur. D'anticipation."


translate french e5s5_massage_gaby_main_c70dd2d4:


    gaby "Je vais me concentrer sur l’intérieur de tes cuisses maintenant."


translate french e5s5_massage_gaby_main_fea3af09:


    dpense "Sa voix est basse. Contrôlée. Mais ses doigts sont plus lents... plus insistants."


translate french e5s5_massage_gaby_main_116b0692:


    d "Mmh... Laisse-moi t'aider..."


translate french e5s5_massage_gaby_main_ffaad131:


    gaby "[name] !"


translate french e5s5_massage_gaby_main_1a3acc53:


    d "Ne t'inquiète pas, je resterai professionnel !"


translate french e5s5_massage_gaby_main_d3ba05a9:


    gaby "Mais..."


translate french e5s5_massage_gaby_main_226c70e9:


    dpense "Elle essaie de reprendre le contrôle."


translate french e5s5_massage_gaby_main_b8980a8e:


    dpense "Mais ses doigts traçent des motifs... bien trop doux pour être professionnels."


translate french e5s5_massage_gaby_main_77c76308:


    d "Laisse-moi aider... tu fais déjà tellement."


translate french e5s5_massage_gaby_main_20b6d50e:


    gaby "[name]..."


translate french e5s5_massage_gaby_main_d7b29708:


    d "Chut. Ressens juste ça."


translate french e5s5_massage_gaby_main_913875c9:


    dpense "Son corps s'est tendu. Mais elle ne s'est pas éloignée."


translate french e5s5_massage_gaby_main_0ae9bcd0:


    ""


translate french e5s5_massage_gaby_main_20313501:


    gaby "Ah..."


translate french e5s5_massage_gaby_main_862affd8:


    gaby "Humpff..."


translate french e5s5_massage_gaby_main_f7c934e2:


    gaby "Ce n’est pas..."


translate french e5s5_massage_gaby_main_746cb4ce:


    gaby "Pourquoi je suis venue ici..."


translate french e5s5_massage_gaby_main_50b86890_1:


    d "Alors pourquoi tes mains sont toujours sur moi ?"


translate french e5s5_massage_gaby_main_89fadf36:


    gaby "Parce que..."


translate french e5s5_massage_gaby_main_16534fb1:


    gaby "Je ne peux pas m'arrêter."


translate french e5s5_massage_gaby_main_0ae9bcd0_1:


    ""


translate french e5s5_massage_gaby_main_4b1beaff:


    dpense "Elle n’évite plus rien."


translate french e5s5_massage_gaby_main_3bb11019:


    d "Tu vois ? Tu es incroyable. Tu me fais fondre sous tes mains."


translate french e5s5_massage_gaby_main_da48d11f:


    gaby "Tu rends ça impossible de rester professionnelle..."


translate french e5s5_massage_gaby_main_a400c057:


    d "Peut-être que je ne veux pas que tu restes professionnelle."


translate french e5s5_massage_gaby_main_863b5583:


    gaby "...Si quelqu'un découvre ça..."


translate french e5s5_massage_gaby_main_c5c828de:


    d "Personne ne le saura. C’est juste nous. Juste ce moment."


translate french e5s5_massage_gaby_main_011f8b53:


    gaby "Alors..."


translate french e5s5_massage_gaby_main_16366704:


    gaby "Ne t’arrête pas..."


translate french e5s5_massage_gaby_main_4040ad56:


    dpense "Sa main bouge lentement… Mon Dieu, c’est tellement agréable."


translate french e5s5_massage_gaby_main_127051e6:


    d "Tu es incroyable… tellement douce..."


translate french e5s5_massage_gaby_main_84fb6e85:


    gaby "Et toi… tu es… tellement dur… c’est fou…"


translate french e5s5_massage_gaby_main_bc45f22f:


    dpense "Je presse mes doigts à l'intérieur d'elle, lentement. Elle arque son dos, haletante."


translate french e5s5_massage_gaby_main_2819d3b3:


    gaby "[name]... c’est... ah..."


translate french e5s5_massage_gaby_main_280253c4:


    dpense "Elle serre sa prise… elle me caresse et maintenant..."


translate french e5s5_massage_gaby_main_b4a12fa6:


    d "...Oh merde..."


translate french e5s5_massage_gaby_main_49787490:


    dpense "Son autre main caresse doucement mes testicules."


translate french e5s5_massage_gaby_main_142e2c27:


    d "Gabriella…"


translate french e5s5_massage_gaby_main_6b6a3cd0:


    gaby "Est-ce que ça te fait du bien ? Tu aimes quand je joue avec toi comme ça ?"


translate french e5s5_massage_gaby_main_823df15c:


    d "Je peux pas... Je veux dire... Ouais. J’adore. Ne t’arrête pas…"


translate french e5s5_massage_gaby_main_0f6591ea:


    dpense "Son corps fond contre le mien. Ses hanches bougent avec mes doigts."


translate french e5s5_massage_gaby_main_72fa43fa:


    gaby "Tu me rends folle… Je peux pas réfléchir… Je veux juste…"


translate french e5s5_massage_gaby_main_182ffcf6:


    dpense "Elle se perd. Et moi je tiens à peine."


translate french e5s5_massage_gaby_main_e7ebce38:


    d "Dis-le. Qu’est-ce que tu veux ?"


translate french e5s5_massage_gaby_main_2129045c:


    gaby "...Plus... Toi. Tout de toi… juste..."


translate french e5s5_massage_gaby_main_de6ec826:


    dpense "Elle se frotte contre ma main, gémissant mon nom..."


translate french e5s5_massage_gaby_main_5fc8c6f9:


    gaby "[name]... ne t’arrête pas, ne t’avise pas de t’arrêter..."


translate french e5s5_massage_gaby_main_7e736253:


    dpense "Sa voix se brise… elle est proche. Et moi aussi."


translate french e5s5_massage_gaby_main_0d706a94:


    d "Ensemble… d’accord ?"


translate french e5s5_massage_gaby_main_db99af1b:


    gaby "Oui… oui..."


translate french e5s5_massage_gaby_main_ffaad131_1:


    gaby "[name] !"


translate french e5s5_massage_gaby_main_755003ab:


    d "Gabriella !"


translate french e5s5_massage_gaby_main_811a0b65:


    gaby "Oh mon dieu… oh mon..."

translate french e5s5_massage_gaby_main_0b2df493:


    gaby "...Qu'est-ce qu'on vient de faire ?"


translate french e5s5_massage_gaby_main_6c647e79:


    d "On a lâché prise. Juste un instant."


translate french e5s5_massage_gaby_main_f49451f4:


    gaby "Je... Je peux pas croire que ça soit arrivé. Je suis ton coach. Je suis censée te guider, pas..."


translate french e5s5_massage_gaby_main_f877753b:


    d "Tu n'as rien fait de mal. Tu étais juste... humaine."


translate french e5s5_massage_gaby_main_9383a269:


    gaby "Ça ne peut pas se reproduire."


translate french e5s5_massage_gaby_main_1523fe20:


    d "..."


translate french e5s5_massage_gaby_main_cd81800a:


    gaby "Je dois y aller."


translate french e5s5_massage_gaby_main_7de26861:


    dpense "Elle est partie. Comme ça."


translate french e5s5_massage_gaby_main_c1d4a101:


    dpense "Je ne sais pas ce qui se passe dans sa tête, mais je sais exactement ce qui se passe dans la mienne."


translate french e5s5_massage_gaby_main_1529b40c:


    dpense "C'était... inoubliable."


translate french e5s5_massage_gaby_main_c47791a5:


    dpense "Mais qu'est-ce que ça veut dire maintenant ?"


translate french e5s5_massage_gaby_main_25815f44:


    dpense "Blue m'attend..."


translate french e5s5_massage_gaby_main_be915c33:


    dpense "Je suppose que j'ai la matinée pour moi."


translate french e5s5_blue_75debac5:


    sofia "Hé toi !"


translate french e5s5_blue_be3f1544:


    d "Sofia."


translate french e5s5_blue_620fb770:


    d "Tu es magnifique aujourd'hui."


translate french e5s5_blue_fc64dba5:


    sofia "Toi aussi. Bien dormi ?"


translate french e5s5_blue_1834f689:


    d "Disons que j'ai déjà passé des nuits pires."


translate french e5s5_blue_bcbec8d3:


    sofia "Parfait. J'ai besoin de ton œil d'homme pour m'aider à choisir un sac."


translate french e5s5_blue_7ec6a092:


    sofia "Et peut-être… un peu plus si tu te tiens bien."


translate french e5s5_blue_ae000f54:


    d "De la corruption dès le matin ?"


translate french e5s5_blue_fb33e447:


    sofia "Appelle ça du charme, M. le Consultant en mode."


translate french e5s5_blue_d5388720:


    d "Au fait, j'ai croisé quelqu'un récemment. Il s'appelle Marc."


translate french e5s5_blue_4252ada9:


    sofia "Marc ? Ça ne me dit rien."


translate french e5s5_blue_947a94bc:


    d "Il semblait savoir beaucoup de choses sur le B.E.S.T... et sur nous."


translate french e5s5_blue_91707ffd:


    sofia "Attends, quoi ? Comment c’est possible ?"

translate french e5s5_blue_c39a3e10:


    d "Aucune idée. Il a dit des trucs bizarres, comme s'il avait accès à tout. Et il m'a averti."


translate french e5s5_blue_70da401d:


    sofia "D'accord, là je commence à flipper."


translate french e5s5_blue_945cec7b:


    sofia "Tu penses qu'il est un genre d'espion ? Un ancien participant ?"


translate french e5s5_blue_b1595f94:


    d "Je ne sais pas. Mais il était trop calme. Trop sûr de lui."


translate french e5s5_blue_66fe77eb:


    d "Je voulais juste te le dire. Au cas où."


translate french e5s5_blue_4198957c:


    sofia "Merci... J'aime que tu me dises ces choses. Je promets de rester vigilante."


translate french e5s5_blue_b1c1af7b:


    sofia "Peut-être que je vais demander à ma sœur. Si quelqu'un peut avoir des infos sur lui, c'est elle."


translate french e5s5_blue_725f748a:


    sofia "Elle peut faire ça pour nous."


translate french e5s5_blue_cf3e6cde:


    d "Nous... Est-ce que tu te demandes ce que ça signifie vraiment ?"


translate french e5s5_blue_9ae6e49d:


    d "Toi et moi. En plein milieu de cette compétition. Les autres filles, les enjeux... tout le monde nous regarde."


translate french e5s5_blue_e94e1e53:


    sofia "Je pense surtout que je t'aime vraiment."


translate french e5s5_blue_acf6b488:


    sofia "Et que c'est trop spécial pour le cacher juste à cause d'un jeu."


translate french e5s5_blue_8b47f51d:


    d "Mais ce n'est pas juste un jeu. Certains d'entre eux feraient n'importe quoi pour gagner. Si on se montre, on devient une cible."


translate french e5s5_blue_37ec2028:


    sofia "Peut-être. Mais si on a trop peur d'aimer, alors on a déjà perdu, non ?"


translate french e5s5_blue_c82f9e2f:


    d "Je... je ne veux pas que tu sois blessée à cause de moi. Ni qu'ils utilisent ça contre nous."


translate french e5s5_blue_dc8acdeb:


    sofia "Tu te fais trop de souci, [name]. Mais..."


translate french e5s5_blue_29b26585:


    sofia "C’est l’une des raisons pour lesquelles je me sens en sécurité avec toi."


translate french e5s5_blue_ebf8e1e8:


    d "Tu veux qu’on prenne un selfie ? Juste pour nous."


translate french e5s5_blue_4c765146:


    sofia "J'adorerais ça."


translate french e5s5_blue_5657a5b4:


    d "Voilà. Un parfait cliché d'un couple puissant."


translate french e5s5_blue_2bc5878d:


    d "Tu penses que je devrais le poster ? Le rendre... un peu officiel ?"


translate french e5s5_blue_274949db:


    sofia "Hmm... Tu veux dire genre, ‘Hé le monde, elle est à moi’ ?"


translate french e5s5_blue_7eef06a5:


    d "Je veux dire... est-ce qu'on est prêts pour ça ? Le montrer à tout le monde, alors que les gens surveillent chacun de nos gestes ?"


translate french e5s5_blue_dc3b82d2:


    sofia "Je dis qu’on arrête de se cacher et qu’on commence à vivre. Si ça semble réel, laissons-le être réel."


translate french e5s5_blue_75d187ba:


    d "C’est fait. C’est peut-être un petit geste, mais ça veut dire beaucoup."

translate french e5s5_blue_aa655c08:


    sofia "Wow... d'accord. C'est officiel maintenant."


translate french e5s5_blue_2141b0cb:


    sofia "Tu vas avoir quelques commentaires jaloux."


translate french e5s5_blue_d2080394:


    d "Qu'ils viennent. Une seule opinion m'importe."


translate french e5s5_blue_e6fba878:


    d "La tienne."


translate french e5s5_blue_2f874638:


    sofia "Charmeur."


translate french e5s5_blue_f483d2ca:


    d "Non... pas encore. Gardons ça juste pour nous pour l'instant."


translate french e5s5_blue_5baa0c26:


    sofia "D'accord. Tant que c'est réel, ça me suffit."


translate french e5s5_blue_e9989e88:


    sofia "Mais un jour, tu ferais bien de montrer au monde ce que tu as."


translate french e5s5_blue_845b87d7:


    d "Marché conclu. Mais TOI, tu ferais bien de me montrer ce que tu as !"


translate french e5s5_blue_fc056c41:


    sofia "Tu veux dire ce fessier ???"


translate french e5s5_blue_801518fe:


    d "Exactement !"


translate french e5s5_blue_da65a7e3:


    sofia "Ahah !"


translate french e5s5_blue_2907598c:


    d "Gardons ce moment pour nous. J'aime avoir ça juste pour nous."


translate french e5s5_blue_233674e4:


    sofia "Moi aussi. Ça le rend encore plus spécial."


translate french e5s5_blue_64417f8f:


    d "Hmm ? Un message de Grace."


translate french e5s5_blue_a2dd00bb:


    sofia "Et un de ma sœur."


translate french e5s5_blue_a9a66518:


    d "Il est temps d'y aller."


translate french e5s5_blue_a6f4c0d7:


    sofia "Je suppose qu'on achètera ce sac une autre fois."


translate french e5s5_blue_33e6da38:


    d "La prochaine fois, rien ne nous arrête."


translate french e5s5_blue_7cd819e6:


    sofia "Marché conclu. Maintenant va gagner ce truc."


translate french e5s5_blue_a3289c70:


    d "Oh, tu veux gagner ?"


translate french e5s5_blue_f716865d:


    sofia "Moi ? Non ! Je m'en fiche !"


translate french e5s5_blue_fb9c731f:


    sofia "Mais je vais t'aider."


translate french e5s5_blue_dd5d68f3:


    d "Hein ?"


translate french e5s5_blue_580c045a:


    sofia "Si je peux..."

translate french e5s5_prep_match_64417f8f:


    d "Hmm ? Un message de Grace."


translate french e5s5_prep_match_a9a66518:


    d "Il est temps d'y aller."

translate french strings:


    old "Gently pull her gown back into place.[TEMP1!t]"
    new "Tire doucement sa robe pour la remettre en place.[TEMP1!t]"


    old "Leave it as it is...[TEMP2!t]"
    new "Laisse comme ça...[TEMP2!t]"


    old "Morning, troublemaker. 😘"
    new "Bonjour, fauteur de troubles. 😘"


    old "Wanna help me pick out a new bag today?"
    new "Tu veux m'aider à choisir un nouveau sac aujourd'hui ?"


    old "Meet me at 11? You’ll get bonus kisses."
    new "On se retrouve à 11h ? Tu auras des bisous bonus."


    old "You drive a hard bargain."
    new "Tu sais comment négocier."


    old "Only fair. You drive me crazy."
    new "C'est bien mérité. Tu me rends folle."


    old "Post the selfie on OnlyStan"
    new "Publie le selfie sur OnlyStan"


    old "Don’t post it"
    new "Ne le publie pas"


    old "My new universe ;)"
    new "Mon nouveau univers ;)"


    old "Discovering each other!"
    new "Nous découvrons l'un l'autre !"


    old "Where are you?! It's time!!"
    new "Où es-tu ?! C'est l'heure !!"


    old "Everyone needs to be at the stadium!"
    new "Tout le monde doit être au stade !"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
