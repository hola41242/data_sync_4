


translate french e5intro_7a6dbcfd:


    ji "Merci à vous de garder Ruby ce soir, Carmen. C'est un soulagement de la savoir avec vous."


translate french e5intro_edb6d03d:


    carmen "Bien sûr ! Ne vous inquiétez pas. On va passer un bon moment."


translate french e5intro_929c4d69:


    ji "Merci beaucoup. À plus tard !"


translate french e5intro_9e5be354:


    ruby "Tu veux faire quoi quand tu seras grande ?"


translate french e5intro_87095544:


    mad "Moi ? Je serai une reine ! J'aurai un immense château, et tout le monde fera ce que je dis."


translate french e5intro_905b78ff:


    ruby "Waouh ! Et moi ? Qu’est-ce que je ferais dans ton château ?"


translate french e5intro_12303531:


    mad "Tu seras ma garde du corps ! Comme dans les films ! Tu seras super forte et tu me protégeras."


translate french e5intro_577e458b:


    ruby "Oui ! Je serai super forte, et personne ne viendra t’embêter !"


translate french e5intro_9c810aea:


    mad "Voilà. Comme ça, on sera toujours ensemble."


translate french e5intro_12fa9d5f:


    ruby "D’accord ! Je te protégerai toujours."


translate french e5intro_5b31b56d:


    carmen "Officier ?"


translate french e5intro_48c88889:


    ji "Madame Forrester, je suis désolé de passer si tard, mais j’ai une mauvaise nouvelle."


translate french e5intro_2eb678a8:


    ji "C’est au sujet de M. et Mme Suyin. Ils ont eu un accident de voiture."


translate french e5intro_f19a3649:


    ji "Un camion est apparu de nulle part et a percuté leur voiture. Les secours sont arrivés rapidement, mais… c’était trop tard. Ils n’ont pas survécu."


translate french e5intro_4845026b:


    carmen "Les deux ? Vous êtes sûr qu’il n’y a aucun espoir ?"


translate french e5intro_507c9a75:


    ji "Je suis vraiment désolé. Non, il n’y a eu aucun survivant."


translate french e5intro_00836242:


    carmen "Et Ruby ? Qu’est-ce qui va lui arriver maintenant ? C’est juste une petite fille…"


translate french e5intro_1a9d63a8:


    ji "Les services sociaux seront prévenus. Ils contacteront les membres de la famille les plus proches pour organiser sa prise en charge."


translate french e5intro_4f4626eb:


    carmen "Je vois. Mais en attendant, elle est ici. Elle connaît cet endroit, elle s’y sent en sécurité."


translate french e5intro_a7266098:


    carmen "Est-ce que je peux la garder avec moi jusqu’à ce que tout soit réglé ? Je veux juste m’assurer qu’elle va bien."


translate french e5intro_6d6764e8:


    ji "Cela me semble raisonnable. Mais vous devrez rapidement vous coordonner avec les autorités pour rendre cela officiel."


translate french e5intro_35108db2:


    carmen "Bien sûr. Je ferai tout dans les règles. Je veux juste qu’elle se sente en sécurité et protégée."


translate french e5intro_ecb697e9:


    ji "Très bien. Je vous tiendrai informée dès que j’aurai plus d’informations."


translate french e5intro_a554831c:


    mad "Tu te souviens de ce que j’ai dit ? Je serai toujours là pour toi. Tout ira bien."


translate french e5intro_b7de6fef:


    mad "Plus tard, quand on sera grandes, tout ira mieux. Tu verras."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
