

translate french strings:


    old "Look at the numbers backwards"
    new "Regardez les chiffres à l'envers"


    old "Don't click on the image"
    new "Ne cliquez pas sur l'image"


    old "The answer is in the question"
    new "La réponse est dans la question"



translate french strings:


    old "Please choose your teammate..."
    new "Veuillez choisir votre partenaire..."


    old "    Bonus: Objects"
    new "    Bonus: Objets"


    old "    Bonus: Speed"
    new "    Bonus: Vitesse"


    old "    Bonus: Hint"
    new "    Bonus: Indice"


    old "    Bonus: Brain"
    new " Bonus: Mastermind"


    old "    Bonus: Mother"
    new "    Bonus: Mère"


    old "    Bonus: Places"
    new "    Bonus: Endroits"



translate french strings:


    old "You're everyone's best friend!"
    new "Vous êtes le meilleur ami de tous!"


    old "Knowledge is your power!"
    new "Le savoir est votre atout!"


    old "You’re a true champion!"
    new "Vous êtes un vrai champion!"


    old "You lead the way!"
    new "Vous menez le groupe!"


    old "Follow ELISE and OUR HERO in the next level of the competition!"
    new "Suivez ELISE et NOTRE HEROS dans le prochain niveau de la compétition!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
