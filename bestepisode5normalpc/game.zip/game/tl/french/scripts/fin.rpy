


translate french fin_d13211cd_1:


    julia "Hey coucou ! On dirait que tu as atteint la fin de cette mise à jour ! J'espère que tu l'as aimé !"


translate french fin_591d2301:


    julia "Quand la mise à jour est mise en ligne, les Créateurs la mettent sur différents sites web..."


translate french fin_e6109cf4_1:


    cr "Ouais... Quand je fais pas n'importe quoi avec les mises à jour..."


translate french fin_7c77b00a_1:


    julia "Ouais bon... Si tu aimes le jeu, les filles, ou même les Créateurs, pense à montrer ton soutien !"


translate french fin_f803f865_1:


    julia "Dis leur ce que tu aimes, ce que tu aimerais voir dans le jeu, quel personnage est ton favori..."


translate french fin_241336b2:


    julia "En donnant de l'argent pour montrer ton soutien, les Créateurs peuvent m'acheter plein de vêtements et j'ADORE les vêtements !!!"


translate french fin_6155034b_1:


    cr "Tu veux pas 100 balles et un mars non plus ?"


translate french fin_e17d85e1_1:


    julia "... Bon surtout ils pourront acheter une nouvelle machine pour faire des images et du contenu beaucoup plus rapidement..."


translate french fin_d1f2e7be_1:


    cr "Oui c'est vrai... Une image ou une animation prend beaucoup de temps et on n'a pas une machine de la NASA...."


translate french fin_8556d080_1:


    julia "Bref ce serait sympa d'y penser !"


translate french fin_08fa1cc4_1:


    julia "Bon, je vais pas te garder plus longtemps..."


translate french fin_73504a9c_1:


    julia "J'espère que tu reviendras !"


translate french fin_5c8aa31e_1:


    julia "A bientôt !"




translate french fin_845373f5:


    grace "Hey toi ! Tu aimes le jeu ?"


translate french fin_f190bc01:


    grace "Génial ! Est ce que tu pourrais nous aider en ajoutant le jeu à ta wishlist sur STEAM ?"


translate french fin_b873e822:


    grace "Ca ne te coûte rien mais pour nous c'est hyper important pour l'arrivée de l'épisode 2 sur Steam en janvier !"


translate french fin_9c14f477:


    grace "Alors... Peux tu cliquer sur ce lien ?"


translate french fin_550056d1:


    grace "Ah bon ? Je suis désolée... Mais tu peux laisser des avis et commentaires sur ce que tu aimes, ou n'aime pas, sur les différents sites et forums..."


translate french fin_36653393:


    grace "Dis nous ce que tu aimes et ce que tu veux dans un jeu !"


translate french fin_b32a6fc0:


    grace "Et si tu veux quand me^me nous aider tu peux cliquer sur ce lien pour ajouter le jeu à ta wishlist sur STEAM !"


translate french fingrace_dd6e84e8:


    grace "Merci beaucoup pour le temps passé sur notre jeu "


translate french fingrace_a9060cf0:


    julia "Ah coucou ! On dirait que tu as atteint la fin de cette mise à jour... J'espère que ça t'a plu !"


translate french fingrace_38aab629:


    julia "Quand la mise à jour est prête, les Créateurs la mettent sur différents sites..."


translate french fingrace_e6109cf4:


    cr "Ouais enfin je le fais quand je comprend comment ça marche..."


translate french fingrace_7c77b00a:


    julia "Bref... Si tu aimes le jeu, les filles, ou les Créateurs, n'oublies pas de nous supporter !"


translate french fingrace_f803f865:


    julia "En laissant des commentaires sur ce que tu aimes, sur ce que tu voudrais voir dans le jeu, quel personnage est ton préféré..."


translate french fingrace_241336b2:


    julia "En donnant de l'argent pour nous aider au développement, les Créateurs pourront m'acheter des vêtements et j'ADORE les vêtements !!!"


translate french fingrace_6155034b:


    cr "Tu veux pas 100 balles et un mars non plus ?"


translate french fingrace_e7507687:


    julia "... Bon okay ils pourront surtout acheter du matériel plus puissant pour faire des rendus de meilleure qualité et des animations sympas...."


translate french fingrace_d1f2e7be:


    cr "Oui tu as raison... Les images et les animations prennent du temps et on n'a pas un ordi de la NASA à la maison...."


translate french fingrace_8556d080:


    julia "Si tu peux au moins y réfléchir !"


translate french fingrace_08fa1cc4:


    julia "Bon je ne vais pas te garder plus longtemps...."


translate french fingrace_73504a9c:


    julia "J'espère vraiment que tu reviendras !"


translate french fingrace_5c8aa31e:


    julia "A bientôt !"




translate french fin_7d9b621c:


    grace "Génial ! J'aimerais que vous nous aidiez en nous laissant une review sur STEAM !"


translate french fin_3ba5730c:


    grace "C'est peut être un détail pour vous, mais pour nous ça veut dire beaucoup !"


translate french fingrace_e4a123b7:


    julia "J'espère vraiment que vous reviendrez quand la prochaine mise à jour sera lancée !"




translate french fin_254dd07d:


    grace "Coucou toi ! Dis-moi, est-ce que le jeu te plaît ?"


translate french fin_ad4cee14:


    grace "Si c'est le cas... C'est juste le début ! Alors prépare toi à une histoire excitante et à encore plus d'aventures très bientôt !"


translate french fin_434cd35f:


    grace ""


translate french fin_fe8ebd99:


    grace ""


translate french fingrace_64116e44:


    grace "Merci à toi en tous cas pour avoir choisi ce jeu. Nous espérons vraiment que tu as passé du bon temps dessus avec nous !"


translate french fingrace_d13211cd:


    julia "Ah ! On dirait que tu es arrivé à la fin de cette mise à jour ! J'espère que tu l'as appréciée !"


translate french fingrace_b9df2fb5:


    cr "Ouais... Quand j'aurais compris comment ça fonctionne je le ferais..."


translate french fingrace_4a83dbf2:


    cr "Tu veux pas 100 balles et un mars non plus ?"


translate french fingrace_c2ddfb8d:


    julia "Ben si vous proposez... Je déconne ! Nan mais en vrai, grace au support ils peuvent acheter du nouveau matériel et faire plus de contenu... de meilleure qualité..."


translate french fingrace_47f68eca:


    julia "Bon je vais pas vous retenir plus longtemps !"


translate french fingrace_28c14350:


    julia "J'espère vraiment que vous reviendrez à la prochaine mise à jour !"




translate french fin_df49880d:


    grace "Si c'est le cas... C'est juste le début ! Alors prépare toi à une histoire excitante et à encore plus d'aventures très bientôt !"




translate french fingrace_0ea9a7e1:


    gaby "Fais attention [name]..."


translate french fingrace_2c7a6b72:


    mad "Père... Pourquoi est ce que tu veux le rencontrer ?"


translate french fingrace_315b4afb:


    mad "..."


translate french fingrace_9f07be60:


    mad "Je le ferais..."


translate french fingrace_84936006:


    cha "Tu vas à la soirée ce soir ?"


translate french fingrace_d681a17c:


    ruby "Il faut que je me trouve une robe !"


translate french fingrace_3d8592ac:


    ruby "Et une autre pour notre sortie au cinéma !"


translate french fingrace_7a16ee9c:


    grace "Tu es le seul que je veux ce soir..."




translate french fingrace_b7de489c:


    ji "Fais attention [name]..."


translate french fingrace_7a29416a:


    ji "Toi aussi tu vas à la fête ce soir ?"




translate french fingrace_aee41bbd:


    ji "Maman..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
