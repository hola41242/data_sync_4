

translate french strings:


    old "Replayer"
    new "Replayer"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
