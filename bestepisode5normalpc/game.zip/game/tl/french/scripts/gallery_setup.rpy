

translate french strings:


    old "{color=#ffffffff}Taxi Drive{/color}"
    new "{color=#ffffffff}Taxi Drive{/color}"


    old "{color=#ffffffff}Red is Dead{/color}"
    new "{color=#ffffffff}Red is Dead{/color}"


    old "{color=#ffffffff}Bed is Red{/color}"
    new "{color=#ffffffff}Bed is Red{/color}"


    old "{color=#ffffffff}Kitty{/color}"
    new "{color=#ffffffff}Kitty{/color}"


    old "{color=#ffffffff}Dirty{/color}"
    new "{color=#ffffffff}Dirty{/color}"


    old "{color=#ffffffff}Yummy{/color}"
    new "{color=#ffffffff}Yummy{/color}"


    old "{color=#ffffffff}Ice-Cream{/color}"
    new "{color=#ffffffff}Ice-Cream{/color}"


    old "{color=#ffffffff}MotorButt{/color}"
    new "{color=#ffffffff}MotorButt{/color}"


    old "{color=#ffffffff}Mystery{/color}"
    new "{color=#ffffffff}Mystery{/color}"



translate french strings:


    old "{color=#ffffffff}Temple{/color}"
    new "{color=#ffffffff}Temple{/color}"


    old "{color=#ffffffff}Bed is Blue{/color}"
    new "{color=#ffffffff}Bed is Blue{/color}"


    old "{color=#ffffffff}Shooting{/color}"
    new "{color=#ffffffff}Shooting{/color}"


    old "{color=#ffffffff}Mother{/color}"
    new "{color=#ffffffff}Mother{/color}"


    old "{color=#ffffffff}Peace{/color}"
    new "{color=#ffffffff}Peace{/color}"


    old "{color=#ffffffff}Witch{/color}"
    new "{color=#ffffffff}Witch{/color}"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
