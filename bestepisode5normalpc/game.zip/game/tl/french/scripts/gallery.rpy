

translate french strings:


    old "Rufus Found : [persistent.rufusgame] / 9"
    new "Rufus Trouvés : [persistent.rufusgame] / 9"



translate french strings:


    old "Rufus Found : [persistent.rufusgame] / 15"
    new "Rufus Trouvés : [persistent.rufusgame] / 15"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
