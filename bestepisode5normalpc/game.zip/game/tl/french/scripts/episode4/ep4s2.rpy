


translate french ep4s2_94fa98b5:


    dpense "Bon..."


translate french ep4s2_69ed6f54:


    dpense "Une autre journée de passée."


translate french ep4s2_004519e6:


    dpense "Je vais vérifier mon téléphone rapidement avant de dormir."


translate french ep4s2_87ce1d2e:


    dpense "Je dois rester concentré pour demain."


translate french ep4s2_4408d1f3:


    dpense "Toujours pas de nouvelles d'Élise."


translate french ep4s2_c054dd5a:


    dpense "C'est pas normal..."


translate french ep4s2_ffc0b3a5:


    dpense "J'espère qu'elle va bien..."


translate french roommcep4_5dda0f88:


    d "Hmm ?"


translate french bluephonep4inter_bffc964b:


    dpense "J'espère qu'elle ira bien ce soir..."

translate french strings:


    old "Hey, still awake?"
    new "Hé, toujours réveillée ?"


    old "For you? Always. :)"
    new "Pour toi ? Toujours. :)"


    old "I couldn't end the day without talking to you."
    new "Je ne pouvais pas finir la journée sans te parler."


    old "You're such a sweetheart. I missed you today."
    new "Tu es tellement adorable. Tu m'as manqué aujourd'hui."


    old "I missed you too. Feels like something was missing all day."
    new "Toi aussi, tu m'as manqué. C'est comme s'il me manquait quelque chose toute la journée."


    old "Same here. But hearing from you now makes up for it."
    new "Pareil ici. Mais t'avoir maintenant vaut bien toute cette attente."


    old "Good. I was worried I might’ve been the only one feeling like that."
    new "Bien. J'avais peur d'être le seul à ressentir ça."


    old "Never. You’re stuck with me now, remember?"
    new "Jamais. Tu es coincé avec moi maintenant, tu te souviens ?"


    old "Wouldn’t want it any other way."
    new "Je ne voudrais pas qu'il en soit autrement."


    old "Me neither."
    new "Moi non plus."


    old "Alright, I’ll let you get some rest now. Sweet dreams, my girl."
    new "D'accord, je te laisse te reposer maintenant. Fais de beaux rêves, ma belle."


    old "Sweet dreams, my guy. Sleep well. <3"
    new "Fais de beaux rêves, mon homme. Dors bien. <3"


    old "Hey, Sofia. Missed me today?"
    new "Hé, Sofia. Je t'ai manqué aujourd'hui ?"


    old "Maybe... Or maybe I was just busy thinking about last night. ;)"
    new "Peut-être... Ou peut-être que j'étais occupée à penser à hier soir. ;)"


    old "Oh? The part where you couldn’t keep your balance?"
    new "Oh ? La partie où tu ne pouvais pas garder ton équilibre ?"


    old "Please. You’re the one who couldn’t resist. That bathroom got... steamy fast."
    new "S'il te plaît. C'est toi qui ne pouvais pas résister. Cette salle de bain est devenue... torride rapidement."


    old "Can you blame me? You’re hard to resist."
    new "Tu peux pas m'en vouloir! C'est difficile de te résister."


    old "Good answer. Let’s just say I’ve been replaying that moment in my head all day."
    new "Bonne réponse. Disons que j'ai rejoué ce moment dans ma tête toute la journée."


    old "Now I’m replaying it too. Thanks for that."
    new "Maintenant je le rejoue aussi. Merci pour ça."


    old "You're welcome. But let’s switch gears before this conversation gets too hot."
    new "De rien. Mais changeons de sujet avant que cette conversation ne devienne trop chaude."


    old "I have a surprise for you!"
    new "J'ai une surprise pour toi !"


    old "What? What kind of surprise?"
    new "Quoi ? Quel genre de surprise ?"


    old "WoW! It fits you so well!"
    new "Waouh ! Ça te va si bien !"


    old "Ahah! Thank you!"
    new "Ahah ! Merci !"


    old "My sister knows about us, you know."
    new "Ma sœur est au courant pour nous, tu sais."


    old "Wait, Elisabeth? How?"
    new "Attends, Élisabeth ? Comment ?"


    old "She has her ways. Plus, she knows there’s an event tomorrow."
    new "Elle a ses infos. En plus, elle sait qu'il y a un événement demain."


    old "She’s convinced it’ll be an elimination round."
    new "Elle est convaincue que ce sera un tour éliminatoire."


    old "Elisabeth always has the inside scoop, doesn’t she?"
    new "Élisabeth a toujours des infos exclusives, n'est-ce pas ?"


    old "Of course. She loves to be in control. Don’t let her intimidate you tomorrow, okay?"
    new "Bien sûr. Elle adore avoir le contrôle. Ne la laisse pas t'intimider demain, d'accord ?"


    old "You worried about me?"
    new "Tu t'inquiètes pour moi ?"


    old "Maybe. But I know you’ll handle it. Just don’t let her play her games with you."
    new "Peut-être. Mais je sais que tu géreras. Ne la laisse juste pas jouer avec toi."


    old "Got it. Thanks for the heads-up, Sofia."
    new "C'est noté. Merci pour l'info, Sofia."


    old "Don’t thank me yet. I might need another... Private moment to stay motivated. You know, like last night."
    new "Ne me remercie pas encore. J'aurai peut-être besoin d'un autre... moment privé pour rester motivée. Tu sais, comme hier soir."


    old "Careful, or I might call your bluff."
    new "Attention, sinon je pourrais répondre à ton bluff."


    old "Bluff? Who said I was bluffing? Goodnight, [name]. Sweet dreams. ;)"
    new "Bluff ? Qui a dit que je bluffais ? Bonne nuit, [name]. Fais de beaux rêves. ;)"


    old "Goodnight, Sofia. Don’t dream too much about me."
    new "Bonne nuit, Sofia. Ne rêve pas trop de moi."



translate french strings:


    old "Maybe... Or maybe I was just busy thinking about last night. ;) "
    new "Peut être... Ou peut être j'étais juste en train de penser à hier soir. ;) "


    old "Bluff? Who said I was bluffing? Goodnight, [name]. Sweet dreams. ;) "
    new "Bluff? Qui a dit que je bluffais? Bonne nuit, [name]. Fais de beaux rêves. ;) "
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
