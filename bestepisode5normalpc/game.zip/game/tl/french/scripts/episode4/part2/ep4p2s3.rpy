


translate french ep4p2s3_1b4b1a57:


    dpense "Bon... Demain le match."


translate french ep4p2s3_f5497cd8:


    dpense "Va falloir que je sois au niveau face à l'équipe de Steven."


translate french ep4p2s3_a4145184:


    dpense "Et Hector... Il va sûrement chercher les emmerdes."


translate french ep4p2s3_fd950b31:


    dpense "Pfff...."


translate french ep4p2s3_e009422d:


    dpense "Rouge m'a demandé de lui envoyer un message."


translate french ep4p2s3_8d0d9a0a:


    dpense "On va lui envoyer un truc... Au moins ce sera fait."


translate french ep4p2s3_b2db8fea:


    dpense "Bon, c'est bon, je suppose."


translate french ep4p2s3_7de58b15:


    dpense "Quel après-midi avec Grace..."


translate french ep4p2s3_8ecbb8fb:


    dpense "Sa chaleur, son corps... et ce moment dans le jacuzzi. Inoubliable."


translate french ep4p2s3_40fe0c09:


    dpense "Cette soirée chez Sofia était incroyable."


translate french ep4p2s3_18b96cc1:


    dpense "Elle s'ouvre à moi complètement, tandis que Rouge reste aux aguets, toujours sur sa garde."


translate french roommcep42_cd3b9b76:


    dpense "Bon, il est temps de dormir... même si j'ai la tête en ébullition."


translate french roommcep42_e5eaf1ae:


    dpense "Espérons que je puisse me reposer cette nuit... Ou peut être encore des rêves bizarres..."


translate french reverobotchat_5074775d:


    dpense "Tout semble... Bizarre. Je suis pas sûr d'où je suis, mais ça me semble familier, comme un souvenir que je ne peux déchiffrer."


translate french reverobotchat_b353e56c:


    d "Quel est cet endroit?"


translate french reverobotchat_195839f0:


    dpense "Une forêt brillante... Les arbres semblent prendre vie, et le sol qui se dérobe sous mes pieds comme si je marchais sur un nuage."


translate french reverobotchat_1c07a19a:


    d "Ca ne peut être réel."


translate french reverobotchat_65f9a265:



    voice "Tu reviens de loin, mais il y a encore beaucoup à faire."
    dpense "Qui est là?"


translate french reverobotchat_e207e7ac:


    voice "Vos choix façonnent le chemin. Le résultat n'est jamais fixé."


translate french reverobotchat_5021a89c:


    dpense "Maintenant je suis dans une ville mais c'est désert. Les buildings s'élèvent hauts dans le ciel, leurs murs pulsant de leur lumière."


translate french reverobotchat_93b6b973:


    dpense "Il y a une sorte d'odeur métallique dans l'air, comme si la ville elle-même était en vie."


translate french reverobotchat_a845ca80:


    dpense "Quel est ce bruit?"


translate french reverobotchat_ad1fc3b6:


    dpense "Un... Robot-chat? On dirait Mr. Rufus, mais c'est métallique, avec des yeux qui brillent et une allure mécanique."


translate french reverobotchat_ba346cd0:


    d "Mr. Rufus? C'est bien vous?"


translate french reverobotchat_ddf42f0d:


    robot_cat "Profil activé."


translate french reverobotchat_77795da7:


    dpense "De quoi? Ca veut dire quoi?"


translate french reverobotchat_368425d0:


    robot_cat "Analyser. Adapter. Agir."


translate french reverobotchat_ba7bb93c:


    d "De quoi parlez-vous? S'adapter à quoi?"


translate french reverobotchat_49670042:


    robot_cat "Les pieces sont en mouvement. Vous êtes l'une d'entre elles."


translate french reverobotchat_f14836fd:


    dpense "Pieces? En mouvement? Mais ça veut dire quoi?"


translate french reverobotchat_d5394f74:


    robot_cat "Le temps est venu. Réveille-toi... et rapelle-toi."


translate french reverobotchat_b2f6c52c:


    robot_cat "PROFIL ACTIVE"


translate french reverobotchat_2ecd560f:


    dpense "Ce rêve... ça paraissait tellement vrai. Le robot-chat, la voix... Et ce 'Profil activé'?"


translate french reverobotchat_e68135ad:


    "PROFIL ACTIVE" with hpunch


translate french reverobotchat_11991fc8:


    d "Quoi????"


translate french reverobotchat_91b9690d:


    d "C'est mon téléphone?"

translate french strings:


    old "Hey, ready for tomorrow?"
    new "Hey, t'es prête pour demain?"


    old "Of course! You?"
    new "Bien sûr! Et toi?"


    old "I’m a little nervous. Steven’s team is tough, and I don’t want to let everyone down."
    new "Un peu nerveux. L'équipe de Steven est d'un autre niveau et j'ai pas envie de décevoir les autres."


    old "Don’t even think about that! They’re strong, sure, but so are we."
    new "Pense pas à ça! Ils sont forts c'est sûr mais nous aussi!"


    old "Plus, we’ve got Madison! And you! You’re our secret weapon."
    new "Et en plus on a Madison! Et toi! Tu es notre arme secrète!"


    old "Secret weapon, huh? No pressure there."
    new "Arme secrète? Pas de pression non non..."


    old "Hey, if anyone can handle it, it’s you. You’ve got this."
    new "Hey, si y'à bien quelqu'un qui peut s'en sortir, c'est toi. Tu vas gérer."


    old "Thanks, Ruby. I’ll do my best."
    new "Merci Ruby. Je vais faire de mon mieux."


    old "I know you will. Just focus on the game, not the scoreboard. We’ll handle the rest."
    new "Je sais que tu le feras. Concentre toi sur le jeu, pas sur le score. On fera le reste."


    old "Alright. I’ll try to get some sleep. See you tomorrow!"
    new "Okay. Je vais essayer de dormir. A demain!"


    old "You better bring your A-game tomorrow, because we’re taking them down. Good night!"
    new "T'as intérêt à emmener ton meilleur coup de pied demain, parce qu'on va les éclater! Bonne nuit!"


    old "Hey, remember earlier at the hospital? I found something weird in my pocket: '1410'."
    new "Hey, tu te rapelle à l'hôpital? J'ai trouvé un truc dans ma poche : '1410'"


    old "What? That’s random."
    new "De quoi? C'est quoi?"


    old "I have no idea where it came from. That’s why I’m asking you."
    new "Aucune idée d'où ça vient. C'est pour ça que je te le demande."


    old "I… don’t think it rings a bell. Maybe it’s a date? 14/10? Or a time? 14:10?"
    new "Je... vois pas du tout ce que ça pourrait être. C'est une date? 14/10 ? ou une heure? 14:10?"


    old "No, it’s just '1410'. Plain and simple."
    new "Nan c'est juste '1410'. Simple."


    old "Hmm… That’s strange. Do you think someone might have slipped it into your pocket?"
    new "Hmmm... C'est bizarre. Tu penses que quelqu'un l'a mis dans ta poche exprès?"


    old "Honestly, I don’t know. Maybe. It’s weird though."
    new "Je sais pas du tout. Peut être. C'est spé quand même."


    old "Yeah… With everything going on today, I didn’t even notice."
    new "Ouais... Avec tout ce qui s'est passé aujourd'hui, j'ai pas fait attention."


    old "But this is kind of unsettling."
    new "Mais c'est étrange."


    old "I’ll let you know if I figure it out."
    new "Je te dis si je trouve ce que c'est."


    old "Please do. Good night!"
    new "oui tiens moi au courant. Bonne nuit!"


    old "Good night, Julia."
    new "Bonne nuit, Julia."




translate french ep4p2s3_e869a1ff:


    dpense "La soirée chez Sofia était incroyable."


translate french roommcep42_9a227918:


    d "Humm?"


translate french roommcep42_1d8f8cec:


    dpense "Et... pas de réponse..."


translate french reverobotchat_1d9e1362:


    "Tu viens de loin, mais il y a encore du chemin à faire."


translate french reverobotchat_61c079a3:


    dpense "Qui est là?"


translate french reverobotchat_a8e4f680:


    "Vos choix définissent le chemin. Le résultat n'est jamais fixé."


translate french reverobotchat_e203e08c:


    dpense "Où suis-je?"


translate french reverobotchat_90cc6b8b:


    dpense "Il y a une odeur mécanique dans l'air."


translate french reverobotchat_172d9967:


    dpense "Qu'est ce que c'est?"


translate french reverobotchat_1d738374:


    dpense "Un... Robochat?"


translate french reverobotchat_a4080e44:


    "Profil activé."


translate french reverobotchat_68c3eab0:


    "Analyser."


translate french reverobotchat_90926537:


    "S'adapter."


translate french reverobotchat_c12d5bca:


    "Agir."


translate french reverobotchat_445be304:


    "Les pièces sont en mouvement. Vous êtes l'une d'entre elles."


translate french reverobotchat_d1fb5488:


    d "Pièces? Mouvement? Qu'est ce que ça veut dire?"


translate french reverobotchat_dea02d29:


    "Le temps est venu. Réveille-toi... et rapelle-toi."


translate french reverobotchat_733ada87:


    "PROFIL ACTIVE."

translate french strings:


    old "A great night with good company!"
    new "Une super soirée en bonne compagnie!"


    old "Look who we found tonight!"
    new "Regardez qui on a rencontré ce soir?"


    old "Awesome night! Let's do this again anytime!😊"
    new "Une soirée géniale! On se refait ça quand vous voulez!😊"


    old "A great night with my BF!"
    new "Une super soirée avec ma BF!"


    old "Partying together!"
    new "En soirée ensemble!"


    old "Oh! I missed this? Next time I will be there!"
    new "Oh! J'ai râté ça? La prochaine fois je serais là!"


    old "You're doing great [name]."
    new "Tu t'en sors bien [name]."


    old "What do you want from me?"
    new "Qu'est ce que vous voulez de moi?"


    old "Just listen to me."
    new "Que tu m'écoutes."


    old "Play for you."
    new "Joue pour toi."


    old "What does that mean?"
    new "Comment ça?"


    old "Time will come."
    new "Ca va bientôt commencer."


    old "Come on! This is cryptic!"
    new "Allez! Arrêtez les énigmes!"


    old "Once we met, remember this."
    new "Quand on se verra, rapelle-toi de ça."


    old "remember what?"
    new "Se rapeller de quoi?"


    old "Hum... Can I ask you something?"
    new "Hum... Je peux te demander quelque chose?"


    old "Sure!"
    new "Bien sûr!"


    old "Tomorrow, after the match..."
    new "Demain, après le match..."


    old "Would you like to come to the cinema with me?"
    new "Tu veux bien venir au cinéma avec moi?"


    old "Yes! It would be a pleasure!"
    new "Oui! Avec plaisir!"


    old "Thank you so much!!!"
    new "Trop bien! Merci!!!!"


    old "I promised to you."
    new "Je te l'ai promis."




translate french roommcep42_68efe25b:


    d "Encore? C'est quoi ça?"


translate french roommcep42_4ee878c5:


    "Charlotte demande à vous ajouter à ses contacts..."


translate french roommcep42_f16cfd6d:


    "Voulez-vous l'ajouter?"


translate french roommcep42_29a3c486:


    d "Qu'est ce qu'elle me veut?"


translate french roommcep42_06b50b53:


    d "J'ai rien compris..."


translate french roommcep42_cf36c76d:


    d "J'ai déjà assez de monde à gérer..."



translate french strings:


    old "Once we meet, remember this."
    new "Quand on se verra, rapelle toi de cela."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
