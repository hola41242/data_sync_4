


translate french ep4p2s2_530acdfa:


    dpense "C'est ici que Sofia m'a dit de la retrouver. Elle ne devrait pas être longue maintenant."


translate french ep4p2s2_df219c63:


    sofia "Ah ben te voilà! Je t'ai vu tourner dans le quartier comme un détective."


translate french ep4p2s2_54b8e1eb:


    dpense "Elle semble être de bonne humeur. Tant mieux, je me sentais un peu nerveux."


translate french ep4p2s2_bad4aa28:


    d "Je prenais juste l'air."


translate french ep4p2s2_e9b4b60e:


    sofia "Si tu continues comme ça, je vais pas te laisser partir."


translate french ep4p2s2_a06bc4dc:


    d "Tu vas vraiment me stopper?"


translate french ep4p2s2_60084afa:


    sofia "Allez, viens. Ma maison est juste à côté."


translate french ep4p2s2_7f47e358:


    d "Tes parents sont là ce soir?"


translate french ep4p2s2_1fd8512e:


    sofia "Non, comme d'habitude, ils sont en voyage d'affaires. Mais ne t'inquiète pas, Elizabeth et moi pouvont gérer les choses."


translate french ep4p2s2_93e190ef:


    dpense "Voyager autant... Ca doit faire bizarre de ne pas les voir souvent."


translate french ep4p2s2_1f73dba9:


    d "Ca doit être calme sans vos parents."


translate french ep4p2s2_935816c3:


    sofia "Des fois un peu trop. Mais ça a toujours été comme ça. On a notre propre dépendance donc..."


translate french ep4p2s2_a2790c8b:


    sofia "Elizabeth, regarde qui est là."


translate french ep4p2s2_ed501987:


    beth "Je vois. T'as réussi à le ramener ici."


translate french ep4p2s2_898a5092:


    d "Bonsoir, Elizabeth."


translate french ep4p2s2_ca43a71d:


    beth "Bonsoir. Je prépare le repas, alors pas de bordel pendant que je suis dans la cuisine."


translate french ep4p2s2_cbf92592:


    dpense "Toujours aussi directe. Comme toujours."


translate french ep4p2s2_a2cc0998:


    sofia "Elle fait la boss, mais elle est contente que tu sois là."


translate french ep4p2s2_19d09601:


    sofia "Assieds-toi, on va discuter un peu. Alors, cette compétition... Tu la sens comment?"


translate french ep4p2s2_6a967106:


    d "C'est intense."


translate french ep4p2s2_e59e3b7e:


    sofia "Ouais, tout le monde est sur les nerfs."


translate french ep4p2s2_8ec18dba:


    sofia "Emerick est insupportable. Il pense qu'il peut faire tout ce qu'il veut."


translate french ep4p2s2_b94d27aa:


    beth "Il est chiant mais il sait ce qu'il fait."


translate french ep4p2s2_ac3a26ed:


    dpense "Elizabeth semble avoir un plan. Elle ne dit jamais rien sans raison. Tout dans le contrôle."


translate french ep4p2s2_0f477363:


    sofia "Les filles de Grace, par contre, sont intéressantes. Ruby est unique et futée. Julia est sympa. Grace est charmante, et Madison est... compliquée."


translate french ep4p2s2_5355fad2:


    beth "Tu les idéalises pas un peu trop? Elles ont toutes leurs défauts hein."


translate french ep4p2s2_c88ea45c:


    d "Et toi, Elizabeth? Tu penses quoi de ce groupe?"


translate french ep4p2s2_d155847d:


    beth "Je préfère observer. Les alliances sont nouées sur les faits, pas sur les émotions."


translate french ep4p2s2_c98db75d:


    dpense "Alliances? Ca c'est un mot intéressant. Elle voit cette compétition comme un jeu d'échecs."


translate french ep4p2s2_cda883af:


    d "Et qui vois-tu comme alliés potentiels alors?"


translate french ep4p2s2_8131e039:


    beth "Ceux qui pensent avant d'agir. Qui comprennent que chaque option est importante."


translate french ep4p2s2_a79791d9:


    dpense "Elle essaie de me jauger... Je ne vais pas lui donner d'avantages si facilement."


translate french ep4p2s2_b48a7664:


    d "Je suppose que ça veut dire que tu m'observes aussi?"


translate french ep4p2s2_a1842220:


    beth "Tout le monde observe tout le monde. La question est de savoir ce que toi tu observes?"


translate french ep4p2s2_4ac13fec:


    dpense "Elle tourne autour du pot. Elle est impressionnante mais je ne la laisserais pas me déstabiliser."


translate french ep4p2s2_d082a9f0:


    d "Je dirais que je cherche ce que les autres essaient de cacher."


translate french ep4p2s2_d368f496:


    beth "Intéressant. Peut être que tu n'es pas si naïf finalement."


translate french ep4p2s2_011f8701:


    sofia "C'était super bon! Merci Beth!"


translate french ep4p2s2_11f6c91b:


    d "C'est vrai. C'était délicieux."


translate french ep4p2s2_de71d125:


    beth "Je sais. Mais merci quand même."


translate french ep4p2s2_f5a70e38:


    sofia "Elizabeth et moi sommes différentes, mais on se complémente bien."


translate french ep4p2s2_f68be3d8:


    d "Je vois ça. Vous avez une alchimie unique."


translate french ep4p2s2_95e4195d:


    beth "Unique c'est le mot! Parfois fatiguante aussi!"


translate french ep4p2s2_6f689509:


    d "Ca vous dérange quand les gens vous appellent 'Rouge' et 'Bleue'?"


translate french ep4p2s2_0755dcb7:


    sofia "Franchement ça va. Mais ça nous ramène constamment à une comparaison."


translate french ep4p2s2_cc0e6b06:


    beth "C'est fatiguant. On est des individus, pas des couleurs."


translate french ep4p2s2_d3390c0d:


    sofia "Tu sais pourquoi je l'accepte? Parce que même si je suis 'Bleue', au moins je ne suis pas invisible. Avant, c'était pire."


translate french ep4p2s2_349ca4ea:


    beth "Pour moi, c'est juste des étiquettes. Si les gens pensent que 'Rouge' me définit, c'est leur problème, pas le mien."


translate french ep4p2s2_8c8371e9:


    dpense "Elles doivent porter ça depuis un moment. Ce genre de surnoms ne définissent pas qui elles sont."


translate french ep4p2s2_89ca0014:


    sofia "C'est aussi un peu pour ça que je change de style en ce moment. Nouvelle coiffure, nouveaux vêtements... Ca m'aide à me démarquer."


translate french ep4p2s2_f77098d1:


    beth "Ou à te distancer."


translate french ep4p2s2_70081f14:


    sofia "Pas du tout! J'évolue! C'est pas contre toi Elizabeth."


translate french ep4p2s2_24100ba9:


    dpense "On dirait que ce sujet semble sensible."


translate french ep4p2s2_a7bcef68:


    beth "Quand tu te regardes dans le miroir, peut être que tu vois quelqu'un de différent. Mais moi je n'y vois toujours que ma soeur et tu n'as pas besoin de changer."


translate french ep4p2s2_a51f08d8:


    sofia "Ce n'est pas un changement. C'est... de l'estime de soi."


translate french ep4p2s2_028c0cd7:


    d "Leur lien est fort, mais leurs différences commencent à se remarquer. C'est à cause de moi? Ou juste le passage du temps?"


translate french ep4p2s2_9e94e620:


    sofia "Mais toi t'es là pour moi maintenant."


translate french ep4p2s2_e0c34a25:


    sofia "Je me demande si tu me vois réellement comment je suis, ou si tu me ranges dans une case toi aussi."


translate french ep4p2s2_4c549eae:


    d "Je te vois clairement comme une fille qui pense beaucoup trop à ce que je pense."


translate french ep4p2s2_50af6feb:


    sofia "Ah ben voilà tu avoues! Tu ne penses pas à grand chose."


translate french ep4p2s2_e21595d9:


    beth "Ne te fais pas d'idées. Si quelqu'un te fais du mal, ils auront à faire à moi."


translate french ep4p2s2_940a765e:


    beth "Je protège ma soeur. Mais je sais aussi reconnaître quand quelqu'un peut être utile."


translate french ep4p2s2_746f142e:


    d "Est ce que je dois prendre ça comme une menace ou comme une opportunité?"


translate french ep4p2s2_37619690:


    beth "Les deux. Tout dépendra de toi. Mais si tu crois que le fait d'être lié à ma soeur me fera baisser ma garde, tu as tout faux."


translate french ep4p2s2_47340a30:


    sofia "Okay! Allez, je vais te montrer ma chambre."


translate french ep4p2s2_6ff2d3ba:


    sofia "Mets-toi à l'aise."


translate french ep4p2s2_81411292:


    d "C'est sympa ici."


translate french ep4p2s2_2b138a1c:


    sofia "Merci. J'avais hâte de me retrouver avec toi."


translate french ep4p2s2_f7cd02e4:


    dpense "Elle semble sincère. Elle veut me parler de quelque chose d'important."


translate french ep4p2s2_8f407172:


    d "De quoi veux-tu parler?"


translate french ep4p2s2_79a38c73:


    sofia "De moi. De ce que les gens disent de moi."


translate french ep4p2s2_b046a057:


    sofia "Tu sais, les gens pensent que je suis 'facile', mais c'est juste une façade."


translate french ep4p2s2_b0caddbf:


    sofia "Avec Elizabeth si forte et indépendante, il a fallu que je me démarque différemment."


translate french ep4p2s2_56628414:


    dpense "Ca explique pourquoi elle essaie de se démarquer avec son propre style."


translate french ep4p2s2_010dba7e:


    sofia "Etre 'Bleue' c'était mieux qu'être personne."


translate french ep4p2s2_615ccb96:


    sofia "Des fois, je ressentais qu'Elizabeth était la Star, et moi juste son ombre."


translate french ep4p2s2_5a1a4899:


    sofia "Mais franchement, tout ça est futile. Je me suis adaptée à ce que les autres attendaient mais ça n'a jamais marché."


translate french ep4p2s2_285f0b9f:


    d "Comment ça?"


translate french ep4p2s2_b4c35998:


    sofia "Ben ma réputation, ce que les gens pensent de moi..."


translate french ep4p2s2_af20113e:


    sofia "T'aimes bien mes seins hein?"


translate french ep4p2s2_70a855ae:


    d "Ouais! J'adore le contact de ta peau et tes têtons!"


translate french ep4p2s2_f9e6dae8:


    sofia "Je vois ça!"


translate french ep4p2s2_9b10c2c3:


    sofia "Du coup oui... Ma réputation... C'est pas ce que je suis."


translate french ep4p2s2_b27aa068:


    sofia "Je suis resté parmi les garçons juste pour montrer que j'étais différente, mais ça voulait rien dire."


translate french ep4p2s2_141a9915:


    sofia "J'ai juste une fois essayé de me mettre en relation avec quelqu'un et... ça a été un échec."


translate french ep4p2s2_9d53492b:


    dpense "Elle s'ouvre vraiment à moi. C'est une partie d'elle que je n'aurais jamais imaginé."


translate french ep4p2s2_00609b4d:


    sofia "Avec toi, c'est différent. Je me sens... normale. Pas jugée. Pas comparée. Aimée pour ce que je suis."


translate french ep4p2s2_5d5f12cb:


    d "Tu mérites d'être aimée pour ce que tu es, Sofia. Tu es géniale juste comme tu es."


translate french ep4p2s2_06414540:


    sofia "Des fois je me demande si je mérite quelqu'un qui m'accepte vraiment. C'est bizarre nan?"


translate french ep4p2s2_b2cc9ce7:


    d "Pas du tout. Tout le monde a des doutes. Mais si quelqu'un ne voit pas ta valeur, c'est que c'est lui qui est bizarre."


translate french ep4p2s2_de01fc66:


    sofia "Je pourrais presque croire que tu es romantique."


translate french ep4p2s2_017e1dd0:


    sofia "Merci. Grâce à toi, je pense que j'ai trouvé quelqu'un qui voit au delà des apparences."


translate french ep4p2s2_d270a0bc:


    dpense "Ces moments avec elle sont précieux. Elle a tellement plus à découvrir que ce qu'on raconte d'elle."


translate french ep4p2s2_88f26e97:


    sofia "Assez de sérieux! Tu sais que j'ai changé ma chambre juste pour toi?"


translate french ep4p2s2_ef5066d9:


    d "Ah bon? C'était comment avant?"


translate french ep4p2s2_c4efd746:


    sofia "Des posters de licornes et des coeurs avec des arcs en ciel."


translate french ep4p2s2_3c735778:


    dpense "Elle blague mais en vrai j'adore l'idée."


translate french ep4p2s2_a4ee1c19:


    d "Je suis sûr que ça avait du charme."


translate french ep4p2s2_dccdcd45:


    sofia "Hum... J'aurais dû garder les licornes. Ca t'aurait impressionné!"


translate french ep4p2s2_ec6f5d21:


    d "Evidemment! Je suis facilement impressionnable."


translate french ep4p2s2_98f55821:


    sofia "Ma soeur est en bas du coup..."


translate french ep4p2s2_cc70055b:


    sofia "On ne peut pas faire de bruits."


translate french ep4p2s2_5fd024b0:


    sofia "Mais j'ai une idée."


translate french ep4p2s2_66b57b7d:


    d "Je pense que je vais aimer ça."


translate french ep4p2s2_a0f008fc:


    sofia "Je suis sûre que tu vas aimer!"


translate french ep4p2s2_de074968:


    sofia "Je crois que mon ami ici-bas est un peu endormi."


translate french ep4p2s2_922905f7:


    sofia "Je vais le réveiller. Retire tes vêtements!"


translate french ep4p2s2_85fd51ca:


    sofia "Allez, descend avant qu'Elizabeth vienne te chopper. Elle peut te cuisiner plus que le dîner!"


translate french ep4p2s2_7f6391f7:


    beth "Hey, toi. Si tu blesses ma soeur, tu auras affaire à moi."


translate french ep4p2s2_f903930d:


    dpense "Note à moi-même : ne pas croiser Elizabeth."


translate french ep4p2s2_c895e478:


    d "J'ai compris. Mais ça veut dire que tu vas me garder à l'oeil dans la compétition aussi?"


translate french ep4p2s2_ec523280:


    beth "Evidemment. Chaque mouvement que tu fais est important. Si t'es intelligent, tu comprendras que notre rivalité ne bloque pas les opportunités."


translate french ep4p2s2_511416a5:


    d "Opportunités?"


translate french ep4p2s2_1d5e9999:


    beth "Peut être. Tant que tu sais où est ta place. Mais ne te fais pas d'idées. Si tu crois que ta connection avec Sofia te donne un avantage, tu as déjà perdu."


translate french ep4p2s2_36738ef8:


    dpense "Elle est formidable. Une concurrente, mais aussi une alliée potentielle si je joue bien mes cartes."


translate french ep4p2s2_e0104e45:


    beth "Dans ce jeu, les alliés ne sont pas nos amis. Ce sont des leviers. Alors fais attention, est ce que tu seras un levier pour Sofia..."


translate french ep4p2s2_e3795a7e:


    beth "Ou pour moi?"


translate french ep4p2s2_dd5bc1e1:


    beth "Si tu veux vraiment rester dans la vie de ma soeur, tu as plutôt intérêt à prouver que tu es meilleur que les autres."


translate french ep4p2s2_281de307:


    d "Et si j'y arrive pas?"


translate french ep4p2s2_ff4c841d:


    beth "Alors tu n'auras pas besoin de te soucier de ce que je pense de toi, vu que tu ne seras plus là."


translate french ep4p2s2_5da59355:


    d "Je suppose que je dois rester en alerte."


translate french ep4p2s2_a5ac2fd0:


    beth "Et tu as bien raison. Allez, bonne nuit!"


translate french ep4p2s2_fc6e2dde:


    beth "Rapelle-toi, je guette. Que ce soit pour elle... ou contre toi."




translate french ep4p2s2_673b7e9d:


    d "Ca doit être silencieux sans vos parents autour."


translate french ep4p2s2_45d4e726:


    sofia "Trop silencieux parfois, mais ça a toujours été comme ça depuis qu'on est nées. On a demandé à nos parents si on pouvait vivre dans la maison des invités..."


translate french ep4p2s2_589a490f:


    sofia "Ouais, tout le monde est sur les nerfs."


translate french ep4p2s2_eac165f6:


    beth "Je préfère observer. J'ai besoin de tout évaluer avant de faire des alliances."


translate french ep4p2s2_04ed70aa:


    sofia "Franchement, ça va. Mais ça nous ramène à chaque fois à des comparaisons."


translate french ep4p2s2_f615ef4b:


    sofia "Tu sais pourquoi je l'accepte? Parce que même si je suis 'Bleue', je ne suis pas invisible. C'était pire avant."


translate french ep4p2s2_8cc6ae08:


    sofia "Pas du tout! J'évolue, Elizabeth. Et ça n'a rien à voir avec toi."


translate french ep4p2s2_5e1f4029:


    beth "Quand tu te regardes dans le miroir, peut être que tu vois quelqu'un de différent, mais je continue à y voir ma soeur. Tu n'as pas besoin de changer."


translate french ep4p2s2_92fbc56d:


    dpense "Leur lien est fort mais leurs différences commencent à se ressentir. C'est à cause de moi? Ou juste le fait de grandir?"


translate french ep4p2s2_e79b76f8:


    sofia "Allez assez à propos de Beth et moi. Tu es ici en tant que mon invité!"


translate french ep4p2s2_afa13238:


    d "Je te vois comme la fille qui pense trop à ce que je pense."


translate french ep4p2s2_b4416a79:


    beth "Ne t'inquiète pas Sofia. Si quelqu'un te fait du mal, il aura à faire à moi. "


translate french ep4p2s2_42854063:


    beth "Je protège ma soeur, mais je sais aussi reconnaître quand quelqu'un peut être utile."


translate french ep4p2s2_b249881f:


    beth "Les deux. Tout dépend de toi. Si tu penses que je vais baisser ma garde à cause de notre lien, c'est que tu as tout faux."


translate french ep4p2s2_549bd88f:


    sofia "Franchement, tout ça est futile. J'ai essayé de m'adapter à ce que les autres voulaient et ça n'a jamais marché."


translate french ep4p2s2_ee6782ed:


    d "Ouais! J'adore toucher ta peau et jouer avec tes têtons."


translate french ep4p2s2_acc35567:


    dpense "Elle s'ouvre complètement à moi. Je ne pensais pas qu'elle serait comme ça."


translate french ep4p2s2_1b4ec24b:


    d "Pas du tout. Tout le monde a des doutes, et si quelqu'un ne peut pas voir ta valeur, c'est que c'est lui qui est bizarre."


translate french ep4p2s2_bc47fbc5:


    sofia "Merci... A cause de toi, j'ai l'impression d'avoir trouvé quelqu'un qui voit au delà des apparences."


translate french ep4p2s2_14bee954:


    sofia "Mais assez parlé sérieusement! Tu sais que j'ai changé la déco de ma chambre juste pour toi?"


translate french ep4p2s2_961ee93b:


    sofia "On ne peut pas faire trop de bruits."


translate french ep4p2s2_56251d19:


    sofia "Je vais le réveiller. Maintenant, retire tes vêtements."


translate french ep4p2s2_f607fa28:


    sofia "C'est mieux!"


translate french ep4p2s2_0ae9bcd0:


    ""


translate french ep4p2s2_c804ee1b:


    d "Sofia... Tu es... incroyable..."


translate french ep4p2s2_f87ddc89:


    sofia "Chut! Ne fais pas de bruits..."


translate french ep4p2s2_4fdbb733:


    d "Oui."


translate french ep4p2s2_e24aedd7:


    sofia "Ma soeur pourrait nous entendre."


translate french ep4p2s2_d83c8599:


    d "Mais..."


translate french ep4p2s2_db30d910:


    sofia "Hmmm Hmmm..."


translate french ep4p2s2_f3f88eb9:


    d "Je vais pas tenir longtemps..."


translate french ep4p2s2_e2ac8e66:


    d "Sofia..."


translate french ep4p2s2_55aca788:


    sofia "Ne t'inquiètes pas..."


translate french ep4p2s2_2f2dd27a:


    d "Je vais..."


translate french ep4p2s2_f6b31f93:


    sofia "Je sais... Tu trembles!"


translate french ep4p2s2_b95efa92:


    d "Je..."


translate french ep4p2s2_a8911b75:


    sofia "Vas-y..."


translate french ep4p2s2_5128c0e5:


    d "Dans ta bouche?"


translate french ep4p2s2_a67cda65:


    sofia "Hmmm Hmmm!"


translate french ep4p2s2_e17b5d39:


    sofia "Hmmm..."


translate french ep4p2s2_f427720b:


    sofia "On dirait du jus d'ananas!"


translate french ep4p2s2_8433216a:


    d "Ahah... Incroyable!"


translate french ep4p2s2_bcf27535:


    sofia "Rhabille toi et descend avant qu'Elizabeth ne viennent nous voir. Elle pourrait te cuisiner plus que le dîner!"


translate french ep4p2s2_55417eda:


    d "Je vois. Tu vas garder un oeil sur moi pendant la competition aussi?"


translate french ep4p2s2_ceb58bee:


    beth "Peut être. Tant que tu sais où est ta place. Mais ne te fais pas d'idées. Si tu crois que ton lien avec Sofia te donne un avantage, c'est que tu as déjà perdu."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
