


translate french save4part2_285f8ea7:


    "Veuillez sauvegarder ici..."


translate french save4part2_f029d6e4:


    "Toutes mes condoléances..."


translate french save4part2_47ce667d:


    orushi "Au vu des évènements récents je pense que c'est le temps des duels!"


translate french save4part2_51a9581e:


    orushi "Le premier duel sera [name]..."


translate french save4part2_c1c27e01:


    orushi "Contre Grace!"




translate french save4part2_c3393239:


    orushi "En raison des évènements récents je pense qu'il est temps pour les duels!"


translate french save4part2_fcba8ba6:


    mad "Je vais aller dans la tour Orushi et je vais trouver ce qu'il se passe !"


translate french save4part2_80081324:


    orushi "Le premier duel sera [name]..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
