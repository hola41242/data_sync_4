


translate french ep4p2s1_b3808d9e:


    grace "AH! Je suis contente que tu sois là! Tu connais le chemin maintenant!"


translate french ep4p2s1_7f002652:


    d "Oui. Ca fait plaisir d'être ici avec toi. Cette maison est apaisante, un peu comme toi!"


translate french ep4p2s1_c6f14024:


    grace "Mets toi à l'aise. Je vais prendre un truc à boire."


translate french ep4p2s1_4a403308:


    d "Avec plaisir!"


translate french ep4p2s1_b1f5a158:


    grace "Et voilà! Un bon jus de fruit. Tu vas adorer."


translate french ep4p2s1_082f9c63:


    d "Merci. Parfait pour un moment relaxant."


translate french ep4p2s1_1bd36f71:


    grace "En parlant de moment relaxant, j'ai prévu quelque chose pour nous cet aprem."


translate french ep4p2s1_b6d0af63:


    d "Qu'est ce que tu as prévu?"


translate french ep4p2s1_3ac0262d:


    grace "Je suis sûre que tu vas aimer! Suis moi!"


translate french ep4p2s1_e525e412:


    grace "Voilà ma chambre. Tu dois t'en rappeler... Mais cette fois-ci, j'ai une surprise pour toi."


translate french ep4p2s1_4ba5428a:


    d "Une surprise?"


translate french ep4p2s1_ca1a1e05:


    grace "Allez! T'es prêt? J'espère que tu aimes les jacuzzis parce que le mien va te faire oublier tous tes soucis. Rien ne vaut de l'eau chaude et une bonne compagnie!"


translate french ep4p2s1_7878335e:


    d "Un jacuzzi? Sérieux? C'est génial!"


translate french ep4p2s1_ce4cf5f3:


    grace "Donne-moi 2 secondes, je vais chopper des maillots."


translate french ep4p2s1_06a838b1:


    dpense "Oh merde. J'ai pas de maillot. Je vais faire comment?"


translate french ep4p2s1_7a6ff864:


    grace "Qu'est ce que tu penses de celui-là?"


translate french ep4p2s1_edaa937c:


    dpense "Wow... Elle sait vraiment comment me captiver. Ce maillot est magnifique sur elle, mais je crois que ce qui lui plaît le plus c'est de tester ma réaction."


translate french ep4p2s1_cc979e67:


    d "C'est très... élégant."


translate french ep4p2s1_8b13eea6:


    dpense "Pas sûr qu'élégant était le mot qu'elle attendait. Elle sait ce qu'elle fait c'est sûr."


translate french ep4p2s1_feae9023:


    grace "Ah bon? Attends, j'en ai un autre."


translate french ep4p2s1_8d6d2b18:


    dpense "Et c'est reparti... Elle s'amuse à me donner envie."


translate french ep4p2s1_149a78e5:


    d "Celui-ci est vraiment magnifique. Tu as bon goût. Et ça te va bien."


translate french ep4p2s1_e35882b0:


    dpense "Comment je suis censé rester concentré? Elle est parfaite dans chacun d'eux!"


translate french ep4p2s1_035e7d2c:


    grace "Hmmm... T'es sûr que c'est le maillot qui t'impressionne?"


translate french ep4p2s1_8396a3dc:


    dpense "Je me demande comment je vais faire sans maillot... Est ce qu'elle s'en soucie en fait?"


translate french ep4p2s1_5417fd7d:


    dpense "Elle a ce sourire joueur... Elle sait exactement ce qu'elle fait et comment me donner chaud."


translate french ep4p2s1_0bea34b9:


    d "C'est ce que je devrais dire mais tu rends ça plus... dûr."


translate french ep4p2s1_b2deb524:


    dpense "Pas de maillot... Oh je vais improviser. Je vais rentrer en premier, peut être qu'elle le verra pas."


translate french ep4p2s1_5bec97e4:


    d "Wow... C'est encore mieux que je l'imaginais."


translate french ep4p2s1_1153422f:


    dpense "L'eau est parfaite. Chaude, douce..."


translate french ep4p2s1_81295a2f:


    grace "T'es prêt?"


translate french ep4p2s1_ce4058d4:


    dpense "Elle est incroyable. Ce maillot... Elle captive toute mon attention."


translate french ep4p2s1_2891d94c:


    grace "Nan mais attends! Tu es tout... nu?"


translate french ep4p2s1_07c397d9:


    dpense "Et merde..."


translate french ep4p2s1_1694b6fb:


    d "Euh... Oui... Désolé... J'ai pas de maillot. Je pensais que ce serait moins bizarre comme ça."


translate french ep4p2s1_b9108ad4:


    grace "Moins bizarre? Sérieusement?"


translate french ep4p2s1_6c4d97c7:


    grace "Et ben au moins tu es honnête. Tu sais comment improviser!"


translate french ep4p2s1_b0b8bf84:


    dpense "Son sourire est si naturel. Elle réussit à changer un moment de gêne en quelque chose de plus léger et fun. Elle est géniale."


translate french ep4p2s1_9c5ed970:


    grace "Je suppose que ça rend les choses plus... Intéressantes. Allez on va dire que je n'ai rien vu."


translate french ep4p2s1_2689ddc3:


    d "Merci pour ta... Compréhension."


translate french ep4p2s1_f9e2bcdc:


    grace "Bon... Dis-moi, qu'est ce que t'as en tête maintenant?"


translate french ep4p2s1_8ef971e4:


    d "Hummm... Que ce moment est parfait... Mais c'est surtout toi que j'ai en tête là..."


translate french ep4p2s1_05d4fb55:


    dpense "Elle est le parfait mélange entre chaleur et énergie. Chaque détail de ce moment est en train de s'imprimer dans ma mémoire."


translate french ep4p2s1_91cb5e2f:


    grace "Tu sais... C'est comme si le monde n'existait plus. Juste toi, moi et l'eau."


translate french ep4p2s1_dfb599a8:


    grace "C'est rare de se sentir aussi... bien. Avec toi, je peux être moi-même."


translate french ep4p2s1_15438c00:


    d "C'est à cause de toi tout ça! Tu rends tout spécial!"


translate french ep4p2s1_497f4618:


    dpense "Chaque sourire, chaque mot qu'elle dit... Je sens mon coeur s'attacher."


translate french ep4p2s1_2d968c58:


    grace "L'eau est chaude... mais pas autant que toi en ce moment."


translate french ep4p2s1_4b8541f2:


    dpense "Son dos contre mon torse, sa peau mouillée qui glisse contre la mienne... C'est comme si tout mon corps réagissait à sa proximité."


translate french ep4p2s1_1c0d3bd5:


    grace "Tu sais, je pense que c'est mignon que tu sois gêné. Ca montre que tu as des faiblesses, et c'est rare chez les hommes."


translate french ep4p2s1_57705c71:


    dpense "Mignon? C'est une façon de voir... Au moins elle est a pas l'air gênée elle!"


translate french ep4p2s1_261046b5:


    grace "Tu es si important pour moi. Plus que je ne le pensais... et je crois que je t'ai un peu allumé là..."


translate french ep4p2s1_b59160c0:


    d "Grace..."


translate french ep4p2s1_a4b40074:


    dpense "Elle sait exactement ce qu'elle fait. Mon coeur bat si vite et elle doit le sentir. Chaque mouvement qu'elle fait, chaque mot qu'elle me susurre... Je suis complètement sous son emprise."


translate french ep4p2s1_88455d06:


    dpense "Je pourrais rester des heures, juste à regarder et savour ce moment. Elle est tout ce que je veux."


translate french ep4p2s1_0872eca3:


    grace "Shhh... Pas besoin de mots. Viens par là."


translate french ep4p2s1_1f4f1595:


    grace "C'est ici que la magie opère."


translate french ep4p2s1_10e61212:


    dpense "Sa chambre est juste comme elle, chaude, accueillante et incroyablement belle."


translate french ep4p2s1_ef464366:


    grace "Viens par là."


translate french ep4p2s1_fb394095:


    grace "Je voulais te dire... Ca représente beaucoup pour moi. Toi, nous... Tout ce qu'on partage. Des fois je pense que je dois tout contrôler mais, avec toi, tout paraît plus simple."


translate french ep4p2s1_67b86a70:


    dpense "Ses yeux... Ils vrillent avec une sincérité qui me laisse sans voix. Ce moment est juste à nous."


translate french ep4p2s1_14f051c6:


    d "T'es incroyable, Grace. Je ne sais pas comment je peux être aussi chanceux."


translate french ep4p2s1_a9e714f0:


    grace "C'est pas de la chance... C'est toi."


translate french ep4p2s1_8e3647db:


    grace "Et si on continuait cette soirée quelque part plus... confortable?"


translate french ep4p2s1_b1ce614c:


    grace "Viens par là. Laisse moi te montrer à quel point tu es important pour moi."


translate french ep4p2s1_5c0194b2:


    dpense "Chaque moment, chaque regarde est plein de tendresse. Avec elle, tout semble parfait."


translate french ep4p2s1_3ced0deb:


    grace "Je... Je veux essayer quelque chose mais... Je ne suis pas sure de moi."


translate french ep4p2s1_060b5aa3:


    d "Grace, tu peux me dire ce que tu veux."


translate french ep4p2s1_070c0a44:


    grace "C'est juste que... J'ai jamais vraiment fait ça avant alors... Je ne veux pas te décevoir."


translate french ep4p2s1_fd1f8772:


    dpense "Son hésitation est touchante. Elle veut tout bien faire, mais elle n'en a pas besoin. Tout ce que je veux c'est être avec elle, peut importe comment."


translate french ep4p2s1_0d6bf48d:


    d "Hey, regarde-moi. Tu n'as rien à prouver. Tout ce qui m'importe est de partager ce moment ensemble."


translate french ep4p2s1_0ad386e3:


    grace "Tu es vraiment... Tu sais exactement quoi dire. Merci."


translate french ep4p2s1_2f26bb3e:


    dpense "Son sourire me fait fondre. Elle est parfaite, me^me quand elle doute. Ca rend ce moment encore plus réel, plus précieux."


translate french ep4p2s1_e7cbe062:


    grace "Je veux que ce moment soit spécial... Juste pour nous deux."


translate french ep4p2s1_cbd4d6a7:


    dpense "Ses mots, sa voix... Tout en elle irradie de sincérité et d'amour. C'est plus qu'un moment flottant, c'est une profonde connection."


translate french ep4p2s1_c7b664d2:


    d "Grace... Je..."


translate french ep4p2s1_92ea9e59:


    dpense "Pas besoin de finir ma phrase. Elle sait. Elle comprend."


translate french ep4p2s1_323779a3:


    grace "Je veux que ce moment sois parfait. Juste toi et moi, plus rien d'autre n'a d'importance."


translate french ep4p2s1_7b7bcec2:


    dpense "Sa voix tremble un peu, avec l'émotion. Elle est belle, vulnérable et forte à la fois."


translate french ep4p2s1_1054ebf8:


    d "Grace... Je suis là. C'est tou ce que je veux. Etre avec toi."


translate french ep4p2s1_3d2a1600:


    grace "Alors viens plus près. Laisse-moi te montrer à quel point tu m'es important."


translate french ep4p2s1_8c417ab5:


    dpense "Ses mouvements sont si tendres, comme si ses gestes racontaient une histoire. Elle épouse mon corps parfaitement et c'est comme si le monde s'effaçait autour de nous."


translate french ep4p2s1_c77fc3e0:


    dpense "Je ne peux penser qu'à elle. La douceur de sa peau, son regard. C4est plus qu'un moment physique, c'est une union, une promesse silencieuse."


translate french ep4p2s1_7e93c462:


    grace "Tu es incroyable... Tu me fais me sentir si... vivante!"


translate french ep4p2s1_ca2de023:


    dpense "Je veux qu'elle comprenne qu'elle est spéciale. Que ce moment soit ancrés dans nos coeurs pour toujours."


translate french ep4p2s1_ddcb961f:


    d "Grace... Tu es tout pour moi. Et je ferais tout pour te rendre heureuse."


translate french ep4p2s1_ce41ab78:


    dpense "On y est, ensemble, dans ce moment suspendu. Chaque battement de coeur, chaque souffle est en symbiose. C'est un pur bonheur."


translate french ep4p2s1_46556e09:


    dpense "Chaque moment avec elle est un intense mélange d'émotions. Ses gestes sont doux et plein de passion. Elle se donne totalement, et je veux faire de même pour elle."


translate french ep4p2s1_2db32ad0:


    grace "Je... Je suis trop heureuse d'être avec toi...."


translate french ep4p2s1_ee3ad65a:


    dpense "Sa respiration, ses murmures... Tout en elle est en harmonie avec nos mouvements. C'est comme si l'on ne faisait qu'un."


translate french ep4p2s1_a7010377:


    dpense "Une vague d'émotions me submerge de bonehure, de passion et de respect. Ce moment... J'aimerais que ça ne s'arrête jamais."


translate french ep4p2s1_b844df27:


    grace "C'était... Parfait. Merci pour tout."


translate french ep4p2s1_4c6db8a5:


    dpense "La voir comme ça me remplit de bonheur. Je veux lui donner tellement plus."


translate french ep4p2s1_95225672:


    d "Grace... Tu es incroyable. Tu rends tout spécial."


translate french ep4p2s1_e439758c:


    drew "Alors, tu es encore là [name]? Je suppose que tu as passé une bonne journée."


translate french ep4p2s1_9f20b4e2:


    dpense "Mrs. Drew... Toujours impressionnante et un peu intimidante. Mais aujourd'hui, il y a quelque chose d'autre dans son regard.... Comme un challenge."


translate french ep4p2s1_dd984e2d:


    d "Oui, Mrs. Drew. Grace m'a invité pour passer l'après-midi ensemble."


translate french ep4p2s1_a7f3baa7:


    drew "Je vois ça. Elle me semble particulièrement enjouée ces derniers jours. Est ce que ça ne viendrait pas de toi?"


translate french ep4p2s1_1a216738:


    dpense "Son ton est flatteur, mais ses yeux semblent analyser chaque mot qui sort de ma bouche. Elle fait peser une aura qui irradie de contrôle et de séduction."


translate french ep4p2s1_c8837520:


    d "Grace est incroyable. Elle mérite tout le bonheur du monde."


translate french ep4p2s1_c753ca85:


    drew "Charmant. Mais rappelle toi que je suis sa mère, ainsi que ta directrice. Tant que tu gagnes et que tu fais les choses bien, Je ne m'opposerais pas."


translate french ep4p2s1_f3b2beab:


    dpense "Ses mots ressemblent à un avertissement. Elle teste mes nerfs, ma confiance et mes intentions."


translate french ep4p2s1_01a10b35:


    drew "Ne baisse pas ta garde. Tu es plein de ressources mais ça ne fait que commencer. Et crois-moi, je surveillerais."


translate french ep4p2s1_332770ae:


    dpense "Elle est fascinante... Mais dangereuse. Son sourire cache ses intentions que je n'arrive pas à décrypter. Je sens à la fois le désir de la comprendre et la peur d'être brulé."


translate french ep4p2s1_40c3f520:


    drew "Bonne chance, [name]. Et bonne nuit."


translate french ep4p2s1_a5c33cac:


    dpense "Une après-midi mémorable, à tous les niveaux. Grace... et Mrs. Drew. Les choses deviennent quand même de plus en plus compliquées."




translate french ep4p2s1_0bbf0b4b:


    grace "Je suis contente que tu sois là! Tu dois connaître le chemin maintenant!"


translate french ep4p2s1_c72f2895:


    grace "L'eau est chaude... Mais pas autant que toi actuellement."


translate french ep4p2s1_8625c88f:


    grace "Tu sais, c'est mignon que tu sois gêné. Ca montre que tu as des faiblesses, et c'est rare de voir ça chez un homme."


translate french ep4p2s1_1469b8b9:


    dpense "Son souffle, ses murmures... tout se synchronise à moi. C'est comme si l'on ne faisait plus qu'un."


translate french ep4p2s1_68fdba72:


    drew "Charmant, mais attention, je suis sa mère et aussi ta directrice. Tant que tu gagnes et que tu fais les choses bien je ne m'opposerais pas."




translate french ep4p2s1_91945af7:


    grace "J'avais hâte qu'on puisse se retrouver un peu ensemble."


translate french ep4p2s1_b8942a86:


    grace "Entre dans le jacuzzi, j'arrive dans 2 secondes."


translate french ep4p2s1_55301d7a:


    dpense "L'eau est parfaite. Douce, chaude..."


translate french ep4p2s1_5cf2745f:


    grace "Moins bizarre?"


translate french ep4p2s1_493c649c:


    grace "Ben, au moins tu sais comment improviser, n'est ce pas?"


translate french ep4p2s1_f8bb1a7d:


    d "Ben toi et ton... corps."


translate french ep4p2s1_33273874:


    grace "Tu peux me toucher tu sais... J'adore sentir tes mains sur ma peau..."


translate french ep4p2s1_fd9b9b99:


    dpense "Elle sait exactement ce qu'elle fait. Mon coeur bat si fort, elle doit le sentir."


translate french ep4p2s1_c5774ad3:


    dpense "Chaque geste qu'elle fait, chaque mot qu'elle murmure... Elle m'envoûte complètement."


translate french ep4p2s1_b318ce0d:


    grace "Shhh.... Pas besoin de mots."


translate french ep4p2s1_3cf0e8c6:


    grace "Je voulais te dire... C'est vraiment important pour moi. Toi, nous... tout ce qu'on partage."


translate french ep4p2s1_d5ffd576:


    grace "Des fois j'ai l'impression que je pense beaucoup trop, mais avec toi, tout paraît simple."


translate french ep4p2s1_78fa8715:


    grace "Tu es si... Dur..."


translate french ep4p2s1_a6ee6892:


    grace "J'adore cette sensation..."


translate french ep4p2s1_3d1cb93e:


    grace "Je... Ca me rend toute... Excitée..."


translate french ep4p2s1_4b00b4ea:


    d "Grace, ça devient difficile pour moi de résister..."


translate french ep4p2s1_4123acb2:


    grace "Alors... Ne résiste pas..."


translate french ep4p2s1_e9612217:


    grace "Prend moi [name], fais moi ressentir ton désir."


translate french ep4p2s1_4239d05c:


    grace "Si on continuait dans un endroit plus... confortable?"


translate french ep4p2s1_967def27:


    dpense "Elle y met tout son coeur."


translate french ep4p2s1_b77f8cb3:


    dpense "Je peux sentir que ce n'est pas une pro mais elle le fait pour moi"


translate french ep4p2s1_5d9a560f:


    grace "C'est... différent de ce que j'avais vu dans les films."


translate french ep4p2s1_7b33f5ab:


    d "Oh? Tu regardes des pornos?"


translate french ep4p2s1_00fe7e07:


    grace "Non... Enfin, oui mais dans un but d'apprentissage!"


translate french ep4p2s1_fcae45c4:


    d "D'apprentissage?"


translate french ep4p2s1_64ab9de4:


    grace "Oui... J'avais besoin de conseils pour le faire bien alors..."


translate french ep4p2s1_97ab9f33:


    d "T'aurais dû demander à Kira!"


translate french ep4p2s1_a46e0701:


    grace "C'est pas une mauvaise idée!"


translate french ep4p2s1_6a1ea1df:


    dpense "Je la sens tendue maintenant... Il faut que je fasse quelque chose."


translate french ep4p2s1_c68a4ce9:


    d "Viens là, t'as pas besoin de me faire plaisir comme ça tu sais!"


translate french ep4p2s1_d921915a:


    grace "T'es sûr que...."


translate french ep4p2s1_cfff1add:


    d "Chut!"


translate french ep4p2s1_39da1184:


    grace "Sois doux... C'est la première fois..."


translate french ep4p2s1_0fca028b:


    d "Je vais juste faire entrer le bout pour l'instant..."


translate french ep4p2s1_21a8ca52:


    grace "Okay..."


translate french ep4p2s1_aeb55d36:


    d "Ca va?"


translate french ep4p2s1_af36b020:


    grace "Oui... Tu peux continuer..."


translate french ep4p2s1_e9aa9767:


    grace "Oh mon dieu... Tu es si... Gros!"


translate french ep4p2s1_99d97c19:


    grace "Je peux le sentir à travers mon.... OHHHHHHHHH!"


translate french ep4p2s1_1b3995fd:


    d "Grace? Tu vas bien?"


translate french ep4p2s1_bc3d1f74:


    grace "Si je vais bien? Mais c'est trop bon!!!!"


translate french ep4p2s1_3e543cc7:


    grace "Mon dieu, Quand t'as touché le fond c'est comme si j'avais pris un éclair de plaisir!"


translate french ep4p2s1_cdd4eede:


    grace "J'en veux plus!"


translate french ep4p2s1_6a230ed2:


    d "Tu veux?"


translate french ep4p2s1_3ec569ec:


    grace "Oui [name]! Vas-y à fond!"


translate french ep4p2s1_777bd54e:


    dpense "Nous y voilà, ensemble, dans ce moment suspendu."


translate french ep4p2s1_73c2150f:


    dpense "Chaque battement de coeur, chaque souffle en synchronisation. C'est du pur bonheur."


translate french ep4p2s1_74aab3e0:


    grace "C'est fabuleux! T'arrêtes pas!"


translate french ep4p2s1_f400c5bf:


    dpense "Chaque moment avec elle est un mélange d'émotions intenses."


translate french ep4p2s1_459e7e6a:


    dpense "Ses gestes sont doux et enrobés de passion."


translate french ep4p2s1_b8bb17b8:


    grace "Plus fort! Je veux te sentir entièrement en moi!"


translate french ep4p2s1_4f31f137:


    dpense "Elle se donne complètement, et je veux faire de même pour elle."


translate french ep4p2s1_419cc14a:


    dpense "Son souffle, ses murmures... Tout en elle se synchronise à moi."


translate french ep4p2s1_316f8b34:


    dpense "C'est comme si l'on ne faisait plus qu'un."


translate french ep4p2s1_5944a9dd:


    grace "[name] je crois que ça vient..."


translate french ep4p2s1_6c04aba9:


    d "Vas y Grace! Laisse le plaisir monter et laisse toi aller!"


translate french ep4p2s1_4c15fa43:


    grace "[name]! Je peux pas l'arrêter!"


translate french ep4p2s1_26e8afcc:


    grace "C'est si..."


translate french ep4p2s1_b3b8b566:


    grace "BOOOOOOOOONNNNNNNNNNNNNNNNNNNNN!"


translate french ep4p2s1_6e552b19:


    dpense "Je vais pas pouvoir me retenir non plus... son corps, son orgasme..."


translate french ep4p2s1_09fd42a9:


    dpense "Je vais y aller aussi!"


translate french ep4p2s1_333214ba:


    d "Grace! Je..."


translate french ep4p2s1_39de39e2:


    grace "Oh mon dieu! Je sens tout trembler en moi!"


translate french ep4p2s1_b2db4984:


    grace "Plus fort!"


translate french ep4p2s1_eae22951:


    grace "Remplis-moi!"


translate french ep4p2s1_1540e282:


    d "Grace! Je..."


translate french ep4p2s1_1385b400:


    grace "Ahhhhhhhhhhhhhh!"


translate french ep4p2s1_801e530d:


    grace "OUUIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII!"


translate french ep4p2s1_761992b2:


    grace "C'est trop foooort!"


translate french ep4p2s1_edb671d1:


    grace "Je jouis encooooooooooooooorrrrre"


translate french ep4p2s1_59364ac1:


    grace "Je peux plus respirer, je peux plus...."


translate french ep4p2s1_a2035db7:


    grace "Ohhhhhhhhhh"


translate french ep4p2s1_d9b36350:


    grace "Merci pour cette... Première fois..."


translate french ep4p2s1_580278d9:


    grace "Tu l'as rendue inoubliable..."


translate french ep4p2s1_957fa26d:


    d "J'espère ne pas t'avoir fait mal..."


translate french ep4p2s1_841ac660:


    grace "Fais mal? C'est une blague?"


translate french ep4p2s1_5d26842e:


    grace "La prochaine fois tu iras à fond! J'en voulais plus!"


translate french ep4p2s1_d8566773:


    d "Ahah! T'es insatiable!"


translate french ep4p2s1_f1083877:


    grace "C'est ce que tu aimes chez moi non?"


translate french ep4p2s1_2d1667b9:


    d "Bien sûr!"


translate french ep4p2s1_03fd30d9:


    grace "Allez... Ma mère va arriver dans pas longtemps... Vaut mieux qu'on se rhabille!"


translate french ep4p2s1_80d74b76:


    drew "Charmant, mais rapelle-toi, je suis sa mère mais aussi ta proviseure."


translate french ep4p2s1_8b8420f6:


    drew "Tant que tu gagnes et que tu fais bien les choses, je ne vois pas de problèmes."




translate french ep4p2s1_452f4bf8:


    grace "Mon Dieu! Quand t'as tapé dans le fond c'était hallucinant!"


translate french ep4p2s1_87e8bae4:


    grace "Plus profond! Je veux te sentir me remplir complètement!"


translate french ep4p2s1_d1f5d42b:


    dpense "Elle se donne à moi complètement, et je veux faire de même pour elle."


translate french ep4p2s1_b0ccaec1:


    grace "[name] je crois que ça vient..."


translate french ep4p2s1_1e1adda8:


    d "Vas-y Grace! Laisse le plaisir venir. Je veux que tu le ressentes à fond!"


translate french ep4p2s1_fb38a634:


    grace "Que c'est... Booooooooooooooooonnnnnnnn!"


translate french ep4p2s1_d7dfd55e:


    dpense "Je vais venir aussi!"


translate french ep4p2s1_fc5e024b:


    grace "Oh mon dieu! Je te sens trembler en moi!"


translate french ep4p2s1_847f2188:


    grace "Remplis-moi!"


translate french ep4p2s1_39192f82:


    grace "C'est si booooooooonnnnnnnn!"


translate french ep4p2s1_2825f206:


    grace "Je jouis encore! Ahhh, ahhh, unhhhhh"


translate french ep4p2s1_6d159a7a:


    grace "La prochaine fois, je ne veux pas que tu te retiennes ! J'en voulais plus !"


translate french ep4p2s1_39dccf09:


    d "Ahahah! T'es incroyable!"


translate french ep4p2s1_3eee8d5e:


    grace "C'est ce que t'aimes chez moi non?"


translate french ep4p2s1_a1f2194a:


    grace "Bon allez... Ma mère va arriver d'une minute à l'autre. On devrait se rhabiller."


translate french ep4p2s1_d00f5771:


    drew "Ne baisse pas ta garde. Ton profil est intéressant mais les vrais challenges vont juste commencer. Et crois-moi, je te surveille."


translate french ep4p2s1_958ea060:


    dpense "Elle est fascinante, pleine d'allure mais aussi dangereuse à la fois. Ses sourires cachent ses intentions que je ne peux décoder. Je voudrais la comprendre mais j'ai bien peur de me brûler si j'essaie."


translate french ep4p2s1_73e47ea6:


    drew "Bonne chance, [name], et bonne nuit."




translate french ep4p2s1_954ede5f:


    d "Viens par là, t'as pas besoin de me faire plaisir comme ça."


translate french ep4p2s1_0ae9bcd0:


    ""




translate french ep4p2s1_c4fcc899:


    grace "Oh mon dieu! Je la sens grandir en moi!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
