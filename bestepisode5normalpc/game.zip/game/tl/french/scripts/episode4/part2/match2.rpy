


translate french match2_69284cbf:


    orushi "Bienvenue à cette demi-finale. Aujourd'hui, vous jouez pour plus qu'une victoire."


translate french match2_5b842112:


    orushi "Le match sera joué en 3 points gagnants. Nouvelle règle: chaque équipe aura le droit à un goal."


translate french match2_d66f6358:


    orushi "N'oubliez pas, l'équipe qui gagnera la finale aura la maison comme récompense ultime."


translate french match2_5f03f6e1:


    orushi "Donnez tout ce que vous avez. Que la meilleure équipe gagne!"


translate french match2_41ca5aa1:


    d "Un goal?"


translate french match2_04684a01:


    grace "T'inquiètes! Je vais garder les cages!"


translate french match2_a68cfae0:


    d "Oh? D'accord."


translate french match2_73f5537e:


    dpense "Ils sont déjà là."


translate french match2_e5e45f56:


    s "Vous pensez vraiment avoir une chance?"


translate french match2_28d49d51:


    s "Ca sera rapide."


translate french match2_9ad31edb:


    hec "Ne t'inquiètes pas, Steven. Ils vont bouffer la poussière avant même d'avoir commencé."


translate french match2_c1d792e1:


    mad "Te la joue pas, Steven. Tout peut arriver."


translate french match2_59184b90:


    ruby "On est à un match de la finale. Y'à pas moyen d'abandonner maintenant."


translate french match2_d8416a09:


    julia "Restez concentrés!"


translate french match2_9f83db86:


    gaby "Vous n'êtes pas arrivés jusque là par accident! Montrez que vous méritez votre place."


translate french match2_3d03d7c6:


    dpense "Même Gaby est là pour encourager ses filles."


translate french match2_8f114abf:


    orushi "Toutes les équipes en position."


translate french match2_8db59867:


    orushi "Equipe B, vous avez l'engagement."


translate french match2_9bc85abf:


    emerick "Regarde moi le Frenchie, il se croit déjà en finale le gars."


translate french match2_91905166:


    beth "S'il est là, c'est peut être qu'il en est capable. Il travaille dûr pour avancer, pas comme d'autres."


translate french match2_f04114a2:


    emerick "Tu défends ce gamin? C'est une blague?"


translate french match2_bf78d112:


    beth "Je ne blague jamais. Peut être que tu devrais jeter un oeil à ce qu'il fait."


translate french match2_98900f7b:


    kira "Peut être qu'on pourrait juste se focus sur le match plutôt que perdre du temps à parler. "


translate french match2_e6636ab0:


    emerick "On verra ce que tu diras quand il bouffera l'herbe."


translate french match2_9bc85abf_1:


    emerick "Regarde moi le Frenchie, il se croit déjà en finale le gars."


translate french match2_3a13bbd2:


    sofia "Il est plus fort qu'il en a l'air. Je pense qu'il pourrait te surprendre."


translate french match2_f9ca9132:


    emerick "T'es sérieuse? Il va se faire démonter."


translate french match2_e56250a5:


    sofia "Peut être. Mais tout peut arriver dans un match."


translate french match2_9691e1fd:


    emerick "Trop mignon, Sofia. Tu veux pas lui faire un peu de cheerleading non plus?"


translate french match2_b32c3ce6:


    kira "Vous êtes fatigants. Le match va commencer, alors regardez et prenez des notes."


translate french match2_503584a0:


    s "Regarde, je vais finir ça directement dès le début."


translate french match2_be56c117:


    dpense "Qu'est ce qu'il fait?"


translate french match2_096c4e5a:


    dpense "Attends... Est ce qu'il...?"


translate french match2_ea102efd:


    gaby "Attention!"


translate french match2_c0039868:


    mad "Quoi?!"


translate french match2_95ae5709:


    d "Que...?"


translate french match2_8088ed99:


    grace "Je... Je l'ai même pas vu venir. C'était trop rapide."


translate french match2_3d8da864:


    s "Je vous avais prévenu. C'était rapide n'est ce pas?"


translate french match2_00d132e0:


    emerick "C'est ce que j'appelle un bon départ. Ils n'ont aucune chance."


translate french match2_6f805dcc:


    sofia "C'est que le début."


translate french match2_689fbeda:


    mad "Y'à pas moyen qu'on se laisse humilier comme ça."


translate french match2_93b0ef9b:


    ruby "C'est juste un but. On peut revenir."


translate french match2_57ae5e3e:


    julia "Respirez. On va leur en mettre un."


translate french match2_0d53043d:


    dpense "1-0... Dès le premier engagement. On peut revenir, mais faut qu'on se réveille."


translate french match2_42673556:


    d "T'inquiètes pas Grace, c'est pas de ta faute."


translate french match2_0c7d5527:


    mad "Oui Grace. Tu chopperas le prochain."


translate french match2_d18bbbec:


    ruby "Ouais! On va t'aider!"


translate french match2_1fb89bd3:


    gaby "Ne les laissez pas vous intimider. Jouez intelligemment."


translate french match2_c06dbb22:


    ruby "On y va!"


translate french match2_4104810c:


    dpense "Jouez intelligemment qu'elle dit."


translate french match2_12e1e4bf:


    dpense "Leur équipe est basée sur plusieurs points-clés."


translate french match2_5eb5d451:


    dpense "Steven irradie de pure force et va probablement essayer d'inscrire des buts avec le plus de puissance possible."


translate french match2_a5154a0c:


    dpense "Hector est agressif, Je pense qu'il doit jouer la pression pour récupérer les balles."


translate french match2_7d87dabb:


    dpense "Mac est imposant mais relativement agile, faisant de lui un excellent goal, rendant difficile de trouver un angle de tir."


translate french match2_82a57563:


    dpense "Ben est agile et rapide. Je ne pense pas qu'il ait beaucoup de puissance."


translate french match2_780e314b:


    dpense "Le dernier semble plutôt moyen. Sans doute pris par défaut."


translate french match2_9223ecc1:


    dpense "Leur équipe semble plutôt forte..."


translate french match2_85f324f3:


    ruby "On y va!"


translate french match2_a0bce6d2:


    s "Hey, donne moi ça!"


translate french match2_33e7a978:


    ruby "Attrape-la si tu peux!"


translate french match2_79a053dc:


    dpense "Elle va essayer de passer à Madison."


translate french match2_0e37c63d:


    dpense "Hector va essayer d'intercepter, mais Madison devrait le doubler."


translate french match2_af1bc548:


    dpense "Je vais le bloquer!"


translate french match2_5e575114:


    hec "Casse-toi de là, chevalier blanc!"


translate french match2_1364de62:


    d "Tu devras me passer d'abord si tu veux la balle."


translate french match2_f4c3b9f5:


    dpense "Il est pas assez rapide."


translate french match2_574765f5:


    mad "T'as trop mangé hier soir ou quoi? T'es trop lent!"


translate french match2_a561a0a6:


    mad "Julia, à toi!"


translate french match2_55928131:


    julia "J'ai!"


translate french match2_9f8121b0:


    dpense "Julia avance, mais Ben va la bloquer! Elle va perdre la balle!"


translate french match2_b5dcb408:


    julia "Tiens! A toi de faire la différence!"


translate french match2_aa45fd5c:


    d "Merci Julia!"


translate french match2_f8317683:


    dpense "C'est ma chance... Je prends le tir. Je vais leur montrer!"


translate french match2_5a9b36ce:


    dpense "Putain, Mac prend tellement de place!"


translate french match2_ce01da72:


    dpense "Je positionne mon pied..."


translate french match2_1f235451:


    dpense "Et je tire!"


translate french match2_51696d02:


    mac "Trop faible..."


translate french match2_e2904d9a:


    mad "Tu t'es précipité!"


translate french match2_29cf30b1:


    ruby "C'est pas grave! Tu vas y arriver!"


translate french match2_799f9fce:


    dpense "Maintenant ils ont la balle. Va falloir que je me rattrape..."


translate french match2_e44e7c0d:


    d "Excellent, Ruby!"


translate french match2_90634bd2:


    dpense "Ruby envoie une tête précise à Julia."


translate french match2_c379c03a:


    dpense "Mais Julia est entourée."


translate french match2_6fe7774e:


    dpense "Elle se prépare à tirer..."


translate french match2_b9160fb9:


    mad "Allez Julia, vas y!" with hpunch


translate french match2_245e1e23:


    dpense "Julia fait une feinte de tir..."


translate french match2_5ecbefd0:


    dpense "Mac bloque à droite, mais la balle va de l'autre côté!"


translate french match2_da18de86:


    dpense "Je dois prendre l'avantage sur ça!"


translate french match2_23b9f044:


    dpense "Le tir lifté de Kira!"


translate french match2_ee630cd2:


    d "Cette fois-ci..."


translate french match2_44d8ab2b:


    d "Il y va!"


translate french match2_529bf17d:


    kira "Hey, c'est mon tir!"


translate french match2_3e63910a:


    mad "But!"


translate french match2_10e86634:


    julia "Bien joué, [name]!"


translate french match2_3c5c4af6:


    ruby "Bravo!"


translate french match2_ddfd26c8:


    dpense "C'est pas assez puissant."


translate french match2_f818e2dd:


    ruby "Pas si vite!"


translate french match2_15b9b540:


    dpense "Qu'est ce qu'elle fait?"


translate french match2_3d50fe88:


    ruby "IIIIIIIIIII....KEIIIIIIIIIII!"


translate french match2_77201de2:


    d "Sérieux?"


translate french match2_b7b3ca9b:


    ruby "J'ai toujours rêvé de dire ces mots, ahah!"


translate french match2_dae059c5:


    mad "C'était quoi ce but?"


translate french match2_799370a7:


    julia "Ruby, t'es incroyable!"


translate french match2_20b630f1:


    ruby "Hey, tout ce qui compte c'est qu'on a marqué non?"


translate french match2_7a59b4c5:


    dpense "1-1. Ruby a changé une situation critique en un moment incroyable."


translate french match2_50e9ab37:


    hec "C'est quoi ce cirque?"


translate french match2_9d67ac96:


    s "On va les défoncer. Ils auront pas autant de chance la prochaine fois."


translate french match2_dc01440e:


    gaby "C'était innatendu, mais efficace. Continuez et les laisser pas remonter!"


translate french match2_8646a8e5:


    dpense "Le match est reparti, il faut qu'on garde cette énergie."


translate french match2_0fc283ec:


    emerick "Sérieusement?"


translate french match2_5bd864ec:


    beth "Pas besoin de paniquer."


translate french match2_132e5c23:


    sofia "C'était bien joué. Ils sont meilleurs que je ne le pensais."


translate french match2_f7f4510f:


    kira "Intéressant..."


translate french match2_ec16b204:


    emerick "Tais-toi Kira. C'est pas le moment d'apprécier ces fantaisies."


translate french match2_cc6b5705:


    beth "Allez [name], montre-nous ce dont tu es capable."


translate french match2_bfbc8487:


    sofia "Reste concentré [name]."


translate french match2_bc7d616f:


    dpense "L'équipe de Steven semble déstabilisée après notre égalisation."


translate french match2_ffa0489a:


    gaby "Bonne réaction, mais ne relâchez pas la pression. Ils vont revenir plus forts!"


translate french match2_f3d4e5e0:


    ruby "C'est que le début, on vient de les secouer!"


translate french match2_afcc1829:


    mad "Faut continuer comme ça. Ne les laisser pas reprendre le contrôle."


translate french match2_d419577e:


    dpense "C'est maintenant ou jamais!"


translate french match2_d8110760:


    dpense "je réussis à chopper la balle."


translate french match2_c6abc97e:


    dpense "Faut juste que je passe ce gars et..."


translate french match2_28acde52:


    hec "Talan! Maintenant!" with hpunch


translate french match2_9d4ca66f:


    dpense "Hein?"


translate french match2_a315a1f9:


    dpense "Qu'est-ce que???"


translate french match2_0a953b4b:


    mad "Derrière toi!!!" with hpunch


translate french match2_07a7c5f3:


    julia "Vous allez le blesser!"


translate french match2_fc120b89:


    dpense "Râté! Bâtard..."


translate french match2_abf9d5be:


    hec "Ouch!"


translate french match2_c36be87a:


    hec "Casse-toi mon chemin! Idiot!"


translate french match2_b67fd9f0:


    dpense "Puatain mais ce gars..."


translate french match2_9a56cc01:


    dpense "Julia court..."


translate french match2_c1b81708:


    dpense "Je vais lui passer..."


translate french match2_05315ce2:


    d "Aoutch!"


translate french match2_1b8dbf39:


    mad "Qu'est ce que c'est que ça?"


translate french match2_1ef192a0:


    ruby "Il y a faute là!"


translate french match2_bb722d24:


    dpense "Et Steven qui prend la balle comme si rien ne s'était passé."


translate french match2_a0fe57e5:


    s "Et voilà le deuxième!"


translate french match2_f0c3d1c8:


    d "Grace!!!"


translate french match2_16e96a3a:


    grace "Je... Je l'ai touchée..."


translate french match2_34768985:


    ruby "C'est pas fini, on peut encore revenir."


translate french match2_5da8614c:


    gaby "Restez focus! Il y a encore du temps. Gardez la tête froide!"


translate french match2_7370e626:


    dpense "2-1... Il faut qu'on réagisse de suite. Le match n'est pas fini."


translate french match2_f945104f:


    emerick "Ouais! C'est ça que je voulais voir. Juste comme prévu."


translate french match2_db64e3e5:


    kira "J'aime bien cette dynamique."


translate french match2_358ea9d2:


    emerick "Arrête de paler Kira. Ce gosse doit comprendre à qui il a affaire."


translate french match2_97af930d:


    sofia "Ne sous-estime pas [name]."


translate french matchep4second_e78da9e2:


    dpense "Julia dribble rapidement jusqu'au goal."


translate french matchep4second_28480f4d:


    mac "T'es de retour Frenchie!"


translate french matchep4second_47836406:


    mac "Tu crois que t'as une chance avec tes tirs de moineau?"


translate french matchep4second_6cd653ed:


    dpense "Je suis au bon endroit pour shooter, mais ce coup-ci, je dois suivre les conseils de gabriella."


translate french matchep4second_4d2be1f1:


    d "Un dernier conseil pour le match qui arrive?"


translate french matchep4second_31a27688:


    gaby "Oh? Hmmm... Joue avec la barre."


translate french matchep4second_8a31fef2:


    dpense "Je suis pas vraiment sûr de ce que je fais..."


translate french matchep4second_a0e89740:


    mac "Trop haut!"


translate french matchep4second_d0988695:


    dpense "Okay..."


translate french matchep4second_6a6fbc07:


    dpense "Et maintenant?"


translate french matchep4second_8baee4f0:


    mad "[name]! Baisse-toi!"


translate french matchep4second_11991fc8:


    d "Quoi???"


translate french matchep4second_f3eab93d:


    dpense "J'ai l'impression de voir un oiseau voler."


translate french matchep4second_0e5206c6:


    dpense "Elle... fait un retourné en l'air? Sérieusement?"


translate french matchep4second_08f1d4c9:


    mad "Prend ça dans ta gueule!"


translate french matchep4second_5d63347f:


    d "C'est dedans! Putain quel tir!"


translate french matchep4second_fed7f7c0:


    ruby "Incroyable Madison!"


translate french matchep4second_70a788d3:


    d "Wow! Mais c'était quoi ce tir?"


translate french matchep4second_fe640476:


    mad "Je sais pas, j'ai improvisé!"


translate french matchep4second_6a99c886:


    hec "Ce match devient n'importe quoi!"


translate french matchep4second_9b6cbc23:


    s "Va falloir faire gaffe. C'est pas fini."


translate french matchep4second_59f5c083:


    gaby "Bien joué. Gardez la pression. Continuez comme ça!"


translate french matchep4second_141c267f:


    dpense "Julia garde la balle, dribblant avec une agilité incroyable."


translate french matchep4second_b2f80deb:


    dpense "Les filles sont instoppables!"


translate french matchep4second_38fafc12:


    dpense "Ruby va tirer!"


translate french matchep4second_3ee87ee0:


    dpense "Attends... Elle a râté???"


translate french matchep4second_39c058d3:


    julia "C'est dedans!"


translate french matchep4second_359a4e58:


    ruby "On l'a fait! Ahah quel jeu!"


translate french matchep4second_c970baeb:


    mad "Haha! Bien joué Ruby!"


translate french matchep4second_e6a4702b:


    hec "Ils ont encore marqué... C'est pas possible."


translate french matchep4second_ac22af49:


    s "On va les terminer, y'à pas de doutes."


translate french matchep4second_e0d12a3b:


    gaby "C'est mieux. Continuez et relâchez pas la pression."


translate french matchep4second_51e0ab44:


    dpense "2-2. Le match est reparti, mais faut garder cette énergie."


translate french matchep4second_499c4e94:


    dpense "2-1. Il faut qu'on en finisse maintenant."


translate french matchep4second_6fb1e762:


    emerick "Y'à pas moyen!"


translate french matchep4second_4eb64cbf:


    kira "Leur jeu devient de plus en plus fluide. Ce match est loin d'être joué."


translate french matchep4second_f94e811f:


    ruby "On continue! On les laisse pas respirer!"


translate french matchep4second_d25b09e0:


    dpense "L'autre équipe joue le tout pour le tout et avance en bloc."


translate french matchep4second_8ecbf1ba:


    dpense "Ils s'approchent du but."


translate french matchep4second_6f171c3f:


    d "Grace, tiens toi prête!"


translate french matchep4second_f80cd25b:


    dpense "Ils font un tir croisé!"


translate french matchep4second_2018f902:


    dpense "Grace va se faire battre!"


translate french matchep4second_39197b2c:


    d "Putain!"


translate french matchep4second_05315ce2:


    d "Aoutch!"


translate french matchep4second_23e0014d:


    grace "Ca va?"


translate french matchep4second_ebdec052:


    d "Ouais! Pas le choix de toute façon!"


translate french matchep4second_a7849659:


    grace "Merci [name], tu nous as sauvé..."


translate french matchep4second_ad983571:


    d "C'est pas fini."


translate french matchep4second_5c5a871f:


    dpense "Ils font un tir croisé!"


translate french matchep4second_f0c3d1c8:


    d "Grace!!!"


translate french matchep4second_aa175d96:


    d "Quel arrêt gracieux!"


translate french matchep4second_b66c1976:


    grace "Merci!"


translate french matchep4second_ffe847fc:


    grace "Allez on y va!"


translate french matchep4second_158eee26:


    dpense "Ruby reçoit la balle et charge l'équipe en face."


translate french matchep4second_59a47ab7:


    dpense "Julia et Madison suivent ses pas."


translate french matchep4second_ba0c383f:


    ruby "Madison, à toi!"


translate french matchep4second_8d89b654:


    dpense "Madison a la balle mais elle est marquée."


translate french matchep4second_86f915da:


    dpense "Elle passe à Julia."


translate french matchep4second_9a044c12:


    ruby "Hey!"


translate french matchep4second_ec185663:


    d "Julia!"


translate french matchep4second_4839864c:


    dpense "Elle me fait une talonnade alors qu'elle est en train de tomber!"


translate french matchep4second_5d8fbd38:


    dpense "Bien joué Julia!"


translate french matchep4second_1e2f00ad:


    julia "Ooof!"


translate french matchep4second_03a729f4:


    dpense "Madison n'est pas libre..."


translate french matchep4second_0aa83cc9:


    dpense "Ruby non plus..."


translate french matchep4second_11b34c7a:


    ruby "C'est à toi de le faire! Fais attention à Mac!" with hpunch


translate french matchep4second_c6c0e157:


    dpense "Tout dépend de moi maintenant. Je dois être prêt pour ce tir maintenant!"


translate french matchep4second_0ad36974:


    gaby "C'est le moment, tu sais ce que t'as à faire!"


translate french matchep4second_de458733:


    dpense "Je me positionne, mon coeur bat à mille à l'heure. C'est maintenant. Plus d'hésitation."


translate french matchep4second_46a94b4e:


    dpense "Je positionne mon pied..."


translate french matchep4second_00c2f60b:


    dpense "Je mets mon poids vers l'avant..."


translate french matchep4second_baa240b1:


    dpense "Hector est en train de hurler je sais pas quoi mais je n'entend plus rien. Focus."


translate french matchep4second_a0d76026:


    dpense "Respire..."


translate french matchep4second_d3be1be3:


    mad "Allez! Tu peux le faire!"


translate french matchep4second_8c5ead54:


    ruby "Je sais que tu peux marquer! Vas-y!"


translate french matchep4second_00251041:


    julia "C'est à toi maintenant! On compte toutes sur toi!"


translate french matchep4second_027daccb:


    dpense "Grace, Ruby, Madison, Julia... Elles sont toutes suspendues à mon tir. Je ne peux pas les décevoir."


translate french matchep4second_80f103fb:


    d "C'est fois-ci, c'est la BONNE!"


translate french matchep4second_1c691cc8:


    hec "Non... C'est pas possible!"


translate french matchep4second_763c08a6:


    julia "Il l'a fait!"


translate french matchep4second_7150340a:


    dpense "J'ai marqué. On a gagné!"


translate french matchep4second_932c5ef1:


    d "Je l'ai fait!"


translate french matchep4second_ff6fc861:


    d "Haha!"


translate french matchep4second_3b8a129e:


    emerick "Putain!!!!"


translate french matchep4second_3058ff8c:


    kira "La finale va être cool!"


translate french matchep4second_e5123440:


    beth "Hmmm..."


translate french matchep4second_e1bd8ff6:


    ruby "T'es le meilleur Cortex!"


translate french matchep4second_0e3e9124:


    d "Je pouvais rien faire sans toi Minus!"


translate french matchep4second_2dd9ffce:


    mad "On a tout donné, et ça a payé. On mérite notre finale."


translate french matchep4second_e37298c9:


    dpense "Les filles se congratulent entre elles, un large sourire sur leur visage. C'est une victoire bien méritée."


translate french matchep4second_404ff5ef:


    orushi "Homme du match : [name]!"


translate french matchep4second_9601c912:


    ruby "[name] ! On se voit après?"


translate french matchep4second_b95a51bd:


    d "Bien sûr! Donne moi juste le temps de me doucher et me changer et j'arrive!"

translate french strings:


    old "EDUCATION ACTIVATED"
    new "EDUCATION ACTIVEE"


    old "TEMPERAMENT ACTIVATED"
    new "TEMPERAMENT ACTIVE"


    old "SPORT ACTIVATED"
    new "SPORT ACTIVE"



translate french strings:


    old "BUDDY ACTIVATED"
    new "BUDDY ACTIVE"




translate french matchep4second_ff0c8649:


    d "Ouais, ça va! De toute façon y'avait pas le choix!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
