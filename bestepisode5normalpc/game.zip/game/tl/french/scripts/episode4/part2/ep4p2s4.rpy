


translate french ep4p2s4_51f317c6:


    ruby "J'arrive pas à croire qu'on ait gagné! Ce match était tendu."


translate french ep4p2s4_b7a16e73:


    d "Ouais, mais la finale va être encore plus dûre. Il faut qu'on reste prêts."


translate french ep4p2s4_cf3bc980:


    ruby "Pfff... Avec moi dans l'équipe? On va le faire!"


translate french ep4p2s4_9329e1ed:


    emerick "Encore toi? T'en as pas marre de te mettre sur mon chemin?"


translate french ep4p2s4_db16eb90:


    d "Tu devrais peut être arrêter de me suivre alors."


translate french ep4p2s4_1a7a161f:


    emerick "Tu crois que t'es intouchable juste parce que tu gagnes? Petite info pour toi, tu n'es rien."


translate french ep4p2s4_67d7ebd1:


    ruby "Emerick, c'est inutile. Laisse le tranquille."


translate french ep4p2s4_5208f1a9:


    emerick "Reste en dehors de ça, Ruby."


translate french ep4p2s4_4320e783:


    ruby "Je suis sérieuse. C'est des gamineries!"


translate french ep4p2s4_e2bd787f:


    ruby "Vous deux, arrêtez!!!!"


translate french ep4p2s4_79a17149:


    d "RUBY!!!!!!!!!!!!"




translate french ep4p2s4_d0877d63:


    emerick "Encore toi? T'en as pas marre de tout le temps être sur mon chemin?" with hpunch


translate french ep4p2s4_9b139935:


    d "Râté!"


translate french ep4p2s4_1cdf3893:


    emerick "Casse-toi!"


translate french ep4p2s4_61e6b404:


    ruby "Ahhhh!" with hpunch


translate french ep4p2s4_bebbbb63:


    d "RUBY!!!!!!!!!!" with hpunch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
