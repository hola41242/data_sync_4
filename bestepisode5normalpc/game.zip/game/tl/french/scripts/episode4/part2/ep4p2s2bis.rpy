


translate french ep4p2s2bis_0ae9bcd0:


    ""


translate french ep4p2s2bis_49b4de62:


    kira "Ah, ben te voilà! T'en as mis du temps!"


translate french ep4p2s2bis_5522736e:


    d "J'étais occupé... et puis c'est toi qui m'a invité non?"


translate french ep4p2s2bis_71249c93:


    kira "Oui oui et je suis content que tu sois venu. J'espère que tu vas apprécier la soirée!"


translate french ep4p2s2bis_abfc4897:


    d "Tu sembles particulièrement en forme ce soir. T'as prévu quelque chose de spécial?"


translate french ep4p2s2bis_0bd36608:


    kira "Rien de fou, juste une soirée sympa entre amis. J'aime voir comment les gens se lâchent après quelques verres. Toujours amusant."


translate french ep4p2s2bis_22c9f1f2:


    d "J'imagine. Du coup tu as un plan pour la soirée, ou tu vas juste te laisser aller avec l'ambiance?"


translate french ep4p2s2bis_3f159b67:


    kira "Un peu des deux. Je dois veiller sur Fanny, être sûre qu'elle fasse le show, et chopper des clichés pour OnlyStan. Ca paie bien tu sais?"


translate french ep4p2s2bis_523898a1:


    d "Ouais, on dirait une mine d'or ton truc... Et avec tous les trucs d'AI c'est pas un peu plus difficile?"


translate french ep4p2s2bis_d808c8d1:


    kira "QUi sait? Pour l'instant, c'est de l'argent facile. Et les gens paient encore plus pour des illusions que pour la réalité."


translate french ep4p2s2bis_09a48cda:


    d "Et qu'est ce qu'il se passe si ils se rendent compte que c'est faux?"


translate french ep4p2s2bis_bd828e19:


    kira "Ils comprennent pas. Ils en ont pas envie. Tout le monde aime les fantasmes et je leur donne juste ce qu'ils demandent."


translate french ep4p2s2bis_f6f2c8fb:


    d "On dirait que tu maîtrises tout ça. T'as pensé à en faire quelque chose de plus... légal?"


translate french ep4p2s2bis_7452d65d:


    kira "Qu'est ce qui est légal vraiment? Si ça paie, ça marche. A l'inverse de toi, j'ai pas besoin de me mouiller pour avoir des résultats."


translate french ep4p2s2bis_8a617357:


    d "Dis la fille qui travaille sur son téléphone comme un job à plein temps."


translate french ep4p2s2bis_c7798e5b:


    kira "Touché. Mais soyons honnêtes, entre étudier et gérer une affaire, qui a le vrai pouvoir ici?"


translate french ep4p2s2bis_b42f115b:


    d "Je suppose qu'on verra quand j'aurais gagné le B.E.S.T."


translate french ep4p2s2bis_dcce6b13:


    kira "Oh? De la confiance? J'aime ça. Continue comme ça."


translate french ep4p2s2bis_b0546b66:


    kira "Allez amuse-toi, mais n'oublies pas le match de demain."


translate french palazio_gabriella_charlotte_14ef5c37:


    dpense "Oh? Gabriella?"


translate french palazio_gabriella_charlotte_49c12c87:


    dpense "Et... Charlotte?"


translate french palazio_gabriella_charlotte_1d8386f2:


    cha "Ces temps-ci, je suis de plus en plus intriguée à l'idée de flirter avec un jeune homme."


translate french palazio_gabriella_charlotte_0fb2ac99:


    dpense "Intéressant... Je vais écouter un petit peu. "


translate french palazio_gabriella_charlotte_3769dfaf:


    gaby "Oh? Tu veux dire... Quelqu'un qui a à peine l'âge de commander un verre?"


translate french palazio_gabriella_charlotte_87137957:


    cha "Ouais..."


translate french palazio_gabriella_charlotte_50cf5c9c:


    gaby "Oh, intéressant. Ca serait la première fois pour toi hein?"


translate french palazio_gabriella_charlotte_c6ff4f28:


    cha "Complètement. Ca ne m'était jamais venu à l'esprit avant. Et toi?"


translate french palazio_gabriella_charlotte_c70a5ce7:


    gaby "Pareil, mais honnêtement, je crois en sentir le besoin."


translate french palazio_gabriella_charlotte_6a3e5667:


    cha "Ils ont cette fraîcheur et cette énergie tu sais? C'est excitant."


translate french palazio_gabriella_charlotte_03604e35:


    dpense "Elles sont en train de parler de moi?"


translate french palazio_gabriella_charlotte_ae385376:


    gaby "Ouais, et y'à un truc de spontané avec eux... de fougueux. Ca peut être rafraîchissant."


translate french palazio_gabriella_charlotte_2087bed4:


    cha "C'est ça! Mais il faut un peu de maturité quand même. Pas de babysitting."


translate french palazio_gabriella_charlotte_b7c2e1d5:


    gaby "Et qu'il soit intelligent. Si il est juste là pour dire 'oui-oui' ça ne marchera pas."


translate french palazio_gabriella_charlotte_ae875628:


    cha "Complètement! Mais imagine quelqu'un avec de l'énergie et qui prenne soin de toi? C'est rare."


translate french palazio_gabriella_charlotte_6887397d:


    gaby "Et qui sait tenir le rythme. Y'en a qui font les mâlins en te promettant une nuit de folie et..."


translate french palazio_gabriella_charlotte_1871a36d:


    cha "Qui s'endorment directs après le premier round? On connaît ça."


translate french palazio_gabriella_charlotte_1aac0b32:


    gaby "Je veux quelqu'un qui m'écoute tu vois?"


translate french palazio_gabriella_charlotte_c80e4db7:


    cha "Oh, tu veux dire quelqu'un qui soit là pour toi et qui se sente investi dans la relation? C'est une licorne ça!"


translate french palazio_gabriella_charlotte_d90f3750:


    gaby "Exactement! Un gars qui sait prendre les rennes mais qui sait aussi se retenir quand il le faut."


translate french palazio_gabriella_charlotte_47a77884:


    cha "Hmmm, maintenant ça me donne encore plus envie d'essayer..."


translate french palazio_gabriella_charlotte_aa5bd80d:


    dpense "C'était une discussion intéressante. Il faut que je garde contacts avec elles."


translate french palazio_gabriella_charlotte_b425999c:


    dpense "Je savais pas qu'elle se connaissaient."


translate french palazio_gabriella_charlotte_3b497e25:


    dpense "Ca pourrait être intéressant..."


translate french palazio_dancefloor_8d839d85:


    d "Vous dancez bien, dûr de ne pas le remarquer."


translate french palazio_dancefloor_16616b27:


    ji "Oh? C'est comme ça que tu penses chopper? Couillu."


translate french palazio_dancefloor_7e8f7728:


    d "Je pense que c'est plus une observation qu'une phrase d'accroche."


translate french palazio_dancefloor_77c1853a:


    ji "Hmmm... Je devrais te remercier alors?"


translate french palazio_dancefloor_703bcbb5:


    d "Seulement si ça vous intéresse."


translate french palazio_dancefloor_db7ea34b:


    ji "J'aime les gens qui savent me parler. Mais dis-moi, tu serais pas un peu jeune pour moi?"


translate french palazio_dancefloor_73f96a46:


    d "Peut être, mais l'âge n'est il pas juste une histoire de perspective?"


translate french palazio_dancefloor_57e473f6:


    ji "Un jeune homme avec de la confiance. Mais être courageux ne sera pas suffisant mon cher."


translate french palazio_dancefloor_3a66788a:


    d "Alors qu'est ce que je dois faire?"


translate french palazio_dancefloor_5c95885b:


    ji "Du mystère. Du contrôle. Et, plus important, savoir quand arrêter de chasser."


translate french palazio_dancefloor_7367dea2:


    ji "Envoie-moi un message... Si tu penses pouvoir être à la hauteur. Et moi c'est Evelyn au fait."


translate french palazio_kira_fanny_f5e96e01:


    d "Alors, c'est ton grand projet ce soir?"


translate french palazio_kira_fanny_397b9762:


    kira "Qu'est ce que tu crois? L'argent tombe pas tout seul."


translate french palazio_kira_fanny_3d79c3a3:


    d "Et moi qui pensait que tu étais juste en train d'apprécier le show."


translate french palazio_kira_fanny_ecc06f6e:


    kira "Oh je le fais! Mais je cherche aussi les meilleurs angles pour que Fanny puisse en retirer chaque centime."


translate french palazio_kira_fanny_829f95d3:


    d "T'es vraiment à fond là-dedans."


translate french palazio_kira_fanny_0b799d82:


    kira "Tu paraîs surpris. J'aime pas les choses faites à moitié. Si je fais les choses, je les fais bien."


translate french palazio_kira_fanny_5f32cb00:


    d "Rappelle moi de ne jamais te sous-estimer."


translate french palazio_kira_fanny_222483ba:


    kira "Choix intelligent. Maintenant va t'amuser pendant que je transforme ça en mine d'or."


translate french palazio_kira_fanny_9dce8f2a:


    d "Et les photos ça va?"


translate french palazio_kira_fanny_006eaa46:


    kira "Ouais, génial. Et t'as pas vu la meilleure partie. Avec l'AI, je peux prendre ces clips et les faire ressembler à ce que je veux."


translate french palazio_kira_fanny_b9481509:


    kira "Les gars vont payer une tonne pour du contenu trafiqué, et Fanny aura même pas à bouger le petit doigt."


translate french palazio_kira_fanny_17b9a34a:


    d "Et personne s'en plaint?"


translate french palazio_kira_fanny_9834c423:


    kira "Pourquoi ils le feraient? Ils ont exactement ce qu'ils veulent, même si c'est pas 'vrai'. Gagnant-Gagnant."


translate french palazio_kira_fanny_8ad9b91e:


    kira "Tu sais, le fake est bien plus profitable que le réel. C'est pas de l'arnaque, c'est de l'adaptation au marché."


translate french palazio_kira_fanny_f9ee1416:


    d "Et toi? Tu gères ça dans l'ombre... T'as pas envie de tester et de te mettre en avant?"


translate french palazio_kira_fanny_ba2693ca:


    kira "Moi? Jamais! Je suis une Orushi. J'ai une réputation à tenir. Performer? Pas mon truc."


translate french palazio_kira_fanny_5e1f4a8b:


    kira "Enfin bref, amuse-toi, mais n'oublies pas le match de demain. Voyons voir si t'es aussi bon sur le terrain qu'avec les filles."


translate french palazio_kira_fanny_f77eea5e:


    dpense "Elle a raison. Le match..."




translate french ep4p2s2bis_321c818f:


    d "Ouais, on dirait que t'as trouvé une mine d'or..."


translate french ep4p2s2bis_0f7efc7b:


    kira "Qui sait? Pour l'instant c'est de l'argent facile."


translate french palazio_gabriella_charlotte_3869eae3:


    gaby "Ouais et y'à un truc de spontané avec eux. Quelque chose... d'inattendu. C'est rafraîchissant."


translate french palazio_dancefloor_6d208509:


    dpense "Wow! C'est qui cette femme?"


translate french palazio_dancefloor_17ec4e46:


    dpense "Mystérieuse... et intrigante!"


translate french palazio_dancefloor_d70e0b8e:


    dpense "J'aime ça!"


translate french palazio_kira_fanny_eabe8c3d:


    d "Hum... Je vois."


translate french palazio_kira_fanny_87a80f3c:


    d "Attends..."


translate french palazio_kira_fanny_6feb7f18:


    d "Elle porte pas de culotte?" with hpunch


translate french palazio_kira_fanny_bf70984c:


    kira "Ahah! Non! Ca excite les gars alors je me focus sur son cul!"


translate french palazio_kira_fanny_8df0b723:


    d "T'as de la chance que y'ait pas grand monde."


translate french palazio_kira_fanny_45c23257:


    kira "Ouais, c'est tôt. C'est pour ça qu'on est là d'ailleurs."


translate french palazio_kira_fanny_ae34bddc:


    d "Comment ça?"


translate french palazio_kira_fanny_8d1b7bcd:


    kira "Ben on peut bosser tranquille sans avoir des abrutis à venir nous faire chier."


translate french palazio_kira_fanny_2624a59e:


    kira "Ca c'est intelligent!"


translate french palazio_kira_fanny_80e19788:


    kira "Allez viens là! On va prendre un selfie ensemble!"


translate french palazio_kira_fanny_6672ddba:


    kira "Fanny! Viens là! Double bisous!"


translate french palazio_kira_fanny_b7e3ab68:


    kira "Regarde ton OnlyStan un peu plus tard."


translate french palazio_kira_fanny_1a7ff2b3:


    d "Elle t'obéis au doigt et à l'oeil."


translate french palazio_kira_fanny_0bf9a922:


    kira "Evidemment."


translate french palazio_kira_fanny_c4de64ce:


    kira "Elle sait d'où viennent les sous!"


translate french palazio_kira_fanny_d066b3a0:


    kira "Les gars paient une tonne pour elle, et elle a rien à faire."


translate french palazio_kira_fanny_90d0f720:


    kira "J'ai même commencé à utiliser de l'IA pour faire des petits clips... Je te montrerais!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
