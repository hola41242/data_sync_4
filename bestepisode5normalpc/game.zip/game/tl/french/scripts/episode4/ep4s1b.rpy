


translate french ep4s1b_2aef19a0:


    "Cet ascenseur pourri... Ils doivent vraiment le remplacer." with hpunch


translate french ep4s1b_20db93c1:


    dpense "Quelqu'un passe clairement pas une bonne journée."


translate french ep4s1b_f023dd57:


    d "Je suis là..."


translate french ep4s1b_7e007843:


    gaby "Pile à l'heure !"


translate french ep4s1b_237b830f:


    dpense "Elle est aussi sexy qu'elle est stricte."


translate french ep4s1b_9e1cd86e:


    dpense "Son décolleté..."


translate french ep4s1b_6ff3d2b0:


    gaby "C'est fascinant."


translate french ep4s1b_774234f3:


    d "Ça l'est..."


translate french ep4s1b_4cb68f51:


    d "Pardon, quoi ?"


translate french ep4s1b_123981c4:


    gaby "C'est fascinant de voir comment les civilisations anciennes ont jeté les bases de tout ce que nous avons aujourd'hui."


translate french ep4s1b_3ad169b2:


    d "Oh ! Hum... Oui !"


translate french ep4s1b_6e5af138:


    gaby "Même si le temps a passé, leur influence est toujours là. Nous sommes peut-être modernes, mais nos racines sont anciennes, profondément ancrées dans l'histoire."


translate french ep4s1b_64f8e3ca:


    d "Donc, nous sommes comme des versions mises à jour du monde antique ? Comme des tablettes high-tech basées sur des tablettes d'argile ?"


translate french ep4s1b_ed00c3fc:


    gaby "C'est une façon de le voir, mais... C'est un peu plus complexe que ça."


translate french ep4s1b_b51c5cb8:


    dpense "Note pour moi-même : ne compare pas les civilisations anciennes à des iPads devant un professeur."


translate french ep4s1b_8c66ec4d:


    gaby "Ce qui est important, c'est de comprendre que vieux ne veut pas forcément dire dépassé."


translate french ep4s1b_36eb79ab:


    gaby "En fait, ce qui est ancien est souvent plus stable, plus fiable que quelque chose de nouveau."


translate french ep4s1b_46126506:


    d "Donc, vous dites que les choses anciennes ont plus de valeur que les nouvelles ?"


translate french ep4s1b_82c0b67e:


    d "Comme une voiture classique par rapport à une toute nouvelle bien brillante ?"


translate french ep4s1b_f047d55f:


    gaby "Disons qu'il y a une sagesse dans l'expérience que tu ne peux pas obtenir de quelque chose de jeune et non éprouvé."


translate french ep4s1b_092c33aa:


    dpense "L'expérience, hein ? Oui, elle a ça. Je me demande si elle réalise à quel point cette conversation pourrait... prendre une autre tournure."


translate french ep4s1b_1628d00c:


    d "Je suppose que les choses nouvelles sont excitantes, mais elles n'existeraient pas sans les anciennes, non ?"


translate french ep4s1b_00a2dc22:


    d "On pourrait dire qu'elles se complètent... un peu comme un couple."


translate french ep4s1b_443de289:


    gaby "Euh... Je parlais des civilisations, mais... Oui, c'est une comparaison appropriée."


translate french ep4s1b_22c093f7:


    dpense "Appropriée ? Presque un ‘A+’ pour celle-là."


translate french ep4s1b_1b0c331e:


    gaby "Prenons cette sculpture, par exemple. Elle représente les traditions et les valeurs d'une époque révolue."


translate french ep4s1b_e5cc9718:


    gaby "Mais ces valeurs, même si elles ont évolué, sont toujours présentes dans notre société."


translate french ep4s1b_22c6401f:


    gaby "Nous les avons adaptées, mais leurs racines sont toujours là. C'est comme... une fondation sur laquelle notre société a été construite."


translate french ep4s1b_aa28714c:


    d "Une base solide. Comme vous. Enfin, pas vous-vous, mais... Vous voyez ce que je veux dire."


translate french ep4s1b_f05d77db:


    gaby "Oui, je pense que je comprends."


translate french ep4s1b_f8fd408a:


    dpense "Bien joué, [name], tu viens de comparer une femme à une fondation. Si je m'en sors, je mérite une médaille."


translate french ep4s1b_65731413:


    gaby "Ces civilisations comprenaient que l'équilibre entre l'ancien et le nouveau était crucial."


translate french ep4s1b_eb5c5da1:


    gaby "Il ne s'agit pas de tout remplacer, mais d'évoluer tout en gardant ce qui est précieux du passé."


translate french ep4s1b_c28fbdee:


    d "Donc, pour évoluer, tu dois respecter l'ancien tout en embrassant le nouveau ? Ça... a du sens."


translate french ep4s1b_50f19c6d:


    d "Et si on faisait ça avec, eh bien... tout ?"


translate french ep4s1b_26954de7:


    gaby "Qu'est-ce que tu veux dire par là ?"


translate french ep4s1b_d47c4d06:


    d "Je veux dire, vous savez, les relations, les dynamiques. Ce n'est pas si différent, non ?"


translate french ep4s1b_c654f226:


    d "Respecter l'expérience et apprendre du neuf."


translate french ep4s1b_e2038cd7:


    gaby "Euh... Je suppose."


translate french ep4s1b_d265d969:


    dpense "Bingo. Elle y réfléchit. Allez, Gabriella, un petit sourire."


translate french ep4s1b_0c7848ff:


    gaby "Ce que je veux dire, c'est que ces civilisations savaient que l'harmonie venait de la compréhension de leurs racines, mais aussi de l'ouverture aux nouvelles idées."


translate french ep4s1b_a660b588:


    d "Comme nous, non ? Une ancienne civilisation et une nouvelle génération... Explorant ensemble de nouvelles idées."


translate french ep4s1b_80d6b94e:


    gaby "C'est... Une façon de voir les choses, oui."


translate french ep4s1b_6629519d:


    dpense "Je pense qu'elle commence à changer d'avis."


translate french ep4s1b_d15890e0:


    gaby "Il y a encore plus à voir à l'étage. La prochaine partie de l'exposition montre comment la vie moderne se rattache à ces fondations anciennes."


translate french ep4s1b_869e1168:


    d "Ça a l'air super, mais... J'ai un dîner de prévu ce soir. Je dois rejoindre Madison."


translate french ep4s1b_ea20ae3b:


    gaby "Oh, je ne savais pas que tu avais des plans."


translate french ep4s1b_0d7758e5:


    dpense "Elle ne le montre pas, mais je peux dire qu'elle est un peu déçue."


translate french ep4s1b_175c9f5c:


    d "Oui, j'avais presque oublié... J'ai promis d'y être."


translate french ep4s1b_1467dd29:


    dpense "Je ne peux vraiment pas rester. J'ai fait une promesse."


translate french ep4s1b_d26bb7e7:


    d "Gabriella, je suis vraiment désolé, mais je dois partir. Je ne peux pas rester."


translate french ep4s1b_a81dc863:


    gaby "Oh... Je comprends. Les dîners, c'est important."


translate french ep4s1b_57b94c81:


    dpense "Je peux sentir sa déception, mais elle essaie de la cacher."


translate french ep4s1b_bcf8ece3:


    d "Je me rattraperai, je vous le promets."


translate french ep4s1b_bbfd92a2:


    gaby "C'est bon. Va, ne la fais pas attendre."


translate french ep4s1b_53eff1d8:


    dpense "J'ai l'impression de rater quelque chose d'important en partant."


translate french ep4s1b_305f0aa8:


    dpense "Le dîner peut attendre. Je ne suis pas prêt à la quitter maintenant."


translate french ep4s1b_bdee29e8:


    d "Vous savez quoi ? Le dîner peut attendre."


translate french ep4s1b_bd4db720:


    gaby "Vraiment ? Ça me fait plaisir."


translate french ep4s1b_15d7de72:


    dpense "Il y a quelque chose dans son sourire qui rend impossible de partir maintenant."


translate french ep4s1b_d6e11cdb:


    gaby "Très bien, allons à l'étage alors."


translate french ep4elevator_7667e06b:


    gaby "Nous allons prendre l'ascenseur là-bas pour accéder au deuxième étage."


translate french ep4elevator_01b3701d:


    gaby "Qu'est-ce... Qu'est-ce qui vient de se passer ?"


translate french ep4elevator_c6eacd14:


    d "Je pense que l'ascenseur s'est arrêté."


translate french ep4elevator_3f7ab310:


    dpense "Évidemment, il fallait que ça arrive maintenant."


translate french ep4elevator_77feb3f8:


    gaby "Il est bloqué ? Qu'est-ce qu'on fait ?"


translate french ep4elevator_2ce331f6:


    d "Essayons d'appeler à l'aide. On va sortir d'ici."


translate french ep4elevator_7ddedd2d:


    d "Bonjour ? Il y a quelqu'un ? L'ascenseur est bloqué !"


translate french ep4elevator_52150cb5:


    "Nous avons déjà appelé le réparateur... Mais il ne répond pas. Vous pourriez être coincés un moment."


translate french ep4elevator_034ac3e3:


    dpense "Génial... Coincé dans un ascenseur. Juste moi et Gabriella. Ça pourrait être pire... Ça pourrait être bien pire."


translate french ep4elevator_fba8c6cd:


    gaby "Vous pensez qu'on sera coincés combien de temps ?"


translate french ep4elevator_738373b2:


    "Difficile à dire. Il faudra être patient."


translate french ep4elevator_0ab0a545:


    dpense "Le timing ne pouvait pas être pire. Je vais définitivement manquer le dîner avec Madison maintenant..."


translate french ep4elevator_f505d2df:


    d "Je devrais prévenir Madison que je vais être en retard."


translate french ep4elevator_b982659c:


    dpense "Pas de réseau... C'est parfait, vraiment..."


translate french ep4elevator_312f63db:


    dpense "Donc, je suppose que c'est juste moi et Gaby maintenant, sans distractions."


translate french ep4elevator_3a4b1a0d:


    gaby "Je suppose qu'on est coincés pour un moment..."


translate french ep4elevator_8c147f51:


    dpense "Juste nous deux, coincés ensemble. Ça pourrait être intéressant."


translate french ep4elevator_cff633d9:


    gaby "Il commence à faire chaud ici ou c'est juste moi ?"


translate french ep4elevator_3da2c0ae:


    d "Non, il fait définitivement plus chaud. Probablement parce qu'il n'y a pas de ventilation."


translate french ep4elevator_6b2fa339:


    d "Peut-être qu'on devrait... se déshabiller un peu. Tu sais, pour éviter de surchauffer."


translate french ep4elevator_0a9639bc:


    gaby "Quoi ? Je... Non, ce n'est pas nécessaire."


translate french ep4elevator_966568ec:


    d "Écoute, c'est juste nous deux. Personne ne va voir."


translate french ep4elevator_409c7c4d:


    dpense "Elle hésite, mais je peux voir qu'elle y réfléchit."


translate french ep4elevator_c0b28a5d:


    dpense "La chaleur rend sa résistance plus difficile."


translate french ep4elevator_c66e1d4d:


    gaby "Je ne sais pas... Ça ne semble pas approprié."


translate french ep4elevator_7b8b73cd:


    dpense "Allez, Gabriella, tu transpires déjà. Laisse-toi aller."


translate french ep4elevator_0ca38835:


    d "Fais-moi confiance, tu te sentiras mieux. Moi, je vais le faire."


translate french ep4elevator_f21b46f4:


    dpense "Je vais enlever ma chemise. Il fait trop chaud pour se soucier du reste."


translate french ep4elevator_a2af452c:


    gaby "Je suppose... Oui, c'est vrai."


translate french ep4elevator_ce90d82c:


    dpense "Elle enlève vraiment sa veste ?! Ses mouvements sont lents, hésitants..."


translate french ep4elevator_1b378c31:


    dpense "Mais elle le fait. Et maintenant, je ne peux plus détourner les yeux."


translate french ep4elevator_ac0c4fc5:


    dpense "La façon dont sa chemise colle à sa peau, cette fine couche de tissu, toute cette beauté cachée, bien visible."


translate french ep4elevator_3bfd40bf:


    dpense "Ses courbes, son corps... Je ne peux pas la quitter des yeux."


translate french ep4elevator_3cc651e4:


    dpense "Ce chemisier épouse parfaitement sa silhouette. Je peux voir chaque ligne, chaque courbe..."


translate french ep4elevator_a06eab4e:


    dpense "Rien d'autre n'existe en ce moment, à part elle."


translate french ep4elevator_1d229afa:


    gaby "Ce... Ce n'est pas comme ça que j'avais imaginé ma journée."


translate french ep4elevator_45f8bbf6:


    d "Moi non plus, mais je ne vais pas me plaindre."


translate french ep4elevator_c03d21c1:


    dpense "Elle se tient là, à quelques pas seulement. La distance semble plus petite, l'air entre nous chargé de chaleur et... d'autre chose."


translate french ep4elevator_0465ce21:


    dpense "Elle est si proche maintenant. Sa peau, son corps... juste hors de portée."


translate french ep4elevator_d5e0f854:


    dpense "Mon cœur s'emballe, et à la façon dont elle me regarde... J'espère qu'elle le ressent aussi."


translate french ep4elevator_d5f13aa0:


    gaby "Je pense... Qu'on est un peu trop proches."


translate french ep4elevator_8d148ee1:


    dpense "Trop proches ? Est-ce qu'il y a quelque chose de plus proche ?"


translate french ep4elevator_2ff5d7f3:


    d "Peut-être... mais parfois, ces choses arrivent naturellement, non ?"


translate french ep4elevator_e29be498:


    dpense "On dirait qu'elle veut dire quelque chose, mais elle ne parle pas."


translate french ep4elevator_de3d9a7b:


    dpense "Est-ce qu'elle veut ça aussi ? Elle se tient juste à côté de moi. Cette tension me rend fou."


translate french ep4elevator_eceab2b3:


    gaby "C'est... Mal, mais..."


translate french ep4elevator_c21e7875:


    dpense "Elle détourne le regard, mais elle est toujours si proche. Elle pourrait le vouloir autant que moi."


translate french ep4elevator_910ce499:


    d "Mais ça donne envie, non ?"


translate french ep4elevator_6f6aa215:


    dpense "Sa main est juste là. Je veux l'atteindre, la prendre. Réduire ce dernier espace entre nous."


translate french ep4elevator_4ff38949:


    dpense "Sa respiration est courte, sa poitrine monte et descend plus vite. Elle est toujours là. Elle doit vouloir ça aussi."


translate french ep4elevator_fcb96b1b:


    gaby "On ne devrait pas..."


translate french ep4elevator_2c4142c9:


    d "Peut-être... mais tu veux vraiment arrêter ?"


translate french ep4elevator_8dff537d:


    dpense "Toujours silencieuse, toujours juste devant moi."


translate french ep4elevator_47b86c10:


    dpense "C'est comme si nous étions figés, attendant l'inévitable."


translate french ep4elevator_4468b7df:


    "Le réparateur est là ! Désolé pour le retard. Deux minutes et vous serez libres."


translate french ep4elevator_1e0c076a:


    gaby "Oh ! Euh... Merci !"


translate french ep4elevator_6f9314a4:


    dpense "Nous étions... Nous avons presque... Qu'est-ce qui vient de se passer ?"


translate french ep4elevator_05c6b624:


    "Vous pouvez y aller maintenant."


translate french ep4elevator_1a23e951:


    d "D'accord... Merci."


translate french ep4elevator_5796a093:


    dpense "Enfin, on est sortis de cet ascenseur. Mais elle regarde toujours ailleurs. Nous avons presque..."


translate french ep4elevator_b437b2be:


    dpense "J'ai de nouveau du réseau sur mon téléphone, bien."


translate french ep4elevator_8cd916f1:


    d "Je devrais vérifier mes messages."


translate french ep4elevator_df81e54d:


    mad "Où es-tu ?" with hpunch


translate french ep4elevator_fd83eba6:


    mad "Tu es en retard !" with hpunch


translate french ep4elevator_cb375f76:


    mad "Tu m'ignores sérieusement ?" with hpunch


translate french ep4elevator_3ac6e9bf:


    mad "Tu as intérêt à avoir une bonne raison pour ça !" with hpunch


translate french ep4elevator_34af879e:


    mad "Tu es incroyable." with hpunch


translate french ep4elevator_7eea6d94:


    dpense "Génial. Madison est furieuse. Ça va être sympa à expliquer."


translate french ep4elevator_73791ccf:


    gaby "Tout va bien ?"


translate french ep4elevator_30eecdde:


    d "Oui... Juste quelques messages auxquels je dois répondre."


translate french ep4elevator_164e2365:


    dpense "Je ne peux pas m'empêcher de penser à ce qui a failli se passer... et à ce qui aurait pu arriver si nous n'avions pas été interrompus."


translate french ep4elevator_86714805:


    gaby "Eh bien, je suppose que c'est ici qu'on se quitte..."


translate french ep4elevator_2bc57af2:


    dpense "Elle fait comme si de rien n'était, mais elle ne me trompe pas. Je sais qu'elle pense aussi à ce qui s'est passé."


translate french ep4elevator_31316f12:


    d "Oui, je suppose... On se revoit ?"


translate french ep4elevator_4bad11ec:


    gaby "Oui... À bientôt."


translate french ep4elevator_e1631a3d:


    dpense "Elle sourit toujours, mais elle semble tendue, sur la réserve. Nous étions si proches tout à l'heure... peut-être trop proches."


translate french ep4elevator_5ffc9210:


    gaby "Prends soin de toi, [name]."


translate french ep4elevator_8cd50de3:


    d "Toi aussi, Gabriella."


translate french ep4elevator_8234f528:


    dpense "Je me demande si les choses seront différentes la prochaine fois qu'on se verra."


translate french ep4elevator_07cf2c01:


    dpense "La journée n'est pas encore finie, et je dois encore gérer Madison. J'espère juste pouvoir sauver ce qui reste de la soirée."

translate french strings:


    old "Go to the dinner with Madison"
    new "Aller au dîner avec Madison"


    old "Stay with Gabriella"
    new "Rester avec Gabriella"




translate french strings:


    old "Go to the dinner with Madison[TEMP1!t]"
    new "Rejoindre Madison[TEMP1!t]"


    old "Stay with Gabriella[TEMP2!t]"
    new "Rester avec Gabriella[TEMP2!t]"




translate french ep4elevator_53f21230:


    dpense "La façon dont son haut épouse sa peau, cette couche de tissu, toute cette beauté cachée, demandant d'être révélée."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
