


translate french masterepreuveep4_c28a81b6:


    "Vous avez réussi l'épreuve avec succès !"


translate french masterepreuveep4_90ac4d81:


    "Veuillez patienter pendant que votre résultat s'affiche."


translate french masterepreuveep4_5f25cb0b:


    "Vous avez terminé premier, votre classement B.E.S.T sera mis à jour en conséquence."


translate french masterepreuveep4_7ec3c5c3:


    "Votre équipe a terminé en deuxième position, votre classement B.E.S.T sera mis à jour en conséquence."


translate french masterepreuveep4_53bc6a15:


    "Votre équipe a terminé à la 5e place, votre classement B.E.S.T sera mis à jour en conséquence."


translate french masterepreuveep4_56b59a55:


    "Votre équipe a terminé à la 14e place, votre classement B.E.S.T sera mis à jour en conséquence."


translate french emericktrialep4_b2f31e5e:


    "Annonce à tous les participants :"


translate french emericktrialep4_e6973948:


    "Le premier duo à remporter l'épreuve est :"


translate french emericktrialep4_ea83f46d:


    "L'équipe d'Emerick."


translate french emericktrialep4_c23b34ab:


    dpense "Merde... Encore lui..."


translate french gracefintrialep4_9cdc3488:


    "Bzzz bzzz"


translate french gracefintrialep4_97d130d1:


    grace "J'ai reçu un message de ma mère."


translate french gracefintrialep4_3deed7ed:


    d "Vraiment ?"


translate french gracefintrialep4_0bbee708:


    grace "Oui. Elle vient de me donner le code."


translate french gracefintrialep4_fd6aa687:


    grace "Allons à l'amphi."


translate french gracefintrialep4_43b49e4c:


    d "D'accord."


translate french gracefintrialep4_5f9ff550:


    grace "Nous y voilà !"


translate french gracefintrialep4_5b5ee1b7:


    dpense "C'est un peu de la triche, mais bon..."


translate french gracefintrialep4_ade1dd2d:


    dpense "J'imagine que Mme Drew est prête à tout pour s'assurer que sa fille réussisse."


translate french rienDansCettePiece_5a2e0c5c:


    "On dirait qu'il n'y a rien ici."


translate french rienDansCetObjet_0d41afa0:


    d "Je n'ai rien trouvé."


translate french plusRienDansCetObjet_ba8fb8ed:


    d "Il n'y a plus rien à trouver ici..."


translate french trouveUnObjet_99bd8c4e:


    d "Oh, j'ai trouvé quelque chose !"


translate french trouveUnObjet_5686c6b1:


    d "Le numéro que j'ai trouvé est [currentFoundObject.linkedNumber]"


translate french trouveUnObjet_3dadca81:


    "Bzzz bzzz" with hpunch


translate french trouveUnObjet_c97b3b7f:


    julia "Oh, j'ai reçu un message de Ruby."


translate french trouveUnObjet_deda3703:


    julia "Elle a trouvé un numéro que nous n'avons pas ! C'est [str(getNotFoundObject().linkedNumber)] !"


translate french trouveUnObjet_4762ac9d:


    julia "Tout ce qu'il reste à faire, c'est retourner à l'amphi."


translate french trouveUnObjet_d1fb860d:


    "Il n'y a plus rien à trouver ici."


translate french changerPiece_e6b6555b:


    "Il n'y a rien à trouver ici."


translate french changerPiece_d1fb860d:


    "Il n'y a plus rien à trouver ici."


translate french rubypown_0f0f27bd:


    ruby "Oh, c'est un Mastermind ?!"


translate french rubypown_3691690b:


    ruby "J'adore ça ! Laisse-moi faire !"


translate french rubypown_392c8349:


    dpense "Elle résout le Mastermind en deux secondes à peine..."





translate french masterepreuveep4_bbe3c7e7:


    "Epreuve terminée! Votre rang B.E.S.T va être mis à jour."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
