


translate french ep4s1c_6dad0253:


    d "Elle m'a demandé de l'attendre au coin..."


translate french ep4s1c_5856afbc:


    d "Hmm... Ça doit être elle."


translate french ep4s1c_f4a0b348:


    mad "Tu es prêt ? On y va ?"


translate french ep4s1c_f4ce41d5:


    d "Oui, allons-y."


translate french ep4s1c_5cf376db:


    dpense "Elle semble nerveuse..."


translate french ep4s1c_4a19f7fa:


    d "Tout va bien ? Tu sembles un peu... tendue."


translate french ep4s1c_93632179:


    mad "Mes parents ne sont pas faciles à impressionner. Surtout mon père."


translate french ep4s1c_a5086d58:


    d "Qu'entends-tu par impressionner ?"


translate french ep4s1c_b14eac55:


    mad "Disons simplement qu'il est exigeant. Trop exigeant."


translate french ep4s1c_00663f12:


    mad "Ce soir, ce serait mieux si tu ne parlais pas trop, surtout sur des sujets sensibles."


translate french ep4s1c_a436ea69:


    mad "Et quoi que tu fasses, ne le contredis pas. Même si tu n'es pas d'accord."


translate french ep4s1c_9093d13b:


    d "Compris, je resterai silencieux."


translate french ep4s1c_2355a152:


    mad "Merci... J'apprécie."


translate french ep4s1c_230d6202:


    mad "Nous sommes arrivés."


translate french ep4s1c_84714175:


    cassie "Maman !"


translate french ep4s1c_a21367c6:


    mad "Coucou, ma chérie."


translate french ep4s1c_f0f27eb0:


    mad "C'est presque l'heure d'aller au lit, non ?"


translate french ep4s1c_006d7bde:


    cassie "Oui, mais je voulais te faire un câlin d'abord !"


translate french ep4s1c_7f1f0a96:


    dpense "Drôle de tête..."


translate french ep4s1c_d5a2866d:


    cassie "C'est mon Monsieur Kitty !"


translate french ep4s1c_a647ab43:


    d "Oh ?"


translate french ep4s1c_fe4611ae:


    d "Bouh !"


translate french ep4s1c_84714175_1:


    cassie "Maman !"


translate french ep4s1c_73b051f2:


    mad "Quel idiot !"


translate french ep4s1c_7ef88f63:


    d "Hmm... Bonjour ?"



translate french ep4s1c_84714175_2:


    cassie "Maman !"


translate french ep4s1c_22cc38e4:


    mad "N'aie pas peur Cassie ! Il ne mord pas !"


translate french ep4s1c_c622716f:


    mad "Elle est timide..."


translate french ep4s1c_ed02c613:


    ted "Enfin arrivé, hein ?"


translate french ep4s1c_da8cfc7c:


    mad "Et toi ? Toujours là à ne rien faire comme d'habitude."


translate french ep4s1c_fdef9d73:


    ted "Moi, je suis là pour aider, contrairement à d'autres."


translate french ep4s1c_cfea4d5b:


    charles "Il a raison, Madison. Ton frère se sacrifie pour s'occuper de ta fille pendant que tu es occupée avec tes cours et le football."


translate french ep4s1c_48143dc6:


    mad "Je travaille dur pour réussir, Papa."


translate french ep4s1c_fdea709a:


    charles "Réussir ? Tu appelles ça réussir ? Regarde où tu en es."


translate french ep4s1c_d5dc8496:


    charles "Regarde les jumelles Orushi, Elizabeth et Sofia, et même Emerick ! Ils sont toujours en avance sur toi."


translate french ep4s1c_e23b0113:


    mad "Je fais de mon mieux, Papa."


translate french ep4s1c_65b21c17:


    charles "De ton mieux? Ca ne suffit pas. Tu es une Forrester !"


translate french ep4s1c_fb11c0f9:


    charles "Notre famille devrait être la plus puissante de cette ville, et tu en es loin."


translate french ep4s1c_43b093b0:


    charles "Pendant ce temps, ton frère est ici, se sacrifiant pour toi afin que tu puisses courir après des résultats qui ne sont même pas dignes de notre nom."


translate french ep4s1c_14e60a85:


    mad "Il ne se sacrifie pas du tout ! Il reste juste à la maison parce qu'il sait que tu vas lui donner ton empire !"


translate french ep4s1c_b4652781:


    mad "Qu'est-ce qu'il a fait ?! Il n'a postulé ni à l'université ni à un emploi, rien !"


translate french ep4s1c_70ed9669:


    charles "Madison, regarde-toi. Tu es une déception par rapport à ce que j'attends de toi."


translate french ep4s1c_1f24c8da:


    charles "Et ton frère tient cette famille ensemble, sans reconnaissance. Tu es loin d'être où tu devrais être."


translate french ep4s1c_01762278:


    mad "Tu crois que je ne ressens pas ça ? Le poids d'être une Forrester, les attentes, les jugements constants ?"


translate french ep4s1c_2e303027:


    mad "Tu ne me comprendras jamais. Je fais tout ce que je peux, et ce n'est jamais assez pour toi."


translate french ep4s1c_5af23123:


    mad "Je vais me changer et mettre Cassie au lit... [name], tu peux rester ici jusqu'à mon retour."


translate french ep4s1c_276d651a:


    d "Oh ? D'accord..."


translate french ep4s1c_3f32141d:


    dpense "Wow, la tension ici est incroyable."


translate french ep4s1c_401cb507:


    dpense "Avec un père comme ça et un frère qui provoque constamment, pas étonnant que Madison soit toujours sur les nerfs."


translate french ep4s1c_b51a0db4:


    dpense "Comment je peux l'aider dans une situation pareille ?"


translate french ep4s1c_fa0b69c6:


    ji "Enchantée de faire ta connaissance... [name] ?"


translate french ep4s1c_a647ab43_1:


    d "Oh ?"


translate french ep4s1c_f4cad055:


    d "Oui, c'est moi. C'est un plaisir de vous rencontrer..."


translate french ep4s1c_cb378405:


    d "Vous devez être la... sœur de Madison ?"


translate french ep4s1c_d63a0bdf:


    ji "Oh oh oh ! Quel charmeur ! Malheureusement, non..."


translate french ep4s1c_af8697e3:


    carmen "Je suis sa mère... Mais tu peux m'appeler Carmen."


translate french ep4s1c_c36276f3:


    carmen "Il a même de bonnes manières... intrigant."


translate french ep4s1c_0f7ade2f:


    carmen "Le dîner sera prêt dans quelques minutes."


translate french ep4s1c_df8b1672:


    charles "Alors, dis-moi, [name]. D'où viens-tu exactement ? Quelle est ta famille ?"


translate french ep4s1c_dde4c475:


    dpense "Pourquoi ai-je l'impression que cette question va mal finir..."


translate french ep4s1c_566bdb5d:


    d "Euh... Je viens d'une famille normale. Rien de... remarquable."


translate french ep4s1c_bdd50929:


    charles "Normale, hein ?"


translate french ep4s1c_f465d5bd:


    charles "Et que fais-tu ? Des compétences, de grands projets ?"


translate french ep4s1c_c9cbe71f:


    d "Je suis encore en train de réfléchir... Je n'ai pas encore de plans concrets."


translate french ep4s1c_9117d419:


    charles "Toujours en train de réfléchir, hein ?"


translate french ep4s1c_7b058e25:


    charles "Pas d'antécédents remarquables, pas de plans solides, et pourtant tu es avec ma fille ?"


translate french ep4s1c_e94675da:


    mad "Papa, ce n'est pas le moment."


translate french ep4s1c_fad03ada:


    d "?"


translate french ep4s1c_9364193b:


    charles "Madison, tu ne fréquentes pas des gens sans avenir."


translate french ep4s1c_fa7f34d3:


    charles "Nous sommes des Forrester, et nous ne nous abaissons pas à ce niveau."


translate french ep4s1c_dfdc475a:


    mad "C'est ridicule. Il est ici avec moi, et cela devrait suffire."


translate french ep4s1c_2418351b:


    charles "Non, ça ne suffit pas. Ma fille ne traînera pas avec un inconnu."


translate french ep4s1c_298da46a:


    dpense "Je savais que ça allait mal tourner..."


translate french ep4s1c_d7ddfd07:


    charles "Tu vois ? C'est exactement ce que je disais."


translate french ep4s1c_b51e7b23:


    charles "Elle traîne avec des gens sans ambition, et c'est pour ça qu'elle est toujours en retard par rapport aux autres."


translate french ep4s1c_be095a14:


    charles "Dis-moi, [name], est-ce que j'ai tort ?"


translate french ep4s1c_9b75d279:


    d "Peut-être..."


translate french ep4s1c_ab508016:


    dpense "Elle m'a dit de rester agréable, mais je déteste dire ça."


translate french ep4s1c_e80c2f3b:


    mad "Merci pour le dîner, mais je ne peux pas rester dans cette atmosphère."


translate french ep4s1c_4a253169:


    mad "J'en ai assez. On s'en va."


translate french ep4s1c_3f42795c:


    mad "Désolée maman, mais je ne supporte pas ça ce soir !"


translate french ep4s1c_df44d9ad:


    carmen "Mais... J'ai déjà préparé le poulet !"


translate french ep4s1c_27c40301:


    carmen "Charles !"


translate french ep4s1c_e0d01298:


    charles "Quoi ?"


translate french ep4s1c_339cc60f:


    d "Non. Vous avez tort."


translate french ep4s1c_ad367550:


    d "Madison travaille incroyablement dur. Elle mixe ses études, le football et s'occupe de sa fille."


translate french ep4s1c_c3273228:


    d "C'est une femme forte, et elle mérite beaucoup plus de respect."


translate french ep4s1c_64cef363:


    mad "Qu'est-ce que tu..."


translate french ep4s1c_b0ca796d:


    d "Vous ne voyez pas tout ce qu'elle fait pour réussir, et tout ce qu'elle sacrifie."


translate french ep4s1c_95ea10a0:


    d "Elle donne tout, et ce n'est pas juste de la rabaisser comme ça."


translate french ep4s1c_02bb2db2:


    charles "Comment oses-tu me parler ainsi dans ma propre maison ?!"


translate french ep4s1c_bd9f2cf9:


    carmen "Chéri, s'il te plaît, ce n'est pas le moment de te mettre en colère. Ils sont jeunes..."


translate french ep4s1c_80325eb3:


    charles "Assez ! Je ne veux plus entendre ça. Vous deux, dehors. Maintenant !" with hpunch


translate french ep4s1c_9f370207:


    mad "Oui, oui. On s'en va."


translate french ep4s1c_3f42795c_1:


    mad "Désolée maman, mais je ne supporte pas ça ce soir !"


translate french ep4s1c_df44d9ad_1:


    carmen "Mais... J'ai déjà préparé le poulet !"


translate french ep4s1c_27c40301_1:


    carmen "Charles !"


translate french ep4s1c_e0d01298_1:


    charles "Quoi ?"


translate french end_dinner_departure_bec8b557:


    d "On aurait dû au moins manger le poulet, non ?"


translate french end_dinner_departure_ed6750c3:


    d "Ou au moins un doggy-bag ?"


translate french end_dinner_departure_02ddc437:


    mad "Monte dans la voiture..."


translate french end_dinner_departure_828c1428:


    mad "Merci d'être venu ce soir. Je sais que ce n'était pas facile."


translate french end_dinner_departure_2255152a:


    d "Ce n'est rien. Je suis juste désolé que les choses se soient passées ainsi."


translate french end_dinner_departure_7d7004a3:


    mad "Tu as fait ce que je t'ai demandé. C'est tout ce que je pouvais espérer."


translate french end_dinner_departure_6691cdab:


    dpense "Pourquoi ai-je l'impression que quelque chose reste en suspens ? Comme s'il y avait tant de choses non dites entre nous..."


translate french end_dinner_departure_c6150c87:


    d "Ça va... toi ?"


translate french end_dinner_departure_b6b5e82c:


    mad "Je vais bien. Juste... Fatiguée."


translate french end_dinner_departure_df35f693:


    dpense "Fatiguée... Est-ce vraiment tout ?"


translate french end_dinner_departure_37e64b70:


    dpense "..."


translate french end_dinner_departure_565e71b6:


    d "Ta mère est jeune, non ?"


translate french end_dinner_departure_e4b71768:


    d "Je veux dire... Ton père semble beaucoup plus âgé qu'elle ?"


translate french end_dinner_departure_edbe80d3:


    mad "Oui. Ils se sont rencontrés dans un hôtel où ma mère travaillait pour payer ses études. Elle avait dix-huit ans."


translate french end_dinner_departure_03cdb1b6:


    mad "Ils ont commencé une relation et elle est tombée enceinte."


translate french end_dinner_departure_4801c24b:


    mad "Pour éviter les scandales... et parce que ma mère est belle, mon père l'a épousée."


translate french end_dinner_departure_58c8c435:


    mad "C'est pour ça qu'il m'a reproché d'avoir eu un enfant jeune."


translate french end_dinner_departure_1767b585:


    mad "Il ne voulait pas que je fasse les mêmes erreurs que lui et ma mère..."


translate french end_dinner_departure_a80c510e:


    d "Oh. Je comprends..."


translate french end_dinner_departure_7e53ce03:


    mad "On est arrivés."


translate french end_dinner_departure_1590ce56:


    d "Madison... à propos de ce soir..."


translate french end_dinner_departure_33de70ff:


    mad "Non. C'est fini. Oublions ça."


translate french end_dinner_departure_f4ed03c1:


    mad "Merci d'avoir été compréhensif. Bonne nuit."


translate french end_dinner_departure_c7ba9543:


    d "Bonne nuit, Madison."


translate french end_dinner_departure_d92c02fb:


    d "Tu sais que tu n'as pas à tout porter toute seule, hein ?"


translate french end_dinner_departure_24a5a86e:


    mad "Je sais."


translate french end_dinner_departure_80070976:


    mad "Rentre chez toi."


translate french end_dinner_departure_e3023bd7:


    dpense "Il y a quelque chose de plus. Je le sens. Mais pourquoi ne veut-elle pas me laisser l'aider ?"


translate french end_dinner_exclusion_bec8b557:


    d "On aurait dû manger du poulet avant ! Non ?"


translate french end_dinner_exclusion_ed6750c3:


    d "Ou au moins un doggy-bag ?"


translate french end_dinner_exclusion_8d1dace7:


    mad "Je n'en reviens pas ! Mon père est incroyable !"


translate french end_dinner_exclusion_9a3e72c3:


    d "Madison, je suis désolé, je pensais juste..."


translate french end_dinner_exclusion_789f9dad:


    mad "Tu pensais quoi ?! Je t'ai dit de ne pas le contredire ! Pourquoi ne peux-tu jamais simplement m'écouter ?"


translate french end_dinner_exclusion_842f20c1:


    mad "Tu dois toujours faire les choses à ta manière, n'est-ce pas ? Pourquoi tu n'écoutes jamais ?"


translate french end_dinner_exclusion_3114f6e9:


    mad "Pourquoi tu vas toujours à l'encontre de ce que je dis ?"


translate french end_dinner_exclusion_cefb8915:


    mad "Pourquoi... Pourquoi tu fais toujours ça... ?"


translate french end_dinner_exclusion_79ddb1a3:


    mad "Tu... Avec Red..."


translate french end_dinner_exclusion_b186eaf3:


    mad "Monte juste dans la voiture."


translate french end_dinner_exclusion_6691cdab:


    dpense "Pourquoi ai-je l'impression que quelque chose reste en suspens ? Comme s'il y avait tant de choses non dites entre nous..."


translate french end_dinner_exclusion_c6150c87:


    d "Ça va... toi ?"


translate french end_dinner_exclusion_b6b5e82c:


    mad "Je vais bien. Juste... Fatiguée."


translate french end_dinner_exclusion_df35f693:


    dpense "Fatiguée... Est-ce vraiment tout ?"


translate french end_dinner_exclusion_37e64b70:


    dpense "..."


translate french end_dinner_exclusion_565e71b6:


    d "Ta mère est jeune, non ?"


translate french end_dinner_exclusion_e4b71768:


    d "Je veux dire... Ton père semble beaucoup plus âgé qu'elle ?"


translate french end_dinner_exclusion_edbe80d3:


    mad "Oui. Ils se sont rencontrés dans un hôtel où ma mère travaillait pour payer ses études. Elle avait dix-huit ans."


translate french end_dinner_exclusion_03cdb1b6:


    mad "Ils ont commencé une relation et elle est tombée enceinte."


translate french end_dinner_exclusion_4801c24b:


    mad "Pour éviter les scandales... et parce que ma mère est belle, mon père l'a épousée."


translate french end_dinner_exclusion_58c8c435:


    mad "C'est pour ça qu'il m'a reproché d'avoir eu un enfant jeune."


translate french end_dinner_exclusion_1767b585:


    mad "Il ne voulait pas que je fasse les mêmes erreurs que lui et ma mère..."


translate french end_dinner_exclusion_a80c510e:


    d "Oh. Je comprends..."


translate french end_dinner_exclusion_7e53ce03:


    mad "On est arrivés."


translate french end_dinner_exclusion_e1fe360c:


    d "Madison... à propos de ce soir..."


translate french end_dinner_exclusion_33de70ff:


    mad "Non. C'est fini. Oublions ça."


translate french end_dinner_exclusion_f4ed03c1:


    mad "Merci de ta compréhension. Bonne nuit."


translate french end_dinner_exclusion_c7ba9543:


    d "Bonne nuit, Madison."


translate french end_dinner_exclusion_d92c02fb:


    d "Tu sais que tu n'as pas à tout porter toute seule, hein ?"


translate french end_dinner_exclusion_24a5a86e:


    mad "Je sais."


translate french end_dinner_exclusion_80070976:


    mad "Rentre chez toi."


translate french madicarep4_d8f6e37a:


    mad "Pourquoi es-tu..."


translate french madicarep4_69f7a537:


    mad "Pourquoi rends-tu tout si compliqué ?"


translate french madicarep4_cecb0a3c:


    mad "Allons-y."


translate french madicarep4_f3931eec:


    d "Hum... Où ça ?"


translate french madicarep4_e1fca818:


    mad "Tu verras."


translate french madicarep4_b606edb1:


    d "Où allons-nous ?"


translate french madicarep4_15b9b540:


    dpense "Qu'est ce qu'elle fait ?"


translate french madicarep4_53a281cf:


    dpense "Nous sommes... nulle part..."


translate french madicarep4_328d9c7f:


    d "Alors ? Où sommes..."


translate french madicarep4_8777e1e5:


    mad "Pour une fois dans ta vie, tais-toi et fais ce qu'on te dit." with hpunch


translate french madicarep4_21ae9489:


    dpense "Sérieux ?"


translate french madicarep4_973d116c:


    dpense "Je n'arrive même pas à réfléchir correctement en ce moment..."


translate french madicarep4_9c7e17ef:


    dpense "Elle a besoin d'affection."


translate french madicarep4_181bd2fb:


    dpense "Elle a besoin d'amour."


translate french madicarep4_3c1a2941:


    dpense "Elle a besoin de..."


translate french madicarep4_722429d9:


    dpense "Moi."


translate french madicarep4_16408cd2:


    mad "Ahhhh..."


translate french madicarep4_c2706398:


    dpense "Je te donnerai tout, Madison."


translate french madicarep4_30c998e5:


    mad "Plus...."


translate french madicarep4_482bce7e:


    dpense "Tu seras traitée comme une reine, comme tu le mérites."


translate french madicarep4_570d1a88:


    mad "Plus fort !"


translate french madicarep4_e41549ac:


    mad "Ahh... Comme ça... Juste comme ça..."


translate french madicarep4_9c9ea9b2:


    mad "Ahhh... Ahhh...Ahhh"


translate french madicarep4_9009007c:


    mad "PUUUUUUUUUUUUUUUUUUUUUUTAIN"


translate french madicarep4_1e64df45:


    mad "Attends... Laisse-moi me retourner..."


translate french madicarep4_8fa495fa:


    d "Tu es tellement magnifique."


translate french madicarep4_b17db2f4:


    dpense "Si l'amour était un temple..."


translate french madicarep4_9b7ac599:


    dpense "Tu serais ma religion !"


translate french madicarep4_7dc5d9ef:


    d "Tu as... ?"


translate french madicarep4_2b13f232:


    mad "Oui... Et toi ?"


translate french madicarep4_3baac7b7:


    d "Hum... Non..."


translate french madicarep4_03af6cc7:


    mad "D'accord... Je t'en dois une."


translate french madicarep4_6029c909:


    dpense "Compte là-dessus!"


translate french madicarep4_6f1f98c0:


    mad "Tu ne seras pas déçu."


translate french carmadi_9073db10:


    dpense "Et la revoilà silencieuse..."


translate french carmadi_b7c92e7a:


    d "Madison, parle-moi. Tu ne peux pas continuer comme ça. Qu'est-ce qui se passe vraiment ?"


translate french carmadi_7968a21e:


    mad "Je suis une Forrester. Toi et moi... On ne peut pas faire ça. Ce n'est pas censé arriver."


translate french carmadi_490f3c49:


    d "Qu'est-ce que ça veut dire ? Tu continues de me repousser, mais pourquoi ?"


translate french carmadi_e4c53d96:


    mad "J'ai des responsabilités, un nom à préserver. Toi... Tu n'y corresponds pas. Tu ne correspondras jamais."


translate french carmadi_16ef6dd4:


    d "Madison, ce n'est pas juste."


translate french carmadi_2e133450:


    mad "La vie n'est pas juste. Surtout pour les gens comme moi."


translate french carmadi_d6eb2433:


    mad "On ne peut pas continuer comme ça."


translate french carmadi_b93e5c76:


    mad "Ça doit s'arrêter."


translate french carmadi_d5cb0d6f:


    dpense "Forrester... C'est vraiment ça qui nous sépare ? Ou bien est-elle simplement effrayée ?"


translate french carmadi_565e71b6:


    d "Ta mère est jeune, non ?"


translate french carmadi_e4b71768:


    d "Je veux dire... Ton père semble beaucoup plus âgé qu'elle, non ?"


translate french carmadi_7ac5d7ec:


    mad "Oui. Ils se sont rencontrés dans un hôtel pendant que maman faisait ses études, elle avait 18 ans."


translate french carmadi_0afeaecb:


    mad "Ils ont commencé une relation et elle est tombée enceinte."


translate french carmadi_a1079f88:


    mad "Pour éviter les scandales... Et parce que maman est belle, il l'a épousée."


translate french carmadi_1e47bb42:


    mad "C'est pour ça qu'il me reproche d'avoir eu un enfant jeune."


translate french carmadi_eae292b4:


    mad "Il ne voulait pas que je fasse les mêmes erreurs que lui et elle ont faites..."


translate french carmadi_ba9103a5:


    d "Oh... Je comprends..."


translate french carmadi_2083bc62:


    mad "On est arrivés. Descends."


translate french carmadi_7bcc50f4:


    d "D'accord..."


translate french carmadi_ce96d8e7:


    dpense "Et elle est s'en va."


translate french carmadi_60b769a1:


    dpense "Je ne la comprends pas du tout..."


translate french carmadi_42642c81:


    dpense "Qu'est-ce qui lui fait si peur ?"

translate french strings:


    old "Boo!"
    new "Bouh!"


    old "Hello?"
    new "Bonjour?"


    old "Agree with him"
    new "Etre d'accord avec lui"


    old "Stand up to the father"
    new "Défendre Madison"




translate french madicarep4_0ae9bcd0:


    ""



translate french strings:


    old "Agree with him[TEMP1!t]"
    new "Etre d'accord[TEMP1!t]"


    old "Stand up to the father[TEMP2!t]"
    new "Défendre Madison[TEMP2!t]"




translate french madicarep4_06f80c70:


    d "HUmmm... NOn, mais je suis pas loin."


translate french madicarep4_3192ed71:


    mad "OKay... Laisse-moi faire."


translate french madicarep4_48ad44f5:


    mad "[name]..."


translate french madicarep4_362c6bb7:


    d "Madison..."


translate french madicarep4_c5fd0efd:


    mad "Je..."


translate french madicarep4_61e0dcea:


    mad "HUMMMMMM"


translate french madicarep4_c96dfce7:


    d "Madison, je..."


translate french madicarep4_8ed3e38a:


    mad "Vas-y! Fais-le!"


translate french madicarep4_719c3868:


    mad "AHHHH!"


translate french madicarep4_60aa49f8:


    d "Madi... JE... AAAAHHH!"


translate french madicarep4_dd056acf:


    mad "Je veux te sentir..."


translate french madicarep4_b1d8ec0d:


    mad "TOIIIIIIIIIII !"


translate french madicarep4_c5fd0efd_1:


    mad "Je..."


translate french madicarep4_e48aa4b0:


    mad "T'es pas croyable!"


translate french madicarep4_e3b20b7b:


    d "Pourquoi?"


translate french madicarep4_f0151273:


    mad "A chaque fois j'essaye de mettre des barrières'..."


translate french madicarep4_81742674:


    mad "Et toi..."


translate french madicarep4_d50aab69:


    mad "Merci."


translate french madicarep4_3d140dca:


    d "De rien."


translate french carmadi_30c3b5c1:


    dpense "Il faut que je change de sujet le temps qu'elle se calme."


translate french carmadi_5726cc40:


    d "Madison, tu sais que je suis là pour toi."


translate french carmadi_fd221f30:


    d "Tu n'es pas seule."


translate french carmadi_24a5a86e:


    mad "Je sais."


translate french carmadi_1e49c06a:


    dpense "Je n'abandonnerais pas."




translate french ep4s1c_785af72e:


    mad "Tu te fous de moi? T'as vu l'heure?"


translate french ep4s1c_79b7b2d0:


    d "Désolé, j'étais avec Gabrielle et..."


translate french ep4s1c_33f79b07:


    mad "Je m'en fous!" with hpunch


translate french ep4s1c_46cf0602:


    mad "Des fois je me demande si tu le fais pas exprès!"


translate french ep4s1c_fe54f4ad:


    d "Non, mais..."


translate french ep4s1c_29bea964:


    mad "T'es prêt? On peut y aller?" with hpunch


translate french ep4s1c_16848415:


    dpense "Elle me paraît nerveuse... Enfin, un peu plus que d'habitude..."




translate french ep4s1c_a0d653f4:


    charles "Regarde les jumelles Da Fonseca ou me^me Emerick! Ils sont toujours devant toi!"


translate french madicarep4_2acc949b:


    d "Tu as...?"


translate french madicarep4_10d22e60:


    mad "HUMMMMMMM."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
