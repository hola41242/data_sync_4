


translate french ep4s1d_3151755a:


    "I am Malenia, blade of Miquella..."


translate french ep4s1d_3151755a_1:


    "I am Malenia, blade of Miquella..."


translate french ep4s1d_3dd2e30c:


    d "Ouais, ouais, ouais..."


translate french ep4s1d_3151755a_2:


    "I am Malenia, blade of Miquella..."


translate french ep4s1d_43f42653:


    "I am..."


translate french ep4s1d_7e31e439:


    d "Va te faire foutre !"


translate french ep4s1d_88827fe4:


    dpense "Il me faut quelque chose pour me calmer..."


translate french ep4s1d_06a6996e:


    dpense "Je devrais aller voir ce que fait Ruby."


translate french ep4s1d_cefad54e:


    ruby "Non ! Non ! Non !"


translate french ep4s1d_e8cfd3f7:


    ruby "Argh !!!"


translate french ep4s1d_ca2c7e19:


    ruby "Donc tu es le genre à prendre le micro juste pour m'engueuler."


translate french ep4s1d_1c93a4f7:


    ruby "Tu es la personne la plus inutile de notre équipe !"


translate french ep4s1d_3ffb0504:


    ruby "Je n'ai jamais vu quelqu'un rage-quit autant que toi !"


translate french ep4s1d_96c7a6f6:


    ruby "Tu devrais peut-être retourner jouer à Team Fortress 2 !"


translate french ep4s1d_0df3fca5:


    ruby "Raaaaaah"


translate french ep4s1d_8e2bcb51:


    ruby "Et si tu aimes tant Mercy, pourquoi tu ne l'épouses pas ?"


translate french ep4s1d_36ead268:


    dpense "Bon... Ce n'est pas le bon moment..."


translate french ep4s1d_8ad52066:


    dpense "Je vais la laisser tranquille."

translate french strings:


    old "After some training and some homework..."
    new "Après un peu d'entraînement et quelques révisions..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
