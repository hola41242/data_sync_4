


translate french postepreuvep4_d95c0c5f:


    d "Ouais !!!! Je l'ai fait ! Je suis le meilleur !"


translate french postepreuvep4_2b9a1516:


    ruby "Haha ! Je le savais ! J'ai bien fait de croire en toi dès le départ !"


translate french postepreuvep4_ebb64208:


    ruby "Mon instinct ne me trompe jamais !"


translate french postepreuvep4_914d232a:


    d "Merci, Ruby !"


translate french postepreuvep4_b502f042:


    grace "Félicitations !"


translate french postepreuvep4_85e4ae4e:


    mad "Ouais. Bravo."


translate french postepreuvep4_968df1dc:


    d "Ne fais pas cette tête, Madison ! Tu auras ta chance dans les prochaines épreuves !"


translate french postepreuvep4_76bb8453:


    mad "Oh, ça, tu peux en être sûr."


translate french postepreuvep4_f34661f2:


    mad "Personne ne prendra cette place à ma place !"


translate french postepreuvep4_4b66f82a:


    d "Tu devras d'abord me battre !"


translate french postepreuvep4_49fdce4f:


    mad "Pfff..."


translate french postepreuvep4_fae32503:


    julia "Ne t'inquiète pas. Elle n'aime pas perdre, mais ça lui passera."


translate french postepreuvep4_0af351f3:


    ruby "Ouais, et je pense qu'au fond, elle est contente !"


translate french postepreuvep4_2c3a63c7:


    d "Qu'est-ce que tu veux dire ?"


translate french postepreuvep4_4966be78:


    ruby "Eh bien, tu as battu Emerick ! Et rien ne la rend plus heureuse que de le voir perdre."


translate french postepreuvep4_a06e5c1b:


    emerick "Allez, qui est le meilleur ?"


translate french postepreuvep4_ff9aa7c2:


    mad "Merde ! Toujours à te la jouer, hein ?"


translate french postepreuvep4_a0b9bdc0:


    ruby "Eh bien, pour être honnête, il est plutôt fort."


translate french postepreuvep4_59401327:


    mad "Ruby ! Tu es censée être de mon côté !" with hpunch


translate french postepreuvep4_ca7f4ebd:


    ruby "Je dis juste ça comme ça ! Pas la peine de me frapper !"


translate french postepreuvep4_8c3a0b8e:


    mad "Ugh, peu importe. La prochaine fois, je l'écrase !"


translate french postepreuvep4_3c809472:


    d "J'ai hâte de voir ça !"


translate french postepreuvep4_3548917f:


    mad "Enfin !" with hpunch


translate french postepreuvep4_2307991b:


    ruby "Quoi ?"


translate french postepreuvep4_11760e79:


    mad "Je suis numéro un !"


translate french postepreuvep4_c2d13269:


    mad "Haha !"


translate french postepreuvep4_efcd65ff:


    mad "Je suis tellement heureuse !"


translate french postepreuvep4_b6d09f2c:


    d "Félicitations !"


translate french postepreuvep4_88b285a4:


    mad "Merci !"


translate french postepreuvep4_fe9c9277:


    mad "Ce crétin doit être dévasté d'avoir perdu sa couronne !"


translate french postepreuvep4_8a5b80e4:


    ruby "Maintenant, il te reste juste à la garder !"


translate french postepreuvep4_f5b25916:


    mad "Oh, c'est prévu !"


translate french postepreuvep4_2c4dd3c6:


    dpense "Hmm... Il va y avoir un problème, cependant."


translate french postepreuvep4_8a15ed11:


    dpense "Je vais devoir gagner à un moment donné."


translate french postepreuvep4_11e68000:


    dpense "Quand ce jour arrivera, Madison, nous serons rivaux."


translate french finpart1ep4_c9b7daef:


    sofia "On l'a fait !"


translate french finpart1ep4_c804b774:


    d "Ahah ouais !"


translate french finpart1ep4_41790409:


    julia "Bravo tout le monde !"


translate french finpart1ep4_5360cfd9:


    grace "En tous cas, vous vous êtes tous bien battus ! On est encore tous dans la course."


translate french finpart1ep4_46f6ea63:


    grace "Et maintenant, il ne reste plus que 20 d'entre nous !"


translate french finpart1ep4_88510f87:


    ruby "La fin est proche !"


translate french finpart1ep4_d3f9eca3:


    julia "Ça m'a épuisé. Je vais me reposer."


translate french finpart1ep4_7e5c2c3c:


    ruby "Ouais, pareil ici. Et on a encore le match de demain."


translate french finpart1ep4_3d33b78b:


    sofia "Tu veux venir ce soir ?"


translate french finpart1ep4_a821b5e8:


    d "Où ça ?"


translate french finpart1ep4_a2d67328:


    sofia "Chez moi."


translate french finpart1ep4_0d83ea1f:


    d "Oh ? Euh..."


translate french finpart1ep4_3d0cbac8:


    d "Oui, absolument !"


translate french finpart1ep4_da93614d:


    sofia "Super ! Passe vers 20h."


translate french finpart1ep4_daa9b8fd:


    sofia "Euh... Tu sais où on habite ?"


translate french finpart1ep4_1e98cad6:


    d "Dans le quartier de Madison, c'est ça ?"


translate french finpart1ep4_108c8239:


    sofia "Ouais, juste derrière."


translate french finpart1ep4_61a478ae:


    d "Je trouverai."


translate french finpart1ep4_5b1a7f4a:


    sofia "Envoie-moi un message quand tu seras près, et je viendrai te chercher."


translate french finpart1ep4_5a2f6599:


    d "Et ta sœur ?"


translate french finpart1ep4_efb9908d:


    sofia "Quoi, elle ?"


translate french finpart1ep4_e3d67dfa:


    d "Eh bien... Elle ne dira rien ?"


translate french finpart1ep4_94e6f7b8:


    sofia "Elle n'a rien à dire."


translate french finpart1ep4_7911cccb:


    sofia "Et honnêtement, je pense qu'elle sera contente que tu sois avec moi."


translate french finpart1ep4_dcc8fdd9:


    d "Pourquoi ça ?"


translate french finpart1ep4_29c56406:


    sofia "Même si nous sommes différentes, nous sommes quand même jumelles !"


translate french finpart1ep4_d7a76cc2:


    sofia "Alors, nous sommes... connectées !"


translate french finpart1ep4_294b570e:


    sofia "Ce qui signifie que je pense qu'elle veut ce qu'il y a de mieux pour moi."


translate french finpart1ep4_7e8a8360:


    sofia "Et avec toi..."


translate french finpart1ep4_f6caeca9:


    sofia "Je me sens bien."


translate french finpart1ep4_cfced47e:


    sofia "Tu sais, Elisabeth ne le dira peut-être pas, mais elle tient à moi."


translate french finpart1ep4_00b9550f:


    d "Vraiment ? Elle ne le montre pas beaucoup."


translate french finpart1ep4_a9802b78:


    sofia "Oui, ce n’est pas son genre de l’exprimer ouvertement, mais je le ressens. Connexion jumelle, tu vois ?"


translate french finpart1ep4_02a44635:


    d "Ça doit être sympa d’avoir ça."


translate french finpart1ep4_e22c7d25:


    sofia "Oui. Et en ce moment, j’ai l’impression que tu fais partie de cette connexion aussi."


translate french finpart1ep4_dcadd612:


    mad "hum hum !" with vpunch


translate french finpart1ep4_bd15cdba:


    dpense "Oh..."


translate french finpart1ep4_c152dad6:


    d "D’accord alors, c’est réglé. 20h chez toi !"


translate french finpart1ep4_34e9aab5:


    sofia "Parfait !"


translate french finpart1ep4_025b7b74:


    d "Désolé, mais j’ai déjà des plans cet après-midi."


translate french finpart1ep4_e5596a13:


    d "Et avec le match de demain, je pense que je devrais rester en pleine forme."


translate french finpart1ep4_6dbfad43:


    sofia "Oh ? D'accord..."


translate french finpart1ep4_931ca24a:


    sofia "Eh bien, à plus tard alors ?"


translate french finpart1ep4_4fdbb733:


    d "Ouais."


translate french finpart1ep4_76c93456:


    beth "Bien joué, Frenchie."


translate french finpart1ep4_f72f2645:


    d "Tu n’étais pas mal toi non plus."


translate french finpart1ep4_dcb12307:


    d "Mais je me demande encore où tu obtiens toutes tes infos..."


translate french finpart1ep4_9fb1fca3:


    d "Tu sembles tout savoir avant tout le monde."


translate french finpart1ep4_05cb055d:


    beth "Oh, c’est simple."


translate french finpart1ep4_8bf45f55:


    beth "J’ai des trucs compromettants sur un des membres du staff des Orushi."


translate french finpart1ep4_c1b7f1d3:


    beth "Alors soit il me donne les infos qu’il a sur les défis qu’ils préparent..."


translate french finpart1ep4_27c53a50:


    beth "Soit je montre à sa femme ce qu’il fait avec la mère d’Emerick."


translate french finpart1ep4_30170964:


    d "La mère d’Emerick ?"


translate french finpart1ep4_ea5c16fc:


    beth "Ouais. Elle sort beaucoup et se lâche quand elle est en bonne compagnie."


translate french finpart1ep4_1d9c4eea:


    d "Euh... Il est au courant ?"


translate french finpart1ep4_eaa48dbb:


    beth "Qui ? Emerick ?"


translate french finpart1ep4_4fdbb733_1:


    d "Ouais."


translate french finpart1ep4_328d8e67:


    beth "Non. Ce gars ne voit pas plus loin que le bout de son nez."


translate french finpart1ep4_a3ecdb69:


    beth "On ne s’attend pas à ce qu’il remarque quoi que ce soit autour de lui."


translate french finpart1ep4_10cc8e1f:


    d "Mais ce n’est pas ton allié ?"


translate french finpart1ep4_0acb728c:


    beth "Emerick ? Un allié ?"


translate french finpart1ep4_619c193e:


    beth "C'est un toutou."


translate french finpart1ep4_b083584a:


    beth "Je le garde dans les parages et je le laisse faire ses petites combines pour garder les Orushi de mon côté."


translate french finpart1ep4_62d2c152:


    d "Oh ? Et Kira ?"


translate french finpart1ep4_b1596419:


    beth "Non... C'est un tout autre niveau. On évite de se croiser."


translate french finpart1ep4_87c7b85c:


    dpense "Intéressant..."


translate french finpart1ep4_5e031470:


    beth "Bref. Voici mon numéro pour qu’on puisse communiquer plus facilement."


translate french finpart1ep4_a1c55f8b:


    d "Waouh ! La grande Elisabeth me donne son numéro !"


translate french finpart1ep4_c8b3625d:


    d "Je devrais me sentir honoré ?"


translate french finpart1ep4_e2aa9109:


    beth "Ne me fais pas regretter, [name]."


translate french finpart1ep4_c684e4b2:


    d "D'accord, je plaisante."


translate french finpart1ep4_8f1a7e3e:


    beth "Envoie-moi un message ce soir."


translate french finpart1ep4_85454a22:


    d "Euh... Si tu veux."


translate french finpart1ep4_021335d3:


    grace "Tu veux passer du temps avec moi cet après-midi ?"


translate french finpart1ep4_e5da28cf:


    grace "Je serai seule à la maison jusqu’à ce que ma mère rentre."


translate french finpart1ep4_7a1a5887:


    d "Oui, bien sûr !"


translate french finpart1ep4_7a5a0376:


    grace "Super ! Rentrons ensemble alors !"


translate french finpart1ep4_aa6a11f5:


    d "Je pense que je vais m’entraîner un peu pour demain."


translate french finpart1ep4_15f30b71:


    grace "Oui, je comprends."


translate french finpart1ep4_e6682e66:


    grace "Je te verrai demain alors."


translate french finpart1ep4_3e02fdf4:


    d "Parfait."


translate french finpart1ep4_c2d0abb3:


    d "Bon, à demain les filles !"


translate french finpart1ep4_5fb753fe:


    ruby "À demain !"


translate french finpart1ep4_739b751a:


    julia "À demain !"

translate french strings:


    old "Of course!"
    new "Bien sûr !"


    old "I’ve got other things to do."
    new "J’ai d’autres choses à faire."


    old "No, thanks."
    new "Non, merci."



translate french strings:


    old "Of course![TEMP1!t]"
    new "Evidemment![TEMP1!t]"




translate french finpart1ep4_510a6c8f:


    mad "*Se râcle la gorge* Hum! Hum!" with vpunch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
