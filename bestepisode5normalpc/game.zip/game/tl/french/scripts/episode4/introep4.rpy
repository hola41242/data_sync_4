


translate french introep4_d12fc746:


    ruby "Hey ! Coucou !"


translate french introep4_3f6be409:


    ruby "Alors que la compétition s'intensifie et qu'il ne reste plus que 40 participants, revenons sur le parcours incroyable de notre héros : [name] !"


translate french introep4_b9184002:


    ruby "Quel parcours jusqu'à présent, n'est-ce pas ? Depuis le premier parcours d'obstacles, où [name] et [chosen] ont fait preuve d'un vrai courage, jusqu'à la deuxième épreuve réussie avec un score de [score] sur 10 !"


translate french introep4_520d55a2:


    ruby "Vraiment impressionnant, [name] ! Tu as fait du bon travail pour être parmi les quarante derniers participants, à la [Rank]ème position."


translate french introep4_b7440b24:


    ruby "Oh, et n'oublions pas ce moment avec Red dans les vestiaires... Les étincelles fusaient ! Ces deux-là ont définitivement une connexion."


translate french introep4_6507d017:


    ruby "Et qui pourrait oublier cette scène torride sous la douche avec Madison ? Les choses deviennent intéressantes par ici..."


translate french introep4_2bfaee56:


    ruby "Et puis il y a Blue... Explorer de nouvelles profondeurs ensemble, hein ? Ces moments étaient inoubliables."


translate french introep4_51f6fdaa:


    ruby "Et Grace... Quelle nuit c'était. Cela s'est terminé sur une note si positive avec elle."


translate french introep4_636ca528:


    ruby "Mais maintenant, les enjeux sont plus élevés que jamais. La prochaine épreuve est imminente, et c'est contre l'équipe de Steven !"


translate french introep4_92f583ba:


    ruby "Je ne sais pas pour vous, mais je suis surexcitée rien qu'en y pensant ! Ce match va être épique !"


translate french introep4_03936d73:


    ruby "Mais avant d'y arriver, notre héros doit prendre des décisions importantes. Que va t-il faire maintenant ?"


translate french introep4_f771828c:


    ruby "Passera-t-il un moment avec Gabriella au musée, peut-être en trouvant l'inspiration parmi les œuvres d'art ?"


translate french introep4_9a72089e:


    ruby "Sera-t-il aux côtés de Julia à l'hôpital, pour la soutenir alors qu'elle rend visite à sa mère dans ce moment difficile ?"


translate french introep4_38d24d7d:


    ruby "Peut-être rejoindra-t-il Madison pour un dîner avec sa famille. Ce pourrait être une soirée intéressante, c'est le moins qu'on puisse dire."


translate french introep4_6bd2a1f7:


    ruby "Peut-être qu'il se concentrera sur la préparation de la prochaine épreuve, en affinant ses compétences pour ce qui l'attend."


translate french introep4_2ae225eb:


    ruby "Avec la compétition qui s'accélère et toutes ces relations à gérer, je ne peux m'empêcher de me demander comment [name] va gérer tout cela. La pression monte, et chaque décision compte."


translate french introep4_582b7e53:


    ruby "J'espère vraiment que [name] saura être à la hauteur pour la prochaine épreuve qu'Orushi nous a préparée. Ça ne va pas être facile, mais s'il y en a un qui peut le faire, c'est lui !"


translate french introep4_fc654be2:


    ruby "Je suis tellement impatiente de voir comment tout cela va se dérouler ! J'en peux plus ! Mais pour l'instant, je vous laisse. Bonne chance !"


translate french introep4_c17416f5:


    "Mise à jour de la version de votre téléphone..."


translate french introep4_33f67964:


    "Les notifications ont été activées..."


translate french introep4_616fdfab:


    "De nouvelles applications ont été installées..."


translate french introep4_8975978c:


    "Vous avez reçu une invitation pour installer OnlyStan."


translate french introep4_9a5f6a1c:


    "Voulez-vous l'installer ?"


translate french introep4_05d09197:


    "Application installée, veuillez vérifier vos informations..."


translate french introep4_473a1d4a:


    d "Hmm, ça doit être Kira..."


translate french introep4_873c3127:


    "Entrez un nom d'utilisateur :"


translate french introep4_6adface7:


    d "D'accord, voyons cette application."


translate french introep4_2d8cef31:


    d "Je ne veux pas avoir plus de choses sur mon téléphone."

translate french strings:


    old "EPISODE 4"
    new "ÉPISODE 4"


    old "ACCELERATION"
    new "ACCÉLÉRATION"


    old "Your Username?"
    new "Votre nom d'utilisateur ?"


    old "Awake?"
    new "Réveillée ?"


    old "Yeah, bit of a headache but I'm fine."
    new "Oui, un peu mal à la tête mais ça va."


    old "'I had fun at the party, thanks for bringing me."
    new "Je me suis bien amusé à la soirée, merci de m'avoir invité."


    old "I had fun too! It was over too soon."
    new "Moi aussi, je me suis amusée ! Ca s'est fini trop vite."


    old "You don't regret how it ended?"
    new "Tu ne regrettes pas comment ça s'est terminé ?"


    old "Regret? Are you insane? It was marvelous."
    new "Regretter ? Tu es fou ? C'était merveilleux."


    old "It was the best night of my life!"
    new "C'était la meilleure nuit de ma vie !"


    old "You actually make time for me, listen to what I say..."
    new "Tu prends vraiment du temps pour moi, tu écoutes ce que je dis..."


    old "I never felt so respected by a man..."
    new "Je ne me suis jamais sentie autant respectée par un homme..."


    old "My man?"
    new "Mon homme ?"


    old "Your man."
    new "Ton homme."


    old "Have to go. See you later!"
    new "Je dois y aller. À plus tard !"


    old "See ya!"
    new "À plus !"


    old "Hey! Do you still want me to come with you to the hospital?"
    new "Hé ! Tu veux toujours que je vienne avec toi à l'hôpital ?"


    old "If you don't mind..."
    new "Si ça ne te dérange pas..."


    old "No, no, not at all."
    new "Non, non, pas du tout."


    old "Great! I'm heading there soon."
    new "Super ! J'y vais bientôt."


    old "Should we meet out front?"
    new "On se retrouve devant ?"


    old "Alright! See you in a bit!"
    new "D'accord ! À tout à l'heure !"


    old "See you soon!"
    new "À toute !"


    old "Awake and ready to meet up with you!"
    new "Réveillé et prêt à te retrouver !"


    old "What part of 'only in case of emergency' do you not understand?"
    new "Quelle partie de 'uniquement en cas d'urgence' ne comprends-tu pas ?"


    old "Hey, it was just so you wouldn’t worry."
    new "Hé, c'était juste pour que tu ne t'inquiètes pas."


    old "I wasn't worried."
    new "Je ne m'inquiétais pas."


    old "I'm not gonna miss our date either!"
    new "Je ne vais pas manquer notre rendez-vous non plus !"


    old "It's not a date!"
    new "Ce n'est pas un rendez-vous !"


    old "Yeah, yeah!"
    new "Oui, oui !"


    old "Just be on time."
    new "Sois juste à l'heure."


    old "Yes, ma'am!"
    new "Oui, madame !"




translate french strings:


    old "No[TEMP1!t]"
    new "Non[TEMP1!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
