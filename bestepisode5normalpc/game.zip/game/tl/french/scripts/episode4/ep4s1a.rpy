


translate french ep4s1a_20c9ad11:


    julia "Merci d'être venu avec moi aujourd'hui, [name]."


translate french ep4s1a_8f3f1879:


    julia "J'en avais vraiment besoin."


translate french ep4s1a_7e35fbb9:


    d "Hé, pas de souci. Je suis là pour ça."


translate french ep4s1a_798b37f7:


    d "Je te l'ai dit, je suis là pour toi quand tu as besoin."


translate french ep4s1a_1cedbfe4:


    julia "Oui, je sais. Mais merci quand même."


translate french ep4s1a_886abaf6:


    d "Wow !"


translate french ep4s1a_68ada36b:


    julia "Quoi ?"


translate french ep4s1a_e86145ea:


    d "Non, non... rien..."


translate french ep4s1a_e44d7546:


    julia "D'accord, allons-y."


translate french ep4s1a_54134776:


    d "Tu veux que j'attende ici ?"


translate french ep4s1a_453a8aaf:


    julia "Non, tu peux venir."


translate french ep4s1a_e8f90dc9:


    julia "Elle n'est plus vraiment là..."


translate french ep4s1a_0a6d6189:


    julia "Maman..."


translate french ep4s1a_76710067:


    d "Que lui est-il arrivé exactement ?"


translate french ep4s1a_10ac15f6:


    julia "Elle a eu un cancer du sein alors qu'elle était assez jeune."


translate french ep4s1a_a5e75600:


    julia "Ça s'est propagé à sa peau, sur toute son épaule et…"


translate french ep4s1a_14b2730a:


    julia "Eh bien, partout en fait."


translate french ep4s1a_b52d04e6:


    julia "Petit à petit, les tumeurs se sont propagées dans tout son corps… Et finalement, elles ont atteint son cerveau."


translate french ep4s1a_6038d7cf:


    julia "C'est à ce moment-là qu'ils ont dû la plonger dans un coma artificiel… Pour arrêter la douleur."


translate french ep4s1a_4e452bbd:


    d "Oh..."


translate french ep4s1a_bef3d6e9:


    d "Ça a dû être vraiment difficile pour vous deux."


translate french ep4s1a_8987783b:


    julia "C'était difficile. Voir ma mère perdre ses cheveux pendant que les miens poussaient... Je ne savais pas comment m'en occuper. Pas une enfance normale, c'est sûr."


translate french ep4s1a_b629e81e:


    julia "Au bout d'un moment, elle a commencé à perdre la tête. Elle avait des délires, comme des hallucinations causées par les traitements et le cancer qui atteignait son cerveau…"


translate french ep4s1a_8c680c87:


    julia "Elle n'était plus elle-même. Elle me criait dessus, parlait de ma sœur... Je n'en ai même pas."


translate french ep4s1a_80f1e158:


    d "C'est terrible. Tu dois t'inquiéter de l'avoir un jour ?"


translate french ep4s1a_9e506163:


    julia "Malheureusement, c'est génétique..."


translate french ep4s1a_a327b7fb:


    julia "J'ai été testée, et heureusement je n'ai pas les marqueurs pour ça."


translate french ep4s1a_47d7d147:


    julia "Mais ça saute souvent une génération, donc il y a toujours une chance que mes enfants puissent l'avoir..."


translate french ep4s1a_ad25a9e6:


    d "Je vois... Ça doit être beaucoup à gérer."


translate french ep4s1a_b4a2294b:


    julia "Ça l'est, mais je prends les choses une étape à la fois."


translate french ep4s1a_5fd62a27:


    d "Je ne sais même pas quoi dire..."


translate french ep4s1a_a1b2ccce:


    julia "Ne t'inquiète pas, je ne te demande pas de comprendre ou d'avoir pitié de moi."


translate french ep4s1a_09cc0a8a:


    julia "Le simple fait que tu sois ici avec moi aujourd'hui signifie beaucoup."


translate french ep4s1a_162d485e:


    d "Tu viens souvent lui rendre visite ?"


translate french ep4s1a_a1fcf155:


    julia "J'essaie de venir tous les deux jours."


translate french ep4s1a_4f7968df:


    julia "Mais entre le travail et les études, parfois je ne peux tout simplement pas."


translate french ep4s1a_73baebc1:


    julia "Et les traitements coûtent cher..."


translate french ep4s1a_dd8840b0:


    julia "Mais les médecins disent... qu'il ne lui reste plus beaucoup de temps."


translate french ep4s1a_0a6d6189_1:


    julia "Maman..."


translate french ep4s1a_714f2208:


    d "Alors, qu'est-ce que tu vas faire cet aprèm ?"


translate french ep4s1a_834ed170:


    julia "Eh bien, je vais me détendre un peu. Mon dos me fait encore un peu mal."


translate french ep4s1a_56e0418c:


    julia "Ensuite, j'ai des cours à rattraper, et mon appartement est en bazar..."


translate french ep4s1a_c6c5499b:


    julia "Et toi ?"


translate french ep4s1a_616de764:


    d "Je vais retrouver Gabriella au musée."


translate french ep4s1a_d97405e0:


    julia "Ohhh oui, ton grand rendez-vous avec la milf de Ruby !"


translate french ep4s1a_a776abc5:


    d "Haha, oui... Enfin, ce n'est pas vraiment un rendez-vous, mais c'est une occasion de mieux la connaître."


translate french ep4s1a_ec12eec5:


    julia "Tu verras, elle est un peu mystérieuse, mais c'est une bonne personne."


translate french ep4s1a_89114304:


    julia "C'est notre coach, et elle est super exigeante."


translate french ep4s1a_79aab06d:


    julia "Juste... Ne la mets pas en colère, tu vois ?"


translate french ep4s1a_a2edb627:


    d "Je ferai de mon mieux pour rester cool !"


translate french ep4s1a_7b68489f:


    d "J'ai un dîner avec Madison."


translate french ep4s1a_95e9319e:


    julia "Madison ? Oh, waouh..."


translate french ep4s1a_257943fa:


    d "Oui, je vais chez elle pour dîner avec sa famille."


translate french ep4s1a_02e67166:


    julia "Oh... Fais attention, tu entres sur un terrain miné."


translate french ep4s1a_2c3a63c7:


    d "Qu'est-ce que tu veux dire ?"


translate french ep4s1a_893d4e1a:


    julia "Madison est une Forrester."


translate french ep4s1a_9bab20a6:


    julia "C'est, genre, la troisième famille la plus influente de la ville après les Orushi."


translate french ep4s1a_0ed8cdd3:


    julia "Donc oui, tout est une question de perfection avec eux."


translate french ep4s1a_b1190186:


    julia "Habille-toi bien."


translate french ep4s1a_4ca205d9:


    d "Euh... D'accord. J'ai encore le costume que j'ai porté hier. Je suppose que je vais mettre ça."


translate french ep4s1a_6f595adf:


    julia "Oui, tu devrais, si tu veux faire bonne impression."


translate french ep4s1a_37cb29af:


    d "Merci pour le conseil..."


translate french ep4s1a_b2c92cdc:


    julia "De rien !"


translate french ep4s1a_657ccf98:


    d "Je dois m'entraîner pour le prochain match, et je devrais aussi étudier un peu..."


translate french ep4s1a_e134941d:


    julia "Oui, ne néglige pas l'entraînement ou les cours."


translate french ep4s1a_b4f01913:


    julia "Bon, je te laisse ici. Merci encore pour tout."


translate french ep4s1a_f32bf035:


    d "Oh, c'est normal !"


translate french ep4s1a_a0beed8f:


    julia "Oh ?"


translate french ep4s1a_026c94db:


    d "Désolé... en France, on s'embrasse sur les deux joues."


translate french ep4s1a_d031609a:


    julia "Non, c'est moi... Je... Euh..."


translate french ep4s1a_ff8ab879:


    julia "Eh bien, on dirait que tu m'as volé mon premier baiser..."


translate french ep4s1a_4e452bbd_1:


    d "Oh..."


translate french ep4s1a_50e16c23:


    julia "Fais pas cette tête ! Je ne m'y attendais juste pas, c'est tout !"


translate french ep4s1a_44cfdc8a:


    d "Tu veux réessayer ? Cette fois, tu seras prête !"


translate french ep4s1a_8c3c7c10:


    julia "Hmm... Peut-être plus tard, qui sait ?"


translate french ep4s1a_669d7f1d:


    julia "Allez, à plus tard !"


translate french ep4s1a_c5072505:


    d "À plus."


translate french ep4s1a_5f13b557:


    dpense "Julia... Il y a quelque chose de tellement touchant chez elle."


translate french ep4s1a_04fa9d91:


    dpense "Malgré tout ce qu'elle traverse avec sa mère, elle est si forte. Mais dans des moments comme celui-ci, je peux voir sa vulnérabilité."


translate french ep4s1a_38ba8bbc:


    dpense "Ce mélange de force et de fragilité... C'est difficile de ne pas être attiré par elle."


translate french ep4s1a_7c6dc66b:


    dpense "Et ce baiser... Eh bien, accidentel ou pas, c'était inattendu."


translate french ep4s1a_c51fab7f:


    dpense "Son rire après ça, la façon dont elle l'a pris à la légère. Elle a une façon de rendre même les moments gênants naturels."


translate french ep4s1a_7b26a132:


    dpense "Est-ce que je viens vraiment de lui voler son premier baiser ?"


translate french ep4s1a_e9feed51:


    dpense "Je me demande ce que cela signifie pour nous..."


translate french ep4s1a_628b3fc9:


    dpense "Attends... C'est quoi ça dans ma poche ?"


translate french ep4s1a_10b0457b:


    dpense "Est-ce que quelqu'un a glissé ça sans que je m'en rende compte ?"


translate french ep4s1a_0def6966:


    dpense "1410 ? Qu'est-ce que ça signifie ?"


translate french ep4s1a_9d5f494f:


    dpense "Et qui a laissé ce mot ? Est-ce que ça concerne Julia ?"




translate french strings:


    old "Take care of her: 1410"
    new "Prend soin d'elle : 1410"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
