


translate french epreuveep4_f5e6cdac:


    "Voulez-vous éviter l'épreuve ? (Veuillez noter que vous aurez le score minimum pour continuer l'histoire.)"

translate french strings:


    old "Skip the trial"
    new "Eviter l'épreuve"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
