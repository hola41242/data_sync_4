


translate french gameoverep4_a733e2ee:


    orushi "Malheureusement, vous n'avez pas réussi à passer toutes les épreuves, [name]..."


translate french gameoverep4_84c6535c:


    orushi "C'est décevant..."


translate french gameoverep4_3bdd13e5:


    orushi "Eh bien, la prochaine fois... Essayez de faire de meilleurs choix !"


translate french gameoverep4_783ab545:


    "Fshhhhhhhhhh!!!!"


translate french gameoverep4_e233951b:


    "Même joueur joue encore !"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
