


translate french ep4s3_e8bd61eb:


    d "Bon, il est temps de commencer la journée !"


translate french ep4s3_32954422:


    d "Oh, salut ! Je ne m'attendais pas à te voir."


translate french ep4s3_f6313d78:


    d "Si tu traînes ici... ton maître ne doit pas être loin, non ?"


translate french ep4s3_91988ae3:


    rufus "Prrrrrrrr !"


translate french ep4s3_e776a54d:


    d "Tu es un bon chat, hein ?"


translate french ep4s3_3dfcc959:


    d "Beurk, je ne supporte pas les chats !"


translate french ep4s3_22182f2e:


    rufus "Hsssss !"


translate french ep4s3_b13ccae6:


    d "Ouais, ouais, siffle autant que tu veux."


translate french ep4s3_886abaf6:


    d "Waouh !"


translate french ep4s3_33c6f2cd:


    beth "Suis-moi."


translate french ep4s3_2f10d688:


    d "Oh... D'accord..."


translate french ep4s3_75deccb4:


    beth "Il va y avoir un défi dans quelques minutes."


translate french ep4s3_4ebefc7f:


    beth "Je sais déjà ce qu'on doit faire."


translate french ep4s3_d2069617:


    beth "Et je sais où se trouvent les objets qu'on doit trouver."


translate french ep4s3_2e165cba:


    beth "Tu devras choisir ton partenaire pour aujourd'hui."


translate french ep4s3_47e8a1be:


    beth "Choisis-moi."


translate french ep4s3_9ad54e19:


    d "Oh... Euh..."


translate french ep4s3_2ca6f83a:


    beth "Je sais pour toi et ma sœur."


translate french ep4s3_2f10d688_1:


    d "Oh... D'accord..."


translate french ep4s3_633d7fff:


    beth "Tu as intérêt à ne pas..."


translate french ep4s3_a19c6b04:


    sofia "Laisse-le tranquille !"


translate french ep4s3_60e7b84a:


    beth "Sofia !"


translate french ep4s3_f97abb54:


    beth "Oh, laissez tomber. Débrouillez-vous."


translate french ep4s3_3992efb2:


    sofia "J'ai suivi ma sœur hier soir pour voir ce qu'elle faisait."


translate french ep4s3_95cd67eb:


    sofia "Je sais où elle est allée fouiner."


translate french ep4s3_416e814f:


    sofia "Tu veux faire équipe pour le défi ?"


translate french ep4s3_9ad54e19_1:


    d "Oh... Euh..."


translate french ep4s3_e1f05114:


    d "Salut tout le monde !"


translate french ep4s3_d52773cf:


    d "Vous êtes prêtes ?"


translate french ep4s3_71a7b4cc:


    ruby "Prête ? Je suis *tellement* excitée !"


translate french ep4s3_fe2b3523:


    d "Hmm... Ruby..."


translate french ep4s3_6f8e0a32:


    ruby "Oui ?"


translate french ep4s3_b8112270:


    d "Tifa ? Sérieusement ?"


translate french ep4s3_acb088b5:


    ruby "Hé ! C'est une combattante, et je me sens comme une combattante aujourd'hui !"


translate french ep4s3_af768ada:


    ruby "Hushh !"


translate french ep4s3_8c0c30a9:


    d "D'accord... Plutôt Yuffie alors."


translate french ep4s3_b25157d3:


    ruby "Grace m'a dit qu'il va y avoir un nouveau défi aujourd'hui. Ça va être épique !"


translate french ep4s3_134c20f9:


    d "Sérieusement ?"


translate french ep4s3_318ce411:


    grace "Oui. Ma mère était debout à l'aube pour tout préparer."


translate french ep4s3_d925e272:


    d "Ça a l'air sérieux."


translate french ep4s3_9098eb6d:


    mad "Et mes parents semblaient aussi savoir que quelque chose se préparait."


translate french ep4s3_51b7f2ff:


    d "Qu'est-ce que tu veux dire par là ?"


translate french drewappelep4_e54fe14c:


    drew "A l'attention de tous les participants du B.E.S.T !"


translate french drewappelep4_dba9fc01:


    drew "Veuillez vous rendre immédiatement à l'auditorium !"


translate french drewappelep4_421c99b2:


    d "On dirait que c'est parti..."


translate french drewappelep4_f3bea7c5:


    drew "Chers participants."


translate french drewappelep4_96e44cc9:


    drew "Vous avez commencé cette compétition à cent. Maintenant, il ne reste plus que quarante d'entre vous."


translate french drewappelep4_3999b90e:


    drew "Et aujourd'hui, les enjeux sont encore plus élevés."


translate french drewappelep4_2f4698d7:


    drew "C'est avec grand plaisir..."


translate french drewappelep4_91cf5307:


    drew "Et un immense honneur de vous présenter..."


translate french drewappelep4_40b3fe90:


    drew "Hummm..."


translate french drewappelep4_c0f0836c:


    drew "M. Orushi d'Orushi Corp. !"


translate french drewappelep4_182d15dd:


    orushi "Merci, Mme Drew."


translate french drewappelep4_db9faf88:


    rufus "Miaouuuuu..."


translate french drewappelep4_38aa3afe:


    orushi "Et merci à tous pour cet accueil chaleureux."


translate french drewappelep4_2165a5cb:


    orushi "Étudiants..."


translate french drewappelep4_831e141a:


    orushi "Je suis ravi de faire partie de cette compétition extraordinaire avec vous."


translate french drewappelep4_a25e37f6:


    orushi "Aujourd'hui marque un tournant majeur, car seulement la moitié d'entre vous passera à l'étape suivante après ce défi."


translate french drewappelep4_acdbcee0:


    orushi "Nous avons testé vos capacités athlétiques lors du premier défi."


translate french drewappelep4_1f1b4369:


    orushi "Et vos connaissances générales lors du deuxième."


translate french drewappelep4_7c90e673:


    orushi "Maintenant, nous allons tester votre compréhension du monde qui vous entoure."


translate french drewappelep4_0b26132b:


    orushi "Le défi d'aujourd'hui est une course d'orientation."


translate french drewappelep4_9ea1b9d2:


    orushi "C'est un événement chronométré, et votre classement dépendra entièrement de votre rapidité à le terminer."


translate french drewappelep4_9cefd6b5:


    orushi "En résumé : plus vous terminez rapidement, plus votre classement sera élevé."


translate french drewappelep4_d03a3a60:


    orushi "Donnez tout ce que vous avez, et surtout... Soyez les B.E.S.T !"



translate french drewappelep4_9948de8f:


    orushi "Maintenant, je laisse Mme Drew vous expliquer les règles."


translate french drewappelep4_ed65a178:


    mad "Si je gagne ça, je passe première !"


translate french drewappelep4_5a767a3c:


    ruby "Vraiment ?"


translate french drewappelep4_8c7a55bc:


    mad "Oui, je suis juste derrière Emerick... Je dois gagner."


translate french drewappelep4_6d39de95:


    dpense "Humm..."


translate french drewappelep4_f8d0d0c8:


    drew "Merci, M. Orushi."


translate french drewappelep4_5b11c3d5:


    drew "Voici comment cela va se dérouler."


translate french drewappelep4_2a6aa502:


    drew "Dans un instant, vous recevrez tous une invitation sur vos téléphones."


translate french drewappelep4_f1d0ce9e:


    drew "Acceptez l'invitation, et elle installera l'application B.E.S.T. Cette application sera essentielle pour la suite de la compétition."


translate french drewappelep4_45bf5076:


    d "Ils ont le droit de faire ça?"


translate french drewappelep4_d3c76b14:


    ruby "Tu peux refuser si tu veux, mais tu ne pourras pas participer sans ça."


translate french drewappelep4_43a5dd76:


    d "Je suppose que je n'ai pas vraiment le choix."


translate french drewappelep4_bbf0abb5:


    drew "Le défi est simple : c'est une course d'orientation."


translate french drewappelep4_6c4fc160:


    drew "Sur votre écran, vous verrez une carte des différents lieux à visiter."


translate french drewappelep4_b861a299:


    drew "Les indices pour chaque lieu seront répertoriés dans la section 'Indices'."


translate french drewappelep4_0d24b286:


    drew "Gardez à l'esprit : chaque déplacement entre les lieux vous coûtera du temps."


translate french drewappelep4_e75a16a0:


    drew "À chaque bon emplacement, vous devrez trouver un objet avec un numéro dessus."


translate french drewappelep4_479f68d0:


    drew "Votre objectif est de collecter quatre numéros."


translate french drewappelep4_4bf7d85d:


    drew "Une fois que vous les avez tous, retournez à l'auditorium pour vous connecter à l'application."


translate french drewappelep4_c1aa9c15:


    drew "Si vous avez collecté les bons numéros, une nouvelle section de l'application se débloquera."


translate french drewappelep4_a8875244:


    drew "Complétez cette section pour finaliser votre classement."


translate french drewappelep4_c74feb05:


    drew "Voici la subtilité : ce défi est une épreuve en équipe."


translate french drewappelep4_9e1cc064:


    drew "Vous devez choisir un partenaire pour relever le défi."


translate french drewappelep4_ba1ba14b:


    drew "Choisissez judicieusement."


translate french drewappelep4_694e6df3:


    drew "Chaque personne a ses forces et ses faiblesses, et le choix de votre partenaire aura un impact significatif sur vos résultats."


translate french drewappelep4_0a57b22e:


    drew "Cette décision pourrait faire ou défaire votre performance."


translate french drewappelep4_ec5bb550:


    drew "Prenez votre temps, choisissez votre partenaire et lancez l'application."


translate french drewappelep4_9bc471f1:


    drew "Bonne chance !"


translate french drewappelep4_88d05149:


    d "Bon, alors… allons-y !"


translate french redtrialep4_a82fd129:


    beth "D'accord, tu explores et je te montre où se trouvent les objets cachés."


translate french redtrialep4_6c20eb5c:


    d "Parfait. Allons-y !"


translate french maditrialep4_6c20eb5c:


    d "Parfait. Allons-y !"


translate french juliatrialep4_6c20eb5c:


    d "Parfait. Allons-y !"


translate french rubytrialep4_6c20eb5c:


    d "Parfait. Allons-y !"


translate french gracetrialep4_6c20eb5c:


    d "Parfait. Allons-y !"


translate french bluetrialep4_21c5256c:


    sofia "Je vais te montrer où j'ai vu ma sœur hier !"


translate french bluetrialep4_6c20eb5c:


    d "Parfait. Allons-y !"

translate french strings:


    old "Pet the cat"
    new "Caresser le chat"


    old "Shoo the cat away"
    new "Faire fuir le chat"


    old "Choose Elisabeth"
    new "Choisir Elisabeth"


    old "Choose Madison"
    new "Choisir Madison"


    old "Choose Julia"
    new "Choisir Julia"


    old "Choose Ruby"
    new "Choisir Ruby"


    old "Choose Grace"
    new "Choisir Grace"


    old "Choose Sofia"
    new "Choisir Sofia"


translate french strings:


    old "Pet the cat[TEMP1!t]"
    new "Caresser le chat[TEMP1!t]"




translate french drewappelep4_c96615ed:


    orushi "Maintenant, je vais laisser Mrs Drew vous expliquer les règles."




translate french drewappelep4_3eb12593:


    "Une sauvegarde a été faite sur le slot 9-1 en backup."




translate french ep4s3i_e40a7f98:


    d "Je vais envoyer un message à Ruby pour voir où elles sont."


translate french drewappelep4_d396a4fb:


    "Une sauvegarde de secours a été mise en 9-2."

translate french strings:


    old "Hey, Were are you?"
    new "Hey, vous êtes où?"


    old "In the hall!"
    new "Dans le hall!"


    old "Okay coming!"
    new "Okay j'arrive!"



translate french strings:


    old "Hey, where are you?"
    new "Hey, vous êtes où?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
