


translate french ep3s2b_0ae9bcd0:


    ""


translate french ep3s2b_0ae9bcd0_1:


    ""


translate french ep3s2b_d56e0059:


    mad "Oui ? Qu'est-ce que tu veux, Papa?"


translate french ep3s2b_32c1a608:


    "Madison, c'est qui ce français avec qui tu t'es mise en équipe pour la compétition?"


translate french ep3s2b_0091a552:


    mad "Comment tu sais ça? Et qu'est ce que ça peut te faire?"


translate french ep3s2b_185b9e19:


    "Je ne veux pas voir ma fille traîner avec des gars qui sont incapables de gagner!"


translate french ep3s2b_522008c6:


    "Tu as une fille, je te rapelle. Et son 'père', si on appeler ça comme ça, ne sert à rien. Alors pas besoin d'un autre gars tout aussi inutile dans ta vie!"


translate french ep3s2b_062d0790:


    mad "C'est ma responsabilité, pas la tienne. J'ai pas besoin d'avoir ton aval sur comment je vis ma vie et avec qui je passe du temps!"


translate french ep3s2b_5b68cb36:


    "Je veux que tu me l'emmène à dîner demain soir! C'est ta chance de me montrer que tu es responsable."


translate french ep3s2b_07c235cf:


    "Ne me fais pas regretter."


translate french ep3s2b_d6d05e4d:


    mad "Mais pourquoi tu tiens tant à le voir?"


translate french ep3s2b_6ae5d577:


    "Demain soir, 19 heures."


translate french ep3s2b_315b4afb:


    mad "..."


translate french ep3s2b_0b0d85c6:


    mad "Tu fais quoi ici toi?"


translate french ep3s2b_4189c756:


    mad "En fait tu tombes bien. Il faut que je te parle."


translate french ep3s2b_552c4164:


    d "Tout va bien ? Je veux pas m'incruster..."


translate french ep3s2b_63f41e3d:


    mad "Mon père veut te voir demain à sept heures pour le dîner. Tu peux le faire?"


translate french ep3s2b_81bb9408:


    d "Moi? Mais pourquoi?"


translate french ep3s2b_02f9f09e:


    mad "Demande pas... Dis juste oui..."


translate french ep3s2b_128ee54e:


    d "Heu... Oui pas de problèmes. Faut juste que je vois comment aller jusqu'à chez toi."


translate french ep3s2b_61c99aed:


    mad "T'inquiète pas pour ça je viendrais te chercher."


translate french ep3s2b_d627f5ff:


    mad "Tiens, prend mon numéro. Ce sera plus simple si on a besoin de s'appeler."


translate french ep3s2b_08c3c4ca:


    d "D'accord."


translate french ep3s2b_f0d4cb36:


    mad "Merci. Pour... Tu sais... Etre là. On va faire ce dîner. Mon père ne peut pas continuer à dicter comment je dois vivre ma vie."


translate french ep3s2b_865b61b3:


    mad "Ecoute, pour demain... Mon père a quelques problèmes avec les choix que j'ai pu faire dans le passé... Surtout en ce qui concerne ma fille."


translate french ep3s2b_77086cd0:


    mad "Il n'a jamais accepté mes anciennes relations, et encore moins le fait que je sois mère célibataire maintenant."


translate french ep3s2b_74fbeb94:


    d "Je vois. Ca doit être difficile pour toi. Mais tu n'as pas besoin de te justifier auprès de moi... Ou même de n'importe qui en fait!"


translate french ep3s2b_c665b921:


    mad "Merci. Ca... me touche beaucoup."


translate french ep3s2b_432871ef:


    d "C'est moi qui te remercie de venir me chercher du coup! Et je serais là, peut importe ce qu'en pense ton père."


translate french ep3s2b_68a4faa7:


    mad "Mon père a cette façon de... Bref, il va faire une montagne de ce dîner avec toi."


translate french ep3s2b_4d78f3f9:


    mad "Après notre 'succès' au B.E.S.T, il doit te voir comme un élément gênant."


translate french ep3s2b_c2a05840:


    mad "C'est un peu bizarre, mais il veut absolument te rencontrer demain du coup."


translate french ep3s2b_de30ff18:


    d "Je vois. Mais ça te dérange pas que je vienne?"


translate french ep3s2b_0409766e:


    mad "Non non bien au contraire! Ca peut être intéressant. Ma mère fera le dîner, comme d'hab. Mon père va sans doute parler et se faire mousser... Comme d'hab... Il essaiera sans doute de te mettre mal à l'aise alors... Reste calme..."


translate french ep3s2b_ea49cf54:


    d "D'accord."


translate french ep3s2b_c270fcf5:


    d "J'ai hâte de savoir contre qui on joue lundi."


translate french ep3s2b_a7d2d034:


    mad "Oh! On t'a pas dit?"


translate french ep3s2b_30d72d9c:


    d "De quoi?"


translate french ep3s2b_bf9328cc:


    mad "Le tirage au sort a été fait."


translate french ep3s2b_52e0f737:


    d "Et?"


translate french ep3s2b_e9ec6def:


    mad "Devine..."


translate french ep3s2b_aafe548a:


    mad "Les gars de l'équipe masculine... Ils sont forts."


translate french ep3s2b_6d68cbc1:


    mad "Steven, leur capitaine, sait motiver son équipe et il a de la puissance."


translate french ep3s2b_047aa479:


    mad "Y'à aussi Hector, ce gars est vicieux et on peut pas trop prévoir ce qu'il va faire sur le terrain."


translate french ep3s2b_6706d7cc:


    d "Ouais, je le connais lui. Je me suis un peu embrouillé avec lui hier."


translate french ep3s2b_8f2bb8a5:


    mad "Hm... Ca peut être une bonne chose."


translate french ep3s2b_bec902dc:


    d "Comment ça?"


translate french ep3s2b_80e30dba:


    mad "Bah il risque de se focaliser sur toi. Ca nous laissera le champ libre."


translate french ep3s2b_bb20d578:


    d "Ouais... Mais je pense que ça va être physique!"


translate french ep3s2b_1940ca92:


    mad "Ca fait parti du jeu. Fais juste attention qu'ils ne te fassent pas du sale."


translate french ep3s2b_e8fc89cc:


    d "Je vais essayer."


translate french ep3s2b_0b4e5289:


    mad "Après y'à Ben, qui suit les ordres de Steven sans poser de questions."


translate french ep3s2b_1683d1f4:


    mad "Et Mac, le gardien. Un vrai mur."


translate french ep3s2b_0ea43725:


    mad "Mais c'est leur cinquième joueur qui est un mystère. Je ne sais pas qui c'est."


translate french ep3s2b_112950f5:


    d "Un joueur que tu ne connais pas? Ca complique les choses."


translate french ep3s2b_b8846a29:


    mad "C'est ça. Va falloir faire attention, surtout avec Steven et son influence sur l'équipe. Il a ce... Charisme qui les pousse. Même si c'est pas mon genre de leader."


translate french ep3s2b_27a52dc6:


    d "On va trouver un moyen de passer leurs défenses. On a nos propres forces, en commençant par toi!"


translate french ep3s2b_e0621148:


    mad "J'apprécié ton optimisme. Mais tu as raison. On va leur montrer ce qu'on sait faire."


translate french ep3s2b_91e758df:


    mad "Bon maintenant faut vraiment continuer à s'entraîner. On a un match à gagner, et je ne vais pas laisser mon père ou ces clowns me distraire."


translate french ep3s2b_b38d594c:


    d "Je suis avec toi, Madison. On va faire ça ensemble."


translate french ep3s2b_f39ff206:


    mad "Merci, vraiment. Pour tout."


translate french ep3s2b_9d72cfd2:


    d "Tu sais, j'étais en train de penser..."


translate french ep3s2b_cfa39340:


    d "QUand Emerick a gagné la course. Personne ne l'a vu passer les obstacles n'est ce pas?"


translate french ep3s2b_d66a57ee:


    mad "Maintenant que tu le dis... C'est comme s'il avait disparu, puis réapparu à la fin... Sans que personne ne sâche comment il a fait."


translate french ep3s2b_ff0beae2:


    d "On l'a vu arriver de l'autre côté du stade, et le temps qu'on cherche nos sacs il était déjà parti."


translate french ep3s2b_ac184b92:


    mad "Les règles de cette compétition sont vagues, c'est frustrant."


translate french ep3s2b_11d7cc60:


    d "On pourrait pas les utiliser à notre avantage? Pour contrer Emerick je veux dire."


translate french ep3s2b_72dc96cb:


    mad "C'est une idée. Si les règles ne sont pas claires, il y a peut être des choses que l'on peut faire."


translate french ep3s2b_ae06e0f4:


    mad "Peut être même qu'on pourra retourner ces règles contre lui. Surtout s'il les utilise dans ses plans."


translate french ep3s2b_b386fe59:


    d "C'est ça. On devrait chercher des failles qu'on pourrait exploiter."


translate french ep3s2b_5760655e:


    d "Si Emerick joue avec les règles, y'à pas de raison qu'on ne puisse pas le faire. Tout ça sans tricher bien sûr."


translate french ep3s2b_35b5c838:


    mad "Je suis d'accord. On devrait discuter de ça avec les filles, au cas où elles auraient des idées."


translate french ep3s2b_b6cd81e7:


    mad "Mais pour l'instant, on se concentre sur le prochain match. Il va nous falloir toute notre force et de la stratégie pour celui-là."


translate french ep3s2b_4fdbb733:


    d "Ouais."


translate french ep3s2b_cfe3c6a6:


    mad "C'est bientôt l'heure du cours avec Gabriella."


translate french ep3s2b_dc09f676:


    d "Allons-y."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
