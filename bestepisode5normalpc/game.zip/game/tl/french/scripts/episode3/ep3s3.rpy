


translate french ep3s3_2ddd95bb:


    dpense "Autre jour... Autre cours..."


translate french ep3s3_dc432cdc:


    dpense "Ils sont tous déjà là."


translate french ep3s3_4e7dabcc:


    dpense "Bleue paraît un peu... différente aujourd'hui."


translate french ep3s3_e3e365da:


    dpense "Est ce qu'elle m'attend?"


translate french ep3s3_196077bc:


    dpense "Elle n'a pas mis son maquillage bleu d'ailleurs."


translate french ep3s3_7d7d8bab:


    dpense "Les filles sont toutes jolies."


translate french ep3s3_051fbf9a:


    dpense "Même Madison avec sa nouvelle... coupe de cheveux?"


translate french ep3s3_eb478b29:


    dpense "Qu'est ce qu'elles ont toutes avec leurs cheveux sans dec?"


translate french ep3s3_78d0ae4a:


    dpense "Rouge est avec Steven..."


translate french ep3s3_dec237ba:


    dpense "Sûrement en train de complôter..."


translate french ep3s3_ae753f0b:


    dpense "Ces deux-là, ensemble..."


translate french ep3s3_9d146b53:


    dpense "Je vais essayer de les éviter..."


translate french ep3s3_948122a8:


    dpense "Pas vraiment besoin d'avoir des soucis dans l'Academy..."


translate french ep3s3_68ac6f64:


    beth "Hey, beau gosse!"


translate french ep3s3_5dda0f88:


    d "Hmm?"


translate french ep3s3_c9c1336f:


    beth "Bon écoute, va y avoir une épreuve pendant le prochain cours."


translate french ep3s3_c4dae10d:


    d "Comment tu..."


translate french ep3s3_87807a25:


    beth "Cherche pas. Bref, ce sera des questions."


translate french ep3s3_6b4b1159:


    beth "Pour les réponses, ne répond jamais la réponse D..."


translate french ep3s3_dd5d68f3:


    d "Hein?"


translate french ep3s3_2508ad6c:


    beth "A,B,C,D... Jamais D! Tu as pigé?"


translate french ep3s3_b69cc98d:


    d "Mais comment tu sais ça?"


translate french ep3s3_a5f7a2d0:


    beth "Fais moi confiance c'est tout!"


translate french ep3s3_7bcc50f4:


    d "Okay..."


translate french ep3s3_0b732a56:


    sofia "Je peux t'aider pour le prochain test."


translate french ep3s3_bec902dc:


    d "Comment ça?"


translate french ep3s3_010257d7:


    sofia "Là, pendant le cours, va y avoir un test à la fin."


translate french ep3s3_01c7de32:


    d "Un test?"


translate french ep3s3_3d972ad4:


    sofia "Oui. Bref, y'aura une question où tu devras trouver un point sur l'image."


translate french ep3s3_44b10ff2:


    d "Heu... Un point."


translate french ep3s3_99269401:


    sofia "Oui un point. Faudra appuyer sur le point qui est à la fin de la question."


translate french ep3s3_37c947b7:


    d "Qu'est ce que tu veux dire par appuyer sur le point?"


translate french ep3s3_039ea5b7:


    sofia "Putain t'es pas un rapide toi!"


translate french ep3s3_7e8a2cca:


    sofia "Dans tous les cas, quand t'as la question sur les points, regarde pas l'image dessous, appuies sur le point final de la question."


translate french ep3s3_013db366:


    d "Heu okay je vais essayer."


translate french ep3s3_065c8531:


    sofia "Tu dois réussir. Je ferais tout pour t'aider."


translate french ep3s3_bbaee512:


    d "Heu... Merci?"


translate french ep3s3_e80e7368:


    sofia "On se voit plus tard."


translate french ep3s3_5d27ba6f:


    gaby "Bonjour à tous."


translate french ep3s3_53d46b9f:


    gaby "Veuillez vous mettre un par table s'il vous plaît!"


translate french ep3s3_43b49e4c:


    d "D'accord."


translate french ep3s3_693e08b4:


    gaby "Aujourd'hui nous allons parler un peu de commerce, en particulier des origines."


translate french ep3s3_672697a3:


    gaby "Quelle est selon vous une des premières formes de commerce?"


translate french ep3s3_bb9e3929:


    d "L'arrivée de la monnaie?"


translate french ep3s3_21d685ea:


    gaby "Hum, c'est une bonne idée mais c'est encore trop récent."


translate french ep3s3_f67ff181:


    gaby "La monnaie et l'économie qui y est associée ont plutôt été mis en place par les romains avec leurs marchés."


translate french ep3s3_498ed84d:


    d "Les dons entre tribus?"


translate french ep3s3_3001538f:


    gaby "Alors ce n'est pas une mauvaise une réponse, mais le principe de commerce suppose un échange."


translate french ep3s3_7244dc6f:


    gaby "Même si les dons étaient souvent utilisés lors de rituels pour obtenir une protection, divine ou stratégique entre tribus."


translate french ep3s3_9523ba64:


    gaby "Ce n'était pas tout à fait ce que l'on pourrait appeler du commerce."


translate french ep3s3_799d5576:


    d "Le troc?"


translate french ep3s3_c9667fb0:


    gaby "C'est une excellente réponse!"


translate french ep3s3_b1ef523b:


    gaby "Le troc a été pour beaucoup de tribus commençant à s'établir dans des villages lors de leur sédentarisation un moyen d'échange."


translate french ep3s3_3abd7c0d:


    gaby "Cela a permis d'instaurer des notions de valeur, de quantité, de propriété."


translate french ep3s3_c1748d43:


    gaby "Toutes ces notions sont toujours d'actualité, on les retrouve notamment à la bourse avec la valeur d'une action, le nombre d'actions et les propriétaires de ces actions."


translate french ep3s3_c43fcdc4:


    d "La prostitution?"


translate french ep3s3_1d22fb2c:


    gaby "De quoi?"


translate french ep3s3_62da3e44:


    d "Bah utiliser son corps pour gagner de l'argent!"


translate french ep3s3_f9cc5397:


    gaby "Oh!"


translate french ep3s3_7789f8f3:


    gaby "Je n'avais pas du tout pensé à ça. Mais ça aurait en effet pû être correct, sauf que la prostitution telle qu'on la connaît n'est apparue que bien plus tard."


translate french ep3s3_70cb96c7:


    gaby "Avec l'émergence de la monnaie, des civilisations et de la vie en communauté."


translate french ep3s3_d699719c:


    gaby "Auparavant les relations de ce genre étaient plutot... bestiales et dictées par les instincts et la tribu."


translate french suitecourseco0_ac74b583:


    gaby "Non, c'était le troc."


translate french suitecourseco0_1f6d8475:


    gaby "Le troc a été pour beaucoup de tribus commençant à s'établir dans des villages lors de leur sédentarisation un moyen d'échange."


translate french suitecourseco0_3abd7c0d:


    gaby "Cela a permis d'instaurer des notions de valeur, de quantité, de propriété."


translate french suitecourseco0_c1748d43:


    gaby "Toutes ces notions sont toujours d'actualité, on les retrouve notamment à la bourse avec la valeur d'une action, le nombre d'actions et les propriétaires de ces actions."


translate french suitecourseco_eb10b496:


    gaby "Vous voyez donc que c'est dans le passé que l'on retrouve les bases de ce que nous avons aujourd'hui."


translate french suitecourseco_b7e5c992:


    gaby "Connaître les origines de quelque chose pour en comprendre son fonctionnement ou ses effets est souvent le meilleur moyen d'apprendre et d'évoluer."


translate french suitecourseco_6b8ee6cc:


    gaby "A ce sujet, il y a demain une exposition au musée sur le jurassique et la vie au néolithique."


translate french suitecourseco_5917ed0d:


    gaby "[name], comme tu as donné la bonné réponse, voudrais-tu m'accompagner pour cette exposition?"


translate french suitecourseco_b9239156:


    d "Ce serait avec plaisir!"


translate french suitecourseco_b21afd26:


    gaby "Parfait. Viens me voir à la fin du cours."


translate french suitecourseco_094116c0:


    d "D'accord madame."


translate french suitecourseco_fe3248b2:


    d "Ah non je suis désolé, mais j'ai déjà des choses de prévues demain."


translate french suitecourseco_d51f7177:


    gaby "Oh? Quelqu'un d'autre?"


translate french suitecourseco_c8be3742:


    ji "Moi madame!"


translate french suitecourseco_df0cb0e4:


    gaby "Très bien..."


translate french suitecourseco_a685ef35:


    gaby "Est ce que quelqu'un voudrait m'y accompagner?"


translate french suitecourseco_7e3f71e4:


    ji "Moi madame!" with hpunch


translate french suitecourseco_77e4be5c:


    ji "Moi aussi je veux bien!" with hpunch


translate french suitecourseco_ee90ce3a:


    ruby "Madame ! Ne croyez-vous pas que ce serait intéressant pour notre élève fraîchement arrivé de France de voir de nouveaux endroits dans une ville qu'il ne connaît pas?"


translate french suitecourseco_c4afb5bd:


    ruby "Après tout, comment connaître une ville sans en connaître les origines et quel endroit mieux qu'un musée pourrait le lui montrer?"


translate french suitecourseco_d6d0fc86:


    ruby "C'est bien ce que vous venez de dire non?"


translate french suitecourseco_988772c9:


    gaby "Tu as raison!"


translate french suitecourseco_ff59d716:


    gaby "[name], voudrais-tu m'accompagner pour cette exposition?"


translate french suitecourseco_b9239156_1:


    d "Ce serait avec plaisir!"


translate french suitecourseco_b21afd26_1:


    gaby "Parfait. Viens me voir à la fin du cours."


translate french suitecourseco_094116c0_1:


    d "D'accord madame."


translate french suitecourseco_fe3248b2_1:


    d "Ah non je suis désolé, mais j'ai déjà des choses de prévues demain."


translate french suitecourseco_d51f7177_1:


    gaby "Oh? Quelqu'un d'autre?"


translate french suitecourseco_c8be3742_1:


    ji "Moi madame!"


translate french suitecourseco_df0cb0e4_1:


    gaby "Très bien..."


translate french suitecourseco_3302879f:


    gaby "Très bien, venez me voir après le cours."


translate french preepreuve_7c509ee7:


    gaby "Nous avons donc vu que..."


translate french preepreuve_f1b10217:


    drew "A tous les participants du B.E.S.T!"


translate french preepreuve_f3581df3:


    drew "Vous allez recevoir une tablette sur laquelle vous allez devoir répondre à des questions."


translate french preepreuve_0e0e1ad0:


    drew "Ces questions vont nous permettre d'évaluer votre logique, votre sens de la déduction, ou vos connaissances générales."


translate french preepreuve_ea74468a:


    drew "Etre le B.E.S.T signifie avoir un esprit affuté pour les défis qui nous entourent."


translate french preepreuve_b8b787a7:


    drew "Vous allez donc avoir 3 minutes au démarrage de l'épreuve pour répondre aux dix questions qui vont vous être posées."


translate french preepreuve_6c53b35c:


    drew "Vous pouvez passer une question si vous ne savez pas la réponse."


translate french preepreuve_32c8c257:


    drew "Ne pas répondre à une question ne signifie pas une élimination."


translate french preepreuve_4a68b967:


    drew "Par contre votre score total sera évalué et les dix derniers étudiants du classement seront éliminés."


translate french preepreuve_48d61694:


    drew "Je répète, vous avez trois minutes pour répondre aux dix questions."


translate french preepreuve_64c124f1:


    drew "Vous pouvez passer les questions mais votre score sera évalué à la fin et les dix derniers seront éliminés."


translate french preepreuve_7e2c012b:


    drew "Bonne chance à tous."


translate french postepreuve_4a800c5f:


    gaby "Vous pouvez poser votre tablette."


translate french postepreuve_0d6e0638:


    gaby "Ceci conclut le cours d'aujourd'hui."


translate french postepreuve_c5fbc9ab:


    gaby "[name], tu peux rester avec moi quelques minutes?"


translate french postepreuve_2d1667b9:


    d "Bien sûr!"


translate french postepreuve_b7e2f84a:


    gaby "Bonne journée à tous!"


translate french gabimusee1_d993aed7:


    gaby "Demain je t'attendrai devant le musée vers 14 heures. Ca ira pour toi?"


translate french gabimusee1_32e2a5d2:


    gaby "Je sais que vous avez une fête ce soir, donc je ne m'attend pas à ce que tu sois levé tôt."


translate french gabimusee1_d52492ad:


    d "Ca marche pour moi!"


translate french gabimusee1_d89a5895:


    gaby "J'espère que tu vas apprécier la visite."


translate french gabimusee1_17580177:


    d "Ne vous inquiétez pas, tant que je suis avec vous, je serais heureux n'importe où dans le monde."


translate french gabimusee1_2dad25e0:


    gaby "C'était un peu kitsh... Garde la tête froide jeune homme."


translate french gabimusee1_cd1d68c1:


    gaby "C'est juste une visite, pas un rendez-vous..."


translate french gabimusee1_9c209113:


    d "ET pourquoi ça pourrait pas être les deux?"


translate french gabimusee1_54945a89:


    gaby "Quoi? Non !"


translate french gabimusee1_40091c60:


    d "Haha! A demain, my lady! "


translate french gabimusee1_6e90ecf8:


    gaby "My lady?"


translate french gabimusee1_48876117:


    gaby "..."


translate french afterepreuve_49d76cd7:


    d "Alors les filles ? Ca a donné quoi ?"


translate french afterepreuve_9db1793b:


    mad "Niquel, c’était assez facile."


translate french afterepreuve_94a379b9:


    ruby "Ouais ça va !"


translate french afterepreuve_df08b2d1:


    grace "J’ai eu un peu de mal sur certaines questions moi."


translate french afterepreuve_5134a24b:


    mad "Vous êtes classées combien à la fin ?"


translate french afterepreuve_c3762510:


    ruby "14 ème!"


translate french afterepreuve_6fb2ffbf:


    grace "31ème pour moi..."


translate french afterepreuve_f4af23e0:


    mad "Je suis deuxième... On se demande qui est premier..."


translate french afterepreuve_62fb39a8:


    d "Hum?"


translate french afterepreuve_5c9d97f5:


    emerick "C'est qui le B.E.S.T?"


translate french afterepreuve_8144b71e:


    "C'est toi!"


translate french afterepreuve_b89e940c:


    grace "Emerick..."


translate french afterepreuve_41884caf:


    grace "Et toi, [name]?"


translate french afterepreuve_b620d1f0:


    d "Je suis [Rank]ème"


translate french afterepreuve_2d7cab0e:


    grace "Super!"


translate french afterepreuve_1cdd7644:


    ruby "Julia était excusée, je crois qu'elle est 15ème..."


translate french afterepreuve_c0599f41:


    mad "Excusée?"


translate french afterepreuve_a1a0d10a:


    mad "C'est vrai qu'elle était pas là aujourd'hui."


translate french afterepreuve_7910c319:


    ruby "Oui, j’ai entendu Mrs Drew tout à l’heure qui parlait d’une agression."


translate french afterepreuve_f8a6ff1c:


    d "J’y étais hier soir…"


translate french afterepreuve_efd85f70:


    grace "Hein ?"


translate french afterepreuve_75d8ffec:


    d "Quand je rentrais hier soir je suis arrivé dans une rue et Julia venait de se faire agresser par Hector et sa bande."


translate french afterepreuve_c9393e49:


    grace "T’es sérieux ?"


translate french afterepreuve_25ef201b:


    grace "Quel connard celui-là !"


translate french afterepreuve_1094b572:


    d "Quand je suis intervenu ils sont partis, mais elle avait un peu mal au dos."


translate french afterepreuve_1a886072:


    ruby "Hum… Je comprends mieux."


translate french afterepreuve_4067eee5:


    ruby "Brrrrrrrrr…. Si j’étais plus forte je les chopperais par en bas et j’en ferais de la bouillie."


translate french afterepreuve_221a7213:


    ruby "Je commencerais par les écraser pour en faire de la purée…"


translate french afterepreuve_cdfa9673:


    ruby "Puis je les broierais jusqu’à ce qu’elles éclatent…"


translate french afterepreuve_63bcf30e:


    ruby "je les découperais en tranches et je les passerais au mixeur…"


translate french afterepreuve_7523033d:


    ruby "Je…"


translate french afterepreuve_136f81dc:


    d "Ruby?"


translate french afterepreuve_b09db3c1:


    d "Tu t’enflammes pas un peu là ?"


translate french afterepreuve_585a72a2:


    ruby "Oh ? Oui… pardon…"


translate french afterepreuve_fb656274:


    mad "T’inquiète on va les exploser sur le terrain !"


translate french afterepreuve_2307991b:


    ruby "De ?"


translate french afterepreuve_6be94e9a:


    mad "Le tirage au sort a été fait… C’est eux nos prochains adversaires…"


translate french afterepreuve_5f32c47f:


    ruby "Oh?"


translate french afterepreuve_ea7bcd1b:


    ruby "Okay!"


translate french afterepreuve_e13999ea:


    ruby "Bon… On a du travail pour ce soir !"


translate french afterepreuve_49591a81:


    ruby "On y va Grace ?"


translate french afterepreuve_eb67e331:


    grace "Je te suis."


translate french afterepreuve_22a275e6:


    mad "Moi j’ai ma fille pour l’après-midi je vous rejoins ce soir."


translate french afterepreuve_e7e750c1:


    grace "Pas de problèmes."


translate french afterepreuve_47debeb0:


    ruby "Bon ben… A ce soir ?"


translate french afterepreuve_030945bb:


    mad "A ce soir !"


translate french afterepreuve_4cf42b7d:


    d "A ce soir !"


translate french afterepreuve_c9415513:


    dpense "Bon il me reste du temps avant la soirée."


translate french afterepreuve_194a59d5:


    dpense "Je peux continuer à m’entraîner ou…"


translate french afterepreuve_d9e0a872:


    dpense "Je peux aller me reposer un peu pour ce soir. Ca risque d’être une sacrée soirée !"

translate french strings:


    old "10:30 AM"
    new "10:30"


    old "The appearance of money?"
    new "L'arrivée de la monnaie?"


    old "Gifts?"
    new "Les dons?"


    old "Barter?[TEMP1!t]"
    new "Le troc?[TEMP1!t]"


    old "Prostitution?"
    new "La prostitution?"


    old "Yes[TEMP1!t]"
    new "Oui[TEMP1!t]"


    old "No[TEMP2!t]"
    new "Non[TEMP2!t]"




translate french preepreuve_6964222b:


    "Si vous le souhaitez, vous pouvez passer ce quiz avec le score minimal nécessaire pour continuer l'aventure."


translate french preepreuve_692de64d:


    "Veuillez noter que vous n'obtiendrez pas de meilleur rang ni de points supplémentaires."

translate french strings:


    old "Do you want to skip the quiz?"
    new "Voulez-vous éviter le quiz?"




translate french preepreuve_3eb12593:


    "Une sauvegarde a été effectuée dans l'emplacement 9-1 en guise de sauvegarde."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
