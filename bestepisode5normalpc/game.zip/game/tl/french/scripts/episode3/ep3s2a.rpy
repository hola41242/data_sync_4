


translate french ep3s2a_11692d1a:


    ruby "Mais où est-ce que ça pourrait bien être ? J'étais sûre de les avoir mises ici..."


translate french ep3s2a_f45efed9:


    ruby "Ah, je les trouve pas! Allez... C'est pas comme si je les avais utilisées!"


translate french ep3s2a_c8e09e9f:


    d "Tu cherches quelque chose en particulier ? Besoin d'un coup de main ?"


translate french ep3s2a_4d5c3078:


    ruby "Oh, euh... Non, enfin oui... C'est juste que, tu sais, j'avais des trucs à emmener et... ça a disparu."


translate french ep3s2a_82e7f578:


    d "Tu veux que je t'aide à les chercher?"


translate french ep3s2a_b47d4f38:


    ruby "Non, laisse tomber. Si je continue à chercher, je vais être en retard. On n'a pas toute la journée."


translate french ep3s2a_94cefeaa:


    ruby "J'ai même pas encore déjeuné... Ca va être un marathon aujourd'hui..."


translate french ep3s2a_9e16ac9f:


    ruby "Surtout avec tout ce que j'ai à préparer pour ce soir. Rien n'est prêt, absolument rien!"


translate french ep3s2a_cc397e3f:


    d "Tu as prévu quoi exactement?"


translate french ep3s2a_7186988a:


    ruby "C'est une surprise!"


translate french ep3s2a_c63a6995:


    d "Okay,okay! On verra bien ce soir alors!"


translate french ep3s2a_bd6a0342:


    ruby "C'est ça! Bon, on peut y aller?"


translate french ep3s2a_d8d1b09d:


    d "Heu... T'oublies rien?"


translate french ep3s2a_6b0b0af2:


    ruby "De quoi?"


translate french ep3s2a_3339f33a:


    ruby "Oh... OH !"


translate french ep3s2a_60cfb41d:


    ruby "J'en ai même oublié de m'habiller!"


translate french ep3s2a_9f5cc69e:


    ruby "Tu sais quoi? Donne-moi deux minutes et on va passer par la cafèt! Prendre un petit-déj en speed!"


translate french ep3s2a_ca8a4f56:


    d "Ca me va!"


translate french ep3s2a_27b44026:


    dpense "Elle avait pas dit deux minutes?"


translate french ep3s2a_074aea1e:


    ruby "Okay, je suis prête!"


translate french ep3s2a_bf017898:


    ruby "On y va!"


translate french ep3s2a_0d33e6e7:


    ruby "AH, ça fait du bien!"


translate french ep3s2a_bec598f0:


    d "Ouais, un bon jus de fruit le matin, et on est prêts pour une bonne journée!"


translate french ep3s2a_f8bc6076:


    ruby "Bonne journée, bonne journée... On a cours dans quelques minutes, puis faut que je passe dans ma chambre récupérer ce que j'ai préparé pour la fête."


translate french ep3s2a_6dfa40f3:


    ruby "Et cette après-midi, il me reste à préparer les jeux pour ce soir et m'habiller!"


translate french ep3s2a_5032c97b:


    d "Alors, quelle robe tu penses mettre?"


translate french ep3s2a_e84c5d39:


    ruby "Tu verras bien! Je t'avais dit de choisir!"


translate french ep3s2a_033f2e7d:


    d "Des indices sur les jeux que t'as prévu?"


translate french ep3s2a_53d03f1a:


    ruby "Heu... Non ça serait de la triche!"


translate french ep3s2a_886fed77:


    ruby "Mais t'inquiète pas, t'auras pas le temps de t'ennuyer!"


translate french ep3s2a_7a67eec2:


    d "J'ai déjà hâte!"


translate french ep3s2a_979e7529:


    ruby "Bon, on devrait aller en classe..."


translate french ep3s2a_116b0c41:


    ruby "J'espère que Gabriella sera de bonne humeur!"


translate french ep3s2a_a735b1d5:


    d "Oh! Je t'ai pas dit!"


translate french ep3s2a_2307991b:


    ruby "De quoi?"


translate french ep3s2a_f3ddd5e4:


    d "Je suis tombé sur elle hier soir sur sa moto!"


translate french ep3s2a_351fd21f:


    ruby "Elle a une moto?"


translate french ep3s2a_ae03bbda:


    d "Ouais! Elle a failli m'écraser parce que je faisais pas attention..."


translate french ep3s2a_430c9b2b:


    ruby "Et?"


translate french ep3s2a_3193c1a9:


    d "Ben j'ai fini par avoir son numéro de téléphone!"


translate french ep3s2a_d9ee4a01:


    ruby "Mais non!"


translate french ep3s2a_16e5da27:


    d "Je te jure!"


translate french ep3s2a_d2894bee:


    ruby "Je te l'avais dit! Même le destin essaie de te mettre avec elle!"


translate french ep3s2a_6c1aa172:


    d "Euh t'emballes pas quand même!"


translate french ep3s2a_e1d4fa0d:


    ruby "Ben, c'est juste un contact pour l'instant... Mais on progresse!"


translate french ep3s2a_4e839775:


    ruby "Je devrais me faire appeler Cupidon. Je crois que j'ai un don!"


translate french ep3s2a_f5eeefc8:


    d "Ben voyons!"


translate french ep3s2a_e62774af:


    ruby "Ouais ouais... Tu verras!"


translate french ep3s2a_c739e98c:


    ruby "Bref, j'ai hâte de voir quelle sera la prochaine étape avec elle après!"


translate french ep3s2a_7ccab813:


    d "T'abuses... Y'à pas de prochaine étape... Y'à même pas de première étape!"


translate french ep3s2a_517c3e0c:


    ruby "C'est ce qu'on dit!"


translate french ep3s2a_e862964b:


    ruby "Mais au final t'as le numéro de ta Milf!"


translate french ep3s2a_474f9baa:


    d "Ruby..."

translate french strings:


    old "9:00 AM"
    new "9:00"


    old "Ten minutes later..."
    new "Dix minutes plus tard..."


    old "9:30 AM"
    new "9:30"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
