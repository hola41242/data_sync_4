


translate french ep3s1_4b26bc0b:


    dpense "Hmm... J'ai bien dormi. Aujourd'hui s'annonce chargé, mais je suis prêt."


translate french ep3s1_be8d8a59:


    dpense "Il y a cette grande soirée ce soir. Il faut absolument que je fasse bonne impression. Y'aura plein de gens que je ne connais pas... Heureusement que les filles seront là."


translate french ep3s1_ab10fc20:


    dpense "Ça promet d'être mémorable."


translate french ep3s1_251d6609:


    dpense "Je vais envoyer un message à Julia. Voir comment elle va."


translate french ep3s1_cbf61221:


    dpense "Après ce qu'il s'est passé hier, elle doit pas être bien."


translate french ep3s1_83d877ff:


    dpense "C'est pas surprenant qu'elle reste chez elle un peu."


translate french ep3s1_1ec5d604:


    dpense "Bon allez... On se concentre sur la journée!"


translate french ep3s1_e9a08faa:


    dpense "Ruby s'occupe de la soirée. Peut-être qu'elle voudrait prendre un petit-déjeuner pour faire le plein d'énergie?"


translate french ep3s1_d1c4015e:


    dpense "Le tournoi reprend lundi. Je suis clairement pas au même niveau que les autres... Je devrais peut être aller m'entraîner un peu?"


translate french ep3s1_58decb74:


    dpense "Est ce que je dois aller chercher Grace? Je pense qu'on doit parler... Après hier..."


translate french ep3s1_23383d89:


    dpense "Bon allez, je suis prêt!"

translate french strings:


    old "8:30 AM"
    new "8:30"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
