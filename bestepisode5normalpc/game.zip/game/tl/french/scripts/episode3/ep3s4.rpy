


translate french Training2_2314b734:


    dpense "Plante ton pied dans le sol..."


translate french Training2_6a4e888c:


    dpense "Si je veux marquer, je dois mettre plus de force dedans..."


translate french Training2_dbd94726:


    ji "HEY!" with vpunch


translate french Training2_62e760ef:


    ji "Si tu veux gagner, va falloir faire mieux que ça hein!"


translate french Training2_f7499b79:


    ji "Passe moi la balle!"


translate french Training2_cba91d2b:


    ji "Et regarde ça!"


translate french Training2_43398bf1:


    d "Qu'est ce que..."


translate french Training2_0144d7f9:


    d "Hum?"


translate french Training2_d83c8599:


    d "Mais..."


translate french Training2_62ecd993:


    d "Qui es tu?"


translate french Training2_c2e66dfd:


    ji "Savoir mon prénom ne t'avancerait à rien."


translate french Training2_5e4b894c:


    ji "Continues de t'entraîner parce que j'ai hâte de jouer contre toi!"


translate french Training2_8926922d:


    ji "On se voit en finale..."


translate french Training2_9d7f15ed:


    ji "Si tu y arrives..."


translate french Training2_e8e8e63a:


    d "O...kay..."


translate french Training2_7994d614:


    dpense "Il va vraiment falloir s'améliorer..."


translate french Training2_08535ece:


    dpense "Cette fille a une de ces frappes..."


translate french Training2_ce2cd1a5:


    dpense "J'ai quasiment senti le vent tourner autour de la balle..."


translate french Training2_86048621:


    dpense "Allez... On y retourne!"


translate french Chambreep3_7d909d2f:


    dpense "Hummm... Il est quelle heure?"


translate french Chambreep3_cb1c8beb:


    dpense "17:30"


translate french Chambreep3_2aa2e6be:


    dpense "Je vais pas tarder à y aller..."


translate french Chambreep3_ed39d6a5:


    dpense "Je devrais peut être envoyer un message à Elise avant de partir..."


translate french Chambreep3_37e64b70:


    dpense "..."


translate french Chambreep3_6f5ea18e:


    dpense "Pas de réponse?"


translate french Chambreep3_5284f567:


    dpense "C'est bizarre... D'habitude elle répond dans les trois secondes..."


translate french Chambreep3_9c2712db:


    dpense "Est ce que quelqu'un pourrait avoir besoin de quelque chose?"


translate french Chambreep3_68c57ca6:


    dpense "Ruby doit être occupée... Mieux vaut la laisser tranquille..."


translate french Chambreep3_0d47971e:


    dpense "A qui je devrais envoyer un message?"


translate french gracephoneep3s4_7cd0dad9:


    dpense "Ces lèvres..."


translate french gracephoneep3s4_40bf0c88:


    dpense "Bon, on dirait que ça se passe bien..."


translate french juliaphoneep3s4_bffc964b:


    dpense "J'espère que ça ira pour elle ce soir..."


translate french madphoneep3s4_4c58dcba:


    dpense "Je suis un idiot, elle a dit qu'elle avait sa fille..."


translate french madphoneep3s4_fda3813c:


    dpense "Elle doit être souvent occupée..."


translate french madphoneep3s4_99f61674:


    dpense "Va falloir que je change d'approche avec elle..."


translate french bluephoneep3s4_28c2d9c9:


    dpense "Elle a vraiment changé..."


translate french bluephoneep3s4_02a7ab74:


    dpense "Il s'est passé quelque chose..."


translate french gabyphoneep3s4_d5bafb7c:


    dpense "Bon ben... Au moins j'aurais vérifié!"


translate french gabyphoneep3s4_6ba6c89d:


    dpense "Faut pas que j'oublie ma non-date avec elle demain..."


translate french gabyphoneep3s4_f008a47b:


    dpense "Sinon elle va me tuer!"


translate french departsoiree_bd5a3951:


    dpense "Allez, on y va!"


translate french departsoiree_2a7b2a88:


    dpense "Charlotte m'a demandé de passer avant la fête..."


translate french ArriveeFete_d10b0838:


    d "Maintenant... La fête!"


translate french ArriveeFete_af385284:


    d "C'est parti..."


translate french Charlottetime_44050cec:


    dpense "C'est fermé..."


translate french Charlottetime_f423db45:


    dpense "Les lumières sont allumées..."


translate french Charlottetime_37b557c2:


    dpense "Elle a dit qu'elle avait des trucs à compter je crois..."


translate french Charlottetime_5df73d10:


    dpense "Y'à peut être une porte derrière?"


translate french Charlottetime_8b1242bd:


    dpense "Ah ben voilà..."


translate french Charlottetime_a3d61da9:


    dpense "C'est ouvert."


translate french Charlottetime_017bee57:


    d "Alors c'est là que tu te caches?"


translate french Charlottetime_c3e5e858:


    cha "Hein?"


translate french Charlottetime_641b24ec:


    cha "Ahhhh!"


translate french Charlottetime_b31d7873:


    d "T'inquiète pas! Je choppe ça! ... Heu... Je te choppe toi!"


translate french Charlottetime_bfd3fd79:


    cha "Oh?"


translate french Charlottetime_99c90c60:


    cha "Tu m'as fait peur!"


translate french Charlottetime_c8863a0d:


    d "Désolé! Ce n'était pas mon intention."


translate french Charlottetime_fca708e0:


    cha "T'es à l'aise là?"


translate french Charlottetime_2c3a63c7:


    d "Comment ça?"


translate french Charlottetime_0ebfde79:


    cha "Tu peux lâcher mes seins, tu sais..."


translate french Charlottetime_a2a9798e:


    d "Oh! Oui... Pardon!"


translate french Charlottetime_2e1075ac:


    cha "Attend, tant que t'es là. Tiens-moi. Je dois compter l'arrière de l'étagère."


translate french Charlottetime_d93e0955:


    d "Heu... Ouais, okay."


translate french Charlottetime_cfa70a59:


    cha "Tiens-moi bien hein!"


translate french Charlottetime_b82983f4:


    d "Oui oui!"


translate french Charlottetime_46359b02:


    dpense "Quel cul!"


translate french Charlottetime_3957d45a:


    dpense "Nan mais attends..."


translate french Charlottetime_b4475d8b:


    dpense "Elle porte pas de culotte?" with hpunch


translate french Charlottetime_e11f72be:


    dpense "Elle l'a fait exprès, c'est pas possible..."


translate french Charlottetime_eafe9e61:


    cha "Attends, faut que je me penche un peu plus pour voir l'arrière..."


translate french Charlottetime_e9fcb1fb:


    dpense "Elle est sérieuse?"


translate french Charlottetime_9b0004ac:


    dpense "Elle veut jouer..."


translate french Charlottetime_53e24e7b:


    dpense "Alors on va jouer!"


translate french Charlottetime_bfd3fd79_1:


    cha "Oh?"


translate french Charlottetime_e7fc63f0:


    cha "Qu'est ce que... ?"


translate french Charlottetime_385ef974:


    cha "Ah!"


translate french Charlottetime_98998053:


    cha "Hummmm..."


translate french Charlottetime_38e5071e:


    cha "Oui... Vas y..."


translate french Charlottetime_a1818eb0:


    cha "Je savais que tu allais apprécier la vue..."


translate french Charlottetime_215da4ac:


    cha "Je pensais bien que tu... Humpffff..."


translate french Charlottetime_a6aeabed:


    cha "Saurais prendre ta chance.... Haaa..."


translate french Charlottetime_38954f7f:


    cha "T'es vraiment bon à ça.... ohhhh!"


translate french Charlottetime_11bbaae7:


    cha "Oui! Juste là!"


translate french Charlottetime_64c167b7:


    cha "Vas-y! Bouffe-moi cette chatte!"


translate french Charlottetime_4cd519e2:


    cha "Oh mon dieu c'est trop bon..."


translate french Charlottetime_c4c6380f:


    dpense "Elle mouille à mort..."


translate french Charlottetime_e5d1a0b8:


    dpense "Je pensais pas arriver à lécher la chatte d'une femme comme ça..."


translate french Charlottetime_30c9594f:


    dpense "J'adore son goût..."


translate french Charlottetime_5bd1f2d3:


    dpense "J'ai jamais eu une femme comme ça dans ma vie..."


translate french Charlottetime_38a2c2e0:


    dpense "Tellement excitée..."


translate french Charlottetime_ace19207:


    cha "Okay big boy."


translate french Charlottetime_bf324701:


    cha "Montre-moi ce que tu sais faire."


translate french Charlottetime_f7e912e8:


    cha "Vire-moi ces vêtements que je puisse apprécier ce corps si tentant!"


translate french Charlottetime_d40c7883:


    cha "Ouaiiiiiiis... C'est bien ce que je pensais..."


translate french Charlottetime_f83572f2:


    cha "Si musclé..."


translate french Charlottetime_f40ea147:


    cha "Et tu sens bon."


translate french Charlottetime_602fd819:


    cha "Je..."


translate french Charlottetime_6b46261d:


    d "Assez parlé!"


translate french Charlottetime_139f3ef4:


    cha "Whaaa!"


translate french Charlottetime_d0858423:


    cha "T'aimes prendre les choses en main?"


translate french Charlottetime_df64e08e:


    d "Je suis pas là pour faire la causette..."


translate french Charlottetime_7627c9c7:


    d "Je crois qu'il est temps de libérer ces deux beautés de leur prison."


translate french Charlottetime_b04ed3cd:


    d "Putain, ça c'est une paire de seins!"


translate french Charlottetime_c085c6c5:


    cha "Oui... Vas-y... joue avec eux..."


translate french Charlottetime_6d716f8d:


    d "J'ai pas le temps de jouer..."


translate french Charlottetime_15b5a1b0:


    d "Tu voulais un jeune homme vigoureux..."


translate french Charlottetime_eb5c5535:


    d "Le voilà..."


translate french Charlottetime_fc3eeae2:


    cha "Ahhhhhhh! T'es bien plus qu'un jeune homme en bas!"


translate french Charlottetime_8ee6bc76:


    cha "Ahhh..."


translate french Charlottetime_a5dfa887:


    cha "Ouiiii... Je te sens bien là.... Tu remplis ma petite chatte serrée..."


translate french Charlottetime_80e8641c:


    dpense "C'est vrai que c'est serré..."


translate french Charlottetime_44684764:


    cha "Vas y [name]! Défonce-moi!"


translate french Charlottetime_1f3544ea:


    cha "Vas-y plus fort!"


translate french Charlottetime_7eb1ed65:


    d "Prend ça tiens!"


translate french Charlottetime_be561219:


    cha "Oh mon dieu! Oh mon dieu! Oh mon dieu!"


translate french Charlottetime_f18aa612:


    d "Tu l'as voulu!"


translate french Charlottetime_09fa1492:


    cha "Oui! Oui! J'en veux plus! Encore!"


translate french Charlottetime_3951848a:


    d "Je viens!"


translate french Charlottetime_fac14cdd:


    cha "Moi aussi!!!"


translate french Charlottetime_fd6d20bb:


    d "Tourne-toi je vais jouir sur ton cul!"


translate french Charlottetime_f8d931fa:


    cha "Vas-y donne moi ton sperme tout chaud [name]! "


translate french Charlottetime_85a345ef:


    cha "Je veux le sentir sur ma peau!"


translate french Charlottetime_b4461efb:


    d "Ahhhhhhh !!!"


translate french Charlottetime_85f0a600:


    d "Putain, c'était bon!"


translate french Charlottetime_87137957:


    cha "Ouais..."


translate french Charlottetime_d91aadfa:


    cha "Je me sens un peu vide maintenant..."


translate french Charlottetime_6e5b9427:


    d "Ca tombe bien! C'est pas fini!"


translate french Charlottetime_363cd597:


    cha "De quoi?"


translate french Charlottetime_36f25c9c:


    cha "MON CUL!"


translate french Charlottetime_18b75d90:


    cha "Fais attention... Je..."


translate french Charlottetime_4f482ae4:


    cha "Ahhhh! Putainnnnnnnnn!"


translate french Charlottetime_f9f78226:


    cha "Oh mon dieu! T'es vraiment en train de m'éclater le cul là!"


translate french Charlottetime_3271d50d:


    cha "Baise-moi le cul [name]! Vas-y! Putainnnnnnn!"


translate french Charlottetime_93db56f7:


    cha "T'en as encore en réserve..."


translate french Charlottetime_258c8329:


    cha "ET t'es toujours dûr!"


translate french Charlottetime_7ab6f1b2:


    d "Je vais pas tenir longtemps! T'es tellement serrée!"


translate french Charlottetime_3414f046:


    cha "Jouis-en moi!"


translate french Charlottetime_b78a309b:


    cha "Remplis-moi le cul!"


translate french Charlottetime_8c9fa616:


    d "Ahhhhhhhhhhh!"


translate french Charlottetime_bf1e921f:


    cha "Ahhhhhhhhhhhhhhhhh!"


translate french Charlottetime_933cc1f7:


    cha "Je jouis du culllllllllllll!!!"


translate french Charlottetime_31a9b907:


    d "Wooo... C'est ce que j'appelle un joli trou!"


translate french Charlottetime_f8e2e91c:


    cha "Je sais pas si je vais pouvoir m'asseoir aujourd'hui..."


translate french Charlottetime_6bba4eab:


    d "Je peux pas rester, je dois..."


translate french Charlottetime_dd5f6d96:


    cha "Ouais, ouais..."


translate french Charlottetime_17dba0b7:


    cha "Va à ta fête..."


translate french Charlottetime_aee3450e:


    cha "A plus tard!"


translate french Charlottetime_f1c77c07:


    d "Ouais! A plus!"


translate french Charlottetime_f272ff3b:


    cha "Pas tout de suite..."

translate french strings:


    old "14:30"
    new "14:30"


    old "17:30"
    new "17:30"


    old "Hey! Are you awake?"
    new "Hey! T'es réveillée?"


    old "Blue"
    new "Bleue"


    old "Pass"
    new "Passer"


    old "You guys doing okay?"
    new "Vous vous en sortez?"


    old "Yeah, we're good! We're almost done :)"
    new "Ouais ça va! On a presque fini!"


    old "You need anything?"
    new "Vous avez besoin de quelque chose?"


    old "Nope!"
    new "Nan nan!"


    old "Ruby thought of everything as usual!"
    new "Ruby a pensé à tout comme d'hab!"


    old "Okay... Well, see you later then!"
    new "Okay... Bon ben à tout à l'heure alors!"


    old "Yes! See you later!"
    new "Oui! A tout à l'heure!"


    old "I can't wait to see you already!"
    new "J'ai déjà hâte à ce que tu arrives!"


    old "Feeling better?"
    new "Ca va mieux?"


    old "Still a bit of back pain, but I'm okay..."
    new "Toujours un peu mal mais ça va..."


    old "If you need massages, I'm here!"
    new "Si t'as besoin de massages je suis là hein!"


    old "Haha! No, it's okay!"
    new "Haha! Non ça va!"


    old "I'm getting ready for tonight..."
    new "Je me prépare pour ce soir..."


    old "Well, don't hesitate if you need anything!"
    new "Ben hésite pas à demander si t'as besoin de quelque chose !"


    old "I'll remember that!"
    new "Je m'en souviendrais!"


    old "See you tonight!"
    new "A ce soir!"


    old "Are you ready for tonight?"
    new "T'es prête pour ce soir?"


    old "I'm not even dressed yet..."
    new "Je suis même pas encore habillée..."


    old "Seriously?"
    new "Sérieusement?"


    old "Stay like that, it works for me!"
    new "Reste comme ça, moi ça me va!"


    old "If only I could..."
    new "Si seulement je pouvais..."


    old "I won't bother you any longer then!"
    new "Je t'embête pas plus longtemps alors!"


    old "Oh, you're not bothering me!"
    new "Oh, tu m'embêtes pas!"


    old "Tease!"
    new "Allumeuse!"


    old "You have no idea how much!"
    new "T'as pas idée!"


    old "Alright, see you later!"
    new "Allez, à tout à l'heure!"


    old "See you later!"
    new "A tout à l'heure!"


    old "Join her"
    new "La rejoindre"


    old "Or not"
    new "Ou pas"




translate french Chambreep3_3a83ddfa:


    dpense "Oh! Y'à une mise à jour de mon téléphone!"


translate french Chambreep3_5e298433:


    dpense "Nouvelle fonctionnalité: Envoyez des messages via l'application contacts!"


translate french Chambreep3_ec2c1d7a:


    dpense "Okay je vais essayer..."


translate french Charlottetime_9b93c49a:


    cha "Quoi?" with hpunch

translate french strings:


    old "Join her[TEMP1!t]"
    new "La rejoindre[TEMP1!t]"


    old "Or not[TEMP2!t]"
    new "Ou pas[TEMP2!t]"



translate french strings:


    old "A wallpaper has been added"
    new "Un wallpaper a été ajouté!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
