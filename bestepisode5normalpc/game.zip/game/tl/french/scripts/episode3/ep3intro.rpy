


translate french ep3intro_6a95f5af:


    "Regardez comme elles sont jolies toutes les deux. On dirait de vraies petites princesses."


translate french ep3intro_d52a2d2f:


    "Elles sont magnifiques. Mais comment allons-nous les appeler ? Avoir deux miracles en même temps, je n'y étais pas préparé."


translate french ep3intro_17e52c09:


    "Et si on nommait cette petite reine Elizabeth ? Cela te va ?"


translate french ep3intro_5155ce6b:


    "Elizabeth... Oui, c'est parfait. Et pour sa sœur... Que dirais-tu de Sofia ? Un nom tout aussi royal."


translate french ep3intro_d059f665:


    "Sofia, regarde comme ta sœur manie bien son vélo. Prends exemple sur elle, tu verras, c'est facile. Elle est vraiment plus forte que toi."


translate french ep3intro_db1f4100:


    "Sofia, pourquoi toujours ce bleu ? On dirait un garçon ! Ta sœur au moins a choisi le rouge !"


translate french ep3intro_63a49d35:


    "Sofia, tu as encore choisi le bleu pour ton dessin ? Regarde les couleurs que ta sœur utilise, elles sont si... vivantes."


translate french ep3intro_ae6a403c:


    sofia "Pourquoi on me compare toujours à elle..."


translate french ep3intro_1abbf48a:


    "Sofia, tu dois apprendre à t'adapter un peu plus. Regarde Elizabeth, elle a tout pour elle."


translate french ep3intro_26f7887d:


    sofia "Laissez-moi… Je veux juste... Etre moi…"


translate french ep3intro_525bb56e:


    "Sofia, Sofia !!!"


translate french ep3intro_c5f6d561:


    "Plus forte que toi… "


translate french ep3intro_4433515c:


    "Sofia!"


translate french ep3intro_4433515c_1:


    "Sofia!"


translate french ep3intro_6b34e089:


    beth "Sofia! Dépêche-toi, on va être en retard!"


translate french ep3intro_14fabf4a:


    sofia "Oui ! J'arrive…"

translate french strings:


    old "EPISODE 3 {p} \n Let's get it started!"
    new "EPISODE 3 {p} \n C'est parti! "


    old "8:00 AM"
    new "8:00"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
