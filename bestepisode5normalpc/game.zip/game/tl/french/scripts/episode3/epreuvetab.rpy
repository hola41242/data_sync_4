

translate french strings:


    old "The Colossus of Rhodes"
    new "Le colosse de Rhodes"


    old "The Great Pyramid of Giza[TEMP1!t]"
    new "La Grande Pyramide de Gizeh[TEMP1!t]"


    old "The Lighthouse of Alexandria"
    new "Le Phare d'Alexandrie"


    old "The Temple of Artemis"
    new "Le Temple d'Artémis"


    old "The Queen of Clubs[TEMP1!t]"
    new "La Reine de Trèfle[TEMP1!t]"


    old "The Queen of Spades"
    new "La Reine de Pique"


    old "The Queen of Hearts"
    new "La Reine de Coeur"


    old "The Queen of Diamonds"
    new "La reine de Carreau"


    old "J. R. R. Tolkien"
    new "J. R. R. Tolkien"


    old "George R. R. Martin"
    new "George R. R. Martin"


    old "George Orwell[TEMP1!t]"
    new "George Orwell[TEMP1!t]"


    old "Stephen King"
    new "Stephen King"


    old "Internet Explorer"
    new "Internet Explorer"


    old "Mosaic[TEMP1!t]"
    new "Mosaic[TEMP1!t]"


    old "Netscape Navigator"
    new "Netscape Navigator"


    old "Google Chrome"
    new "Google Chrome"


    old "Canberra[TEMP1!t]"
    new "Canberra[TEMP1!t]"


    old "Sydney"
    new "Sydney"


    old "Melbourne"
    new "Melbourne"


    old "Perth"
    new "Perth"


    old "Mona Lisa"
    new "Mona Lisa"


    old "Aya Brea"
    new "Aya Brea"


    old "Lara Croft[TEMP1!t]"
    new "Lara Croft[TEMP1!t]"


    old "Katniss Everdeen"
    new "Katniss Everdeen"


    old "Violet[TEMP1!t]"
    new "Violet[TEMP1!t]"


    old "Orange"
    new "Orange"


    old "Green"
    new "Vert"


    old "Pink"
    new "Rose"



translate french strings:


    old "What is the only Wonder of the ancient world still visible?"
    new "Quelle est la dernière Merveille du Monde Antique encore visible?"


    old "In a traditional deck of cards,\nwhich queen holds her scepter with both hands?"
    new "Dans un jeu de cartes traditionnel,\nquelle reine porte son sceptre avec les deux mains?"


    old "Who wrote '1984'?"
    new "Qui a écrit '1984'?"


    old "What is the missing number?\n16 06 68 88 ?? 98"
    new "Quel est le chiffre manquant?\n16 06 68 88 ?? 98"


    old "What was the name of the first widely available web browser?"
    new "Quel était le nom du premier navigateur Internet?"


    old "What is the capital of Australia?"
    new "Quelle est la capitale de l'Australie?"


    old "Who is hidden behind this image?"
    new "Qui est cachée derrière cette image?"


    old "If you mix red and blue,\nwhat color do you get?"
    new "Si vous mélangez du rouge et du bleu,\nquelle couleur obtenez-vous?"


    old "Press the POINT"
    new "Appuyez sur le POINT"


    old "The answer is obvious"
    new "La réponse est evidente"



translate french strings:


    old "You finished on time! Your score is [score] / 10."
    new "Vous avez fini à temps! Votre score est de [score] / 10."


    old "You did not finish on time. Your score is [score] / 10."
    new "Vous n'avez pas fini à temps. Votre score est [score] / 10."


    old "Your new rank is :"
    new "Votre nouveau rang est:"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
