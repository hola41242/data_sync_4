


translate french bluebathsequence_bfc258f4:


    sofia "Te voilà..."


translate french bluebathsequence_640cb0b2:


    sofia "Dépêche-toi, on a pas beaucoup de temps..."


translate french bluebathsequence_39a0fffb:


    sofia "Ah!"


translate french bluebathsequence_eaf3c1ee:


    d "C'est ça que tu veux?"


translate french bluebathsequence_5b2496bc:


    dpense "Elle est toujours si demandeuse..."


translate french bluebathsequence_e5f0d377:


    sofia "Ce que je veux..."


translate french bluebathsequence_50fca145:


    sofia "Je veux un homme..."


translate french bluebathsequence_99fba79e:


    sofia "Qui sache me prendre..."


translate french bluebathsequence_65a81c4a:


    sofia "Me diriger..."


translate french bluebathsequence_6ef36208:


    sofia "AH!"


translate french bluebathsequence_3b78e516:


    dpense "Elle me rend fou..."


translate french bluebathsequence_c50c170c:


    d "T'es déjà excitée avant me^me d'avoir commencé..."


translate french bluebathsequence_d9512405:


    sofia "Je suis excitée depuis que tu m'as fait jouir... Dans l'amphi... "


translate french bluebathsequence_c48e54c4:


    sofia "Depuis que j'ai senti tes doigts..."


translate french bluebathsequence_5b26181d:


    d "Ces doigts?"


translate french bluebathsequence_5a262f9a:


    dpense "J'adore comment elle réagit..."


translate french bluebathsequence_2f26ac84:


    sofia "Hmmm..."


translate french bluebathsequence_cf4f776b:


    d "T'es trempée!"


translate french bluebathsequence_0b8370ab:


    sofia "Je te l'ai dit!"


translate french bluebathsequence_74d543c4:


    sofia "Mais c'est pas tes doigts que je veux aujourd'hui!"


translate french bluebathsequence_abc5915a:


    sofia "Je veux ta queue!"


translate french bluebathsequence_5707bfa6:


    sofia "Alors dépêche-toi, on a plus beaucoup de temps!"


translate french bluebathsequence_6c2ebf4b:


    d "Laisse-moi tirer ça..."


translate french bluebathsequence_b7c5a512:


    sofia "Vas-y!"


translate french bluebathsequence_56afc663:


    dpense "C'est tellement mouillé, ça rentre tout seul..."


translate french bluebathsequence_2f26ac84_1:


    sofia "Hmm..."


translate french bluebathsequence_79cf69e9:


    sofia "Continue..."


translate french bluebathsequence_ebb813c0:


    sofia "Comme ça!"


translate french bluebathsequence_47efd07c:


    sofia "Oh mon dieu, ça fait du bien..."


translate french bluebathsequence_0bd2f923:


    dpense "Elle est incroyable..."


translate french bluebathsequence_56849dc7:


    sofia "Je te sens bien au fond de moi..."


translate french bluebathsequence_a26bcf05:


    sofia "Ohhhhhhhhh"


translate french bluebathsequence_fc4c4d59:


    sofia "Encore! Encore!"


translate french bluebathsequence_021156c2:


    sofia "Plus vite!"


translate french bluebathsequence_33fabc63:


    sofia "Plus fort!"


translate french bluebathsequence_eb8f7bf6:


    dpense "Elle est tarée!"


translate french bluebathsequence_56d2001c:


    sofia "Vas y, je sens que je viens."


translate french bluebathsequence_312c0410:


    d "Moi aussi, je sens que j'arrive."


translate french bluebathsequence_944ded0c:


    sofia "Je veux te sentir... En moi! Vas-y!"


translate french bluebathsequence_420528c9:


    sofia "Remplis-moi!"


translate french bluebathsequence_d75056be:


    sofia "Ouiiiii! Je te sens grossir!!!"


translate french bluebathsequence_dad3c95e:


    d "Ahhhhhhhhhhh !!!"


translate french bluebathsequence_6a936112:


    dpense "C'est si bon..."


translate french bluebathsequence_3eb7df3c:


    sofia "Oh mon dieu!!!"


translate french bluebathsequence_fb6a33b0:


    sofia "Ca fait tellement de bien..."


translate french bluebathsequence_541b1006:


    sofia "Tu peux faire ce que tu veux de moi..."


translate french bluebathsequence_925c17d4:


    sofia "Je suis tienne..."


translate french bluebathsequence_4971b75a:


    sofia "Wow... C'était intense..."


translate french bluebathsequence_24a08cec:


    dpense "C'était tellement génial, j'arrive pas à y croire..."


translate french bluebathsequence_1774c03c:


    sofia "Va rejoindre les autres..."


translate french bluebathsequence_2aa95cae:


    sofia "Je te vois plus tard..."


translate french bluebathsequence_d5fa7ba5:


    dpense "J'ai déjà hâte à la prochaine fois..."


translate french freepokersequence_c2938bd3:


    emerick "Ah, ben enfin..."


translate french freepokersequence_cf8678ec:


    emerick "Le gars réussit à s'inviter et en plus il prend son temps..."


translate french freepokersequence_24dcd6cc:


    emerick "J'espère qu'au moins tu sais jouer..."


translate french freepokersequence_32415610:


    emerick "On commence avec 1000 dollars... On mise toujours un minimum de 100 quand on veut commencer, pas de check."


translate french freepokersequence_e8a73106:


    emerick "On ne peut raise qu'une fois, on va pas au dessus de 200."


translate french freepokersequence_04aa1bf5:


    emerick "On joue au Texas Hold'em: 2 cartes en mains, 5 sur le board. Tu connais où t'as besoin qu'on t'explique les règles?"


translate french freepokersequence_07fcd65a:


    d "Tu peux rafraîchir ma mémoire? Ca fait un bail que j'ai pas joué..."


translate french freepokersequence_36279863:


    emerick "Rouge, tu peux lui expliquer?"


translate french freepokersequence_a9c4bc36:


    beth "Okay, c'est parti pour le premier tour de jeu, je vais lui expliquer en même temps..."


translate french freepokersequence_ec5fc430:


    d "T'inquiètes, je sais jouer."


translate french freepokersequence_54d07f02:


    emerick "Bien! On va voir ça!"


translate french firsthand_e86a8a7a:


    dpense "Sept et deux..."


translate french firsthand_ceb191ba:


    beth "Tu peux choisir de miser 100 pour jouer ou passer..."


translate french firsthand_212cc397:


    beth "Sept et deux est la pire main que tu puisses avoir... Passe ce sera plus simple."


translate french firsthand_4d9cec0f:


    beth "Attendons une meilleure main."


translate french raisefirst_4af3fef4:


    d "Hum..."


translate french raisefirst_da6cdede:


    d "Je mise 100."


translate french raisefirst_a8f7e65c:


    emerick "Je suis..."


translate french raisefirst_dee9a1f0:


    hec "Je passe..."


translate french raisefirst_73612da1:


    ben "Je passe..."


translate french raisefirst_e963ac4e:


    mac "Je suis..."


translate french raisefirst_cbfb1f43:


    beth "Le board..."


translate french raisefirst_360c9b51:


    beth "Sept de coeurs. Roi de piques. Reine de trèfles."


translate french raisefirst_ac0535ba:


    dpense "J'ai une paire de sept..."


translate french raisefirst_27738fbb:


    dpense "Mais le roi et la reine..."


translate french raisefirst_cd216665:


    emerick "Pas mal..."


translate french raisefirst_04e21e0e:


    mac "Hmm..."


translate french raisefirst_bb544eb2:


    dpense "C'est à mon tour de parler en premier."


translate french foldfirst_86a9bfaa:


    d "Je passe."


translate french foldfirst_42175e86:


    emerick "Ah! Ca passe déjà..."


translate french foldfirst_6ac4b55b:


    d "J'attends un peu avant de te plumer..."


translate french foldfirst_e75f4463:


    emerick "Ouais ouais, bien sûr!"


translate french betfirst_507e59b5:


    d "Je mise 100..."


translate french betfirst_a8f7e65c:


    emerick "Je suis..."


translate french betfirst_e963ac4e:


    mac "Je suis..."


translate french betfirst_1ca60585:


    beth "La turn..."


translate french betfirst_efb4200a:


    beth "Deux de coeurs"


translate french betfirst_85a67f5b:


    dpense "J'ai deux paires maintenant."


translate french betfirst_84464fb5:


    emerick "Une brique..."


translate french betfirst_d30b2f3d:


    mac "Tu parles trop sérieux!"


translate french betfirst_d6926074:


    emerick "Ah ouais? Ca te dérange?"


translate french betfirst_92675bce:


    mac "Non, non..."


translate french betfirstturn_507e59b5:


    d "Je mise 100..."


translate french betfirstturn_bf39ee43:


    emerick "Je raise..."


translate french betfirstturn_01952dec:


    mac "Je suis..."


translate french callraiseturnfirst_d4af3017:


    d "Je suis..."


translate french callraiseturnfirst_7312aa2f:


    dpense "Allez... La river..."


translate french callraiseturnfirst_43774c19:


    beth "Et la river."


translate french callraiseturnfirst_86e388f5:


    beth "Huit de trèfles."


translate french callraiseturnfirst_72054f19:


    dpense "Un huit... Ca m'aide pas beaucoup."


translate french callraiseturnfirst_cf34f265:


    dpense "J'ai toujours deux paires..."


translate french betfirstriver_507e59b5:


    d "Je mise 100..."


translate french betfirstriver_bf39ee43:


    emerick "Je raise..."


translate french betfirstriver_4857b6aa:


    mac "Je passe..."


translate french betfirstriver_6aae5fac:


    emerick "Ah ben voilà! Monsieur le Pro qui passe!"


translate french betfirstriver_98b0aa51:


    mac "..."


translate french betfirstriver_3f18fd8f:


    emerick "Et toi, Frenchie?"


translate french betfirstriver_5c342d8e:


    emerick "Tu suis ou tu te couches comme Mac?"


translate french endfirst_585c495f:


    d "Je suis!"


translate french endfirst_1ddc9ab4:


    emerick "Bien!"


translate french endfirst_0123b601:


    beth "Les gars, montrez vos cartes!"


translate french endfirst_9af984ce:


    emerick "Deux paires, Roi-Dame!"


translate french endfirst_a9039faa:


    d "Merde..."


translate french endfirst_57a20cf5:


    hec "Sept et deux..."


translate french endfirst_855e48ca:


    ben "Pffft..."


translate french endfirst_29ac5843:


    d "Ben quoi?"


translate french endfirst_a44c39cf:


    mac "Rien, rien..."


translate french endfirst_d866667e:


    emerick "C'est un bon début!"


translate french secondhand_a25952de:


    ben "C'est pas possible d'avoir autant de chatte!" with hpunch


translate french secondhand_71235bca:


    emerick "C'est le jeu, Ben!"


translate french secondhand_7bdb1b2e:


    ben "Ouais, ouais... Bon, j'y vais moi les gars!"


translate french secondhand_53648650:


    mac "Bonne nuit, Ben!"


translate french secondhand_f6ff6b04:


    hec "Nuit..."


translate french secondhand_5617520a:


    emerick "Allez les gars, il vous reste combien?"


translate french secondhand_dcb8ab17:


    hec "400..."


translate french secondhand_7607269e:


    dpense "J'ai [moneypoker]$..."


translate french secondhand_723b2ccf:


    dpense "Faut que je gère avec ça."


translate french secondhand_92d4ec21:


    d "[moneypoker]..."


translate french secondhand_bfb72c89:


    emerick "Et toi, Mac?"


translate french secondhand_7af6f01b:


    mac "Je reste aux alentours des 1000 depuis le début..."


translate french secondhand_51a2c941:


    emerick "Allez on continue!"


translate french secondhand_acb6662d:


    dpense "Les As!"


translate french secondhand_309b2606:


    dpense "Là c'est intéressant!"


translate french secondhand_cfb4069e:


    beth "T'as la meilleure main du jeu."


translate french secondhand_d2c68232:


    beth "Tu dois miser quand t'as l'avantage."


translate french secondhand_9ffa980a:


    beth "Tu parles en dernier, regardons d'abord ce que vont faire les autres..."


translate french secondhand_29aafa4e:


    emerick "Je mise 100!"


translate french secondhand_534589df:


    hec "Je suis..."


translate french secondhand_2abf8722:


    mac "Je suis..."


translate french secondhand_4a9c96af:


    beth "Vas-y, enchérit!"


translate french callsecond_d4af3017:


    d "Je suis..."


translate french callsecond_a0eff481:


    beth "Mouais... Au moins ils te verront pas venir..."


translate french foldsecond_5853f4b8:


    d "Je les sens pas..."


translate french foldsecond_8cd9bc60:


    beth "T'es sérieux?"


translate french foldsecond_29ac5843:


    d "Quoi?"


translate french foldsecond_0d45e5bf:


    beth "Nan rien..."


translate french raisesecond_5449efcb:


    d "Je raise!"


translate french raisesecond_72f87a6e:


    beth "Parfait."


translate french raisesecond_b2b546ab:


    emerick "Je suis..."


translate french raisesecond_534589df:


    hec "Je suis..."


translate french raisesecond_2abf8722:


    mac "Je suis..."


translate french boardsecond_71d323cf:


    beth "Le board..."


translate french boardsecond_8c073ec8:


    beth "Neuf de trèfles. Valet de piques. Dame de piques."


translate french boardsecond_4eadc122:


    dpense "Hmmmm..."


translate french boardsecond_5b5e5b81:


    beth "Ouais... le board est pas en ta faveur... Neuf-Valet-Dame..."


translate french boardsecond_18a9af10:


    beth "T'es déjà battu par deux paires, brelans, quinte... Y'à même une couleur qui se profile..."


translate french boardsecond_1a210212:


    beth "Attends devoir ce que font les autres..."


translate french boardsecond_29aafa4e:


    emerick "Je mise 100!"


translate french boardsecond_d222b261:


    hec "Tapis!"


translate french boardsecond_f0146759:


    emerick "Oh-oh! Quelqu'un a une main ici!"


translate french boardsecond_0b44c64a:


    mac "Je passe."


translate french boardsecond_a170c960:


    dpense "Qu'est ce que je fais?"


translate french boardsecond_8a805c56:


    beth "Passe... Ca sent pas bon..."


translate french boardsecond_f487f85b:


    beth "Au poker, quand t'as un doute... C'est que y'à pas de doutes..."


translate french boardsecond_130fe238:


    beth "T'es clairement pas en bonne position..."


translate french boardsecond_7bf7d14d:


    beth "Garde ce qu'il te reste, tu auras tout le temps de remonter..."


translate french boardsecond_bdc68931:


    d "All in!"


translate french boardsecond_585c495f:


    d "Je suis!"


translate french boardsecond_9cff1cb6:


    emerick "Je suis!"


translate french boardsecond_bdc68931_1:


    d "All in!"


translate french boardsecond_5449efcb:


    d "Je raise!"


translate french boardsecond_9cff1cb6_1:


    emerick "Je call!"


translate french boardsecond_7404b6d9:


    d "Je passe..."


translate french boardsecond_f7de9063:


    emerick "Bon Hector est all in... Montre ta main!"


translate french boardsecond_1d55aa40:


    hec "Brelan de neuf!"


translate french boardsecond_c2596d04:


    emerick "Oh ouais!"


translate french boardsecond_8b385b22:


    emerick "Pas mal... J'ai Roi-Valet..."


translate french boardsecond_d95b091a:


    sofia "Voici la turn..."


translate french boardsecond_2e8a73d2:


    sofia "Deux de coeurs..."


translate french boardsecond_9eeb175e:


    emerick "T'es toujours bon Hector!"


translate french boardsecond_ebe96f90:


    hec "Pas de bad beat... Pas de bad beat..."


translate french boardsecond_65c54f8c:


    emerick "Allez! On veut la river!"


translate french boardsecond_25e4f758:


    sofia "Et voici la river..."


translate french boardsecond_70ddf0f2:


    sofia "Dix de piques..."


translate french boardsecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate french boardsecond_58145255:


    emerick "La quinte Papa!" with hpunch


translate french boardsecond_cfed94d4:


    hec "Putain..."


translate french boardsecond_7426dcb3:


    emerick "Oh allez Hector, t'as pas mal joué!"


translate french boardsecond_9a3c3b3d:


    hec "Va te faire foutre!"


translate french boardsecond_a21e69bd:


    emerick "Haha! Allez on continue!"


translate french turnsecond_5b45644b:


    emerick "Alors les gars, vous êtes tous les deux allin... Montrez vos mains!"


translate french turnsecond_1d55aa40:


    hec "Brelan de neuf!"


translate french turnsecond_09efb43f:


    d "Les As!"


translate french turnsecond_c2596d04:


    emerick "Ah ouais!"


translate french turnsecond_8b385b22:


    emerick "Pas mal... J'ai juste Roi-Valet..."


translate french turnsecond_d95b091a:


    sofia "Voici la turn..."


translate french turnsecond_2e8a73d2:


    sofia "2 de coeurs..."


translate french turnsecond_9eeb175e:


    emerick "T'es toujours bon Hector!"


translate french turnsecond_ebe96f90:


    hec "Pas de bad beat... Pas de bad beat..."


translate french turnsecond_08723f2a:


    dpense "Il me faut un as..."


translate french turnsecond_65c54f8c:


    emerick "Allez! On veut la river!"


translate french turnsecond_25e4f758:


    sofia "Voici la river..."


translate french turnsecond_9a610ffe:


    sofia "Dix de piques..."


translate french turnsecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate french turnsecond_58145255:


    emerick "La quinte Papa!" with hpunch


translate french turnsecond_cfed94d4:


    hec "Putain..."


translate french turnsecond_7426dcb3:


    emerick "Oh allez Hector, t'as bien joué!"


translate french turnsecond_9a3c3b3d:


    hec "Va te faire foutre!"


translate french turnsecond_78561908:


    emerick "Et merci d'être venu, Frenchie! Merci pour l'argent!"


translate french turnsecond_d95b091a_1:


    sofia "Voici la turn..."


translate french turnsecond_2e8a73d2_1:


    sofia "Deux de coeurs..."


translate french turnsecond_29aafa4e:


    emerick "Je mise 100!"


translate french turnsecond_bdc68931:


    d "All in!"


translate french turnsecond_d4af3017:


    d "Je suis..."


translate french turnsecond_bdc68931_1:


    d "All in!"


translate french turnsecond_5449efcb:


    d "Je raise!"


translate french turnsecond_9cff1cb6:


    emerick "Je suis!"


translate french turnsecond_7404b6d9:


    d "Je passe..."


translate french turnsecond_f7de9063:


    emerick "Bon Hector est allin... Montre ta main!"


translate french turnsecond_1d55aa40_1:


    hec "Brelan de neuf!"


translate french turnsecond_c2596d04_1:


    emerick "Ah ouais!"


translate french turnsecond_8b385b22_1:


    emerick "Pas mal... J'ai juste Roi-Valet..."


translate french turnsecond_9eeb175e_1:


    emerick "T'es toujours bon Hector!"


translate french turnsecond_ebe96f90_1:


    hec "Pas de bad beat... Pas de bad beat!"


translate french turnsecond_65c54f8c_1:


    emerick "Allez! On veut la river!"


translate french turnsecond_25e4f758_1:


    sofia "Voici la river..."


translate french turnsecond_9a610ffe_1:


    sofia "Dix de piques..."


translate french turnsecond_ff4ed839_1:


    emerick "BOOM!!!" with vpunch


translate french turnsecond_58145255_1:


    emerick "La quinte Papa!" with hpunch


translate french turnsecond_cfed94d4_1:


    hec "Putain..."


translate french turnsecond_7426dcb3_1:


    emerick "Oh allez Hector, t'as bien joué!"


translate french turnsecond_9a3c3b3d_1:


    hec "Va te faire foutre!"


translate french turnsecond_a21e69bd:


    emerick "Haha! Allez on continue!"


translate french riversecond_5b45644b:


    emerick "Bon les gars vous êtes tous les deux à tapis... Montrez vos mains!"


translate french riversecond_1d55aa40:


    hec "Brelan de neuf!"


translate french riversecond_09efb43f:


    d "Les As!"


translate french riversecond_c2596d04:


    emerick "Ah ouais!"


translate french riversecond_8b385b22:


    emerick "Pas mal... J'ai juste Roi-Valet..."


translate french riversecond_9eeb175e:


    emerick "T'es encore bon Hector!"


translate french riversecond_ebe96f90:


    hec "Pas de bad beat... Pas de bad beat..."


translate french riversecond_08723f2a:


    dpense "J'ai besoin d'un as..."


translate french riversecond_65c54f8c:


    emerick "Allez! On veut la river!"


translate french riversecond_25e4f758:


    sofia "Voici la river..."


translate french riversecond_9a610ffe:


    sofia "Dix de piques..."


translate french riversecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate french riversecond_58145255:


    emerick "La quinte Papa!" with hpunch


translate french riversecond_cfed94d4:


    hec "Putain..."


translate french riversecond_7426dcb3:


    emerick "Oh allez Hector! T'as bien joué!"


translate french riversecond_9a3c3b3d:


    hec "Va te faire foutre!"


translate french riversecond_78561908:


    emerick "ET merci d'être venu, Frenchie! Merci pour l'argent!"


translate french riversecond_25e4f758_1:


    sofia "Voici la river..."


translate french riversecond_9a610ffe_1:


    sofia "Dix de piques..."


translate french riversecond_29aafa4e:


    emerick "Je mise 100!"


translate french riversecond_d4af3017:


    d "Je suis..."


translate french riversecond_bdc68931:


    d "All in!"


translate french riversecond_bdc68931_1:


    d "All in!"


translate french riversecond_5449efcb:


    d "Je raise!"


translate french riversecond_9cff1cb6:


    emerick "Je call!"


translate french riversecond_7404b6d9:


    d "Je passe..."


translate french riversecond_f7de9063:


    emerick "Bon Hector est allin... Montre ta main!"


translate french riversecond_1d55aa40_1:


    hec "Brelan de neuf!"


translate french riversecond_c2596d04_1:


    emerick "AH ouais!"


translate french riversecond_a405345e:


    emerick "Pas mal... Mais..."


translate french riversecond_ff4ed839_1:


    emerick "BOOM!!!" with vpunch


translate french riversecond_58145255_1:


    emerick "La quinte Papa!" with hpunch


translate french riversecond_cfed94d4_1:


    hec "Putain..."


translate french riversecond_7426dcb3_1:


    emerick "Oh allez Hector, t'as bien joué!"


translate french riversecond_9a3c3b3d_1:


    hec "Va te faire foutre!"


translate french riversecond_a21e69bd:


    emerick "Haha! Allez on continue!"


translate french finalsecond_f7de9063:


    emerick "Bon Hector est all in... Montre ta main!"


translate french finalsecond_1d55aa40:


    hec "Brelan de neuf!"


translate french finalsecond_c2596d04:


    emerick "Ah ouais!"


translate french finalsecond_a405345e:


    emerick "Pas mal... Mais..."


translate french finalsecond_ff4ed839:


    emerick "BOOM!!!" with vpunch


translate french finalsecond_58145255:


    emerick "La quinte Papa!" with hpunch


translate french finalsecond_cfed94d4:


    hec "Putain..."


translate french finalsecond_7426dcb3:


    emerick "Oh allez Hector, t'as bien joué!"


translate french finalsecond_9a3c3b3d:


    hec "Va te faire foutre!"


translate french finalsecond_78561908:


    emerick "Et merci d'être venu Frenchie! Merci pour l'argent!"


translate french finalsecond_a21e69bd:


    emerick "Haha! Allez on continue!"


translate french twistersequence_b12cdd7a:


    ruby "Allez, c'est parti!"


translate french twistersequence_a255f487:


    ruby "Qui veut jouer?"


translate french twistersequence_605daa46:


    kira "J'en suis!"


translate french twistersequence_207bcd32:


    s "Moi aussi!"


translate french twistersequence_70936eb4:


    ruby "Okay! Steven, Kira..."


translate french twistersequence_b5432fd9:


    ruby "[name]?"


translate french twister1_854f7ed7:


    mad "Oh, allez, compte moi aussi!"


translate french twister1_dc165b3b:


    ruby "Super!"


translate french twister1_738560b4:


    ruby "Bon ben moi je m'occupe de la roue!"


translate french twister1_705961f2:


    ruby "Et quand quelqu'un tombe, il a un gage!"


translate french twister1_58455e31:


    dpense "J'espère qu'elle va pas aller trop loin avec ses gages..."


translate french twister1_3afbfedb:


    dpense "Le corps athlétique de Madison et ses seins énormes vont clairement être une distraction..."


translate french twister1_8867adec:


    dpense "Et Kira... Cette silhouette avec ce cul rond parfait. Ca promet!"


translate french twister1_b12cdd7a:


    ruby "Allez! C'est parti!"


translate french twister1_1adf77ff:


    ruby "Premier tour... Main droite Rouge!" with hpunch


translate french twister1_122f3e71:


    kira "Facile!"


translate french twister1_b8a9c191:


    s "C'est bon!"


translate french twister1_e3c1a095:


    d "C'est bon pour moi!"


translate french twister1_6a6f3496:


    mad "Du gâteau!"


translate french twister1_aeac2c84:


    ruby "Prochain tour... Pied gauche sur Vert!" with hpunch


translate french twister1_c1382146:


    kira "Faut un peu s'étirer là!"


translate french twister1_4201ad80:


    s "Pas mal."


translate french twister1_55b0f2bb:


    d "Ca va je gère."


translate french twister1_354fbd29:


    mad "C'est bon pour moi!"


translate french twister1_fd2ab163:


    dpense "Madison étire son corps et montre sa silhouette athlétique. Elle est vraiment bien gaulée."


translate french twister1_12ecdece:


    dpense "Les mouvements de Kira accentuent ses courbes. Ce cul c'est vraiment quelque chose putain."


translate french twister1_16e4c677:


    ruby "Pied droit sur Bleu!" with hpunch


translate french twister1_759345ef:


    kira "Ca devient tactique là!"


translate french twister1_ba2f3a28:


    s "Whoa, j'ai failli tomber!"


translate french twister1_9ac46c0a:


    d "Attention Steven!"


translate french twister1_37961fdb:


    mad "C'est bon, c'est bon!"


translate french twister1_ff6edbf5:


    ruby "Main gauche sur Jaune!" with hpunch


translate french twister1_d8dca636:


    kira "Okay là c'est dûr!"


translate french twister1_a0d6dc23:


    s "Je glisse!"


translate french twister1_830b4098:


    d "Tiens bon Steven!"


translate french twister1_310bd1e1:


    mad "Concentre-toi Steven!"


translate french twister1_9dcbc0e8:


    ruby "Steven t'es éliminé!"


translate french twister1_dcd39989:


    s "Fais chier!"


translate french twister1_6e17f083:


    ruby "Un gage! Tu dois faire le tour de la maison en sous-vêtements!"


translate french twister1_86063441:


    s "Sérieusement?"


translate french twister1_3239e163:


    s "Très bien. Un pari est un pari..."


translate french twister1_0c843431:


    s "Je reviendrai!"


translate french twister1_ee4baf21:


    "Rires"


translate french twister1_b7b6e9ac:


    ruby "Okay allez, on continue!"


translate french twister1_65aec8b5:


    ruby "Trois joueurs restants!"


translate french twister1_d897c9d7:


    ruby "Prochain tour... Main droite sur Vert!" with hpunch


translate french twister1_5986ca7c:


    kira "J'ai!"


translate french twister1_5b657902:


    d "Facile!"


translate french twister1_76175d7e:


    mad "Toujours là!"


translate french twister1_f8247d44:


    dpense "L'endurance de Madison est impressionnante. Elle est trop belle."


translate french twister1_d229fb74:


    dpense "Kira se concentre à fond. Et son corps est à tomber."


translate french twister1_43358402:


    ruby "Pied gauche sur Rouge!" with hpunch


translate french twister1_bd6057c8:


    kira "Ouah j'ai failli me râter là!"


translate french twister1_5d3a4772:


    d "Attention!"


translate french twister1_3efe91a9:


    mad "Toujours stable!"


translate french twister1_87f0e3b4:


    ruby "Pied droit sur jaune!" with hpunch


translate french twister1_818e5609:


    kira "Je commence à le sentir passer!"


translate french twister1_4dd5f4c3:


    d "Encore un peu à tenir!"


translate french twister1_1b2e41c7:


    mad "C'est bon pour moi!"


translate french twister1_8feb4af2:


    dpense "La détermination de Madison est claire."


translate french twister1_2e19129d:


    ruby "Kira éliminée!"


translate french twister1_c4fb4f4c:


    kira "Oh... Bon ben au moins c'était drôle le temps que ça a duré!"


translate french twister1_1a37fe6d:


    ruby "Kira, ton gage est..."


translate french twister1_d2a489e9:


    ruby "Tu dois embrasser qui tu veux !"


translate french twister1_f9115114:


    kira "Hmmm, intéressant..."


translate french twister1_7a77e836:


    kira "Très bien, je choisis [name]!"


translate french twister1_d9649ae4:


    mad "Sérieusement, Kira?"


translate french twister1_71db9840:


    mad "T'étais obligé de chopper [name]?"


translate french twister1_99102486:


    kira "POurquoi? T'es jalouse?"


translate french twister1_d9d3c314:


    mad "Moi? NON!"


translate french twister1_b38549e6:


    mad "Fais ce que tu veux..."


translate french twister1_42fe5f0e:


    dpense "Ouah ce baiser c'est quelque chose..."


translate french twister1_5c6118f1:


    dpense "Mais la réaction de Madison est encore plus intrigante."


translate french twister1_26fbc773:


    ruby "Okay, on avance! Deux joueurs restants... [name] et Madison!"


translate french twister1_c95a5382:


    ruby "On va compliquer les choses!"


translate french twister1_f5469193:


    ruby "Prochain tour... Les deux mains sur Bleu!" with hpunch


translate french twister1_7959b43b:


    mad "Ca m'étire..."


translate french twister1_610f5201:


    d "J'y suis presque..."


translate french twister1_3ff0b1af:


    dpense "Je sens la chaleur émaner du corps de Madison. Elle est tellement proche."


translate french twister1_59bb579b:


    ruby "Pied droit sur Vert!" with hpunch


translate french twister1_0fbf0d2a:


    mad "Plus chaud là!"


translate french twister1_2ea85ac8:


    d "Encore un peu..."


translate french twister1_8e5eb314:


    dpense "Nos corps se rapprochent, la tension est palpable."


translate french twister1_a0fb982d:


    ruby "Pied gauche sur Jaune!" with hpunch


translate french twister1_a637c946:


    mad "Ca tient..."


translate french twister1_b14c35cd:


    d "J'ai failli me rater là!"


translate french twister1_8d6b1f6e:


    dpense "Madison se colle à moi, ses courbes sont impossibles à ignorer."


translate french twister1_17b1529b:


    ruby "Allez ça va être plus difficile là!"


translate french twister1_8e509e5b:


    ruby "Les deux mains sur Bleu! Mais pas les mêmes que ceux sur lesquels vous êtes!" with hpunch


translate french twister1_85c61c22:


    mad "Là ça devient intense!"


translate french twister1_f153692d:


    d "Nan tu crois..."


translate french twister1_7d81ee16:


    dpense "On est si proches... Je sens sa respiration sur ma peau..."


translate french twister1_61a8520a:


    dpense "Son corps pressé contre le mien, et je peux pas m'empêcher de sentir comment elle est douce."


translate french twister1_462c5f1d:


    dpense "Nos visages sont l'un en face de l'autre, et je peux voir des éclairs dans ses yeux. Ce jeu est beaucoup plus intense que ce que je pensais."


translate french twister1_dc8bad59:


    mad "On dirait que c'est juste toi et moi..."


translate french twister1_5b62eedd:


    d "Ouais... C'est... Interessant."


translate french twister1_8de7275b:


    dpense "Son corps est pratiquement moulé au mien, la tension est électrique."


translate french twister1_74637e05:


    ruby "Madison éliminée! [name], tu as gagné!"


translate french twister1_26e90d0a:


    mad "Fais chier c'était pas loin."


translate french twister1_36cd59a5:


    d "Bien joué, Madison!"


translate french twister1_9021a01e:


    ruby "Bravo [name], tu es notre nouveau champion de Twistplay!"


translate french twister1_283935f2:


    mad "Je suppose que je vais avoir droit à un gage maintenant?"


translate french twister1_9a10d66c:


    ruby "Madison, ton gage... Hmmm... Qu'est ce que tu pourrais faire?"


translate french twister1_16fcf0c7:


    dpense "Voyons voir ce qu'elle va proposer..."


translate french twister1_562e58ec:


    ruby "Et pourquoi pas... embrasser [name] toi aussi? "


translate french twister1_0b8cbe55:


    mad "Oh, c'est facile!"


translate french twister1_e9f9d80b:


    ruby "Nan! Pas juste un bisou. Un vrai baiser."


translate french twister1_224206c9:


    mad "Oh! Tu veux dire comme ça?"


translate french twister1_9be3f4e8:


    mad "Viens là, [name]."


translate french twister1_ae94e9b1:


    dpense "Wow, elle y va vraiment. Je peux sentir tout son corps pressé contre le mien. C'est intense."


translate french twister1_51930a95:


    mad "Et voilà."


translate french twister1_ca820d31:


    dpense "Ses lèvres sont si douces... C'est bon mais je me demande si j'aurais pas pû avoir un peu plus."


translate french twister1_9b7b30a4:


    ruby "Allez... Steven devrait revenir bientôt."


translate french twister1_2fd3cfa8:


    dpense "Madison continue de me regarder et j'arrive pas à savoir ce qu'elle pense."

translate french strings:


    old "9:00 PM"
    new "21:00"


    old "Go play Poker"
    new "Jouer au Poker"


    old "Go play Twister"
    new "Jouer au Twistplay"


    old "I need a refresher"
    new "J'ai besoin d'aide"


    old "No, I'm good"
    new "Nan ça va!"


    old "Bet[TEMP1!t]"
    new "Miser[TEMP1!t]"


    old "Fold[TEMP2!t]"
    new "Passer[TEMP2!t]"


    old "Bet"
    new "Miser"


    old "Call"
    new "Suivre"


    old "A few hands later..."
    new "Quelque mains plus tard..."


    old "Raise"
    new "Relancer"


    old "Yeah, I'm in[TEMP1!t]"
    new "Ouais je joue![TEMP1!t]"


    old "No, thanks"
    new "Non, merci"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
