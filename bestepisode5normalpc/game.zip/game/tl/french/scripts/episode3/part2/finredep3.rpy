


translate french afterpoker_26fc436e:


    emerick "Putain, le gars me sort une royale contre mon carré quoi!" with hpunch


translate french afterpoker_e128b8b4:


    d "Bien joué, Emerick."


translate french afterpoker_59e4a75a:


    emerick "Bien joué? Parce que pour toi c'est juste un jeu ? Je devais gagner!" with hpunch


translate french afterpoker_3c955927:


    d "La chance était de mon côté on dirait."


translate french afterpoker_dd4d55fe:


    emerick "La chance? Arrête un peu. Je ne perds pas. Ce n'est pas fini."


translate french afterpoker_77e65e36:


    dpense "Emerick a l'air furieux. Il prend pas bien la défaite."


translate french afterpoker_3745a13a:


    beth "Impressionnant, [name]."


translate french afterpoker_dea409f1:


    dpense "Beth m'a regardé toute la soirée. Je me demande ce qu'elle mijote."


translate french afterpoker_63c46105:


    beth "Tu veux rester un peu?"


translate french stay_with_beth_12cbaf67:


    beth "Bien. Je savais que tu ferais le bon choix."


translate french stay_with_beth_13637baa:


    dpense "Il y a quelque chose en her... Si autoritaire, irrésistible."


translate french stay_with_beth_5927b544:


    beth "Assis."


translate french stay_with_beth_2c4b2623:


    dpense "On va pas la contredire..."


translate french stay_with_beth_50a31f22:


    beth "Bon garçon."


translate french stay_with_beth_a6ab9cc9:


    beth "TU sais, [name], je te surveille depuis le début."


translate french stay_with_beth_e9aab196:


    beth "J'aime ce que je vois."


translate french stay_with_beth_7dd0a916:


    dpense "Elle est si confiante, si dominante. C'est à la fois intimidant et ça me fait frissonner."


translate french stay_with_beth_51848909:


    beth "Viens ici."


translate french stay_with_beth_270f026f:


    beth "Maintenant."


translate french stay_with_beth_5d63b95b:


    dpense "Je ne peux pas lui résister. Son autorité est magnétique."


translate french stay_with_beth_df740f72:


    beth "A genoux!"


translate french stay_with_beth_4d0f74d6:


    d "Oui, Beth."


translate french stay_with_beth_00872fa6:


    dpense "J'ai jamais rencontré quelqu'un d'aussi autoritaire. Sa domination me submerge."


translate french stay_with_beth_3b4a1fbe:


    beth "Bouffe-moi."


translate french stay_with_beth_79dc6287:


    dpense "Ses mots m'envoient des frissons dans tout le corps."


translate french stay_with_beth_8a2ed47c:


    dpense "Son parfum est ennivrant. Le goût de sa chatte est tellement puissant."


translate french stay_with_beth_217d20bd:


    beth "Oui, juste comme ça. Ne t'arrête pas."


translate french stay_with_beth_8752824b:


    dpense "Elle presse ma tête contre elle, prenant tout le contrôle. C'est intense mais j'adore ça."


translate french stay_with_beth_03fc9228:


    beth "Tu t'en sors bien. Continue."


translate french stay_with_beth_5b7fdae8:


    dpense "Ses ordres m'excitent encore plus. Je veux lui faire plaisir, la faire se sentir incroyable."


translate french stay_with_beth_d9f34e3d:


    beth "Je suis pas loin... Ne t'avise pas de t'arrêter maintenant!"


translate french stay_with_beth_ee2d4b4c:


    dpense "Je sens son corps trembler. Elle va venir."


translate french stay_with_beth_3a93f79f:


    beth "Ahhh... Oui!!! Juste comme ça!"


translate french stay_with_beth_39e51c28:


    dpense "Son orgasme est puissant. Elle m'arrache les cheveux, me tenant en place."


translate french stay_with_beth_f72b2ae0:


    beth "Maintenant, à toi."


translate french stay_with_beth_804a34c9:


    beth "Allonge-toi sur la table."


translate french stay_with_beth_1b4e9d65:


    dpense "Elle prend le contrôle de tout. Je suis sur une autre planète."


translate french stay_with_beth_824d66ce:


    beth "Je vais te chevaucher jusqu'à ma jouissance."


translate french stay_with_beth_c59d4f05:


    dpense "Sa confiance est encore plus forte. J'ai tellement hâte de la sentir sur moi."


translate french stay_with_beth_7da8c02e:


    dpense "Ses mouvements sont parfaits. Elle a un contrôle total sur moi, c'est merveilleux."


translate french stay_with_beth_2836d3f7:


    beth "Oui... Juste comme ça. Ne bouge pas."


translate french stay_with_beth_dcc9adf8:


    dpense "Je me sens déjà venir. Sa domination m'excite tellement que je suis déjà à la limite."


translate french stay_with_beth_4f7ab2b2:


    beth "Oh putain je vais vais jouir! Je t'interdis de finir avant moi!"


translate french stay_with_beth_96dca394:


    dpense "Ses mots, son contrôle... C'est trop. Je vais..."


translate french stay_with_beth_54eb3554:


    beth "Maintenant!"


translate french stay_with_beth_da6a63b9:


    dpense "Je peux pas me retenir plus!"


translate french stay_with_beth_6841e6fc:


    d "Ahhhhhhhh!!!!"


translate french stay_with_beth_c10f8726:


    d "Putainnnnnn!"


translate french stay_with_beth_d35fe4c2:


    d "Fshhhhhh...."


translate french stay_with_beth_8f3148fe:


    dpense "Heu... Qu'est ce qu'elle fait?"


translate french stay_with_beth_4a484680:


    beth "Surprise!"


translate french stay_with_beth_23d91f6d:


    beth "On a du public. Un petit sourire?"


translate french stay_with_beth_f2258407:


    d "De quoi?" with hpunch


translate french stay_with_beth_0d5b52a6:


    ruby "Oh mon dieu..."


translate french stay_with_beth_64d9349d:


    grace "Mais qu'est ce que..."


translate french stay_with_beth_f37737eb:


    mad "Dégoûtant!"


translate french stay_with_beth_46038782:


    sofia "Hey les filles! Qu'est ce que..."


translate french stay_with_beth_81e7c462:


    sofia "[name]???"


translate french stay_with_beth_9521deef:


    sofia "Comment est que tu peux?"


translate french stay_with_beth_53155274:


    dpense "Sofia..."


translate french stay_with_beth_8690e0c0:


    dpense "Non..."


translate french stay_with_beth_21a32b9c:


    beth "Tu..."


translate french stay_with_beth_98249955:


    beth "Es..."


translate french stay_with_beth_5681410d:


    beth "A moi!"


translate french stay_with_beth_119586b3:


    beth "Je crois que tu peux rentrer maintenant."


translate french stay_with_beth_9e386227:


    d "Mais..."

translate french strings:


    old "Sure, why not?[TEMP1!t]"
    new "Bien sûr, pourquoi pas?[TEMP1!t]"


    old "No, thanks.[TEMP2!t]"
    new "Non, merci.[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
