


translate french free22_1be28055:


    kira "T'as déjà perdu?"


translate french free22_77d71485:


    d "Ouais... Ton cousin a trop de chance..."


translate french free22_fc89a466:


    kira "Ahah! C'est juste que tu ne sais pas jouer!"


translate french free22_f338cc08:


    d "Heu..."


translate french free22_272aa8c2:


    d "Non non, on fait juste une pause!"


translate french free22_9b3fe7b3:


    kira "Oh okay!"


translate french free22_f4034d91:


    kira "Si je peux te donner un conseil..."


translate french free22_88283594:


    kira "Emerick sait ce qu'il fait."


translate french free22_e11ee7fa:


    kira "Mais si tu penses que tu as l'avantage à un moment..."


translate french free22_ae5d5593:


    kira "Fais lui croire que c'est lui qui l'a..."


translate french free22_d42fe897:


    kira "Il te donnera tout..."


translate french free22_2c3a63c7:


    d "Comment ça?"


translate french free22_f291fd44:


    kira "Joue sur son ego."


translate french free22_7eff095c:


    d "OKay... Je vais essayer."


translate french free22_0ba5d46b:


    ruby "On met un peu de musique?" with hpunch


translate french free22_e3a83ad3:


    grace "Oui, c'est trop calme ici!"


translate french free22_a3fb43b8:


    ruby "Attends, je bouge la table pour qu'on puisse danser!"


translate french free22_468861f3:


    d "Danser?"


translate french free22_b9488c59:


    ruby "Oui! T'aimes pas ça?"


translate french free22_40cb86c2:


    d "Si si! Mais je ne savais pas que tu aimais danser!"


translate french free22_01a43774:


    d "Heu non... Pas pour moi... Mais je ne savais pas que tu aimais danser!"


translate french danse22_4f62b28b:


    ruby "Moi? Non!!!" with vpunch


translate french danse22_980d278f:


    ruby "Mais Grace..."


translate french danse22_3deed7ed:


    d "Ah bon?"


translate french danse22_fb565796:


    ruby "Allez assieds-toi... Et profite du spectacle!"


translate french danse22_dd5d68f3:


    d "Hein?"


translate french danse22_69c1622d:


    d "Wow!!! Je m'attendais pas à ça!"


translate french danse22_a955a3b7:


    ruby "Je te l'avais dit!"


translate french danse22_5f558a08:


    dpense "Ce rythme..."


translate french danse22_16f3e257:


    dpense "Ces mouvements..."


translate french danse22_6f3e5dad:


    dpense "C'est vraiment une déesse..."


translate french danse22_d769145c:


    dpense "La façon dont elle bouge en rythme avec la musique..."


translate french danse22_88ff6449:


    dpense "C'est comme si elle racontait une histoire à chaque pas..."


translate french danse22_1a96938b:


    dpense "Je ne peux pas détacher mes yeux d'elle..."


translate french danse22_165575e4:


    dpense "Chaque geste est une invitation au rêve..."


translate french danse22_df9bdb38:


    dpense "Grace captive tout le monde..."


translate french danse22_be93a8b1:


    grace "T'en as pensé quoi?"


translate french danse22_8b5925da:


    d "Tu étais..."


translate french danse22_5ed46a7b:


    d "Magnifique..."


translate french danse22_442f607d:


    grace "Merci!"


translate french danse22_092218ab:


    hec "Et bien, y'à du talent par ici!"


translate french danse22_7c71854d:


    kira "Et c'est pas fini!"


translate french danse22_dd5d68f3_1:


    d "Hein?"


translate french danse22_bd15cdba:


    dpense "Oh..."


translate french danse22_7a82419b:


    dpense "Pu..."


translate french danse22_1dfd470a:


    dpense "Tain..."


translate french danse22_46359b02:


    dpense "Ce cul..."


translate french danse22_eadce89f:


    dpense "Merde..."


translate french danse22_58235d12:


    dpense "J'imagine même pas tout ce que j'aimerais lui faire..."


translate french danse22_ef768a8f:


    d "Okay okay... T'es bonne aussi!"


translate french danse22_52a1acec:


    kira "Ahah! Je sais!"


translate french danse22_655b2071:


    hec "Prend des notes, Frenchie!"


translate french danse22_e48c9cb0:


    d "Hmmm..."


translate french danse22_d4f312f9:


    d "Minus?"


translate french danse22_b89db320:


    ruby "Oui?"


translate french danse22_7b984d44:


    d "Vas-y... Mets-moi du bon son!"


translate french danse22_335a5311:


    ruby "Oh? Okay!"


translate french danse22_9e11135f:


    dpense "Et maintenant..."


translate french danse22_2798004b:


    d "Show Time!"


translate french danse22_a33e428d:


    ruby "Vas-y, montre leur [name]!"


translate french danse22_7caf9fa9:


    grace "Woooh!"


translate french danse22_5477c44c:


    ruby "[name]! [name]! [name]!"


translate french danse22_58203668:


    ruby "Trop génial! Mais t'as appris où à faire ça?"


translate french danse22_1994e955:


    d "Oh... J'aime bien danser et sortir avec mes amis tu sais..."


translate french danse22_0a44a128:


    grace "C'était trop bien!"


translate french danse22_38e03a72:


    d "Haha! Merci!"


translate french danse22_17420bbd:


    hec "Hmpfff..."


translate french danse22_c81eac44:


    d "Ouais ouais..."


translate french danse22_22d2064c:


    dpense "Cause toujours. J'en parlerais à mn cheval..."

translate french strings:


    old "10:00 PM"
    new "22:00"


    old "Yes, I do![TEMP1!t]"
    new "Si si, bien sûr![TEMP1!t]"


    old "Uh, not really!"
    new "Heu, pas vraiment!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
