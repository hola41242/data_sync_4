


translate french free20main_b9817b1b:


    dpense "Mon coeur a râté un battement à ces mots. Je m'attendais pas à ça de Sofia. Est ce que je devrais y aller?"


translate french free20poker_e46e10c0:


    emerick "T'es pas invité, Frenchie. Retourne avec ton harem!"


translate french free20poker_166fb7af:


    d "C'est quoi ton problème, Emerick?"


translate french free20poker_e3a21349:


    emerick "Mon problème? T'es pas invité alors... Casse-toi!"


translate french free20poker_09774e7f:


    d "Je suis juste là pour passer du bon temps, comme tout le monde."


translate french free20poker_caffb51d:


    emerick "Je m'en fous!"


translate french julia20_e9b667af:


    julia "Coucou!"


translate french julia20_7b0543b1:


    d "Salut! Ton dos va mieux?"


translate french julia20_90f7916e:


    julia "Ca va, mais je fais attention."


translate french julia20_e01785b9:


    julia "Je reste un peu pour les filles, mais je vais pas pouvoir participer aux jeux que Ruby a organisé..."


translate french julia20_d303c45f:


    d "Haha! Je sais pas ce que je vais faire non plus!"


translate french julia20_0a194220:


    julia "Amuse-toi! C'est le principal!"


translate french julia20_a676d5f9:


    d "On va essayer!"


translate french julia20_91ae47cb:


    d "Tu bois quelque chose?"


translate french julia20_ebb81cf3:


    julia "Nan, vaut mieux pas avec les médicaments..."


translate french julia20_f36a5ff4:


    d "Okay!"


translate french julia20_12d28bf4:


    d "Oh... Sinon... J'adore cette nouvelle coupe de cheveux!"


translate french julia20_d5c0dba2:


    julia "Ah? Merci!"


translate french julia20_c37e26a1:


    d "T'aimes bien changer de coupe de cheveux non? Chaque fois que je te vois, t'en as une nouvelle!"


translate french julia20_27255f05:


    julia "Ben... En fait... L'autre con m'a traité de Pinkie l'autre jour du coup ça m'a saoulée..."


translate french julia20_ba9103a5:


    d "Ah... Oui je comprend..."


translate french julia20_4811f618:


    julia "Du coup il va probablement me laisser tranquille maintenant..."


translate french julia20_f4bcc054:


    julia "Et franchement, j'aime bien comme ça... Peut être que je vais les garder comme ça!"


translate french julia20_58878192:


    d "Haha! Fais comme tu le sens!"


translate french julia20_8b665ac1:


    d "Même si c'est marrant de te voir changer à chaque fois!"


translate french julia20_c4520b4a:


    d "J'aime bien me demander à quoi tu vas ressembler la prochaine fois! C'est toujours une surprise!"


translate french julia20_c2c84d9a:


    julia "Une surprise?"


translate french julia20_d3bc2521:


    d "Oui! Tu es imprévisible, mais j'adore ça!"


translate french julia20_c9b9f09a:


    julia "Tu aimes les filles imprévisibles?"


translate french julia20_b4e7c55d:


    d "J'aime les filles qui me surprennent."


translate french julia20_8deff805:


    julia "C'ets nôté!"


translate french julia20_ddf64e4d:


    d "Je vais voir ce que font les autres! On se voit plus tard?"


translate french julia20_122dc49a:


    julia "A plus tard!"


translate french ruby20_54e9eef5:


    ruby "Hey! T'es prêt pour ce soir?"


translate french ruby20_2d1667b9:


    d "Evidemment!"


translate french ruby20_47838d55:


    ruby "Bon, la première activité qu'on a organisé c'est un Twistplay!"


translate french ruby20_55bd9a0f:


    d "Oh mon dieu... Ca fait un bail que j'ai pas joué à ça..."


translate french ruby20_5624a2c3:


    ruby "C'est comme le vélo, ça s'oublie pas! Allez de toute façon c'est juste pour s'amuser!"


translate french ruby20_fb37dec8:


    ruby "Y'à rien à gagner, juste s'amuser!"


translate french ruby20_ddd135eb:


    ruby "Alors..."


translate french ruby20_a220d848:


    ruby "Tu veux jouer à Twistplay?"


translate french ruby20_2a344a80:


    d "OUi, bien sûr!"


translate french ruby20_c6e7417e:


    d "Non merci!"


translate french gracemadison20_22e7c1e7:


    mad "Et il m'aurait pas dit qu'elle a été malade toute la journée jusqu'à ce que je lui demande sur le vomi sur ses vêtements!"


translate french gracemadison20_ec0774f0:


    mad "Il l'a même pas changée! Je te jure!"


translate french gracemadison20_929b3308:


    grace "Tu peux pas lui faire confiance..."


translate french gracemadison20_5fb85e30:


    mad "Je ne crois plus aucun homme dans ma vie!"


translate french gracemadison20_2e4b2f5d:


    mad "Je te le dis! Vaut mieux être seule que mal accompagnée!"


translate french gracemadison20_5813eb09:


    grace "Ils sont pas tous comme ça non plus!"


translate french gracemadison20_0f959e66:


    mad "Si t'en trouves un qui n'est pas comme ça, t'as plutôt intérêt à le garder alors! "


translate french gracemadison20_bb8a7268:


    grace "On ne sait jamais, on pourrait trouver quelqu'un qui puisse nous satisfaire."


translate french gracemadison20_aaae4443:


    mad "Genre le garçon parfait qui tomberait du ciel? Ca n'arrivera pas ma chérie!"


translate french gracemadison20_dd6aca0e:


    grace "Et pourquoi attendre qu'il tombe?"


translate french gracemadison20_47e7ef71:


    grace "Je pourrais juste le rencontrer dans le ciel!"


translate french gracemadison20_2c8fb2dd:


    mad "Hein???"


translate french gracemadison20_9e3164dd:


    d "Vous parlez de quoi?"


translate french gracemadison20_e0fa34d0:


    mad "Oh tu sais, responsabilités, relations, enfants."


translate french gracemadison20_21c07e24:


    mad "Discussions de filles quoi!"


translate french gracemadison20_833b1ae7:


    grace "Hey [name]! Est ce que tu aimerais avoir des enfants?"


translate french gracemadison20_31236522:


    d "Un jour, oui! Mais je ne suis pas pressé!"


translate french gracemadison20_7babe025:


    mad "Oui, il est jeune, il a tout son temps!"


translate french gracemadison20_ab07cfa9:


    grace "Oui, c'est vrai. Mais c'est bon de savoir quand même!"


translate french gracemadison20_cae75794:


    d "Nan, franchement, je pense pas que je sois fait pour avoir des enfants."


translate french gracemadison20_ae441c39:


    mad "AU moins il est honnête..."


translate french gracemadison20_e1929ec1:


    grace "On sait jamais, il pourrait changer d'avis plus tard."


translate french gracemadison20_a68fb151:


    d "Je ne sais pas... En tous cas, pour l'instant, c'est pas dans mes plans!"


translate french gracemadison20_00c8df40:


    mad "Moi j'ai déjà assez avec la mienne pour l'instant!"


translate french gracemadison20_68b29370:


    grace "Haha! J'imagine! En plus t'as un frère qui te donne plus de boulot qu'il n'en fait..."


translate french gracemadison20_4bf8646f:


    d "Son frère?"


translate french gracemadison20_e7caeca7:


    grace "Oui, son frère s'occupe de sa fille quand elle est à l'Academy ou en voyages pour les matches..."


translate french gracemadison20_0179b026:


    mad "Mais c'est pas vraiment un succès!"


translate french gracemadison20_3996a386:


    mad "Le gars traîne sur le canapé toute la journée, et quand il s'agit de s'occuper de la petite... Bizarrement il est introuvable."


translate french gracemadison20_8c9ae968:


    grace "Allez, Maddie! Relax et prend un verre, ça ira mieux!"


translate french gracemadison20_9a1573c3:


    mad "Ouais, t'as raison! Arrêtons de penser à ça et profitons de la soirée! "


translate french gracemadison20_ceddc600:


    grace "C'est ça! Alors on trinque à..."


translate french gracemadison20_66edb94c:


    grace "A quoi?"


translate french gracemadison20_996828a8:


    d "A notre rencontre?"


translate french gracemadison20_281c814d:


    grace "Ouais voilà! A nos rencontres, à cette compétition, et à cette année qui va sûrement être pleine de surprises!"


translate french gracemadison20_6860a799:


    "Santé!" with hpunch


translate french kira20_76978961:


    kira "Hey! [name], c'est ça?"


translate french kira20_11b6e570:


    d "Ouais!"


translate french kira20_63270a58:


    kira "Je te présente Fanny!"


translate french kira20_c9f48e51:


    d "Enchanté!"


translate french kira20_cbac991e:


    kira "Oh t'inquiète pas, elle comprend rien à ce que tu dis!"


translate french kira20_dd5d68f3:


    d "Hein?"


translate french kira20_090957fb:


    kira "Ouais, elle vient d'un autre pays, et elle ne parle pas notre langue."


translate french kira20_b2fb687f:


    d "Euh... Pourquoi elle est là du coup?"


translate french kira20_714495ac:


    kira "Ben, notre école a un programme d'échange linguistique. Tu sais, pour le commerce international."


translate french kira20_67a82fd5:


    kira "Du coup je l'héberge mais elle est pas vraiment intéressée par l'apprentissage de notre langue!"


translate french kira20_25b067eb:


    kira "Elle a des formes parfaites, un corps idéal et une jolie tête par contre."


translate french kira20_9fca5bb8:


    kira "Du coup j'en ai profité pour devenir son OSM."


translate french kira20_23c22a5e:


    d "Son OSM?"


translate french kira20_822c4b60:


    kira "OnlyStan Manager!"


translate french kira20_2540386d:


    d "C'est quoi ça?"


translate french kira20_0d95348d:


    kira "Hum... Tu connais OnlyStan?"


translate french kira20_87fc9282:


    d "J'en ai entendu parler. C'est cette plateforme pour les créateur de contenus qui est assez..."


translate french kira20_7caab17d:


    kira "Adulte, oui. Enfin y'à un peu de tout dessus quoi!"


translate french kira20_470a0ba6:


    kira "Et comme elle savait pas quoi faire."


translate french kira20_c9052c34:


    kira "J'ai ouvert un compte pour elle pour qu'elle puisse se faire de l'argent!"


translate french kira20_bec902dc:


    d "Comment ça?"


translate french kira20_f0c1cba5:


    kira "En gros, elle touche pas au compte, c'est moi qui le gère."


translate french kira20_36c8d6dc:


    kira "Je lui prépare un emploi du temps. Genre lundi tu vas à la plage et tu prends des photos en maillot."


translate french kira20_7a54482d:


    kira "Mardi tu vas à la piscine... Mercredi tu te prends en photo dans ton lit..."


translate french kira20_a4a39f55:


    d "Et elle le fait?"


translate french kira20_f1dc0a9e:


    kira "Ben oui! Elle passait déjà son temps à se prendre en photo avant..."


translate french kira20_9d72dc9f:


    kira "Du coup ça change pas grand chose... On fait juste de l'argent avec ses photos!"


translate french kira20_1bda52ce:


    d "Hum... Et si on lui demande des trucs un peu plus osés?"


translate french kira20_d26751e5:


    kira "Oh ben ça c'est elle qui voit hein! Je lui envoit les requêtes des gars et elle décide si elle veut y répondre ou pas."


translate french kira20_4e452bbd:


    d "Oh..."


translate french kira20_4dba9ffa:


    kira "Après c'est aussi comme ça que tu te fais le plus d'argent, faut pas croire. C'est bien d'avoir des abonnements mais les trucs plus persos paient vachement plus!"


translate french kira20_8f92cc28:


    d "C'est pas un peu de la prostitution?"


translate french kira20_7afac9f9:


    kira "Ben, dans ce cas, ça fait de moi la maquerelle la plus sexy et pimpante que tu auras rencontré!"


translate french kira20_d912e36d:


    d "Haha! Nan mais je voulais pas dire ça. C'est juste que vous vous faites de l'argent avec son corps."


translate french kira20_bda08395:


    kira "Oui... Bof... Elle se plaint pas!"


translate french kira20_a1cb4e30:


    d "Ben, si elle parle pas vraiment... Elle peut pas non plus..."


translate french kira20_db2aa7b3:


    kira "Et puis elle prend 80 pour cent de ce qu'elle génère. Je prend juste 20 pour cent pour organiser et répondre aux messages pour elle."


translate french kira20_85110e9c:


    d "Ah, parce que c'est pas elle qui répond?"


translate french kira20_778d6ef8:


    kira "Ben non! Elle pourrait pas!"


translate french kira20_9feafa6e:


    kira "Alors je fais genre je suis elle et j'encourage les gars qui lui parlent à liker ses photos et aller voir les nouvelles."


translate french kira20_6d7a39b0:


    d "T'as l'air d'avoir tout prévu."


translate french kira20_bc15f278:


    kira "Ouais, mais bon c'est un petit entraînement pour d'autres projets! Je vais pas faire ça toute ma vie! C'est plus un passe-temps."


translate french kira20_cadb9a4f:


    d "Drôle de passe-temps!"


translate french kira20_f695fe29:


    kira "Ouais! Okay ragarde! Je vais lui dire de prendre une photo maintenant tu vas voir!"


translate french kira20_a6c2d4ec:


    kira "Fanny! Va au milieu là, je vais te prendre en photo!"


translate french kira20_f0657274:


    "Okay."


translate french kira20_d7331970:


    kira "Tu vois, elle fait ce que je lui dis!"


translate french kira20_9a3fd59f:


    kira "Maintenant, montre plus ton cul!"


translate french kira20_e099747a:


    d "Okay... Je vous laisse là! A plus tard?"


translate french kira20_edceb7aa:


    kira "Ouais! Et oublie pas de checker son OnlyStan si t'es intéressé!"


translate french kira20_65fdf5f6:


    d "Heu... J'y penserais!"


translate french debiles20_ee280869:


    mac "ET là le mec il me call jusqu'à la river!"


translate french debiles20_0b75be13:


    ben "Putain!"


translate french debiles20_8cf98d22:


    mac "Ouais! J'avais tu les As, tu vois!"


translate french debiles20_0b75be13_1:


    ben "Putain!"


translate french debiles20_d3c96603:


    mac "Et là, ben il a choppé sa couleur, t'inquiète pas!"


translate french debiles20_ea8b6fa1:


    mac "Et mes As craqués encore une fois!"


translate french debiles20_0b75be13_2:


    ben "Putain!"


translate french debiles20_1300bd7d:


    mac "Ouais! Je te jure, ces gars savent pas jouer!"


translate french debiles20_a01646a5:


    ben "Ouais, pareil moi l'autre jour..."


translate french debiles20_e9adca6b:


    "Ben alors?" with hpunch


translate french debiles20_dd5d68f3:


    d "Hein?"


translate french debiles20_983ef4f8:


    s "On n'attend pas Steven?"


translate french debiles20_5ee1a6cf:


    "Ouais!" with hpunch


translate french debiles20_27a3722f:


    s "Le roi de la fête est là!"


translate french debiles20_5ee1a6cf_1:


    "Ouais!" with hpunch


translate french debiles20_825642f5:


    d "Le roi de la fête?"


translate french debiles20_84f4497b:


    sofia "Ouais, le gars se croit chaud comme la braise..."


translate french debiles20_dd5d68f3_1:


    d "Euh?"


translate french debiles20_7bdad836:


    sofia "En gros ils organisent leur soirée chaque année et pensent que c'est la meilleure soirée que l'on puisse faire..."


translate french debiles20_18000c7a:


    sofia "Mais à la fin, ils finissent toujours entre eux, n'organisent rien, boivent, et se finissent dans le canapé..."


translate french debiles20_a99b3fad:


    sofia "Les rois de la fête."


translate french debiles20_9e386227:


    d "Mouais..."


translate french debiles20_d6f6da9b:


    s "Allons montrer à ces filles ce que c'est qu'un vrai homme!"


translate french debiles20_5ee1a6cf_2:


    "Ouais!" with hpunch


translate french blue20_5eee312c:


    d "Tu fais quoi là toute seule?"


translate french blue20_9d28e022:


    sofia "Je prends un peu l'air avant que tout le monde s'excite!"


translate french blue20_baffc8cb:


    d "S'excitent?"


translate french blue20_5e9e01cf:


    sofia "Oui, tu sais. Les jeux, l'alcool..."


translate french blue20_efd9aaae:


    d "T'aimes pas ça?"


translate french blue20_ef5e272b:


    sofia "Si, si... Mais j'aime bien avoir mes moments de temps en temps."


translate french blue20_3655435f:


    d "Il y a quelque chose qui te perturbe?"


translate french blue20_08958f33:


    sofia "Ah, euh..."


translate french blue20_4876fdd7:


    dpense "Elle est clairement troublée par quelque chose."


translate french blue20_6fb8f6cb:


    dpense "Je devrais peut être lui dire quelque chose pour qu'elle se sente mieux."


translate french blue20_4b57eba2:


    d "Je ne suis pas sûr de bien comprendre pourquoi tu as décidé de ne plus porter ton maquillage bleu mais ça va te va très bien sans."


translate french blue20_36f6f4f8:


    sofia "Tu le penses vraiment?"


translate french blue20_75efb952:


    d "Oui... Je sais pas comment dire, mais c'est comme si quelque chose en toi avait changé."


translate french blue20_08809f48:


    sofia "Oui... Enfin, pas encore."


translate french blue20_b7ba2ada:


    d "Et tu vas changer tes cheveux aussi comme les autres?"


translate french blue20_165ba7f8:


    sofia "Euh... J'ai pas pensé à ça encore."


translate french blue20_0e1ed2f6:


    d "Nan mais je déconne! C'est juste que toutes les filles semblent vouloir changer, et je pensais que tu voudrais te démarquer de..."


translate french blue20_e69d927e:


    sofia "Ma soeur..."


translate french blue20_1ecede8d:


    d "Euh... Non, j'allais dire des autres, mais..."


translate french blue20_4f768d0a:


    sofia "Oh. Oui. Je ne sais pas."


translate french blue20_fba1bb14:


    sofia "Je vais aller faire un tour dans la salle de bain avant que ça commence. Prendre une minute pour nettoyer ma tête tu vois?"


translate french blue20_1cda50cf:


    d "Ah? Okay!"


translate french blue20_97785a33:


    d "A plus tard alors?"


translate french blue20_231069d2:


    sofia "Oui, à plus tard!"


translate french blue20_2476d037:


    dpense "Elle a un problème avec sa soeur?"


translate french blue20_d6acb73c:


    dpense "Bizarre..."


translate french red20_b983e6dc:


    beth "TU veux jouer?"


translate french red20_49f5c417:


    d "T'as entendu le chef?"


translate french red20_55418a01:


    beth "Ouais, mais là c'est pas un problème. Il ne peut rien me refuser. Et certainement pas avoir quelqu'un à table pour jouer."


translate french red20_b7783d6e:


    beth "Alors, tu veux jouer?"


translate french red20_48ae9e3d:


    d "Ouais, ça serait sympa!"


translate french red20_655febea:


    beth "Cool! Bon écoute, je vais mettre 1000$ sur la table pour toi."


translate french red20_5731001e:


    beth "Si tu gagnes, tu me rends les 1000$ et tu gardes le reste."


translate french red20_b836592c:


    beth "Si tu perds... Tu devras me rembourser d'une autre façon."


translate french red20_f36a5ff4:


    d "Okay, ça me va!"


translate french red20_f26b2c0b:


    beth "Parfait!"


translate french red20_c6b71068:


    d "Non, c'est bon."


translate french red20_1e03c0a4:


    d "Pas envie de traîner avec des gars comme ça..."


translate french red20_9d3c5279:


    beth "T'es sûr? Je peux allonger l'argent si t'as besoin!"


translate french red20_f337b71d:


    d "Non non c'est bon."


translate french red20_b811790e:


    beth "Okay!"


translate french emerick20_bdd5c9e4:


    emerick "On dirait que tu t'es trouvé un ange-gardien..."


translate french emerick20_cd4e2af9:


    emerick "Bon... Tu peux jouer avec nous si tu veux."


translate french emerick20_56454df3:


    emerick "On joue pendant deux heures, tu peux pas partir tant que c'est pas fini!"


translate french emerick20_6b777721:


    emerick "Tu es sûr que tu veux jouer contre nous?"


translate french emerick20_80bb8032:


    d "Ouais. J'ai hâte de voir si vous êtes bons."


translate french emerick20_8cbc8217:


    emerick "Sois pas trop sûr de toi..."


translate french emerick20_d86ce540:


    d "EUh... Euh... Euh... Nan!"


translate french emerick20_d598134a:


    d "Je veux pas passer la soirée ici."


translate french emerick20_0093a926:


    emerick "Alors pourquoi tu nous fait perdre notre temps?"


translate french kira20poker_3feab173:


    d "Kira... Tu pourrais m'aider avec ton cousin?"


translate french kira20poker_271d1f62:


    kira "Hein?"


translate french kira20poker_148ff3e5:


    d "Il me laisse pas jouer au poker avec lui et ses gars."


translate french kira20poker_afa7eb49:


    kira "Oh?"


translate french kira20poker_e0facd95:


    kira "T'inquiètes, je lui dit que c'est moi qui t'invite."


translate french kira20poker_b7378a12:


    kira "Il ne peut pas refuser."


translate french kira20poker_227865d4:


    d "T'es sûre?"


translate french kira20poker_9b0d0415:


    kira "Oui oui, vas y je te le dis!"


translate french kira20poker_b01d0032:


    d "Oh, super, merci!"

translate french strings:


    old "Meet me in the bathroom up there"
    new "Rejoins moi dans la salle de bain là haut"


    old "Um... Why?"
    new "Heu... Pourquoi?"


    old "Hurry up... We don't have much time..."
    new "Dépêche-toi... On a pas beaucoup de temps..."


    old "Accept[TEMP1!t]"
    new "Accepter[TEMP1!t]"


    old "Decline[TEMP2!t]"
    new "Refuser[TEMP2!t]"


    old "Okay... I'll be right there."
    new "Okay... J'arrive."


    old "I'm not sure if that's a good idea..."
    new "Je suis pas sûr que ce soit une bonne idée..."


    old "I understand... Maybe some other time then."
    new "D'accord... Peut être une autre fois alors."


    old "Yes (Advance time and ends free-roam)"
    new "Oui (Avancer le temps et terminer le free-roam)"


    old "No, maybe later..."
    new "Non, peut être plus tard..."




translate french gracemadison20_70f6dc22:


    grace "Haha! J'imagine! En plus, avec ton frère qui te donne plus de travail qu'autre chose!"




translate french kira20_42ec4458:


    kira "Elle a des formes parfaites, un corps idéal et une jolie tête."


translate french kira20_552d5dfd:


    d "Ca me paraît pas mal."




translate french emerick20_6f369099:


    emerick "Quelqu'un a décidé de se porter garant pour toi..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
