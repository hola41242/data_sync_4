

translate french strings:


    old "Progress: [done]/[total] scenes"
    new "Progress: [done]/[total] scenes"


    old "Quick Travel:"
    new "Voyage rapide:"



translate french strings:


    old "🌳 Garden"
    new "🌳 Jardin"


    old "🎲 Poker Room"
    new "🎲 Salle de poker"


    old "⬆️ Upstairs"
    new "⬆️ Etage"


    old "🏠 Back to Living Room"
    new "🏠 Retour au salon"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
