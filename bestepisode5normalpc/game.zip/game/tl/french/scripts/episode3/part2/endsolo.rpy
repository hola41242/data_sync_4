


translate french endsolo_514498de:


    dpense "Bon ben... Me voilà de retour dans ma chambre..."


translate french endsolo_6ef229a3:


    dpense "C'est pas comme ça que j'avais imaginé ma fin de soirée mais bon..."


translate french endsolo_e38a6085:


    dpense "Demain j'aurais encore plein de choses à faire et à voir..."


translate french endsolo_33e62c6e:


    dpense "Accompagner Julia à l'hôpital..."


translate french endsolo_7791dddf:


    dpense "Rejoindre Gabriella au musée..."


translate french endsolo_be37121e:


    dpense "Participer à ce fameux dîner avec Madison..."


translate french endsolo_fe3f28ed:


    dpense "Dans tous les cas, cette soirée était vraiment intéressante."


translate french endsolo_49647293:


    dpense "Cette Kira est intrigante..."


translate french endsolo_1cfe3d36:


    dpense "Par contre j'ai toujours pas de nouvelles d'Elise..."


translate french endsolo_1ea70810:


    dpense "Ca ne lui ressemble pas..."


translate french endsolo_517c34b4:


    dpense "On verra bien ce qui va se passer..."


translate french endsolo_43441124:


    orushi "Simmons! C'est Orushi!"


translate french endsolo_29a690d4:


    orushi "Comment ça se passe avec les tiens?"


translate french endsolo_0ba913d0:


    "On avance..."


translate french endsolo_6c05280d:


    "Quasiment prêts pour la phase 2."


translate french endsolo_49eecb65:


    orushi "Déjà?"


translate french endsolo_334961ea:


    "Oui... Et de ton côté?"


translate french endsolo_ef8e4566:


    orushi "On va accélérer les choses pour être prêts."


translate french endsolo_2474301e:


    "Et les autres?"


translate french endsolo_54f4af4a:


    orushi "Pareil. Tout le monde est à peu près au même niveau..."


translate french endsolo_88825eb1:


    "Parfait!"


translate french endsolo_656c418e:


    orushi "Okay. Bon je te rapelle pour la prochaine phase."


translate french endsolo_f19f8ae6:


    "Da!"




translate french endsolo_220827a5:


    dpense "Une rare chance d'avoir un dîner avec la famille de Madison."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
