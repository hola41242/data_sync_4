


translate french fingraceep3_122be50a:


    grace "Merci de m'avoir accompagné dans ma chambre, [name]. Je me suis vraiment bien amusée ce soir."


translate french fingraceep3_426cd657:


    d "Moi aussi, Grace. C'était une chouette soirée."


translate french fingraceep3_4b3a0964:


    grace "Alors, heu, c'est ma chambre. C'est pas grand chose, mais j'y suis à l'aise."


translate french fingraceep3_0e9f56a6:


    dpense "Grace est nerveuse. C'est trop mignon."


translate french fingraceep3_b0f25365:


    grace "Je vais juste me changer pour être plus confortable. Mets toi à l'aise."


translate french fingraceep3_815640c8:


    d "Prends ton temps."


translate french fingraceep3_9e3f7bee:


    dpense "J'arrive pas à croire que je sois dans sa chambre. La soirée a été géniale jusque là et maintenant... Il faut que je reste calme."


translate french fingraceep3_197417a0:


    grace "J'espère que c'est pas un peu trop..." with vpunch


translate french fingraceep3_886abaf6:


    d "Wow!"


translate french fingraceep3_4586d679:


    d "Grace... Tu es... Magnifique."


translate french fingraceep3_5d0f5cab:


    dpense "Cette lingerie est à tomber! La façon dont ça moule son corps... Reste concentré."


translate french fingraceep3_ba62c79b:


    dpense "Sa confiance est aveuglante. Je suis à la fois excité et limite apeuré! Faut pas que je me rate! "


translate french fingraceep3_a09e0834:


    grace "Je suis contente que tu aime. J'avais peur que ce soit un peu too much."


translate french fingraceep3_52143285:


    d "C'est parfait. Tu es incroyable."


translate french fingraceep3_f1edd5b8:


    grace "Je peux m'asseoir sur toi?"


translate french fingraceep3_08c3c4ca:


    d "Bien sûr!"


translate french fingraceep3_d9d93097:


    dpense "Mon coeur bat à mille à l'heure. Reste calme."


translate french fingraceep3_056e239a:


    dpense "So lit est tellement tentant, mais vaut mieux pas rusher les choses et lui faire peur."


translate french fingraceep3_93e3c736:


    grace "Tu sais, j'ai jamais vraiment été seule dans ma chambre avec un garçon auparavant."


translate french fingraceep3_2813b2b2:


    d "Je suis honoré d'être le premier."


translate french fingraceep3_32881572:


    dpense "Elle est si proche... Je peux sentir son parfum. C'est enivrant."


translate french fingraceep3_549668d3:


    dpense "Je dois me contrôler. Ne pas la faire fuir."


translate french fingraceep3_67c2a699:


    grace "Tu sais... Tu es le seul avec qui je voulais vraiment être ce soir..."


translate french fingraceep3_b59160c0:


    d "Grace..."


translate french fingraceep3_b397b53c:


    dpense "Entendre me fait tellement plaisir. Elle le veut vraiment elle aussi."


translate french fingraceep3_75ad9296:


    grace "Est ce qu'on peut... s'embrasser encore?"


translate french fingraceep3_ec9ea850:


    d "J'adorerais ça."


translate french fingraceep3_b76665a2:


    grace "Hummm. Tes baisers me rendent tellement chaude à l'intérieur."


translate french fingraceep3_e15e14e0:


    dpense "Ses lèvres sont si douces, et la façon dont elle répond à mes baisers... C'est comme si elle était faite pour ça."


translate french fingraceep3_28a5e0bb:


    dpense "Chaque baiser semble être la promesse de quelque chose de plus en plus intense."


translate french fingraceep3_820b5315:


    grace "J'aime sentir le contact de tes mains sur mon corps... C'est comme si tu savais exactement ce dont j'ai besoin."


translate french fingraceep3_a35d76bb:


    grace "Oh, ça fait tellement de bien..."


translate french fingraceep3_78709cf8:


    dpense "Sa peau est incroyablement réceptive. La façon dont elle réagit à mes caresses me rend fou."


translate french fingraceep3_0dceca55:


    grace "Oh..."


translate french fingraceep3_c86f948f:


    dpense "J'ai envie d'explorer chaque centimètre de son corps, mais je dois rester dans la douceur. C'est sa première fois. "


translate french fingraceep3_a771222e:


    d "Grace, est ce que je peux... ?"


translate french fingraceep3_b449a8b0:


    grace "Oui, vas-y."


translate french fingraceep3_378a05b5:


    d "Laisse moi prendre soin de toi."


translate french fingraceep3_dc39bf28:


    dpense "Je dois prendre mon temps, pour rendre ça inoubliable pour elle."


translate french fingraceep3_0e6387d4:


    grace "Okay... Je suis un peu nerveuse."


translate french fingraceep3_b28a10e6:


    d "Ne t'inquiète pas, juste concentre toi sur ce que tu ressens."


translate french fingraceep3_db7c8734:


    d "Comment te sens-tu?"


translate french fingraceep3_af9d73bb:


    grace "Oh... C'est merveilleux. Tes mains sont si chaudes."


translate french fingraceep3_e568dcd6:


    dpense "Sa peau est électrique. Je peux la sentir se relâcher sous mes doigts."


translate french fingraceep3_4f161a1c:


    grace "Ahhh..." with hpunch


translate french fingraceep3_5c868772:


    grace "Hummm..."


translate french fingraceep3_d743f1b7:


    dpense "Elle mouille de plus en plus..."


translate french fingraceep3_a4adae84:


    d "Et comme ça?"


translate french fingraceep3_119475ec:


    grace "Doucement... S'il te plaît..."


translate french fingraceep3_a66ca034:


    grace "Oh mon dieu!" with hpunch


translate french fingraceep3_62f474cf:


    grace "Tes doigts me font tellement de bien! C'est comme si ils allaient là où mon esprit les invitait!"


translate french fingraceep3_26cbeda5:


    dpense "Elle doit ressentir des choses qu'elle n'a jamais ressenti."


translate french fingraceep3_a41e6e7a:


    d "Alors maintenant, t'as juste à prendre plaisir avec ça..."


translate french fingraceep3_0dceca55_1:


    grace "Oh...."


translate french fingraceep3_59945c86:


    grace "Oh mon dieu..."


translate french fingraceep3_c7c1e31e:


    grace "[name]..."


translate french fingraceep3_76991c79:


    grace "C'est..."


translate french fingraceep3_291ded06:


    grace "Fabuleux..."


translate french fingraceep3_05caf10b:


    dpense "Elle a un goût tellement ennivrant. ET la façon dont sa chatte se colle à ma langue... Ca me rend fou."


translate french fingraceep3_2782f4db:


    grace "J'aurais jamais pensé ressentir quelque chose comme ça... C'est comme si ton mon corps se mettait à vivre."


translate french fingraceep3_423e395a:


    dpense "Ses gémissements sont comme un récital dans mes oreilles. Je veux tout lui donner."


translate french fingraceep3_2a70dac6:


    grace "Ne t'arrête pas... S'il te plaît. Ne t'arrête pas..."


translate french fingraceep3_a7e481d4:


    dpense "Je sens ses tremblements devenir de plus en plus intenses. Je dois lui faire ressentir chaque sensation, chaque moment."


translate french fingraceep3_3a697b05:


    grace "Je... Je crois que... Je... Je vais... Ahhhh! "


translate french fingraceep3_e54511e0:


    dpense "Elle est tellement mouillée, je pense qu'elle va bientôt jouir."


translate french fingraceep3_3fed4df0:


    grace "AHHHHHHHHHHH!"


translate french fingraceep3_e34e7f8a:


    grace "MON DIEUUUUUUUUUUUUUUUUUUUU!"


translate french fingraceep3_0ee90716:


    grace "Oh mon.... Je ne peux... C'était... Wow..."


translate french fingraceep3_3db97e94:


    dpense "La voir comme ça, complètement satisfaite... C'est fabuleux."


translate french fingraceep3_4272566a:


    dpense "Je ne me suis jamais senti aussi proche de quelqu'un de ma vie."


translate french fingraceep3_2b6bfbea:


    grace "Je... Je crois que j'ai un peu trop bû ce soir. Je me sens nauséeuse...."


translate french fingraceep3_c3411169:


    d "Tout va bien Grace. C'était parfait ce soir."


translate french fingraceep3_2fda0097:


    dpense "J'aurais bien voulu plus, mais je crois qu'elle est encore sous le choc. Je dois être patient."


translate french fingraceep3_2292c0d6:


    grace "J'i vraiment aimé ça, mais je crois qu'il faut que je reste comme ça un petit peu. Mon estomac a l'air de pas apprécier."


translate french fingraceep3_078e1e76:


    d "Ne t'inquiète pas. Restons juste allongés."


translate french fingraceep3_07f5d822:


    dpense "Le tenir dans mes bras comme ça... Je ne veux pas que ce moment s'arrête."


translate french fingraceep3_84a6230f:


    dpense "Son souffle, sa douceur... Je me sens si proche d'elle."


translate french fingraceep3_c7bfadaa:


    grace "Merci [name]. C'était la meilleure nuit de ma vie."


translate french fingraceep3_06c6f93b:


    d "La mienne aussi, Grace. La mienne aussi."


translate french fingraceep3_56ec7c6e:


    dpense "Sa gratitude est touchante. Je veux la protéger, la rendre heureuse."


translate french fingraceep3_a28a7494:


    grace "Tu devrais y aller maintenant, ma mère ne devrait pas tarder à rentrer et je ne veux pas que tu aies des problèmes avec elle..."


translate french fingraceep3_0e1666ec:


    d "Tu as raison..."


translate french fingraceep3_6049f48d:


    dpense "Je peux sentir sa respiration ralentir pendant qu'elle s'endort dans mes bras. C'est parfait."


translate french fingraceep3_d8d34b7d:


    dpense "Je dois me rappeler de ce moment, enregistrer chaque détail."


translate french fingraceep3_8099769b:


    d "Bonne nuit, Grace."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
