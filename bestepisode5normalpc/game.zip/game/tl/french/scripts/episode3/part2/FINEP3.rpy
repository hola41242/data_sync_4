


translate french FINEP3_285f8ea7:


    "Veuillez sauvegarder ici..."


translate french FINEP3_8636bfb0:


    gaby "Et qu'est ce qu'un gars comme toi ferait d'une femme comme moi?"


translate french FINEP3_aee41bbd:


    ji "Maman..."


translate french FINEP3_9b55d749:


    drew "Vous avez une nouvelle épreuve cette après-midi."


translate french FINEP3_f8acb000:


    drew "Vous devez choisir votre partenaire pour celle-ci [name]."


translate french FINEP3_c8f69174:


    mad "Okay... On ne peut pas perdre ce match!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
