


translate french ep320h_2d397f37:


    emerick "Alors les gars? Prêts pour passer une soirée avec moi?"


translate french ep320h_32390969:


    "Ouais!"


translate french ep320h_5b232966:


    emerick "Frenchie! Tu sais comment t'habiller maintenant?"


translate french ep320h_328830e7:


    emerick "L'habit ne fait pas le moine tu sais?"


translate french ep320h_7e51d70c:


    hec "Tiens vlà le chevalier blanc..."


translate french ep320h_6a2dc343:


    hec "T'as pas ta Pinkie avec toi?"


translate french ep320h_b6fde834:


    mad "Tu devrais juste fermer ta gueule Hector, où je vais te faire passer l'envie de l'ouvrir!"


translate french ep320h_ec2abea6:


    emerick "Et bien, et bien... Madison qui défend l'opprimée..."


translate french ep320h_48df3ce2:


    julia "On aura tout vu..."


translate french ep320h_4da915b8:


    julia "Mais merci Madison... J'apprécie le soutien."


translate french ep320h_d8adca3a:


    d "Heu... Faut que tu me dises un truc..."


translate french ep320h_2307991b:


    ruby "Quoi?"


translate french ep320h_cbbc64d1:


    d "Vous avez tous un problème avec vos cheveux ou quoi?"


translate french ep320h_6b0b0af2:


    ruby "Hein?"


translate french ep320h_e513a108:


    d "Ben... Toi, Madison, Julia... Bientôt Grace va avoir les cheveux bleus..."


translate french ep320h_33793f20:


    ruby "On ne t'as jamais dit que souvent femme varie?"


translate french ep320h_dd5d68f3:


    d "Comment ça?"


translate french ep320h_b8f092fd:


    ruby "Ben oui... Si quelque chose... Ou quelqu'un cause un changement chez une femme..."


translate french ep320h_eb0cdf0c:


    ruby "Ben elle change!"


translate french ep320h_51dd6509:


    d "Et qu'est ce qui vous fait changer comme ça chacune votre tour?"


translate french ep320h_85e25575:


    ruby "Devines gros bêta!"


translate french ep320h_ccf9fa2a:


    ruby "Et puis y'à aussi un effet de groupe!"


translate french ep320h_0e7c633f:


    ruby "Un peu comme la synchronisation de nos règles..."


translate french ep320h_431c81ae:


    d "Ruby..." with hpunch


translate french ep320h_2307991b_1:


    ruby "Ben quoi?"


translate french ep320h_70104ecf:


    emerick "Allez! Y'à une table qui nous attend les gars!"


translate french ep320h_32390969_1:


    "Ouais!"


translate french ep320h_48ca22b2:


    emerick "Bien sûr, je ne parlais pas pour toi, Frenchie."


translate french ep320h_1523fe20:


    d "..."


translate french ep320h_0a3b9a9e:


    "T'as raison, cher cousin, va t'enfermer avec ta bande couilles molles!" with vpunch


translate french ep320h_3283d5fb:


    d "Qui..."


translate french ep320h_bc430bec:


    "Et tant que t'y es, essaie de ne pas trop les arnaquer!"


translate french ep320h_65dd16d6:


    "Les pauvres, déjà qu'ils ont pas de dignité, si tu leur prend leur argent..."


translate french ep320h_21ef69aa:


    ruby "La Princesse est arrivée..."


translate french ep320h_74d8ea2d:


    d "La Princesse?"


translate french ep320h_db6ebde1:


    ruby "Oui... Laisse moi te présenter..."


translate french ep320h_8a332571:


    ruby "Kira Orushi."


translate french ep320h_d52ff3a3:


    d "Orushi?" with hpunch


translate french ep320h_88407b4c:


    ruby "Ouaip... Sa fille."


translate french ep320h_8e04f38b:


    ruby "C'est la cousine d'Emerick et... Comment dire..."


translate french ep320h_baf02865:


    ruby "Là où Kira passe... Emerick trépasse."


translate french ep320h_515638be:


    ruby "Si Emerick joue le grand avec son influence..."


translate french ep320h_b45b2506:


    ruby "Kira a juste besoin de lever le petit doigt pour qu'il soit virer de la place."


translate french ep320h_3deed7ed:


    d "Sérieux?"


translate french ep320h_4bb3aaa2:


    ruby "Oui oui... Regarde les s'en aller..."


translate french ep320h_afb43a4a:


    ruby "On dirait des chiens battus..."


translate french ep320h_4e9c7294:


    d "Mais pourquoi..."


translate french ep320h_3d792aab:


    ruby "C'est une des personnes les plus puissantes de tout le pays..."


translate french ep320h_a1e5b9c0:


    ruby "Influenceuse, puissance, la compagnie de son père dont elle va hériter..."


translate french ep320h_da574b0b:


    ruby "Et une tonne de business qu'elle gère divinement bien."


translate french ep320h_09de2a72:


    ruby "Elle contrôle son image parfaitement..."


translate french ep320h_ea0a923f:


    ruby "Et..."


translate french ep320h_12e4da9d:


    kira "Et je ne me suis pas encore présentée!"


translate french ep320h_9cfd5489:


    kira "Je suis Kira. Bienvenue dans notre pays!"


translate french ep320h_2969bbf3:


    kira "Encore désolée pour tout à l'heure sur le terrain..."


translate french ep320h_1567a5c4:


    kira "Mais je voulais te bouger un peu... Je suis sûr que tu peux faire mieux."


translate french ep320h_c9ceb4e6:


    kira "Bon! On profites de cette soirée?"


translate french ep320h_ee39177b:


    ruby "Heu... Oui..."


translate french ep320h_82e6f175:


    kira "T'inquiètes pas Ruby, tout va bien se passer! Et j'ai confiance en toi, je suis sûre que tu as préparé plein de choses pour nous tous!"


translate french ep320h_b528cca1:


    ruby "Oui oui! Alors à chaque heure y'aura des activités dans divers endroits de la maison."


translate french ep320h_8bbb0f7b:


    ruby "Vous avez juste à profiter en vous baladant!"


translate french ep320h_fd9b1315:


    ruby "Et si vous savez pas quoi faire où que vous êtes perdus..."


translate french ep320h_52f91e69:


    ruby "Venez me voir!"


translate french ep320h_12346ed5:


    kira "Excellent! J'ai déjà hâte de voir tout ça!"


translate french ep320h_93d865fe:


    grace "Bon ben je crois qu'on peut lancer cette soirée?"


translate french ep320h_5ee1a6cf:


    "Ouais!" with hpunch

translate french strings:


    old "8:00 PM"
    new "20:00"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
