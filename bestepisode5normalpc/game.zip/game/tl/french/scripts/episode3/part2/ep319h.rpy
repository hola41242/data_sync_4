


translate french ep319h_288e63cd:


    dpense "Y'à déjà du monde..."


translate french ep319h_5afe9333:


    dpense "Et tous bien habillés..."


translate french ep319h_13a9fa4a:


    dpense "C'est qui cette fille qui..."


translate french ep319h_98025551:


    d "Ruby???"


translate french ep319h_8ce58592:


    dpense "C'est vraiment Ruby? Elle est si... différente..."


translate french ep319h_29939e59:


    ruby "Oui? Oh, t'es déjà là?"


translate french ep319h_fefd1e11:


    d "Wow! T'es magnifique!"


translate french ep319h_0646292d:


    dpense "J'y crois pas... Elle est si belle ce soir."


translate french ep319h_5f32c47f:


    ruby "Oh?"


translate french ep319h_a526621d:


    ruby "Ben... Merci!"


translate french ep319h_ec88a91b:


    ruby "Bon, pour ce soir, on a préparé pas mal de choses. J'espère que tu t'ennuieras pas!"


translate french ep319h_ae9dbbe9:


    d "Qu'est ce que vous avez prévus exactement?"


translate french ep319h_49729cc2:


    dpense "J'espère que ce sera pas des trucs embarassants..."


translate french ep319h_0ca74eee:


    ruby "Tu verras bien!"


translate french ep319h_d0c288ce:


    ruby "En gros, toute la soirée est divisée en heures."


translate french ep319h_5c4a411a:


    ruby "Et à chaque heure, j'ai organisé différents jeux."


translate french ep319h_4bec68d4:


    ruby "Tu peux nous rejoindre, ou pas. C'est comme tu le sens."


translate french ep319h_fafccd1b:


    dpense "Des jeux? Ca peut être marrant... Ou un vrai désastre..."


translate french ep319h_bb1569ab:


    ruby "Je te force à rien! Et puis t'es libre de te balader dans la maison."


translate french ep319h_1af2f630:


    ruby "Comme d'habitude dans ces soirées, tu es susceptible de rencontrer des gens un peu partout..."


translate french ep319h_255a7214:


    ruby "Y'en a même qui seront dans le garage à jouer au poker, alors hésites pas à te balader!"


translate french ep319h_0a1f2fff:


    ruby "Mais j'espère te voir à un de mes jeux!"


translate french ep319h_71621c21:


    dpense "Je devrais au moins essayer pour voir ce que ça donne..."


translate french ep319h_dc5092d9:


    d "Bon, je suppose qu'il vaut mieux que j'aille me préparer alors..."


translate french ep319h_b2c71a98:


    dpense "Va falloir se faire beau..."


translate french ep319h_4a431b19:


    ruby "Grace doit t'attendre à l'intérieur."


translate french ep319h_79e4de0e:


    ruby "Va la voir! Elle va te dire où aller te changer! "


translate french ep319h_15e6cd4c:


    d "Okay. A tout à l'heure?"


translate french ep319h_153d7992:


    ruby "A tout à l'heure!"


translate french ep319h_0cdc2a05:


    dpense "Bon j'espère que je vais pas me râter..."


translate french ep319h_0d6e6088:


    d "Ce que tu peux être belle..."


translate french ep319h_fb1b5575:


    grace "Merci!"


translate french ep319h_62b19db8:


    dpense "J'ai tellement envie de l'embrasser, mais il ne faut pas risquer d'être vus..."


translate french ep319h_dd8da065:


    grace "On va pas pouvoir le faire beaucoup quand tout le monde sera là."


translate french ep319h_9f52115e:


    grace "Alors je prends le rique maintenant..."


translate french ep319h_8034db0c:


    d "Oui, essayons de rester discrets."


translate french ep319h_410930f8:


    dpense "Ses lèvres sont si douces... Ce moment est trop court."


translate french ep319h_3dbd89d8:


    d "Ca va être dûr de ne pas te sauter dessus pendant la soirée!"


translate french ep319h_96c87c04:


    grace "Oui..."


translate french ep319h_8d61d8e6:


    dpense "J'ai tellement envie d'elle, mais on doit faire attention..."


translate french ep319h_044e92c2:


    d "Attention, quelqu'un pourrait nous voir."


translate french ep319h_2e68ce35:


    d "Vaut mieux pas tenter le diable."


translate french ep319h_e2691be7:


    grace "Oui, tu as raison."


translate french ep319h_429f8aa7:


    dpense "Je déteste l'idée de nous restreindre, mais c'est nécessaire..."


translate french ep319h_228cc50b:


    grace "Pour cette soirée, je te laisse t'amuser comme tu veux."


translate french ep319h_ea019296:


    dpense "Comme je veux? Ca peut être marrant..."


translate french ep319h_0765a666:


    grace "De toute façon, j'ai pas trop le choix."


translate french ep319h_cde65b21:


    d "Tout ce que je veux?"


translate french ep319h_da9605d7:


    grace "Dans la limite du raisonnable bien sûr!"


translate french ep319h_4fef3683:


    grace "Mais je sais comment fonctionne Ruby et si tu finis par devoir embrasser une fille..."


translate french ep319h_518dcdae:


    grace "Ou danser collé-serré avec une uatre..."


translate french ep319h_a89eba91:


    grace "Ruby a prévu des gages donc je ne t'en tiendrais pas rigueur."


translate french ep319h_4fa86eb0:


    grace "Plus tu agis comme un mec célib..."


translate french ep319h_b97bc95a:


    grace "Moins les gens auront de doutes à notre propos."


translate french ep319h_d53904b1:


    d "D'accord."


translate french ep319h_b330e6ff:


    dpense "Jouer au célibataire peut être un peu dangereux, mais bon si c'est pour la bonne cause..."


translate french ep319h_cf274390:


    grace "Mais après la fête, tu es tout à moi!"


translate french ep319h_435babe9:


    dpense "J'ai déjà hâte..."


translate french ep319h_6181ffc8:


    d "Tu sais si Rouge a laissé quelque chose pour moi?"


translate french ep319h_4b78ee47:


    grace "Oui, elle a laissé ton costume dans la chambre en haut."


translate french ep319h_39f0500c:


    grace "Monte les escaliers, prends la première porte à gauche, et ça devrait être dans l'armoire."


translate french ep319h_659c76cf:


    d "Okay! Merci!"


translate french ep319h_fef54646:


    dpense "J'espère que le costume sera beau..."


translate french ep319h_5704be0d:


    grace "Non, mais ne t'inquiète pas."


translate french ep319h_685bd6f6:


    grace "Monte dans la chambre à gauche."


translate french ep319h_194ad930:


    grace "Tu peux prendre le costume dans l'armoire."


translate french ep319h_d24354b3:


    grace "C'est celui à mon père. Je pense qu'il t'ira parfaitement."


translate french ep319h_73e5a328:


    d "Merci beaucoup, Grace!"


translate french ep319h_f78eebb7:


    dpense "J'espère qu'il m'ira..."


translate french ep319h_86e4c7aa:


    grace "De rien! Allez vas-y!"


translate french ep319h_e65cbcaf:


    dpense "Il est temps de se préparer pour ce qui nous attend..."


translate french ep319h_2928c85d:


    grace "J'aurais peut être dû le prévenir pour Madison..."


translate french ep319hmadison_faeed9e5:


    dpense "Ces jambes..."


translate french ep319hmadison_7b470d71:


    dpense "Et ce corps... Elle a dû travailler dûr pour avoir cette silhouette."


translate french ep319hmadison_2cceb6e2:


    d "Madison?"


translate french ep319hmadison_95b89350:


    dpense "Qu'est ce qu'elle fait là?"


translate french ep319hmadison_e9d6e7e4:


    mad "Oui?"


translate french ep319hmadison_4058aafc:


    mad "Oh! C'est toi?"


translate french ep319hmadison_005532b2:


    d "Désolé... Je cherchais mon costume mais je peux revenir plus tard et..."


translate french ep319hmadison_15923c5d:


    mad "Non non. Puisque t'es là, aide-moi à mettre mon collier."


translate french ep319hmadison_4974962b:


    d "Celui sur le lit là?"


translate french ep319hmadison_548cfe7d:


    mad "T'en vois un autre?"


translate french ep319hmadison_a67f284e:


    d "Hummmmm... Non..."


translate french ep319hmadison_7bcc50f4:


    d "Okay..."


translate french ep319hmadison_b338417f:


    d "Tu es vraiment étincelante."


translate french ep319hmadison_80856c0f:


    dpense "Sa beauté est indéniable, mais c'est sa force qui me captive le plus."


translate french ep319hmadison_9e40f1b6:


    mad "Tu trembles."


translate french ep319hmadison_2ce96c5a:


    d "Ouais... J'ai pas pour habitude de toucher une si belle femme tous les jours..."


translate french ep319hmadison_c456a93d:


    dpense "Elle doit penser que je suis comme les autres. Il fautr lui montrer que je suis différent."


translate french ep319hmadison_83ae8453:


    mad "Je t'ai dit que c'était juste pour une fois..."


translate french ep319hmadison_5db0af98:


    d "Je sais."


translate french ep319hmadison_4e845f8a:


    dpense "Mais chaque moment que je passe avec elle est un cadeau que j'ai l'impression ne pas mériter."


translate french ep319hmadison_8b44f43b:


    mad "Et ça ne doit pas se reproduire..."


translate french ep319hmadison_d806887a:


    mad "Même si les désirs sont là..."


translate french ep319hmadison_e99f6e2f:


    dpense "Elle est tellement sur ses gardes. Qui pourrait la blâmer vu ce qu'elle doit gérer."


translate french ep319hmadison_d00f18cb:


    mad "On ne doit pas..."


translate french ep319hmadison_592754b5:


    mad "Continuer... "


translate french ep319hmadison_bb9305c7:


    mad "Mais surtout..."


translate french ep319hmadison_48a192a6:


    mad "Tu ne peux pas continuer comme ça..."


translate french ep319hmadison_1390acac:


    d "Je sais..."


translate french ep319hmadison_a6762298:


    mad "Et moi non plus."


translate french ep319hmadison_916964a1:


    dpense "Je dois être patient. Elle a besoin de temps pour avoir confiance à nouveau."


translate french ep319hmadison_336548fb:


    mad "Arrête de me dire des compliments..."


translate french ep319hmadison_40a2f618:


    d "Je ne peux pas..."


translate french ep319hmadison_de49923d:


    mad "Arrête de dire ce que j'ai besoin d'entendre..."


translate french ep319hmadison_dc3bdbc7:


    d "Je ne peux pas..."


translate french ep319hmadison_e6ceeb5a:


    mad "Arrête..."


translate french ep319hmadison_f0fd1cdb:


    dpense "Elle a peur de s'ouvrir. Il faut que je trouve un moyen de passer à travers ses barrières."


translate french ep319hmadison_a75434a9:


    mad "Les filles m'attendent!"


translate french ep319hmadison_81f6fd8e:


    dpense "Je sais qu'elle essaie juste de me repousser, mais je ne peux pas abandonner."


translate french ep319hmadison_bbfbae37:


    dpense "Bon ben j'ai plus qu'à gérer."


translate french ep319hsolo_bbfbae37:


    dpense "Bon ben j'ai plus qu'à gérer."

translate french strings:


    old "7:30 PM"
    new "19:30"


    old "Kiss her[TEMP1!t]"
    new "L'embrasser[TEMP1!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
