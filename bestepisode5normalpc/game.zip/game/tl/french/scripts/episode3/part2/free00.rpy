


translate french free00_6b4b0cf1:


    grace "Bon, les amis..."


translate french free00_679a2306:


    grace "Je suis désolée, mais j'ai promis à ma mère qu'on stopperait la soirée à minuit..."


translate french free00_98a03685:


    ruby "Oh, déjà?"


translate french free00_fc5d43b7:


    grace "Oui... Elle sera à la maison dans une heure, et vaut mieux que vous ne soyez pas là quand elle arrivera..."


translate french free00_34d48dad:


    ruby "Pas de soucis! Allez la troupe! C'est l'heure pour Cendrillon de se changer en femme de ménage!"


translate french free00_45282a81:


    grace "Tu restes avec moi?"


translate french free00_aa7a6ace:


    d "Bien sûr!"


translate french free00_6ff5bfb7:


    ruby "Allez, on y va!"


translate french free00_9cab7c01:


    d "Je vais rester avec Grace pour l'aider à nettoyer!"


translate french free00_dc303eb0:


    ruby "Ouais, ouais! Bien sûr! Nettoyer..."


translate french free00_5fb753fe:


    ruby "A demain!"


translate french free00_a6a8874f:


    mad "A demain tout le monde!"


translate french free00_0eaf48fc:


    d "A demain!"


translate french free00_c47afec2:


    grace "A demain!"


translate french free00_ac896290:


    d "Nan, je ne préfère pas..."


translate french free00_0dceca55:


    grace "Oh..."


translate french free00_13a7d26b:


    ruby "Allez, à demain!"


translate french free00_a6a8874f_1:


    mad "A demain tout le monde!"


translate french free00_0eaf48fc_1:


    d "A demain!"


translate french free00_c47afec2_1:


    grace "A demain!"


translate french free00_6ff5bfb7_1:


    ruby "Allez, on y va!"


translate french free00_a6a8874f_2:


    mad "A demain tout le monde!"


translate french free00_0eaf48fc_2:


    d "A demain!"


translate french free00_c47afec2_2:


    grace "A demain!"

translate french strings:


    old "00:00 AM"
    new "00:00"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
