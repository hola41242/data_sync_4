


translate french poker23_3e30ce77:


    mac "Putain, mais c'est pas possible!" with vpunch


translate french poker23_f8e333c6:


    emerick "Haha!"


translate french poker23_1f8b3bf4:


    mac "Encore craqué mes As!"


translate french poker23_5b43b033:


    mac "Je vais arrêter de les jouer!"


translate french poker23_46928cb5:


    emerick "C'est le jeu!"


translate french poker23_1f88ae2d:


    mac "OUais ouais... C'est de la merde!"


translate french poker23_1bd62c92:


    emerick "Plus que nous deux, Frenchie!"


translate french poker23_ff6a1930:


    dpense "J'ai réussi à monter à 2000$ avec les quelques mains que j'ai joué..."


translate french poker23_253a69ef:


    emerick "Allez, le heads-up!"


translate french poker23_3acfb082:


    beth "C'est ton tour de jouer [name]."


translate french poker23_96927053:


    d "Je suis."


translate french poker23_d89911e1:


    emerick "Hmmm."


translate french poker23_1594e8a3:


    emerick "Je relance."


translate french poker23_dc181045:


    d "Suivi."


translate french poker23_cbfb1f43:


    beth "Le board..."


translate french poker23_e394760b:


    beth "As de coeurs, Dix de piques, Roi de piques."


translate french poker23_61e98f59:


    d "Je mise 100."


translate french poker23_1594e8a3_1:


    emerick "Je relance."


translate french poker23_e48c9cb0:


    d "Hmm..."


translate french poker23_dc181045_1:


    d "Suivi."


translate french poker23_1ca60585:


    beth "La turn..."


translate french poker23_4e0f3456:


    beth "As de piques."


translate french poker23_e48c9cb0_1:


    d "Hmm..."


translate french poker23_0c16dfff:


    dpense "Kira m'a dit de jouer sur sa confiance..."


translate french poker23_7266d996:


    dpense "Comment je fais ça?"


translate french poker23_907fdef1:


    emerick "Alors, tu te décides?"


translate french poker23_1fc32aee:


    emerick "Tu vas pas passer quand même?"


translate french poker23_cddf2c53:


    dpense "Il me paraît très sûr de lui..."


translate french poker23_5e4910c9:


    d "Je me rapelle pas..."


translate french poker23_0ce9fdf0:


    d "Une couleur c'est mieux qu'une quinte ou pas?"


translate french poker23_f8e333c6_1:


    emerick "Haha!"


translate french poker23_1592616c:


    emerick "Oui!"


translate french poker23_242b94d5:


    emerick "Tu as l'une ou l'autre?"


translate french poker23_d5ee268c:


    d "Non, non, c'était juste pour savoir..."


translate french poker23_d89911e1_1:


    emerick "Hmmm..."


translate french poker23_6e8a688e:


    emerick "Ecoute, Frenchie. On va pas passer la nuit là!"


translate french poker23_7426abd6:


    emerick "Alors je te propose quelque chose!"


translate french poker23_c31b56fc:


    emerick "On y va all in et on voit qui gagne à la fin!"


translate french poker23_ec7e4047:


    emerick "Qu'est ce que t'en penses?"


translate french poker23_13bcf77c:


    emerick "Combien t'as? 2000?"


translate french poker23_fc6dea88:


    d "Ouais..."


translate french poker23_5bd579fe:


    emerick "Okay, je mets 2000 et c'est parti."


translate french poker23_f338cc08:


    d "Euh..."


translate french poker23_7bcc50f4:


    d "Okay..."


translate french poker23_d4af3017:


    d "Ben je suis..."


translate french poker23_1b8051aa:


    emerick "Tu sais pourquoi je te propose ça?"


translate french poker23_76a68131:


    d "Parce que t'es sûr de gagner?"


translate french poker23_e39b1be7:


    emerick "Evidemment!"


translate french poker23_ba32e80a:


    d "Parce que tu crois en toi et en ton jeu?"


translate french poker23_e8143a9b:


    emerick "Haha! Toujours!"


translate french poker23_4e56fdd8:


    d "Parce que t'es taré?"


translate french poker23_610444ad:


    emerick "Faut bien l'être un peu non?"


translate french poker23_dbb2bc0c:


    emerick "Mais non... Parce que je sais que je vais gagner!"


translate french poker23_0a541187:


    emerick "Allez! La river Beth!"


translate french poker23_5b38b6ff:


    beth "La river..."


translate french poker23_af61be04:


    beth "Le deux de coeurs..."


translate french poker23_6faa39e5:


    beth "Montrez vos cartes messieurs!"


translate french poker23_f9d65ba9:


    emerick "Carré baby!" with vpunch


translate french poker23_7e7fc3d4:


    d "Wow!!! Un carré..."


translate french poker23_765965dc:


    d "C'est rare un carré..."


translate french poker23_e5f13971:


    emerick "Et ouais mec!"


translate french poker23_03c37d01:


    emerick "Bien essayé en tous cas..."


translate french poker23_fb6205e3:


    d "Wow, c'est fou..."


translate french poker23_c154fd55:


    d "Je pensais que t'avais juste un as..."


translate french poker23_a5265cf0:


    d "OKay... Peut être un full..."


translate french poker23_78ff97d6:


    emerick "Haha! Je sais jouer!"


translate french poker23_b2842d1b:


    d "Oui..."


translate french poker23_96d96279:


    d "Belle main en tous cas..."


translate french poker23_01a6c5e7:


    d "Mais... Sais tu pourquoi je t'ai demandé si une flush c'était mieux qu'une quinte?"


translate french poker23_88c2931a:


    emerick "Heu... non!"


translate french poker23_8b0f7c01:


    d "Ben... Parce que j'avais..."


translate french poker23_8e217ed9:


    d "Les deux..."


translate french poker23_bcfc41d9:


    d "Quinte Flush Royale!" with vpunch


translate french poker23_d3a632b6:


    emerick "De quoiiiiiiii???" with hpunch


translate french poker23_a5e63099:


    emerick "Tu te fous de moi?"


translate french filles23_e63d14a0:


    hec "Allez. C'était juste une blague!"


translate french filles23_6e377ba4:


    julia "Laisse moi tranquille, Hector."


translate french filles23_13caae44:


    hec "Joue pas la prude. Je suis sûr que y'à moyen de bien s'amuser avec ce que y'à sous cette robe!"


translate french filles23_99f1a7c0:


    julia "Je t'ai dit de me laisser tranquille!"


translate french filles23_6b599e1a:


    hec "Allez tu t'es fait toute belle, ce serait bête de pas en profiter!"


translate french filles23_31b3aea6:


    hec "Viens, on va aller quelque part de plus privé!"


translate french filles23_99ce83cb:


    d "Je crois qu'elle t'a demandé de partir."


translate french filles23_0fb1be6e:


    hec "Putain mais t'es tout le temps là toi!"


translate french filles23_848785e8:


    hec "Pire qu'un moustique le mec!"


translate french filles23_97292c7a:


    hec "Vas-y, je te laisse ta princesse... C'est une frigide de toute façon."


translate french filles23_f9c7f0b0:


    d "Tu vas bien?"


translate french filles23_9da28c53:


    julia "Oui, oui... Je suis habituée, t'inquiète pas."


translate french filles23_398d0cff:


    julia "Mais c'est gentil de ta part. Merci."


translate french filles23_27970b90:


    julia "Pour être là pour moi. Encore."


translate french filles23_098db63e:


    d "Oh, c'est rien. Je peux pas le voir de toute façon."


translate french filles23_b44e6db9:


    julia "Ahah! Moi non plus."


translate french filles23_4af33191:


    julia "Hey..."


translate french filles23_fad03ada:


    d "?"


translate french filles23_2817e51d:


    julia "Ca peut te sembler bizarre mais..."


translate french filles23_73e08839:


    julia "Est ce que tu accepterais de m'accompagner à l'hôpital demain?"


translate french filles23_46f54ac1:


    d "Pourquoi? Tu es malade?"


translate french filles23_b95b525d:


    julia "Non. Je dois aller voir ma mère."


translate french filles23_cb1ee412:


    julia "Et j'aurais bien besoin de quelqu'un avec moi vu les résultats des tests..."


translate french filles23_73af0f04:


    d "Ils sont pas bons?"


translate french filles23_8f9c6f6d:


    julia "Non. Pas du tout."


translate french filles23_a90e9d4d:


    julia "Il ne lui reste que quelques jours..."

translate french filles23_6e7e6c4f:


    julia "On aura essayé mais c'est la fin."


translate french filles23_bf456521:


    d "Je serais là pour toi."


translate french filles23_8ffcb975:


    julia "Merci [name]."


translate french filles23_4e67cd6a:


    julia "Ca représente beaucoup pour moi."


translate french filles23_643ee3b5:


    d "N'hésite pas si tu as besoin de quelque chose."


translate french filles23_bd82f144:


    julia "Je veux pas m'imposer..."


translate french filles23_0d2bd84b:


    d "Hey c'est ce que les amis font non?"


translate french filles23_66c7136d:


    d "Enfin je veux dire... On est amis?"


translate french filles23_60d8c678:


    julia "On est amis!"


translate french filles23_9f9dba11:


    julia "Même si je suis pas sûre qu'un ami me choppe les fesses le premier jour de notre rencontre..."


translate french filles23_bfbf1c07:


    d "Oh! Euh..."


translate french filles23_260e8d1d:


    julia "Haha! Je rigole..."


translate french filles23_29065e5a:


    d "Bon, pour être honnête, il est joli aussi."


translate french filles23_f14e0ae3:


    julia "Haha! Je sais! Mais on touche avec les yeux!"


translate french filles23_ff49f6fb:


    d "Alors en tant qu'amis, si on allait profiter de la soirée?"


translate french filles23_7eabd694:


    julia "Tu as raison. Je vais pas rester beaucoup plus longtemps de toute façon."


translate french filles23_b4b50c32:


    d "Allons-y!"


translate french filles23_c1d6711f:


    ruby "Je n'ai jamais... Euh..."


translate french filles23_fcbdc5b7:


    ruby "Acheté de jouet érotique!"


translate french filles23_b4c311d4:


    kira "Tu peux dire un gode tu sais!"


translate french filles23_6b94590f:


    ruby "Euh..."


translate french filles23_0352a573:


    mad "Laisse la parler comme elle veut Kira!"


translate french filles23_05c46b86:


    mad "Elle a ses propres mots avec tous ses trucs Kawaï!"


translate french filles23_be415281:


    kira "Et tu vas me dire qu'avec toutes tes peluches, t'as pas un petit lapinou pour te frotter de temps en temps?"


translate french filles23_a21ad27d:


    ruby "Euh... Non..."


translate french filles23_2705baee:


    kira "Je sais pas comment vous faites les filles mais si j'ai pas ma dose de plaisir de temps en temps, je deviens agressive!"


translate french filles23_03785299:


    kira "Du coup j'en ai acheté un l'autre jour... Vous verriez le truc..."


translate french filles23_d9ad2417:


    grace "Ca ressemble à quoi?"


translate french filles23_646ef5b5:


    mad "Grace?"


translate french filles23_0c9d4e4e:


    grace "Ben quoi? Je suis juste curieuse!"


translate french filles23_745587fa:


    kira "Haha! C'est long, gros et nervuré..."


translate french filles23_cf7d2902:


    kira "Je l' ai pas encore testé, mais d'après ce que j'en ai entendu... On verra bien..."


translate french filles23_0c6f12cb:


    kira "ET toi Madison, c'est quoi ton favori?"


translate french filles23_7fa17ae4:


    kira "Je te vois bien avec un petit canard vibrant dans ton bain!"


translate french filles23_e57728f4:


    mad "Pour que ma fille joue avec? Non merci!"


translate french filles23_c308f921:


    mad "Et puis c'est pas tes affaires!"


translate french filles23_fe8120c9:


    kira "Ben voyons... Madison Forrester qui joue la prude!"


translate french filles23_4bd272c9:


    mad "Je ne suis pas prude!"


translate french filles23_29ccd7f5:


    kira "Ouais, ouais..."


translate french filles23_d721fb2f:


    d "Ca parle de quoi ici?"


translate french filles23_bcdd5352:


    ruby "De jouets!"


translate french filles23_19dc7043:


    mad "De trucs intimes..."


translate french filles23_0a7a132b:


    kira "De godes et de se toucher dans le bain!"


translate french filles23_52720f61:


    d "Outch... Okay..."


translate french filles23_541a9a65:


    grace "Plus facile pour les gars je suppose..."


translate french filles23_bec902dc:


    d "Comment ça?"


translate french filles23_81c99eed:


    grace "Ben, quand t'en as besoin, tu peux le faire facilement non? C'est plutôt rapide..."


translate french filles23_10ab5d15:


    d "Heu... Je crois que, comme les filles, ça dépend de la personne... Et on doit être stimulé quand même!"


translate french filles23_129b6de5:


    kira "Ben oui... Est ce que vous saviez que les hommes et les femmes sont plus ou moins visuels, auditifs ou tactiles selon la situation?"


translate french filles23_584173a2:


    ruby "Qu'est ce que ça veut dire?"


translate french filles23_b4384300:


    kira "En gros... Les gars vont facilement réagir à des stimulis visuels, comme les formes de ton corps."


translate french filles23_72c860a3:


    kira "Pour plein de filles, des sons, des mots et même certaines façons de toucher seront plus excitantes."


translate french filles23_564c078d:


    ruby "Ah? Et ça marche comment?"


translate french filles23_07a91765:


    kira "Oh ben ça je te laisse le découvrir! C'est surtout important que tu saches ce qui te plaît et que tu en parles avec ton partenaire."


translate french filles23_104a8c12:


    grace "Mais comment tu sais tout ça Kira?"


translate french filles23_fea58b2c:


    kira "Ben... J'expérimente et je fais des recherches. Y'à tellement à apprendre de notre corps et de notre sexualité."


translate french filles23_a728e041:


    kira "Les gens sont si puritains. Ils trouvent que le sexe est tellement taboo qu'ils sont embarassés par leurs corps et leur sexualité."


translate french filles23_ffa5c37b:


    kira "Mais c'est complètement naturel et sain d'explorer."


translate french filles23_66374259:


    grace "Je t'envie..."


translate french filles23_8dc09e6e:


    kira "Si je peux te donner un conseil..."


translate french filles23_0d3bc963:


    kira "Quand tu seras prête à explorer cette partie de toi avec quelqu'un, sois sûre de porter ta meilleure lingerie, te laisser aller, et profiter du moment avec la personne que tu as choisi."


translate french filles23_76869d69:


    kira "De cette façon, tu n'auras pas de regrets!"


translate french filles23_0adef93a:


    grace "Hum... Okay..."

translate french strings:


    old "11:00 PM"
    new "23:00"


    old "Because you're sure you'll win?"
    new "Parce que tu es sûr de gagner?"


    old "Because you trust yourself?"
    new "Parce que tu crois en toi?"


    old "Because you're crazy?"
    new "Parce que t'es taré?"




translate french filles23_1a134164:


    hec "Putain mais t'es toujours là toi!" with hpunch


translate french filles23_0ea9962d:


    d "Ben... Pour être honnête... Il est joli."


translate french filles23_208dc12d:


    mad "Grace?" with hpunch
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
