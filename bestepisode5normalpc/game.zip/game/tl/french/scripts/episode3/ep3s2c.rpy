


translate french ep3s2c_fa64e7e4:


    d "Bonjour Madame Drew."


translate french ep3s2c_2f405874:


    drew "Oh! [name]! Tu m’as fait peur."


translate french ep3s2c_e40f222b:


    drew "Que me vaut le plaisir?"


translate french ep3s2c_30793e1a:


    d "Je suis venu voir Grace."


translate french ep3s2c_eb73b104:


    drew "Elle se prépare; elle ne devrait plus tarder."


translate french ep3s2c_505dea50:


    drew "Vous semblez très proches dernièrement…"


translate french ep3s2c_c31186bc:


    d "C’est… oui, on passe du temps ensemble."


translate french ep3s2c_6dac8fb4:


    drew "Ne t'inquiète pas, je trouve ça charmant."


translate french ep3s2c_bf615426:


    drew "Garde-la près de toi. Emmène-la loin dans cette compétition."


translate french ep3s2c_019d7b3d:


    d "Heu... D'accord?"


translate french ep3s2c_0697ca82:


    drew "Je vous observe, vous savez. Et je dois avouer que je suis impressionnée."


translate french ep3s2c_3deed7ed:


    d "Vraiment?"


translate french ep3s2c_03f5de77:


    drew "Oui, j’espère sincèrement que vous réussirez tous les deux."


translate french ep3s2c_74782c19:


    drew "Bien que je garde un œil sur toi."


translate french ep3s2c_8407fa45:


    drew "Pour le moment, je suis d'accord pour que tu fréquentes ma fille."


translate french ep3s2c_eee464d8:


    drew "Mais souviens-toi, elle doit gagner."


translate french ep3s2c_ae5eb82d:


    d "Et moi?"


translate french ep3s2c_fe8d23fa:


    drew "Eh bien, vous devez gagner ensemble."


translate french ep3s2c_169b9f75:


    drew "Je sais me montrer reconnaissante. Plus tu avances, plus les récompenses seront grandes."


translate french ep3s2c_54957448:


    d "Des récompenses?"


translate french ep3s2c_e014bf88:


    drew "Pour l'instant, pouvoir voir ma fille à ta guise est ta récompense."


translate french ep3s2c_7eb0d926:


    drew "Mais sache que tu attires les regards, et pas seulement les siens…"


translate french ep3s2c_f1b55811:


    drew "Maintenant va, elle t’attend. Et ne soyez pas en retard."


translate french ep3s2c_06c2d188:


    d "D'accord."


translate french ep3s2c_2c7fb1a0:


    drew "Oh, et avant que tu partes… La première réponse est Gizeh..."


translate french ep3s2c_94518b14:


    dpense "Ça signifie quoi ça ?"


translate french ep3s2c_d05736e9:


    drew "Tu comprendras en temps voulu."


translate french ep3s2c_30bbb352:


    drew "Considère ça comme un petit bonus."


translate french ep3s2c_06c2d188_1:


    d "Compris."


translate french ep3s2c_8bd88703:


    dpense "Qu'est ce qu'elle a voulu dire?"


translate french ep3s2c_d981fc7b:


    dpense "Etrange..."


translate french ep3s2c_50b572ee:


    dpense "Bon, la chambre de Grace…"


translate french ep3s2c_b6805db4:


    grace "Oh, [name]."


translate french ep3s2c_627b921c:


    d "Je ne te dérange pas, j’espère ?"


translate french ep3s2c_ca4039c3:


    grace "Pas du tout, je finissais de me préparer. Entre."


translate french ep3s2c_9b902222:


    d "Tu es ravissante."


translate french ep3s2c_8390f9cc:


    grace "Arrête, tu vas me faire rougir."


translate french ep3s2c_9a8a1bb6:


    d "Ai-je le droit de t’embrasser ?"


translate french ep3s2c_a9bed95f:


    grace "Le droit ? Plutôt le devoir !"


translate french ep3s2c_495bb525:


    d "Ta mère semble nous donner sa bénédiction."


translate french ep3s2c_98ebbfd9:


    grace "Vraiment ? Qu’a-t-elle dit exactement ?"


translate french ep3s2c_a70b9367:


    d "Elle a remarqué qu’on passait du temps ensemble et…"


translate french ep3s2c_4f14570b:


    grace "Je voulais justement te parler de ça."


translate french ep3s2c_01edd90d:


    grace "Écoute, pendant la compétition, gardons ça pour nous. C’est notre petit secret."


translate french ep3s2c_e3b20b7b:


    d "Pourquoi ?"


translate french ep3s2c_dffb0ec1:


    grace "Dans cette compétition, tout peut être utilisé contre nous."


translate french ep3s2c_5703408b:


    grace "Et ce soir… Après la fête, nous aurons tout le temps pour..."


translate french ep3s2c_4dd2a10c:


    grace "Ahhh! J’aime quand tes mains me frôlent."


translate french ep3s2c_eb3879c2:


    d "Et moi, j'adore sentir le contact de ta peau."


translate french ep3s2c_31c40958:


    grace "Ah..."


translate french ep3s2c_5c868772:


    grace "Hummm..."


translate french ep3s2c_7126ab4d:


    grace "Arrête, sinon je réponds plus de rien."


translate french ep3s2c_27faf88b:


    grace "Ce soir..."


translate french ep3s2c_433869b9:


    d "Et pour ce soir, vous êtes prêtes?"


translate french ep3s2c_499297e6:


    grace "En fait là on va aller en cours et après je dois rejoindre Ruby on va passer toute l'après-midi à tout préparer."


translate french ep3s2c_7dd8afa4:


    grace "Elle a prévu plein de choses!"


translate french ep3s2c_60371a03:


    d "Ah bon? Je ne vais pas venir vous déranger alors!"


translate french ep3s2c_4082c591:


    grace "Non, vaut mieux pas."


translate french ep3s2c_97610549:


    grace "Surtout avec Ruby si tu es dans ses pattes tu vas te faire gronder."


translate french ep3s2c_2c0572e7:


    d "Gronder? Par Ruby?"


translate french ep3s2c_44e82c85:


    grace "Ah oui oui, quand elle est dans son truc, il vaut mieux pas l'embêter."


translate french ep3s2c_eee5a2a8:


    d "D'accord. Et du coup, il faut que j'arrive vers quelle heure alors?"


translate french ep3s2c_36b419b1:


    grace "La fête commence vraiment vers 21 heures, mais tu peux arriver vers 20h pour te préparer."


translate french ep3s2c_26b2a481:


    d "Ca me va."


translate french ep3s2c_c349746e:


    grace "Et puis, oublie pas, ce soir, c'est chic et choc."


translate french ep3s2c_ed1501d9:


    d "Oui, ben ça, je sais pas encore comment ça va se passer. Je sais même pas comment je vais m'habiller."


translate french ep3s2c_ba22db80:


    grace "A ce que j'ai compris, Ruby m'a dit comme quoi, y aurait... Tu aurais un costume... Que Rouge devrait apporter."


translate french ep3s2c_ec5e29a1:


    grace "Si c'est pas le cas, j'en ai encore un. Il est à mon père, donc ne t'inquiète pas tout est réglé."


translate french ep3s2c_1d7c521b:


    grace "De toute façon Ruby à une liste au cas où quelque chose ne va pas."


translate french ep3s2c_935db071:


    grace "Et elle a même une liste de secours de sa liste de secours..."


translate french ep3s2c_06c2d188_2:


    d "Ah ouais, elle rigole pas!"


translate french ep3s2c_c5790358:


    grace "Laisse-moi deux minutes et j'arrive."


translate french ep3s2c_bfde5076:


    d "Waw... qu'est ce que t'es belle!"


translate french ep3s2c_4f3d4452:


    grace "Toi aussi t'es pas mal non plus!"


translate french ep3s2c_4e193a9e:


    grace "Allez on va finir pas à être retard."


translate french ep3s2c_ffe847fc:


    grace "On y va!"


translate french ep3s2c_b4b50c32:


    d "C'est parti!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
