


translate french coming3_17342d50:


    "La main droite sur le rond vert!"


translate french coming3_4c61430b:


    "Tapis!"


translate french coming3_7a16ee9c:


    grace "Tu es le seul que je veux ce soir..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
