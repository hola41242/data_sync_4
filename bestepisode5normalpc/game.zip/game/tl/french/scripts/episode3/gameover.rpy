


translate french gameover_a733e2ee:


    orushi "Malheureusement, vous n'avez pas passé les épreuves avec succès, [name]..."


translate french gameover_84c6535c:


    orushi "C'est très décevant..."


translate french gameover_3bdd13e5:


    orushi "Et bien... La prochaine fois... Essayez de prendre de meilleures décisions!"


translate french gameover_783ab545:


    "Fschhhhhhhhhh!!!"




translate french gameover_e233951b:


    "Même joueur joue encore!"




translate french gameovere5_a733e2ee:


    orushi "Malheureusement, vous n'avez pas passé les épreuves avec succès, [name]..."


translate french gameovere5_84c6535c:


    orushi "C'est très décevant..."


translate french gameovere5_3bdd13e5:


    orushi "Et bien... La prochaine fois... Essayez de prendre de meilleures décisions!"


translate french gameovere5_783ab545:


    "Fschhhhhhhhhh!!!"




translate french gameovere5_e233951b:


    "Même joueur joue encore !"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
