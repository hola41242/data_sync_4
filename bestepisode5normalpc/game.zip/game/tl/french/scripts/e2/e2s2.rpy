


translate french e2s2_0de6c2b7:


    d "Qu'est ce que c'est que ce bonnet ?"


translate french e2s2_2651da73:


    julia "Ben... En fait, j'aime ma couleur de cheveux, mais il y a des gens que je ne veux pas croiser qui pourraient me voir de loin... Je préfère rester incognito..."


translate french e2s2_a09a9275:


    d "Tu as des problèmes ?"


translate french e2s2_747f24b1:


    julia "Hum... Pas vraiment..."


translate french e2s2_81710995:


    julia "Et sinon, tu te fais à la vie ici ?"


translate french e2s2_a69974f7:


    d "Ben, tu sais, je suis là que depuis 2 jours... J'ai pas vu grand chose !"


translate french e2s2_8be5e67c:


    d "Mais j'aimerais bien voir un peu tout, on a un peu de temps donc c'est l'occasion..."


translate french e2s2_649f8856:


    d "Avec la compétition, les cours qui vont commencer, et tous les gens que je rencontre... Je sais à peine où je suis..."


translate french e2s2_0ddb529d:


    julia "J'imagine ! Ca doit faire un choc...."


translate french e2s2_41e417f6:


    d "Ben à la base... J'étais là pour venir étudier..."


translate french e2s2_2e7a7210:


    d "Et maintenant je fais partie du programme B.E.S.T, je suis dans une chambre universitaire que je n'ai pas demandé, j'ai rencontré la principale et sa fille... Toi... Les autres..."


translate french e2s2_2d9dc3c5:


    d "Je ne sais même pas par où commencer et les cours n'ont même pas repris !"


translate french e2s2_60da1eec:


    julia "Haha ! Et c'est pas fini ! A la fin de la semaine, y'à la soirée d'intégration !"


translate french e2s2_1b8d5ee7:


    julia "C'est comme une grande fête avec des jeux, plein de gens partout... Ca finit souvent en orgie... Dans tous les sens du terme... J'espère que tu as l'estomac bien accroché !"


translate french e2s2_ec991449:


    d "Tant que j'ai du monde avec moi ça va ! Et puis je suis pas du genre à dépasser mes limites !"


translate french e2s2_322bba4a:


    d "En vrai, j'aime bien ces soirées quand on s'amuse !"


translate french e2s2_170cdd76:


    julia "Tellement d'accord ! Ce n'est vraiment pas mon genre de fête... Je préfère rester seule..."


translate french e2s2_fdd47e50:


    julia "Mais je fais un effort, et chaque année je viens voir comment ça se passe et comment les nouveaux sont intégrés..."


translate french e2s2_1bae9f5e:


    d "Oh, tu sais, à ces soirées, faut juste savoir se limiter... Autrement tu es bonne pour un bon mal de tête, et puis les mauvaises habitudes peuvent arriver vite..."


translate french e2s2_1c7dbdcc:


    d "Et ça affecte tes notes..."


translate french e2s2_a42f6436:


    julia "Tu prends les cours très au sérieux hein ?"


translate french e2s2_ef6e3ce0:


    d "Ben, ouais... Pas le choix... Si mes notes ne sont pas bonnes c'est retour en France. Pas envie de faire tout ça pour rien alors..."


translate french e2s2_a4b21c2c:


    julia "Je comprends..."


translate french e2s2_ddeb79fb:


    d "Je ne bois que très peu d'alcool pour rester en bonne condition physique... Le sport avant tout ! Damn !"


translate french e2s2_3131a946:


    julia "Oh wow ! Monsieur est déjà un grand athlète ?"


translate french e2s2_2abccca6:


    d "Nan mais j'essaye de rester énorme et sec pour atteindre les meilleures performances possibles !"


translate french e2s2_f5bfadf3:


    d "Si je le pouvais, je mangerais que du riz-dinde et de l'huile d'olive pour les bons lipides pour rester énorme et sec ! Mais pour l'instant j'ai plus l'impression de passer de Tortank à Métamorphe..."


translate french e2s2_04da4eb4:


    julia "Haha ! Nan, en vrai je dirais plutôt un Machoc !"


translate french e2s2_2f84c3bb:


    d "Hey !"


translate french e2s2_0ff2a046:


    d "A boire et des jolies filles ? C'est tout ce dont j'ai besoin ! Ca promet déjà d'être génial !"


translate french e2s2_2a1cca83:


    julia "T'emballes pas trop vite Don Juan ! C'est pas parce que tu seras là que les filles seront à tes pieds hein !"


translate french e2s2_210ff254:


    julia "Et puis il faut tenir l'alcool... Et on a cours le lendemain !"


translate french e2s2_e1c58ffa:


    d "Il en faut plus pour m'effrayer ! Je vais leur montrer qui est le roi du dance floor ! Ils vont tous être ébahis devant ma French Touch !"


translate french e2s2_ac2e69c2:


    julia "Ouais okay..."


translate french e2s2_f6cfd155:


    julia "En tous cas, pratiquement tout le monde sera à cette soirée ! D'habitude c'est Madison qui l'organise mais elle n'en a pas parlé cette année..."


translate french e2s2_619b5244:


    julia "Je pense que c'est plus difficile avec sa fille en ce moment... Du coup je ne sais même pas où ce sera... Tu auras peut être plus d'infos avec les autres !"


translate french e2s2_ad3f6506:


    d "Mais tu viendras quand même ?"


translate french e2s2_a34dcd03:


    julia "Oui oui ! C'est presque obligatoire d'au moins y faire une apparition, sinon t'es catalogué anti-sociale... Mais je ne resterai sûrement pas longtemps..."


translate french e2s2_9d401a52:


    d "On verra bien... Je parie que Ruby sera à fond encore !"


translate french e2s2_b389601e:


    julia "Ca c'est sûr ! Chaque année elle organise des petits jeux avec les filles... C'est surtout elle qui rend ces parties amusantes..."


translate french e2s2_a97e81c6:


    julia "Sinon on doit éviter les relous qui viennent taper l'incruste..."


translate french e2s2_f1b6f7a1:


    d "Les relous ?"


translate french e2s2_6d800bf6:


    julia "Ouais, l'équipe de foot de Steven... A chaque soirée ils viennent et se lancent des défis stupides pour montrer qui est le mâle alpha..."


translate french e2s2_2c2249c6:


    julia "Et bien sûr, on est leurs cibles... Donc chaque année ils essayent... Et chaque année ils se font rembarrer !"


translate french e2s2_198ee8a3:


    d "Mais tout à l'heure dans le parc, tu as dit que tu n'avais jamais embrassé quelqu'un..."


translate french e2s2_4e619f92:


    julia "Oui..."


translate french e2s2_ff8f5d14:


    d "T'as jamais eu de petit copain ?"


translate french e2s2_a59c2be9:


    julia "Pas vraiment... J'ai jamais ressenti d'attirance pour un gars en fait... Enfin... Je ne suis pas sûre..."


translate french e2s2_f96d060b:


    d "Tu préfères les filles ?"


translate french e2s2_cbc0a567:


    julia "Quoi ? Non !!!! C'est juste que je n'ai jamais rencontré quelqu'un qui m'intéresse vraiment... Enfin... Pas encore ! Mais ça viendra quand ça viendra !"


translate french e2s2_2154c2d6:


    julia "Après tout... Je veux explorer cette partie de moi avec quelqu'un en qui j'ai totalement confiance et qui va m'aider à me découvrir de la meilleure façon..."


translate french e2s2_f515507e:


    d "Et les autres ? Elles sont aussi réticentes à se laisser approcher ?"


translate french e2s2_5609f7b7:


    julia "Humm... Grace aime bien qu'on la drague sans que ça aille trop loin... Elle est gentille..."


translate french e2s2_17d1ebbd:


    julia "Elle va pas dire non à quelqu'un qui veut lui parler ou danser avec elle... Mais dès que ça commence à chauffer, elle s'échappe..."


translate french e2s2_063a254d:


    d "Elle s'échappe ?"


translate french e2s2_2f7bba62:


    julia "Ouais ! Soit elle appelle une copine pour garder le gars occupé le temps d'aller autre part, où alors elle disparaît sans rien dire... Donc, ouais, elle est fuyante !"


translate french e2s2_1ef78c01:


    d "Haha ! Et Ruby ?"


translate french e2s2_31bb772d:


    julia "Oulà ! Ruby c'est différent ! Elle n'a pas le temps de se faire draguer parce qu'elle veut s'occuper de tout..."


translate french e2s2_76e1c2af:


    julia "Elle va jouer avec nous, vérifier qu'il ne manque rien dans la cuisine, elle va même préparer des sacs de préservatifs et d'autres trucs pour les gens de la soirée..."


translate french e2s2_a0507f21:


    julia "Mais du coup elle ne s'amuse pas autant qu'elle le devrait..."


translate french e2s2_cd5b7cef:


    d "Je vois ce que tu veux dire !"


translate french e2s2_4b92c7e2:


    julia "Et de l'autre côté tu as d'autres filles qui sont moins... Exigeantes... Mais je te laisse l'occasion de les découvrir... Si tu en as envie !"


translate french e2s2_5c581896:


    d "On verra bien comment ça se passera..."


translate french e2s2_7c2f365c:


    julia "Plus tôt dans le parc, les filles parlaient d'un truc... à propos des jumelles... c'était quoi ?"


translate french e2s2_f37455ff:


    d "J'aime bien Bleue..."


translate french e2s2_101332d7:


    julia "Hein ?"


translate french e2s2_c5609e2e:


    d "Ouais je sais pas ... Elle est spéciale... Je sais pas trop quoi te dire..."


translate french e2s2_8d85d16f:


    julia "Hummm... Je comprends mieux pourquoi Madison disait ça... Ca va être plus dur de te faire accepter par Maddie maintenant !"


translate french e2s2_5bc0ea87:


    d "On verra bien..."


translate french e2s2_40ea1b9b:


    d "Ben j'ai la jumelle bleue qui m'a approché... Mais je ne suis pas interessé par elle..."


translate french e2s2_1ee38eaf:


    julia "Ah bon ?"


translate french e2s2_bdb8233e:


    d "Oui... C'est pas mon style, ce genre de filles... Laissons la aux footeux et aux relous comme tu dis !"


translate french e2s2_da81affe:


    julia "Haha ! Du coup tu marques des points auprès de Maddie ! Ce sera plus facile pour elle de t'accepter si t'es pas avec les jumelles, et encore plus si tu les envoies balader !"


translate french e2s2_5bc0ea87_1:


    d "On verra bien..."


translate french e2s2_045838c2:


    d "J'aime beaucoup Rouge"


translate french e2s2_101332d7_1:


    julia "Hein ?"


translate french e2s2_c5609e2e_1:


    d "Ouais je sais pas ... Elle est spéciale... Je sais pas trop quoi te dire..."


translate french e2s2_8ae374e1:


    julia "Hummm... Je comprends mieux pourquoi Ruby disait ça... Ca va être plus dur de te faire accepter par Maddie maintenant !"


translate french e2s2_5bc0ea87_2:


    d "On verra bien..."


translate french e2s2_6b7da03e:


    d "Ben j'ai la jumelle rouge qui m'a approché... Mais je ne suis pas interessé par elle..."


translate french e2s2_1ee38eaf_1:


    julia "Ah bon ?"


translate french e2s2_bdb8233e_1:


    d "Oui... C'est pas mon style, ce genre de filles... Laissons la aux footeux et aux relous comme tu dis !"


translate french e2s2_da81affe_1:


    julia "Haha ! Du coup tu marques des points auprès de Maddie ! Ce sera plus facile pour elle de t'accepter si t'es pas avec les jumelles, et encore plus si tu les envoies balader !"


translate french e2s2_5bc0ea87_3:


    d "On verra bien..."


translate french e2s2_97eb4ac6:


    julia "Sinon, voilà la piscine ! Grace passe le plus clair de son temps là bas à s'entraîner."


translate french e2s2_2c11e212:


    julia "Si tu ne sais pas où elle est... Ben, vas y et tu la trouveras sûrement !"


translate french e2s2_f36a5ff4:


    d "Okay !"


translate french e2s2_597f2c85:


    julia "A côté, t'as le gymnase... On y est passé tout à l'heure pour se changer. C'est là bas que tu trouveras Madison..."


translate french e2s2_39b61a84:


    julia "Elle s'y entraîne régulièrement. Tu risques de voir Steven et les autres aussi... Mais bon..."


translate french e2s2_16c75a70:


    d "Tu n'y va pas ?"


translate french e2s2_a4696a89:


    julia "En fait... Entre les cours et... J'ai pas vraiment le temps..."


translate french e2s2_43b49e4c:


    d "Okay."


translate french e2s2_58a7c153:


    julia "Par là bas tu as le Grand Theater, c'est un cinéma... Et des magasins si t'as besoin de quelque chose... Y'à même un pub !"


translate french e2s2_360c3a8e:


    d "C'est comme une mini-ville !"


translate french e2s2_aeb44433:


    julia "Oui, on peut voir ça comme ça ! Mais je te préviens de suite... La plupart des affaires ici sont à la famille d'Emerick ou à celle des jumelles..."


translate french e2s2_c5e72fc1:


    d "Ils sont riches à ce point ?"


translate french e2s2_a55c01fd:


    julia "Encore plus que tu ne peux l'imaginer... Mais leurs parents veulent leur inculquer la valeur de l'argent... Si j'ai bien compris..."


translate french e2s2_d1d6f45b:


    julia "Du coup Rouge s'occupe du magasin de vêtements où elle fait la gérance et donne de bons conseils sur la mode... Quand à Emerick... Tu verras ses business bien assez tôt..."


translate french e2s2_b651150d:


    d "Et Bleue ?"


translate french e2s2_ccd58cdf:


    julia "Oh elle est beaucoup moins interessée par l'argent que par les ... relations humaines on va dire !"


translate french e2s2_df522c84:


    julia "Mais elle est souvent au cinéma ou au bowling ! Et puis elle s'entraîne au terrain... Au moins on ne peut pas lui en vouloir pour ça !"


translate french e2s2_0aae168a:


    d "Et toi tu fais quoi dans tout ça ?"


translate french e2s2_08822955:


    julia "Moi ? Hum..."


translate french e2s2_f526b9a7:


    julia "Oh tiens ! On est arrivé à la bibliothèque et il est déjà super tard !"


translate french e2s2_ebd88aab:


    julia "Je dois te laisser là ! Si t'as des questions, hésite pas à m'envoyer un message !"


translate french e2s2_1b2a5bf7:


    julia "Et puis on se voit demain en cours d'éco !"


translate french e2s2_c372f1a0:


    d "Huh... Ouais... D'accord !"


translate french e2s2_09f84ac2:


    julia "A demain du coup !"


translate french e2s2_df3539f1:


    d "A demain !"


translate french e2s2_d79bb79d:


    dpense "Bizarre qu'elle ne réponde jamais à mes questions sur elle ..."


translate french e2s2_62613341:


    cr "Ici vous aller avoir le choix de continuer l'histoire dans l'ordre que vous voulez..."


translate french e2s2_8205de36:


    cr "C'est le menu MYA... Make Your Adventure... A chaque mise à jour un chemin s'ouvrira..."


translate french e2s2_dcd00f97:


    cr "Le menu sera affiché de multiples fois pendant l'histoire principale pour vous donner l'occasion... ou pas... de passer du temps avec les filles dans l'ordre que vous voulez."


translate french e2s2_afb2051f:


    cr "Si vous ne voulez pas passer de temps avec l'une d'entre elles ( ou aucune !) Cliquez juste sur retour dans ma chambre !"


translate french menumya_36657ccc:


    "Ce contenu sera disponible dans une future mise à jour..."


translate french menumya_36657ccc_1:


    "Ce contenu sera disponible dans une future mise à jour..."


translate french menumya_36657ccc_2:


    "Ce contenu sera disponible dans une future mise à jour..."

translate french strings:


    old "Ask about her love life"
    new "Parler de sa vie amoureuse..."


    old "Ask about the others"
    new "Demander pour les autres..."


    old "Leave the path open with Blue"
    new "Laisser ouvert le chemin avec Bleue"


    old "Close the path with Blue"
    new "Fermer le chemin avec Bleue"


    old "Leave the path open with Red"
    new "Laisser ouvert le chemin avec Rouge"


    old "Close the path with Red"
    new "Fermer le chemin avec Rouge"


    old "Visit the swimming pool"
    new "Visiter la piscine..."


    old "Available in 0.2.2"
    new "Disponible à la 0.2.2"


    old "Available in 0.2.3"
    new "Disponible à la 0.2.3"


    old "Available in 0.2.4"
    new "Disponible à la 0.2.4"


    old "Return to my room"
    new "Retourner dans ma chambre..."



translate french strings:


    old "I like Blue"
    new "J'aime bien Bleue"


    old "I don't like Blue"
    new "Je déteste Bleue"


    old "I like Red"
    new "J'aime bien Rouge"


    old "I don't like Red"
    new "Je déteste Rouge"




translate french e2s2_12d69c96:


    d "J'aimerais bien explorer un peu et profiter qu'on ait un peu de temps pour prendre mes repères..."


translate french e2s2_528a694f:


    julia "Oh wow ! Alors Monsieur est déjà un grand athlète ?"


translate french e2s2_73733c8a:


    julia "Ouais, t'as l'équipe de Steven... Les gars du football... A chaque fête ils viennent et font des défis débiles pour déterminer qui est le mâle alpha..."


translate french e2s2_69793ab9:


    julia "Du coup, Rouge s'occupe du magasin de vêtements et donne de bons conseils... Emerick lui... Tu verras bien assez tôt ses combines..."


translate french e2s2_168a4a22:


    julia "De toute façon, on se voit au cours d'éco demain !"


translate french e2s2_f49e8424:


    dpense "C'est bizarre, elle répond jamais à mes questions sur ce qu'elle fait..."


translate french e2s2_9af37617:


    cr "Le prochain menu apparaîtra plusieurs fois durant l'histoire pour vous permettre de choisir l'ordre dans lequel vous voulez que les évènements se passent..."



translate french strings:


    old "Available later..."
    new "Disponible plus tard..."



translate french strings:


    old "Ask about her love life [TEMP1]"
    new "Lui parler de sa vie amoureuse [TEMP1]"


    old "Ask about the others [TEMP2]"
    new "En apprendre plus sur les autres [TEMP2]"


    old "I like Blue [TEMP1]"
    new "J'aime bien Blue [TEMP1]"


    old "I don't like Blue [TEMP2]"
    new "Je n'aime pas Blue [TEMP2]"


    old "I like Red [TEMP1]"
    new "J'aime bien Red[TEMP1]"


    old "I don't like Red [TEMP2]"
    new "Je n'aime pas Red [TEMP2]"


    old "Visit the swimming pool [TEMP1]"
    new "Aller à la piscine [TEMP1]"


    old "Return to my room [TEMP2]"
    new "Retourner dans ma chambre [TEMP2]"



translate french strings:


    old "Ask about her love life [TEMP1!t]"
    new "Lui parler de sa vie amoureuse [TEMP1!t]"


    old "Ask about the others [TEMP2!t]"
    new "En apprendre plus sur les autres [TEMP2!t]"


    old "I like Blue [TEMP1!t]"
    new "J'aime bien Blue [TEMP1!t]"


    old "I don't like Blue [TEMP2!t]"
    new "Je n'aime pas Blue [TEMP2!t]"


    old "I like Red [TEMP1!t]"
    new "J'aime bien Red[TEMP1!t]"


    old "I don't like Red [TEMP2!t]"
    new "Je n'aime pas Red [TEMP2!t]"


    old "Visit the swimming pool [TEMP1!t]"
    new "Aller à la piscine [TEMP1!t]"


    old "Return to my room [TEMP2!t]"
    new "Retourner dans ma chambre [TEMP2!t]"




translate french e2s2_699705df:


    d "Pourquoi tu portes un bonnet maintenant ?"


translate french e2s2_f013355a:


    d "Mais j'aimerais bien explorer le coin un petit peu... Et puis comme on a un peu de temps, ranger mes affaires..."


translate french e2s2_4194debf:


    d "Ouais ben... En fait... J'étais juste venu là pour étudier moi..."


translate french e2s2_4e3f7e5b:


    d "En gros j'adore ces soirées si on s'amuse sinon..."


translate french e2s2_e4720c4a:


    julia "Je pense que c'est difficile en ce moment avec sa fille... Du coup je sais même pas où ça va se passer... T'auras peut être plus d'infos avec les autres ! "


translate french e2s2_02fcf1f9:


    julia "De toute façon, on se voit demain en cours d'éco !"




translate french e2s2_134e56cd:


    d "Ouais, eh bien... En fait, je suis juste venu pour étudier..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
