


translate french pool_72637706:


    dpense "Voyons voir ce qu'on a là."


translate french pool_9e7c87f7:


    ji "Hey mon gars... Tu n'as pas le droit d'entrer là dedans avec des vêtements !"


translate french pool_279f9a91:


    dpense "Qui..."


translate french pool_b85af03c:


    dpense "Whaaa... Okay..."


translate french pool_b26cb75e:


    ji "Tu peux acheter un maillot à l'accueil si t'en as pas..."


translate french pool_204f2638:


    d "Oh... Heu... D'accord... Merci !"


translate french pool_0b4cdda2:


    ji "De rien... Amuse-toi bien !"


translate french pool_bd97412f:


    d "Ouais ouais..."


translate french pool_68ef2048:


    dpense "Putain cette femme c'était un avion de chasse ! Non une fusée ! ..."


translate french pool_26d4b995:


    dpense "Que dis-je ! C'est une bombe atomique !"


translate french pool_1346f98d:


    dpense "Bon, vaut mieux aller acheter ce maillot..."


translate french pool_2858ce6f:


    dpense "Maintenant on peut y aller !"


translate french pool_c7cc1930:


    sofia "Viens par là... Tu voulais me voir évoluer... Je suis déjà toute mouillée..."


translate french pool_4ed86741:


    d "Tu veux aller où ?"


translate french pool_e12af768:


    sofia "Je connais un endroit où on sera tranquilles..."


translate french pool_5036ca42:


    d "D'accord ! On y va !"


translate french pool_140612ac:


    d "Non merci ! J'ai une jolie sirène qui m'attend !"


translate french pool_7ea2f9dd:


    sofia "Tu ne sais pas ce que tu rates..."


translate french pool_f36c14c5:


    sofia "Qu'est ce que tu fais là le Frenchie ? T'as pas mieux à faire que venir zieuter à la piscine ?"


translate french pool_e90456c6:


    d "Oh t'inquiètes pas ! Je suis pas là pour toi... Je vois pas ce que je ferais de toi de toute façon..."


translate french pool2_d9572a1c:


    d "Alors c'est là que tu t'entraînes ?"


translate french pool2_fa3467c8:


    grace "Oh ? Heu... Oui..."


translate french pool2_f66455b4:


    d "Julia m'a montré un peu les alentours, et je pensais venir me relaxer un peu à la piscine... avec ces derniers jours..."


translate french pool2_b8e2fee2:


    grace "Je connais rien de mieux que de sentir le contact de l'eau sur ma peau pour recharger mes batteries..."


translate french pool2_c670f8b1:


    d "Tu t'entraînes ici tous les soirs ?"


translate french pool2_7cfa0a63:


    grace "Oui, ça m'aide à rester en forme pour les matchs."


translate french pool2_7f1e4dbe:


    d "T'as un entraînement spécifique ?"


translate french pool2_2ccaf0b5:


    grace "Ben d'abord je me relaxe, ensuite j'enchaîne des longueurs, et des fois je fais un peu de vitesse..."


translate french pool2_d5462bbf:


    d "C'est parce que tu n'as jamais testé mes massages !"


translate french pool2_275ce8d3:


    grace "Tu sembles bien sûr de toi !"


translate french pool2_3ba1bae1:


    d "Evidemment ! Comparé à l'eau, mes mains sont plus agiles et peuvent relaxer tout ton corps d'un simple toucher..."


translate french pool2_76c08320:


    grace "Ah bon ? J'aimerais bien voir ça tiens !"


translate french pool2_0e0f6b87:


    d "Qui sait... Encore faut il que tu le mérites !"


translate french pool2_46bc144d:


    grace "Et toi tu t'entraînes un peu ?"


translate french pool2_b1500910:


    d "Pas vraiment..."


translate french pool2_67a8763d:


    dpense "Putain quelle déesse..."


translate french pool2_6f4442f4:


    grace "Tu fais pas de sports en dehors des cours ?"


translate french pool2_7937cad2:


    d "Ben j'ai pas vraiment eu le temps ici..."


translate french pool2_2bc3d50b:


    d "En France je faisais du foot et de l'escalade..."


translate french pool2_45a97532:


    grace "De l'escalade ?"


translate french pool2_2059714a:


    d "Ouais en pleine nature, sur des falaises, des petites montagnes..."


translate french pool2_413052f1:


    grace "Il faut de l'endurance pour ça ! Et c'est super dangereux !"


translate french pool2_3c7caf13:


    d "Bah faut avoir une bonne prise en main, mais surtout savoir se sécuriser..."


translate french pool2_a897be39:


    d "Et oui ça demande de l'endurance... Mais en jouant au foot je fais du cardio donc je suis bon pour ça !"


translate french pool2_feb3be0c:


    grace "Tu es bon ?"


translate french pool2_79d25a85:


    d "Heu... Ouais !"


translate french pool2_72618b93:


    grace "Okay Monsieur je suis bon... Je te propose un marché !"


translate french pool2_5dda0f88:


    d "Hmmmm ?"


translate french pool2_03b270ed:


    grace "On fait un aller retour dans la piscine, et le perdant doit au gagnant une faveur, n'importe où, n'importe quand..."


translate french pool2_ad924887:


    d "Quel genre de faveur ?"


translate french pool2_2a17a6fb:


    grace "Hmmm... Je vais y réfléchir..."


translate french pool2_f427102d:


    d "Okay... Donc si je gagne..."


translate french pool2_53d303bf:


    grace "Tu ne gagneras pas !"


translate french pool2_4e58cc80:


    d "Hahah ! Donc quand j'aurai gagné... Je peux te demander quasiment n'importe quoi ?"


translate french pool2_3c81889e:


    grace "Plus ou moins, oui... Mais ça marche dans les deux sens !"


translate french pool2_6967de82:


    d "Dans les deux sens ?"


translate french pool2_fddacfe2:


    grace "Comme je vais gagner... Je pourrai te demander ce que je veux !"


translate french pool2_5e16e0f2:


    d "Ouais, d'accord..."


translate french pool2_26544772:


    grace "On verra bien !"


translate french pool2_48ff1ed8:


    d "D'accord !"


translate french pool2_7bc9d103:


    grace "A vos marques !"


translate french pool2_992acfcb:


    d "Je ne peux pas râter ça !"


translate french pool2_f6390a0e:


    grace "A 3, on y va !"


translate french pool2_3314f8cb:


    d "Prêt !"


translate french pool2_b8466fb7:


    grace "1..."


translate french pool2_67424511:


    grace "2..."


translate french pool2_542ac620:


    grace "3!"


translate french nage2_226132c8:


    dpense "Il faut que j'aille plus vite qu'elle !"


translate french nage3_58c7f260:


    dpense "C'est le sprint final !"


translate french nage3_8278132c:


    d "VICTOIRE !!!"


translate french nage3_8278132c_1:


    d "VICTOIRE !!!"


translate french nage3_09c9d4b2:


    grace "TRICHEUR !!!"


translate french nage3_3ed7a701:


    grace "VICTOIRE !!!"


translate french victory_a3e3783a:


    grace "Wow ! Tu m'as impressionné ! J'ai pas réussi à te rattraper !"


translate french victory_c991dce0:


    d "Tu as géré ! j'ai crû que j'allais perdre à la fin !"


translate french victory_4fa8f8ce:


    grace "Ouais... Du coup je te dois une faveur..."


translate french victory_c5e4f86c:


    d "Haha ! C'est toi qui a proposé hein !"


translate french victory_1be0c3fd:


    grace "Oui ben je m'attendais pas à une telle compétition !"


translate french victory_7961d703:


    d "Je t'avais prévenu !"


translate french victory_3de0ddee:


    grace "Nananana ! Monsieur je suis trop fier !"


translate french victory_f44767f2:


    d "Qu'est ce que je vais bien pouvoir te demander..."


translate french victory_92628f4c:


    grace "Ne sois pas trop dûr avec moi s'il te plaît..."


translate french victory_c5c89714:


    d "Hmmmm..."


translate french victory_9e5421b0:


    dpense "Si tu savais ce qui est dur en ce moment..."


translate french victory_6e81e294:


    d "Je vais garder ça pour plus tard ... ça te va ?"


translate french victory_9a03811a:


    grace "D'accord... !"


translate french cheater_d760c5d6:


    grace "Tu as triché !"


translate french cheater_e4bc3bdd:


    d "On n'a jamais dit qu'on devait toucher le mur !"


translate french cheater_41767841:


    grace "N'importe quoi !"


translate french cheater_06713c9c:


    d "Ben quoi ?"


translate french cheater_2b33e359:


    grace "Bon ben du coup on va dire qu'on a tous les deux le droit à une faveur de l'autre... okay ?"


translate french cheater_40ab082c:


    d "Ca me va !"


translate french cheater_92628f4c:


    grace "Ne sois pas trop dur avec moi, s'il te plaît !"


translate french cheater_c5c89714:


    d "Hmmmm..."


translate french cheater_9e5421b0:


    dpense "Si tu savais ce qui est dur en ce moment..."


translate french cheater_6e81e294:


    d "Je vais garder cette faveur pour plus tard si ça te va !"


translate french cheater_9a03811a:


    grace "D'accord... !"


translate french defeat_5978fda4:


    grace "J'ai gagné ! Ahahah !"


translate french defeat_8654b90d:


    d "Je pouvais rien faire, t'es beaucoup trop forte !"


translate french defeat_af31fc61:


    grace "Ouais, je sais !"


translate french defeat_278f39a6:


    d "Bon je me suis quand même bien battu !"


translate french defeat_4a38dc42:


    grace "Oui c'est sûr... Bon qu'est ce que je vais bien pouvoir te demander..."


translate french defeat_058f48b4:


    dpense "Demande moi tout ce que tu veux..."


translate french defeat_7141816a:


    grace "Je vais garder ça pour plus tard si ça te va..."


translate french defeat_3813ec2e:


    d "Pas de soucis !"


translate french endpool_feb0a042:


    d "Tu avais raison en tous cas... Ca fait trop du bien d'être dans l'eau comme ça... même après une course c'est très relaxant..."


translate french endpool_7d7eae2f:


    grace "Je te l'avais dit ! Ca m'aide à enlever le stress et à ne pas penser aux problèmes quotidiens..."


translate french endpool_2983d61f:


    d "Ta mère te stresse ?"


translate french endpool_88af9c16:


    grace "Ma mère ? Oui... En gros faut être Miss Parfaite pour Madame la Principale de l'Université...."


translate french endpool_08e82bfc:


    grace "C'est super pesant..."


translate french endpool_875ad268:


    d "Ouais, je comprend..."


translate french endpool_3f8b6f6a:


    grace "Si j'ai pas les meilleures notes, si je suis pas capitaine de l'équipe de foot..."


translate french endpool_91740a1a:


    grace "Si j'ai pas un copain qui vient d'une bonne famille..."


translate french endpool_9c7f54c9:


    d "Oh, elle t'embêtes avec ça aussi ?"


translate french endpool_ceb17858:


    grace "Oulà oui... Je dois être parfaite en tout et prêt à me marier à un riche héritier pour faire des alliances entre nos familles..."


translate french endpool_5950ee26:


    grace "C'est comme ça que ça marche ici..."


translate french endpool_80818372:


    d "Et t'as déjà des prétendants ?"


translate french endpool_77603962:


    grace "Plein ! Mais j'ai jamais trouvé le bon..."


translate french endpool_1f36b29c:


    grace "Et ma mère me pousse à aller vers Emerick ou d'autres des familles comme les Orushi..."


translate french endpool_657cfc1d:


    d "Et si quelqu'un..."


translate french endpool_ca5ed8b2:


    d "Etait interessé par toi..."


translate french endpool_d12ba1aa:


    d "Mais n'était pas de ce milieu là..."


translate french endpool_c4cf4b82:


    grace "Ma mère serait..."


translate french endpool_26b66551:


    grace "Vraiment mécontente..."


translate french endpool_49cfcdc9:


    d "Mais est ce que..."


translate french endpool_36cff508:


    d "Tu le serais ?"


translate french endpool_9ff13fac:


    ji "Ahem, ahem..." with hpunch


translate french endpool_53896545:


    drew "Grace ! Tu veux bien sortir de l'eau et me rejoindre rapidement... On a un dîner ce soir !"


translate french endpool_754ea95c:


    grace "Oui, Mère..."


translate french endpool_0d1f41a3:


    dpense "Phew, c'était chaud..."


translate french endpool_1297fb29:


    drew "Et toi [name]... N'oublie pas que je te surveille... Tu m'as bien compris ?"


translate french endpool_df4aea3a:


    d "Oui, Mrs. Drew..."


translate french endpool_d191e4f0:


    dpense "Ca va pas être facile..."


translate french endpool_bdc6204a:


    grace "Hey, [name] !"


translate french endpool_5dda0f88:


    d "Hmmm ?"


translate french endpool_8a8583e7:


    grace "Tu as un téléphone ?"


translate french endpool_63ba9085:


    d "Euh... Ouais..."


translate french endpool_77be5b7d:


    grace "Tiens, ajoute moi à tes contacts plus tard !"


translate french endpool_cd0a4421:


    d "Hey ! Tu sais quelque chose à propos d'une soirée à la fin de la semaine ?"


translate french endpool_d1605dea:


    grace "Evidemment ! C'est moi qui l'organise !"


translate french endpool_3130185e:


    grace "Tu viendras ?"


translate french endpool_de9778f4:


    d "Bien sûr !"


translate french endpool_62becd20:


    grace "Parfait ! Du coup... A demain !"


translate french endpool_df3539f1:


    d "A demain !"


translate french sofiapool_7474e0b0:


    d "On est où ?"


translate french sofiapool_46856e57:


    sofia "C'est le vieil amphi..."


translate french sofiapool_3fbc8b5d:


    sofia "Plus personne ne l'utilise... à part le conseil des élèves..."


translate french sofiapool_d90a9ae5:


    sofia "Et comme je suis membre du conseil.... J'ai la clé !"


translate french sofiapool_4c3c7b1f:


    sofia "Alors... Tu vas me montrer de quoi t'es capable ?"


translate french sofiapool_4d46038d:


    d "Tu n'es pas prête..."


translate french sofiapool_5b20eac3:


    sofia "Parce que tu crois que tu peux me gérer facilement ?"


translate french sofiapool_5b80429a:


    d "Je vais faire de toi ma traînée et tu vas hurler mon nom jusqu'à ce que j'en ai fini avec toi..."


translate french sofiapool_f1a71605:


    sofia "Ahhhh..."


translate french sofiapool_6b59357b:


    d "Je vais te faire gicler jusqu'à ce que tu me supplies de te baiser..."


translate french sofiapool_47c38ad4:


    sofia "Vas y... Fais le..."


translate french sofiapool_f022ad6a:


    d "Tu seras ma salope et tu boiras directement mon sperme dans ta gorge..."


translate french sofiapool_55bbb5fd:


    sofia "Oh oui... Je le ferai !"


translate french sofiapool_ce0d59cb:


    d "Je te traiterai comme mon esclave personnelle... tu répondras à tous mes désirs..."


translate french sofiapool_9b670c10:


    sofia "Fais ce que tu veux de moi..."


translate french sofiapool_3f55375c:


    d "Allonge toi sur le bureau !"


translate french sofiapool_bab69aa7:


    sofia "Hummmm !"


translate french sofiapool_7cb0a8e4:


    sofia "J'en peux plus d'attendre que tu me touches..."


translate french sofiapool_af039036:


    sofia "S'il te plaît... Joue avec moi... Je suis ton jouet..."


translate french sofiapool_0664179c:


    sofia "Ahhhhhhhhhhhh..."


translate french sofiapool_f99d8985:


    dpense "Elle est totalement sous mon emprise..."


translate french sofiapool_de8ff332:


    dpense "Elle me laisse lui faire ce que je veux..."


translate french sofiapool_38c92066:


    dpense "J'ai l'impression qu'elle prend une tonne de plaisir à être dominée..."


translate french sofiapool_8a6010a7:


    sofia "Oh putain... Je suis déjà en train de venir ! Ne t'arrêtes pas !"


translate french sofiapool_aecb242a:


    sofia "Ahhhhhhhhh !!!"


translate french sofiapool_cbb4b371:


    sofia "Donne moi ta queue !"


translate french sofiapool_5aee8d42:


    sofia "Fais moi jouir mon seigneur..."


translate french sofiapool_e43ef0da:


    sofia "Et répands-toi sur moi pendant que je jouis aussi..."


translate french sofiapool_f9449b96:


    sofia "Je veux te sentir sur mon visage"


translate french sofiapool_d8e4cc07:


    dpense "Elle devient complètement folle..."


translate french sofiapool_0295c7cd:


    sofia "Oh putain j'adore ta bite ! Hummmm..."


translate french sofiapool_26ee886c:


    sofia "Vas y continue comme ça !"


translate french sofiapool_3078de21:


    sofia "Oui... Comme ça ! Comme ça ! Encore !!!!"


translate french sofiapool_636b8efc:


    sofia "Ohhhh ! Je VIENS !!!!!!"


translate french sofiapool_bb354e6f:


    sofia "Ahhhhh ! AHHHHHHHH ! ......."


translate french sofiapool_038daf43:


    sofia "MMMMMOOOOOOONNNNNNNN DDDDDIIIIIIIIIEEEEEEEEEEUUUUUUUU !!!"


translate french sofiapool_8fe1a030:


    d "Je viens aussi !!!!"


translate french sofiapool_70345f51:


    d "Ahhhhhhhhh..."


translate french sofiapool_6ca2c9d6:


    sofia "Un peu gluant... Mais appétissant !"


translate french sofiapool_64eaab9a:


    d "Je t'avais dit que je te ferais gicler !"


translate french sofiapool_1dc39c06:


    sofia "Ouais..."


translate french sofiapool_4dc3c5ca:


    d "Tu as été bonne ..."


translate french sofiapool_efc0c1d6:


    sofia "T'étais pas mal non plus..."


translate french sofiapool_6be327d6:


    sofia "Tu as un téléphone ?"


translate french sofiapool_a22554f8:


    d "Oui... Pourquoi ?"


translate french sofiapool_af2f290c:


    sofia "Plus facile pour garder contact..."


translate french sofiapool_2c98ee9b:


    sofia "Bon... On se voit plus tard ?"


translate french sofiapool_11f964e5:


    d "Ouais... D'accord..."


translate french sofiapool_9e894c95:


    dpense "J'espère que Bleue n'a pas été trop bruyante..."

translate french strings:


    old "5 MINUTES LATER"
    new "5 MINUTES PLUS TARD"


    old "Follow her."
    new "La suivre..."


    old "Reject her."
    new "La rejeter..."


    old "Go faster"
    new "Aller plus vite"


    old "Watch her"
    new "La regarder..."


    old "Swim normally"
    new "Nager normalement"


    old "Go even faster"
    new "Aller encore plus vite"


    old "Cheat"
    new "Tricher"


    old "Sprint"
    new "Sprinter"


    old "Win"
    new "Gagner"


    old "Let her win"
    new "La laisser gagner"




translate french pool_dd32c606:


    ji "Tu peux acheter un maillot à l'accueil..."


translate french pool_ec548b9f:


    dpense "Mieux vaut aller acheter ce maillot..."


translate french pool2_7dd0a2f8:


    grace "Ouais... Ca m'aide à rester en forme pour les matchs."


translate french endpool_4981c72d:


    drew "Grace ! Veux-tu bien sortir de l'eau... Nous avons un dîner ce soir !"


translate french sofiapool_075af965:


    sofia "Plus personne ne l'utilise... à part le conseil des étudiants..."


translate french sofiapool_1f77f57e:


    sofia "Plus facile pour rester en contact..."




translate french endpool_c459a192:


    grace "Oui... En gros, je dois être la fille parfaite pour Madame la Directrice de l'Université..."



translate french strings:


    old "Follow her. [TEMP1]"
    new "La suivre [TEMP1]"


    old "Reject her. [TEMP2]"
    new "La rejeter [TEMP2]"


    old "Sport [TEMP1]"
    new "Sport [TEMP1]"


    old "Temperament [TEMP2]"
    new "Temperament [TEMP2]"


    old "Go faster [TEMP1]"
    new "Allez au plus vite [TEMP1]"


    old "Watch her [TEMP2]"
    new "La regarder [TEMP2]"


    old "Swim normally [TEMP3]"
    new "Nager tranquille [TEMP3]"


    old "Go even faster [TEMP1]"
    new "Essayer d'aller plus vite [TEMP1]"


    old "Cheat [TEMP2]"
    new "Tricher [TEMP2]"


    old "Sprint [TEMP1]"
    new "Sprinter [TEMP1]"


    old "Win [TEMP2]"
    new "Gagner [TEMP2]"


    old "Let her win [TEMP3]"
    new "La laisser gagner [TEMP3]"



translate french strings:


    old "Follow her. [TEMP1!t]"
    new "La suivre [TEMP1!t]"


    old "Reject her. [TEMP2!t]"
    new "La rejeter [TEMP2!t]"


    old "Sport [TEMP1!t]"
    new "Sport [TEMP1!t]"


    old "Temperament [TEMP2!t]"
    new "Temperament [TEMP2!t]"


    old "Go faster [TEMP1!t]"
    new "Allez au plus vite [TEMP1!t]"


    old "Watch her [TEMP2!t]"
    new "La regarder [TEMP2!t]"


    old "Swim normally [TEMP3!t]"
    new "Nager tranquille [TEMP3!t]"


    old "Go even faster [TEMP1!t]"
    new "Essayer d'aller plus vite [TEMP1!t]"


    old "Cheat [TEMP2!t]"
    new "Tricher [TEMP2!t]"


    old "Sprint [TEMP1!t]"
    new "Sprinter [TEMP1!t]"


    old "Win [TEMP2!t]"
    new "Gagner [TEMP2!t]"


    old "Let her win [TEMP3!t]"
    new "La laisser gagner [TEMP3!t]"




translate french pool_7a1baaf2:


    ji "Jeune homme... Vous n'êtes pas autorisé à entrer dans l'enceinte de la piscine habillé de cette façon !"


translate french pool_e1b9209f:


    ji "Vous pouvez acheter un maillot à l'entrée..."


translate french pool_c303edbb:


    dpense "Vaut mieux que j'aille acheter ce maillot..."


translate french pool2_58f2204f:


    grace "Un aller-retour dans la piscine, le perdant doit une faveur au gagnant, n'importe quand, n'importe où..."


translate french pool2_ecef2909:


    dpense "Je ne peux pas râter ça !"


translate french sofiapool_72d38011:


    d "Je vais faire de toi une petite salope et tu boiras mon sperme directement depuis le fond de ta gorge..."




translate french sofiapool_9abed53e:


    sofia "Ahhhhhh !!!!"


translate french sofiapool_6b59357b_1:


    d "Je vais te faire jouir jusqu'à ce que tu me supplie de te finir..."


translate french sofiapool_47c38ad4_1:


    sofia "Oui.... Vas y..."


translate french sofiapool_9b670c10_1:


    sofia "Fais ce que tu veux de moi..."


translate french sofiapool_3f55375c_1:


    d "Allonge-toi sur le bureau !"


translate french sofiapool_bab69aa7_1:


    sofia "Hummmmm..."


translate french sofiapool_7cb0a8e4_1:


    sofia "J'ai besoin de sentir tes doigts..."


translate french sofiapool_af039036_1:


    sofia "S'il te plaît... Joue avec moi... Je suis ton jouet..."


translate french sofiapool_0664179c_1:


    sofia "Ahhhhhhhhhhhhh..."


translate french sofiapool_f99d8985_1:


    dpense "Elle est totalement sous mon contrôle..."


translate french sofiapool_de8ff332_1:


    dpense "Je peux lui faire tout ce que je veux..."


translate french sofiapool_38c92066_1:


    dpense "Elle a l'air de ressentir un énorme plaisir à être dominée..."


translate french sofiapool_8a6010a7_1:


    sofia "Oh... Je viens déjà ! Ne t'arrêtes pas !"


translate french sofiapool_5aee8d42_1:


    sofia "Fais moi jouir mon seigneur..."


translate french sofiapool_d8e4cc07_1:


    dpense "Elle devient complètement folle..."


translate french sofiapool_636b8efc_1:


    sofia "Ohhhhh ! Je viensssssssss !!!!"


translate french finblueep2_64eaab9a:


    d "Je t'avais dit que je te ferais gicler !"


translate french finblueep2_1dc39c06:


    sofia "Ouais..."


translate french finblueep2_4dc3c5ca:


    d "T'as été bonne..."


translate french finblueep2_efc0c1d6:


    sofia "T'étais pas mal non plus..."


translate french finblueep2_6be327d6:


    sofia "Tu as un téléphone ?"


translate french finblueep2_a22554f8:


    d "Oui bien sûr... Pourquoi ?"


translate french finblueep2_1f77f57e:


    sofia "Plus facile pour rester en contact..."


translate french finblueep2_2c98ee9b:


    sofia "Bon... On se voit plus tard ?"


translate french finblueep2_11f964e5:


    d "Ouais... Okay..."


translate french finblueep2_9e894c95:


    dpense "J'espère que Bleue n'a pas été trop bruyante..."




translate french sofiapool_6b9d811b:


    sofia "C'est le vieil amphi..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
