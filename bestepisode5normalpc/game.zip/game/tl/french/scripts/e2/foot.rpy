


translate french foot_edf3fa74:


    dpense "Dans les vestiaires, c'est toujours la même routine..."


translate french foot_77a4fd1a:


    dpense "D'abord la jambe gauche... Toujours..."


translate french foot_92ec1830:


    dpense "Ensuite la jambe droite... Toujours..."


translate french foot_f25f54f9:


    dpense "Ensuite, c'est le moment de se concentrer sur le match..."


translate french foot_55095236:


    mad "Bouge de là !" with hpunch


translate french foot_dd5d68f3:


    d "Hein ?"


translate french foot_1c4a0bf9:


    d "Qu'est ce que tu fous là ?"


translate french foot_43d53e49:


    mad "BAh, les jumelles se sont ramenées dans le vestiaire des filles, il me fallait un coin tranquille... Et il faut croire que t'as trouvé le dernier vestiaire tranquille..."


translate french foot_b782ec56:


    mad "Bref..."


translate french foot_0b9463d0:


    dpense "Elle va vraiment se changer là ? Juste devant moi ?"


translate french foot_8b891988:


    mad "Quoi ? T'as jamais vu une femme se changer avant ou quoi ?"


translate french foot_79d25a85:


    d "Euh... Si, si..."


translate french foot_ca733686:


    mad "Tu profites du spectacle ?"


translate french foot_19e56d79:


    d "Ben c'est toi qui arrive là et qui te change juste devant moi..."


translate french foot_86840f36:


    mad "On est dans la même équipe..."


translate french foot_3d0ab973:


    mad "Alors j'ai rien à te cacher..."


translate french foot_9e7fc475:


    dpense "Ah ben là c'est sûr qu'elle ne me cache pas grand chose..."


translate french foot_e98c80dd:


    dpense "Elle est quand même vraiment belle..."


translate french foot_97bbdea9:


    dpense "Et si athlétique... J'aimerais pas jouer contre elle..."


translate french foot_8ebf33b9:


    mad "Allez, c'est parti..."


translate french foot_b1351d09:


    mad "Ah au fait... C'est qui la bombasse maintenant ?"


translate french foot_dd5d68f3_1:


    d "Hein ?"


translate french foot_315b4afb:


    mad "..."


translate french foot_cc1af243:


    dpense "Ah c'est ça ! L'avoir comparé à Ruby tout à l'heure l'a énervé ! Elle est tellement compétitive que du coup il fallait qu'elle prouve que c'est une bombe !"


translate french foot_f64c111a:


    dpense "Ne t'inquiètes Madison... Tu es une bombasse... Il n'y a pas de doutes là-dessus..."


translate french foot_49c50de8:


    d "Allez c'est parti..."


translate french foot_b7bc84a3:


    d "Il y a un match à gagner..."




translate french foot_d5ab1f7c:


    mad "Allez les filles ! J'espère que vous êtes prêtes !"


translate french foot_ed845cf0:


    ruby "Evidemment !"


translate french foot_b7fd8669:


    mad "On dirait que les premiers matches sont finis..."


translate french foot_a571c092:


    julia "Ouais, Steven a gagné le sien..."


translate french foot_591e2cd8:


    grace "Et on dirait qu'Emerick a gagné aussi..."


translate french foot_acf1a1cf:


    d "Vous connaissez nos adversaires ?"


translate french foot_06aad2a0:


    mad "Non... Quelle importance ?"


translate french foot_193370d4:


    mad "Un seul objectif : Gagner !"


translate french foot_248a945d:


    mad "Fais comme je te dis et ça passera tout seul..."


translate french foot_2ea87172:


    mad "Reste derrière et monte à l'avant dès qu'on récupère le ballon..."


translate french foot_7bcc50f4:


    d "Okay..."


translate french foot_9a0db5cc:


    orushi "Chers participants, les règles sont simples..." with hpunch


translate french foot_7a5e14ed:


    orushi "La première équipe à 3 points gagne la rencontre..."


translate french foot_95a00a65:


    orushi "Pas de gardien..."


translate french foot_69b2f6c3:


    orushi "Vous jouerez sur un demi-terrain..."


translate french foot_0d205797:


    orushi "La première équipe dans l'ordre alphabétique engage le match..."


translate french foot_b2a4838f:


    orushi "Que les meilleurs gagnent."


translate french foot_af49f050:


    d "C'est parti..."


translate french foot_84270059:


    dpense "Julia fonce sur elle..."


translate french foot_7889bc98:


    dpense "Quoi ???"


translate french foot_8c16a232:


    dpense "Putain elle retient pas ses coups..."


translate french foot_2d685b93:


    dpense "Okay, Madison a dit : Dès qu'elles ont récupéré la balle je fonce en avant..."


translate french foot_eee1b7c6:


    dpense "Donc..."


translate french foot_271b982b:


    dpense "Je fonce en avant..."


translate french foot_9e7f43f3:


    dpense "Elle passe à Ruby..."


translate french foot_0eb8144f:


    dpense "Ouah bien le contrôle..."


translate french foot_51704437:


    dpense "Elle me l'envoit..."


translate french foot_b23ca261:


    dpense "C'est à mon tour de jouer..."


translate french solofoot1_0582ace2:


    dpense "Droite..."


translate french solofoot1_91496986:


    dpense "Gauche..."


translate french solofoot1_0582ace2_1:


    dpense "Droite..."


translate french solofoot1_3730c4c4:


    dpense "Et Gauche !!!"


translate french solofoot1_de6164a3:


    dpense "Allez, on mets le premier !!!!"


translate french solofoot1_b3487855:


    d "Vas y !!!" with hpunch


translate french solofoot1_753e42ba:


    d "Ouais !!!!"


translate french solofoot1_e67fad0e:


    ruby "Bien joué [name]!"


translate french solofoot1_974b328e:


    orushi "0 - 1 pour l'équipe H..."


translate french solofoot1_a6cdb1f6:


    orushi "Equipe H, à votre tour d'engager..."


translate french solofoot1_717cf009:


    d "Merde..."


translate french solofoot1_c13d8579:


    d "Huh ???"


translate french solofoot1_b2eece69:


    mad "Hyaaaaaaa..."


translate french solofoot1_761a446b:


    mad "Ouais !"


translate french solofoot1_16f3fcc2:


    mad "Et de un !"


translate french solofoot1_974b328e_1:


    orushi "0 - 1 pour l'équipe H..."


translate french solofoot1_a6cdb1f6_1:


    orushi "Equipe H, à votre tour d'engager..."


translate french juliafoot1_47bd8943:


    d "Julia ! A toi !"


translate french juliafoot1_f832f206:


    dpense "Non mais je rêve ? Elle est en train de jongler ?"


translate french juliafoot1_66f71455:


    julia "Hop !"


translate french juliafoot1_66f71455_1:


    julia "Hop !"


translate french juliafoot1_ce3a9306:


    dpense "Putain c'est haut !"


translate french juliafoot1_74847b12:


    dpense "Je vais devoir tenter un retourné !"


translate french juliafoot1_a636450b:


    d "Allez !" with hpunch


translate french juliafoot1_753e42ba:


    d "Ouais !"


translate french juliafoot1_e67fad0e:


    ruby "Bien joué [name] !"


translate french juliafoot1_974b328e:


    orushi "0 - 1 pour l'équipe H..."


translate french juliafoot1_a6cdb1f6:


    orushi "Equipe H, à votre tour d'engager..."


translate french juliafoot1_6706606d:


    d "Trop haut !!!"


translate french juliafoot1_9d037827:


    ruby "Han !!!"


translate french juliafoot1_753e42ba_1:


    d "Ouais !"


translate french juliafoot1_ec038a82:


    d "Bien joué Ruby !"


translate french juliafoot1_fe9c6c78:


    ruby "T'as vu ça ?"


translate french juliafoot1_974b328e_1:


    orushi "0 - 1 pour l'équipe H..."


translate french juliafoot1_a6cdb1f6_1:


    orushi "Equipe H, à votre tour d'engager..."


translate french juliafoot1_c710da6e:


    mad "Et voilà le premier !!!"


translate french juliafoot1_753e42ba_2:


    d "Ouais !"


translate french juliafoot1_4f3fd317:


    d "Bien joué Madison !"


translate french juliafoot1_e84315d6:


    ruby "T'es trop forte Maddie !"


translate french juliafoot1_974b328e_2:


    orushi "0 - 1 pour l'équipe H..."


translate french juliafoot1_a6cdb1f6_2:


    orushi "Equipe H, à votre tour d'engager..."


translate french madisonfoot1_c710da6e:


    mad "Et voilà le premier !!!"


translate french madisonfoot1_753e42ba:


    d "Ouais !"


translate french madisonfoot1_4f3fd317:


    d "Bien joué Madison !"


translate french madisonfoot1_e84315d6:


    ruby "T'es trop forte Maddie !"


translate french madisonfoot1_974b328e:


    orushi "0 - 1 pour l'équipe H..."


translate french madisonfoot1_a6cdb1f6:


    orushi "Equipe H, à votre tour d'engager..."


translate french footpart2_8c14bc76:


    mad "C'est à notre tour de commencer... On y va tous ensemble !"


translate french footpart2_8dde1283:


    grace "Okay !"


translate french footpart2_7840c8ac:


    mad "C'est parti pour le deuxième but !!!"


translate french footpart2_a3adb02b:


    dpense "C'est pas une équipe de foot c'est un tsunami qui avance..."


translate french solofoot2_0582ace2:


    dpense "Droite..."


translate french solofoot2_91496986:


    dpense "Gauche..."


translate french solofoot2_0582ace2_1:


    dpense "Droite..."


translate french solofoot2_3730c4c4:


    dpense "Et gauche !!!"


translate french solofoot2_27457a03:


    dpense "Allez... Faut encore marquer !!!"


translate french solofoot2_b3487855:


    d "Vas y !!!" with hpunch


translate french solofoot2_753e42ba:


    d "Ouais !"


translate french solofoot2_e67fad0e:


    ruby "Bien joué [name] !"


translate french solofoot2_3d5b715b:


    orushi "0 -2 pour l'équipe H..."


translate french solofoot2_3dca3269:


    orushi "Equipe D, à votre tour d'engager..."


translate french solofoot2_717cf009:


    d "Merde..."


translate french solofoot2_c13d8579:


    d "Huh ???"


translate french solofoot2_b2eece69:


    mad "Hyaaaaaaaa..."


translate french solofoot2_761a446b:


    mad "Ouais !"


translate french solofoot2_8a0891ca:


    mad "Et de deux !"


translate french solofoot2_3d5b715b_1:


    orushi "0 - 2 pour l'équipe H..."


translate french solofoot2_3dca3269_1:


    orushi "Equipe D, à votre tour d'engager..."


translate french juliafoot2_47bd8943:


    d "Julia ! A toi !"


translate french juliafoot2_f832f206:


    dpense "Je rêve où elle est en train de jongler ?"


translate french juliafoot2_66f71455:


    julia "Hop !"


translate french juliafoot2_66f71455_1:


    julia "Hop !"


translate french juliafoot2_ce3a9306:


    dpense "Putain c'est haut !"


translate french juliafoot2_74847b12:


    dpense "Je vais devoir tenter un retourné !"


translate french juliafoot2_a636450b:


    d "Allez !" with hpunch


translate french juliafoot2_753e42ba:


    d "Ouais !"


translate french juliafoot2_e67fad0e:


    ruby "Bien joué [name]!"


translate french juliafoot2_3d5b715b:


    orushi "0 - 2 pour l'équipe H..."


translate french juliafoot2_3dca3269:


    orushi "Equipe D, à votre tour d'engager..."


translate french juliafoot2_6706606d:


    d "Trop haut !!!"


translate french juliafoot2_9d037827:


    ruby "Han !!!"


translate french juliafoot2_753e42ba_1:


    d "Ouais !!!"


translate french juliafoot2_ec038a82:


    d "Bravo Ruby !!!"


translate french juliafoot2_fe9c6c78:


    ruby "T'as vu ça ?"


translate french juliafoot2_3d5b715b_1:


    orushi "0 - 2 pour l'équipe H..."


translate french juliafoot2_3dca3269_1:


    orushi "Equipe D, à votre tour d'engager..."


translate french juliafoot2_4fffecae:


    mad "Et voilà le deuxième !!!"


translate french juliafoot2_753e42ba_2:


    d "Ouais !"


translate french juliafoot2_4f3fd317:


    d "Bien joué Madison !"


translate french juliafoot2_e84315d6:


    ruby "T'es trop forte Maddie !"


translate french juliafoot2_3d5b715b_2:


    orushi "0 - 2 pour l'équipe H..."


translate french juliafoot2_3dca3269_2:


    orushi "Equipe D, à votre tour d'engager..."


translate french madisonfoot2_a6e1b431:


    mad "Et voilà le deuxième !!!"


translate french madisonfoot2_753e42ba:


    d "Ouais !"


translate french madisonfoot2_4f3fd317:


    d "Bien joué Madison !"


translate french madisonfoot2_e84315d6:


    ruby "T'es trop forte Maddie !"


translate french madisonfoot2_3d5b715b:


    orushi "0 - 2 pour l'équipe H..."


translate french madisonfoot2_3dca3269:


    orushi "Equipe D, à votre tour d'engager..."


translate french footpart3_d03c73aa:


    mad "C'est le dernier..."


translate french footpart3_8cbe0101:


    d "Ouais !"


translate french footpart3_a5e72e2d:


    mad "[name] ?"


translate french footpart3_9e4ecabd:


    d "Oui ?"


translate french footpart3_bc560022:


    mad "Quand tu auras la balle..."


translate french footpart3_fb8a0316:


    mad "Envoie la moi !"


translate french footpart3_7bcc50f4:


    d "Okay..."


translate french footpart3_bcb5c60f:


    mad "Pour la victoire !!!"


translate french footpart3_431e2f0e:


    ruby "Ouais !!!"


translate french footpart3_d85731c5:


    d "Joli Grace !"


translate french footpart3_5218b90d:


    dpense "Petit pont au calme !"


translate french footpart3_7bba1598:


    d "Super Grace !"


translate french Supermad_633b9d24:


    mad "Je vais leur montrer pourquoi on m'appelle la tigresse !"


translate french Supermad_b707d65c:


    mad "Hyaaaaaaaaaa !!!!"


translate french Supermad_b0b7239e:


    mad "Victoire !"


translate french Supermad_013aaa82:


    orushi "0 - 3 pour l'équipe H..."


translate french Supermad_94a591b5:


    orushi "Equipe D, vous êtes éliminés..."


translate french juliafoot3_47bd8943:


    d "Julia ! A toi !"


translate french juliafoot3_f832f206:


    dpense "Elle est en train de jongler ?"


translate french juliafoot3_66f71455:


    julia "Hop !"


translate french juliafoot3_66f71455_1:


    julia "Hop !"


translate french juliafoot3_ce3a9306:


    dpense "Putain c'est haut !"


translate french juliafoot3_74847b12:


    dpense "Je vais tenter un retourné !"


translate french juliafoot3_a636450b:


    d "Allez vas y !" with hpunch


translate french juliafoot3_753e42ba:


    d "Ouais !"


translate french juliafoot3_e67fad0e:


    ruby "Bien joué [name] !"


translate french juliafoot3_013aaa82:


    orushi "0 - 3 pour l'équipe H..."


translate french juliafoot3_94a591b5:


    orushi "Equipe D, vous êtes éliminés..."


translate french juliafoot3_6706606d:


    d "Trop haut !!!"


translate french juliafoot3_9d037827:


    ruby "Han !!!"


translate french juliafoot3_753e42ba_1:


    d "Ouais !"


translate french juliafoot3_ec038a82:


    d "Bien joué Ruby !"


translate french juliafoot3_fe9c6c78:


    ruby "T'as vu ça ?"


translate french juliafoot3_013aaa82_1:


    orushi "0 - 3 pour l'équipe H..."


translate french juliafoot3_94a591b5_1:


    orushi "Equipe D, vous êtes éliminés..."


translate french juliafoot3_558b89c4:


    mad "Et voilà le troisième !!!"


translate french juliafoot3_753e42ba_2:


    d "Ouais !"


translate french juliafoot3_4f3fd317:


    d "Bien joué Madison !"


translate french juliafoot3_e84315d6:


    ruby "T'es trop forte Maddie !"


translate french juliafoot3_013aaa82_2:


    orushi "0 - 3 pour l'équipe H..."


translate french juliafoot3_94a591b5_2:


    orushi "Equipe D, vous êtes éliminés..."


translate french solofoot3_0582ace2:


    dpense "Droite..."


translate french solofoot3_91496986:


    dpense "Gauche..."


translate french solofoot3_0582ace2_1:


    dpense "Droite..."


translate french solofoot3_3730c4c4:


    dpense "Et gauche !!!"


translate french solofoot3_27457a03:


    dpense "Allez, on doit encore marquer !!!"


translate french solofoot3_b3487855:


    d "Vas y !!!" with hpunch


translate french solofoot3_753e42ba:


    d "Ouais !"


translate french solofoot3_e67fad0e:


    ruby "Bien joué [name] !"


translate french solofoot3_013aaa82:


    orushi "0 - 3 pour l'équipe H..."


translate french solofoot3_94a591b5:


    orushi "Equipe D, vous êtes éliminés..."


translate french solofoot3_717cf009:


    d "Merde..."


translate french solofoot3_c13d8579:


    d "Huh ???"


translate french solofoot3_b2eece69:


    mad "Hyaaaaaaa..."


translate french solofoot3_761a446b:


    mad "Ouais !"


translate french solofoot3_c114d736:


    mad "Et de trois !"


translate french solofoot3_013aaa82_1:


    orushi "0 - 3 pour l'équipe H..."


translate french solofoot3_94a591b5_1:


    orushi "Equipe D, vous êtes éliminés..."


translate french rubyfoot3_0eb8144f:


    dpense "Putain le contrôle..."


translate french rubyfoot3_51704437:


    dpense "Elle me la re-passe..."


translate french rubyfoot3_671485ee:


    d "Et ça c'est pour le troisième but !!!" with hpunch


translate french rubyfoot3_013aaa82:


    orushi "0 - 3 pour l'équipe H..."


translate french rubyfoot3_94a591b5:


    orushi "Equipe D, vous êtes éliminés..."


translate french finfoot1_6ad6f3b2:


    ruby "On a gagné !!!"


translate french finfoot1_2ab5c4c9:


    ruby "Ahahahah !"


translate french finfoot1_44bcfc57:


    ruby "Je suis tellement fière de toi..."


translate french finfoot1_c4e84b13:


    ruby "Même si t'as pas marqué de but !"


translate french finfoot1_b7adf193:


    grace "T'as même mis un but !"


translate french finfoot1_7e3496d9:


    julia "Et même plusieurs..."


translate french finfoot1_6468fcae:


    orushi "Bien, c'est la fin de ce match..."


translate french finfoot1_e26c5fd2:


    orushi "Le meilleur joueur est :"


translate french finfoot1_58254362:


    orushi "Etudiant [name] !"


translate french finfoot1_ecde1b4d:


    orushi "Etudiante Madison !"


translate french finfoot1_6f88b953:


    orushi "Le prochain match aura lieu lundi..."


translate french finfoot1_ec91a1bf:


    orushi "D'ici là... Vous êtes libres..."


translate french finfoot1_3d52e4e0:


    orushi "Fin de transmission..."

translate french strings:


    old "Play solo"
    new "Jouer en solo"


    old "Pass it to Julia"
    new "Passer à Julia"


    old "Pass it to Madison"
    new "Passer à Madison"


    old "Play with Madison"
    new "Jouer avec Madison"


    old "Play with Julia"
    new "Jouer avec Julia"


    old "Play with Ruby"
    new "Jouer avec Ruby"




translate french finfoot1_602db608:


    dpense "Bon... Une bonne chose de faîte..."


translate french finfoot1_5b12d403:


    dpense "C'était un match facile, et les filles ont été fantastiques..."


translate french finfoot1_4e366d50:


    dpense "Les passes de Grace, le jeu de jambes de Julia, les tirs de Madison... J'avais presque rien à faire."


translate french finfoot1_9fea8065:


    dpense "Le prochain match sera sûrement plus difficile..."


translate french finfoot1_f6727475:


    dpense "Allez... Retour aux vestiaires..."


translate french finfoot1_04e96e05:


    grace "[name] !!!"


translate french finfoot1_7a2450db:


    grace "[name] attends !!!"


translate french finfoot1_66d23871:


    d "Hein ?"


translate french finfoot1_b4ae2579:


    grace "T'as été génial aujourd'hui..."


translate french finfoot1_6066fac0:


    grace "Entre l'épreuve du choix..."


translate french finfoot1_c8e72772:


    d "J'ai pas fait grand chose... C'est surtout Blue qui m'a aidé... Elle savait où était la dernière balle..."


translate french finfoot1_e74e7001:


    d "Je sais pas comment, mais quelque chose me dit que sa soeur n'y est pas étrangère..."


translate french finfoot1_0dceca55:


    grace "Oh..."


translate french finfoot1_b6e71a4b:


    grace "Tu es proche de Blue..."


translate french finfoot1_4d01480f:


    grace "La piscine, et maintenant ça..."


translate french finfoot1_7407154a:


    d "J'ai pas fait grand chose... C'est surtout Ruby qui m'a aidé..."


translate french gracekiss_3852d8e4:


    grace "Ferme tes yeux s'il te plaît !"


translate french gracekiss_dd5d68f3:


    d "Hein ?"


translate french gracekiss_c6e0575b:


    grace "Ferme tes yeux..."


translate french gracekiss_7bcc50f4:


    d "D'accord..."


translate french gracekiss_92b2ae06:


    grace "Il y a quelque chose que j'ai envie de faire... Mais je n'en ai pas le courage..."


translate french gracekiss_92268307:


    d "Allez vas y !"


translate french gracekiss_c1f4c969:


    d "On ne devrait pas..."


translate french gracekiss2_47a2537c:


    grace "Ce sera plus facile si tu as les yeux fermés..."


translate french gracekiss2_7c99e43d:


    d "Si tu le dis..."


translate french gracekiss2_f091ef9d:


    grace "Depuis que tu es arrivé, Ruby est heureuse..."


translate french gracekiss2_6260bdfe:


    grace "Julia a déjà changé 3 fois de coupes de cheveux..."


translate french gracekiss2_a0646cad:


    grace "Même Madison est plus... plaisante..."


translate french gracekiss2_f338cc08:


    d "Heu..."


translate french gracekiss2_546e33a9:


    grace "Chut..."


translate french gracekiss2_bdf56354:


    grace "Tu as été un vrai gentleman quand tu étais chez moi..."


translate french gracekiss2_b96a1cba:


    grace "Je suis contente que l'on se soit rencontré..."


translate french gracekiss2_bd4d4f9e:


    grace "Et du coup..."


translate french gracekiss2_13938477:


    d "Tu viens de m'embrasser là ?"


translate french gracekiss2_3677efee:


    grace "Oui... Et c'était génial..."


translate french gracekiss2_1f9ac873:


    grace "Je suis trop contente ! Je pensais pas pouvoir y arriver..."


translate french gracekiss2_6413d69a:


    d "Tu sais que c'est ce que je voulais faire depuis que je t'ai vu ?"


translate french gracekiss2_e287c813:


    grace "Oh ?"


translate french gracekiss2_6bb9c921:


    grace "Ben maintenant tu pourras le faire quand tu voudras..."


translate french gracekiss2_95aeacb1:


    d "Dans ce cas..."


translate french gracekiss2_cd952255:


    dpense "Je peux sentir son coeur battre si fort..."


translate french gracekiss2_59e2f283:


    dpense "Ne t'inquiète pas Grace, je vais prendre soin de toi..."


translate french gracekiss2_e11fae02:


    dpense "Tu es la plus belle femme que j'aurais pu rencontrer..."


translate french gracekiss2_e81a6af4:


    dpense "Et tu penses tellement aux autres que tu t'en oublies toi-même..."


translate french gracekiss2_eaf4b947:


    dpense "Je vais être là pour toi..."


translate french gracekiss2_aa15d993:


    grace "C'était... Inattendu..."


translate french gracekiss2_06891b96:


    grace "Mais très bon aussi !"


translate french gracekiss2_ac69ed09:


    grace "Je dois y aller... On se voit demain ? En classe ?"


translate french gracekiss2_729e449c:


    d "Oui ! Evidemment !"


translate french gracekiss2_75e8238f:


    grace "Oh ! N'oublies pas ma fête demain soir !"


translate french gracekiss2_93c9e4c4:


    d "T'inquiètes pas ! J'oublierai pas !"


translate french gracekiss2_27aa1aac:


    dpense "J'arrive pas à croire que je sors avec cette déesse..."


translate french gracekiss2_3161a1f9:


    dpense "J'ai bien de la chance..."


translate french gracekiss2_b1ca8c29:


    dpense "Bon... Retour aux vestiaires..."


translate french gracekiss2_f738d3eb:


    beth "Merde..."


translate french graceleave_42f3466f:


    grace "Ohhh... Heu... Je devrais y aller, j'ai plein de choses à faire et à préparer pour la fête de demain soir..."


translate french graceleave_f0404ad6:


    grace "On se voit en classe demain matin !"


translate french graceleave_32a25851:


    d "Oh... Okay ! A demain !"


translate french graceleave_9ab62b43:


    beth "Bien joué soeurette..."


translate french vestiairesfinep2_c822e579:


    d "Non mais c'est pas vrai !"


translate french vestiairesfinep2_8abd3135:


    mad "Chut ! Ecoute, j'ai eu une matinée stressante, et après ce match, j'ai qu'une envie..."


translate french vestiairesfinep2_df37ec18:


    mad "Relâcher la pression..."


translate french vestiairesfinep2_925fe17f:


    mad "Tu comprends ce que je veux dire ?"


translate french vestiairesfinep2_b615c5d1:


    mad "T'as le choix : soit je pars et on en reste là..."


translate french vestiairesfinep2_41ce3dab:


    mad "Ou alors tu me fais passer un bon moment..."


translate french vestiairesfinep2_a3733b7d:


    mad "Et si j'étais toi, je ferais pas le fier quand une fille tiens mes boules dans sa main..."


translate french vestiairesfinep2_9f8bc5ee:


    mad "Alors ?"


translate french madileaveep2_f1d63fb1:


    mad "Bon... Va falloir trouver quelqu'un d'autre alors... Dommage..."


translate french madifinep2_1a4e579c:


    mad "Parfait..."


translate french madifinep2_fa8ca9c6:


    mad "HUm ? T'es déjà prêt ?"


translate french madifinep2_b95efa92:


    d "Je..."


translate french madifinep2_f4645ac0:


    mad "Chut..."


translate french madifinep2_d89d51b4:


    mad "Vas y [name] ! Montre moi ce que tu sais faire !"


translate french madifinep2_dfd2a33e:


    dpense "Cette fille..."


translate french madifinep2_6c713e31:


    mad "Et n'aie pas peur ! Je suis pas en sucre !"


translate french madifinep2_927f3cd3:


    dpense "Wah... Elle est serrée !"


translate french madifinep2_49060b46:


    dpense "Et mouillée à mort !"


translate french madifinep2_3d93f24b:


    mad "Allez [name] ! Plus fort !"


translate french madifinep2_c17d8f33:


    mad "Oui..."


translate french madifinep2_416ec5fe:


    mad "Plus profond..."


translate french madifinep2_acad3ae3:


    mad "Hummmm..."


translate french madifinep2_9e1bdebf:


    mad "Comme ça... Continue..."


translate french madifinep2_f1befcce:


    mad "Han... Pas mal..."


translate french madifinep2_17fb853f:


    mad "Et si tu me montrais tes performances athlétiques ?"


translate french madifinep2_3e6ca67f:


    d "Comment ça ?"


translate french madifinep2_422353fa:


    mad "Tiens moi !"


translate french madifinep2_bab45b3d:


    mad "Oh Putain... Oui ! Là c'est mieux... Là je te sens bien !"


translate french madifinep2_e51da890:


    dpense "Cette chatte... Elle m'aspire de plus en plus..."


translate french madifinep2_83b4bb13:


    mad "Encore [name]... C'est trop bon !!!!"


translate french madifinep2_1684842c:


    dpense "Elle en tremble..."


translate french madifinep2_2c3d8a59:


    mad "Oh mon dieu... Je suis proche de..."


translate french madifinep2_25f65b46:


    dpense "Je suis pas loin derrière... "


translate french madifinep2_4a3e4891:


    mad "Humpfff... Continue [name] !"


translate french madifinep2_2685775f:


    mad "T'as pas intérêt à t'arrêter maintenant !"


translate french madifinep2_ad3d320e:


    mad "Encore ! Encore ! Encore !"


translate french madifinep2_79ea7920:


    mad "J'en veux plus ! J'en veux...."


translate french madifinep2_f56eba72:


    mad "Ahhhhhhhhhh !"


translate french madifinep2_01a01d80:


    mad "Ouiiiiiiiiiiiii !"


translate french madifinep2_4a3f086d:


    mad "Oh putain... [name]!"


translate french madifinep2_b1bb593b:


    mad "TU..... Humpffff..."


translate french madifinep2_ebf39002:


    mad "Je... Fshhhhh..."


translate french madifinep2_00957e17:


    d "Sans mot ?"


translate french madifinep2_afde25b0:


    mad "Chut !!!"


translate french madifinep2_ebaedda5:


    mad "Tu n'as pas fini ?"


translate french madifinep2_30073e1f:


    d "Non..."


translate french madifinep2_e95eef45:


    mad "Okay..."


translate french madifinep2_44d674d9:


    mad "Fais-le sur mes seins... Tu l'as mérité..."


translate french madifinep2_2461ad76:


    mad "Allez... Relâche ton jus sur mes seins !"


translate french madifinep2_2c536cc9:


    d "Putain..."


translate french madifinep2_a0f73616:


    mad "Wow... C'est quoi tout ça !"


translate french madifinep2_1789fa85:


    mad "Beurkkk..."


translate french madifinep2_9f65972f:


    mad "Je devrais aller laver ça..."


translate french madifinep2_9b3ca75a:


    d "Tu peux prendre ma douche... J'avais fini..."


translate french madifinep2_c7ec2d67:


    mad "Nan... Ca pue... Le sexe..."


translate french madifinep2_2c0f470e:


    mad "Merci [name]..."


translate french madifinep2_eec57c4e:


    d "Heu... De rien ?"


translate french madifinep2_d3fe6a33:


    mad "Oh et..."


translate french madifinep2_08958e67:


    mad "Evidemment... C'était juste pour une fois hein !"


translate french madifinep2_bb54c687:


    mad "Ne te fais pas d'idées..."


translate french madifinep2_595996da:


    d "Evidemment..."


translate french chambrefinep2_98fa4014:


    d "Un message ?"


translate french chambrefinep2_084c58a1:


    d "Juste à attendre..."


translate french chambrefinep2_9ddb6277:


    eli "Tu peux me voir ?"


translate french chambrefinep2_753e42ba:


    d "Oui !"


translate french chambrefinep2_840e3421:


    eli "Coucou !"


translate french chambrefinep2_d4678439:


    eli "Ca fait trop plaisir de te voir !"


translate french chambrefinep2_887162e1:


    d "Haha... J'ai pas changé en une semaine tu sais !"


translate french chambrefinep2_92bc22ab:


    eli "Ouais mais... Nos appels me manquent..."


translate french chambrefinep2_76cbae2d:


    d "Ouais..."


translate french chambrefinep2_fa662e80:


    eli "Alors... Comment ça se passe en Amérique ?"


translate french chambrefinep2_118b25cd:


    dpense "Je lui raconte tout au sujet de l'Université et du B.E.S.T et tout ce qui s'est passé depuis le début..."


translate french chambrefinep2_7f489c26:


    eli "Putain... Quelle histoire !"


translate french chambrefinep2_5383b3e6:


    eli "Attends une seconde... Je me mets dans mon lit !"


translate french chambrefinep2_1c33c8d8:


    eli "T'as rencontré des filles ?"


translate french chambrefinep2_d50f3269:


    d "J'ai rencontré des filles dans l'avion..."


translate french chambrefinep2_84caaeb8:


    d "J'ai choppé le cul de l'une d'entre elles... Julia... Je sais pas pourquoi mais quand elle est passée devant moi... Ma main a été attirée par son cul..."


translate french chambrefinep2_7be37bab:


    d "Le premier jour, des jumelles sont venues m'accoster... Une est Bleue et l'autre est Rouge..."


translate french chambrefinep2_7f66895f:


    d "La Bleue a essayé de m'impressionner..."


translate french chambrefinep2_37ba556f:


    d "La rouge m'a mis au défi de l'impressionner..."


translate french chambrefinep2_a2ebc3ef:


    d "Puis j'ai fait le premier test du B.E.S.T avec :"


translate french chambrefinep2_474f9baa:


    d "Ruby..."


translate french chambrefinep2_dd120e78:


    d "Julia..."


translate french chambrefinep2_b59160c0:


    d "Grace..."


translate french chambrefinep2_362c6bb7:


    d "Madison..."


translate french chambrefinep2_4b7d83be:


    d "C'était un parcours du combattant en duo..."


translate french chambrefinep2_05518b79:


    d "J'ai presque gagné l'épreuve..."


translate french chambrefinep2_d5d4cd8f:


    d "Pendant ma douche dans les vestiaires... La Bleue est venue et m'a taillé une pipe en récompense..."


translate french chambrefinep2_3f8b2dfe:


    eli "Nan !!! T'es sérieux ???"


translate french chambrefinep2_fb0ebc6a:


    d "Ouais ! Je venais juste de finir ma douche quand elle est arrivée !"


translate french chambrefinep2_4cf39263:


    eli "La salope !"


translate french chambrefinep2_1be7b02e:


    d "Hum... Oui et non..."


translate french chambrefinep2_9e7b4d66:


    eli "Oh ?"


translate french chambrefinep2_d109ff97:


    d "Ouais... Je pense qu'elle veut m'aider pendant la compétition..."


translate french chambrefinep2_338d1bf8:


    d "Je sais pas pourquoi mais..."


translate french chambrefinep2_dd3f6e7e:


    d "Pendant ma douche dans le vestiaire... La rouge est venue et était chaude pour tester un french kiss..."


translate french chambrefinep2_3f8b2dfe_1:


    eli "Nan !!! T'es sérieux ???"


translate french chambrefinep2_fb0ebc6a_1:


    d "Ouais ! Je venais juste de finir ma douche quand elle est arrivée !"


translate french chambrefinep2_4cf39263_1:


    eli "La salope !"


translate french chambrefinep2_1be7b02e_1:


    d "Hum... Oui et non..."


translate french chambrefinep2_9e7b4d66_1:


    eli "Oh ?"


translate french chambrefinep2_800edf68:


    d "Ouais... Je pense qu'elle essaye de me dominer pour la compétition..."


translate french chambrefinep2_495acc95:


    d "Pour avoir un avantage ou je sais pas quoi..."


translate french chambrefinep2_5d359f5f:


    d "Après je suis allé au parc avec les filles..."


translate french chambrefinep2_91070114:


    d "Elles m'ont demandé laquelle d'entre elles je préférais..."


translate french chambrefinep2_42f94226:


    d "Tu sais bien... Les discussions entre filles habituelles..."


translate french chambrefinep2_f55bccd2:


    d "Du coup je leur ai dit que [chosen] était ma favorite..."


translate french chambrefinep2_3bcb4400:


    eli "Oh ? Et elle a dit quoi ?"


translate french chambrefinep2_fbda1389:


    d "Elle était contente !"


translate french chambrefinep2_4f9791c5:


    d "Je leur ai dit que j'avais un faible pour les Milfs..."


translate french chambrefinep2_c4db2015:


    eli "Wow wow wow.... Comment vous en êtes arrivés à parler de Milfs ?"


translate french chambrefinep2_2e3da88b:


    d "Ben, Ruby nous a fait une conférence sur les Visual Novels..."


translate french chambrefinep2_79eea45f:


    eli "Les quoi ?"


translate french chambrefinep2_54910736:


    d "Ouais... Nan... Mais... Bref en gros le sujet c'était les trucs que les joueurs aiment et elle a dit un truc à propos des Milfs..."


translate french chambrefinep2_3ffd0020:


    eli "Heu... d'accord..."


translate french chambrefinep2_ecd08031:


    d "Puis elles ont parlé de leur prof qui est une très belle femme mais qui semble seule... ou un truc comme ça..."


translate french chambrefinep2_a0702e84:


    d "Et elles ont décidé que ce serait ma Milf !"


translate french chambrefinep2_8ea2ff1f:


    eli "Heu... Elles sont tarées ?"


translate french chambrefinep2_22f739b2:


    d "Ouais un peu..."


translate french chambrefinep2_2c7d82fe:


    d "Puis, à la piscine, j'ai rencontré Gabrielle... La prof..."


translate french chambrefinep2_8098008c:


    d "Et j'ai revu la jumelle Bleue... Je lui ai fait une sorte d'introduction au rapport dominant-dominé..."


translate french chambrefinep2_1bcb5e64:


    eli "Tu rigoles ?"


translate french chambrefinep2_aa10cf4e:


    d "Nan ! Je te jure ! Je lui avais promis que je la ferais gicler..."


translate french chambrefinep2_33642f58:


    eli "Tu l'as fait ?"


translate french chambrefinep2_f7ccf4f5:


    d "Ouais ! Juste avec mes doigts !"


translate french chambrefinep2_21ea0582:


    eli "Ohhhhh..."


translate french chambrefinep2_a8c6b84f:


    d "Elle a aimé ça et je pense qu'elle m'aime bien maintenant vu qu'elle a essayé de m'aider pendant l'épreuve qui s'est passé après..."


translate french chambrefinep2_fb014fc8:


    eli "Okay..."


translate french chambrefinep2_d0454e0a:


    d "A la piscine j'ai gagné une course contre Grace.... Elle me doit une faveur maintenant..."


translate french chambrefinep2_122f0303:


    d "J'ai perdu à la course contre Grace dans la piscine du coup je lui dois une faveur..."


translate french chambrefinep2_0facb3c9:


    d "Ruby m'a demandé si j'aimais bien Julia, je lui ai dit que je la trouvais intéressante..."


translate french chambrefinep2_bc9900ee:


    d "J'ai reçu des messages de Julia hier soir et je pense qu'on s'entend bien..."


translate french chambrefinep2_9b985cdd:


    d "Et aujourd'hui a été particulièrement mouvementé..."


translate french chambrefinep2_f1706518:


    d "J'étais en équipe avec Ruby, Madison, Grace et Julia..."


translate french chambrefinep2_2dfaa29b:


    d "Et on devait faire un match de foot à 5 contre 5... "


translate french chambrefinep2_a5b05574:


    d "Mais avant ça y'avait une sorte de jeu de hasard pour savoir qui allait participer au tournoi..."


translate french chambrefinep2_703a2543:


    d "J'ai écouté les conseils de Bleue et j'ai gagné... Je lui en dois une..."


translate french chambrefinep2_18693a93:


    d "J'ai écouté les conseils de Ruby et j'ai gagné..."


translate french chambrefinep2_9dbeee40:


    d "Puis on a joué le match..."


translate french chambrefinep2_2554cdce:


    d "On a gagné 3-0..."


translate french chambrefinep2_f23ee1c6:


    eli "Oh !!! Bravo !!!"


translate french chambrefinep2_11e5e078:


    d "C'était facile..."


translate french chambrefinep2_dae60f7e:


    d "Je ne sais pas qui sera nos prochains adversaires..."


translate french chambrefinep2_70a656e9:


    d "Après le match Grace est venue et m'a embrassé..."


translate french chambrefinep2_3dfc3e36:


    d "C'était génial..."


translate french chambrefinep2_5c8d2710:


    eli "Quelqu'un est déjà amoureux ?"


translate french chambrefinep2_0f25a809:


    d "Non... Mais... Elle est fantastique..."


translate french chambrefinep2_a5da8f20:


    d "Dans la douche Madison était excitée après le match et... pour faire baisser le stress..."


translate french chambrefinep2_23afa93c:


    d "Elle m'a demandé de la baiser..."


translate french chambrefinep2_1fb9e0ec:


    eli "Nooonnnnnnnn !"


translate french chambrefinep2_30f1c327:


    d "SI... C'était cool mais elle a dit que c'était juste une fois donc..."


translate french chambrefinep2_b4755b6b:


    eli "Hum... Elle est aussi cool que moi ?"


translate french chambrefinep2_6255c4ec:


    d "C'était... Différent... Mais ne t'inquiète pas... Je ne t'oublies pas !"


translate french chambrefinep2_8658a731:


    eli "Oh mon dieu... Tu es là depuis seulement 4 jours et t'es déjà dans un bordel pas possible avec toutes ces filles autour..."


translate french chambrefinep2_fc6dea88:


    d "Ouais..."


translate french chambrefinep2_3b9f9c32:


    eli "Fais attention Casanova... Ou ça va mal finir..."


translate french chambrefinep2_a04fa141:


    d "T'inquiètes ! Je gère !"


translate french chambrefinep2_5753911f:


    eli "Ouais ouais... A chaque fois que tu dis ça... C'est encore pire après !"


translate french chambrefinep2_fcce6271:


    eli "Bon... Il est déjà 23h ici... Je vais aller dormir..."


translate french chambrefinep2_8f59a387:


    eli "Tu me manques..."


translate french chambrefinep2_ecbb90b9:


    d "Tu me manques aussi..."


translate french chambrefinep2_a5d0bb79:


    eli "Je t'appelle bientôt !!!"


translate french chambrefinep2_07f26224:


    d "J'attends ton appel !"


translate french chambrefinep2_1f9b6d8c:


    eli "A bientôt ! Bisous !"


translate french chambrefinep2_1680b1bf:


    d "Bonne nuit Elise..."

translate french strings:


    old "You mean more to me"
    new "Tu es plus importante à mes yeux..."


    old "I like her, yes..."
    new "Je l'aime bien, oui..."


    old "Let her continue"
    new "La laisser continuer..."


    old "Accept"
    new "Accepter..."


    old "Ahah ! So funny !"
    new "Ahah ! Trop drôle !"


    old ":) So how are you ?"
    new ":) Alors comment tu vas ?"


    old "Oh wait I will call you !"
    new "Oh... Attends je vais t'appeler !"


    old "?"
    new "?"




translate french madileaveep2_b270a0dd:


    mad "Quelle déception..."




translate french vestiairesfinep21_78c32f4b:


    d "Putain ! Ce qu'on leur a mis !"


translate french vestiairesfinep21_50a8bffb:


    d "Et vous les filles, vous avez été exceptionnelles !"


translate french vestiairesfinep21_9686d4b0:


    mad "Mouais..."


translate french vestiairesfinep21_92a2ff53:


    d "Nan mais sérieusement... Vous m'aviez pas dit que vous étiez si fortes !"


translate french vestiairesfinep21_c8be3d53:


    mad "C'était un match... J'appelerais même pas ça un match en fait..."


translate french vestiairesfinep21_8fb1935d:


    mad "La prochaine fois... Ce sera pas pareil..."


translate french vestiairesfinep21_4775cd63:


    d "Ouais mais on peut quand même célébrer la victoire non ?"


translate french vestiairesfinep21_e7a937db:


    mad "Vas y je t'en prie !"


translate french madinocalin_60533d2e:


    mad "Heu ?? Tu fais quoi là ?"


translate french madinocalin_ce1c3eb9:


    d "Ben je célèbre !"


translate french madinocalin_8a203556:


    mad "Ouais ouais.. Allez à plus tard !"


translate french madinocalin_8b684304:


    d "Hey !!!"


translate french madinocalin_20da34d0:


    d "Ca va pas être facile avec elle..."


translate french madicalin_60533d2e:


    mad "Heu ??? Tu fais quoi là ?"


translate french madicalin_c4470e54:


    d "Ben une célébration d'équipe ?"


translate french madicalin_750fd072:


    mad "Et t'as besoin de rester collé à moi pour faire ça ?"


translate french madicalin_465fafd7:


    d "Laisse toi aller pour une fois... Madison..."


translate french madicalin_5e6bf0de:


    mad "Nan, désolée... Je préfère partir avant qu'une des jumelles se ramène et suggère quelque chose à plusieurs..."


translate french madicalin_29ac5843:


    d "De quoi ?"


translate french madicalin_ab00b208:


    mad "Ouais, ouais... Allez à plus tard..."


translate french madicalin_20da34d0:


    d "C'est pas facile avec elle..."


translate french madicalin_c181cb06:


    mad "Je peux pas me laisser aller comme je veux [name]..."


translate french madicalin_de693696:


    mad "Ma vie est déjà un sacré bordel... Je ne peux pas laisser qui ou quoi que ce soit entrer dedans actuellement..."


translate french madicalin_5bc827e8:


    mad "J'ai ma fille, mes études, la compétition... Rien ne viendra perturber ma..."


translate french madicalin_b8eee199:


    d "Tu n'es pas seule..."


translate french madicalin_f741ec0e:


    d "Et j'ai pas l'intention de venir pertuber ta vie..."


translate french madicalin_94ca423a:


    d "Mais je peux la rendre meilleure..."


translate french madicalin_c17d8f33:


    mad "Oui..."


translate french madicalin_fdaf3f91:


    mad "Non..."


translate french madicalin_c5fd0efd:


    mad "Je..."


translate french madicalin_c03bb58e:


    mad "Je ne peux pas..."


translate french madicalin_7bcf0972:


    d "Pas de problèmes..."


translate french madicalin_090f161d:


    d "On a le temps..."


translate french madicalin_81715ab7:


    mad "Désolée..."


translate french madicalin_19ce0e7d:


    d "Bon, je vais à la douche... On se voit plus tard ?"


translate french madicalin_81d27177:


    mad "Hein ? Oh oui... oui..."


translate french madicalin_11ca4429:


    mad "Oh... Et puis merde !"


translate french vestiairesfinep2_6ff07c76:


    mad "Chut ! Ecoute, c'était une matinée stressante et après tout ça j'ai..."


translate french vestiairesfinep2_5371cc26:


    mad "Besoin de libérer toute cette pression..."


translate french vestiairesfinep2_69a2286b:


    mad "Soit on passe du bon temps ensemble..."


translate french vestiairesfinep2_7d22bde8:


    mad "Et bien sûr... Personne ne doit savoir... Ca ne se reproduira pas..."


translate french madifinep2_7e086fb1:


    mad "Ne perd pas de temps..."


translate french madifinep2_acb8f6a1:


    mad "T'as pas intérêt à t'arrêter maintenant !"


translate french madifinep2_65a9f185:


    mad "Fais le sur mes seins..."

translate french strings:


    old "Give her a hug"
    new "Lui faire un câlin"


    old "Leave her alone"
    new "La laisser tranquille"




translate french finep2_4c9fc634:


    emerick "Je veux que tu te charges de lui..."


translate french finep2_58069b0b:


    hec ""


translate french finep2_e9632f46:


    sofia ""




translate french finep2_a202e2f9:


    ji "Ne t'inquiètes pas... Il sortira du terrain sur un brancard..."


translate french finep2_27c03ada:


    sofia "Oh non..."


translate french finep2_1cfb8569:


    sofia "[name]..."

translate french strings:


    old "Play solo [TEMP1]"
    new "La jouer perso [TEMP1]"


    old "Pass it to Julia [TEMP2]"
    new "Passer à Julia [TEMP2]"


    old "Pass it to Madison [TEMP3]"
    new "Passer à Madison [TEMP3]"


    old "Play with Madison [TEMP1]"
    new "Jouer avec Madison [TEMP1]"


    old "Play with Julia [TEMP2]"
    new "Jouer avec Julia [TEMP2]"


    old "Play solo [TEMP3]"
    new "Jouer en solo [TEMP3]"


    old "Play with Ruby [TEMP4]"
    new "Jouer avec Ruby [TEMP4]"


    old "You mean more to me [TEMP1]"
    new "T'es bien plus importante à mes yeux [TEMP1]"


    old "I like her, yes... [TEMP2]"
    new "Je l'aime bien oui... [TEMP2]"


    old "Let her continue [TEMP1]"
    new "La laisser continuer [TEMP1]"


    old "Give her a hug [TEMP1]"
    new "Lui faire un câlin [TEMP1]"


    old "Leave her alone [TEMP2]"
    new "La laisser tranquille [TEMP2]"



translate french strings:


    old "Accept [TEMP1]"
    new "Accepter [TEMP1!t]"



translate french strings:


    old "Play solo [TEMP1!t]"
    new "La jouer perso [TEMP1!t]"


    old "Pass it to Julia [TEMP2!t]"
    new "Passer à Julia [TEMP2!t]"


    old "Pass it to Madison [TEMP3!t]"
    new "Passer à Madison [TEMP3!t]"


    old "Play with Madison [TEMP1!t]"
    new "Jouer avec Madison [TEMP1!t]"


    old "Play with Julia [TEMP2!t]"
    new "Jouer avec Julia [TEMP2!t]"


    old "Play solo [TEMP3!t]"
    new "Jouer en solo [TEMP3!t]"


    old "Play with Ruby [TEMP4!t]"
    new "Jouer avec Ruby [TEMP4!t]"


    old "You mean more to me [TEMP1!t]"
    new "T'es bien plus importante à mes yeux [TEMP1!t]"


    old "I like her, yes... [TEMP2!t]"
    new "Je l'aime bien oui... [TEMP2!t]"


    old "Let her continue [TEMP1!t]"
    new "La laisser continuer [TEMP1!t]"


    old "Give her a hug [TEMP1!t]"
    new "Lui faire un câlin [TEMP1!t]"


    old "Leave her alone [TEMP2!t]"
    new "La laisser tranquille [TEMP2!t]"


    old "Accept [TEMP1!t]"
    new "Accepter [TEMP1!t]"




translate french gracekiss2_1c603af5:


    grace "Ouais... Et c'était bien..."


translate french gracekiss2_50c94879:


    dpense "Tu es la plus belle femme que j'ai pu rencontrer..."


translate french vestiairesfinep2_6693d960:


    mad "Besoin de relâcher la tension..."


translate french vestiairesfinep2_0d3b5304:


    mad "Tu vois ce que je veux dire ?"


translate french vestiairesfinep2_2673ba73:


    mad "Ou on passe du bon temps... Toi et moi..."


translate french vestiairesfinep2_810f749f:


    mad "Et bien sûr... Personne ne doit savoir... Et ça se reproduira pas..."


translate french madifinep2_2f645723:


    mad "Ne perds pas de temps..."


translate french madifinep2_078053e8:


    mad "Ha ? T'es déjà prêt... "


translate french madifinep2_32d6db02:


    dpense "Cette fille..."


translate french madifinep2_1777b9bc:


    dpense "Putain de chatte... Elle m'aspire de plus en plus..."


translate french madifinep2_245419c3:


    mad "Encore ! Oui ! Encore !"


translate french madifinep2_4d84113c:


    d "Tu peux utiliser ma douche hein... j'ai fini..."


translate french chambrefinep2_d3d73219:


    eli "Bien !"


translate french chambrefinep2_c28f2eeb:


    dpense "Je lui ai tout raconté sur mon arrivée à l'Université et sur le B.E.S.T..."


translate french chambrefinep2_2c010a8b:


    eli "Attends deux secondes... Je vais sur mon lit !"


translate french chambrefinep2_19b0c6a9:


    d "J'ai rencontré des filles dans l'avion..."


translate french chambrefinep2_f25609de:


    d "Après j'ai passé la première épreuve en duo avec:"


translate french chambrefinep2_1e1a4d94:


    d "C'était un parcours du combattant par équipe de deux..."


translate french chambrefinep2_f80dcac7:


    eli "Nan !!! Tu déconnes ???"


translate french chambrefinep2_49a107c8:


    d "Elles ont décidé que ce serait ma Milf..."


translate french chambrefinep2_f3ed2fab:


    d "Elle a aimé ça je crois, du coup elle a essayé de m'aider pendant le dernier test..."


translate french chambrefinep2_709280ee:


    d "J'ai gagné une course à la piscine contre Grace... Maintenant elle me doit une faveur..."


translate french chambrefinep2_a1807d52:


    d "J'ai perdu une course à la piscine contre Grace... Maintenant je lui dois une faveur..."


translate french chambrefinep2_deca89d1:


    d "Après j'ai reçu des messages de Julia hier soir et on s'entend plutôt bien..."


translate french chambrefinep2_5ae3d40d:


    d "J'étais dans l'équipe de Madison avec Julia, Ruby et Grace..."


translate french chambrefinep2_7d68cce8:


    d "Pendant la douche Madison était excitée après le match et... Et pour relâcher son stress..."


translate french chambrefinep2_cec9ca0d:


    d "C'était... Différent... Mais ne t'inquiètes pas je ne t'oublie pas !"


translate french chambrefinep2_11fe92e0:


    eli "Oh mon dieu... Ca fait que 4 jours que t'es là-bas et t'as déjà plein d'histoires avec une tonne de filles..."


translate french chambrefinep2_8f00470f:


    eli "Ouais ouais... A chaque fois que tu as dit ça... C'était pire !"


translate french chambrefinep2_dc91fc7c:


    eli "Bon... Il est onze heures, il va falloir que j'aille dormir quand même..."




translate french madivestfin_ca733686:


    mad "Ca va ? Tu profites de la vue ?"


translate french madivestfin_19e56d79:


    d "Ben... Tu viens là et tu te changes pile en face de moi..."


translate french madivestfin_86840f36:


    mad "On est dans la même équipe..."


translate french madivestfin_3d0ab973:


    mad "J'ai rien à te cacher..."


translate french madivestfin_9e7fc475:


    dpense "Ah ben c'est sûr qu'elle ne me cache rien là..."


translate french madivestfin_e98c80dd:


    dpense "Elle est quand même vraiment belle..."


translate french madivestfin_97bbdea9:


    dpense "Et si athlétique... J'aimerais pas l'avoir comme adversaire..."


translate french madivestfin_8ebf33b9:


    mad "Bon allez... On y va..."


translate french madivestfin_b1351d09:


    mad "Ah au fait... C'est qui la bombasse maintenant ?"


translate french madivestfin_dd5d68f3:


    d "Hein ?"


translate french madivestfin_315b4afb:


    mad "..."


translate french madivestfin_cc1af243:


    dpense "Ah d'accord ! C'est le fait de l'avoir comparé à Ruby tout à l'heure... Elle est tellement compétitive qu'il fallait qu'elle prouve sa supériorité..."


translate french madivestfin_f64c111a:


    dpense "T'inquiètes pas Madison... Tu es une bombasse... Pas de doutes là-dessus..."


translate french madivestfin_49c50de8:


    d "Bon... Allons-y..."


translate french madivestfin_b7bc84a3:


    d "Y'à un match à gagner..."


translate french madivestfin_d5ab1f7c:


    mad "Okay les filles ! J'espère que vous êtes prêtes !"


translate french madivestfin_ed845cf0:


    ruby "Evidemment !"


translate french madivestfin_b7fd8669:


    mad "On dirait que les premiers matchs sont finis..."


translate french madivestfin_a571c092:


    julia "Ouais, Steven a gagné son premier match..."


translate french madivestfin_591e2cd8:


    grace "On dirait qu'Emerick aussi..."


translate french madivestfin_acf1a1cf:


    d "Vous savez qui on affronte ?"


translate french madivestfin_06aad2a0:


    mad "Nan... On s'en fout !"


translate french madivestfin_193370d4:


    mad "Un seul objectif : Gagner !"


translate french madivestfin_248a945d:


    mad "Fait comme je te dis.... Et ça passera tout seul..."


translate french madivestfin_2ea87172:


    mad "Reste à l'arrière et monte dès qu'on reprend la balle..."


translate french madivestfin_7bcc50f4:


    d "Okay..."


translate french madivestfin_9a0db5cc:


    orushi "Chers participants, les règles sont simples..." with hpunch


translate french madivestfin_7a5e14ed:


    orushi "La première équipe qui atteindra 3 points gagne le match..."


translate french madivestfin_95a00a65:


    orushi "Pas de gardien..."


translate french madivestfin_69b2f6c3:


    orushi "Vous allez jouer sur un demi-terrain..."


translate french madivestfin_0d205797:


    orushi "La première équipe dans l'ordre alphabétique engage..."


translate french madivestfin_b2a4838f:


    orushi "Que les meilleurs gagnent !"


translate french madivestfin_af49f050:


    d "C'est parti..."


translate french madivestfin_84270059:


    dpense "Julia fonce sur elle..."


translate french madivestfin_7889bc98:


    dpense "Hein ???"


translate french madivestfin_8c16a232:


    dpense "Elle retient pas ses coups..."


translate french madivestfin_2d685b93:


    dpense "Okay, Madison a dit : dès qu'on a la balle, je monte..."


translate french madivestfin_eee1b7c6:


    dpense "Donc..."


translate french madivestfin_271b982b:


    dpense "Je monte..."


translate french madivestfin_9e7f43f3:


    dpense "Elle passe à Ruby..."


translate french madivestfin_0eb8144f:


    dpense "Sympa le contrôle..."


translate french madivestfin_51704437:


    dpense "Elle me la renvoit..."


translate french madivestfin_b23ca261:


    dpense "A mon tour de jouer..."


translate french finmadi1_c822e579:


    d "Nan... C'est une blague ?"


translate french finmadi1_6ff07c76:


    mad "Shhhh ! Ecoute, j'ai eu une matinée stressante et après tout ça, j'ai..."


translate french finmadi1_6693d960:


    mad "Besoin de laisser retomber la pression..."


translate french finmadi1_0d3b5304:


    mad "Tu vois ce que je veux dire ?"


translate french finmadi1_b615c5d1:


    mad "Donc, t'as un choix... Soit je repars et ça s'arrête là..."


translate french finmadi1_2673ba73:


    mad "Soit on partage un moment tous les deux... Toi et moi..."


translate french finmadi1_810f749f:


    mad "Et bien sûr... Personne ne doit être au courant... Et ça se reproduira pas..."


translate french finmadi2_9f8bc5ee:


    mad "Alors ?"


translate french madifin3_b270a0dd:


    mad "Pfff... Quelle déception..."


translate french madifin4_d89d51b4:


    mad "Vas y [name] ! Montre-moi ce que tu sais faire ! "


translate french madifin4_32d6db02:


    dpense "Cette fille..."


translate french madifin4_6c713e31:


    mad "Et tu peux y aller... Je suis pas en sucre !"


translate french madifin4_927f3cd3:


    dpense "Putain... Elle est serrée !"


translate french madifin4_49060b46:


    dpense "Et mouillée de ouf !"


translate french madifin4_3d93f24b:


    mad "Allez [name] ! Plus fort !"


translate french madifin4_c17d8f33:


    mad "Oui..."


translate french madifin4_416ec5fe:


    mad "Plus profond..."


translate french madifin4_acad3ae3:


    mad "Hummmm..."


translate french madifin4_9e1bdebf:


    mad "Comme ça... Continue..."


translate french madifin4_f1befcce:


    mad "Hummm... Pas mal vraiment..."


translate french madifin4_17fb853f:


    mad "Et si tu me montrais un peu ta force ?"


translate french madifin4_3e6ca67f:


    d "Comment ?"


translate french madifin4_422353fa:


    mad "Tiens moi !"


translate french madifin4_bab45b3d:


    mad "Oh putain... Oui !!!!"


translate french madifin4_1777b9bc:


    dpense "Cette chatte... Elle m'aspire de plus en plus..."


translate french madifin4_83b4bb13:


    mad "Encore [name]... C'est trop bon !!!"


translate french madifin4_1684842c:


    dpense "Elle est en train de trembler..."


translate french madifin4_2c3d8a59:


    mad "Oh putain... Je suis proche..."


translate french madifin4_25f65b46:


    dpense "Je suis pas loin derrière..."


translate french madifin4_4a3e4891:


    mad "Humpfff... Continue [name] !"


translate french madifin4_acb8f6a1:


    mad "T'arrêtes surtout pas !"


translate french madifin4_245419c3:


    mad "Encore ! Oui ! Encore !"


translate french madifin4_79ea7920:


    mad "J'en veux plus ! J'en veuxxxxx........"


translate french madifin4_f56eba72:


    mad "Ahhhhhhhhhhhh !"


translate french madifin4_01a01d80:


    mad "Ouiiiiiiiiiiiii !"


translate french madifin4_4a3f086d:


    mad "Oh putain... [name]!"


translate french madifin4_b1bb593b:


    mad "Tu... Humpfff..."


translate french madifin4_ebf39002:


    mad "Je... Fsssshhh...."


translate french madifin4_00957e17:


    d "Sans voix ?"


translate french madifin4_afde25b0:


    mad "Ta gueule !!!"


translate french madifin4_ebaedda5:


    mad "T'as pas fini ?"


translate french madifin4_30073e1f:


    d "Nan..."


translate french madifin4_e95eef45:


    mad "Okay..."


translate french madifin4_65a9f185:


    mad "Finis toi sur mes seins..."


translate french madifin4_2461ad76:


    mad "Allez... Relâche tout sur mes seins !"


translate french madifin4_2c536cc9:


    d "Putain..."


translate french madifin4_a0f73616:


    mad "Wow... c'est quoi tout ça !"


translate french madifin4_1789fa85:


    mad "Beurk..."


translate french madifin4_9f65972f:


    mad "Faut que j'aille laver ça maintenant..."


translate french madifin4_4d84113c:


    d "Tu peux prendre ma douche... J'avais fini..."


translate french madifin4_c7ec2d67:


    mad "Nan... Ca pue... Le sexe..."


translate french madifin5_2c0f470e:


    mad "Merci [name]..."


translate french madifin5_eec57c4e:


    d "Hummmm... De rien ?"


translate french madifin5_d3fe6a33:


    mad "Oh et..."


translate french madifin5_08958e67:


    mad "Evidemment... C'était juste une fois hein !"


translate french madifin5_bb54c687:


    mad "Te fais pas d'idées..."


translate french madifin5_595996da:


    d "Evidemment..."


translate french elisechoix1_3f8b2dfe:


    eli "Nan !!! T'es sérieux ???"


translate french elisechoix1_fb0ebc6a:


    d "Ouais ! Je venais juste de finir ma douche quand elle est arrivée !"


translate french elisechoix1_4cf39263:


    eli "La pute !"


translate french elisechoix1_1be7b02e:


    d "Hum... Oui et non..."


translate french elisechoix1_9e7b4d66:


    eli "Oh ?"


translate french elisechoix1_d109ff97:


    d "Ouais... Je pense qu'elle veut m'aider pour la compétition..."


translate french elisechoix1_338d1bf8:


    d "Je sais pas trop pourquoi mais..."


translate french elisechoix1_dd3f6e7e:


    d "Pendant ma douche dans les vestiaires... La jumelle Rouge est arrivée et était chaude pour tester le french kiss..."


translate french elisechoix1_f80dcac7:


    eli "Nan !!! Tu déconnes ???"


translate french elisechoix1_fb0ebc6a_1:


    d "Je te jure ! Je venais juste de finir ma douche quand elle est arrivée !"


translate french elisechoix1_4cf39263_1:


    eli "La salope !"


translate french elisechoix1_1be7b02e_1:


    d "Hum... Oui et non..."


translate french elisechoix1_9e7b4d66_1:


    eli "Oh ?"


translate french elisechoix1_800edf68:


    d "Ouais... Je pense qu'elle veut essayer de me dominer pendant la compétition..."


translate french elisechoix1_495acc95:


    d "Pour avoir un avantage ou quelque chose comme ça...."


translate french elisechoix1_5d359f5f:


    d "Après je suis allé au parc avec les filles..."


translate french elisechoix1_91070114:


    d "Elles m'ont demandé qui était ma favorite parmi elles..."


translate french elisechoix1_42f94226:


    d "Tu sais... Les discussions de filles quoi... "


translate french elisechoix1_f55bccd2:


    d "Du coup je leur ai dit que c'était [chosen]..."


translate french elisechoix1_3bcb4400:


    eli "Oh ! Et elle a dit quoi ?"


translate french elisechoix1_fbda1389:


    d "Bah elle était contente..."


translate french elisechoix1_4f9791c5:


    d "Je leur ai dit que j'aimais bien les Milfs..."


translate french elisechoix1_c4db2015:


    eli "Wow wow wow.... Comment vous en êtes arrivés à ce genre de discussion ?"


translate french elisechoix1_2e3da88b:


    d "Ben... Ruby nous a fait une conférence sur les Visuals Novels et..."


translate french elisechoix1_79eea45f:


    eli "Les quoi ?"


translate french elisechoix1_54910736:


    d "Ouais... Nan... Bref... On a parlé des trucs que les joueurs aiment et ça a dérivé sur les Milfs...."


translate french elisechoix1_3ffd0020:


    eli "Heu... Okay..."


translate french elisechoix1_ecd08031:


    d "Puis elles ont parlé de leur prof qui est super belle mais seule... Ou un truc du genre..."


translate french elisechoix1_49a107c8:


    d "Et elles ont décidé que ce serait ma Milf..."


translate french elisechoix1_8ea2ff1f:


    eli "Euh... Elles sont tarées ou... ??"


translate french elisechoix1_22f739b2:


    d "Ouais un peu !"


translate french elisechoix1_2c7d82fe:


    d "A la piscine j'ai rencontré Gabriella... La prof..."


translate french elisechoix1_8098008c:


    d "Et j'ai rencontré Blue pour finir par lui faire une sorte d'intro à la domination..."


translate french elisechoix2_1bcb5e64:


    eli "De quoi ? Nan ! Tu rigoles ?"


translate french elisechoix2_aa10cf4e:


    d "Nan nan ! Je te jure ! Je lui avais promis que je la ferais... Gicler et..."


translate french elisechoix2_33642f58:


    eli "Tu l'as fait ???"


translate french elisechoix2_f7ccf4f5:


    d "Ben ouais... Juste avec mes doigts !!!"


translate french elisechoix2_21ea0582:


    eli "Ohhhh..."


translate french elisechoix2_f3ed2fab:


    d "Elle a aimé ça et je pense qu'elle m'aime bien vu qu'elle a essayé de m'aider lors de la dernière épreuve..."


translate french elisechoix2_fb014fc8:


    eli "Okay..."


translate french elisechoix2_709280ee:


    d "J'ai gagné une course à la piscine face à Grace... Maintenant elle me doit une faveur..."


translate french elisechoix2_a1807d52:


    d "J'ai perdu une course face à Grace à la piscine... Maintenant je lui dois une faveur..."


translate french elisechoix2_0facb3c9:


    d "Ruby m'a demandé si j'aimais bien Julia du coup je lui ai dit que je la trouvais intéressante..."


translate french elisechoix2_deca89d1:


    d "Puis j'ai eu des messages de Julia hier soir et je pense qu'on s'entend vraiment bien..."


translate french elisechoix2_9b985cdd:


    d "Aujourd'hui a été chargé aussi..."


translate french elisechoix2_5ae3d40d:


    d "J'étais en équipe avec les filles..."


translate french elisechoix2_2dfaa29b:


    d "On devait faire un match de foot..."


translate french elisechoix2_a5b05574:


    d "Mais avant ça y'avait une sorte de loterie pour savoir qui allait jouer et qui ne pourrait pas participer..."


translate french elisechoix2_703a2543:


    d "J'ai écouté les conseils de Blue et j'ai gagné le jeu... Je lui en dois une du coup..."


translate french elisechoix2_18693a93:


    d "J'ai écouté les conseils de Ruby et j'ai gagné le jeu..."


translate french elisechoix2_9dbeee40:


    d "Puis on a fait notre match..."


translate french elisechoix2_2554cdce:


    d "On a gagné 3-0..."


translate french elisechoix2_f23ee1c6:


    eli "Ah ouais ! Bien !"


translate french elisechoix2_11e5e078:


    d "C'était facile..."


translate french elisechoix2_dae60f7e:


    d "Je ne sais pas qui on va affronter au prochain tour..."


translate french elisechoix2_70a656e9:


    d "Après le match Grace est venue me voir et on s'est embrassés..."


translate french elisechoix2_3dfc3e36:


    d "C'était génial..."


translate french elisechoix2_5c8d2710:


    eli "Oulà ! Déjà amoureux ?"


translate french elisechoix2_0f25a809:


    d "Quoi ? Nan ! Mais elle est fantastique..."


translate french elisechoix2_7d68cce8:


    d "Dans la douche Madison était excitée après le match et... Pour baisser la pression... "


translate french elisechoix4_23afa93c:


    d "Elle m'a demandé de coucher avec elle..."


translate french elisechoix4_1fb9e0ec:


    eli "Naaaaaaaaaaaannnnnn"


translate french elisechoix4_30f1c327:


    d "Si... C'était énorme mais elle a dit que c'était juste une fois du coup..."


translate french elisechoix4_b4755b6b:


    eli "Hummm... Aussi bonne que moi ?"


translate french elisechoix4_cec9ca0d:


    d "C'était... Différent... T'inquiètes je t'oublie pas !!!"


translate french elisechoix4_11fe92e0:


    eli "Oh mon dieu... Ca fait 4 jours que t'es là et t'es déjà en train de draguer tout ce qui bouge..."


translate french elisechoix4_fc6dea88:


    d "Ouais..."


translate french elisechoix4_3b9f9c32:


    eli "Fais attention Casanova... Ou ça va mal finir..."


translate french elisechoix4_a04fa141:


    d "T'inquiète ! Je gère !"


translate french elisechoix4_8f00470f:


    eli "Ouais ouais... A chaque fois que tu dis ça... Tu gères rien du tout !"


translate french elisechoix4_dc91fc7c:


    eli "Bon... Il est déjà 23 heures ici... Faut que je dorme..."


translate french elisechoix4_8f59a387:


    eli "Tu me manques tu sais..."


translate french elisechoix4_ecbb90b9:


    d "Toi aussi..."


translate french elisechoix4_a5d0bb79:


    eli "Je t'appelle bientôt !"


translate french elisechoix4_07f26224:


    d "J'attendrai ton appel !"


translate french elisechoix4_1f9b6d8c:


    eli "Allez ! Bisous !"


translate french elisechoix4_1680b1bf:


    d "Bonne nuit Elise..."




translate french elisechoix1_7f7c490c:


    d "Je leur ai dit que j'avais un faible pour les Milfs..."


translate french elisechoix1_6e07921b:


    d "Ben, Ruby nous a donné les règles d'un Visual Novel..."


translate french elisechoix2_4985cd2f:


    d "Puis on a joué le match..."


translate french elisechoix4_5cd3c30f:


    eli "Ouais ouais... A chaque fois que je t'ai entendu dire ça... C'était pire après!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
