


translate french e2s3_a984cb58:


    d "Il est temps de regarder ce téléphone !"


translate french e2s3_86bd34e7:


    d "Oh ? Un autre message !"


translate french e2s3_a25d3f67:


    d "Okay... il va falloir être frais pour demain..."


translate french e2s3_90146086:


    d "Encore ?"


translate french e2s3_4768f182:


    d "Maintenant... Au dodo !"




translate french e2s3_845373f5:


    grace "Coucou toi ! Est ce que tu aimes le jeu ?"


translate french e2s3_f00c15b1:


    grace "Génial ! J'aimerais que tu nous aides en ajoutant le jeu à ta liste de souhaits STEAM !"


translate french e2s3_faa4cf02:


    grace "Ca ne te coûte rien mais ça nous aide énormément à préparer la sortie du jeu en janvier !"


translate french e2s3_9c14f477:


    grace "Alors... Peux tu cliquer sur ce lien ?"


translate french e2s3_550056d1:


    grace "Ah bon ? Désolé mais tu peux quand même laisser des commentaires sur ce que tu aimes ou n'aimes pas sur les forums..."


translate french e2s3_36653393:


    grace "Dis nous ce que tu voudrais voir ou faire !"


translate french e2s3_b32a6fc0:


    grace "ET si tu veux quand même nous aider, ajoute nous à ta liste de souhaits STEAM !"




translate french fingrace_614f2200:


    julia "♪ I threw a wish in the well... ♪"


translate french fingrace_9d61bc4e:


    julia ""


translate french fingrace_9d4569e8:


    julia ""


translate french fingrace_0849f2f6:


    julia ""


translate french fingrace_f9e786bb:


    julia ""


translate french fingrace_bb752026:


    julia ""


translate french fingrace_afe7b44a:


    julia ""


translate french fingrace_0cab0354:


    julia ""


translate french fingrace_ed0e926b:


    julia ""


translate french fingrace_1e474c68:


    julia ""


translate french fingrace_05a5d3df:


    julia ""


translate french fingrace_1f085ffc:


    julia ""


translate french fingrace_5c5469cc:


    julia "{i}♪ Hey, I just met you... ♪ {/i}"


translate french fingrace_12f16252:


    julia "{i}♪ And this is crazy... ♪{/i}"


translate french fingrace_125a8758:


    julia "{i}♪ But here's my number... ♪{/i}"


translate french fingrace_6eb4bbc1:


    julia "{i}♪ So call me, maybe? ♪{/i}"


translate french fingrace_2eaf79ee:


    ji "C'est bien la première fois que je t'entends chanter comme ça !"


translate french fingrace_d314bb4d:


    julia "Hein ? Ah... Oui..."


translate french fingrace_180aa646:


    ji "Y'à un gars derrière tout ça !!!!"


translate french fingrace_4d6deba1:


    julia "Quoi ? Non non pas du tout... Qu'est ce que tu vas t'imaginer ?"


translate french fingrace_8aa0c3dd:


    ji "Allez... Arrête... Je t'ai jamais vu aussi enjouée et pleine de vie !"


translate french fingrace_af5b50d7:


    ji "Je peux sentir quand une amie est intéressée par un gars !"


translate french fingrace_d6003cdf:


    julia "Bon... C'est trois fois rien... Juste un gars que j'ai rencontré..."


translate french fingrace_b00a0896:


    ji "Il est comment ?"


translate french fingrace_74703c30:


    julia "Charlotte !!!"


translate french fingrace_66671b48:


    cha "Ben quoi ? Il doit être sacrément spécial pour t'avoir tapé dans l'oeil !"


translate french fingrace_1f425e96:


    julia "Ben... Pas vraiment... Je ne sais pas... Je l'aime bien, c'est tout..."


translate french fingrace_dcdc0b5a:


    cha "Et lui... Tu sais ce qu'il pense de toi ?"


translate french fingrace_a02e67e4:


    julia "Je crois qu'il m'aime bien... Mais je n'en suis pas sûre..."


translate french fingrace_22afcde9:


    cha "Génial ! Allez ma grande... Tu vas entrer dans la cour des grands !!!!"


translate french fingrace_68ae02f5:


    julia "Comment ça ?"


translate french fingrace_4f013c56:


    cha "Tu veux que je te fasse un dessin ?"


translate french fingrace_9bc420b9:


    julia "Un gars... Une fille ... De l'amour...."


translate french fingrace_23330d4b:


    julia "Oh arrête... On en est pas encore là !"


translate french fingrace_67660424:


    cha "Je serai vraiment curieuse de le rencontrer n'empêche..."


translate french fingrace_81c2222a:


    cha "Pour que tu sois dans cet état... Il doit en valoir le coup..."


translate french fingrace_a3c0d52f:


    cha "Tu le rencontreras sûrement bientôt..."


translate french fingrace_0c163247:


    cha "Ouais... Bref... Va t'occuper des gars là... Je vais faire la caisse !"


translate french fingrace_6fd36bef:


    julia "D'accord..."


translate french fingrace_6c28afa2:


    julia "Je pense qu'il me voit juste comme une copine..."


translate french fingrace_a5f1e4b2:


    cha "Ah merde... C'est pas un bon début ça !"


translate french fingrace_8e8b945d:


    julia "Ben c'est même pas un début en fait..."


translate french fingrace_d76c7bb5:


    cha "Mais s'il est aussi bien que ça... J'aimerais le rencontrer !"


translate french fingrace_81c2222a_1:


    cha "S'il te met dans cet état... C'est qu'il doit en valoir le coup !"


translate french fingrace_a3c0d52f_1:


    cha "Tu le rencontreras bientôt je pense..."


translate french fingrace_0c163247_1:


    cha "Ouais... Bref... Va t'occuper des gars là... Je vais faire la caisse !"


translate french fingrace_6fd36bef_1:


    julia "D'accord..."


translate french fingrace_87bd76d0:


    julia "Messieurs, s'il vous plaît.... Nous allons fermer..."


translate french fingrace_7fc2e979:


    ji "Le client est roi non ? C'est pas comme ça qu'ils disent ?"


translate french fingrace_68ae02f5_1:


    julia "Comment ça ?"


translate french fingrace_13e15321:


    ji "Ben si je décide qu'on reste ici... Alors on reste... Hein les gars !"


translate french fingrace_7cf02106:


    ji "Ouais !!!"


translate french fingrace_97b1d9f0:


    julia "Ecoutez... Je vous demande juste de partir pour que je puisse rentrer chez moi..."


translate french fingrace_ca5bec71:


    ji "Je m'en fous de ce que tu veux !"


translate french fingrace_d67f447b:


    ji "Au pire tu pourrais nous montrer ton petit cul... Et peut être qu'on te laissera tranquille ! Hein les gars !"


translate french fingrace_7cf02106_1:


    ji "Ouais !!!"


translate french fingrace_934c38f0:


    s "Les gars, dehors... Vous avez entendez la dame..."


translate french fingrace_8d0a4594:


    ji "Mais mec ! C'est elle qui vient nous chauffer là..."


translate french fingrace_8be1c017:


    s "J'ai dit DEHORS !!!"


translate french fingrace_f5928430:


    ji "Okay Capitaine... Pas besoin de gueuler !"


translate french fingrace_87ed5711:


    ji "Quand à toi... J'en ai pas fini avec toi..."


translate french fingrace_70b956e4:


    s "Désolé Julia... Les gars sont un peu sous pression..."


translate french fingrace_4e619f92:


    julia "Mouais..."


translate french fingrace_d5176ae5:


    s "Ne leur en tient pas rigueur... Et si ils te causent d'autres soucis... Préviens-moi..."


translate french fingrace_d1f70c04:


    julia "..."


translate french fingrace_35115fe7:


    cha "Qu'est ce qu'il foutait là ?"


translate french fingrace_9f36931f:


    julia "Il est venu chercher ses gars... Je suppose qu'ils vont s'entraîner..."


translate french fingrace_4344ba5b:


    cha "A cette heure-ci ?"


translate french fingrace_683a7314:


    julia "Ouais... Ils ont été nuls l'année dernière, du coup ils veulent se rattraper..."


translate french fingrace_7bdd87db:


    cha "Sinon ils vont perdre leurs bourses d'études... Je vois..."


translate french fingrace_ff51750b:


    julia "C'est possible..."


translate french fingrace_b092efff:


    cha "Bon allez c'est bon... On y va !"


translate french fingrace_51e8bb06:


    julia "Okay..."


translate french fingrace_1b483561:


    cha "Tu me tiendras au courant au sujet de ce mystérieux étranger hein !"


translate french fingrace_487b4d4a:


    julia "Heu... Oui oui ne t'inquiètes pas !"


translate french fingrace_f6a0b0ae:


    cha "Ah et au fait... Demain tu seras toute seule pour l'ouverture... J'arriverai un peu plus tard... Il me reste un peu de gestion à faire..."


translate french fingrace_5713d02d:


    julia "D'accord... Je serai là..."


translate french fingrace_d1651a03:


    cha "A demain !"


translate french fingrace_41dfeedb:


    julia "A demain."


translate french fingrace_0e1e2253:


    julia "Bon... va encore falloir jongler demain... Les cours, le restaurant..."


translate french fingrace_20ab69a7:


    julia "Il m'a pas envoyé de message..."


translate french fingrace_2a8582c3:


    julia "Est ce que je devrais lui en envoyer un ?"


translate french fingrace_5a09cb73:


    julia "Punaise, je sais même pas quoi faire dans ce cas-là..."


translate french fingrace_63632687:


    julia "Je suis vraiment nulle..."


translate french fingrace_aa8e4281:


    julia "Allez Julia... Prends ton courage à deux mains... "


translate french fingrace_5dcbb5c3:


    julia "Coucou !"


translate french fingrace_d247e240:


    julia "Coucou... T'as pas pire pour commencer ?"


translate french fingrace_593e1a4d:


    julia "Merde ! Il a répondu !"


translate french fingrace_6e99c3a2:


    julia "Je fais quoi ? Je fais quoi ? Je fais quoi ?"


translate french fingrace_14b367ef:


    d "Hey ! Salut !"


translate french fingrace_c57e2904:


    julia "Bon... Il est pas mieux que moi sur les phrases d'accroche..."


translate french fingrace_edd120a3:


    julia "Je devrais lui dire quoi ? Ca va ? Nan c'est nul..."


translate french fingrace_3d5456ee:


    julia "Passé une bonne journée ?"


translate french fingrace_5c32a5b6:


    julia "C'est pas mieux... On dirait que c'est sa mère qui lui parle...."


translate french fingrace_5763b18b:


    julia "Oh... Mon dieu..."


translate french fingrace_3e3f740c:


    julia "Ahhhh ! Un autre message !"


translate french fingrace_dbb0af3a:


    d "Je suis crevé de ma journée... Merci pour le tour en tous cas..."


translate french fingrace_bbf54d60:


    julia "De rien !"


translate french fingrace_fa6876e2:


    julia "J'espère que je n'ai rien oublié !"


translate french fingrace_5ee78e9a:


    d "Ne t'inquiètes pas, tu as été parfaite ! Et si j'ai besoin d'infos, je te demanderai !"


translate french fingrace_d6f16a8e:


    julia "Oui..."


translate french fingrace_e17f2213:


    d "Bon, je te laisse dormir ! Tu dois être crevée à passer ton temps à la librairie..."


translate french fingrace_40340f5e:


    julia "Tu peux même pas t'imaginer..."


translate french fingrace_5769e4a9:


    d "Bonne nuit Julia."


translate french fingrace_5dfa7b90:


    julia "Bonne nuit, [name]."


translate french fingrace_358c7e0e:


    julia "Nan, il s'en fout..."




translate french e2s3_5b2d794b:


    julia "{i}Hey, I just met you...{/i}"


translate french e2s3_d255241c:


    julia "{i}And this is crazy...{/i}"


translate french e2s3_d7f51766:


    julia "{i}But here's my number...{/i}"


translate french e2s3_fb89d37b:


    julia "{i}So call me, maybe?{/i}"


translate french e2s3_1d184b05:


    ji "C'est bien la première fois que je t'entends chanter comme ça !"


translate french e2s3_d314bb4d:


    julia "Hein ? Ah... Oui..."


translate french e2s3_180aa646:


    ji "Y'à un gars derrière tout ça !!!!"


translate french e2s3_4d6deba1:


    julia "Quoi ? Non non pas du tout... Qu'est ce que tu vas t'imaginer ?"


translate french e2s3_8aa0c3dd:


    ji "Allez... Arrête... Je t'ai jamais vu aussi enjouée et pleine de vie !"


translate french e2s3_af5b50d7:


    ji "Je peux le sentir quand une de mes amies est attirée par un gars !"


translate french e2s3_d6003cdf:


    julia "Nan mais c'est rien... Juste un gars que j'ai rencontré..."


translate french e2s3_b00a0896:


    ji "Il est comment ?"


translate french e2s3_74703c30:


    julia "Charlotte !!!"


translate french e2s3_66671b48:


    cha "Ben quoi ??? Il doit être génial pour t'avoir tapé dans l'oeil comme ça !"


translate french e2s3_1f425e96:


    julia "Ben... Pas vraiment... Enfin je sais pas... Je l'aime bien, c'est tout..."


translate french e2s3_dcdc0b5a:


    cha "Et tu sais ce qu'il pense de toi ?"


translate french e2s3_a02e67e4:


    julia "Je crois qu'il m'aime bien... "


translate french e2s3_22afcde9:


    cha "Génial ! Allez ma grande... Tu vas entrer dans la cour des grands !!!!"


translate french e2s3_68ae02f5:


    julia "Comment ça ?"


translate french e2s3_4f013c56:


    cha "Tu veux que je te fasse un dessin ?"


translate french e2s3_dfd7962c:


    cha "Un gars... Une fille ... De l'amour...."


translate french e2s3_23330d4b:


    julia "Oh arrête... On en est pas encore là !"


translate french e2s3_67660424:


    cha "Je serai vraiment curieuse de le rencontrer n'empêche..."


translate french e2s3_81c2222a:


    cha "Pour que tu sois dans cet état... Il doit en valoir le coup..."


translate french e2s3_c66bfef3:


    julia "Tu le rencontreras sûrement bientôt..."


translate french e2s3_0c163247:


    cha "Ouais... Bref... Va t'occuper des gars là... Je vais faire la caisse !"


translate french e2s3_6fd36bef:


    julia "D'accord..."


translate french e2s3_6c28afa2:


    julia "Je pense qu'il me voit juste comme une copine..."


translate french e2s3_a5f1e4b2:


    cha "Ah merde... C'est pas un bon début ça !"


translate french e2s3_8e8b945d:


    julia "Ben c'est même pas un début en fait..."


translate french e2s3_d76c7bb5:


    cha "Mais s'il est aussi bien que ça... J'aimerais le rencontrer !"


translate french e2s3_81c2222a_1:


    cha "S'il te met dans cet état... C'est qu'il doit en valoir le coup !"


translate french e2s3_c66bfef3_1:


    julia "Tu le rencontreras bientôt je pense..."


translate french e2s3_0c163247_1:


    cha "Ouais... Bref... Va t'occuper des gars là... Je vais faire la caisse !"


translate french e2s3_6fd36bef_1:


    julia "D'accord..."


translate french e2s3_87bd76d0:


    julia "Messieurs, s'il vous plaît.... Nous allons fermer..."


translate french e2s3_7fc2e979:


    ji "Le client est roi non ? C'est pas comme ça qu'ils disent ?"


translate french e2s3_68ae02f5_1:


    julia "Comment ça ?"


translate french e2s3_13e15321:


    ji "Ben si je décide qu'on reste ici... Alors on reste... Hein les gars !"


translate french e2s3_7cf02106:


    ji "Ouais !!!"


translate french e2s3_97b1d9f0:


    julia "Ecoutez... Je vous demande juste de partir pour que je puisse rentrer chez moi..."


translate french e2s3_ca5bec71:


    ji "On s'en fout de ce que tu veux !"


translate french e2s3_d67f447b:


    ji "Au pire tu pourrais nous montrer ton petit cul... Et peut être qu'on te laissera tranquille ! Hein les gars !"


translate french e2s3_7cf02106_1:


    ji "Ouais !!!"


translate french e2s3_ffae4ead:


    s "Les gars, dehors... Vous avez entendu la dame..."


translate french e2s3_8d0a4594:


    ji "Mais mec ! C'est elle qui vient nous chauffer là..."


translate french e2s3_8be1c017:


    s "J'ai dit DEHORS !!!"


translate french e2s3_f5928430:


    ji "Okay Capitaine... Pas besoin de gueuler !"


translate french e2s3_87ed5711:


    ji "Quand à toi... J'en ai pas fini avec toi..."


translate french e2s3_70b956e4:


    s "Désolé Julia... Les gars sont un peu sous pression..."


translate french e2s3_4e619f92:


    julia "Mouais..."


translate french e2s3_d5176ae5:


    s "Ne leur en tient pas rigueur... Et s'ils te causent d'autres soucis... Préviens-moi..."


translate french e2s3_d1f70c04:


    julia "..."


translate french e2s3_35115fe7:


    cha "Qu'est ce qu'il foutait là ?"


translate french e2s3_9f36931f:


    julia "Il est venu chercher ses gars... Je suppose qu'ils vont s'entraîner..."


translate french e2s3_4344ba5b:


    cha "A cette heure-ci ?"


translate french e2s3_683a7314:


    julia "Ouais... Ils ont été nuls l'année dernière, du coup ils veulent se rattraper..."


translate french e2s3_7bdd87db:


    cha "Sinon ils vont perdre leurs bourses d'études... Je vois..."


translate french e2s3_ff51750b:


    julia "C'est possible..."


translate french e2s3_52b4eed6:


    cha "Ces nouveaux vêtements montrent beaucoup trop de... nous..."


translate french e2s3_6a2ae747:


    julia "On peut pas utiliser les anciens ?"


translate french e2s3_fc9ea268:


    cha "Tu as entendu le Boss... Nous nous devons d'attirer une nouvelle clientèle..."


translate french e2s3_81e60c5f:


    julia "Ouais... Mais bon..."


translate french e2s3_b092efff:


    cha "Bon allez c'est bon... On y va !"


translate french e2s3_51e8bb06:


    julia "Okay..."


translate french e2s3_1b483561:


    cha "Tu me tiendras au courant au sujet de ce mystérieux étranger hein !"


translate french e2s3_d2da4b5a:


    julia "Heu... Oui oui ne t'inquiètes pas !"


translate french e2s3_0c4885c6:


    cha "Ah et au fait... Demain tu seras toute seule pour l'ouverture... J'arriverai un peu plus tard..."


translate french e2s3_aa414997:


    cha "Il me reste un peu de gestion à faire..."


translate french e2s3_5713d02d:


    julia "D'accord... Je serai là..."


translate french e2s3_d1651a03:


    cha "A demain !"


translate french e2s3_6dcbeedd:


    julia "A demain !"


translate french e2s3_8c94c5fe:


    julia "Ca doit être froid maintenant..."


translate french e2s3_a116ebc2:


    julia "Et mon café aussi..."


translate french e2s3_ef9f765d:


    julia "Oh putain de talons..."


translate french e2s3_0e1e2253:


    julia "Bon... va encore falloir jongler demain... Les cours, le restaurant..."


translate french e2s3_20ab69a7:


    julia "Il m'a pas envoyé de message..."


translate french e2s3_2a8582c3:


    julia "Est ce que je devrais lui en envoyer un ?"


translate french e2s3_5a09cb73:


    julia "Punaise, je sais même pas quoi faire dans ce cas-là..."


translate french e2s3_63632687:


    julia "Je suis vraiment nulle..."


translate french e2s3_aa8e4281:


    julia "Allez Julia... Prends ton courage à deux mains..."


translate french e2s3_5dcbb5c3:


    julia "Coucou !"


translate french e2s3_d247e240:


    julia "Coucou... T'as pas pire pour commencer ?"


translate french e2s3_593e1a4d:


    julia "Merde ! Il a répondu !"


translate french e2s3_6e99c3a2:


    julia "Je fais quoi ? Je fais quoi ? Je fais quoi ?"


translate french e2s3_14b367ef:


    d "Hey ! Salut !"


translate french e2s3_c57e2904:


    julia "Bon... Il est pas meilleur que moi sur les phrases d'accroche..."


translate french e2s3_edd120a3:


    julia "Je devrais lui dire quoi ? Ca va ? Nan c'est nul..."


translate french e2s3_3d5456ee:


    julia "Passé une bonne journée ?"


translate french e2s3_2c0993bb:


    julia "C'est pas mieux... On dirait que c'est sa mère qui lui parle..."


translate french e2s3_3f4f3e80:


    julia "Oh... Mon dieu..."


translate french e2s3_3e3f740c:


    julia "Ahhhh ! Un autre message !"


translate french e2s3_dbb0af3a:


    d "Je suis crevé de ma journée... Merci pour le tour en tous cas..."


translate french e2s3_bbf54d60:


    julia "De rien !"


translate french e2s3_fa6876e2:


    julia "J'espère que je n'ai rien oublié !"


translate french e2s3_5ee78e9a:


    d "Ne t'inquiètes pas, tu as été parfaite ! Et si j'ai besoin d'infos, je te demanderai !"


translate french e2s3_d6f16a8e:


    julia "Oui..."


translate french e2s3_f8f06dc3:


    d "Bon, je te laisse dormir ! Tu dois être crevée à passer ton temps à la librairie..."


translate french e2s3_40340f5e:


    julia "Tu peux même pas t'imaginer..."


translate french e2s3_5769e4a9:


    d "Bonne nuit Julia."


translate french e2s3_5dfa7b90:


    julia "Bonne nuit, [name]."


translate french e2s3_358c7e0e:


    julia "Nan, il s'en fout..."




translate french e2s3_8cbd665b:


    d "Qui ça peut être ?"


translate french e2s3_f2f3c377:


    ji "C'est bien la première fois que je t'entend chanter comme ça !"


translate french e2s3_cca72ab6:


    d "Ne t'inquiète pas, tu as été parfaite ! Et du coup si j'ai des questions je sais qui venir voir !"




translate french suitejuliatel_20ab69a7:


    julia "Il m'a pas envoyé de message..."


translate french suitejuliatel_2a8582c3:


    julia "Je devrais lui en envoyer ?"


translate french suitejuliatel_5a09cb73:


    julia "Punaise, je ne sais même pas quoi faire dans ce cas..."


translate french suitejuliatel_63632687:


    julia "Je suis vraiment nulle..."


translate french suitejuliatel_aa8e4281:


    julia "Bon... On va essayer..."


translate french suitejuliatel_5dcbb5c3:


    julia "Coucou !"


translate french suitejuliatel_d247e240:


    julia "Coucou... T'as pas mieux pour commencer ? Coucou..."


translate french suitejuliatel_593e1a4d:


    julia "Merde ! Il a répondu !"


translate french suitejuliatel_6e99c3a2:


    julia "Je fais quoi ? Je fais quoi ? je fais quoi ?"


translate french suitejuliatel_14b367ef:


    d "Hey, salut !"


translate french suitejuliatel_c57e2904:


    julia "Bon... Il est pas mieux que moi..."


translate french suitejuliatel_edd120a3:


    julia "Qu'est ce que je devrais lui répondre ? Ca va ? Nan c'est nul..."


translate french suitejuliatel_3d5456ee:


    julia "Passé une bonne journée ?"


translate french suitejuliatel_2c0993bb:


    julia "Pas mieux... On dirait sa mère qui parle..."


translate french suitejuliatel_3f4f3e80:


    julia "Oh mon dieu..."


translate french suitejuliatel_3e3f740c:


    julia "Ahhh ! Un autre message !"


translate french suitejuliatel_dbb0af3a:


    d "Fatigué de la journée... Merci pour le tour en tous cas !"


translate french suitejuliatel_bbf54d60:


    julia "De rien !"


translate french suitejuliatel_fa6876e2:


    julia "J'espère que je n'ai rien oublié !"


translate french suitejuliatel_cca72ab6:


    d "Ne t'inquiètes pas tu as été parfaite ! Et si j'ai besoin d'infos je saurai à qui venir demander !"


translate french suitejuliatel_d6f16a8e:


    julia "Oui..."


translate french suitejuliatel_f8f06dc3:


    d "Bon... Je te laisse dormir ! Tu dois être crevée à passer ton temps à la bibliothèque..."


translate french suitejuliatel_40340f5e:


    julia "Tu peux même pas t'imaginer..."


translate french suitejuliatel_5769e4a9:


    d "Bonne nuit, Julia."


translate french suitejuliatel_5dfa7b90:


    julia "Bonne nuit, [name]."


translate french suitejuliatel_358c7e0e:


    julia "Nan... Il s'en fout..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
