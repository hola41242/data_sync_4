


translate french e2s4_5b6b04d6:


    ji "Tonton Ted ! J'ai envie de regarder la Pat Patrouille !"


translate french e2s4_c2c97b56:


    ted "Nan, Cassie, c'est plus l'heure de regarder la télé !"


translate french e2s4_6d11133e:


    cassie "Mais j'ai TELLEMENT envie de regarder !"


translate french e2s4_a42216b5:


    ted "Non non..."


translate french e2s4_692a2f61:


    cassie "S'te plaît, s'te plaît, s'te plaît !!!!"


translate french e2s4_98a1471a:


    ted "J'ai dit non Cassie ! Il est déjà 8 heures et demie et..."


translate french e2s4_441c0783:


    mad "8 heures et demie ???"


translate french e2s4_d3ea60d5:


    mad "Putain, je vais être en retard !"


translate french e2s4_32fabfce:


    mad "Qu'est ce que je vais me mettre ?"


translate french e2s4_34413095:


    mad "Oh, ça fera l'affaire !"


translate french e2s4_15fa04e3:


    mad "Ted ! Cassie est habillée ?"


translate french e2s4_0db593f2:


    ted "Ouais ouais..."


translate french e2s4_d1c52f83:


    mad "Oublies pas de la déposer à l'école !"


translate french e2s4_0db593f2_1:


    ted "Ouais ouais..."


translate french e2s4_a7500e50:


    mad "Et vérifie qu'elle a bien son goûter dans son cartable !"


translate french e2s4_0db593f2_2:


    ted "Ouais ouais..."


translate french e2s4_c7abb2c6:


    mad "Ouais ouais... Ouais ouais... Il sait dire autre chose lui ?"


translate french e2s4_699afde9:


    mad "Cassie ma puce, Maman s'en va ! On se voit ce soir ma chérie !"


translate french e2s4_2f399ecc:


    cassie "A ce soir maman ! Et t'oublieras pas mon histoire hein ? Tu avais promis !"


translate french e2s4_6ea8c9bd:


    mad "Bien sûr mon coeur ! Promis !"


translate french e2s4_e03d9c57:


    cassie "OUAIS !!!!"


translate french e2s4_3511f9dc:


    mad "Okay, nouvelle journée..."


translate french e2s4_0c084aee:


    mad "Et c'est reparti..."


translate french e2s4_a512fbd7:


    mad "Cours d'éco..."


translate french e2s4_cb7c44c2:


    mad "Entraînement..."


translate french e2s4_8cca5e36:


    mad "Aller chercher Cassie à l'école..."


translate french e2s4_bc9e9ad6:


    mad "Gérer ces deux poufiasses..."


translate french e2s4_90d878c6:


    beth "Ben alors Madison, t'as oublié de t'habiller ce matin ?"


translate french e2s4_04f3053e:


    sofia "Ou Papa et Maman ont plus les moyens de t'acheter des robes ?"


translate french e2s4_4a9669cc:


    mad "Tu vois celui là ?"


translate french e2s4_26f6c27a:


    mad "Mets le bien profond au fond à droite !"


translate french e2s4_5cbb791c:


    ruby "Hey coucou !"


translate french e2s4_d215ddd0:


    mad "Salut Ruby..."


translate french e2s4_b10d9f66:


    ruby "Dûr le réveil ?"


translate french e2s4_9ec6269c:


    mad "Ouais je me suis réveillé à la bourre, même pas eu le temps d'embrasser Cassie avant de partir..."


translate french e2s4_3edbc739:


    mad "J'ai mis les premières choses qui me tombaient sous la main..."


translate french e2s4_62205d67:


    ruby "Oh tu sais t'as pas besoin d'être habillée comme une diva tous les jours hein !"


translate french e2s4_efde3ab7:


    mad "Oui je sais, mais bon..."


translate french e2s4_24bb991b:


    mad "Et mon frère, faut tout lui répéter un million de fois..."


translate french e2s4_595c80ce:


    mad "Fatiguant..."


translate french e2s4_31b16005:


    ruby "Tu devrais te trouver quelque chose pour souffler..."


translate french e2s4_8cbe499c:


    ruby "Et peut être trouver quelqu'un aussi... ça te ferait du bien !"


translate french e2s4_94518faf:


    mad "J'ai pas le temps pour ça !"


translate french e2s4_7dc72278:


    mad "Et qui voudrait d'une mère célibataire avec un frère inutile, un emploi du temps de fou et une vie aussi chaotique ?"


translate french e2s4_62e0c03b:


    ruby "J'aurais bien une petite idée..."


translate french e2s4_d19ecb96:


    mad "Hein ?"


translate french e2s4_77ba680b:


    ruby "Non non... Rien rien..."


translate french e2s4_37f47a0b:


    d "Okay, c'est la bonne classe..."


translate french e2s4_abda508c:


    d "Mais où est ce que je devrais m'asseoir ?"


translate french madiruby_c7149e69:


    d "Je peux m'asseoir ?"


translate french madiruby_94364417:


    ruby "Bien sûr !"


translate french madiruby_93f7fde9:


    mad "Oui oui, bien sûr..."


translate french madiruby_230cca25:


    d "Ca fait bizarre d'être là... dans une classe..."


translate french madiruby_280960ba:


    ruby "Entouré de filles..."


translate french madiruby_d22bf5e3:


    d "Hein ? Ah oui... Ca aussi..."


translate french madiruby_b4f07fd2:


    mad "Ca n'a pas l'air de te déranger..."


translate french madiruby_fbef33c9:


    d "Non non... Pas du tout..."


translate french madiruby_28d87aa3:


    ruby "Tu m'étonnes ! Le mec est assis à côté d'une bombasse..."


translate french madiruby_bf8a9c0a:


    ruby "Il va pas se plaindre non plus !"


translate french madiruby_3efb7af7:


    mad "Ruby... Arrête..."


translate french madiruby_dbf9b320:


    d "Elle a pas tort !"


translate french madiruby_af9136f3:


    mad "Ah bon ?"


translate french madiruby_e55d32ad:


    d "J'ai pas dit que c'était toi la bombasse !"


translate french madiruby_40e66c37:


    mad "Oh !"


translate french madiruby_5f32c47f:


    ruby "Oh ?"


translate french gracejulia_c7149e69:


    d "Je peux m'asseoir ?"


translate french gracejulia_02600786:


    grace "Evidemment !"


translate french gracejulia_e9b99907:


    julia "Oui, oui bien sûr..."


translate french gracejulia_230cca25:


    d "Ca fait bizarre d'être là... dans une classe..."


translate french gracejulia_1f1d00ef:


    julia "C'est ton premier cours c'est ça ?"


translate french gracejulia_dbed4522:


    d "Oui... J'espère que la prof sera sympa !"


translate french gracejulia_1ba870f0:


    julia "T'inquiètes pas... Elle est cool..."


translate french gracejulia_5e3e5401:


    julia "Tant que tu ne dérange pas son cours !"


translate french gracejulia_7bcc50f4:


    d "Okay..."


translate french gracejulia_5b680b5d:


    grace "Je suis encore désolée pour ma mère hier..."


translate french gracejulia_67acc6de:


    d "T'inquiètes pas... Ca arrive..."


translate french gracejulia_cef63d47:


    grace "J'ai vraiment aimé ce moment avec toi..."


translate french gracejulia_f07527e5:


    d "J'espère bien qu'il y en aura d'autres..."


translate french gracejulia_d10a5469:


    grace "Moi aussi..."


translate french sittwins_bb305a4f:


    d "Je peux m'asseoir ?"


translate french sittwins_49293452:


    beth "Bien sûr, Avec plaisir !"


translate french sittwins_f9455265:


    sofia "Uh... Oui, bien sûr !"


translate french sittwins_2686ee98:


    sofia "Alors... Premier cours ?"


translate french sittwins_dd8c52d3:


    d "Oui... Je savais me^me pas quoi apporter..."


translate french sittwins_8b052222:


    beth "C'est toujours comme ça les premières fois..."


translate french sittwins_56e443ac:


    beth "Un peu douloureux... Mais une fois que c'est parti..."


translate french sittwins_b660916b:


    beth "On en redemande..."


translate french sittwins_e78947be:


    sofia "T'en fais pas pour ma soeur... Elle ne mord pas... Quoi que..."


translate french sittwins_013dbb2f:


    d "Oh, j'ai pas peur ! C'est pas avec sa bouche qu'elle m'aura..."


translate french sittwins_7d2ee7e5:


    beth "Ah ouais t'en es sûr ?"


translate french sittwins_ace3b8d4:


    beth "Il paraît que je ne suis pas mauvaise avec ma bouche pourtant..."


translate french sittwins_10760d33:


    beth "A moins que tu ne préfères..."


translate french sittwins_99c38ec9:


    beth "Un contact plus proche et..."


translate french sittwins_ab131cde:


    beth "Plus brutal..."


translate french sittwins_6710910f:


    sofia "Ou alors qu'on satisfasse tous tes désirs..."


translate french sittwins_9ca925ff:


    sofia "Même les plus enfouis..."


translate french sittwins_9ea58198:


    sofia "En allant au plus loin et..."


translate french sittwins_03cc4247:


    sofia "Au plus profond..."


translate french sittwins_590ce44c:


    sofia "Des choses..."


translate french sittwins_f338cc08:


    d "Heu..."


translate french suitecours_46fb28ab:


    gaby "Bonjour tout le monde !"


translate french suitecours_883d9886:


    gaby "Je suis Gabriella, votre professeur d'économie..."


translate french suitecours_fa87f52f:


    gaby "Certains ou certaines d'entre vous me connaissent déjà en tant que coach de l'équipe féminine de foot..."


translate french suitecours_ac5e6d6c:


    gaby "Tandis que d'autres me sont totalement inconnus..."


translate french suitecours_58ff09da:


    gaby "Ne tournons pas autour du pot... J'aime quand les gens sont directs et francs avec moi... Si vous n'êtes pas ici pour travailler ou que ça ne vous intéresse pas..."


translate french suitecours_c9d37095:


    gaby "Vous pouvez partir de suite..."


translate french suitecours_34d67876:


    gaby "Pour les autres..."


translate french suitecours_6f2a997a:


    gaby "Et bien, je suis toujours disponible pour répondre à vos questions, et je serai heureuse de vous aider !"


translate french suitecours_85fcfaee:


    gaby "Je vois que nous avons l'honneur d'accueillir le nouvel élève français... [name], c'est ça ?"


translate french suitecours_2d1f1461:


    d "Oui, madame..."


translate french suitecours_5532afff:


    gaby "Très bien, je vois que vous commencez à vous habituer à l'endroit et que vous ne vous êtes pas perdu cette fois-ci..."


translate french suitecours_11a49d80:


    gaby "Et que vous être habillé convenablement..."


translate french suitecours_b2842d1b:


    d "Oui..."


translate french suitecours_daf08564:


    gaby "Alors, comment ça se passe pour vous ?"


translate french suitecours_4f3652ea:


    d "J'ai rencontré des gens merveillux depuis que je suis ici, et je dois admettre que je ne sais même pas comment les remercier pour leur hospitalité..."


translate french suitecours_4debf90f:


    ruby "Awwww ! C'est trop mignon !!!"


translate french suitecours_27de816f:


    gaby "Les filles... Toujours si gentilles !"


translate french suitecours_df0cb0e4:


    gaby "Très bien..."


translate french suitecours_d88d27c1:


    d "Vous savez... Je ne pense pas qu'il y ait de bonne ou de mauvaise situation..."


translate french suitecours_bf5156e3:


    gaby "Intéressant !"


translate french suitecours_a1418d15:


    gaby "Tu ne penses pas que le monde est soit blanc soit noir ? "


translate french suitecours_596be531:


    d "Je ne sais pas... Je pense surtout qu'il ne faut pas toujours voir le verre à moitié vide..."


translate french suitecours_df0cb0e4_1:


    gaby "Très bien..."


translate french suitecours_4367836d:


    d "J'ai la compétition en tête... Le reste, franchement, ça me passe au dessus..."


translate french suitecours_6c000199:


    gaby "Le B.E.S.T ? Tu en fais partie ?"


translate french suitecours_531910ca:


    d "Ben... Je suis aussi surpris que vous... Mais oui..."


translate french suitecours_df0cb0e4_2:


    gaby "Très bien..."


translate french suitecours_2df75f35:


    d "Ben en fait je vis ma meilleure vie ! Je rencontre des filles de partout, je suis dans le B.E.S.T... Et sérieusement... Avoir une prof aussi belle est génial... Ca me donne envie de venir en cours !"


translate french suitecours_a1699582:


    gaby "Euh... Je m'attendais pas à ça..."


translate french suitecours_a9642ea4:


    d "Haha ! je suis plein de surprises !"


translate french suitecours_9504acb6:


    gaby "Et culotté en plus..."


translate french suitecours_df0cb0e4_3:


    gaby "Très bien..."


translate french suitecours_63b979ab:


    gaby "Bon ben je vois que vous avez commencé à établir des relations franco-américaines..."


translate french suitecours_099834b3:


    gaby "Qui peut me dire, à part [name], quel cadeau la France a offert aux Etats-Unis pour célébrer notre Indépendance ?"


translate french suitecours_ae64f34d:


    d "Tu as confiance en moi ?"


translate french suitecours_a7a44cf1:


    mad "Pas vraiment..."


translate french suitecours_3f883698:


    d "La Statue de la Liberté."


translate french suitecours_91da6cea:


    mad "T'es sûr ?"


translate french suitecours_d38968bc:


    d "Oui, oui..."


translate french suitecours_57cbaadd:


    emerick "La Statue de la Liberté !" with hpunch


translate french suitecours_3df4aaa1:


    d "Et merde..."


translate french suitecours_2d6dad60:


    gaby "Oui c'est correct, Emerick..."


translate french suitecours_ca813997:


    mad "Désolée..."


translate french suitecours_edf1868e:


    mad "Heu... Oui..."


translate french suitecours_3f883698_1:


    d "La Statue de la Liberté."


translate french suitecours_0a6ece95:


    mad "Okay."


translate french suitecours_244ef33c:


    mad "La statue de la Liberté ?"


translate french suitecours_36794003:


    gaby "Oui !"


translate french suitecours_dc636991:


    emerick "Putain, je le savais..."


translate french suitecours_7e3ae4e5:


    gaby "Veuillez soignez votre langage, Emerick!"


translate french suitecours_1bb5a634:


    emerick "Désolé madame !"


translate french suitecours_781a1cd8:


    mad "Merci !"


translate french suitecours_26af0923:


    dpense "La Statue de la Liberté..."


translate french suitecours_57cbaadd_1:


    emerick "La Statue de la Liberté !" with hpunch


translate french suitecours_3df4aaa1_1:


    d "Et merde..."


translate french suitecours_2d6dad60_1:


    gaby "Oui c'est correct, Emerick..."


translate french suitecours_087fee55:


    gaby "Okay... Le cours d'aujourd'hui portera sur les principes généraux d'économie..."


translate french suitecours_af59083d:


    gaby "Et donc... Tout est autour de l'offre et de la demande..."


translate french suitecours_916d515d:


    drew "A tous les participants du B.E.S.T..." with hpunch


translate french suitecours_6820b807:


    drew "Veuillez vous réunir au centre du stade dans 10 minutes..."


translate french suitecours_938fcc14:


    drew "Je répète..."


translate french suitecours_e6f31e6b:


    drew "Tous les participants du B.E.S.T doivent se réunir au centre du stade dans 10 minutes..."


translate french suitecours_d7c1bae8:


    gaby "Et bien, je pense que la classe est terminée..."


translate french suitecours_aab8223d:


    gaby "Bonne chance à tous !"

translate french strings:


    old "Sit with Madison and Ruby"
    new "S'asseoir avec Madison et Ruby"


    old "Sit with Grace and Julia"
    new "S'asseoir avec Grace et Julia"


    old "Sit with the twins"
    new "S'asseoir avec les jumelles"




translate french suitecours_cb6abcd7:


    orushi "Bienvenue, chers participants du B.E.S.T..."


translate french suitecours_04c60917:


    orushi "Vous n'êtes plus que 50 dans cette compétition qui va récompenser le meilleur d'entre vous..."


translate french suitecours_7d3c0eb2:


    orushi "Tout d'abord, je tiens à vous féliciter pour avoir réussi le premier test..."


translate french suitecours_2ac1c2b2:


    orushi "Aujourd'hui, nous avons décidé d'organiser quelque chose de spécial pour vous..."


translate french suitecours_0d63aeed:


    orushi "En fait, j'ai décidé d'ajouter un challenge bonus à la sélection..."


translate french suitecours_118c8a2c:


    orushi "Ce challenge ne sera pas éliminatoire..."


translate french suitecours_fae9f837:


    orushi "En voyant les performances des équipes féminines et masculines de football..."


translate french suitecours_fac953e3:


    orushi "Je me suis dit que ce serait intéressant de faire ressortir votre esprit d'équipe..."


translate french suitecours_d57d8af8:


    orushi "Tout en évaluant vos performances athlétiques..."


translate french suitecours_29f0eedd:


    orushi "Donc, nous avons organisé un tournoi..."


translate french suitecours_7377b77c:


    orushi "Il y aura des matchs à élimination directe..."


translate french suitecours_13d3ec80:


    orushi "Et à la fin, nous aurons la meilleure équipe..."


translate french suitecours_dea55d2d:


    orushi "Bien sûr, s'il n'y a pas d'élimination, il faut qu'il y ait quelque chose en jeu..."


translate french suitecours_2bc2747c:


    orushi "Nous avons donc décidé de récompenser l'équipe gagnante par un bonus un peu spécial..."


translate french suitecours_88d75d0b:


    orushi "Voyez par vous-mêmes..."


translate french suitecours_c42abb16:


    orushi "L'équipe gagnante se verra confier les clés de cette maison, située non loin du campus, durant toute sa participation au B.E.S.T..."


translate french suitecours_72a3d47a:


    orushi "La maison a cinq chambres individuelles et tout le nécessaires pour s'entraîner, se reposer et se préparer aux nouvelles épreuves du B.E.S.T dans les meilleures conditions possibles..."


translate french suitecours_c87ce251:


    orushi "Bien sûr, tout ceci a un coût..."


translate french suitecours_d32d8b03:


    orushi "Comme vous l'aurez deviné, vous allez concourir par équipes de cinq pour gagner ce privilège..."


translate french suitecours_0a5480e5:


    orushi "Ceci pour voir votre motivation, votre performance et les connections que vous arriverez à établir avec les autres..."


translate french suitecours_736785cb:


    orushi "Vous allez vous-mêmes composer vos propres équipes..."


translate french suitecours_040186bf:


    orushi "Juste un conseil : pensez à optimiser votre équipe et vos joueurs..."


translate french suitecours_1e8bfa8c:


    orushi "Il n'y aura rien pour les perdants..."


translate french suitecours_12414ce8:


    orushi "Pour former vos équipes, l'ordinateur a sélectionné des capitaines qui vont choisir leurs équipiers pour ce challenge..."


translate french suitecours_48785378:


    orushi "Voici la liste des capitaines..."


translate french suitecours_d09ce434:


    orushi "Etudiant Steven..."


translate french suitecours_11afa90a:


    s "Oui Monsieur..."


translate french suitecours_b2136f6a:


    orushi "Vous serez le capitaine de l'équipe A..."


translate french suitecours_1a6f6865:


    s "Très bien Monsieur..."


translate french suitecours_c282e467:


    orushi "Etudiant Emerick..."


translate french suitecours_905cbf84:


    emerick "Oui Monsieur..."


translate french suitecours_59809014:


    orushi "Vous serez le capitaine de l'équipe B..."


translate french suitecours_19945eb9:


    orushi "Etudiante Madison..."


translate french suitecours_90670405:


    mad "Oui Monsieur..."


translate french suitecours_acf02fcb:


    orushi "Vous serez le capitaine de l'équipe H..."


translate french suitecours_c9f2c988:


    mad "D'accord..."


translate french suitecours_b31bba35:


    orushi "Maintenant que tous les capitaines ont été désignés, veuillez, s'il vous plaît, un par un et dans l'ordre mentionné auparavant, choisir un coéquipier..."


translate french suitecours_cbab976a:


    s "Okay... Alors je choisis Mac !"


translate french suitecours_e8b0f8fe:


    emerick "Je choisis Elizabeth !"


translate french suitecours_ebdc68c4:


    emerick "T'as réussi à le faire ?"


translate french suitecours_13736fe6:


    beth "Oui, normalement toutes les boules sans dans l'ordre... sauf les leurs..."


translate french suitecours_cfc2ff6b:


    ji "Je choisis Marc !"


translate french suitecours_170ae5c1:


    ji "Eden !"


translate french suitecours_d4bafbfa:


    ji "Luis !"


translate french suitecours_5aacc495:


    ji "Brandon !"


translate french suitecours_2b795fb9:


    ji "Emilia !"


translate french suitecours_37e3f6ae:


    mad "Je choisis [name] !"


translate french suitecours_355fdbbd:


    d "Wow ! Je pensais pas que tu me choisirais !"


translate french suitecours_eeebc711:


    mad "On a géré le premier test... Espérons qu'on fasse pareil sur le second..."


translate french suitecours_ed398876:


    s "Hector !"


translate french suitecours_75c8baf1:


    emerick "Sofia !"


translate french suitecours_ba6a93d7:


    mad "Grace !"


translate french suitecours_a5120c1c:


    s "Ben !"


translate french suitecours_c9eabda7:


    mad "Ruby !"


translate french suitecours_b6c17e44:


    mad "Julia !"


translate french suitecours_42b56b32:


    mad "Je choisis Grace !"


translate french suitecours_ed398876_1:


    s "Hector !"


translate french suitecours_75c8baf1_1:


    emerick "Sofia !"


translate french suitecours_c9eabda7_1:


    mad "Ruby !"


translate french suitecours_a5120c1c_1:


    s "Ben !"


translate french suitecours_b6c17e44_1:


    mad "Julia !"


translate french suitecours_b736ea3c:


    ruby "Madison ! Prends [name] !"


translate french suitecours_636a4cae:


    mad "T'es sûre ?"


translate french suitecours_8bb0774f:


    ruby "Evidemment !"


translate french suitecours_77f04cb3:


    mad "Okay... Je choisis [name] !"


translate french suitecours_5d37a177:


    d "Merci..."


translate french suitecours_1c7f72b8:


    mad "C'est Ruby qu'il faut remercier..."


translate french suitecours_4db55881:


    orushi "Très bien ! Maintenant que vos équipes ont été formées... Nous allons procéder à un tirage au sort..."


translate french suitecours_4bb9c3da:


    orushi "Vous êtes 10 équipes mais seulement 8 pourront participer à ce tournoi..."


translate french suitecours_3f9bd011:


    orushi "Sur les tables derrière vous, il y a des gobelets avec une balle à l'intérieur..."


translate french suitecours_3cb93f68:


    orushi "8 boules noires et 2 boules blanches..."


translate french suitecours_8aa9696e:


    orushi "Vous allez donc devoir passer chacun votre tour pour choisir un sac et montrer la boule que vous aurez choisi..."


translate french suitecours_9c47e601:


    orushi "N'importe qui de votre équipe peut aller choisir la boule..."


translate french suitecours_ec0627c7:


    orushi "Si vous avez une boule noire, vous êtes qualifiés ! Si vous avez une boule blanche, vous ne participerez pas à ce tournoi..."


translate french suitecours_f16f89f9:


    mad "Putain, je suis trop nulle à ça..."


translate french suitecours_584173a2:


    ruby "Comment ça ?"


translate french suitecours_494323f8:


    mad "Disons que la chance n'est pas vraiment de mon côté..."


translate french suitecours_1dbf4149:


    ruby "Ah... Ben... Pareil ici..."


translate french suitecours_c2c87464:


    d "Je peux le faire si tu veux..."


translate french suitecours_18ae2ed2:


    mad "Toi ?"


translate french suitecours_1856c7d4:


    d "Oui... Au pire, si on ne peut pas jouer... Tu pourras dire que c'est de ma faute !"


translate french suitecours_5fdbb2f6:


    mad "Hummm... Okay..."


translate french suitecours_f5e55f54:


    ruby "Attends... j'ai une idée..."


translate french suitecours_ab941b78:


    d "Comment ça ?"


translate french suitecours_1f45ebf6:


    ruby "On sera plus que trois équipes à la fin si je comprend bien l'ordre..."


translate french suitecours_6881b442:


    d "Heu... Ouais... On est l'équipe H donc... La 8ème équipe..."


translate french suitecours_5c99e476:


    ruby "Okay... On va voir comment vont se passer les tirages..."


translate french suitecours_4f781c37:


    emerick "Boule noire !"


translate french suitecours_d42d80c6:


    orushi "Equipe Qualifiée !"


translate french suitecours_b416f0d3:


    s "Boule noire !"


translate french suitecours_d42d80c6_1:


    orushi "Equipe qualifiée !"


translate french suitecours_3988fd6d:


    ji "Noire !"


translate french suitecours_d42d80c6_2:


    orushi "Qualifiée !"


translate french suitecours_3988fd6d_1:


    ji "Noire !"


translate french suitecours_d42d80c6_3:


    orushi "Qualifiée !"


translate french suitecours_3988fd6d_2:


    ji "Noire !"


translate french suitecours_d42d80c6_4:


    orushi "Qualifiée !"


translate french suitecours_3988fd6d_3:


    ji "Noire !"


translate french suitecours_d42d80c6_5:


    orushi "Qualifiée !"


translate french suitecours_3988fd6d_4:


    ji "Noire !"


translate french suitecours_d42d80c6_6:


    orushi "Qualifiée !"


translate french suitecours_a1d614f0:


    orushi "Sept équipes sont à présent qualifiées..."


translate french suitecours_5e014e97:


    orushi "Il ne reste qu'une boule noire parmi les trois derniers gobelets..."


translate french suitecours_11df4754:


    orushi "Equipe H, veuillez continuer..."


translate french suitecours_d3e412b3:


    ruby "Heu... Monsieur Orushi ?"


translate french suitecours_e494fdfd:


    orushi "Oui ?"


translate french suitecours_a932588e:


    ruby "Est ce qu'on pourrait laisser le joueur suivant tirer sa boule ? Nous voudrions leur laisser une chance de tirer une boule avant de tirer la notre... Sinon ils n'auront me^me pas eu le choix..."


translate french suitecours_7797984a:


    orushi "Hmmmm... Je ne vois pas de problèmes à cela..."


translate french suitecours_6a1566d3:


    emerick "Qu'est ce qu'elle mijote ?"


translate french suitecours_fe395a9a:


    d "Pourquoi t'as demandé ça ?"


translate french suitecours_142f5df4:


    ruby "Fais moi confiance !"


translate french suitecours_59837f76:


    ruby "Dis moi... Quelle boule t'aurais choisi ?"


translate french suitecours_51808edd:


    d "Je sais pas... De toute façon j'ai une chance sur trois de tomber sur la bonne !"


translate french suitecours_3a450a96:


    ruby "C'est le principe... 33 pour cent..."


translate french suitecours_72987282:


    d "Celle de gauche..."


translate french suitecours_30508101:


    d "Celle du milieu..."


translate french suitecours_578f2da0:


    d "Celle de droite..."


translate french suitecours_8c4cb72b:


    ji "Je choisis celle du milieu !"


translate french suitecours_7bcc50f4:


    d "Okay..."


translate french suitecours_170fc44d:


    ruby "Attends..."


translate french suitecours_5f484a7a:


    ji "Blanche..."


translate french suitecours_f8af79d9:


    ji "Je choisis celle de gauche !"


translate french suitecours_7bcc50f4_1:


    d "Okay..."


translate french suitecours_170fc44d_1:


    ruby "Attends..."


translate french suitecours_5f484a7a_1:


    ji "Blanche..."


translate french suitecours_f8af79d9_1:


    ji "Je choisis celle de gauche !"


translate french suitecours_7bcc50f4_2:


    d "Okay..."


translate french suitecours_170fc44d_2:


    ruby "Attends..."


translate french suitecours_5f484a7a_2:


    ji "Blanche..."


translate french suitecours_8fdce6a4:


    orushi "Equipe éliminée !"


translate french centerright_ee586e7e:


    mad "Oh mon dieu... J'aurais fait comme tout le monde et j'aurais pris celle de gauche dans l'ordre..."


translate french centerright_158bc8fd:


    grace "Ouais, j'aurais fait pareil..."


translate french centerright_7e9b8995:


    julia "Mais pourquoi t'as fait ça Ruby ?"


translate french centerright_ef6e87dc:


    ruby "Un pressentiment..."


translate french centerright_a3f17df4:


    d "Mais maintenant je fais quoi ? J'ai une chance sur deux de perdre !"


translate french centerright_072df15c:


    ruby "Non... C'est là que tu as tout faux !"


translate french centerright_dd5d68f3:


    d "Hein ?"


translate french centerright_c13ab685:


    ruby "Quand on a commencé, tu avais une chance sur trois d'avoir la boule noire dans celle que tu as choisi non ?"


translate french centerright_d1523116:


    d "Heu... ouais..."


translate french centerright_46b44aa9:


    ruby "Ben maintenant tu as deux chances sur trois qu'elle soit dans celle que tu n'as PAS choisi !"


translate french centerright_dd5d68f3_1:


    d "Hein ?"


translate french centerright_5625102b:


    ruby "Bon fais moi confiance et prends l'autre gobelet..."


translate french centerright_f4379931:


    d "C'est quoi ce délire ?"


translate french centerright_bf9a1fbc:


    d "Elle est complètement tarée..."


translate french centerright_59e62df4:


    d "Bon ben... On y va..."


translate french centerright_02be2d4e:


    orushi "Boule noire ! Equipe qualifiée !"


translate french centerright_85a51d50:


    d "Quoi ???"


translate french centerright_871f33af:


    ruby "Tu vois ! Je te l'avais dit !"


translate french centerright_f542d5d6:


    mad "T'es une malade !"


translate french centerright_a508db31:


    ruby "Mon intuition me trompe jamais... Merci d'avoir crû en moi !"


translate french lefttable_f31fcf7b:


    d "Mais maintenant je fais quoi ? J'ai une chance sur deux de perdre !"


translate french lefttable_072df15c:


    ruby "Non... C'est là que tu as tout faux !"


translate french lefttable_dd5d68f3:


    d "Hein ?"


translate french lefttable_c13ab685:


    ruby "Quand on a commencé, tu avais une chance sur trois d'avoir la boule noire dans celle que tu as choisi non ?"


translate french lefttable_d1523116:


    d "Heu... ouais..."


translate french lefttable_46b44aa9:


    ruby "Ben maintenant tu as deux chances sur trois qu'elle soit dans celle que tu n'as PAS choisi !"


translate french lefttable_dd5d68f3_1:


    d "Hein ?"


translate french lefttable_5625102b:


    ruby "Bon fais moi confiance et prends l'autre gobelet..."


translate french lefttable_f4379931:


    d "C'est quoi ce délire ?"


translate french lefttable_bf9a1fbc:


    d "Elle est complètement tarée..."


translate french lefttable_59e62df4:


    d "Bon ben... On y va..."


translate french lefttable_02be2d4e:


    orushi "Boule noire ! Equipe qualifiée !"


translate french lefttable_85a51d50:


    d "Quoi ???"


translate french lefttable_871f33af:


    ruby "Tu vois ! Je te l'avais dit !"


translate french lefttable_f542d5d6:


    mad "T'es une malade !"


translate french lefttable_a508db31:


    ruby "Mon intuition me trompe jamais... Merci d'avoir crû en moi !"


translate french resulttable_28601e80:


    orushi "Maintenant que toutes les équipes du tournoi ont été désignées, nous allons pouvoir commencer les premiers matchs..."


translate french resulttable_04d36dc5:


    orushi "Veuillez vous diriger vers les vestiaires pour récupérer vos maillots et vous préparer pour les matchs..."


translate french resulttable_e31635c3:


    mad "Okay, allez on y va !"

translate french strings:


    old "Left"
    new "Gauche"


    old "Center"
    new "Milieu"


    old "Right"
    new "Droite"




translate french suitecours_2cfb5c45:


    beth "Oui, normalement toutes les boules sont placées dans l'ordre... à l'exception des dernières... "


translate french suitecours_90146bcc:


    ji "Eden !"


translate french suitecours_daeb8dcf:


    ji "Luis !"


translate french suitecours_0f400b9e:


    ji "Brandon !"


translate french suitecours_b9695e43:


    ji "Emilia !"


translate french suitecours_035d09f5:


    orushi "Derrière vous, il y a des gobelets avec des balles cachées dessous..."


translate french suitecours_6ef0da47:


    orushi "Chacun d'entre vous va choisir tour à tour un gobelet et montrer la balle qu'il aura choisi..."


translate french suitecours_a647ab43:


    d "Oh ?"


translate french suitecours_e0d5187b:


    mad "Mouais... Okay..."


translate french suitecours_c8aa12cf:


    julia "C'est quoi ?"


translate french suitecours_52b03409:


    julia "Heu... Oui... On est l'équipe H... Donc la 8ème équipe..."


translate french suitecours_c320f17e:


    emerick "J'y vais en premier !"


translate french suitecours_09dd397c:


    dpense "Je vais faire confiance à Bleue..."


translate french suitecours_dac16296:


    d "Je vais prendre la dernière..."


translate french suitecours_0b442ff1:


    mad "Mon dieu ! [name] qu'est ce que tu fais ?"


translate french suitecours_58018565:


    d "J'en sais rien !"


translate french suitecours_4fa6cf9d:


    mad "Il est sérieux ?"


translate french suitecours_cf27c58a:


    dpense "Ca pourrait être un piège..."


translate french rusolve_d3e412b3:


    ruby "Monsieur Orushi ?"


translate french rusolve_e494fdfd:


    orushi "Oui ?"


translate french rusolve_a932588e:


    ruby "Est ce qu'on pourrait laisser le joueur suivant tirer sa boule avant nous ? Nous voudrions leur laisser une chance d'au moins tirer leur boule..."


translate french rusolve_28cfd01c:


    orushi "Hmmm... Comme Emerick est passé avant Steven... Je ne vois pas de problèmes à ça..."


translate french rusolve_6a1566d3:


    emerick "Qu'est ce qu'elle mijote ?"


translate french rusolve_fe395a9a:


    d "Pourquoi tu lui demande ça ?"


translate french rusolve_142f5df4:


    ruby "Fais moi confiance !"


translate french rusolve_59837f76:


    ruby "Dis moi... Quelle balle t'aurais choisi ?"


translate french rusolve_51808edd:


    d "Je ne sais pas... J'ai une chance sur trois de choisir la bonne !"


translate french rusolve_3a450a96:


    ruby "C'est le principe... 33 pour cent..."


translate french rusolve_72987282:


    d "Celle de gauche..."


translate french rusolve_30508101:


    d "Celle du milieu..."


translate french rusolve_578f2da0:


    d "Celle de droite..."


translate french rusolve_8c4cb72b:


    ji "Je choisis celle du milieu !"


translate french rusolve_7bcc50f4:


    d "Okay..."


translate french rusolve_170fc44d:


    ruby "Attends..."


translate french rusolve_5f484a7a:


    ji "Blanche..."


translate french rusolve_8fdce6a4:


    orushi "Equipe éliminée !"


translate french rusolve_f8af79d9:


    ji "Je vais choisir celle de gauche !"


translate french rusolve_7bcc50f4_1:


    d "Okay..."


translate french rusolve_170fc44d_1:


    ruby "Attends..."


translate french rusolve_5f484a7a_1:


    ji "Blanche..."


translate french rusolve_8fdce6a4_1:


    orushi "Equipe éliminée !"


translate french rusolve_f8af79d9_1:


    ji "Je vais choisir celle de gauche !"


translate french rusolve_7bcc50f4_2:


    d "Okay..."


translate french rusolve_170fc44d_2:


    ruby "Attends..."


translate french rusolve_5f484a7a_2:


    ji "Blanche..."


translate french rusolve_8fdce6a4_2:


    orushi "Equipe éliminée !"


translate french centerright_81959ae4:


    dpense "Je veux pas regarder..."


translate french lefttable_81959ae4:


    dpense "Je veux pas regarder..."


translate french bluesolve_3b040379:


    d "Et si elle avait tout faux ?"


translate french bluesolve_bf9a1fbc:


    d "Elle est complètement dingue..."


translate french bluesolve_59e62df4:


    d "Bon ben... On y va..."


translate french bluesolve_81959ae4:


    dpense "J'ai pas envie de regarder..."


translate french bluesolve_02be2d4e:


    orushi "Boule noire ! Equipe qualifiée !"


translate french bluesolve_85a51d50:


    d "Quoi ???"


translate french bluesolve_f542d5d6:


    mad "T'es malade !"


translate french resulttable_af173a75:


    orushi "Les matchs auront lieu ainsi :"


translate french resulttable_ae065467:


    orushi "Equipe A contre Equipe C"


translate french resulttable_6f7c934f:


    orushi "Equipe B contre Equipe E"


translate french resulttable_d0f1a017:


    orushi "Equipe D contre Equipe H"


translate french resulttable_da9dba80:


    orushi "Equipe F contre Equipe G"


translate french resulttable_ac7ab3c8:


    mad "Okay ! Allez on y va !"

translate french strings:


    old "Take the last one !!!"
    new "Prends la dernière !"


    old "What ?"
    new "De quoi ?"


    old "Do as I say if you want to continue !!!"
    new "Fais ce que je te dis si tu veux continuer !!!"


    old "Trust Blue"
    new "Croire en Bleue"


    old "Do not trust Blue"
    new "Ne pas croire en Bleue"


    old "Thank you!!!"
    new "Merci !!!"


    old "You owe me one..."
    new "Tu m'en dois une..."



translate french strings:


    old "Sit with Madison and Ruby [TEMP1]"
    new "S'asseoir avec Madison et Ruby [TEMP1]"


    old "Sit with Grace and Julia [TEMP2]"
    new "S'asseoir avec Grace et Julia [TEMP2]"


    old "Sit with the twins [TEMP3]"
    new "S'asseoir avec les jumelles [TEMP3]"


    old "Trust Blue [TEMP1]"
    new "Croire Bleue [TEMP1]"


    old "Do not trust Blue [TEMP2]"
    new "Ne pas croire Blue [TEMP2]"



translate french strings:


    old "Sit with Madison and Ruby [TEMP1!t]"
    new "S'asseoir avec Madison et Ruby [TEMP1!t]"


    old "Sit with Grace and Julia [TEMP2!t]"
    new "S'asseoir avec Grace et Julia [TEMP2!t]"


    old "Sit with the twins [TEMP3!t]"
    new "S'asseoir avec les jumelles [TEMP3!t]"


    old "Trust Blue [TEMP1!t]"
    new "Croire Bleue [TEMP1!t]"


    old "Do not trust Blue [TEMP2!t]"
    new "Ne pas croire Bleue [TEMP2!t]"




translate french madiruby_cb5052fe:


    d "Je peux m'asseoir avec vous ?"


translate french gracejulia_cb5052fe:


    d "Je peux m'asseoir avec vous ?"


translate french sittwins_bfce7842:


    d "Je peux m'asseoir avec vous ?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
