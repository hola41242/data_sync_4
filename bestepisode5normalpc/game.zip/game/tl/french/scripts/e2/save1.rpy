


translate french save1_285f8ea7:


    "Veuillez sauvegarder..."

translate french strings:


    old "SAVE NOW"
    new "Veuillez sauvegarder..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
