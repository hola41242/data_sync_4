


translate french e2s1_03ecf3cb:


    dpense "Putain... Quelle journée !"


translate french e2s1_e3368f91:


    dpense "C'est incroyable quand même... Cette compétition qui provient de nulle part, toutes ces filles, c'était mon premier jour et j'ai même pas eu cours..."


translate french e2s1_981aa673:


    dpense "Mais ça m'a tué... Et je dois encore nettoyer tout ce bazar !"


translate french e2s1_a576b045:


    dpense "Mon téléphone ! Bon... Je n'ai pas encore de contacts ici... Va falloir que je demande aux filles leurs numéros..."


translate french e2s1_d23f0865:


    dpense "Okay... Allons y !"


translate french e2s1_dc56d181:


    d "♫ Here we are. Born to be kings. ♫"


translate french e2s1_aa37498f:


    d "♫ We're the princes of the universe. ♫"


translate french e2s1_67afc8cc:


    d "♫ I am immortal. I have inside me blood of kings. ♫"


translate french e2s1_070855b5:


    d "♫ I have no rival. No man can be my equal. ♫"


translate french e2s1_14aa314d:


    d "♫ Take me to the future of your world. ♫"


translate french e2s1_ab629bc0:


    ruby "Quel spectacle ! Je dois t'appeler Duncan Mac Leod maintenant ?"


translate french e2s1_2f797be5:


    d "Na..."


translate french e2s1_fa027d45:


    ruby "On verra ! Allez, prends tes affaires, les autres nous attendent..."


translate french e2s1_b2842d1b:


    d "Euh... Ouais okay..."


translate french e2s1_50747cac:


    ruby "Oh ? Tu as un téléphone ?"


translate french e2s1_b3a81635:


    d "Euh, ouais... Ben, je n'ai pas encore de contacts vu que je ne connais personne mais... oui... j'ai un téléphone..."


translate french e2s1_d2c08699:


    ruby "Cool !!! Attends, laisse moi t'envoyer mon contact par scan !"


translate french e2s1_44b10ff2:


    d "Euh... ouais okay !"


translate french e2s1_054790de:


    ruby "Bon... On verra tout à l'heure si ça marche !"


translate french e2s1_da01005d:


    ruby "Allez, allons rejoindre les autres !"


translate french e2s1_c71a801b:


    d "J'arrive..."


translate french e2s1_a7ca42d3:


    emerick "Vous m'avez appelé mon Oncle ?"


translate french e2s1_bec82cb9:


    orushi "Oui... J'ai vu les résultats de la première épreuve..."


translate french e2s1_474b3cf8:


    orushi "Tu t'en es bien sorti..."


translate french e2s1_0de5a8e8:


    emerick "Evidemment ! Je n'allais pas laisser ce tas de losers me battre !"


translate french e2s1_fa66421e:


    orushi "Assez !"


translate french e2s1_b14aabed:


    rufus "FSHHHHHHHHHHHHHH"


translate french e2s1_d933fc72:


    orushi "Je sais qu'une de tes vipères est passée avant sur le terrain pour préparer ton sac, histoire que t'aies juste à courir et le prendre..."


translate french e2s1_24ab3896:


    orushi "Tu as de la chance que la tigresse était trop occupée à chercher le sien !"


translate french e2s1_2aaf9bb0:


    orushi "La prochaine fois, je ne laisserai pas passer !"


translate french e2s1_cf4435e1:


    emerick "Oui mon Oncle..."


translate french e2s1_35a7916f:


    orushi "Et ce Français ? Il n'a pas été mauvais..."


translate french e2s1_9512b329:


    emerick "C'est juste un faible comparé à moi..."


translate french e2s1_76552bd6:


    orushi "Faible ou pas, tu devrais te méfier de lui..."


translate french e2s1_cd9cde25:


    emerick "Je vais m'en occuper..."


translate french e2s1_e51d9fe2:


    orushi "Tu ferais mieux de gagner le tournoi qui arrive..."


translate french e2s1_6d3040d9:


    emerick "C'est comme si c'était fait..."


translate french e2s1_af86760f:


    ruby "Bon... Il ne manque plus que Madison... Elle sera là bientôt..."


translate french e2s1_7cc5e482:


    julia "C'est pas grave si elle ne vient pas tu sais !"


translate french e2s1_f02b1c50:


    grace "Julia ! Allez, laisse la tranquille ! Elle est super occupée avec sa fille ! Tu sais que c'est difficile pour elle de devoir tout organiser !"


translate french e2s1_7ee5c516:


    grace "Et en plus de ça, son frère enchaîne conneries sur conneries..."


translate french e2s1_f12f82c3:


    grace "Et ses parents qui sont toujours en train de lui demander des choses... J'ai le même problème avec ma mère... "


translate french e2s1_d579fcfd:


    grace "Toujours à me dire : Grace ne fais pas ça ! Grace, tu es la Capitaine ! Tu dois montrer l'exemple !"


translate french e2s1_19e030da:


    grace "Grace, tu dois avoir les meilleures notes ! Grace, Grace, Grace..."


translate french e2s1_69d97443:


    julia "Ca doit être difficile pour toi de gérer tout ça..."


translate french e2s1_c35ce243:


    grace "Nah !!! Tant que j'ai l'équipe, vous les filles, et quelque chose pour m'échapper un petit peu de tout ça... c'est cool !"


translate french e2s1_a2e2acaf:


    grace "D'ailleurs, j'ai ramené un petit vin français... Vous m'en direz des nouvelles !!!"


translate french e2s1_b47d10ff:


    ruby "Nan mais t'es folle ? On est sur le campus !!!"


translate french e2s1_e8410113:


    grace "Oh... Allez Ruby ! Fais pas ta rabat-joie !!!!"


translate french e2s1_93b521a5:


    ruby "Sérieusement Grace... Si tu veux boire... vas y... mais pas ici..."


translate french e2s1_7ef21552:


    grace "T'en penses quoi [name] ?"


translate french e2s1_669f4ba0:


    d "Tu ne devrais pas boire ici... Ca pourrait causer des soucis..."


translate french e2s1_6eba75e1:


    grace "Okay... Je la range alors..."


translate french e2s1_a933aa2c:


    d "Je ne suis pas vraiment fan de femmes qui boivent pour être honnête..."


translate french e2s1_da6e5f6a:


    grace "Ouais... je suppose que c'est pas sexy... Okay... On se voit ce soir petite bouteille..."


translate french e2s1_639b4fca:


    d "Tu sais que c'est pas bon pour ton corps et pour tes performances ?"


translate french e2s1_83df6de2:


    grace "Haha ! On dirait mon coach ! Okay, bye bye vin de vignoble... Bonjour boisson protéinée !!!"


translate french e2s1_ed8c99c0:


    d "J'ai pas à te dire quoi faire... Mais parfois ça fait du bien de relâcher la pression !"


translate french e2s1_2d9406be:


    grace "Voilà enfin quelqu'un qui comprend comment fonctionne ce monde ! Mais Ruby a raison... Je ne devrais pas garder cette bouteille ici..."


translate french e2s1_5a82890d:


    d "Qui est-ce...."


translate french e2s1_1bb364fc:


    dpense "Ah ouais... C'est pas la même sans sa queue de cheval.... Whaaaa !"


translate french e2s1_deca88bf:


    mad "Pourquoi vous me regardez comme ça ? J'ai un truc sur mon ensemble ?"


translate french e2s1_814d7bc9:


    grace "Non !!! Tu es magnifique Maddie... Je ne comprends pas pourquoi tu es toujours célibataire..."


translate french e2s1_d4a4d528:


    mad "Parlez pour vous les filles ! J'ai un enfant à m'occuper, une famille à éviter et des compétitions à gagner..."


translate french e2s1_21e11beb:


    mad "Y'à plus de place pour personne... Et de toute façon, à cet âge je ne pense pas que les gars auraient envie de s'occuper de tous ces problèmes... N'est ce pas [name] ?"


translate french e2s1_b6cd12ff:


    d "Si tu as besoin d'aide, on peut aussi t'aider à gérer tout ça tu sais... Tu n'es pas seule !"


translate french e2s1_53066af2:


    mad "C'est gentil..."


translate french e2s1_694d95bd:


    ruby "Evidemment qu'il est gentil ! Tu pensais quoi ?"


translate french e2s1_9d81cd20:


    mad "Je ne sais pas..."


translate french e2s1_a114d9b6:


    d "Si tu veux des conseils en quoi que ce soit, je suis disponible..."


translate french e2s1_378658d6:


    mad "Parce que tu t'y connais en éducation de jeunes enfants ?"


translate french e2s1_340fa348:


    mad "Ou en crise de la quarantaine chez des parents assoiffés de pouvoir et de richesse ?"


translate french e2s1_7bc8a915:


    ruby "Hey ! Il t'a pas attaqué !"


translate french e2s1_dbd14366:


    mad "Oui, je sais... Pardonne-moi [name]..."


translate french e2s1_71f3cdde:


    d "On doit se concentrer sur la compétition, le reste ne doit pas nous impacter."


translate french e2s1_9bb66f10:


    mad "Tu as raison... le B.E.S.T... L'équipe... C'est ce qui est important..."


translate french e2s1_5865f53d:


    ruby "Et si tout ne se passe pas bien, on est là pour te soutenir tu sais ! Je suis là pour toi !"


translate french e2s1_30bbab5f:


    mad "Tite Ruby... Je sais que tu es là quand j'en ai besoin..."


translate french e2s1_f1baba71:


    d "J'aurais aucun problème à gérer tout ça..."


translate french e2s1_f5eabbd4:


    d "Après tout, si tu veux être avec quelqu'un, tu prends tout ce qui fait de la personne celle qu'elle est !"


translate french e2s1_b0cb56e3:


    mad "Hmmm... Tu parais sûr de toi... Je me demande comment tu ferais pour gérer tout ça..."


translate french e2s1_9aba7878:


    d "Tu ne peux pas savoir tant que tu n'as pas essayé."


translate french e2s1_c7579901:


    mad "C'est vrai..."


translate french e2s1_dc5b375f:


    ruby "C'est quand même fou tout ce qui nous arrive !"


translate french e2s1_68ae02f5:


    julia "Qu'est ce que tu racontes ?"


translate french e2s1_4acc53b4:


    ruby "Ben... Je sais pas pour vous, mais j'ai l'impression qu'on est en train de vivre quelque chose de spécial..."


translate french e2s1_73fda96c:


    ruby "Comme si on faisait partie de quelque chose de gros... Avec des histoires, des confrontations... Des tests..."


translate french e2s1_9e26ec3f:


    ruby "Même notre rencontre avec [name] est spéciale ! On le rencontre dans un avion et il finit par être un de mes voisins de chambre, il a dormi sa première nuit chez Grace..."


translate french e2s1_61df0e42:


    ruby "Il a passé le premier test B.E.S.T avec [chosen] et il aurait pu gagner ! On dirait que nous avons affaire à un héros de visual novel !"


translate french e2s1_d3bb40de:


    julia "Un quoi ?"


translate french e2s1_6541b6d1:


    ruby "Un héros de visual novel !"


translate french e2s1_85ec0c6b:


    grace "Hein ?"


translate french e2s1_9b5f314f:


    ruby "Un héros de VI-SU-AL NO-VEL !"


translate french e2s1_6e7805f2:


    mad "Un ?"


translate french e2s1_8805bde7:


    ruby "Visual Novel ! Une aventure dont vous êtes le héros !"


translate french e2s1_c1835389:


    d "AH ! Un Visoual Nouvel !"


translate french e2s1_e9754cba:


    ruby "..."


translate french e2s1_2fef4c63:


    ruby "Ouais... Bon... peut être un Visual Novel pour adulte en fait..."


translate french e2s1_2736e21d:


    d "C'est quoi exactement un Visual Novel pour adulte ?"


translate french e2s1_262a0855:


    ruby "Oh mon dieu... Vous y connaissez vraiment rien ?"


translate french e2s1_6443aa2f:


    mad "Ben vas y ! Explique !"


translate french e2s1_5f285438:


    ruby "Okay !!!"


translate french e2s1_cfb4ca65:


    ruby "Un visual novel est un jeu où vous faites des choix pour influencer l'histoire..."


translate french e2s1_60191ee4:


    ruby "Comme choisir d'aller à gauche..."


translate french e2s1_d15659ac:


    ruby "Ou à droite... Et chaque choix crée une branche qui peut emmener l'histoire dans une direction..."


translate french e2s1_da182dc0:


    ruby "Ou dans une autre !"


translate french e2s1_f491c4c0:


    ruby "A ne pas confondre avec un Kinetic Novel qui est une ligne droite en terme de récit. En gros, avec un Kinetic, vous suivez une aventure..."


translate french e2s1_ff85cb50:


    ruby "Avec un Visual Novel, vous êtes acteur de l'aventure et vous décidez de ce que vous faites à chaque choix offert !"


translate french e2s1_e49487a4:


    ruby "Et dans les Visual Novels pour adultes, Il y a des choses qui sont plus..."


translate french e2s1_ce194798:


    ruby "Sexy..."


translate french e2s1_4f9373b1:


    ruby "Et des sujets qui sont un peu plus difficiles à traiter comme l'alcoolisme... les addictions... les questions sur la sexualité..."


translate french e2s1_8222f50e:


    ruby "Des fois même des sujets plus sensibles... Mais je vais pas entrer dans plus de détails !!!"


translate french e2s1_311c7ed2:


    ruby "Il y a 7 règles à suivre dans un Visual Novel pour adultes !"


translate french e2s1_81b67b85:


    d "Tu veux dire quoi par 7 règles à suivre ?"


translate french e2s1_e0e442a8:


    ruby "Ben, en fait, y'en a peut être plus... Mais j'aime bien le chiffre 7... Et puis de toute façon c'est moi qui explique donc c'est moi qui décide !"


translate french e2s1_012699c5:


    ruby "Règle N°1 : Le héros doit être charismatique ! Il doit avoir du caractère ! Il ne doit pas être un paillasson devant tout le monde et dire amen à tout..."


translate french e2s1_69f1461a:


    ruby "Ca ressemble bien à [name] non ?"


translate french e2s1_e80efef1:


    mad "Pourquoi ce serait lui le héros ? Ca ne pourrait pas être une fille ?"


translate french e2s1_b9868f46:


    julia "Ouais c'est vrai ça ! Pourquoi le héros est toujours un garçon ?"


translate french e2s1_2942cb63:


    ruby "C'est pas toujours le cas ! Je connais plein de jeux où le héros est en fait une héroïne..."


translate french e2s1_8cadab8e:


    ruby "Mais comme on est dans le jeu pour adultes, la majorité des joueurs sont... des hommes..."


translate french e2s1_9d1ff317:


    mad "Ca n'explique pas pourquoi c'est [name] le héros de ton histoire..."


translate french e2s1_567e0472:


    ruby "Maddie..."


translate french e2s1_9ea61dc5:


    mad "Okay j'arrête... Continue !"


translate french e2s1_b8d61786:


    ruby "Règle n°2 : Le héros doit avoir des Lis qu'il doit essayer de séduire, comme le joueur qui va s'attacher à elles."


translate french e2s1_f2334755:


    julia "Des Lis ?"


translate french e2s1_5850cbe3:


    ruby "Li... Love Interest ! En gros des conquêtes !!!!"


translate french e2s1_041b7546:


    grace "Et comment elles savent que ce sont des Lis ?"


translate french e2s1_5eab819b:


    ruby "Elles le savent pas ! Elles rencontrent le héros naturellement ! Comme on a rencontré [name] dans l'avion !"


translate french e2s1_386f66a6:


    grace "Donc, chaque fille que le héros rencontre devient une Li ?"


translate french e2s1_004af490:


    ruby "Nan !!!! Et j'ai pas dit que ça doit être exclusivement des filles ! Y'à des jeux où le héros est gay... ou autres..."


translate french e2s1_d772cdb6:


    ruby "Mais ici, par exemple, [name] a rencontré plein de personnes depuis qu'il est là !"


translate french e2s1_e2297a88:


    ruby "Peut être qu'il a déjà créé des connexions avec certaines d'entre elles ! Et d'autres peuvent peut être devenir des 'optionnelles'..."


translate french e2s1_5a63cb46:


    ruby "Comme une jumelle dans le vestiaire..."


translate french e2s1_505f342d:


    julia "Hein ?"


translate french e2s1_e1cf0ec0:


    mad "Ouais... ou une autre sous une douche..."


translate french e2s1_505f342d_1:


    julia "Quoi ?"


translate french e2s1_a4ae5c62:


    grace "[name], qui serait celle qui te plairait le plus parmi les filles que tu as rencontrées ?"


translate french e2s1_b0acae04:


    chosen "Oh, c'est mignon !!! Tiens tu mérites un bisou."


translate french e2s1_29561989:


    ruby "Bon, c'est bien beau tout ça, mais passons maintenant à la règle n°3 !"


translate french e2s1_8b5643a9:


    ruby "Les lis peuvent avoir un passé, mais c'est bien mieux si elles sont encore vierges !"


translate french e2s1_fb631fdc:


    mad "Quoi ???"


translate french e2s1_370788c5:


    ruby "Oui... Bon toi evidemment, on ne peut pas dire que tu l'es.... Tu as une fille, donc..."


translate french e2s1_134961cf:


    mad "Donc je ne peux pas être une Li ?"


translate french e2s1_7e7e2e62:


    ruby "Tu voulais en être une ?"


translate french e2s1_bc824b1a:


    mad "Non mais tu m'as vue ? Si j'étais dans ce genre de jeu, je ne me contenterais pas d'être une 'optionnelle' !"


translate french e2s1_f653a44a:


    grace "Hahaha ! "


translate french e2s1_8af8bebb:


    ruby "Nan mais c'est pas parce que tu n'es pas vierge que tu ne peux pas être une Li ! C'est juste que les joueurs préfèrent avoir une fille qui est 'pure' à une autre qui aurait déjà été voir ailleurs..."


translate french e2s1_c7db646b:


    mad "C'est ridicule... J'aime pas ton jeu..."


translate french e2s1_99cbf7ae:


    ruby "Par exemple, on s'en sort pas si mal ici ! [name] aurait 4 filles dont 3 vierges !"


translate french e2s1_42486048:


    julia "Okay Ruby... Pas obligée de nous le rappeler !"


translate french e2s1_36cccf90:


    grace "Ouais... Je me demande des fois si je devrais pas être plus 'ouverte'....."


translate french e2s1_aede0390:


    ruby "C'est pas grave les filles ! C'est même mieux pour les joueurs... Et au moins on ne sera pas embêtées avec la 4ème règle !"


translate french e2s1_bdfd47df:


    mad "Et c'est quoi ce coup-ci ? Pas le droit d'avoir d'enfants ?"


translate french e2s1_894769a1:


    ruby "Non !!!"


translate french e2s1_dc87ca03:


    ruby "La 4ème règle est : pas de TMI !!!!"


translate french e2s1_29ac5843:


    d "De quoi ?"


translate french e2s1_ce2d5e47:


    ruby "TMI ! Too Much Information ! Trop de passé tue le présent !"


translate french e2s1_6d3dab99:


    grace "Je comprends pas..."


translate french e2s1_24160dd1:


    ruby "En gros, le joueur qui joue à ce jeu... Il veut pas savoir combien de gars tu as embrassé..."


translate french e2s1_c5257780:


    ruby "Ou plus... Avant de le rencontrer... Ca ne l'intéresse pas ! C'est comme dire : Oh wow ! La tienne est plus grosse que celle d'Edouard !"


translate french e2s1_8258fe0c:


    ruby "On s'en fout ! Ou pire ! Entendre... J'ai eu 100 gars... Mais t'es le meilleur coup que j'ai eu..."


translate french e2s1_ce93967e:


    ruby "A part passer pour une catin... Ca n'ajoute rien au jeu pour le joueur à part un certain ressentiment envers la fille !"


translate french e2s1_392c2d22:


    ruby "Des fois ça va même jusqu'à ce que le joueur quitte le jeu parce qu'il ne supporte pas ce genre de propos !!! Donc... pas de TMI, pas de problèmes !"


translate french e2s1_5ce70a32:


    mad "Mais j'ai le droit d'avoir une vie quand même dans ton truc ?"


translate french e2s1_4b1161c1:


    ruby "Ben oui ! Mais ta romance avec le héros ne doit pas être parasitée avec un ancien petit ami ou quelque chose d'autre !"


translate french e2s1_24515339:


    ruby "Après tout, dans la vraie vie, personne ne veut être comparé à quelqu'un d'autre pendant une relation ou pendant un acte sexuel... Alors dans un jeu..."


translate french e2s1_16d76ed1:


    julia "Mouais... Au moins c'est plus facile quand on est vierges !"


translate french e2s1_f48f8f08:


    ruby "Oui mais tu dois pas dire des trucs styles 'Oh, j'ai déjà embrassé des gars avant toi... mais avec toi c'est différent !"


translate french e2s1_a9acb29d:


    julia "Euh.... Ben de toute façon j'ai pas fait ça non plus !"


translate french e2s1_188cc25b:


    ruby "Allez, la 5ème règle !!!"


translate french e2s1_939fccd4:


    d "On dirait qu'on donne naissance à un Gremlin... Ne pas donner à manger après minuit... Ne pas mettre dans l'eau... Ne pas exposer au soleil..."


translate french e2s1_a29cc547:


    ruby "Oh !!! Tu connais les Gremlins ? C'est un film fait par Steven Spielberg !!! Tu savais que..."


translate french e2s1_8209f242:


    d "Ruby !!!"


translate french e2s1_c1826e34:


    ruby "Oui pardon... Okay alors la 5ème règle : Il faut une Milf !"


translate french e2s1_5eefb60e:


    grace "Ahahahahahah! Maddie, celle là est pour toi !"


translate french e2s1_dea17346:


    mad "Je ne suis pas une Milf !"


translate french e2s1_a393b1dd:


    julia "Techniquement... si !"


translate french e2s1_e593a657:


    mad "Mais arrêtez ! J'ai 22 ans ! Je suis pas une Milf... Gabriella en est une si vous voulez !"


translate french e2s1_a6936512:


    grace "La prof ?"


translate french e2s1_b01b9536:


    mad "Ouais !"


translate french e2s1_e453b0a8:


    d "Je la connais pas !"


translate french e2s1_3377260b:


    ruby "Oh t'inquiètes, tu vas la rencontrer demain !!!"


translate french e2s1_4035bba9:


    mad "Et donc elle doit être comment ta Milf ?"


translate french e2s1_d6b663b2:


    ruby "C'est mieux si elle est négligée par son mari... Qu'elle n'a pas été touchée depuis longtemps..."


translate french e2s1_afde39b0:


    ruby "C'est un peu une âme perdue que le héros va secourir..."


translate french e2s1_30d62a1a:


    grace "Et [name] va sauver Gabriella ? Je veux dire, elle pourrait entrer dans cette catégorie, mais je vois pas [name] avec une femme de 35 ans !"


translate french e2s1_1df83774:


    grace "Je te l'avais dit !"


translate french e2s1_8ca883d5:


    julia "C'est joliment dit... C'est romantique !"


translate french e2s1_4dcee382:


    mad "Me regarde pas quand tu dis ça !!!"


translate french e2s1_daafaac8:


    ruby "Bref, il faut une Milf... Parce que ça crée de nouvelles dynamiques avec le joueur, souvent avec quelques tabous et d'autres choses qui titillent leur imagination..."


translate french e2s1_2a5dc559:


    mad "Bah... en même temps, l'imagination des gars est principalement située juste en dessous de la ceinture..."


translate french e2s1_9745ddfe:


    ruby "Ce qui nous emmène à la règle pénultième : Tous les fétichismes ne sont pas pour tout le monde !"


translate french e2s1_18ee35c4:


    grace "Fétichismes ?"


translate french e2s1_c1d261d7:


    ruby "Oui..."


translate french e2s1_c8aa12cf:


    julia "Qui sont ?"


translate french e2s1_d38a2ee3:


    ruby "Hum... Par exemple, il y a des joueurs qui sont fétichistes des pieds... Ils adorent les scènes où il y a des pieds, des bas etc..."


translate french e2s1_c735661d:


    ruby "D'autres aiment le BDSM... D'autres ne supportent pas les scènes lesbiennes... Et ne me démarrez pas sur le NTR !"


translate french e2s1_305242eb:


    d "le NTR ?"


translate french e2s1_29470446:


    ruby "Oui, le NTR... ça vient du japonais netorare... C'est globalement le principe de pouvoir tromper ou être trompé dans un jeu..."


translate french e2s1_4f6772e8:


    ruby "Certains aiment ça... D'autres le détestent... Cela crée des conflits entre deux teams qui argumentent sur ce qui leur paraît le mieux pour eux..."


translate french e2s1_334f2a21:


    ruby "Donc pour éviter ça : Tout ce qui est lié à une opinion personnelle ou à un fétichisme précis lié à la personnalité du joueur doit être OPTIONNEL !"


translate french e2s1_a548b7ad:


    grace "Je vois vraiment pas comment tu peux faire ça du coup..."


translate french e2s1_2bc88dcb:


    ruby "Euh... Okay, un exemple ! Grace, lève toi !"


translate french e2s1_a3493863:


    grace "Okay !"


translate french e2s1_ecde9d6a:


    ruby "Maintenant embrasse moi !"


translate french e2s1_0dafd5f9:


    grace "Hein ???"


translate french e2s1_01eb2f6a:


    ruby "Allez embrase moi ! Juste un petit bisou !"


translate french e2s1_ef85cac4:


    grace "Euh, si tu veux, mais je vois pas en quoi ça montre l'exemple !"


translate french e2s1_ef037255:


    ruby "Stop !"


translate french e2s1_38c5cdf2:


    ruby "[name], est ce que tu veux nous voir nous embrasser ?"


translate french e2s1_e80a0892:


    mad "Evidemment qu'il dit oui... Deux filles qui s'embrassent et il est dûr comme pierre en deux secondes !"


translate french e2s1_def43184:


    ruby "Pas mal..."


translate french e2s1_6a4f23ef:


    grace "Ouais..."


translate french e2s1_d60a073d:


    ruby "Tu vois, on lui a laissé le choix ! C'est le principe. S'il ne voulait pas nous voir nous embrasser, il aurait dit non et on ne l'aurait pas fait !"


translate french e2s1_b79a1c45:


    ruby "Tu vois, on lui a laissé le choix ! C'est le principe. S'il ne voulait pas nous voir nous embrasser, il aurait dit oui et on l'aurait fait !"


translate french e2s1_841cf19e:


    ruby "Mais au moins on respecte ce qu'il aime et ce qu'il a envie de voir !"


translate french e2s1_b6788b9d:


    grace "Okay maintenant je comprends mieux !"


translate french e2s1_b4359a05:


    ruby "Et enfin, la dernière règle ! La plus importante de toute !"


translate french e2s1_45f140c1:


    mad "Je parie que ça va être : Du sexe, partout, tout le temps, avec tout le monde !"


translate french e2s1_e1aa72bf:


    grace "Nan moi je dirais que les filles doivent avoir des seins énormes, un cul ultra rebondi et des lèvres bien pulpeuses...."


translate french e2s1_cd7a880b:


    julia "Ou alors il faut qu'il y ait des dramas ! Des trucs qui font peur, des trucs qui créent de l'émotion..."


translate french e2s1_9f40f626:


    ruby "POOOOOOOOOOOOOTTTTTTTTTT... Vous êtes le maillon faible.... Au revoir !"


translate french e2s1_dd5d68f3:


    d "Hein ?"


translate french e2s1_d5ab8d28:


    ruby "Le sexe devrait être intégré à l'histoire... Et non l'inverse !"


translate french e2s1_2c3a63c7:


    d "Qu'est ce que tu veux dire ?"


translate french e2s1_1a514c11:


    ruby "En gros... L'histoire doit venir en premier. Le sexe ne doit être qu'un des aspects du jeu et ne doit pas en être l'élément principal."


translate french e2s1_476ab487:


    ruby "Sinon, ben tout le reste devient inutile..."


translate french e2s1_e3c56ed3:


    ruby "Dans ce cas, tu peux faire un jeu où le héros est amnésique, il va dans une maison avec sa tante/voisine/propriétaire (rayez la mention inutile), il va voir 2-3-4 filles dedans..."


translate french e2s1_e8625ea9:


    ruby "Et voilà il a un harem sans quitter la maison avec des scènes de sexe toutes les 5 secondes et aucune histoire en dehors..."


translate french e2s1_a9cca5de:


    ruby "C'est sûr que c'est cool pour le joueur fast-food qui joue ça en vitesse ! Mais pour quelqu'un qui aime les histoires c'est repoussant."


translate french e2s1_705eeb93:


    ruby "Le héros devient une machine à baiser sans sentiments et les filles sont juste de la viande..."


translate french e2s1_9d7730bf:


    ruby "En bref, on peut résumer cette règle par : Les joueurs ne veulent pas de réalisme... Ils veulent de la magie !"


translate french e2s1_28d95fb6:


    julia "Oh..."


translate french e2s1_a8699778:


    d "Ah ouais bien !"


translate french e2s1_d3559afb:


    ruby "Mais bon tout ça était juste dans le cas hypothétique où nous serions dans un Visual Novel !"


translate french e2s1_1e5dfb0e:


    mad "Ouais, parce que [name] en tant que héros et moi en tant que Milf..."


translate french e2s1_44699cd8:


    grace "Elle peut pas passer à travers ce truc de la Milf hein !"


translate french e2s1_c02f63b0:


    julia "Bon les filles c'est pas tout ça, j'aurais adoré rester avec vous discuter mais je dois aller à la bibliothèque chercher mes livres..."


translate french e2s1_b8c86f42:


    grace "Moi faut que j'aille à la piscine..."


translate french e2s1_dd120e78:


    d "Julia..."


translate french e2s1_3fb1de81:


    julia "Oui ?"


translate french e2s1_df802e86:


    d "Tu m'avais dit que tu me ferais faire le tour du campus... Il te reste un peu de temps ? "


translate french e2s1_9d3ba8d3:


    julia "Oh, ben viens avec moi ! Je vais te montrer tout ce qu'il y a à voir sur le chemin de la bibliothèque !"


translate french e2s1_34c55b1f:


    d "Merci beaucoup..."


translate french e2s1_3fcacb3d:


    julia "On se voit plus tard les filles !"


translate french e2s1_8f1df40c:


    grace "A plus tard ! Amusez-vous bien et [name]... N'essaye pas trop de la draguer !"


translate french e2s1_c4897051:


    grace "C'est pas parce que tu es le héros et qu'elle est vierge que tu dois lui sauter dessus !"


translate french e2s1_ef579692:


    julia "Grace..."


translate french e2s1_38715887:


    grace "Je ne suis plus là !!!!"


translate french e2s1_3896858a:


    julia "Hum... Tu as un téléphone ?"


translate french e2s1_bc68d24d:


    d "Oui, je viens tout juste de le sortir de mon sac..."


translate french e2s1_8121b812:


    julia "Laisse moi t'ajouter !"


translate french e2s1_ce7133ef:


    julia "Okay... Allons y !"

translate french strings:


    old "EPISODE 2 {p} \n Double Trouble"
    new "EPISODE 2 {p} \n Double Trouble"


    old "NEW CONTACT ADDED"
    new "NOUVEAU CONTACT AJOUTE"


    old "Buddy"
    new "Buddy"


    old "Education"
    new "Education"


    old "Sport"
    new "Sport"


    old "Temperament"
    new "Temperament"


    old "Ruby"
    new "Ruby"


    old "Grace"
    new "Grace"


    old "Madison"
    new "Madison"


    old "Julia"
    new "Julia"


    old "KISS"
    new "KISS"


    old "I'm not a fan of older women."
    new "Je suis pas fan des femmes plus âgées..."


    old "Age has nothing to do with feelings."
    new "L'âge n'a rien à voir avec les sentiments..."


    old "Milfs are life!"
    new "Les Milfs c'est la vie !"


    old "Yes, definitely!"
    new "Ben oui évidemment !"


    old "No, I don't like it."
    new "Non ! Je n'aime pas ça !"




translate french e2s1_845373f5:


    grace "Hey toi ! Est ce que tu aimes le jeu ?"


translate french e2s1_5ef163dd:


    grace "Génial ! Est ce que tu pourrais nous aider en ajoutant le jeu à ta wishlist sur STEAM ? "


translate french e2s1_faa4cf02:


    grace "Ca ne te coûte rien mais pour nous c'est très important pour la sortie de l'épisode 2 en Janvier sur Steam !"


translate french e2s1_9c14f477:


    grace "Alors... Peux tu cliquer sur le lien qui apparaît ?"


translate french e2s1_550056d1:


    grace "Oh ? Je suis désolée mais si tu as des suggestions ou des remarques à faire n'hésites pas à laisser des commentaires sur les sites et forums !"


translate french e2s1_36653393:


    grace "Dis nous ce que tu aimes et ce que tu veux !"


translate french e2s1_b32a6fc0:


    grace "Et si tu veux nous aider tu peux quand même cliquer sur le lien qui apparaît pour ajouter le jeu à ta wishlist !"


translate french fingrace_a7a43b0f:


    grace "Merci beaucoup pour le temps que tu as passé sur ce jeu !"

translate french strings:


    old "Do you like the game ?"
    new "Est ce que tu aimes ce jeu ?"




translate french e2s1_553923c3:


    ruby "On verra bien ! Allez, prends tes affaires, les autres nous attendent..."


translate french e2s1_c679b986:


    mad "Et pourquoi ça serait lui le héros ? Pourquoi ça ne serait pas une fille ?" with hpunch


translate french e2s1_e38298e5:


    d "Ruby !!!" with hpunch


translate french e2s1_91afb2d6:


    mad "Je ne suis pas une Milf !" with hpunch


translate french e2s1_f00c15b1:


    grace "Génial ! J'aimerais vraiment que vous nous aidiez en ajoutant le jeu à votre liste de souhaits STEAM!"




translate french e2s1_c0c7ea31:


    chosen "Oh, trop mignon !!!"


translate french e2s1_c1d00fb4:


    "Mais je ne suis pas Bleue... Retourne avec ta vipère !"




translate french e2s1_5949d107:


    ruby "Oh ? T'as un téléphone ?"


translate french e2s1_9f2c3adf:


    grace "Du coup, j'ai acheté ces bouteilles en France... Vous allez adorer !!!"


translate french e2s1_db67b519:


    grace "Non !!! T'es magnifique Maddie... Je ne comprends pas pourquoi tu es toujours célibataire..."


translate french e2s1_bec58da1:


    ruby "Et dans les Visual Novels les choses sont plus..."


translate french e2s1_1a6dede1:


    ruby "Ben, en fait y'en a plus... mais j'aime bien le chiffre 7 donc... Et puis de toute façon c'est moi qui explique donc c'est moi qui décide !"


translate french e2s1_835b305a:


    ruby "La quatrième règle est : Pas de TMI !!!"


translate french e2s1_58c738d5:


    ruby "En vrai, personne n'a envie d'être comparé à quelqu'un d'autre dans sa relation ou pendant un acte... Alors dans un jeu..."


translate french e2s1_93e11265:


    ruby "Ce qui nous emmène à la pénultième règle : tous le monde n'a pas les mêmes fêtiches !"


translate french e2s1_d9cecfb7:


    ruby "Euh... Par exemple, certains adorent les pieds.... Ils adorent les scènes où on voit des pieds, des bas..."


translate french e2s1_600af04a:


    ruby "Dans ce cas, autant faire un jeu où le héros est amnésique, il va dans un maison avec sa tante/voisine/propriétaire, rayez la mention inutile, et il va s'occuper des 2-3 filles qui sont là à côté..."




translate french e2s1_3989a49b:


    julia "Oh, Viens avec moi ! Je vais te montrer le campus sur le chemin de la bibliothèque, que tu puisses voir les différentes parties de l'Université !"




translate french e2s1_b1dc201a:


    d "Heu....."


translate french chosenkiss_c0c7ea31:


    chosen "Oh, c'est trop mignon !!!"


translate french chosenkiss_c1d00fb4:


    "Mais je ne suis pas Bleue... Retourne avec ta vipère !"


translate french chosenkiss_29561989:


    ruby "Bref, c'est cool, mais passons à la règle numéro 3 !"


translate french chosenkiss_8b5643a9:


    ruby "Les LIs peuvent avoir un passé, mais c'est encore mieux si elles sont vierges !"


translate french chosenkiss_fb631fdc:


    mad "De quoi ???"


translate french chosenkiss_370788c5:


    ruby "Oui... Bon toi évidemment, on peut pas dire que tu l'es... Tu as ta fille, donc..."


translate french chosenkiss_134961cf:


    mad "Donc je ne peux pas être une LI ?"


translate french chosenkiss_7e7e2e62:


    ruby "Tu voulais en être une ?"


translate french chosenkiss_bc824b1a:


    mad "Non mais tu m'as vu ? Si j'étais dans ce genre de jeu, j'espère bien en être une et pas une fille d'à côté ! "


translate french chosenkiss_f653a44a:


    grace "Hahaha !"


translate french chosenkiss_8af8bebb:


    ruby "Nan mais c'est pas parce que tu n'es pas vierge que tu ne peux pas être une LI ! C'est juste que les joueurs préfèrent les filles qui sont pures..."


translate french chosenkiss_c7db646b:


    mad "C'est ridicule... J'aime pas ton jeu..."


translate french chosenkiss_99cbf7ae:


    ruby "Par exemple, ici on est pas mal ! [name] aurait 4 filles, dont 3 seraient vierges !"


translate french chosenkiss_42486048:


    julia "Okay... T'étais pas obligée de le rappeler Ruby..."


translate french chosenkiss_36cccf90:


    grace "Ouais... Des fois je me demande si je suis pas trop coincée et si je devrais pas m'ouvrir un peu plus..."


translate french chosenkiss_aede0390:


    ruby "C'est pas grave les filles ! C'est mieux pour les joueurs... Et au moins on pourra pas nous reprocher quelque chose dans la 4ème règle !!!"


translate french chosenkiss_bdfd47df:


    mad "Et c'est quoi la quatrième règle ? Pas le droit d'avoir des enfants ?"


translate french chosenkiss_894769a1:


    ruby "Nan !!!"


translate french chosenkiss_835b305a:


    ruby "La quatrième règle est : Pas de TMI !!!"


translate french chosenkiss_29ac5843:


    d "Pas de quoi ?"


translate french chosenkiss_ce2d5e47:


    ruby "TMI ! Too Much Information !!! Trop de passé tue le présent !"


translate french chosenkiss_6d3dab99:


    grace "Je comprends rien..."


translate french chosenkiss_24160dd1:


    ruby "En gros, le joueur qui joue au jeu... ne veut pas vraiment savoir combien de garçons tu as embrassé avant..."


translate french chosenkiss_c5257780:


    ruby "Ou alors... Avant de le rencontrer... Ca ne l'intéresse pas ! C'est comme dire : Wow la tienne est plus grosse que celle d'Edouard !"


translate french chosenkiss_8258fe0c:


    ruby "On s'en fout ! Pire... J'ai eu plus de 100 gars avant toi, mais toi t'es le meilleur..."


translate french chosenkiss_ce93967e:


    ruby "A part paraître comme une catin, ça n'ajoute rien au joueur si ce n'est un certain ressentiment envers la fille !"


translate french chosenkiss_392c2d22:


    ruby "Des fois ça va tellement loin que le joueur va quitter le jeu parce qu'il ne veut pas entendre ou lire des choses comme ça ! Donc, pas de TMI, pas de problèmes !"


translate french chosenkiss_5ce70a32:


    mad "Mais j'ai le droit d'avoir une vie quand même non ?"


translate french chosenkiss_4b1161c1:


    ruby "Evidemment ! Mais ta romance avec le héros ne doit pas être en conflit avec des romances du passé !"


translate french chosenkiss_58c738d5:


    ruby "Après tout, dans la vie réelle, personne ne veut être comparé à quelqu'un pendant un acte... Alors encore moins dans un jeu..."


translate french chosenkiss_16d76ed1:


    julia "Du coup c'est beaucoup plus facile quand on est vierges !"


translate french chosenkiss_f48f8f08:


    ruby "Oui mais tu ne dois pas non plus dire un truc style OH j'en ai embrassé des garçons... Mais avec toi c'est différent..."


translate french chosenkiss_a9acb29d:


    julia "Bah... J'ai pas fait ça non plus donc..."


translate french chosenkiss_188cc25b:


    ruby "Bref, cinquième règle !!!"


translate french chosenkiss_939fccd4:


    d "On dirait qu'on donne naissance à un Gremlin... Ne pas donner à manger avant minuit... Ne pas mettre dans l'eau... Ne pas exposer au soleil..."


translate french chosenkiss_a29cc547:


    ruby "Oh !!! Tu connais Gremlins ??? C'est un film de Steven Spielberg !!! Tu sais que..."


translate french chosenkiss_e38298e5:


    d "Ruby !!!" with hpunch


translate french chosenkiss_c1826e34:


    ruby "Pardon, pardon... Bon, la cinquième règle : il faut une Milf !"


translate french chosenkiss_5eefb60e:


    grace "Ahahahahahaha! Maddie, celle là est pour toi !"


translate french chosenkiss_91afb2d6:


    mad "Je suis pas une Milf !" with hpunch


translate french chosenkiss_a393b1dd:


    julia "Techniquement... Tu pourrais en être une !"


translate french chosenkiss_e593a657:


    mad "Mais arrêtez ! J'ai 22 ans, je peux pas être une Milf... Gabriella si vous voulez !"


translate french chosenkiss_a6936512:


    grace "La prof ?"


translate french chosenkiss_b01b9536:


    mad "Ouais !"


translate french chosenkiss_e453b0a8:


    d "Tiens je la connais pas elle !"


translate french chosenkiss_3377260b:


    ruby "T'inquiètes tu vas la voir demain !!!"


translate french chosenkiss_4035bba9:


    mad "Et donc ta Milf elle doit être comment ?"


translate french chosenkiss_d6b663b2:


    ruby "C'est mieux si elle est négligée par son mari.... Qu'elle n'a pas été touchée depuis un moment..."


translate french chosenkiss_afde39b0:


    ruby "C'est un peu une âme perdue que le héros va sauver..."


translate french chosenkiss_30d62a1a:


    grace "Et [name] va sauver Gabrielle ? Je veux dire, elle pourrait être dans cette catégorie, mais je vois pas [name] avec une femme de 35 ans !"


translate french chosenkiss_1df83774:


    grace "Je te l'avais dit !"


translate french chosenkiss_8ca883d5:


    julia "C'est joliment dit... C'est romantique !"


translate french chosenkiss_4dcee382:


    mad "Ne me regarde pas quand tu dis ça !!!"


translate french chosenkiss_daafaac8:


    ruby "Dans tous les cas, on a besoin de notre Milf... Parce que ça crée de nouvelles dynamiques avec le joueur, avec des tabous qui titillent leur imagination..."


translate french chosenkiss_2a5dc559:


    mad "Bah... En même temps, l'imagination des gars est principalement située sous la ceinture..."


translate french chosenkiss_93e11265:


    ruby "Ce qui nous emmène à la pénultième règle : tous les fétiches ne sont pas pour tout le monde ! "


translate french chosenkiss_18ee35c4:


    grace "Les fétiches ?"


translate french chosenkiss_c1d261d7:


    ruby "Oui..."


translate french chosenkiss_c8aa12cf:


    julia "C'est quoi ?"


translate french chosenkiss_d9cecfb7:


    ruby "Heu... par exemple, des joueurs sont fétichistes des pieds... Ils aiment les scènes mettant en avant les pieds les jambes les bas..."


translate french chosenkiss_c735661d:


    ruby "D'autres aiment le BDSM... D'autres détestent les scènes lesbiennes... Et on ne parle pas du NTR..."


translate french chosenkiss_305242eb:


    d "NTR ?"


translate french chosenkiss_29470446:


    ruby "Oui... NTR... ça vient du japonais netorare...En gros c'est le principe de tromper ou d'être trompé dans un jeu..."


translate french chosenkiss_4f6772e8:


    ruby "Certains aiment ça... D'autres détestent... Et ça crée des conflits importants entre deux équipes qui se battent pour ce qu'ils aiment..."


translate french chosenkiss_334f2a21:


    ruby "Donc pour éviter ça : tout ce qui relève d'un fétiche ou d'une opinion personnelle du joueur se doit d'être OPTIONNEL !"


translate french chosenkiss_a548b7ad:


    grace "Je vois pas comment tu fais ça..."


translate french chosenkiss_2bc88dcb:


    ruby "Heu... Okay, un exemple : Grace lève toi !"


translate french chosenkiss_a3493863:


    grace "Okay !"


translate french chosenkiss_ecde9d6a:


    ruby "Maintenant embrasse moi !"


translate french chosenkiss_0dafd5f9:


    grace "Hein ???"


translate french chosenkiss_01eb2f6a:


    ruby "Allez embrasse-moi ! Juste un petit baiser !"


translate french chosenkiss_ef85cac4:


    grace "Ben... Si tu veux... Mais je vois pas comment ça montre l'exemple !"


translate french chosenkiss_ef037255:


    ruby "Stop !"


translate french chosenkiss_38c5cdf2:


    ruby "[name], t'as envie de nous voir nous embrasser ?"


translate french chosenkiss_e80a0892:


    mad "Evidemment qu'il dit oui... Deux filles qui s'embrassent et il est tout dur je parie !"


translate french chosenkiss_def43184:


    ruby "C'était pas mal..."


translate french chosenkiss_6a4f23ef:


    grace "Ouais..."


translate french chosenkiss_d60a073d:


    ruby "Tu vois, on lui a donné le choix ! C'est le principe. S'il ne voulait pas nous voir nous embrasser, il aurait pu dire non."


translate french chosenkiss_b79a1c45:


    ruby "Tu vois, on lui a donné le choix ! C'est le principe. S'il voulait nous voir nous embrasser, il aurait pu dire oui."


translate french chosenkiss_841cf19e:


    ruby "Mais au moins on respecte ce qu'il aime et ce qu'il veut voir quand il joue !"


translate french chosenkiss_b6788b9d:


    grace "Okay je comprends mieux !"


translate french chosenkiss_b4359a05:


    ruby "Et pour finir ! La dernière règle : la plus importante de toutes !"


translate french chosenkiss_45f140c1:


    mad "Je parie que ça va être : du sexe partout, tout le temps, avec tout le monde !"


translate french chosenkiss_e1aa72bf:


    grace "Nan je dirais... Les personnages doivent avoir de gros seins, un cul rebondi et des lèvres pulpeuses..."


translate french chosenkiss_cd7a880b:


    julia "Ou alors il faut du drama, des trucs qui font peur ou qui font pleurer !"


translate french chosenkiss_9f40f626:


    ruby "POOOOOOOOOOOOOOOOTTTTTTT... Vous êtes les maillons faibles... Au revoir !"


translate french chosenkiss_dd5d68f3:


    d "Hein ?"


translate french chosenkiss_d5ab8d28:


    ruby "Le sexe doit être intégré à l'histoire mais doit être un soutien à celle-ci et pas l'inverse !"


translate french chosenkiss_2c3a63c7:


    d "Comment ça ?"


translate french chosenkiss_1a514c11:


    ruby "En gros, l'histoire passe avant tout. Le sexe ne devrait être qu'un des aspects du jeu et non pas l'élément principal..."


translate french chosenkiss_476ab487:


    ruby "Sinon, tout le reste ne sert à rien..."


translate french chosenkiss_600af04a:


    ruby "Dans ce cas, autant jouer à un jeu où le héros est amnésique, il entre dans une maison tenue par sa tante/propriétaire/voisine (rayez la mention inutile) et il choppe 2, 3 ou 4 filles dedans... "


translate french chosenkiss_e8625ea9:


    ruby "ET hop le voilà en harem avec les filles de la maison avec des scènes de sexe toutes les 5 secondes et l'histoire ben... on s'en fout !"


translate french chosenkiss_a9cca5de:


    ruby "Pour sûr c'est sympa pour le joueur fast-food, mais pour un joueur impliqué dans l'histoire, c'est répulsif."


translate french chosenkiss_705eeb93:


    ruby "Le héros est une machine qui n'a aucun sentiment et les filles sont juste de la viande..."


translate french chosenkiss_9d7730bf:


    ruby "En gros, on peut résumer ça par : Les joueurs ne veulent pas du réalisme... Ils veulent de la magie !"


translate french chosenkiss_28d95fb6:


    julia "Oh..."


translate french chosenkiss_a8699778:


    d "D'accord..."


translate french chosenkiss_d3559afb:


    ruby "Mais tout ceci était dans l'hypothétique scénario de ce que ce serait d'être dans un Visual Novel !"


translate french chosenkiss_1e5dfb0e:


    mad "Ouais hypothétique parce que [name] en tant que héros et moi en tant que Milf..."


translate french chosenkiss_44699cd8:


    grace "Elle arrive pas à digérer ce truc de Milf !!!"


translate french chosenkiss_c02f63b0:


    julia "Allez les filles ! J'aimerais bien rester discuter mais je dois aller à la bibliothèque pour aller chercher mes livres..."


translate french chosenkiss_b8c86f42:


    grace "Moi je dois aller à la piscine..."


translate french chosenkiss_dd120e78:


    d "Julia..."


translate french chosenkiss_3fb1de81:


    julia "Oui ?"


translate french chosenkiss_df802e86:


    d "T'as dit que tu me ferais visiter le campus cet après-midi... Tu as toujours le temps ?"


translate french chosenkiss_3989a49b:


    julia "Oh ben viens avec moi ! Je vais te montrer tout ça sur le chemin de la bibliothèque comme ça tu pourras voir les différentes parties de l'Université !"


translate french chosenkiss_34c55b1f:


    d "Merci beaucoup..."


translate french chosenkiss_3fcacb3d:


    julia "A plus tard les filles !"


translate french chosenkiss_8f1df40c:


    grace "A plus tard ! Amusez-vous bien et [name]... N'esssaye pas trop de la draguer !"


translate french chosenkiss_c4897051:


    grace "C'est pas parce que t'es le héros et qu'elle est vierge qu'il faut lui sauter dessus !"


translate french chosenkiss_ef579692:


    julia "Grace..."


translate french chosenkiss_38715887:


    grace "Je ne suis plus là !!!"


translate french chosenkiss_3896858a:


    julia "Heu... T'as un téléphone ?"


translate french chosenkiss_bc68d24d:


    d "Ouais je viens juste de le retirer de mon sac..."


translate french chosenkiss_8121b812:


    julia "Laisse moi t'ajouter au cas où..."


translate french chosenkiss_ce7133ef:


    julia "Okay... On peut y aller !"



translate french strings:


    old "Buddy [TEMP1]"
    new "Buddy [TEMP1]"


    old "Education [TEMP2]"
    new "Education [TEMP2]"


    old "Sport [TEMP3]"
    new "Sport [TEMP3]"


    old "Temperament [TEMP4]"
    new "Temperament [TEMP4]"


    old "Age has nothing to do with feelings. [TEMP1]"
    new "L'âge n'a rien à voir avec les sentiments [TEMP1]"


    old "Milfs are life! [TEMP2]"
    new "Les Milfs c'est la vie ! [TEMP2]"


    old "Yes, definitely! [TEMP1]"
    new "Evidemment ! [TEMP1]"


    old "No, I don't like it. [TEMP2]"
    new "Non, je n'aime pas ça. [TEMP2]"



translate french strings:


    old "Buddy [TEMP1!t]"
    new "Buddy [TEMP1!t]"


    old "Education [TEMP2!t]"
    new "Education [TEMP2!t]"


    old "Sport [TEMP3!t]"
    new "Sport [TEMP3!t]"


    old "Temperament [TEMP4!t]"
    new "Temperament [TEMP4!t]"


    old "Age has nothing to do with feelings. [TEMP1!t]"
    new "L'âge n'a rien à voir avec les sentiments [TEMP1!t]"


    old "Milfs are life! [TEMP2!t]"
    new "Les Milfs c'est la vie ! [TEMP2!t]"


    old "Yes, definitely! [TEMP1!t]"
    new "Evidemment ! [TEMP1!t]"


    old "No, I don't like it. [TEMP2!t]"
    new "Non, je n'aime pas ça. [TEMP2!t]"




translate french e2s1_7abb44d8:


    emerick "Vous m'avez fait demandé mon Oncle ?"


translate french e2s1_5e9c212e:


    grace "Ouais... Je suppose que c'est pas très sexy... Bon allez... On se voit plus tard jolie bouteille..."


translate french chosenkiss_21922934:


    d "Ouais je viens tout juste de le récupérer dans mon sac..."




translate french e2s1_96a9da0e:


    d "{i} Here we are. Born to be kings. {/i}"


translate french e2s1_055fcf24:


    d "{i} We're the princes of the universe. {/i}"


translate french e2s1_c247cc91:


    d "{i} I am immortal. I have inside me blood of kings. {/i}"


translate french e2s1_e19559ea:


    d "{i} I have no rival. No man can be my equal. {/i}"


translate french e2s1_d16b1e74:


    d "{i} Take me to the future of your world. {/i}"




translate french chosenkiss_80e6294b:


    mad "Mais je ne suis pas Bleue donc... Retourne voir ta vipère !"




translate french e2s1_fe0698a3:


    cr "Ruby va expliquer ce qu'est un Visual Novel aux filles."


translate french e2s1_a3dc9317:


    cr "Voulez-vous voir son explication ?"


translate french finrubyvn_c02f63b0:


    julia "Bon, les filles, aussi tentant que ce soit de rester discuter, je dois aller à la bibliothèque chercher mes manuels..."


translate french finrubyvn_b8c86f42:


    grace "Et moi, je dois aller à la piscine..."


translate french finrubyvn_dd120e78:


    d "Julia..."


translate french finrubyvn_3fb1de81:


    julia "Oui ?"


translate french finrubyvn_df802e86:


    d "Tu avais dit que tu me ferais visiter le campus cet après-midi... Tu as toujours le temps ?"


translate french finrubyvn_3989a49b:


    julia "Oh, ben viens avec moi ! Je vais te faire visiter en allant à la bibliothèque, comme ça tu pourras voir les différentes parties de l'université !"


translate french finrubyvn_34c55b1f:


    d "Merci beaucoup..."


translate french finrubyvn_3fcacb3d:


    julia "À plus tard, les filles !"


translate french finrubyvn_8f1df40c:


    grace "À plus tard ! Amusez-vous bien, et [name], ne profite pas trop d'elle !"


translate french finrubyvn_c4897051:


    grace "Ce n'est pas parce que tu es le héros et qu'elle est vierge que tu dois lui sauter dessus !"


translate french finrubyvn_ef579692:


    julia "Grace..."


translate french finrubyvn_38715887:


    grace "Je suis plus là !!!"


translate french finrubyvn_3896858a:


    julia "Hum... Tu as un téléphone ?"


translate french finrubyvn_21922934:


    d "Oui, je viens de le sortir de mon sac..."


translate french finrubyvn_8121b812:


    julia "Laisse-moi t'ajouter !"


translate french finrubyvn_ce7133ef:


    julia "D'accord... Allons-y..."





translate french e2s1_9630385f:


    cr "Veuillez noter que vous pourriez rater du contenu plus tard si vous ne suivez pas la conversation."


translate french e2s1_05f0b011:


    cr "Voulez-vous suivre son explication?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
