


translate french e3s3_12ad8469:


    julia "Voilà on y est. C'est chez moi!"


translate french e3s3_0edccaa4:


    d "C'est sympa!"


translate french e3s3_3700f2d6:


    julia "Oh... Ca n'a rien de spécial, mais y'à tout ce dont j'ai besoin et puis le prix est abordable."


translate french e3s3_6a1c010e:


    julia "Bon après c'est pas dans les meilleurs quartiers, tu as dû le remarquer..."


translate french e3s3_bf939523:


    d "Je ne connais pas encore les quartiers mais oui, l'allée où on est passés faisait un peu peur."


translate french e3s3_9ced4376:


    julia "Ben je passe par là tous les soirs après mon travail!"


translate french e3s3_74e3136e:


    d "Ca me paraît pas très sûr..."


translate french e3s3_6fa84a8a:


    d "Pourquoi tu m'as pas dit que tu travaillais?"


translate french e3s3_56073172:


    julia "Disons que je ne suis pas dans la même situation financière que les autres."


translate french e3s3_a15dd700:


    julia "J'ai une bourse d'études pour pouvoir continuer à payer ma scolarité."


translate french e3s3_df4731e9:


    julia "Mais entre la location de l'appart et... D'autres choses que je dois gérer, il faut que je travaille pour payer tout ça."


translate french e3s3_d5e1b526:


    julia "Et je suis pas comme Madison ou les jumelles, j'ai pas mes parents pour m'aider."


translate french e3s3_682e4e49:


    d "Où sont tes parents?"


translate french e3s3_93efd31f:


    julia "Heu... Je ne sais pas où est mon père. Je ne l'ai jamais connu."


translate french e3s3_e53c2952:


    julia "Et ma mère est très malade."


translate french e3s3_cd177145:


    julia "Elle a un cancer des os et il ne lui reste plus longtemps à vivre..."


translate french e3s3_ad0f2283:


    d "Je suis désolé..."


translate french e3s3_e3457991:


    julia "Comme elle a pas vraiment d'assurance, il faut que je l'aide à payer ses soins."


translate french e3s3_6ec795c1:


    d "Ca fait beaucoup sur tes épaules tout ça."


translate french e3s3_2c8ea51b:


    julia "Oui... Et c'est pourquoi je reste un peu dans mon coin. J'ai assez à gérer de mon côté."


translate french e3s3_040c5935:


    julia "Quand j'entends les autres se plaindre pour des conneries..."


translate french e3s3_584369bb:


    julia "Ou quand Madison me fait chier pour rien, j'ai du mal à calmer mes nerfs..."


translate french e3s3_f9fbb463:


    d "Je comprends."


translate french e3s3_09de03e3:


    julia "Mais ça ne m'empêche pas de vivre et de... Outch!"


translate french e3s3_2baafa95:


    d "Qu'est ce qui se passe?"


translate french e3s3_d8f13f9a:


    julia "Mon dos me fait mal! J'ai vraiment dû me faire quelque chose en tombant!"


translate french e3s3_b99a2b3b:


    d "Attends, on va te poser sur le lit."


translate french e3s3_101332d7:


    julia "Hein?"


translate french e3s3_7ae3d8a2:


    d "Je vais te faire un massage. Ca va te faire du bien."


translate french e3s3_f1e67029:


    julia "Tu sais faire ça toi?"


translate french e3s3_9976359d:


    d "Oui, j'avais pris des cours de thérapie sportive... Je te promets, ça va diminuer tes douleurs."


translate french e3s3_b217ed72:


    julia "Hum... Okay... On peut essayer..."


translate french e3s3_641e6172:


    d "Allonge toi."


translate french e3s3_690aeb67:


    d "Ca serait plus facile si tu enlevais ton haut."


translate french e3s3_933436bb:


    julia "Heu... Oui, c'est vrai."


translate french e3s3_aea36d69:


    d "Ne t'inquiètes pas. Fais de ton mieux pour te relâcher et relaxer tes muscles."


translate french e3s3_dc0f59ff:


    julia "Je vais essayer."


translate french e3s3_f790c5fe:


    julia "Ah, ça fait du bien..."


translate french e3s3_61e25695:


    d "Je te l'avais dit."


translate french e3s3_2b836df5:


    d "Maintenant, relax!"


translate french e3s3_561cd9b9:


    julia "Hum... OUi... Là..."


translate french e3s3_d1923521:


    julia "Un peu plus bas... Là..."


translate french e3s3_8eea2814:


    julia "C'est parfait."


translate french e3s3_ca0cc37f:


    d "Tu veux que je continues un peu plus bas?"


translate french e3s3_53c79c86:


    julia "Je pense que tu as déjà assez touché un peu plus bas dans l'avion l'autre jour."


translate french e3s3_7875d62f:


    d "Oh... Désolé. C'était vraiment naze de ma part."


translate french e3s3_f479b588:


    julia "Mais merci quand même."


translate french e3s3_3a32d93a:


    julia "Je ne sais pas si..."


translate french e3s3_e6a490a3:


    julia "AH, ça fait vraiment du bien..."


translate french e3s3_a3222942:


    d "Tu sais, tu as un corps magnifique."


translate french e3s3_9cb2fb4a:


    julia "Heu... Merci?"


translate french e3s3_cb6df9e9:


    d "Musclée avec de belles courbes, et ta peau est douce."


translate french e3s3_5e76aabf:


    julia "Ah..."


translate french e3s3_93d6639c:


    d "Laisse-moi prendre soin de toi, Julia."


translate french e3s3_ebeb14c7:


    julia "Hmm..."


translate french e3s3_990aa0aa:


    d "Je veux que tu aies confiance en moi, que je puisse être quelqu'un sur qui tu puisses compter."


translate french e3s3_d11ffcb2:


    d "Laisse-moi découvrir la vraie Julia. Celle qui n'attend juste qu'à s'épanouir."


translate french e3s3_28d95fb6:


    julia "Oh..."


translate french e3s3_5242d378:


    d "Je serais là si tu as besoin de moi."


translate french e3s3_5698db07:


    julia "Je..."


translate french e3s3_6584bc6c:


    julia "Ah!"


translate french finjuliaep2_b8dc5ea9:


    julia "Merci. je crois que c'est assez pour ce soir. Je me sens déjà beaucoup mieux."


translate french finjuliaep2_486de3ba:


    d "N'hésite pas à me demander si tu as besoin de mes mains expertes!"


translate french finjuliaep2_23dd4e9a:


    julia "Oui, merci. Vraiment."


translate french finjuliaep2_36ff4f70:


    d "Bon je vais y aller. Il faut encore que je rentre et j'ai promis à Ruby de lui envoyer un message quand je serais rentré. J'ai pas envie qu'elle s'inquiète!"


translate french finjuliaep2_c2b6bb98:


    julia "Oh oui! Tu peux être sûr qu'elle dormira pas tant qu'elle n'a pas de nouvelles de toi!"


translate french finjuliaep2_4ce986cd:


    julia "Elle est comme ça avec les gens qu'elle aime."


translate french finjuliaep2_0a780817:


    d "Je devrais me dépêcher alors."


translate french finjuliaep2_95fa21dd:


    julia "Oui... Tu ferais mieux..."


translate french finjuliaep2_841b0d8a:


    d "A demain, Julia."


translate french finjuliaep2_79f08374:


    julia "A demain... [name]."




translate french e3s3_9d3ce74c:


    julia "Et ma mère est très malade."


translate french e3s3_2bc4c54e:


    julia "Ou quand Madison me fait chier pour rien, j'ai du mal à garder mes nerfs."


translate french e3s3_eb7a265c:


    julia "Mais ça ne m'empêche pas de vivre et de..."


translate french e3s3_bccda825:


    julia "Outch!"


translate french e3s3_a5c86f5a:


    julia "D'accord."


translate french e3s3_0551ca4c:


    d "Franchement... On dirait un cadavre dans cette position!"


translate french e3s3_3d5f9e28:


    julia "Hey!" with hpunch


translate french e3s3_50424d17:


    julia "C'est pas toi qui a mal!"


translate french e3s3_77e66e95:


    d "Oui désolé. Laisse-moi juste faire ça et tu te sentiras mieux après tu verras."


translate french e3s3_89966ef2:


    julia "J'espère bien..."


translate french e3s3_ab68d771:


    d "T'es très tendue!"


translate french e3s3_733bbbb6:


    julia "J'ai pas pour habitude d'être allongée avec quelqu'un sur mon lit..."


translate french e3s3_29a8225a:


    julia "Je crois que je serais plus à l'aise assise."


translate french e3s3_04a6c5de:


    d "Fais comme tu le sens. Je veux juste que tu te détendes."


translate french e3s3_9d672ec7:


    julia "C'est beaucoup mieux."


translate french e3s3_2cbde8fa:


    d "Si tu le dis."


translate french e3s3_8dcc9644:


    julia "Un peu plus bas..."


translate french e3s3_d6f16a8e:


    julia "Ouais..."


translate french e3s3_de861bdc:


    julia "Juste comme ça."


translate french e3s3_69ad8ab5:


    julia "Heu... Oui, ça paraît logique."


translate french e3s3_10487543:


    d "Tu veux que je continue ?"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
