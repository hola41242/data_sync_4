


translate french coming2_2c7a6b72:


    mad "Papa... Pourquoi tu veux le rencontrer?"


translate french coming2_315b4afb:


    mad "..."


translate french coming2_9f07be60:


    mad "Je le ferais..."


translate french coming2_7a29416a:


    ji "Tu vas à la soirée ce soir?"


translate french coming2_aee41bbd:


    ji "Maman..."


translate french coming2_7a16ee9c:


    grace "Tu es le seul que je veux ce soir..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
