


translate french e3s2_1127c8b7:


    dpense "Cette ville est sacrément grande en vrai..."


translate french e3s2_921070ae:


    dpense "Je pourrais me perdre facilement."


translate french e3s2_af8cb32c:


    dpense "Je commence à vraiment avoir faim..."


translate french e3s2_628dd100:


    d "Oh putain!!!"


translate french e3s2_8c797edf:


    ji "[name]!"


translate french e3s2_9a5a998a:


    ji "Fais attention! J'aurais pû t'écraser!"


translate french e3s2_141331e8:


    d "Gabriella?"


translate french e3s2_6ad75cf1:


    gaby "Oui?"


translate french e3s2_e3f41e12:


    d "Quand je disais que vous deviez être fière de votre corps..."


translate french e3s2_154ba855:


    gaby "Comment ça?"


translate french e3s2_360b7017:


    d "Non non, rien..."


translate french e3s2_3b4d6953:


    gaby "Qu'est ce que tu fais tout seul par ici ?"


translate french e3s2_c9a1e7db:


    d "Ben... J'allais rentrer..."


translate french e3s2_e1a3f444:


    d "Mais je commençais à avoir faim, donc j'étais en train de chercher un endroit pour manger quelque chose."


translate french e3s2_bf70937f:


    gaby "Oh... Hummm. Y'à un petit snack qui vend des glaces un peu plus loin, ils servent des sandwichs aussi je crois."


translate french e3s2_fd5a6c65:


    d "Et vous?"


translate french e3s2_7e55ce1d:


    gaby "De quoi, moi ?"


translate french e3s2_a948d4c0:


    d "Vous allez où comme ça?"


translate french e3s2_808c3229:


    gaby "Oh! Ben je vais rejoindre des amies dans un pub un peu plus loin."


translate french e3s2_a03f3ec8:


    gaby "Histoire de prendre l'air et de décompresser. Me changer les idées."


translate french e3s2_cfca72a0:


    d "Et s'amuser un peu?"


translate french e3s2_ea659a8f:


    gaby "S'amuser?"


translate french e3s2_e083016a:


    d "Vous faites si sérieuse. Vous devriez vous lâcher un peu."


translate french e3s2_0a9cfc2b:


    d "Encore une fois, madame, avec tout le respect que je vous dois, vous avez encore toute votre vie devant vous."


translate french e3s2_40639949:


    d "Vous devriez en profiter et vivre un peu plus."


translate french e3s2_edb73cb4:


    gaby "Plus facile à dire qu'à faire!"


translate french e3s2_1dd96015:


    d "Je pourrais vous aider."


translate french e3s2_66b194e0:


    gaby "Pardon?"


translate french e3s2_db8727cf:


    d "Non, mais... Si vous voulez bouger, explorer, trouver et essayer de nouvelles choses..."


translate french e3s2_09fdfeb6:


    d "Vous me dîtes et je serais râvi de découvrir tout ça avec vous!"


translate french e3s2_854ec0fe:


    gaby "Hum... Je vais y réfléchir."


translate french e3s2_40e6a329:


    gaby "Bon, mes amies m'attendent..."


translate french e3s2_c5662bab:


    gaby "Tu vas trouver ton chemin?"


translate french e3s2_17918988:


    d "Vous m'avez dit que c'était au bout de la rue, c'est ça?"


translate french e3s2_f9ad3300:


    gaby "Oui, c'est ça."


translate french e3s2_b457e59a:


    d "Bon ben je vais aller par là et voir si je trouve ce marchand de glaces!"


translate french e3s2_7fd3646a:


    gaby "Hmm... Tu n'es pas encore familier avec cette ville n'est ce pas?"


translate french e3s2_33aadc58:


    gaby "Tiens, prends mon numéro. Si tu as des problèmes n'hésite pas à m'appeler."


translate french e3s2_9ea04bdb:


    gaby "Seulement en cas d'urgence par contre hein!"


translate french e3s2_a5966752:


    d "Heu... Oui... Compris."


translate french e3s2_9cd3569b:


    gaby "Oh, et, ne le donne à personne s'il te plaît..."


translate french e3s2_6fc56de8:


    gaby "Je te fais confiance."


translate french e3s2_a611fd9b:


    d "C'est promis."


translate french e3s2_2d1a777c:


    gaby "Allez, passe une bonne soirée, [name]."


translate french e3s2_fca7b125:


    dpense "Vous aussi, Gabriella."


translate french e3s2_0b836494:


    dpense "Putain trop bien! J'ai le numéro de la prof!"


translate french e3s2_a9dbaa79:


    dpense "Ahahah!"


translate french e3s2_0e9f075b:


    dpense "Si Ruby savait ça..."


translate french e3s2_6f01d825:


    dpense "Bon... Au bout de la rue..."


translate french e3s2_4d58dae6:


    hec "Hey les gars! La boss est pas là!"


translate french e3s2_fb38d61b:


    hec "Venez on se fait un restau basket! Ca lui apprendra à cette pute..."


translate french e3s2_32390969:


    "Ouais!"


translate french e3s2_ff71161a:


    julia "Hey!!!"


translate french e3s2_3db33b00:


    julia "Revenez! Vous n'avez pas payé!"


translate french e3s2_f24da56c:


    hec "Casse-toi Pinkie!"


translate french e3s2_18c56c61:


    hec "Tu vas prendre ce que tu mérites!"


translate french e3s2_4987099d:


    hec "Hein?"


translate french e3s2_3cacebcc:


    d "C'est quoi ton problème? Attaquer une femme comme ça?"


translate french e3s2_49e8c780:


    hec "Lâche-moi! C'est pas tes affaires!"


translate french e3s2_ed275116:


    d "C'est mon amie, donc c'est mes affaires."


translate french e3s2_2ac61999:


    hec "Et qu'est-ce que tu vas faire hein? Je l'ai pas touché. Si tu me frappes il y a des témoins. Si tu veux des problèmes avec la police..."


translate french e3s2_3e77ba36:


    hec "Tu peux dire au revoir à l'Academy. Frenchie."


translate french e3s2_fbe4d78d:


    julia "Laisse tomber [name]... Il n'en vaut pas la peine."


translate french e3s2_7896dad8:


    hec "Ouais. On se verra sur le terrain de toute façon, losers."


translate french e3s2_67b527e6:


    hec "On verra qui tape le plus fort."


translate french e3s2_f9c7f0b0:


    d "Tu vas bien?"


translate french e3s2_c63680a9:


    julia "Heu, ouais... Tu n'aurais pas dû t'en mêler."


translate french e3s2_e967c7b8:


    d "Je ne l'aurais pas laissé t'attaquer."


translate french e3s2_2d39ae6d:


    julia "Merci..."


translate french e3s2_73abd97c:


    cha "Julia, ça va?"


translate french e3s2_51ae6b1b:


    cha "J'ai vu la scène de loin. Mon dieu."


translate french e3s2_5f7f804f:


    julia "Oui oui t'inquiète pas."


translate french e3s2_1ba20f5d:


    cha "Merci, jeune homme, de l'avoir aidé... Mister???"


translate french e3s2_fbf269c6:


    d "[name]"


translate french e3s2_acca40b4:


    cha "Encore merci, [name]. Je n'aurais pas dû la laisser seule à ouvrir le magasin ce soir."


translate french e3s2_e01c9248:


    d "Tu travailles ici?"


translate french e3s2_4e619f92:


    julia "Oui..."


translate french e3s2_48ce23ad:


    d "Pourquoi tu ne me l'as pas dit?"


translate french e3s2_bd49eff6:


    cha "Attendez, on va rentrer. Ca fera du bien à tout le monde de se poser avec un chocolat chaud..."


translate french e3s2_6f6f00e8:


    cha "Mignon, fort, et courageux! Je comprends mieux pourquoi tu chantais. Si tu ne lui sautes pas dessus, je le ferais!"


translate french e3s2_15d9b8f0:


    julia "Je t'en prie... Fais toi plaisir."


translate french e3s2_2387a6fc:


    cha "Sérieux?"


translate french e3s2_cccd82e6:


    julia "Oui oui, il est tout à toi."


translate french e3s2_ec0ae24c:


    julia "Tu crois?"


translate french e3s2_e6a9aec8:


    cha "Un gars comme ça... Crois-moi, t'en trouveras pas dix dans la ville. Tu devrais tenter ta chance."


translate french e3s2_d1f70c04:


    julia "..."


translate french e3s2_36ccb686:


    cha "Je suis désolée Julia. Je suis venu au plus vite après avoir fini les comptes."


translate french e3s2_d62322d6:


    julia "C'est pas de ta faute."


translate french e3s2_22478a66:


    cha "Je ne te laisserais plus ouvrir seule."


translate french e3s2_7d9739b4:


    julia "Tu ne peux rien y faire. Y'aura toujours des cons qui essaieront de ne pas payer ou de nous faire chier... Encore plus avec ces vêtements. Aïe! "


translate french e3s2_b4f06701:


    d "Tu t'es fait mal?"


translate french e3s2_f446ab7a:


    julia "J'ai dû me fouler un muscle. Ca doit être quand il m'a fait tomber."


translate french e3s2_4d7dd868:


    cha "Ecoute Julia. Prends ta soirée. Je te paierais pour la journée et tu reviens lundi si tu te sens mieux. D'accord?"


translate french e3s2_dc1b71b4:


    julia "Euh... T'es sûre que..."


translate french e3s2_00d9f982:


    cha "Oui, évidemment! Vas-y!"


translate french e3s2_737c091e:


    julia "Bon ben... On se voit demain en classe?"


translate french e3s2_4395d1e1:


    cha "Attends! Tu vas quand même pas rentrer toute seule après ça, si?"


translate french e3s2_101332d7:


    julia "Heu..."


translate french e3s2_b07c4bd4:


    cha "[name]... Tu peux l'accompagner? On sait jamais si les gars traînent dans le coin. Et en plus elle est blessée..."


translate french e3s2_c86d76cd:


    d "Evidemment!"


translate french e3s2_98ee41e1:


    julia "Merci, Charlotte, et [name]..."


translate french e3s2_3d6f8fcc:


    d "De rien, je peux pas te laisser comme ça."


translate french e3s2_cb310aad:


    cha "Oh, Julia! Prend soin de toi! Au moins je sais que tu es entre de bonnes mains!"


translate french e3s2_5f93d507:


    julia "Heu... oui. A lundi!"


translate french e3s2_c429c485:


    d "Désolé Julia mais c'était une longue journée et j'ai toujours pas mangé donc..."


translate french e3s2_64959bcf:


    julia "Oh... Oui bien sûr pas de problèmes."


translate french e3s2_737c091e_1:


    julia "A demain en classe alors?"


translate french e3s2_bdc6126b:


    d "Ouais! A demain!"


translate french e3s2_28ec6028:


    julia "A demain..."


translate french e3s2_c429f4fb:


    cha "Et ben... Une bonne chose que tu passais par là."


translate french e3s2_dbed8808:


    cha "Pauvre Julia..."


translate french e3s2_4fdbb733:


    d "Ouais."


translate french e3s2_7d3fd540:


    cha "Et sinon... Je t'ai jamais vu par ici!"


translate french e3s2_4e2cab3e:


    cha "Je m'en serais rappelé!"


translate french e3s2_9764bddd:


    d "Je viens juste d'arriver aux US. Je viens de France."


translate french e3s2_12aafb8a:


    cha "Ah? Ta première fois aux States?"


translate french e3s2_fc6dea88:


    d "Oui..."


translate french e3s2_03dd73c2:


    d "En tous cas merci!"


translate french e3s2_f06a7085:


    cha "Fais pas le timide avec moi! Je ne mords pas! Quoi que... Si on me le demande gentiment..."


translate french e3s2_84242d48:


    d "Je suis pas très à l'aise pour parler avec les gens ici encore. Ca n'a rien de personnel."


translate french e3s2_e89828e2:


    cha "Oui je comprends. Rencontrer tellement de gens d'un coup et perdre ses repères."


translate french e3s2_bec77bc1:


    d "C'est ça."


translate french e3s2_b3d1e3a6:


    cha "Mais ça ne t'a pas empêché de te jeter dans la gueule du loup pour une demoiselle en détresse que tu ne connais que depuis quelques jours."


translate french e3s2_9ce586db:


    d "Ben... Vu comme ça... C'est un peu con oui. j'ai juste agi par instinct."


translate french e3s2_2085f4f1:


    cha "Con? Nan! Impressionnant ! C'est pas tous les jours que quelqu'un a le courage d'intervenir et de défendre une femme."


translate french e3s2_853db437:


    cha "Ca pique ma curiosité."


translate french e3s2_aa5d264e:


    d "Ah vraiment?"


translate french e3s2_28ead7f2:


    cha "Ben oui! Ca me donne envie d'en savoir plus sur toi. D'où tu viens, ce que tu fais..."


translate french e3s2_28985498:


    d "C'est pas très interessant tu sais."


translate french e3s2_a124aa82:


    cha "Pour moi ça l'est! Tu as aidé Julia, t'es un héros! Tu peux te lâcher avec moi!"


translate french e3s2_f338cc08:


    d "Heu..."


translate french e3s2_8d96a0f5:


    cha "Hey! J'ai pas soixante ans hein! Tu penses que je fais vieille?"


translate french e3s2_973b12eb:


    d "Sans vouloir vous manquer de respect... Vous n'êtes pas mon genre. Je préfère en rester là."


translate french e3s2_c3e5e858:


    cha "Huh?"


translate french e3s2_9df72a84:


    d "Encore merci pour le chocolat."


translate french e3s2_497f2de3:


    cha "Heu... D'accord."


translate french e3s2_3a27a1c5:


    cha "Etrange garçon."


translate french e3s2_1e387d97:


    d "Vieille? Nan! Et puis l'âge n'est pas important, si?"


translate french e3s2_174c156d:


    cha "Vas y, continue..."


translate french e3s2_e8c8cd80:


    d "Si je venais à sortir avec une femme plus âgée, que ce soit entre amis ou plus, je pense que je serais fier de t'avoir à mes côtés. Donc l'âge n'est pas important."


translate french e3s2_5e85b9f6:


    cha "Fier?"


translate french e3s2_3223290c:


    d "Ben oui! Avoir une femme active qui gère son commerce..."


translate french e3s2_7180550b:


    d "Une belle femme pour explorer la ville à ses côtés..."


translate french e3s2_d0ed1b72:


    d "Une femme d'expérience avec laquelle on peut tester plein de possibilités..."


translate french e3s2_d7e45884:


    cha "Okay, okay, c'est bon..."


translate french e3s2_a55a49c7:


    cha "Ecoute, il se fait tard. Je dois encore travailler."


translate french e3s2_861c4633:


    cha "Tu vas à la soirée demain soir?"


translate french e3s2_60d6331e:


    d "Oui."


translate french e3s2_48972c73:


    cha "Alors passe par ici avant d'y aller. Je serais là dans l'après-midi à faire mon inventaire."


translate french e3s2_3566bcd4:


    cha "Parfait. Alors on se voit demain?"


translate french e3s2_d20a6f4a:


    d "A demain, Charlotte."


translate french e3s2_c19b505a:


    cha "A demain, [name]."


translate french e3s2_973b12eb_1:


    d "Sans vouloir vous manquer de respect... Vous n'êtes pas mon genre. Je préfère en rester là."


translate french e3s2_c3e5e858_1:


    cha "Huh?"


translate french e3s2_4e34c614:


    d "Encore merci pour le chocolat chaud..."


translate french e3s2_ddc779e8:


    cha "Hum... Okay..."


translate french e3s2_e9f5a102:


    cha "Etrange garçon..."

translate french strings:


    old "Yes, of course."
    new "Oui, bien sûr."


    old "I'd rather not..."
    new "Je préfèrerais pas..."


    old "Okay, I'll stop in."
    new "Okay, je viendrais!"


    old "Uh... no, thanks!"
    new "Hum... Non, merci!"




translate french e3s2_804023bd:


    "Ahahahah!"


translate french e3s2_b235ac9e:


    julia "Bâtards!"


translate french e3s2_2302240e:


    julia "Humpfff..."


translate french e3s2_95b1505d:


    hec "Casse-toi sale pute!"


translate french e3s2_70d11f38:


    julia "Stop!"


translate french e3s2_e2fbc6f9:


    julia "Vous devez payer!"


translate french e3s2_769b2c2f:


    julia "Outch!"


translate french e3s2_8f910df6:


    hec "Je t'ai dit de nous laisser Pinkie!"


translate french e3s2_77d23ef5:


    hec "T'en as pas assez?"


translate french e3s2_a2431503:


    julia "Non! Je..."


translate french e3s2_12cbfb5a:


    hec "Prends ça connasse!"


translate french e3s2_d1d296af:


    julia "Hiiii!"


translate french e3s2_101332d7_1:


    julia "Huh?"


translate french e3s2_b1807fea:


    julia "Qu'est ce que...?"


translate french e3s2_dc11a5bc:


    hec "Qu'est ce que tu fous?"


translate french e3s2_f67fdb4c:


    julia "[name]!"


translate french e3s2_5f341222:


    hec "Et tu vas faire quoi hein? Je l'ai pas touché. Si tu me frappes y'aura des témoins. Et si tu as des ennuis avec la police..."


translate french e3s2_bc1784aa:


    cha "J'ai vu la scène. Mon dieu!"


translate french e3s2_1604c1be:


    d "[name]."


translate french e3s2_33b7d50d:


    cha "Retournons au magasin."


translate french e3s2_93e168f1:


    ji "Intéressant..."


translate french e3s2_4bc03d25:


    cha "Un gars comme ça... Crois-moi, t'en trouveras pas dix dans la ville. Tu devrais tenter ta chance."


translate french e3s2_6d3fade6:


    julia "Tu ne peux rien y faire. Y'aura toujours des cons qui essaieront de ne pas payer ou de nous faire chier... Encore plus avec ces vêtements."


translate french e3s2_bccda825:


    julia "Aïe!"


translate french e3s2_101332d7_2:


    julia "Huh?"


translate french e3s2_00c88aec:


    d "Exactement. Et c'est quoi ce truc avec tes lunettes? Des fois tu les mets, des fois non."


translate french e3s2_1adcfb1a:


    cha "Oh? Je les utilise qu'au travail pour lire et paraître plus... Mature! Mais pour un gars qui ne parle pas trop aux autres..."


translate french e3s2_22466bae:


    d "Sans vouloir vous manquer de respect... Vous n'êtes pas mon genre. Je préfère en rester là."



translate french strings:


    old "Yes, of course.[TEMP1!t]"
    new "Oui, bien sûr.[TEMP1!t]"


    old "I'd rather not...[TEMP2!t]"
    new "Je préfèrerais pas...[TEMP2!t]"


    old "Okay, I'll stop in.[TEMP1!t]"
    new "Okay, Je viendrais.[TEMP1!t]"


    old "Uh... no, thanks![TEMP2!t]"
    new "Uh... non, merci![TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
