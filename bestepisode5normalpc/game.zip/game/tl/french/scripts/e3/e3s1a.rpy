


translate french e3s1a_913c1b8d:


    ruby "Allez! Fais pas cette tête! Tu vas voir, je suis sûre qu'on va s'amuser!"


translate french e3s1a_df808924:


    d "J'en suis pas aussi sûr..."


translate french e3s1a_fe425094:


    ruby "Mais si! Et Rouge est super professionnelle! Je suis sûre qu'elle va nous trouver des trucs trop chouettes pour la soirée de demain!"


translate french e3s1a_2a6ac8ac:


    d "Nous?"


translate french e3s1a_5f3fc3b6:


    ruby "Ben oui NOUS! Demain c'est une soirée à thème! On t'a pas dit?"


translate french e3s1a_2940ea0e:


    d "Heu... Non?"


translate french e3s1a_979fa522:


    ruby "C'est une soirée spéciale chic et choc!"


translate french e3s1a_41d1ae04:


    d "Ca veut dire quoi?"


translate french e3s1a_90556121:


    ruby "Ben, le but c'est de s'habiller classe avec un élément qui dénote un peu... ou qui soit sexy..."


translate french e3s1a_5cadcfe2:


    d "Et comment veux-tu que je sois chic et choc?"


translate french e3s1a_470e5aa3:


    beth "Ca c'est mon travail."


translate french e3s1a_29ac5843:


    d "Hein?"


translate french e3s1a_bfc79f9d:


    ruby "Merci Elizabeth!"


translate french e3s1a_20ab99ea:


    beth "De rien. Je suis là pour ça tu sais!"


translate french e3s1a_a83292d0:


    beth "Ruby... Est ce que tu sais quel style est-ce que tu recherches?"


translate french e3s1a_25a5ce6d:


    ruby "En fait, pour une fois, j'en ai aucune idée..."


translate french e3s1a_4f1ceddc:


    beth "Je vais voir ce que je peux te trouver. Fais ton tour en attendant!"


translate french e3s1a_ea7bcd1b:


    ruby "Okay!"


translate french e3s1a_890030aa:


    ruby "Tu vois! Je te l'avais dit! Quand on est dans son magasin, c'est une autre fille!"


translate french e3s1a_e48c9cb0:


    d "Hmm..."


translate french e3s1a_f890b9d6:


    ruby "Bon, faut quand même qu'on trouve quelque chose... Des idées?"


translate french e3s1a_3bf529d7:


    d "Tout ce que tu mettras t'iras à ravir j'en suis sûr!"


translate french e3s1a_859f0f2e:


    ruby "Oh! T'es trop mignon!"


translate french e3s1a_3ee9764b:


    d "J'aimerais que tu mettes quelque chose qui mette en valeur ton corps. Tu es canon et tu ne le montre pas assez!"


translate french e3s1a_8cc00336:


    ruby "Oh? Heu... Je vais essayer..."


translate french e3s1a_7e930183:


    beth "Venez, j'ai pas mal de choses que vous pouvez essayer!"


translate french e3s1a_c05087df:


    ruby "On arrive!"


translate french e3s1a_a1a21cfb:


    beth "Tiens, Ruby, tu peux utiliser cette cabine."


translate french e3s1a_1efbcfae:


    ruby "Merci Elizabeth!"


translate french e3s1a_7248ffa2:


    beth "Par ici [name], J'ai d'autres choses pour toi aussi!"


translate french rubyshop_ed1da845:


    ruby "Tu peux regarder, ça ne me dérange pas!"


translate french rubyshop_2c3a63c7:


    d "Comment ça?"


translate french rubyshop_952add76:


    ruby "Tu t'es bien changé en face de moi dans ta chambre et j'ai pas fermé les yeux alors..."


translate french rubyshop_f338cc08:


    d "Heu..."


translate french rubyshop_cc0022e7:


    ruby "Tiens tiens... C'est qui le timide maintenant?"


translate french rubyshop_9e0087a7:


    d "Je suis pas timide!"


translate french rubyshop_ec40631d:


    ruby "Alors viens m'aider à retirer ma robe..."


translate french rubyshop_29ac5843:


    d "Quoi?"


translate french rubyshop_1bb724e6:


    ruby "Ma robe. La fermeture coince et j'arrive pas à l'attraper!"


translate french rubyshop_8d0a4a6e:


    d "Ah... D'accord!"


translate french rubyshop_e2889d3c:


    ruby "Ahhhhhh!"


translate french rubyshop_8ae3f02b:


    ruby "Merci."


translate french rubyshop_23b2f656:


    ruby "Tu peux aller t'asseoir. Je vais te montrer celles que je préfère et tu me diras laquelle tu choisirais!"


translate french rubyshop_40ab082c:


    d "Ca me va!"


translate french rubyshop2_18748a7f:


    ruby "Tu en penses quoi?"


translate french rubyshop2_6366f041:


    d "Pas mal, mais je ne suis pas sûr que c'est ce que j'appelerais chic et choc..."


translate french rubyshop2_56516992:


    ruby "Ouais. T'as raison."


translate french rubyshop2_c2881933:


    d "Wow..."


translate french rubyshop2_f9611e40:


    d "T'es à tomber!"


translate french rubyshop2_57fa5bbe:


    d "Mais comment c'est possible? Tout te va comme un gant!"


translate french rubyshop2_7034f0b6:


    ruby "Laquelle tu préfères?"


translate french rubyshop2_0bfcc6ba:


    d "Franchement... Je peux pas me décider. Tu es canon dans chacun d'elles!"


translate french rubyshop2_53917e62:


    ruby "Okay... Bon ben je choisirais et je te ferais la surprise demain soir!"


translate french rubyshop2_e0a25cf5:


    d "J'aime bien le concept!"


translate french redshop_43398bf1:


    d "Qu'est ce que..."


translate french redshop_12681d03:


    beth "Chut!"


translate french redshop_146362be:


    ruby "Qu'est ce qui se passe?"


translate french redshop_7d28839c:


    d "Rien rien! J'ai juste été surpris par les vêtements!"


translate french redshop_60c4b680:


    ruby "Oh! D'accord! Tu sais que tu n'as pas besoin de porter quelque chose de fou non plus hein! Juste chic et choc!"


translate french redshop_c6f2cd3d:


    d "Putain, c'est profond!"


translate french redshop_2307991b:


    ruby "De quoi ?"


translate french redshop_bcd68d7a:


    d "Hum... Je disais que tu avais des pensées profondes!"


translate french redshop_e6fa808c:


    ruby "Oh... Tu penses?"


translate french redshop_731e5fce:


    d "Je... Je... Je ne peux..."


translate french redshop_b4af70db:


    ruby "T'inquiètes pas. Tu peux te lâcher avec moi hein!"


translate french redshop_64f0d24d:


    d "Me lâcher? T'en es sûre?"


translate french redshop_1c0a8c41:


    beth "Humhum..."


translate french redshop_94364417:


    ruby "Bien sûr!"


translate french redshop_8fc1ec88:


    d "Ahhhhhhh! Ca fait du bien!"


translate french redshop_8c5e2da6:


    ruby "Je pensais pas que je pouvais avoir cet effet..."


translate french redshop_c665f1b6:


    d "Je me sens vidé!"


translate french redshop_e47ecb4c:


    ruby "C'est le but! Te vider l'esprit pour être relaxé!"


translate french redshop_8655210a:


    d "Tu ne sais rien, Jon Snow."


translate french redshop_af29a28e:


    ruby "Hey! C'est ma phrase!"


translate french redshop_f5f0c740:


    d "Ahah!!!"


translate french redshop_219a4a36:


    d "Et toi?"


translate french mcshop_92592ec0:


    ruby "Et toi?"


translate french mcshop_0beb0af8:


    beth "Ne t'inquiètes pas pour lui. Je lui emmènerais son costume demain à la soirée! Je sais parfaitement ce dont il a besoin!"


translate french mcshop_dee5c425:


    d "Heu... T'es sûre?"


translate french mcshop_19e14c97:


    ruby "Ah génial! On sera tous les deux surpris!"


translate french mcshop_e81f6775:


    d "Je ne suis pas sûr que..."


translate french mcshop_1d773b28:


    beth "Oui oui! Ne t'inquiètes pas! Même Emerick ne sera pas aussi beau demain soir!"


translate french mcshop_7662c915:


    d "Mais et si..."


translate french mcshop_fb897691:


    ruby "Ca me va! Il faut mettre en avant mon Cortex! Il doit être étincelant!"


translate french mcshop_a774e662:


    beth "Je te le promets Ruby! Il le sera..."


translate french mcshop_84464bc4:


    ruby "Super! Bon allez il faut que j'y aille. Il se fait tard, et il faut que je sois reposée pour demain!"


translate french mcshop_58cf6d6d:


    ruby "[name], tu viens?"


translate french mcshop_0cde5eaa:


    d "Ben en fait j'avais prévu d'aller me manger un petit truc avant de rentrer."


translate french mcshop_055b97ca:


    ruby "Oh? Ben au pire tu vas un peu plus loin à gauche au coin de la rue, il y a quelques restaurants!"


translate french mcshop_fbc4a3b1:


    d "Parfait! Merci pour le conseil!"


translate french mcshop_a40b363d:


    ruby "Bon... Tu me préviens quand t'es rentré?"


translate french mcshop_320e0c8a:


    d "Euh... Oui... Si tu veux..."


translate french mcshop_5ab4406d:


    ruby "Je sais que ça fait un peu surprotectrice mais j'aime pas laisser les gens que j'aime seuls la nuit dans cette ville."


translate french mcshop_02721b20:


    d "Oh? C'est mignon! Mais ne t'inquiète pas. Tout ira bien."


translate french mcshop_beb57c11:


    ruby "Okay... Alors à demain!"


translate french mcshop_0eaf48fc:


    d "A demain!"


translate french mcshop_c645839b:


    d "Tu n'as pas de costume pour moi n'est-ce pas?"


translate french mcshop_701a8840:


    beth "Bien sûr que si! Je te l'emmènerais demain!"


translate french mcshop_134c20f9:


    d "Sérieusement?"


translate french mcshop_c313eee8:


    beth "Evidemment! Je t'ai dit que si tu me satisfait... Tu seras récompensé."


translate french mcshop_291126b8:


    beth "Et tu l'as fait... Avec ce que tu m'as donné tout à l'heure..."


translate french mcshop_ce4e4abc:


    beth "Donc on se voit demain avant la fête, je te donnerai ça."


translate french mcshop_4b78c937:


    d "Ca me va! A demain alors!"


translate french mcshop_79e0c399:


    beth "A demain!"


translate french mcshop_c8810e50:


    beth "Bien sûr que non. Démerde-toi tout seul."


translate french mcshop_b7ff5f06:


    d "T'es sérieuse?"


translate french mcshop_82668fcd:


    beth "Tu ne sais pas à qui tu as à faire le Frenchie. Tu vas bientôt le comprendre."


translate french mcshop_06e7f82f:


    d "Euh... okay... A demain, je suppose."


translate french mcshop_054b635f:


    beth "A demain."

translate french strings:


    old "Follow Red"
    new "Suivre Rouge"


    old "Stay with Ruby"
    new "Rester avec Ruby"




translate french e3s1a_53611aa8:


    d "C'est maintenant qu'on va s'amuser!"


translate french rubyshop_ad43ddfc:


    ruby "Hummmm..."


translate french rubyshop_75127a40:


    ruby "Ohhhh..."


translate french rubyshop_492766ce:


    ruby "Uhhhh"


translate french rubyshop_a905bd37:


    ruby "Euh..."




translate french redshop_2e748302:


    beth "Il va falloir que je m'en occupe moi-même si je veux que tu viennes rapidement..."


translate french redshop_9d9f175f:


    beth "Et je veux pas que tu souilles ma cabine... Donc..."

translate french strings:


    old "Follow Red[TEMP1!t]"
    new "Suivre Rouge[TEMP1!t]"


    old "Stay with Ruby[TEMP2!t]"
    new "Rester avec Ruby[TEMP2!t]"




translate french rubyshop_95230105:


    ruby "Ma robe. La fermeture est bloquée et je peux pas l'atteindre!"


translate french mcshop_a829e67e:


    d "Ben en fait j'avais prévu d'aller manger un petit truc avant de rentrer."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
