


translate french e3s1b_3e99e6fe:


    d "Il faut que je travaille dûr si je veux être au niveau des autres..."


translate french e3s1b_e0b40846:


    d "Je dois m'améliorer."


translate french e3s1b_02909704:


    d "Le prochain match sera plus dûr."


translate french e3s1b_4d6de57e:


    d "Il va falloir que je me surpasse et que je donne tout."


translate french e3s1b_a2c0471f:


    ji "Pas mal."


translate french e3s1b_19e694e7:


    ji "Ca serait mieux si c'était dans le but."


translate french e3s1b_675025bd:


    ji "Tu dois travailler ton placement de pied."


translate french e3s1b_85a51d50:


    d "Hein???"


translate french e3s1b_ca5c561e:


    gaby "Ton pied. La façon dont tu le places pour tirer."


translate french e3s1b_0bafbbe5:


    gaby "Plante ton pied quand tu tires et mets ton poids vers l'avant, tu pourras transférer toute ta force à la balle."


translate french e3s1b_4539f447:


    d "Transférer toute la force?"


translate french e3s1b_8fa50577:


    gaby "Oui. Si tu vas en arrière, la balle va monter. Si tu vas vers l'avant, la balle va prendre toute la puissance et tu pourras mettre plus d'effet dedans."


translate french e3s1b_be887b2f:


    d "Euh... Je savais pas ça..."


translate french e3s1b_54134b7b:


    gaby "Vas y essaie!"


translate french e3s1b_1523fe20:


    d "..."


translate french e3s1b_fef6c142:


    d "C'est pas encore ça. J'arrive pas à bien taper dedans."


translate french e3s1b_2ce8734d:


    gaby "Tu y arriveras."


translate french e3s1b_01d6fdfd:


    d "Comment savez-vous tout ça?"


translate french e3s1b_5939427c:


    gaby "Je suis entraîneur tu sais ! Et il fut un temps où je jouais aussi..."


translate french e3s1b_7441657c:


    gaby "Quand j'étais jeune."


translate french e3s1b_192e17bc:


    d "Vous êtes toujours jeune."


translate french e3s1b_e93a360f:


    gaby "Hum... Je suppose que je le suis encore un peu. Je ne suis juste plus la même."


translate french e3s1b_f22eeffc:


    gaby "J'ai pas le corps que j'avais."


translate french e3s1b_17d5107e:


    gaby "Le passage du temps comme on dit..."


translate french e3s1b_8c82d0dd:


    d "Excusez-moi mais vous vous sous-estimer."


translate french e3s1b_80e32e55:


    d "Vous êtes absolument magnifique. Même le temps semble ne pas avoir d'impact sur vous."


translate french e3s1b_5b7cd72d:


    d "N'importe quel homme serait fou de ne pas voir une femme aussi séduisante que vous."


translate french e3s1b_525161b0:


    d "Désolé... C'est sorti tout seul."


translate french e3s1b_5ec68acb:


    gaby "Je m'attendais pas à ça de la part d'un de mes étudiants..."


translate french e3s1b_8bddce5e:


    gaby "C'est très flatteur. Mais je ne pense pas que ce soit très approprié."


translate french e3s1b_024817af:


    gaby "Même si j'aimerais que tout le monde pense comme toi."


translate french e3s1b_ac0eb531:


    d "Je n'essayais pas de vous flâter. Je dis juste ce que je pense."


translate french e3s1b_718af70d:


    gaby "Garde-le pour toi alors. Tu pourrais nous attirer des ennuis si quelqu'un entendait ces propos. Aucun d'entre nous ne veut de ça n'est-ce pas?"


translate french e3s1b_2c6e3916:


    d "Vous étiez mieux avant? Je vous ai vu en maillot l'autre jour à la piscine et laissez-moi vous dire que vous avez un corps de rêve!"


translate french e3s1b_070198d1:


    gaby "De quoi?"


translate french e3s1b_cdbfaf2a:


    d "Nan mais sérieusement vous êtes une bombe! Je sais pas comment le dire autrement!"


translate french e3s1b_9c8bdb3b:


    d "Si j'étais votre homme je voudrai que le monde soit au courant! Et croyez-moi que je ne raterais pas ma chance d'apprécier et d'explorer vos jolies formes!"


translate french e3s1b_db0ae612:


    gaby "Je ne crois pas que ces propos soient très appropriés [name]."


translate french e3s1b_40493fb5:


    d "Je sais mais c'est la vérité! Nan mais sans déconner. Regardez-vous! Si vous vous regardez dans le miroir et que vous ne voyez pas la beauté absolue que vous êtes... C'est que vous êtes aveugle!"


translate french e3s1b_7f87e2f2:


    d "Je ne sais pas ce qui s'est passé pourque vous pensiez ça. Mais c'est débile!"


translate french e3s1b_2071d2fd:


    d "Si un idiot vous a maltraité dans le passé, vous devez l'oublier. Relevez la tête et avancez parce que vous êtes clairement trop belle pour penser de cette façon!"


translate french e3s1b_ca335262:


    gaby "Hum... Je crois que je vais y aller."


translate french e3s1b_b02ad822:


    gaby "Retourne à ton entraînement. Tu es sur le bon chemin."


translate french e3s1b_d3c7b6ea:


    d "Je vais donner le meilleur de moi."


translate french e3s1b_4d2be1f1:


    d "Un dernier conseil avant le prochain match?"


translate french e3s1b_31a27688:


    gaby "Oh? Heu... Joue avec la barre."


translate french e3s1b_0db8c8d0:


    d "La barre?"


translate french e3s1b_21784a96:


    gaby "A plus tard, jeune homme."


translate french e3s1b_bcf01860:


    d "Heu, ouais... A plus tard."


translate french e3s1b_7c9441d9:


    d "Qu'est ce qu'elle voulait dire par 'joue avec la barre?'"


translate french e3s1b_a132824f:


    d "Bon... D'abord... Positionner mon corps en avant..."


translate french e3s1b_2ad9be58:


    gaby "Assez audacieux mais ce gosse a raison."


translate french e3s1b_154f3cbd:


    gaby "Il faut que j'arrête de me cacher..."


translate french e3s1b_ea375fba:


    gaby "Enfin bon, ça fait longtemps qu'on ne m'avait pas parlé comme ça."


translate french e3s1b_3ea324e1:


    gaby "Stop Gaby. Remets-toi. C'est qu'un étudiant..."




translate french e3s1b_c7644af0:


    d "Si j'étais votre homme je voudrai que le monde soit au courant! Et croyez-moi que je ne raterais pas ma chance d'apprécier et d'explorer vos jolies formes!"



translate french strings:


    old "Education[TEMP1!t]"
    new "Education[TEMP1!t]"


    old "Temperament[TEMP2!t]"
    new "Temperament[TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
