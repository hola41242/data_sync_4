


translate french e3s4_43b49e4c:


    d "Okay."


translate french e3s4_2764ca10:


    d "J'ai promis à Ruby de lui envoyer un message une fois rentré."


translate french e3s4_fb7cad08:


    d "Enfin... Je vais pouvoir dormir. Quelque chose me dit que demain ne sera pas une journée ordinaire."


translate french e3s4_cecbb726:


    dpense "Que les surprises viennent. Après tout, c'est dans l'imprévu que les vraies aventures commencent..."

translate french strings:


    old "Minus... you awake?"
    new "Minus... T'es réveillée?"


    old "Of course! I was worried about you!"
    new "Evidemment! Je m'inquiétais pour toi!"


    old "You're so sweet!"
    new "T'es trop chou!"


    old "You think so?"
    new "Ah bon?"


    old "Absolutely! I couldn't ask for a better friend!"
    new "Ben oui! Je ne pourrais pas avoir une meilleure amie!"


    old "I know I'm the B.E.S.T !"
    new "Je sais! Je suis la B.E.S.T!"


    old "Ahah! For sure!"
    new "Ahah! C'est sûr!"


    old "Good night, my acolyte! "
    new "bonne nuit mon acolyte!"


    old "Sweet dreams, my partner!"
    new "Fais de beaux rêves mon partenaire!"




translate french e3s4_9f40912c:


    d "???" with hpunch


translate french e3s4_6eb69ed4:


    d "Un autre message?"


translate french e3s4_db4f6715:


    d "Pas de réponse..."

translate french strings:


    old "Ahah! For sure! So... I'm back in my room."
    new "Ahah! Evidemment! Bon... Je suis dans ma chambre."


    old "Great! I'm relieved!"
    new "Super! Je suis rassurée!"


    old "Good night, my acolyte!"
    new "Bonne nuit, mon acolyte!"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
