


translate french e3intro_0be561b1:


    ruby "Hmpfff !"


translate french e3intro_95eb778b:


    ruby "Je sais vraiment pas quoi me mettre... Avec la soirée chez Grace..."


translate french e3intro_35c89622:


    ruby "Et la soirée au cinéma avec [name]..."


translate french e3intro_fc09bfd6:


    ruby "Il va falloir me surpasser..."


translate french e3intro_7156630f:


    ruby "Est ce que je devrai mettre quelque chose de... sexy?"


translate french e3intro_b924fffa:


    ruby "Ou plutôt classe?"


translate french e3intro_7fcb6cfe:


    ruby "Vous en dîtes quoi les filles?"


translate french e3intro_18748a7f:


    ruby "Qu'est ce que vous en pensez?"


translate french e3intro_d2eebdc0:


    ruby "Quelque chose..."


translate french e3intro_902e1a01:


    ruby "Un peu cyber?"


translate french e3intro_c4cb47c6:


    ruby "Ou plus élégant?"


translate french e3intro_41ca40a0:


    ruby "Ohhh... Je devrais aller m'acheter de nouvelles robes!"


translate french e3intro_d0053bde:


    ruby "Peut être que [name] voudrait bien m'accompagner?"


translate french e3intro_79bde7bc:


    ruby "J'aimerais vraiment qu'il m'aide à choisir."


translate french e3intro_6d6299b3:


    ruby "Je parie qu'il dort !"




translate french e3intro_2d24ae24:


    ruby "Est ce que je devrais porter quelque chose de sexy..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
