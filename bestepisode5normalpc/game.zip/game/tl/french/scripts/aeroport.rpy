


translate french aeroport_6479b2d0:


    "Un vent frais dans l'air... un nouveau pays, une nouvelle culture, de nouvelles têtes..."


translate french aeroport_90069092:


    "TOUT CE QUE JE T'AI DEMANDE C'ETAIT DE PRENDRE SOIN D'ELLE PENDANT QUE JE NE SUIS PAS LA !"


translate french aeroport_b01ab77e:


    mad "Tu vas me dire que t'as pas remarqué qu'elle était en train de s'étrangler avec sa sucette ?"


translate french aeroport_51e64b91:


    mad "J'arrive dans quelques heures... garde la au calme..."


translate french aeroport_f8b850ec:


    d "TAXI !"


translate french aeroport_60fb3963:


    mad "C'est le mien !"


translate french aeroport_80be1ed7:


    d "Je ne crois pas non."


translate french aeroport_ed1ba37f:


    mad "OH SI c'est le mien !"


translate french aeroport_592db3fe:


    mad "Tu ne crois pas que je vais laisser un obsédé comme toi, qui a osé peloter ma copine, prendre l'avantage de la situation !"


translate french aeroport_f0452d08:


    d "Qu'est ce qu'elle t'a raconté ?"


translate french aeroport_491bf422:


    mad "J'ai pas de temps pour toi. Je me casse et toi, tu te démerdes et tu en trouves un autre !"


translate french aeroport_6723e0fa:


    dpense "Je vais pas la laisser prendre mon taxi comme ça !"


translate french aeroport_dc7b7945:


    d "Je viens aussi ! Chauffeur, emmenez-moi à l'Academy!"


translate french aeroport_da030b0e:


    mad "C'est une blague ? Tu penses vraiment que tu vas partager la course avec moi ?"


translate french aeroport_ffd51a85:


    d "Je ne crois pas, je le fais. Tu peux gueuler sur qui tu veux mais je te connais pas et j'ai pas peur de toi donc tu stopped tes cris de suite, on partage ce taxi et ce sera fini rapidement. "


translate french aeroport_028833a5:


    mad "Ohhh...kay. Mais c'est toi qui payes."


translate french aeroport_bb672df5:


    d "Si sa majesté le désire..."


translate french aeroport_50044fd5:


    dpense ""


translate french aeroport_693ad106:


    d ""


translate french aeroport_83047253:


    mad ""


translate french aeroport_01bade5b:


    mad ""


translate french aeroport_ce392a47:


    d ""


translate french aeroport_61480ab5:


    mad ""


translate french aeroport_4c7c06a1:


    ""


translate french aeroport_635761a9:


    dpense ""


translate french aeroport_e3a00068:


    d ""


translate french aeroport_9f671f65:


    d ""


translate french aeroport_59b1225a:


    mad ""


translate french aeroport_b0009690:


    mad ""


translate french aeroport_431fe540:


    mad ""


translate french aeroport_5e75c83d:


    mad ""


translate french aeroport_383e0b2e:


    dpense ""


translate french aeroport_3d40f4e9:


    dpense ""


translate french aeroport_945187c8:


    dpense ""


translate french aeroport_c1636122:


    dpense ""


translate french aeroport_f1d33904:


    dpense ""


translate french aeroport_14c2256c:


    mad ""


translate french aeroport_86ec9c56:


    d ""


translate french aeroport_39483a46:


    ""


translate french aeroport_1523fe20:


    d ""


translate french aeroport_b62e41c7:


    ""


translate french aeroport_3a9e4dc8:


    mad ""


translate french aeroport_2a44e1df:


    d ""


translate french aeroport_aea6c305:


    mad ""


translate french aeroport_63147c42:


    d ""


translate french aeroport_d5c15180:


    mad ""


translate french aeroport_99be39be:


    d ""


translate french aeroport_441adbd5:


    mad ""


translate french aeroport_ff57f6b2:


    mad "Ecoute... sois un bon toutou et va voir ailleurs si y'à pas un autre taxi."


translate french aeroport_2cb1f5cf:


    d "Mais... c'est moi qui l'ai appelé !"


translate french aeroport_159a23f2:


    mad "Et ?"


translate french aeroport_b8b1a077:


    d "Et..."


translate french aeroport_57b13636:


    dpense "Je dois faire quoi dans cette situation moi ?"


translate french aeroport_e61ffcaa:


    d "On peut partager ?"


translate french aeroport_92c1c803:


    mad "Quoi ?"


translate french aeroport_419d30fe:


    d "Partager...la course..."


translate french aeroport_f351df9d:


    mad "Je ne partage pas..."


translate french aeroport_cae88d96:


    mad "Bon... Tu payes..."


translate french aeroport_5b23d55a:


    d "Si ça peut lui faire plaisir..."


translate french aeroport_50044fd5_1:


    dpense ""


translate french aeroport_693ad106_1:


    d ""


translate french aeroport_9ddac02b:


    mad ""


translate french aeroport_cc8e9b26:


    mad ""


translate french aeroport_77c589b8:


    d ""


translate french aeroport_081c1dc0:


    mad ""


translate french aeroport_a2733830:


    d ""


translate french aeroport_1ea2be44:


    mad ""


translate french aeroport_aabcec33:


    mad ""


translate french aeroport_caf5436f:


    d ""


translate french aeroport_0e2d238f:


    mad ""


translate french aeroport_2c34c040:


    ""


translate french aeroport_b62e41c7_1:


    ""


translate french aeroport_3a9e4dc8_1:


    mad ""


translate french aeroport_ec1d8796:


    d ""


translate french aeroport_928c81df:


    mad ""


translate french aeroport_54008a47:


    d ""


translate french aeroport_01f8e1a4:


    mad ""




translate french aeroport_378e7b4d:


    dpense "Un vent frais dans l'air... un nouveau pays, une nouvelle culture, de nouvelles têtes..."


translate french aeroport_b07237c8:


    dpense "Je suis le dernier... Ils sont déjà tous partis..."


translate french aeroport_808acf6d:


    dpense "Bienvenue en Amérique !"


translate french aeroport_555b6725:


    "TOUT CE QUE JE TE DEMANDAIS C'ETAIT DE PRENDRE SOIN D'ELLE PENDANT QUE JE NE SUIS PAS LA !"


translate french aeroport_08cefcd4:


    mad "J'arrive dans quelques minutes... Calme-la."


translate french aeroport_196a6471:


    d "TAXI !" with hpunch


translate french aeroport_28476fec:


    mad "Tu ne crois pas que je vais laisser un obsédé comme toi, qui a peloté ma copine, prendre ce taxi avant moi ?"


translate french aeroport_cdf632a0:


    d "Je ne crois pas, je le fais. Tu peux gueuler sur qui tu veux mais je ne te connais pas et je n'ai pas peur de toi donc arrêtes tout de suite, on partage le taxi et tout sera fini vite fait."


translate french aeroport_64483950:


    "Est-ce que c'est le dernier Mrs. Drew?"


translate french aeroport_0dad8306:


    "Oui Mr. Orushi. C'est celui qui vient de France. Comme vous l'aviez demandé."


translate french aeroport_01ce3c63:


    "C'est parfait Mme Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_6daca298:


    "Et comment vont les autres ?"


translate french aeroport_56769502:


    "Ils sont tous rentrés chez eux ou sur le campus pour la nuit. Leurs bagages ont été gardés comme vous l'aviez ordonné."


translate french aeroport_da22c79c:


    "Enfin, nous avons nos 100 participants."


translate french aeroport_0deee60a:


    "Demain, the B.E.S.T game va pouvoir démarrer !"


translate french aeroport_dfd3d591:


    "Tu entends ça Mr. Rufus ?"


translate french aeroport_533d812c:


    "RrrrrrrrrrrrRRRRrrrrrrrr..."


translate french aeroport_4ec2a007:


    "Que le spectacle commence !"


translate french aeroport_cbcfa3e5:


    mad "Okay... Mais c'est toi qui payes..."


translate french aeroport_64483950_1:


    "Est ce que c'est le dernier Mrs. Drew ?"


translate french aeroport_0dad8306_1:


    "Oui Mr. Orushi. C'est le gars qui vient de France. Comme vous l'aviez demandé."


translate french aeroport_01ce3c63_1:


    "C'est parfait Mme. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_6daca298_1:


    "Et comment vont les autres ?"


translate french aeroport_56769502_1:


    "Ils sont de retour chez eux ou sur le campus pour la nuit. Leurs bagages ont été gardés comme vous nous l'aviez ordonné."


translate french aeroport_da22c79c_1:


    "Enfin. Nous avons nos 100 participants."


translate french aeroport_0deee60a_1:


    "Demain, le jeu B.E.S.T va pouvoir démarrer !"


translate french aeroport_dfd3d591_1:


    "Vous entendez ça Mr. Rufus ?"


translate french aeroport_533d812c_1:


    "RRRRrrrrrrrrrrrrrrrRRRRRRRrrrrrrr..."


translate french aeroport_4ec2a007_1:


    "Que le spectacle commence !"




translate french aeroport_9c7a3f11:


    "C'est parfait Mme. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_9c7a3f11_1:


    "C'est parfait Mme. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."




translate french aeroport_1074c833:


    dpense "Ahhh ! de l'air frais... un nouveau pays, une nouvelle culture, de nouveaux gens à rencontrer..."


translate french aeroport_e4ca3e2d:


    mad "T'es en train de me dire que t'as pas remarqué qu'elle s'étouffait avec sa tétine ???"


translate french aeroport_6341bbd3:


    mad "J'arrive dans quelques minutes... juste garde la calme..."


translate french aeroport_2e114641:


    mad "Tu ne croyais quand même pas que j'allais laisser un obsédé comme toi, qui a peloté mon équipière, prendre un taxi avant moi ?"


translate french aeroport_25e103b1:


    mad "J'ai pas le temps pour toi. J'y vais et toi tu t'en trouves un autre !"


translate french aeroport_59188c12:


    mad "C'est une blague ? Tu penses vraiment que tu vas partager la course avec moi ?"


translate french aeroport_a207a849:


    d "Je ne pense pas, je le fais. Tu peux être dûre avec qui tu veux mais avec moi ça marche pas. Je ne te connais pas et je n'ai pas peur de toi donc tu arrêtes ton attitude de suite, on partage ce taxi et tout sera fini bien assez tôt."


translate french aeroport_a09afd48:


    "Ils sont tous rentrés chez eux ou sur le campus pour la nuit. Leurs bagages ont été gardés comme vous l'avez ordonné."


translate french aeroport_7cd48552:


    "Tu es content Mr. Rufus ?"


translate french aeroport_37586ce9:


    mad "Ecoute... sois un bon toutou et va voir ailleurs si tu trouves un autre taxi de libre."


translate french aeroport_f4b1a052:


    dpense "Qu'est ce que je dois faire dans cette situation ?"


translate french aeroport_a09afd48_1:


    "Ils sont tous rentrés chez eux ou sur le campus pour la nuit. Leurs bagages ont été gardés comme vous l'avez ordonné."




translate french aeroport_b983271d:


    mad "Ecoute-moi bien, frère stupide et incompétent ! Je serai là dans quelques minutes... calme-la le temps que j'arrive..."


translate french aeroport_642a4241:


    d "Je ne pense pas, je le sais. Je ne te connais pas et j'ai pas peur de toi donc stoppe tout de suite ton attitude ou sors de ce taxi ! Sinon on partage ce taxi et ce sera fini rapidement."


translate french aeroport_de3c83e7:


    mad "Ohh..."


translate french aeroport_064f9f51:


    d "Et on partage ! Je t'ai pas invité !"


translate french aeroport_fd8e2ede:


    mad "Quel gentleman..."


translate french aeroport_4352eddb:


    drew "Oui Mr. Orushi. C'est le gars qui vient de France. Comme vous l'aviez demandé."


translate french aeroport_7116406b:


    orushi "Parfait Mrs. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_7844bdbe:


    orushi "Et comment vont les autres ?"


translate french aeroport_2acca557:


    drew "Ils sont tous rentrés chez eux ou sur le campus pour la nuit. Leurs bagages ont été gardés comme vous l'avez ordonné."


translate french aeroport_d5ab5b44:


    orushi "Enfin. Nous avons nos 100 participants."


translate french aeroport_41d0c460:


    orushi "Demain, le B.E.S.T va pouvoir démarrer !"


translate french aeroport_5ddfbed5:


    orushi "Vous avez entendu ça Mr. Rufus ?"


translate french aeroport_14d7b0f5:


    orushi "Que le spectacle commence !"


translate french aeroport_e19a32cd:


    d "Ecoutez, j'ai appelé ce taxi, mais je vois que vous êtes pressée et que vous avez des problèmes, alors pourquoi ne pas partager ?"


translate french aeroport_c306829f:


    d "Je vais même payer vu que de toute façon j'allais payer pour ma course et puis je n'ai pas envie d'attendre."


translate french aeroport_21823f25:


    mad "D'accord... Merci... je suppose..."


translate french aeroport_d3b6a486:


    d "Maintenant, reposez vous, vous avez besoin de vous calmer. Vous ne pouvez pas hurler sur tout le monde comme ça..."


translate french aeroport_4352eddb_1:


    drew "Oui Mr. Orushi. C'est le gars qui vient de France. Comme vous l'aviez demandé."


translate french aeroport_7116406b_1:


    orushi "Parfait Mrs. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_7844bdbe_1:


    orushi "Et comment vont les autres ?"


translate french aeroport_2acca557_1:


    drew "Ils sont tous rentrés chez eux ou sur le campus pour la nuit. Leurs bagages ont été gardés comme vous l'avez ordonné."


translate french aeroport_d5ab5b44_1:


    orushi "Enfin. Nous avons nos 100 participants."


translate french aeroport_41d0c460_1:


    orushi "Demain, le B.E.S.T va pouvoir démarrer !"


translate french aeroport_bb4cf1c0:


    orushi "Vous avez entendu ça Mr. Rufus ?"


translate french aeroport_14d7b0f5_1:


    orushi "Que le spectacle commence !"



translate french strings:


    old "A NEW LIFE...."
    new "UNE NOUVELLE VIE..."




translate french aeroport_58f747bb:


    d "Et on partage la course ! Je t'ai pas invité !"




translate french aeroport_33058132:


    mad "Tu ne crois quand même pas que je vais laisser un gars qui touche mes copines prendre un taxi avant moi ?"


translate french aeroport_40bc89bc:


    mad "C'est une blague ? Tu crois vraiment que tu vas partager ce taxi avec moi ?"


translate french aeroport_6e3b1b13:


    drew "Ils sont rentrés chez eux ou sur le campus pour la nuit. Leur bagage a été récupéré comme vous l'avez demandé."


translate french aeroport_ed92ac6c:


    d "Je vais même payer puisque de toute façon j'allais le faire et puis j'ai pas envie d'attendre."


translate french aeroport_4a9ad471:


    d "Maintenant... Repose toi... Tu as besoin de te calmer. On ne peut pas gueuler sur tout le monde comme ça..."


translate french aeroport_6e3b1b13_1:


    drew "Ils sont rentrés chez eux ou sur le campus pour la nuit. Leur bagage a été récupéré comme vous l'avez demandé."




translate french aeroport_f4a872b8:


    dpense "Ahhh de l'air frais.... Un nouveau pays, une nouvelle culture, de nouvelles personnes à rencontrer..."




translate french aeroport_1bf3f63c:


    d "Je ne pense pas, je le sais. Je ne vous connais pas et j'ai pas peur de vous donc stoppez tout de suite cette attitude avec moi ou sortez de ce taxi ! Sinon on partage ce taxi et ce sera fini rapidement."


translate french aeroport_b63493c8:


    d "Et on partage la course ! Je ne vous ai pas invité !"


translate french aeroport_897eabbe:


    mad "Ecoute... Sois un bon toutou et va t'en chercher un autre."


translate french aeroport_c27801fc:


    d "Mais... C'est moi qui l'ai appelé !"


translate french aeroport_e9d9321a:


    d "Partager... La course..."


translate french aeroport_fe0cba53:


    d "Maintenant, essayez de vous calmer et prenez une bonne respiration. Vous ne pouvez pas aboyer sur les gens comme ça..."



translate french strings:


    old "You've found a RUFUS !"
    new "Vous avez trouvé un RUFUS !"



translate french strings:


    old "Rrrrrrrrrrrrrrrrr..."
    new "Rrrrrrrrrrrrrrr..."




translate french aeroport_5398bcd5:


    dpense "Un vent frais dans l'air... un nouveau pays, une nouvelle culture, de nouvelles têtes..."


translate french aeroport_e9a0d30e:


    dpense "Je suis le dernier... Ils sont déjà tous partis..."


translate french aeroport_211e98a9:


    dpense "Bienvenue en Amérique !"


translate french aeroport_5179d2f2:


    "TOUT CE QUE JE TE DEMANDAIS C'ETAIT DE PRENDRE SOIN D'ELLE PENDANT QUE JE NE SUIS PAS LA !"


translate french aeroport_709901dd:


    mad "Tu vas me dire que t'as pas remarqué qu'elle était en train de s'étouffer avec sa sucette ?"


translate french aeroport_43b0627a:


    mad "Ecoute-moi bien, frère stupide et incompétent ! Je serai là dans quelques minutes... calme-la le temps que j'arrive..."


translate french aeroport_249cf055:


    mad "C'est le mien!"


translate french aeroport_83e05748:


    mad "J'en ai plus besoin que toi!"


translate french aeroport_77d696c7:


    mad "Tu ne croyais quand même pas que j'allais laisser un obsédé comme toi, qui a peloté mon équipière, prendre un taxi avant moi ?"


translate french aeroport_d34bda64:


    d "QU'est ce qu'elle t'a dit?"


translate french aeroport_899e50ff:


    mad "J'ai pas le temps pour toi. J'y vais et toi tu t'en trouves un autre !"


translate french aeroport_d2ce5a28:


    mad "C'est une blague ? Tu penses vraiment que tu vas partager la course avec moi ?"


translate french aeroport_3c3457a8:


    d "Je ne pense pas, je le fais. Tu peux être dûre avec qui tu veux mais avec moi ça marche pas. Je ne te connais pas et je n'ai pas peur de toi donc tu arrêtes ton attitude de suite, on partage ce taxi et tout sera fini bien assez tôt."


translate french aeroport_f51580c2:


    d "C'est bon? Bon allez, on partage la course et puis c'est tout."


translate french aeroport_fa152289:


    "C'est le dernier Mrs. Drew?"


translate french aeroport_79ea6de1:


    orushi "Parfait Mrs. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_331801eb:


    orushi "Et comment vont les autres ?"


translate french aeroport_adddebb1:


    orushi "Demain, le B.E.S.T va pouvoir démarrer !"


translate french aeroport_103b7468:


    orushi "Vous avez entendu ça Mr. Rufus ?"


translate french aeroport_c13cf216:


    orushi "Que le spectacle commence !"


translate french aeroport_4e324a7e:


    mad "Ecoute... Sois un bon toutou et va t'en chercher un autre."


translate french aeroport_a5b917da:


    d "Mais... C'est moi qui l'ai appelé !"


translate french aeroport_984881d1:


    mad "Et?"


translate french aeroport_d6920383:


    d "ET?!"


translate french aeroport_ce157163:


    dpense "Qu'est ce que je devrais faire dans cette situation?"


translate french aeroport_dc68927a:


    mad "Quoi?"


translate french aeroport_895c541d:


    d "On pourrait se partager le taxi..."


translate french aeroport_997010f1:


    mad "Je ne partage pas."


translate french aeroport_e03560e5:


    mad "D'accord... Merci... je suppose..."


translate french aeroport_36596b81:


    d "Maintenant, reposez vous, vous avez besoin de vous calmer. Vous ne pouvez pas hurler sur tout le monde comme ça..."


translate french aeroport_b1d8ddd1:


    "C'est le dernier Mrs. Drew?"


translate french aeroport_f29d7abc:


    drew "Oui, Mr. Orushi. C'est le gars qui vient de France. Comme vous l'avez demandé."


translate french aeroport_e4a116f7:


    orushi "Parfait Mrs. Drew ! Il est déjà dans les griffes de la tigresse à ce que je vois."


translate french aeroport_7711cc3b:


    orushi "Et comment vont les autres ?"


translate french aeroport_adddebb1_1:


    orushi "Demain, le B.E.S.T va pouvoir démarrer !"


translate french aeroport_29f32552:


    orushi "Vous avez entendu ça Mr. Rufus ?"




translate french rufustuto_96bf5f8d:


    "Des chats sont cachés dans les rendus pendant le jeu, trouvez-les pour débloquer des rendus supplémentaires dans la galerie."


translate french rufustuto_76ea4bfd:


    "Avec le mod Walkthrough, vous recevrez une notification lorsqu'un chat est caché dans les prochains rendus. Ouvrez l'œil !"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
