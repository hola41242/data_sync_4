


translate french e1s2_65d1cb4d:


    "...Et t'étais avec lui toute la nuit ?"


translate french e1s2_5db95835:


    "Ben, oui, pourquoi ?"


translate french e1s2_a714c0c0:


    "Ben je sais pas ... c'est bizarre non ? Tu le connais pas, ta mère dit il dort là et POUF y'à un gars qui dort dans ton salon toute la nuit..."


translate french e1s2_4754d293:


    "Ouais mais , je sais pas , il m'impressionne un peu... de la bonne façon..."


translate french e1s2_9237b6e9:


    "Ca c'est mon Cortex, on dirait pas comme ça mais oui... j'ai la même impression !"


translate french e1s2_09695720:


    "Ton Cortex ?"


translate french e1s2_5d57d32d:


    "Je t'expliquerai plus tard ! Bon, il est 8 heures, faut que je le réveille ! Euh... Mince, c'était quoi son nom déjà ? ... Oh et puis zut..."


translate french e1s2_c73588b3:


    "CORTEXXXXXXXXXXXXX!!!!" with hpunch


translate french e1s2_67b0fbce:


    d "Whaaaaaaaaaaaaaa!"


translate french e1s2_8614e399:


    ruby "Ahaha, je sais que je suis belle à en tomber, mais j'avais jamais pensé au sens complètement littéral de cette expression !"


translate french e1s2_be15c680:


    d "Hey, mais qu'est ce que tu fais là ?"


translate french e1s2_e09077c9:


    ruby "Ben en fait, Mrs. Drew m'a demandé de t'emmener à ta chambre, et vaut mieux lui obéir sinon... On peut y aller ?"


translate french e1s2_a250c6af:


    d "Attends, et Grace ?"


translate french e1s2_1c28c67e:


    grace "Oui ?"


translate french e1s2_c869d411:


    grace "Ne t'inquiètes pas pour moi, j'ai encore une heure pour me préparer ! Je ne sais pas ce qu'il se passe, mais vaut mieux qu'on soit à l'heure à l'Academy, alors dépêchez-vous ou ma mère va gueuler et on veut pas la mettre en colère le premier jour !"


translate french e1s2_0226421c:


    ruby "C'est ça ! Allez hop, hop , hop !"


translate french e1s2_c71a801b:


    d "J'arrive..."


translate french e1s2_2119aba6:


    d "Alors toi aussi t'es à l'Academy. Tu étudies quoi ?"


translate french e1s2_ec3b865c:


    ruby "J'étudie le cinéma, toutes les formes de cinéma. C'est super excitant ! Par exemple est ce que tu sais qu'il y a une expérience qui a été faite pour voir si Jack pouvait rester sur la planche avec Rose ?"


translate french e1s2_be0b1d53:


    d "De quoi est ce que tu parles ? Titanic ? Vraiment ?"


translate french e1s2_3d21d05f:


    ruby "Oui !!! Nan mais elle est trop égoïste... Oh Jack j'ai si froid..."


translate french e1s2_f3ea9ee7:


    ruby "Okay Rose, Je vais tenter de survivre dans une eau à 4 degrés..."


translate french e1s2_5d969260:


    d "T'es sérieuse ?"


translate french e1s2_878d497f:


    ruby "Oui bon... Mais c'est vraiment intéressant je te jure !"


translate french e1s2_287a87b4:


    d "J'imagine. Et qu'est ce que tu aimes dans le cinéma ?"


translate french e1s2_920ba8c1:


    ruby "Ben, par exemple, j'adore les films d'horreur... En fait, j'adore les regarder, mais je cache mes yeux dès qu'il y a quelque chose qui fait peur ! Tu vois genre, les jumpscares dans les films..."


translate french e1s2_20e8d3ca:


    ruby "C'est comme si j'avais une grosse boule dans mon estomac qui explose d'un coup, j'ai ma respiration qui se coupe et j'ai du mal à récupérer... Enfin bref, j'adore cette sensation... Mais j'ai trop peur !"


translate french propcineruby_3634a7f3:


    d "Ben, si tu veux, on pourrait aller voir un film ensemble au cinéma un de ces jours. Ca pourrait être sympa... Mais je veux pas te forcer..."


translate french propcineruby_99e540a3:


    ruby "Oui ! Oui ! Oui !"


translate french propcineruby_6287fda8:


    d "Hein ?"


translate french propcineruby_c43add9f:


    ruby "J'ai jamais été invitée au cinéma alors que j'adore ça donc ... Oui, j'accepte votre invitation, Cortex !"


translate french propcineruby_d8d89651:


    d "Haha ! Okay, alors on ira ensemble et je te laisserai même choisir le film !"


translate french propcineruby_d0c3dc68:


    ruby "Et je pourrai avoir un gros pot de popcorn pour faire comme dans les films ?"


translate french propcineruby_ee3661bc:


    d "Et bien... Je t'achèterai le gros pot si tu veux !"


translate french propcineruby_47d453f2:


    ruby "Je savais que j'avais raison de te choisir pour être mon Cortex, j'en étais sûre !"


translate french propcineruby_e0d30fc1:


    d "Euh oui... Probablement..."


translate french fincineruby_c945114a:


    ruby "Ca y est, on y est presque. Je vais te montrer ta chambre !"


translate french discoverroom_1a237ef5:


    ruby "Va visiter ta chambre ! J'arrive dans 10 minutes, ma tresse est complètement défaite, faut que je la refasse !"


translate french discoverroom_e7861de8:


    d "Whaaaaa! C'est quoi tout ça ?"


translate french discoverroom_f963a737:


    d "Je ferais mieux de toucher à rien... Bon elle arrive d'ici 10 minutes.... Je fais quoi en attendant ?"


translate french discoverroom_a6338c52:


    d "Inspire..."


translate french discoverroom_64e98b03:


    d "Shhhhh ! Expire...."


translate french discoverroom_a6338c52_1:


    d "Inspire..."


translate french discoverroom_64e98b03_1:


    d "Shhhh ! Expire..."


translate french discoverroom_64e98b03_2:


    d "Shhh ! Expire..."


translate french discoverroom_2bd4d989:


    d "You're talking to me ?"


translate french discoverroom_f96400d1:


    d "Okay mon gars, va falloir montrer de quoi t'es capable !"


translate french discoverroom_6dbb1ebc:


    d "C'est qui le meilleur ?"


translate french discoverroom_c656e65a:


    d "Je suis le meilleur !"


translate french discoverroom_da8c427f:


    d "J'espère qu'elle va m'expliquer pourquoi on est tous seuls dans notre chambre..."


translate french rubychambre_5b47cd33:


    d "Bon ça suffit..."


translate french rubychambre_5a8492fe:


    d "Il va falloir que je fasse le ménage là dedans... Pour que ça me ressemble un peu plus..."


translate french rubychambre_af3ce623:


    d "Je ne sais pas pourquoi j'ai le droit à une chambre à moi tout seul mais je vais la faire à ma façon !"


translate french rubychambre_867a4ae9:


    ruby "En fait, la semaine dernière on m'a demandé de préparer une chambre pour un français qui arriverait cette semaine..."


translate french rubychambre_64e90a9f:


    ruby "Donc j'ai pris tout ce que je trouvais... Mais je ne sais même pas ce que tu aimes ! Donc je te laisserai redécorer comme tu veux..."


translate french rubychambre_182f01ea:


    ruby "Enfin, quand tu auras le temps, parce qu'on n'a plus que 15 minutes avant 9 heures !!! Alors tu te changes et on y va !"


translate french rubychambre_450849eb:


    d "Me changer ? Mais j'ai même pas mes affaires ! Et ta tresse ? Pourquoi tu l'as retirée ?"


translate french rubychambre_4243f9af:


    ruby "Oh ma tresse était défaite... et comme je devais refaire ça rapidement... Tu n'aimes pas comme ça ?"


translate french rubychambre_bfcede80:


    d "Euh... Si si mais ça te change beaucoup !"


translate french rubychambre_72b2b727:


    ruby "Bon on laisse les flateries de côté pour l'instant... Regarde dans l'armoire, ne t'inquiètes pas, tu vas trouver quelque chose de cool, j'en suis sûre ! "


translate french rubychambre_f56cac0f:


    ruby "De toute façon, c'est tout ce que j'ai pu récupérer des vêtements oubliés... Alors vas y, essaye, et tu me montreras !"


translate french rubychambre_dd5d68f3:


    d "Hein ?"


translate french rubychambre_06b04368:


    ruby "Allez allez !"


translate french rubychambre_b97d5169:


    d "Okay... Qu'est ce qu'on a là ?"


translate french rubychambre_04593aa2:


    d "Tu veux vraiment que je porte ça ?"


translate french rubychambre_fa34f206:


    ruby "Oui allez ! Fais pas l'enfant !!!"


translate french rubychambre_d83c8599:


    d "Mais ..."


translate french rubychambre_485a28e8:


    ruby "Allez, on va être en retard !"


translate french rubychambre_7bcc50f4:


    d "Okay..."


translate french tenuefier_d419757e:


    ruby "Oh mon dieu, oh mon dieu, oh mon dieu !"


translate french tenuefier_da447aff:


    d "Qu'est ce qu'il se passe ?"


translate french tenuefier_9c1bd9da:


    ruby "Je suis désolée, je suis là avec un gars qui se déshabille devant moi et j'ai pas fermé les yeux !"


translate french tenuefier_474f9baa:


    d "Ruby..."


translate french tenuefier_55f57472:


    ruby "Oh Maman qu'est ce que tu penses de moi ? Je sais que j'aurais dû me tourner mais je ne l'ai pas fait et ..."


translate french tenuefier_474f9baa_1:


    d "Ruby..."


translate french tenuefier_9ec4ff19:


    ruby "Non pas que tu ne sois pas mignon... NON ! Tu es vraiment mignon mais là comme ça, ce n'est pas approprié pour une fille de regarder un garçon si bien ... bâti... comme ça..."


translate french tenuefier_dbf049bf:


    d "RUBY !!!" with vpunch


translate french tenuefier_8fe3ea01:


    ruby "Oh ... Oui quoi ?"


translate french tenuefier_ff81dc7d:


    d "Tu peux te tourner s'il te plaît ?"


translate french tenuefier_154b272f:


    ruby "Oh oui ! Oui !"


translate french tenuefier_6e06f565:


    ruby "Whaaaa... Il fait chaud tout d'un coup..."


translate french tenueshy_ff81dc7d:


    d "Tu peux te tourner s'il te plaît ?"


translate french tenueshy_aa02d9c8:


    ruby "Oh oui ! Oui !"


translate french tenueshy_b962edf3:


    ruby "Whaaaa... Il fait chaud tout d'un coup..."


translate french rubydepart_f3a9f496:


    d "Okay ! Tu peux regarder maintenant ! Vers l'infini et au delà !"


translate french rubydepart_004176c4:


    ruby "Oh Génial ! J'étais sûre que tu trouverais quelque chose à te mettre ! Et vous connaissez Toy Story en France aussi ?"


translate french rubydepart_d2f1eea4:


    d "Euh... Tu crois qu'on a pas de films en France ?"


translate french rubydepart_6fc30deb:


    ruby "NON ! Non, bien sûr que non ... Mais je ne suis jamais allée là bas donc ..."


translate french rubydepart_3e2534f2:


    ruby "Tu savais que Toy Story est le premier film animé complètement en 3D ?"


translate french rubydepart_05244633:


    d "Non mais c'est intéressant !"


translate french rubydepart_75ad79ee:


    ruby "Ouais je sais ! L'année dernière on a appris plein de trucs comme ça ! Comme quoi il y avait plus de 110 000 images dans le film..."


translate french rubydepart_8ec775d3:


    ruby "Et ça prenait entre 2 et 15 heures pour chaque image... Donc y'avait toute une ferme remplie de machines pour pouvoir faire l'équivalent de 500 ans de travail pour faire toutes les images !"


translate french rubydepart_992e6eaa:


    d "Ruby ?"


translate french rubydepart_0a4c4274:


    ruby "Oui ?"


translate french rubydepart_f74d81d3:


    d "T'as pas dit que tu voulais pas être en retard ?"


translate french rubydepart_e28cd635:


    ruby "Oh ! Oui ! Oui ! Bon... Cortex, t'es prêt ?"


translate french rubydepart_44c0877a:


    ruby "C'était pas une question ! On doit y aller ! On ne doit pas être en retard !"

translate french strings:


    old "Invite her someday to cinema"
    new "L'inviter au cinéma"


    old "Not interested"
    new "Ou pas"


    old "Do push-ups"
    new "Faire des pompes"


    old "Go into the bathroom"
    new "Aller dans la salle de bain"


    old "Wait for Ruby"
    new "Attendre Ruby"


    old "30 push-ups later..."
    new "30 pompes plus tard..."


    old "Undress in front of her"
    new "Se déshabiller devant elle"


    old "Ask her to turn"
    new "Lui demander de se retourner"


    old "Yes Minus !"
    new "Oui Minus !"


    old "Nope"
    new "Non"




translate french e1s2_ca50cd2f:


    ruby "Mais oui !!!! Elle est trop égoïste... Oh Jack je suis gelée..."




translate french rubydepart_f5fca5c2:


    ruby "Tu savais que Toy Story était le premier film entièrement animé en 3D ?"




translate french e1s2_4afb0663:


    "Ben je sais pas... Tu trouves pas ça bizarre toi ? Tu le connais pas et ta mère le fait dormir dans ton canapé comme ça...."


translate french e1s2_6b6758b7:


    ruby "Mrs. Drew m'a demandé de t'accompagner jusqu'à ta chambre sur le campus, et il vaut mieux lui obéir... On peut y aller ?"


translate french e1s2_0e0e53e7:


    ruby "J'étudie le cinéma, toutes les formes de cinéma. C'est super excitant ! Tu savais par exemple qu'il y avait des expériences faites pour voir si Jack et Rose tenaient à deux sur la planche ?"


translate french e1s2_a879602e:


    ruby "Ouais !!! Elle est trop égoïste... Oh Jack j'ai froid..."


translate french e1s2_74616e87:


    ruby "Okay Rose, Je vais rester en vie dans cette eau à 4 degrés..."


translate french e1s2_59e57aa3:


    ruby "Ben, par exemple, j'adore les films d'horreur... J'adore les regarder, mais je couvre mes yeux dès que j'ai peur ! Tu sais les jumpscares dans les films..."


translate french e1s2_414a8171:


    ruby "C'est comme si j'avais une grosse boule dans mon estomac qui explose, ma respiration s'arrête et j'ai du mal à récupérer... Mais j'adore ça... Même si j'ai super peur !"


translate french rubychambre_508037ac:


    ruby "En fait, la semaine dernière on m'a demandé de préparer une chambre pour un français qui arriverait cette semaine..."


translate french rubychambre_e4dc2b71:


    ruby "Bon arrête de parler... Regarde dans l'armoire, je suis sûre que tu vas trouver quelque chose à te mettre !"


translate french rubydepart_74e895dc:


    ruby "Super ! J'étais sûre que t'allais trouver ! Et tu connais Toy Story ?"


translate french rubydepart_fb3f392c:


    ruby "Non ! Bien sûr que non... Mais j'ai jamais été là-bas du coup..."


translate french rubydepart_ac6d9b74:


    ruby "Tu savais que Toy Story était le premier film d'animation entièrement réalisé en 3D ?"


translate french rubydepart_0fdce267:


    ruby "Ouais c'est fou ! L'année dernière on a appris plein de trucs sur ce sujet ! Par exemple y'avait plus de 110 000 images dans le film..."




translate french e1s2_a76605d6:


    grace "Ne vous inquiétez pas pour moi; j'ai encore une heure pour être prête ! Je ne sais pas ce qu'il se passe, mais il vaut mieux être à l'heure à l'Université, alors dépêchez-vous... "


translate french e1s2_72e488c4:


    d "Alors tu es à l'Université aussi. Et tu étudies quoi ?"



translate french strings:


    old "Invite her someday to cinema [TEMP1]"
    new "L'inviter à une sortie cinéma [TEMP1]"


    old "Not interested [TEMP2]"
    new "Pas interessé [TEMP2]"


    old "Do push-ups [TEMP1]"
    new "Faire des pompes [TEMP1]"


    old "Go into the bathroom [TEMP2]"
    new "Aller dans la salle de bains [TEMP2]"


    old "Undress in front of her [TEMP1]"
    new "Se déshabiller devant elle [TEMP1]"


    old "Ask her to turn [TEMP2]"
    new "Lui demander de se retourner [TEMP2]"


    old "Yes Minus ! [TEMP1]"
    new "Oui Minus ! [TEMP1]"


    old "Nope [TEMP2]"
    new "Non... [TEMP2]"



translate french strings:


    old "Invite her someday to cinema [TEMP1!t]"
    new "L'inviter à une sortie cinema [TEMP1!t]"


    old "Not interested [TEMP2!t]"
    new "Pas interessé [TEMP2!t]"


    old "Do push-ups [TEMP1!t]"
    new "Faire des pompes [TEMP1!t]"


    old "Go into the bathroom [TEMP2!t]"
    new "Aller dans la salle de bains [TEMP2!t]"


    old "Undress in front of her [TEMP1!t]"
    new "Se déshabiller devant elle [TEMP1!t]"


    old "Ask her to turn [TEMP2!t]"
    new "Lui demander de se retourner [TEMP2!t]"


    old "Yes Minus ! [TEMP1!t]"
    new "Oui Minus ! [TEMP1!t]"


    old "Nope [TEMP2!t]"
    new "Non... [TEMP2!t]"




translate french e1s2_34ad7e5c:


    "... Et t'étais toute seule avec lui cette nuit ?"


translate french e1s2_41cf68f1:


    "Ben, je sais pas... C'est un peu spé quand même ! Tu le connais pas, ta mère dit il dort dans le canap' et hop t'as un gars qui couche chez toi toute la nuit..."


translate french e1s2_24bb8b8a:


    "Ouais, mais je sais pas, j'ai un bon feeling... Je sais pas pourquoi..."


translate french e1s2_2f271829:


    "Je t'expliquerai plus tard ! Bon, il est 8 heures, faut que je le réveille ! Heu... Merde, c'est quoi son prénom déjà ?... Oh et puis zut !!!"


translate french e1s2_4ad557e3:


    ruby "Ben, Mrs Drew m'a demandé de t'escorter à ta chambre, et vaut mieux lui obéir sinon... Donc, on peut y aller ?"


translate french e1s2_b6638c06:


    ruby "J'étudie le cinéma, toutes les formes de cinéma. C'est super excitant ! Tu savais qu'il y a une expérience qui a été faite pour savoir si Jack et Rose pouvaient tenir ensemble sur la planche ?"


translate french e1s2_53942f8e:


    ruby "Ouais !!! Nan mais je te jure ! La fille trop égoïste quoi ! Oh Jack je suis gelée..."


translate french e1s2_07929c8d:


    ruby "Okay okay... Mais je te jure que c'est vachement intéressant !"


translate french e1s2_6f407893:


    ruby "Ben, par exemple, j'adore les films d'horreur... J'adore les regarder, mais je me cache dès que y'à un truc qui fait peur ! Tu sais, les jumpscares dans les films d'horreur..."


translate french propcineruby_41df4702:


    ruby "Et on pourra prendre du popcorn pour faire genre on profite à fond du cinéma ?"


translate french propcineruby_37851153:


    d "Oui bien sûr... Je t'achèterai un gros pot même si tu veux !"


translate french discoverroom_cd4fae71:


    d "Okay mon gars, montre-moi à quel point tu es fort !"


translate french rubychambre_138d5fe3:


    d "Va falloir que je fasse le ménage ici... Que j'essaye de me sentir chez moi..."


translate french rubychambre_a5e75010:


    ruby "Du coup j'ai pris un peu tout ce qui me passait sous la main... Mais je savais même pas ce que tu aimais ! Donc je te laisserai redécorer..."


translate french rubychambre_7d7560a5:


    ruby "Oh ma tresse était défaite... Et comme il fallait faire vite... Tu n'aimes pas ?"


translate french rubychambre_ddbc3bea:


    ruby "En fait, c'est tout ce que j'ai pu récupérer des vêtements oubliés... Mais vas-y essaye ! Tu me montreras !"


translate french rubychambre_794a94d7:


    d "Okay... Qu'est ce qu'on a là ?"


translate french rubychambre_16f08f36:


    ruby "Allez, on va être en retard !"


translate french tenuefier_0954f056:


    ruby "Désolée, je suis là avec un gars qui se déshabille devant moi et j'ai pas fermé les yeux !"


translate french tenuefier_4016e5f2:


    ruby "Oh Maman qu'est ce que tu dois penser de moi ? Je sais que j'aurais dû me retourner mais..."


translate french tenuefier_5d647fc8:


    ruby "Pas que tu ne sois pas mignon... NON ! Tu es vraiment mignon mais en étant là, comme ça... Ce n'est pas approprié pour une fille de regarder à... Un garçon bien bâti... Comme ça..."


translate french tenuefier_aa02d9c8:


    ruby "Oh oui oui ! Bien sûr..."


translate french tenuefier_cf05acac:


    ruby "Whaaa... Il fait pas un peu chaud d'un coup ?"


translate french tenueshy_b2766e52:


    ruby "Whaaa... Il fait pas un peu chaud d'un coup ?"


translate french rubydepart_75fcdfb3:


    d "Heu... Tu crois vraiment qu'on a pas de films chez nous ?"

translate french strings:


    old "Go to the bathroom [TEMP2!t]"
    new "Aller dans la salle de bains[TEMP2!t]"




translate french e1s2_770af536:


    "Ben, oui, pourquoi?"


translate french e1s2_80c276a3:


    "Je sais pas, c'est bizarre nan? Tu le rencontre et ta mère te dit qu'il doit dormir là et finalement t'as un gars qui dort sur ton canapé."


translate french e1s2_31e3cfa2:


    "Ouais c'est bizarre mais ça va il m'a fait bonne impression."


translate french e1s2_501d5b80:


    "Ca c'est mon Cortex, on dirait pas mais je suis sûre que c'est un bon gars!"


translate french e1s2_78364aef:


    "Je t'expliquerauis plus tard. Bon c'est 8 heures, faut que je le réveille. Heu... mince, c'est quoi son prénom déjà ? Oh pas grave..."


translate french e1s2_7df24e34:


    "COOOOOORTEEEEEX!!!!" with hpunch


translate french e1s2_45a5dd64:


    d "On attend pas Grace?"


translate french e1s2_67c680bf:


    grace "Ne t'inquiète pas pour moi, j'ai encore une heure pour me préparer. Je sais pas ce qu'il se passe mais vaut mieux arriver à l'heure à l'Academy. Dépêchez-vous ou ma mère va être furieuse et c'est jamais une bonne idée de la mettre en rogne!"


translate french e1s2_bf9bfb15:


    d "Alors tu fais partie de l'université aussi... Et tu étudies quoi?"


translate french e1s2_1af9e6cb:


    ruby "Le cinéma, dans toutes ses formes. C'est super excitant! Tu savais que y'a eu des expériences pour voir si jack pouvait tenir sur la planche avec Rose?"


translate french e1s2_55638aae:


    d "Tu parles de quoi là? Titanic? Vraiment?"


translate french e1s2_96cc0adf:


    ruby "Ouais! Nan mais vlà l'égoïste quoi! Oh Jack j'ai froid..."


translate french e1s2_f2d78baa:


    ruby "Okay Rose. Je vais essayer de tenir dans une eau à 4 degrés..."


translate french e1s2_4d71f41f:


    d "T'es sérieuse?"


translate french e1s2_b3ab0599:


    ruby "Bon d'accord. Mais c'est vraiment très intéressant je te jure!"


translate french e1s2_b62db3ff:


    ruby "J'adore ressentir des frissons. Par exemple j'adore les films d'horreur. J'adore les regarder, mais je cache mes yeux dès que ça fait peur!"


translate french e1s2_9cf93c5d:


    ruby "C'est comme avoir une grosse boule dans le ventre qui explose, ma respiration s'arrête et me faut du temps pour récupérer. Enfin bon voilà j'adore ça même si j'ai trop peur!"


translate french propcineruby_6e776a5e:


    d "Ben, si tu veux, on peut aller voir un film ensemble un de ces jours? Ca peut être sympa mais je veux pas t'obliger à..."


translate french propcineruby_4ea2e005:


    ruby "OUI OUI OUI!"


translate french propcineruby_1f60adc7:


    ruby "On m'a jamais invité alors que j'adore ça! Donc oui, j'accepte ton invitation Cortex!"


translate french propcineruby_141e7c18:


    ruby "Je pourrais prendre du popcorn?"


translate french propcineruby_849605a1:


    d "Oui... Sûrement."


translate french discoverroom_85dbadc3:


    ruby "Va voir ta chambre! J'arrive dans 10 minutes. Faut que j'aille me coiffer."


translate french discoverroom_1594124b:


    d "Vaut mieux que je touche à rien. Elle sera là dans 10 minutes... Qu'est ce que je peux faire pendant ce temps?"


translate french discoverroom_16a1548f:


    d "Shhhhh! Expirer..."


translate french discoverroom_16a1548f_1:


    d "Shhhh! Expirer..."


translate french discoverroom_16a1548f_2:


    d "Shhhh! Expirer..."


translate french discoverroom_84ecfab6:


    d "C'est à moi que tu parles?"


translate french discoverroom_8a3f962d:


    d "Okay mon gars, montre leur qui c'est le meilleur!"


translate french discoverroom_863e77a7:


    d "C'est qui le meilleur?"


translate french discoverroom_a238a1d1:


    d "Je suis le meilleur!"


translate french rubychambre_5bef6195:


    d "Bon ça va aller!"


translate french rubychambre_41072c92:


    d "Va falloir que je réorganise un peu tout ici. Que je me sente un peu chez moi..."


translate french rubychambre_c06c20e5:


    d "Je sais pas pourquoi j'ai le droit à ma propre chambre mais je vais au moins faire tout pour me sentir chez moi!"


translate french rubychambre_664ab157:


    ruby "En fait, la semaine dernière on m'a demandé de préparer une chambre pour un français qui arriverait cette semaine."


translate french rubychambre_8806eefc:


    ruby "Du coup j'ai choppé un peu tout ce qui se passait... Mais je savais pas ce que tu aimais donc tu pourrais la redécorer toi-même oui..."


translate french rubychambre_2d6b02e1:


    ruby "Enfin, quand t'auras le temps. Il est déjà moins le quart et il faut qu'on y aille! Change toi vite et on y va!"


translate french rubychambre_a794f044:


    d "Me changer? J'ai même pas d'affaires! Et ta tresse? elle est passée où?"


translate french rubychambre_91fb8673:


    ruby "Oh j'en avais marre fallait que je la refasse à chaque fois. Tu aimes?"


translate french rubychambre_a6f5264d:


    d "Euh... Oui mais ça te change quand même!"


translate french rubychambre_7f6541d4:


    ruby "Merci, mais faut que tu sois prêt alors regarde dans l'armoire j'ai trouvé des trucs pour toi."


translate french rubychambre_bc471c95:


    ruby "Et puis de toute façon c'est tout ce que j'ai pu récupérer des objets trouvés. Allez vas y!"


translate french rubychambre_f4d512f9:


    d "Okay... Bon on a quoi la dedans..."


translate french rubychambre_5a34b207:


    d "Faut vraiment que je mette ça?"


translate french rubychambre_44a8b55f:


    ruby "Allez, fais pas l'enfant!"


translate french tenuefier_893914d0:


    ruby "Oh mon dieu, oh mon dieu, oh mon dieu!"


translate french tenuefier_2baafa95:


    d "Qu'est ce qu'il y a?"


translate french tenuefier_df0c0189:


    ruby "Je suis désolée, tu te changes en face de moi et j'ai pas fermé les yeux!"


translate french tenuefier_42253061:


    ruby "Maman, qu'est ce que tu penserais de moi? Je devrais me tourner mais..."


translate french tenuefier_ec8a59ae:


    ruby "C'est pas que tu n'es pas mignon... Ca c'est sûr! T'es vraiment mignon mais tu es là, à moitié nu, et ce n'est pas approprié de regarder quelqu'un de... si bien bâti..."


translate french tenuefier_0a90153a:


    d "RUBY!!!" with vpunch


translate french tenuefier_ad8e36ef:


    ruby "Euh... Oui?"


translate french tenuefier_2f16cf06:


    d "Tu peux te tourner s'il te plaît?"


translate french tenuefier_f744f755:


    ruby "Oh oui! Bien sûr bien sûr..."


translate french tenuefier_3be2d750:


    ruby "Whaaa... Il fait pas un peu chaud ici?"


translate french tenueshy_2f16cf06:


    d "Tu peux te tourner s'il te plaît?"


translate french tenueshy_f744f755:


    ruby "Oh oui! Bien sûr bien sûr..."


translate french tenueshy_3be2d750:


    ruby "Whaaa... Il fait pas un peu chaud ici?"


translate french rubydepart_59094040:


    d "C'est bon! Tu peux regarder! Vers l'infini et au delà!"


translate french rubydepart_9e16abcd:


    ruby "Ah super! J'étais sûre que t'allais trouver quelque chose! Et tu connais Toy Story en France?"


translate french rubydepart_2293fb7a:


    d "Hmmm... Tu crois qu'on pas accès aux films?"


translate french rubydepart_0d55d8d0:


    ruby "Non non! Bien sûr que non! Mais je suis juste passée en coup de vent en France ce week end donc..."


translate french rubydepart_5efecdc4:


    ruby "Tu savais que Toy Story était le premier film d'animation totalement animé en 3D?"


translate french rubydepart_c2b42767:


    d "Euh...Non."


translate french rubydepart_88c4f110:


    ruby "On a appris plein de choses à ce sujet! Par exemple, il a fallu plus de 110 000 images pour faire le film..."


translate french rubydepart_a8d12340:


    ruby "Et ça prenait 15 heures pour faire une image! Ils avaient une ferme complète avec des machines pour faire les 500 ans de temps qu'il fallait pour faire toutes les images!"


translate french rubydepart_136f81dc:


    d "Ruby?"


translate french rubydepart_b89db320:


    ruby "Oui?"


translate french rubydepart_438eb630:


    d "T'as pas dit qu'il fallait qu'on se dépêche?"


translate french rubydepart_9dfd8c7e:


    ruby "Oh! Oui oui! Allez Cortex... T'es prêt?"


translate french rubydepart_a95d95e2:


    ruby "Pas grave! On doit y aller! On ne doit pas être en retard!"

translate french strings:


    old "Ask her to turn around [TEMP2!t]"
    new "Lui demander de se retourner [TEMP2!t]"


    old "Yes Minus! [TEMP1!t]"
    new "Oui Minus! [TEMP1!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
