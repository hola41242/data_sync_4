


translate french e1s4_254f688f:


    dpense "Les filles sont parties se changer dans leur vestiaire"


translate french e1s4_3fa91343:


    dpense "J'ai pas d'affaires, heureusement que j'ai mis un jogging..."


translate french e1s4_98a88ee3:


    dpense "Bon... Ils m'ont dit de prendre le petit chemin par la petite forêt pour rejoindre le stade..."


translate french e1s4_9a15f8ed:


    dpense "Je vais suivre les autres, ils ont l'air d'aller par là..."


translate french e1s4_2ead2b4e:


    dpense "Wow... Ca c'est quelque chose..."


translate french e1s4_377c29dc:


    dpense "Bon, va falloir sauter, faire la poutre, monter un mur super haut..."


translate french e1s4_c9218e91:


    dpense "C'est comme un parcours du combattant..."


translate french e1s4_0ed28279:


    d "Qu'est ce qu'elles font ?"


translate french e1s4_1b095f4a:


    dpense "Il avait pas dit que la course commençait pile dans 10 minutes ?"


translate french e1s4_9d966740:


    d "Ah ouais... D'accord..."


translate french e1s4_81359d8a:


    mad "Tiens-toi prêt... dès que ça sonne on part direct..."


translate french e1s4_d08d7bd8:


    d "Je suis prêt... Sympa la tenue..."


translate french e1s4_1cee3c7b:


    mad "Ouais ben garde tes yeux bien ouverts devant toi !"


translate french e1s4_0277facd:


    ruby "Je t'ai manqué ?"


translate french e1s4_db9355e4:


    d "Euh ouais on va dire ça ! J'avais surtout peur que tu arrives en retard !"


translate french e1s4_fdfcc728:


    ruby "Ben en fait Grace galérait à mettre sa tenue du coup... on a perdu un peu de temps..."


translate french e1s4_e1eac1fe:


    d "Heu... en parlant de tenue... C'est quoi ça ?"


translate french e1s4_15b19890:


    ruby "Oh !!! c'est mon Kimono Style !"


translate french e1s4_58b90a37:


    d "Ton Kimono Style ? Mais on est pas sur un tatami !"


translate french e1s4_62d07dbf:


    ruby "Je sais mais mes affaires de course ben... je les ai perdues..."


translate french e1s4_474f9baa:


    d "Ruby..."


translate french e1s4_af65d736:


    ruby "T'inquiètes pas ! Ca va améliorer mon agilité !"


translate french e1s4_54658857:


    julia "Bon, t'es prêt ?"


translate french e1s4_5631dc25:


    d "Ouais, hâte de voir ce que tu es capable de faire !"


translate french e1s4_3077b247:


    julia "C'est plus à toi de me montrer ce dont TU es capable !"


translate french e1s4_f85d2bb0:


    d "Oulà ! T'inquiètes pas pour moi !"


translate french e1s4_d07ece43:


    grace "Désolée... On est un peu en retard..."


translate french e1s4_df8f2fbb:


    d "Tant que vous êtes là pour le départ moi ça me va hein !"


translate french e1s4_b0b96245:


    grace "Ma tenue était pas évidente à mettre..."


translate french e1s4_ff44cb0f:


    d "En tous cas elle est magnifique ! On dirait Lara Croft !"


translate french e1s4_5dba12c1:


    grace "Ouais ! Mais je suis pas aussi agile qu'elle !"


translate french e1s4_3f58bfa9:


    d "Et encore... regarde ce qu'il y à en face de nous !"


translate french e1s4_c41a91e8:


    grace "On va le faire étape par étape et ça devrait le faire."


translate french e1s4_2dc76bea:


    d "Tu... t'étires ?"


translate french e1s4_40f16f49:


    ruby "Ouais ! Je sais pas trop ce qu'on va avoir à faire alors ..."


translate french e1s4_b2b5a412:


    ruby "Tu crois qu'ils vont mettre un son spécial pour le début de la course ?"


translate french e1s4_4f399a57:


    d "Je suis pas sûr que ce soit vraiment important..."


translate french e1s4_5048dc99:


    ruby "Nan mais , je veux dire, tu crois que ce sera une chanson ? Genre I'm a survivor ? Ou un gros son de corne de brume ? Ou autre chose ..."


translate french e1s4_f097499a:


    ruby "ça répond à ma question..."


translate french e1s4_85a51d50:


    d "Heu ???"


translate french e1s4_dacec8f6:


    dpense "Okay..."


translate french e1s4_5a7f4942:


    dpense "Il faut que je saute..."


translate french e1s4_e3de31ff:


    dpense "Ne perds pas de temps..."


translate french e1s4_e5d68ef1:


    dpense "Ne tombe pas maintenant..."


translate french e1s4_3afc310b:


    dpense "Madison..."


translate french e1s4_bef27060:


    dpense "Elle est rapide !!!"


translate french e1s4_11722e7d:


    julia "AHHHHH !"


translate french e1s4_c6beff58:


    julia "Pervers... mais gentleman !"


translate french e1s4_1d8d941c:


    d "Je ne suis pas..."


translate french e1s4_ef7f41a7:


    julia "Je sais Mignon !"


translate french e1s4_392c0bca:


    julia "Merci !"


translate french e1s4_d1328c7d:


    d "Pas de problèmes..."


translate french e1s4_c45d2021:


    julia "Je savais que tu étais un gentleman !"


translate french e1s4_3287f850:


    dpense "Faut que je rejoigne Madison..."


translate french e1s4_c6beff58_1:


    julia "Pervers... mais gentleman !"


translate french e1s4_1d8d941c_1:


    d "Je ne suis pas ..."


translate french e1s4_ef7f41a7_1:


    julia "Je sais Mignon !"


translate french e1s4_392c0bca_1:


    julia "Merci !"


translate french e1s4_d1328c7d_1:


    d "Pas de problèmes..."


translate french e1s4_c45d2021_1:


    julia "Je savais que tu étais un gentleman !"


translate french e1s4_3287f850_1:


    dpense "Je dois rejoindre Madison !"


translate french e1s4_ec5f501a:


    d "Donnez moi vos mains les filles !"


translate french e1s4_d2ca9147:


    grace "Merci !"


translate french e1s4_861f2793:


    ruby "Gracias !"


translate french trial2_55085e54:


    d "Sautez ! Je vais vous faire la courte échelle !"


translate french trial3_d9e39fb2:


    d "Madison ! Où est le stade ?"


translate french trial3_125278f2:


    mad "Juste après la colline !"


translate french trial3_5e6cd201:


    d "Allez Madison ! On peut le faire !"


translate french trial3_4c002cd5:


    d "Julia ! Où est le stade ?"


translate french trial3_3427b926:


    julia "Juste après la colline !"


translate french trial3_c14b1157:


    julia "Tu m'as pas aidé tout à l'heure... pourquoi je t'aiderais ?"


translate french trial3_b0c2fcfb:


    julia "Maintenant.. dégage !"


translate french trial3_b04a6cac:


    dpense "Okay... Elle m'en veut..."


translate french trial3_f400f290:


    d "Allez les filles ! On peut le faire !"


translate french trial3_f400f290_1:


    d "Allez les filles ! On peut le faire !"


translate french trial4_406dd597:


    drew "VOUS DEVEZ TROUVER VOTRE BAGAGE ET PARTIR AVEC AVANT DE REJOINDRE L'AMPHITHEATRE ! "


translate french trial4_a3db4173:


    d "Euh... Okay...Et où on est censés trouver un sac dans un stade géant comme ça ?"


translate french trial4_32c961d2:


    mad "Ouvre tes yeux petit génie..."


translate french trial4_93a57ae7:


    d "Hein ? Oh !!!"


translate french trial4_ef3a2b6b:


    mad "Non... !"


translate french trial4_c3051f60:


    mad "Non, non, non, non, non !"


translate french trial4_29a24172:


    mad "Cours !!!" with hpunch


translate french trial4_01f455e7:


    emerick "Madison ! T'embêtes pas à courir ! Tu vas perdre comme toujours !"


translate french trial4_3ff9bc88:


    mad "Tu devrais pas être aussi sûr de toi tête de bite !"


translate french trial4_0646d43a:


    dpense "Wow... Sont pas copains ceux-là !"


translate french trial4_7c86948c:


    mad "Mais comment on peut savoir lequel est le nôtre ?"


translate french trial4_84bf4ca9:


    d "Je ne sais pas."


translate french trial4_e46aa47d:


    mad "Il y a des chiffres sur chaque sac."


translate french trial4_731b6dfa:


    d "Des chiffres ?"


translate french trial4_213cb8be:


    dpense "Allez [name]... Réfléchis !"


translate french trial4_82b91c50:


    dpense "Il doit bien y avoir un indice quelque part..."


translate french trial4_b3db403f:


    drew "Vous êtes juste un chiffre sur un dossier. Dans votre cas, vous êtes le 90 !"


translate french trial4_8b86fe0d:


    d "Le 90 ? Le 90 de quoi ?"


translate french trial4_c296a65b:


    drew "J'en ai déjà trop dit... Demain vous comprendrez."


translate french trial4_a2ee175d:


    d "Attends, Mrs. Drew m'a dit que j'étais le numéro 90 !"


translate french trial4_ad3c3345:


    mad "Numéro 90 de quoi ?"


translate french trial4_f0986419:


    d "Je sais pas, mais elle a dit que je comprendrai ce que ça voulait dire aujourd'hui !"


translate french trial4_b42bbe57:


    mad "Si tu es le 90... Je dois aussi avoir un numéro !"


translate french trial4_94831b94:


    d "84...67...90... C'est ça ?"


translate french trial4_2684ce6d:


    d "J'ai trouvé le mien !"


translate french trial4_4c50fb8d:


    mad "Allez, Madison, réfléchis..."


translate french trial4_225df61f:


    d "Si elle m'a dit ça... Elle a dû te dire un truc aussi !"


translate french trial4_169a4c34:


    mad "Le numéro 10 !"


translate french trial4_eda8436c:


    mad "Quand elle parle de moi, souvent elle dit le 10 de pique ! Comme je suis numéro 10 de l'équipe !"


translate french trial4_9879eab6:


    mad "Je l'ai !"


translate french trial4_bdd2cfd3:


    d "Les filles vont arriver... Grace saura qu'et ce qu'on doit faire !"


translate french trial4_d7ead446:


    grace "Ma mère nous a donné à tous un nombre ! Je comprenais pas pourquoi c'était important... Maintenant je comprends !"


translate french trial4_c6beaf67:


    grace "Tous les sacs ont un chiffre... Vous devez trouver le vôtre !"


translate french trial4_bf736dcc:


    d "Un nombre ?"


translate french trial4_11db95ef:


    grace "Oui ! Quand tu l'as rencontrée, elle a dû te dire quelque chose ! Souviens-toi !"


translate french trial4_213cb8be_1:


    dpense "Allez [name]... Réfléchis !"


translate french trial4_82b91c50_1:


    dpense "Doit bien y avoir un indice quelque part..."


translate french trial4_b3db403f_1:


    drew "Vous êtes juste un chiffre sur un dossier. Dans votre cas, vous êtes le 90 !"


translate french trial4_8b86fe0d_1:


    d "Le 90 ? Le 90 de quoi ?"


translate french trial4_c296a65b_1:


    drew "J'en ai déjà trop dit... Demain vous comprendrez."


translate french trial4_20d845c7:


    d "Le 90 ! Je l'ai !"


translate french trial4_965cde84:


    d "Bagage ? Quel bagage ?"


translate french trial4_d0a982ec:


    ruby "J'ai l'impression qu'il y'à quelque chose là-bas !"


translate french trial4_6e7ff7a1:


    grace "Ma mère nous a tous donné un nombre ! Je comprenais pas pourquoi c'était important mais maintenant je sais !"


translate french trial4_0c4da74e:


    grace "C'est votre numéro dans l'équipe les filles !"


translate french trial4_c6beaf67_1:


    grace "Tous les sacs ont un nombre... Vous devez trouver le vôtre !"


translate french trial4_bf736dcc_1:


    d "Un nombre ?"


translate french trial4_11db95ef_1:


    grace "Oui ! Quand tu l'as rencontrée, elle a dû te dire quelque chose ! Rapelle-toi !"


translate french trial4_213cb8be_2:


    dpense "Allez [name]... Souviens-toi !"


translate french trial4_82b91c50_2:


    dpense "Doit bien y avoir un indice quelque part..."


translate french trial4_b3db403f_2:


    drew "Vous êtes juste un chiffre sur un dossier. Dans votre cas, vous êtes le 90 !"


translate french trial4_8b86fe0d_2:


    d "Le 90 ? Le 90 de quoi ?"


translate french trial4_c296a65b_2:


    drew "J'en ai déjà trop dit... Demain vous comprendrez."


translate french trial4_20d845c7_1:


    d "Le 90 ! Je l'ai !"


translate french trial4_3df96114:


    grace "J'ai le mien aussi !"


translate french trial4_c17f7d6d:


    ruby "Ouais ! moi aussi !"


translate french trial4_58f59dc6:


    julia "Pareil !"


translate french trial5_27b88c6d:


    mad "Allez, vite ! A l'amphi !"


translate french trial5_3fcd5f6c:


    d "On doit tout se retaper en sens inverse ?"


translate french trial5_a1ac5cc2:


    mad "Il faut croire !"


translate french trial5_0413c8be:


    d "Où sont les autres ?"


translate french trial5_66ae6200:


    mad "Je ne sais pas... Mais tant qu'on court vers l'amphi on peut gagner !"


translate french trial5_09de3f57:


    d "T'as vu Emerick quelque part ?"


translate french trial5_f2708063:


    mad "Pas depuis qu'on cherchait nos sacs..."


translate french trial5_da52e09c:


    d "Pareil..."


translate french trial5_6933428f:


    mad "On a gagné ?"


translate french trial5_6bc83719:


    d "On dirait bien !"


translate french trial5_94d0ff02:


    mad "Oh, c'est génial !"


translate french trial5_ec79c7cd:


    d "Ouais ! On l'a fait !"


translate french trial5_30f5bf78:


    dpense "Elle est beaucoup plus agréable quand elle gagne !"


translate french trial5_c1a3e6e6:


    d "Madison... Tu..."


translate french trial5_42add1f3:


    dpense "C'est une autre Madison..."


translate french trial5_09f48158:


    mad "Chut..."


translate french trial5_9f153aac:


    dpense "Je pourrais faire n'importe quoi pour ces yeux et ces lèvres..."


translate french trial5_75ca9fd9:


    mad "Tu..."


translate french trial5_873f2806:


    mad "Désolée... Je ne devrais pas..."


translate french trial5_1466bf93:


    emerick "Madison... Madison... Madison..."


translate french trial5_1d624209:


    emerick "Hey les tourtereaux ! Vous pensiez vraiment avoir gagné ?"


translate french trial5_d7bc0bc2:


    emerick "Ahahahahahah !"


translate french trial5_a796af6c:


    mad "Oh putain..."


translate french trial5_9e386227:


    d "Ben..."


translate french trial5_02c64f73:


    emerick "Bien essayé Maddie... Mais comme toujours, tu finis derrière moi !"


translate french trial5_9a9db627:


    emerick "Toi par contre le Frenchy, tu m'as impressionné !"


translate french trial5_a324b55d:


    mad "Attention avec lui... Sa langue est encore plus dangereuse quand il donne des compliments..."


translate french trial5_dd115bf5:


    d "T'inquiètes pas. J'ai pas prévu de faire copain-copain avec lui."


translate french trial5_7b361f19:


    mad "Tu remontes dans mon estime !"


translate french trial5_10c9f974:


    mad "Continues comme ça et il serait possible que je tolère ta présence !"


translate french trial5_e3320973:


    d "Mouais... Je suis pas sûr d'en avoir envie..."


translate french trial5_407e6732:


    sofia "A plus tard, le peloteur..."


translate french trial5_3aa92f61:


    emerick "Ben alors Madison ? T'es loin derrière cette fois ! Comme toujours, en fait !"


translate french trial5_83d40bd8:


    mad "Tente pas ta chance !"


translate french trial5_abb65a9e:


    emerick "Woooh ! La tigresse montre les crocs ! Attention !"


translate french trial5_0cc73e4b:


    grace "Emerick, va t-en !"


translate french trial5_4702d6a8:


    emerick "Okay... Mais j'en ai pas fini avec vous... Je vais montrer à tout le monde que c'est moi le B.E.S.T !"


translate french trial5_166c3d90:


    mad "Ouais, ouais... Si tu veux..."


translate french trial5_94c5f187:


    grace "Allez vite ! A l'amphi !"


translate french trial5_3fcd5f6c_1:


    d "On doit tout se retaper en sens inverse ?"


translate french trial5_0390dffa:


    grace "On dirait oui !"


translate french trial5_3aa92f61_1:


    emerick "Ben alors Madison ? T'es loin derrière cette fois ! Comme toujours, en fait !"


translate french trial5_83d40bd8_1:


    mad "Tente pas ta chance !"


translate french trial5_abb65a9e_1:


    emerick "Woooh ! La tigresse montre les crocs ! Attention !"


translate french trial5_0cc73e4b_1:


    grace "Emerick, va t-en !"


translate french trial5_4702d6a8_1:


    emerick "Okay... Mais j'en ai pas fini avec vous... Je vais montrer à tout le monde que c'est moi le B.E.S.T !"


translate french trial5_166c3d90_1:


    mad "Ouais, ouais... Si tu veux..."


translate french trialfin_7361b1fc:


    "Clap... clap... clap"


translate french trialfin_a3f82246:


    orushi "Chers étudiants ! Vous êtes arrivés à bout de ce test ! Bravo à vous tous !"


translate french trialfin_79541faa:


    orushi "Je dois dire, certains d'entre vous ont abandonnés au grand mur, tandis que d'autres n'ont pas réussi à savoir quel bagage prendre !"


translate french trialfin_ce43e569:


    orushi "Enfin, maintenant place aux résultats du test et à l'affichage de votre nouveau rang dans la compétition !"


translate french trialfin_9dd369ee:


    cr "Wow ! Je vois que vous êtes toujours dans le jeu ! ET vous avez fini le premier test !"


translate french trialfin_c61cc570:


    cr "Bravo !"


translate french trialfin_3bbf030e:


    cr "Maintenant on va juste regarder vite fait la fenêtre des statistiques car il y a quelque chose de nouveau qui a été introduit par la compétition !"


translate french trialfin_e5a61280:


    cr "Cliquez sur le bouton des statistiques s'il vous plaît !"


translate french trialfin_25799538:


    cr "Comme vous pouvez le voir, votre rang B.E.S.T est maintenant de [Rank]"


translate french trialfin_c793ee1f:


    cr "Chaque action durant un test peut l'augmenter, ou le faire baisser."


translate french trialfin_0aa6faf9:


    cr "Dans le premier test il n'y avait pas de mauvais choix... Mais dans les prochains ce sera le cas... Alors faites attention !"


translate french trialfin_331e6b8a:


    cr "Okay ! Maintenant je vous laisse jouer ! Allez chercher votre récompense..."


translate french trialfin_1ca94d08:


    cr "Il y a une RECOMPENSE SPECIALE si vous êtes dans un certain chemin... Avec un certain personnage :)"


translate french trialfin_c6beee0f:


    orushi "Comme vous pouvez le voir, à la fois vos actions individuelles et collectives sont prises en compte dans cette compétition."


translate french trialfin_1962243b:


    orushi "Alors, les 50 premiers du B.E.S.T sont qualifiés pour la suite !"


translate french trialfin_0ad95992:


    orushi "Encore une fois, Bravo à vous tous !"


translate french trialfin_12447cbb:


    orushi "Je vous donne l'après-midi off pour vous reposer."


translate french trialfin_14f60090:


    orushi "A bientôt..."


translate french trialfin_f4d45d06:


    rufus "Miaou..."


translate french trialfin_238811a2:


    grace "Allez les filles ! On va se changer."


translate french trialfin_dd3be176:


    d "A tout à l'heure."


translate french trialfin_81b128fb:


    dpense "Je devrais aller voir où se trouvent les vestiaires..."


translate french reward_273dcdfc:


    julia "Hey Mignon !"


translate french reward_3f69cd63:


    d "Hmm ?"


translate french reward_3bcca2d1:


    julia "Merci pour ton aide pendant le test !"


translate french reward_a7884e22:


    grace "Laisse moi te récompenser pour ton aide mon chevalier blanc..."


translate french reward_7c4ebb9b:


    d "Oh ? ..."


translate french reward_41d76fca:


    ruby "Je savais que je pouvais compter sur toi Cortex !"


translate french reward_16fd5bdd:


    d "Toujours Minus... Toujours !"


translate french final1_43e9250d:


    cr "Vous n'avez pas fini dans les premiers et Beth n'est pas intéressée par vous donc... Pas de récompense avec les jumelles !"


translate french final1_dbf8cd2e:


    cr "Essayez d'améliorer votre rang B.E.S.T, ou de faire d'autres choix et recevez une récompense avec elles ! "

translate french strings:


    old "2 minutes before the race starts..."
    new "2 minutes avant que la course ne commence..."


    old "1 minute before the race starts..."
    new "1 minute avant le départ de la course..."


    old "Help Julia"
    new "Aider Julia"


    old "Continue"
    new "Continuer"


    old "Help the girls"
    new "Aider les filles"


    old "Do it like Madison"
    new "Suivre Madison"


    old "Join Madison"
    new "Rejoindre Madison"


    old "Encourage Madison"
    new "Encourager Madison"


    old "Join Julia"
    new "Rejoindre Julia"


    old "Encourage Girls"
    new "Encourager les filles"


    old "Remember"
    new "Se rappeler"


    old "Wait for girls"
    new "Attendre les filles"


    old "YOUR NEW RANK IS [Rank] !"
    new "VOTRE NOUVEAU RANG EST [Rank] !"


    old "accept bj"
    new "Accept BJ"


    old "refuse"
    new "Refuser"


    old "accept kiss"
    new "Accepter kiss"




translate french trial4_1e17d9fa:


    d "Hum... Okay... Et où je dois trouver un bagage dans un stade grand comme ça ?"


translate french trial4_fc9b9b9d:


    mad "Ouvre tes yeux petit génie..."


translate french trial4_c425099d:


    dpense "Il doit y avoir un indice quelque part..."


translate french trial4_092f4702:


    d "Un bagage ? Quel bagage ?"


translate french trial5_5aa65267:


    emerick "Hey les tourtereaux ! Vous pensiez vraiment que vous aviez gagné ?"


translate french trialfin_17d82854:


    dpense "Je devrais aller voir où se trouvent les vestiaires..."


translate french reward_250f7ffa:


    grace "Laisse moi te récompenser pour ton aide, mon chevalier blanc..."




translate french final1_1c9356b0:


    dpense "Putain... Quelle journée !"


translate french final1_6cab8d90:


    dpense "Une épreuve, des adversaires, les filles..."


translate french final1_d050ec5e:


    dpense "Et ce classement... Tout ça est taré !"


translate french bethfk_22fa6fd0:


    dpense "Orushi..."


translate french bethfk_63f75c72:


    dpense "Même le chat est bizarre !!!"


translate french bethfk_a379367d:


    dpense "Les filles m'aiment bien..."


translate french bethfk_6ade56ff:


    dpense "Mais je ne sais pas si je peux être leur B.E.S.T..."


translate french bethfk_82ab05ad:


    dpense "Cet Emerick me semble dangereux..."


translate french bethfk_5648dd8a:


    dpense "Il faut que je fasse gaffe à lui..."


translate french bethfk_dbdcba12:


    dpense "Et ces jumelles..."


translate french bethfk_3120a8c0:


    dpense "Elles sont si..."


translate french bethfk_9130a1ec:


    d "Ahhhhhh !!!"


translate french bethfk_f9c1baa8:


    beth "Surpris ?"


translate french bethfk_b18b1db2:


    beth "Je t'avais dit que je garderais un oeil sur toi..."


translate french bethfk_b6632a8b:


    beth "Et je dois dire que, pour l'instant, je suis agréablement surprise par ce que j'ai vu..."


translate french bethfk_d543fc81:


    beth "J'ai vu que tu prenais soin de tes filles..."


translate french bethfk_fe2e0e36:


    d "Mes... Filles ?"


translate french bethfk_a3351689:


    beth "Oui oui... Petite Ruby... La Capitaine... Même la Sainte Marie Julia..."


translate french bethfk_98924f38:


    beth "Dommage que je n'ai pas quelqu'un comme ça qui puisse prendre soin de moi et de mes..."


translate french bethfk_d1984265:


    beth "Besoins..."


translate french bethfk_be75ee24:


    beth "Quelqu'un qui puisse me supporter..."


translate french bethfk_dc08f865:


    beth "Et qui pourrait voir..."


translate french bethfk_f0619c38:


    beth "Profondément..."


translate french bethfk_184c3e0d:


    beth "Dans..."


translate french bethfk_89669174:


    beth "Mes yeux..."


translate french bethfk_04bad0c3:


    beth "Mais si..."


translate french bethfk_fdba8dbe:


    beth "J'aimerais essayer.."


translate french bethfk_35864525:


    beth "De voir comment un Français..."


translate french bethfk_e271c468:


    beth "Embrasse ?"


translate french bethfk_3800def7:


    dpense "Waaahhhh... Pincez-moi... Je suis en train de rêver ???"


translate french bethfk_c7a6dee1:


    dpense "Cette langue... Ces lèvres... Ce corps..."


translate french bethfk_60123473:


    dpense "Oh Putain... J'ai envie de..."


translate french bethfk_08da671f:


    beth "Ohhh !"


translate french bethfk_566ac1ae:


    beth "{i}Hmmmmm....{/i}"


translate french bethfk_21da8e20:


    dpense "Je pourrais sucer cette langue pendant des heures..."


translate french bethfk_c9c80cfe:


    dpense "Et ces seins sont si bandants..."


translate french bethfk_fba25779:


    dpense "J'ai..."


translate french bethfk_4b23b39d:


    beth "Y'en a un qui se chauffe à fond là..."


translate french bethfk_5becaa9e:


    beth "Je crois avoir juste parlé d'un baiser..."


translate french bethfk_16d05a4b:


    beth "Maintenant, si tu veux bien m'excuser..."


translate french bethfk_7b56213b:


    d "Où tu vas ?"


translate french bethfk_32e4b981:


    beth "J'ai d'autres choses à faire mais..."


translate french bethfk_3c361341:


    beth "On dirait que quelqu'un est plutôt content par ici..."


translate french bethfk_e8312706:


    beth "Voyons voir si il peut satisfaire sa maîtresse..."


translate french bethfk_a2dea0d7:


    beth "Oui... Comme ça..."


translate french bethfk_a6577c4d:


    dpense "Son parfum... c'est ennivrant..."


translate french bethfk_3b58e07c:


    dpense "Et sa main si directive..."


translate french bethfk_20a6cdda:


    beth "Oh ! Tu es plus gros que je ne le pensais..."


translate french bethfk_97edf3ed:


    beth "Je pense que tu pourrais vraiment m'être utile..."


translate french bethfk_793e600c:


    dpense "Bien sûr que je vais être utile !"


translate french bethfk_f5b4fd52:


    dpense "J'imagine déjà ce que je suis capable de te faire..."


translate french bethfk_8ea4dc7f:


    beth "Quand j'aurai décidé que tu le mérites..."


translate french bethfk_31faee72:


    beth "Tu ferais bien d'être prêt..."


translate french bethfk_484bc7d1:


    dpense "Je le suis déjà..."


translate french bethfk_da1a2c02:


    beth "Mais... En attendant..."


translate french bethfk_2413472c:


    beth "Couché, panier !"


translate french bethfk_26d97def:


    d "Mais non ! Allez !"


translate french bethfk_e4036794:


    dpense "Je sais pas où je me suis fourré..."


translate french bethfk_ef4b9cad:


    ruby "{i}Stupide Cortex...{/i}"


translate french bethfk_0581bacf:


    d "Je sais pas quelle mouche t'a piqué..."


translate french bethfk_6f39147c:


    d "Mais je ne veux pas que mes lèvres aillent se fourrer n'importe où..."


translate french bethfk_2d547900:


    beth "N'importe où ? Tu penses vraiment que n'importe qui peut toucher ce corps ?"


translate french bethfk_49e6c461:


    beth "Ecoutes moi bien le Français, tu brûleras en enfer avant d'avoir à nouveau cette opportunité..."


translate french bethfk_d2bf6605:


    d "Je ne sais pas pourquoi... Mais je pense que tu y seras avant moi Salamèche !"


translate french bethfk_0a4b4b2c:


    ruby "{i} Il est incroyable... {/i}"

translate french strings:


    old "Go for the kiss"
    new "Lui montrer ce qu'est un french kiss"


    old "Refuse"
    new "La repousser"




translate french sofiabj_9c5ddf66:


    d "Waaaah ! Qu'est ce que tu fous là toi ?"


translate french sofiabj_36c8ebe5:


    sofia "Ben en fait... Je dois dire que tu m'as laissé une sacrée impression aujourd'hui..."


translate french sofiabj_65c5b248:


    sofia "ET... Quand j'ai ces... Impressions..."


translate french sofiabj_e57aa0b9:


    sofia "J'ai besoin de satisfaire ma..."


translate french sofiabj_c67bd742:


    sofia "Curiosité..."


translate french sofiabj_0ace3fae:


    sofia "Alors... Dis moi Mister Frenchie..."


translate french sofiabj_a44e81b1:


    sofia "Aurais-tu quelque chose qui puisse me satisfaire ?"


translate french sofiabj_2384fcb7:


    sofia "Où vas tu continuer à courir après le cul de la petite vierge..."


translate french sofiabj_d2275832:


    sofia "Alors que tu pourrais jouer sans limites..."


translate french sofiabj_5cd1ddff:


    sofia "Avec un corps entier et sexy..."


translate french sofiabj_ee9f6ab6:


    d "Euh, c'est une coutume locale d'avoir des filles qui viennent dans le vestiaire des garçons ?"


translate french sofiabj_7b6ea50e:


    d "Où c'est juste l'occase de voir un nouveau à poil ?"


translate french sofiabj_ead8235f:


    sofia "Hum... C'est une coutume française de montrer tout le paquet sans la moindre honte ?"


translate french sofiabj_5b05403c:


    d "Hey ! C'est toi qui est venue là ! Je t'ai rien demandé !"


translate french sofiabj_4ee18543:


    sofia "En plus le paquet est pas aussi gros que je l'avais imaginé..."


translate french sofiabj_7863e362:


    sofia "Pas sûre que tu puisses me donner.... Comment as-tu dit déjà ? Une carabifle ! "


translate french sofiabj_1df8b557:


    d "La douche était froide..."


translate french sofiabj_221e359c:


    d "Mais... Tu veux t'en occuper ? Peut être que t'es assez douée pour en faire quelque chose ?"


translate french sofiabj_b31d7ba7:


    d "Ou alors cette bouche est juste pour dire de la merde ?"


translate french sofiabj_46603bb8:


    sofia "Oh... Vlà que Monsieur se sent pousser des ailes ?"


translate french sofiabj_dff221f1:


    sofia "J'ai pas pour habitude de jouer avec les perdants..."


translate french sofiabj_09d2129f:


    sofia "Mais avec ce que j'ai vu plus tôt..."


translate french sofiabj_d7394d4d:


    sofia "Je pense que tu mérites un lot de consolation..."


translate french sofiabj_2ad66fc4:


    sofia "Et qu'est ce qu'il se passerait si j'ajoutais un peu de..."


translate french sofiabj_bbf61877:


    sofia "Motivation..."


translate french sofiabj_e4a37cb5:


    sofia "Pour notre petit gars..."


translate french sofiabj_8a63b182:


    d "Je pense que tu peux faire plus que ça..."


translate french sofiabj_caddeb77:


    sofia "Confiant et gourmand... Quel homme !"


translate french sofiabj_d85273de:


    sofia "Okay Frencchie... Tu veux jouer ?"


translate french sofiabj_6839384e:


    sofia "Voyons voir comment tu tiens face à moi..."


translate french sofiabj_8ce2bde3:


    sofia "Et si tu réussis à m'impressionner... ne serait-ce qu'un petit peu..."


translate french sofiabj_8405f452:


    sofia "Peut être que je te laisserai jouer avec moi..."


translate french sofiabj_e75e0f01:


    sofia "Alors... Deal ?"


translate french sofiabj_21434d16:


    d "On a un Deal la bleusaille..."


translate french sofiabj_93f7f7d7:


    sofia "Sofia... J'ai un prénom espèce de trouduc..."


translate french sofiabj_a399e704:


    sofia "Et je te conseille de pas rigoler sur ça pendant que je tiens ta bite dans ma main..."


translate french sofiabj_1ac0edce:


    sofia "Maintenant... Stop la parlotte... Place à l'action..."


translate french sofiabj_2bb9fb81:


    mad "Bâtard..."


translate french sofiabj_7c871c87:


    mad "Tous les mêmes..."


translate french sofiabj_2b2db848:


    d "Bon Sofia... Tu peux faire mieux je pense..."


translate french sofiabj_ebcdaa5a:


    sofia "Je crois que c'est à moi de te dire ça !"


translate french sofiabj_b49239f2:


    d "Puisque tu l'as demandé..."


translate french sofiabj_71957600:


    sofia "Ohhh..."


translate french sofiabj_e8006c39:


    sofia "Qu'est ce que c'est que..."


translate french sofiabj_4dbe7388:


    sofia "Ce truc ?"


translate french sofiabj_248c587d:


    sofia "Wow okay... Maintenant on peut discuter !"


translate french sofiabj_92442ef8:


    d "Alors... Impressionnée ?"


translate french sofiabj_768930d5:


    sofia "Pas du tout..."


translate french sofiabj_c30f547e:


    d "Même pas un petit peu ?"


translate french sofiabj_882be446:


    sofia "Peut être..."


translate french sofiabj_cb3c584d:


    sofia "Bon... Voyons comment tu vas réagir à ça..."


translate french sofiabj_d088a656:


    d "Wow... Tu sais utiliser ta langue !"


translate french sofiabj_42db099b:


    sofia "Pas seulement ma langue !"


translate french sofiabj_07d235c4:


    d "Ohhhh ?"


translate french sofiabj_1908f85f:


    sofia "Alors ?"


translate french sofiabj_122c476a:


    d "Pas mal... Tu pourrais le faire plus vite par contre..."


translate french sofiabj_1abffde1:


    sofia "Tu penses être en position de me donner des ordres ?"


translate french sofiabj_f529413b:


    d "Et ta mère t'as jamais appris à ne pas parler la bouche pleine ?"


translate french sofiabj_483b7906:


    sofia "Oh ta gueule..."


translate french sofiabj_b6797206:


    dpense "Putain cette bouche... J'ai tellement envie de la défoncer..."


translate french sofiabj_eb2b1e31:


    dpense "C'est un aspirateur ou quoi ??? Je suis déjà à ma limite !"


translate french sofiabj_38e37bbd:


    d "Je vais pas pouvoir tenir beaucoup plus longtemps !"


translate french sofiabj_320e7128:


    sofia "Ne te retiens pas ! Allez Frenchie ! Donne moi tout !"


translate french sofiabj_fadae4f3:


    dpense "T'inquiètes que je vais tout te donner ! Tout dans ta putain de bouche !"


translate french sofiabj_dad3c95e:


    d "Ahhhhhhhhhhhhh !!!"


translate french sofiabj_d9e8a884:


    d "Ohhh..."


translate french sofiabj_7fb3f60d:


    d "Putain... Tu m'as vidé..."


translate french sofiabj_d3db81d2:


    sofia "Humhum..."


translate french sofiabj_7e015a72:


    sofia "{i}Gulp{/i}"


translate french sofiabj_a2ca227f:


    sofia "Pas mauvais !"


translate french sofiabj_25f7182f:


    sofia "Bon... Maintenant que notre petit arrangement est scellé... Continue à perfer pendant la compétition..."


translate french sofiabj_2f2dd27a:


    d "C'est ce qui est prévu..."


translate french sofiabj_e68d49c9:


    sofia "J'espère bien... Parce que j'ai vraiment, vraiment envie de rejouer avec notre ami commun..."


translate french sofiabj_876533ea:


    d "Tu voudras plus t'arrêter après ça..."


translate french sofiabj_6ece4bdc:


    sofia "C'est pas mon intention..."


translate french sofiabj_0e4e8906:


    sofia "A plus tard le Français !"


translate french sofiabj_c81eac44:


    d "Ouais ouais..."


translate french sofiabj_e4036794:


    dpense "Putain... Dans quoi je me suis fourré ?"


translate french sofiabj_a9ef37dd:


    d "Bon si t'as rien de mieux à faire... Peut être que tu peux aller voir ailleurs si j'y suis ?"


translate french sofiabj_a81b1440:


    sofia "Tu te fous de ma gueule ?"


translate french sofiabj_41ab0038:


    d "Nan..."


translate french sofiabj_3b22e690:


    sofia "N'essaye... Jamais plus... De me parler... Bâtard !!!"


translate french sofiabj_93c9e4c4:


    d "T'inquiètes pas ! C'était pas au programme !"


translate french sofiabj_c81977b0:


    mad "{i}Glousse{/i}"


translate french sofiabj_223a7be2:


    mad "Peut être que c'est un bon finalement..."


translate french bethfk_c15e4493:


    beth "Besoins..."


translate french final_4a598229:


    "M ? Ouais..."


translate french final_aec9e18d:


    "Il est sous contrôle..."


translate french final_b3893525:


    "Il ne sera plus une menace pour toi..."


translate french final_8bda4787:


    "Je vais faire de mon mieux pour le garder au plus loin de ces filles..."


translate french final_894d2571:


    "Ouais je sais..."


translate french final_b2ae06ee:


    "On se voit pour le Tournoi..."


translate french final_9669528e:


    "A plus tard..."

translate french strings:


    old "Provoke her"
    new "La provoquer"


    old "Tell her to go away"
    new "Lui dire de dégager"




translate french trialfin_b5b7b9d4:


    cr "Dans le premier Test, il n'y avait pas de MAUVAISES actions... Mais attention, dans les prochains il y en aura..."


translate french bethfk_e939f4bf:


    dpense "Je dois faire attention à lui..."


translate french bethfk_a98aac7a:


    dpense "Et les jumelles..."


translate french bethfk_855006e5:


    beth "Surprise !"


translate french bethfk_72661536:


    beth "Je t'ai dit que je gardais un oeil sur toi..."


translate french bethfk_2573a943:


    beth "Oui oui... Petite Ruby... La Capitaine... Même la Sainte Marie Julia..."


translate french bethfk_20b6923b:


    beth "Dommage que je n'ai pas quelqu'un comme toi pour prendre soin de mes..."


translate french bethfk_9f04486c:


    beth "Profondément..."


translate french bethfk_ae82b41a:


    dpense "Sa langue... Ses lèvres... Ce corps..."


translate french bethfk_39d96f0d:


    beth "Ah, Y'en a un qui devient gourmand..."


translate french bethfk_9a65c14b:


    beth "J'ai des trus à faire, mais..."


translate french bethfk_5454bf4f:


    beth "On dirait que quelqu'un est content par ici... Hmmm..."


translate french bethfk_ce041d5c:


    beth "Voyons voir s'il a ce qu'il faut pour satisfaire sa maîtresse..."


translate french bethfk_aaea4612:


    dpense "Et sa main est si ferme... et douce à la fois..."


translate french bethfk_dc594ee6:


    beth "Oh, plus gros que je ne le pensais..."


translate french bethfk_acbb7edf:


    beth "Quand j'aurai décidé que tu le mérites..."


translate french bethfk_e96e2b0e:


    dpense "Je le suis... Maintenant !"


translate french bethfk_637a238f:


    dpense "Je ne sais pas dans quoi je me suis fourré..."


translate french bethfk_5e5295e8:


    d "Mais je n'ai pas envie de fourrer mes lèvres n'importe où..."


translate french bethfk_d83a94e7:


    beth "N'importe où ? Tu crois vraiment que je laisse n'importe qui toucher à ce corps ?"


translate french bethfk_d2d7e74c:


    beth "Ecoute moi bien Frenchie de mes deux... Il gêlera en enfer avant que tu n'aies de nouveau cette chance... "


translate french bethfk_85be18e2:


    d "Je ne sais pas... J'ai appris que le réchauffement climatique avait l'effet opposé en enfer. Donc, au pire, Prend tes bottes de neige Salamèche !"




translate french sofiabj_01d20d04:


    d "On a un deal Blue..."




translate french sofiabj_c15f7194:


    dpense "Putain mais c'est un aspirateur ??? Je suis déjà prêt à exploser !"


translate french sofiabj_cbc2a050:


    sofia "Bien... Maintenant que nous avons un marché... Continue à perfer pendant la compétition..."


translate french sofiabj_637a238f:


    dpense "Je sais pas dans quoi je me suis fourré..."




translate french bluejob_221e359c:


    d "Alors... Peut être que tu peux faire quelque chose à ce sujet ?"


translate french bluejob_b31d7ba7:


    d "Où cette bouche est là juste pour faire joli ?"


translate french bluejob_46603bb8:


    sofia "Oh... Voilà que Monsieur se sent pousser des ailes..."


translate french bluejob_dff221f1:


    sofia "Je n'ai pas pour habitude de jouer avec les perdants..."


translate french bluejob_09d2129f:


    sofia "Mais avec ce que j'ai vu plus tôt..."


translate french bluejob_d7394d4d:


    sofia "Je pense que tu mérites un lot de consolation..."


translate french bluejob_2ad66fc4:


    sofia "Et que se passerait-il si..."


translate french bluejob_bbf61877:


    sofia "J'ajoutais un peu de motivation..."


translate french bluejob_e4a37cb5:


    sofia "Pour notre petit gars..."


translate french bluejob_8a63b182:


    d "Je pense que tu peux faire plus..."


translate french bluejob_caddeb77:


    sofia "Confiant et gourmand... Quel homme !"


translate french bluejob_d85273de:


    sofia "Okay le Français... Tu veux jouer ?"


translate french bluejob_6839384e:


    sofia "Voyons voir comment tu tiens face à moi..."


translate french bluejob_8ce2bde3:


    sofia "Et si tu réussis à m'impressionner... ne serait-ce qu'un petit peu..."


translate french bluejob_8405f452:


    sofia "Peut être que je te laisserai jouer avec moi..."


translate french bluejob_e75e0f01:


    sofia "Alors... Marché conclu ?"


translate french bluejob_01d20d04:


    d "Marché conclu la bleusaille..."


translate french bluejob_93f7f7d7:


    sofia "Sofia... J'ai un prénom trou du cul..."


translate french bluejob_a399e704:


    sofia "ET à ta place j'éviterai de déconner avec ça pendant que je tiens ta bite dans ma main...."


translate french bluejob_1ac0edce:


    sofia "Maintenant... Fini la parlotte... Place à l'action..."


translate french bluejob_2bb9fb81:


    mad "Trou du cul..."


translate french bluejob_7c871c87:


    mad "Tous les mêmes..."


translate french bluejob_2b2db848:


    d "Allons Sofia... Tu peux faire mieux que ça !"


translate french bluejob_ebcdaa5a:


    sofia "Je crois que c'est à moi de dire ça !"


translate french bluejob_b49239f2:


    d "Okay... Puisque tu le demande si gentiment..."


translate french bluejob_71957600:


    sofia "Ohhh..."


translate french bluejob_e8006c39:


    sofia "Mais c'est quoi ???"


translate french bluejob_4dbe7388:


    sofia "Ca ???"


translate french bluejob_248c587d:


    sofia "Ohhhh... Maintenant on peut discuter !"


translate french bluejob_92442ef8:


    d "Alors... Impressionnée ?"


translate french bluejob_768930d5:


    sofia "Nan nan..."


translate french bluejob_c30f547e:


    d "Même pas un petit peu ?"


translate french bluejob_882be446:


    sofia "Peut être..."


translate french bluejob_cb3c584d:


    sofia "Voyons voir comment tu vas tenir face à ça..."


translate french bluejob_d088a656:


    d "Wow wow wow... Tu sais te servir de ta langue !"


translate french bluejob_42db099b:


    sofia "Pas seulement ma langue !"


translate french bluejob_07d235c4:


    d "Hein ?"


translate french bluejob_1908f85f:


    sofia "Alors ?"


translate french bluejob_122c476a:


    d "Pas mal... Tu peux le faire un peu plus vite ?"


translate french bluejob_1abffde1:


    sofia "Tu penses que tu es en position de me donner des ordres ?"


translate french bluejob_f529413b:


    d "Et ta mère ne t'a jamais appris à ne pas parler la bouche pleine ?"


translate french bluejob_483b7906:


    sofia "Ta gueule..."


translate french bluejob_b6797206:


    dpense "Cette bouche... J'ai envie de la défoncer comme un barbare..."


translate french bluejob_c15f7194:


    dpense "Putain mais c'est un aspirateur ou quoi ? Je suis déjà prêt à exploser !"


translate french bluejob_38e37bbd:


    d "Je vais pas pouvoir tenir plus longtemps !"


translate french bluejob_320e7128:


    sofia "Ne te retiens pas ! Allez le Frenchie ! Donne moi tout ce que t'as !"


translate french bluejob_fadae4f3:


    dpense "Putain... Je vais tout te donner... Dans ta putain de bouche..."


translate french bluejob_dad3c95e:


    d "Ahhhhhhhhhhhh !!!"


translate french bluejob_d9e8a884:


    d "Ohhhh..."


translate french bluejob_7fb3f60d:


    d "La vache... Tu m'as vidé..."


translate french bluejob_d3db81d2:


    sofia "Humhum..."


translate french bluejob_7e015a72:


    sofia "{i}Gulp{/i}"


translate french bluejob_a2ca227f:


    sofia "Pas mauvais !"


translate french bluejob_cbc2a050:


    sofia "Bon... Maintenant que nous avons notre petite affaire... Continue à perfer pendant la compétition !"


translate french bluejob_2f2dd27a:


    d "C'est prévu t'inquiètes..."


translate french bluejob_e68d49c9:


    sofia "J'espère bien ! Parce que j'ai vraiment, vraiment, envie de rejouer avec notre copain en commun..."


translate french bluejob_876533ea:


    d "Tu voudras plus t'arrêter après ça..."


translate french bluejob_6ece4bdc:


    sofia "J'en ai pas l'intention !"


translate french bluejob_0e4e8906:


    sofia "Allez ciao Frenchie !"


translate french bluejob_c81eac44:


    d "Ouais ouais..."


translate french bluejob_637a238f:


    dpense "Où est ce que je me suis fourré..."


translate french bluejob_a9ef37dd:


    d "Si tu n'as rien de mieux à faire... Peut être que tu peux aller voir ailleurs si j'y suis ?"


translate french bluejob_a81b1440:


    sofia "Tu te fous de ma gueule ?"


translate french bluejob_41ab0038:


    d "Nan nan..."


translate french bluejob_3b22e690:


    sofia "Putain mais ne viens... Plus... Jamais.. essayer de me parler... Bâtard !"


translate french bluejob_93c9e4c4:


    d "T'inquiètes pas ! C'était pas prévu !"


translate french bluejob_c81977b0:


    mad "{i}Glousse{/i}"


translate french bluejob_223a7be2:


    mad "Peut être que c'est un bon lui..."


translate french redkiss_3800def7:


    dpense "Wahhhhh... Je dois être en train de rêver..."


translate french redkiss_ae82b41a:


    dpense "Sa langue... ses lèvres... ce corps..."


translate french redkiss_60123473:


    dpense "Oh putain... J'ai envie de..."


translate french redkiss_08da671f:


    beth "Ohhhh..."


translate french redkiss_566ac1ae:


    beth "{i}Hmmmmm....{/i}"


translate french redkiss_21da8e20:


    dpense "Je pourrais sucer cette langue pendant des heures..."


translate french redkiss_c9c80cfe:


    dpense "Et ces seins sont fabuleux..."


translate french redkiss_fba25779:


    dpense "Je..."


translate french redkiss_39d96f0d:


    beth "AH, y'en a un qui arrive plus à se tenir..."


translate french redkiss_5becaa9e:


    beth "Je crois que j'ai juste parlé d'un baiser..."


translate french redkiss_16d05a4b:


    beth "Maintenant si tu veux bien m'excuser..."


translate french redkiss_7b56213b:


    d "Où tu vas ?"


translate french redkiss_9a65c14b:


    beth "J'ai d'autres choses à faire, mais..."


translate french redkiss_5454bf4f:


    beth "On dirait que quelqu'un est content... Ici... Hmmm..."


translate french redkiss_ce041d5c:


    beth "Voyons voir si il peut satisfaire sa maîtresse..."


translate french redkiss_a2dea0d7:


    beth "Oui... Comme ça..."


translate french redkiss_a6577c4d:


    dpense "Son parfum... C'est ennivrant..."


translate french redkiss_aaea4612:


    dpense "Et sa main... si forte et si douce à la fois..."


translate french redkiss_dc594ee6:


    beth "Oh, tu es plus gros que je ne le pensais..."


translate french redkiss_97edf3ed:


    beth "Tu pourrais vraiment m'être utile..."


translate french redkiss_793e600c:


    dpense "Evidemment que je peux être utile..."


translate french redkiss_f5b4fd52:


    dpense "J'imagine déjà tout ce que j'aimerai te faire..."


translate french redkiss_acbb7edf:


    beth "Quand j'aurai décidé que tu le mérites..."


translate french redkiss_31faee72:


    beth "T'as intérêt à être prêt..."


translate french redkiss_e96e2b0e:


    dpense "Je suis prêt !"


translate french redkiss_da1a2c02:


    beth "Mais... En attendant..."


translate french redkiss_2413472c:


    beth "Couché, panier !"


translate french redkiss_26d97def:


    d "Allez !"


translate french redkiss_637a238f:


    dpense "Putain... Mais dans quoi est ce que je me suis fourré ?"


translate french redkiss_ef4b9cad:


    ruby "{i}Stupide Cortex...{/i}"


translate french redkiss_0581bacf:


    d "Je ne sais pas ce qui t'es passé par la tête..."


translate french redkiss_5e5295e8:


    d "Mais je n'ai pas envie d'avoir mes lèvres aller n'importe où..."


translate french redkiss_d83a94e7:


    beth "N'importe où ? Tu crois vraiment que tout le monde peut toucher à ce corps ?"


translate french redkiss_d2d7e74c:


    beth "Ecoute moi bien, Français de mes deux. Il gêlera en enfer quand tu auras de nouveau l'occase d'avoir ce que tu viens de râter..."


translate french redkiss_85be18e2:


    d "Mouais... Paraît que le réchauffement climatique fait l'inverse en enfer... donc prépare tes bottes et tes après-ski Salamèche... ça va glisser !"


translate french redkiss_0a4b4b2c:


    ruby "{i} Il est incroyable... {/i}"

translate french strings:


    old "New Scene Gallery added"
    new "Scène ajoutée à la gallerie"




translate french final_4a598229_1:


    "M ? Ouais..."


translate french final_aec9e18d_1:


    "Il est sous contrôle..."


translate french final_b3893525_1:


    "Il ne sera plus une menace pour toi..."


translate french final_8bda4787_1:


    "Je vais faire de mon mieux pour le tenir éloigné de ces filles..."


translate french final_894d2571_1:


    "Ouais je sais..."


translate french final_b2ae06ee_1:


    "On se voit pendant le tournoi..."


translate french final_9669528e_1:


    "A plus tard..."




translate french e1s4_1bab997e:


    dpense "Bon... On dirait qu'il va falloir sauter, passer la poutre, et monter un mur super haut..."


translate french e1s4_5470ffc5:


    d "Tu t'étires ?"


translate french e1s4_fb09c47b:


    julia "Pervers... Mais gentleman !"


translate french e1s4_fb09c47b_1:


    julia "Pervers... Mais gentleman !"


translate french trial4_cc180ec8:


    dpense "Il doit bien y avoir un indice quelque part...."


translate french trial4_a206b243:


    d "Bagage ? Quel bagage ?"


translate french trial5_c2508f98:


    d "On doit tout refaire dans l'autre sens ?"


translate french trial5_67022165:


    mad "Continue comme ça et je pourrais te tolérer !"


translate french trial5_c2508f98_1:


    d "On doit tout refaire dans l'autre sens ?"


translate french trialfin_6f496e2c:


    orushi "Je dois dire que plusieurs ont abandonné au Grand Mur, quand d'autres n'ont toujours pas retrouvé leur bagage !"


translate french trialfin_ccc055be:


    cr "Dans cette première épreuve il n'y avait pas de MAUVAISE action... Mais dans les prochains certains choix ou actions auront des répercussions... Faites attention !"


translate french final1_8bfacc8f:


    cr "Vous n'avez pas fini dans les premiers et Beth ne s'intéresse pas à vous... Pas de récompense des jumelles pour vous !"


translate french sofiabj_5ab2b6e7:


    d "Euh... C'est une habitude des filles d'ici de venir dans le vestiaire ?"


translate french sofiabj_c890f437:


    sofia "Hmmm, c'est une habitude des Français de laisser les filles voir leur paquet sans aucune gêne ?"


translate french sofiabj_ba6905d9:


    sofia "Et en parlant de paquet... Pas aussi gros que je l'avais imaginé..."


translate french sofiabj_25ed2fde:


    sofia "Je suis pas sûre que tu arriveras à faire de moi une... Comment tu as dit ça ? Gicleuse ?"


translate french sofiabj_59892900:


    d "La douche était froide..."


translate french bluejob_9864ef2f:


    sofia "Oh... Quelqu'un a trouvé du courage ?"


translate french bluejob_35e464ec:


    sofia "Okay Frenchie... Tu veux jouer ?"


translate french bethfk_a4645742:


    dpense "Les filles m'aiment bien..."


translate french bethfk_bbcedabb:


    beth "Dommage que je n'ai pas quelqu'un comme toi qui pourrait prendre soin de moi..."


translate french redkiss_1b0fd802:


    beth "N'importe où ? Tu crois vraiment que tout le monde peut toucher ce corps ?"


translate french final_b10b320a:


    "Il ne sera plus une menace..."


translate french final_b10b320a_1:


    "Il ne sera plus une menace..."




translate french bethfk_4a3e4292:


    beth "Mes besoins..."



translate french strings:


    old "Help Julia [TEMP1]"
    new "Aider Julia [TEMP1]"


    old "Continue [TEMP2]"
    new "Continuer [TEMP2]"


    old "Help the girls [TEMP1]"
    new "Aider les filles [TEMP1]"


    old "Do it like Madison [TEMP1]"
    new "Joue là comme Madison [TEMP1]"


    old "Help the girls [TEMP2]"
    new "Aider les filles [TEMP2]"


    old "Join Madison [TEMP1]"
    new "Rejoindre Madison [TEMP1]"


    old "Encourage Madison [TEMP2]"
    new "Encourager Madison [TEMP2]"


    old "Join Julia [TEMP1]"
    new "Rejoindre Julia [TEMP1]"


    old "Encourage Girls [TEMP2]"
    new "Encourage les filles [TEMP2]"


    old "Remember [TEMP1]"
    new "Se rappeler [TEMP1]"


    old "Wait for girls [TEMP2]"
    new "Attendre les filles [TEMP2]"


    old "Provoke her [TEMP1]"
    new "La provoquer [TEMP1]"


    old "Tell her to go away [TEMP2]"
    new "L'envoyer bouler [TEMP2]"


    old "Go for the kiss [TEMP1]"
    new "L'embrasser [TEMP1]"


    old "Refuse [TEMP2]"
    new "Refuser [TEMP2]"



translate french strings:


    old "Help Julia [TEMP1!t]"
    new "Aider Julia [TEMP1!t]"


    old "Continue [TEMP2!t]"
    new "Continuer [TEMP2!t]"


    old "Help the girls [TEMP1!t]"
    new "Aider les filles [TEMP1!t]"


    old "Do it like Madison [TEMP1!t]"
    new "Rejoindre Madison [TEMP1!t]"


    old "Help the girls [TEMP2!t]"
    new "Aider les filles [TEMP2!t]"


    old "Join Madison [TEMP1!t]"
    new "Rejoindre Madison [TEMP1!t]"


    old "Encourage Madison [TEMP2!t]"
    new "Encourager Madison [TEMP2!t]"


    old "Join Julia [TEMP1!t]"
    new "Rejoindre Julia [TEMP1!t]"


    old "Encourage Girls [TEMP2!t]"
    new "Encourager les filles [TEMP2!t]"


    old "Remember [TEMP1!t]"
    new "Se rappeler [TEMP1!t]"


    old "Wait for girls [TEMP2!t]"
    new "Attendre les filles [TEMP2!t]"


    old "Provoke her [TEMP1!t]"
    new "La provoquer [TEMP1!t]"


    old "Tell her to go away [TEMP2!t]"
    new "L'envoyer bouler [TEMP2!t]"


    old "Go for the kiss [TEMP1!t]"
    new "L'embrasser [TEMP1!t]"


    old "Refuse [TEMP2!t]"
    new "Refuser [TEMP2!t]"




translate french e1s4_db02abfd:


    dpense "Les filles sont parties se changer dans leur vestiaire..."


translate french trial3_2a135b5e:


    dpense "Okay... Elle m'en veut..."


translate french trial4_d9f3189b:


    drew "VOUS DEVEZ RETROUVER VOTRE BAGAGE ET REPARTIR AVEC EN DIRECTION DE L'AMPHITHEATRE..."


translate french trial4_ab1a0815:


    drew "J'en ai déjà trop dit... Demain vous comprendrez..."


translate french trial4_ab1a0815_1:


    drew "J'en ai déjà trop dit... Demain vous comprendrez..."


translate french trial4_ab1a0815_2:


    drew "J'en ai déjà trop dit... Demain vous comprendrez..."


translate french trial5_78e34d14:


    d "On doit se refaire tout le chemin en sens inverse ?"


translate french trial5_2f2a683b:


    emerick "Mais toi, le Frenchy... Tu m'as impressionné..."


translate french trial5_f07c88c7:


    d "On doit se refaire tout le chemin en sens inverse ?"


translate french sofiabj_6413fc68:


    d "Ou c'était juste l'occasion de voir un nouveau à poil ?"


translate french sofiabj_45991d45:


    sofia "Hmm... C'est une coutume de Français de laisser une fille voir tout le paquet sans gêne ?"


translate french bluejob_fe933c48:


    sofia "Mais avec ce que j'ai vu plus tôt..."


translate french bluejob_4f004b7d:


    sofia "Je pense que je pourrais te dire la même chose !"


translate french bethfk_949548e4:


    dpense "Cet Emerick me paraît dangereux..."


translate french bethfk_8d3edbc7:


    beth "Je t'ai dit que je te surveillais..."


translate french redkiss_d62019b2:


    beth "Je pense avoir juste parlé d'un baiser..."


translate french redkiss_a695e7ba:


    beth "Quand j'aurai décidé que tu le mérites..."


translate french redkiss_0786e21b:


    beth "Tu ferais mieux d'être prêt..."


translate french redkiss_73b76202:


    d "Je ne sais pas. J'ai entendu dire que le réchauffement climatique avait un effet opposé en Enfer. Alors chausse tes après-skis Salamèche, ça va glisser !"




translate french sofiabj_45991d45_1:


    sofia "Hmmm... C'est une habitude des Frenchies de laisser les filles voir tout le paquet sans gêne ?"


translate french sofiabj_5b05403c_1:


    d "Hey ! C'est toi qui est venue ici ! Je t'ai rien demandé !"


translate french sofiabj_ba6905d9_1:


    sofia "Ouais... Et le paquet n'est pas aussi gros que je ne le pensais..."


translate french sofiabj_25ed2fde_1:


    sofia "Pas sûre que tu puisses... Comment tu as dit ? Me faire évoluer ?"


translate french sofiabj_59892900_1:


    d "La douche était froide..."


translate french bluejob_bbf61877_1:


    sofia "Motivation..."


translate french bluejob_e4a37cb5_1:


    sofia "Pour notre petit gars là..."


translate french bluejob_8a63b182_1:


    d "Je pense que tu peux faire mieux..."


translate french bluejob_caddeb77_1:


    sofia "Il a des couilles et en plus il essaye d'en avoir plus... Quel homme !"


translate french bluejob_35e464ec_1:


    sofia "Okay le Frenchie... Tu veux jouer ?"


translate french bluejob_6839384e_1:


    sofia "Voyons voir combien de temps tu tiendras façe à moi..."


translate french bluejob_8ce2bde3_1:


    sofia "Et si tu réussis à m'impressionner... Juste un petit peu..."


translate french bluejob_8405f452_1:


    sofia "Peut être que je te laisserai jouer avec moi..."


translate french bluejob_e75e0f01_1:


    sofia "Alors... Marché conclu ?"


translate french bluejob_01d20d04_1:


    d "Marché conclu Blue..."


translate french bluejob_93f7f7d7_1:


    sofia "Sofia... J'ai un prénom trouduc..."


translate french bluejob_1ac0edce_1:


    sofia "Maintenant... Moins de blabla... Action..."


translate french bluejob_2bb9fb81_1:


    mad "Connard..."


translate french bluejob_7c871c87_1:


    mad "Tous les mêmes..."


translate french finchoixblue_cbc2a050:


    sofia "Et bien... Maintenant que notre petit arrangement est scellé... Continue à performer pendant la compétition !"


translate french finchoixblue_2f2dd27a:


    d "T'inquiètes pas pour ça..."


translate french finchoixblue_e68d49c9:


    sofia "J'espère bien... Parce que j'ai vraiment, vraiment envie de rejouer avec notre ami commun..."


translate french finchoixblue_876533ea:


    d "Tu pourras plus t'arrêter après ça..."


translate french finchoixblue_6ece4bdc:


    sofia "J'en ai pas l'intention !"


translate french finchoixblue_0e4e8906:


    sofia "A plus tard le Frenchie !"


translate french finchoixblue_c81eac44:


    d "Ouais ouais..."


translate french finchoixblue_637a238f:


    dpense "Où est-ce que je me suis fourré ?"


translate french finchoixblue_a9ef37dd:


    d "Euh... Si t'as rien d'autre à faire... Tu peux aller voir là-bas si j'y suis ?"


translate french finchoixblue_a81b1440:


    sofia "Tu te fous de moi ?"


translate french finchoixblue_41ab0038:


    d "Euh.... Nan !"


translate french finchoixblue_3b22e690:


    sofia "Ne... Reviens plus jamais me voir... Bâtard !!!"


translate french finchoixblue_93c9e4c4:


    d "Oh t'inquiètes pas pour ça ! Ca risque pas !"


translate french finchoixblue_c81977b0:


    mad "{i}Haha{/i}"


translate french finchoixblue_223a7be2:


    mad "C'est peut être un bon celui-là..."




translate french trial4_08132be7:


    drew "VOUS DEVEZ TROUVER VOTRE BAGAGE ET L'EMPORTER AVEC VOUS JUSQU'A L'AMPHITHEATRE."


translate french trial5_21020def:


    mad "Vite ! L'amphi !"


translate french trial5_fa81ccee:


    mad "Je ne sais pas... mais tant qu'on court vers l'amphi, on peut gagner !"


translate french trial5_07f344d2:


    grace "Vite ! A l'amphi !"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
