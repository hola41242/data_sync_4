


translate french fin_c2a4549d:


    ji "Hey coucou ! On dirait que vous êtes arrivés à la fin du contenu de cette mise à jour ! J'espère que vous l'avez aimé ?"


translate french fin_57968a9f:


    ji "Les mises à jour sont d'abord mises en ligne sur Patreon..."


translate french fin_e6109cf4:


    cr "Ouais, quand je fais pas n'importe quoi avec les versions..."


translate french fin_8b41fb06:


    ji "Bon, donc, je disais... Si vous aimez le jeu, les filles... voir même les Créateurs... S'il vous plaît, pensez à montrer votre soutien !"


translate french fin_d130ac7a:


    ji "Dites ce que vous aimez, ce que vous voulez voir dans le jeu, quel personnage est votre préféré..."


translate french fin_459180bc:


    ji "Et si vous faites des dons via Patreon, les Créateurs pourront m'acheter des vêtements et J'ADORE les vêtements !"


translate french fin_6155034b:


    cr "Tu veux pas 100 balles et un mars non plus ?"


translate french fin_0722afa7:


    ji "...Bon ils pourront surtout acheter une nouvelle machine pour la création... en gros plus d'argent c'est plus de contenus, plus rapidement..."


translate french fin_d1f2e7be:


    cr "Sur ça tu as raison ! Une image ou une animation prend du temps .... et on n'a pas un ordi de la NASA..."


translate french fin_e878c34f:


    ji "Bref... Juste, pensez-y !"


translate french fin_2e1d206b:


    ji "Je vais pas vous garder plus longtemps..."


translate french fin_a4d5af8b:


    ji "J'espère vraiment vous revoir bientôt..."


translate french fin_382827ef:


    ji "A bientôt !"




translate french fin_d13211cd:


    julia "Hey coucou ! On dirait que vous êtes arrivés à la fin du contenu de cette mise à jour ! J'espère que vous l'avez aimé ?"


translate french fin_08bd4d80:


    julia "Les mises à jour sont d'abord mises en ligne sur Patreon..."


translate french fin_7c77b00a:


    julia "Bon, donc, je disais... Si vous aimez le jeu, les filles... voir même les Créateurs... S'il vous plaît, pensez à montrer votre soutien !"


translate french fin_f803f865:


    julia "Dites ce que vous aimez, ce que vous voulez voir dans le jeu, quel personnage est votre préféré..."


translate french fin_137fb79c:


    julia "Et si vous faites des dons via Patreon, les Créateurs pourront m'acheter des vêtements et J'ADORE les vêtements "


translate french fin_e17d85e1:


    julia "...Bon ils pourront surtout acheter une nouvelle machine pour la création... en gros plus d'argent c'est plus de contenus, plus rapidement..."


translate french fin_8556d080:


    julia "Bref... Juste, pensez-y !"


translate french fin_f77e1948:


    julia "Je vais pas vous garder plus longtemps..."


translate french fin_ac71f3ce:


    julia "J'espère vraiment vous revoir bientôt..."


translate french fin_5c8aa31e:


    julia "A bientôt !"




translate french fin_73504a9c:


    julia "J'espère vraiment que vous reviendrez !"




translate french fin_e7faf5ab:


    julia "Quand la mise à jour est déployée, les Créateurs la mettent d'abord sur Patreon..."


translate french fin_08fa1cc4:


    julia "Allez je ne vais pas vous garder plus longtemps..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
