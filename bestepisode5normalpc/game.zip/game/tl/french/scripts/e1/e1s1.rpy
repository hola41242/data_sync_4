


translate french e1s1_e5c597fd:


    dpense "Tout le monde connaît Madison Forrester... Ben pas moi !"


translate french e1s1_a70be8a3:


    dpense "Pourquoi est-elle si dure ?"


translate french e1s1_65c48bf6:


    dpense "Elle est incroyablement belle mais je ne supporte pas cette façon de parler..."


translate french e1s1_c92b4616:


    dpense "Et je ne sais pas où sont mes bagages..."


translate french e1s1_69bd3e17:


    d "Chauffeur ! On est encore loin de l'Academy ?"


translate french e1s1_8665f3d9:


    "On y est !" with vpunch


translate french e1s1_4149eb70:


    d "C'est pas l'Academy ! C'est un mur !"


translate french e1s1_45302e22:


    "Elle m'a demandé de vous déposer ici mon garçon."


translate french e1s1_79a98cf6:


    d "Elle ?"


translate french e1s1_371dcb1d:


    d "Qui ça elle ?"


translate french e1s1_e6a3617d:


    d "Et il est parti..."


translate french e1s1_df162717:


    dpense "Okay bon... où je suis ? Et c'est qui cette fille qui a demandé au chauffeur de me laisser à côté d'un mur ?"


translate french e1s1_c5e69234:


    dpense "Trop de questions sans réponses..."


translate french e1s1_8bee96b1:


    "Bienvenue en Amérique [name]"


translate french e1s1_6f4899e6:


    d "Qui ... Qui êtes-vous ? Et comment savez-vous comment je m'appelle ?"


translate french e1s1_0387823a:


    "Je suis Mrs. Drew, l'assistante de Mr. Orushi des entreprises Orushi. Et je suis aussi la directrice de l'Academy."


translate french e1s1_07e617a9:


    drew "Je sais tout ce que j'ai besoin de savoir sur vous [name]"


translate french e1s1_ec77f0b1:


    drew "Vous venez de France, étudiant légèrement au-dessus de la moyenne, avec quelques aptitudes sportives dues à l'entraînement et une bonne santé."


translate french e1s1_d64d0926:


    d "De quoi ? Vous m'avez espionné ?"


translate french e1s1_8d32d559:


    drew "Vous espionner ? Vous pensez être assez important pour qu'on mette quelqu'un en France pour espionner un ado lambda ?"


translate french e1s1_7eeb58f1:


    drew "Non... bien sûr que non."


translate french e1s1_b3db403f:


    drew "Vous êtes juste un chiffre sur un dossier... Et dans ce cas vous êtes le 90."


translate french e1s1_8b86fe0d:


    d "Le 90 ? Le 90 de quoi ?"


translate french e1s1_c296a65b:


    drew "J'en ai déjà trop dit... Demain vous comprendrez."


translate french e1s1_fd45f970:


    drew "Maintenant si vous voulez bien m'excuser, je vais vous présenter ma fille. Elle va vous montrer votre dortoir et votre chambre sur le campus."


translate french e1s1_8fd1e978:


    drew "Entrez, je vous en prie."


translate french e1s1_e714ec0e:


    drew "Vous allez voir ma fille est gentille et..."


translate french e1s1_06bd448a:


    drew "BOURREE ?" with hpunch


translate french e1s1_e8290730:


    drew "Grace ! Qu'est ce que t'es en train de faire ? Pourquoi tu bois toute seule à cette heure-ci ? Tu devrais te préparer pour demain !"


translate french e1s1_a8c3bcd8:


    grace "Oh Mère... Tu peux arrêter de me hurler dessus comme ça ? J'ai un putain de mal de tête !"


translate french e1s1_67eae1bf:


    drew "Grace ! Comment tu parles ! Nous avons un invité, alors change de ton et présente toi proprement !"


translate french e1s1_514f955e:


    grace "Oh mon dieu... okay je vais le faire. Mais tu devrais goûter ce Champagne, c'est divin !"


translate french e1s1_d95d77fd:


    grace "Désolée je suis Grace et vous êtes..."


translate french e1s1_d7ec0052:


    grace "L'attrapeur de fesses !"


translate french e1s1_8bb9bfa2:


    grace "Mère ! C'est un pervers !"


translate french e1s1_2f61cd1f:


    grace "Le campagnard !!!"


translate french e1s1_7be91fef:


    grace "Mère, ce gars est trop mignon ! Il a parlé avec Julia tout à l'heure et elle ne semblait pas insensible à ses charmes !"


translate french drewsuite_c214990b:


    drew "Allons Grace, ce n'est pas une façon de se présenter !"


translate french drewsuite_e1aae156:


    grace "Mais..."


translate french drewsuite_f9ed221e:


    drew "Y'à pas de mais !"


translate french drewsuite_d584d61f:


    drew "Désolée, ce doit être une terrible mésentente..."


translate french drewsuite_3f3108a6:


    drew "[name] voici Grace, ma fille."


translate french drewsuite_dec92f66:


    drew "Et Grace, voici [name], un étudiant français qui va venir à l'Academy avec nous pour ce semestre."


translate french drewsuite_9cbeac08:


    grace "Oui... d'accord mère..."


translate french drewsuite_db71b97f:


    grace "Je suis désolée [name], j'ai un peu trop bû et j'ai tendance à trop parler quand je suis un peu éméchée..."


translate french drewsuite_4523b2d5:


    drew "Bon maintenant que tout ceci est réglé..."


translate french drewsuite_696a8742:


    drew "Je ne crois pas que tu sois en état de montrer à [name] sa chambre et son dortoir, Grace..."


translate french drewsuite_4f707c1b:


    grace "Bien sûr que je le peux... Oof !" with vpunch


translate french drewsuite_24e2b9f5:


    drew "Tu as besoin de te reposer et j'ai plein de choses à régler."


translate french drewsuite_981fef1c:


    drew "Donc [name], je vous confie ma fille pour ce soir, gardez un oeil sur elle pour être sûr qu'elle ne continue pas à boire."


translate french drewsuite_89842c29:


    drew "Vous pouvez dormir sur le canapé et je vous enverrai quelqu'un à 8 heures demain matin pour vous emmener à votre chambre."


translate french drewangry_abb6b8a9:


    drew "Je dois vous rappeler que ce n'est sûrement pas un bon départ de me parler sur ce ton jeune homme. Je suis la directrice de l'Academy et je pense que vous voulez garder votre bourse... "


translate french drewangry_bff2d64d:


    d "Je suis désolé Mrs. Drew."


translate french drewangry_f64c1619:


    drew "Je préfère ça... Bon je dois y aller ! On se voit demain matin à 9 heures et ne soyez pas en retard !!!"


translate french drewangry_48cb0ac4:


    d "Ce sera fait..."


translate french drewok_0a468b43:


    drew "C'est ce que j'attendais... J'ai placé de grands espoirs en vous [name]. Ne me décevez pas... et vous serez bien récompensé."


translate french drewok_940dcceb:


    d "Je vais tout faire pour y arriver Mrs. Drew"


translate french drewok_792664f7:


    drew "Je dois y aller ! On se voit demain à 9 heures et ne soyez pas en retard !"


translate french drewok_48cb0ac4:


    d "Ce sera fait..."


translate french gracetip_2181f854:


    cr "Donnez moi juste un moment... Je veux juste être sûr que vous avez bien compris les règles du jeu !"


translate french gracetip_9674208e:


    cr "Même si je suis sûr que vous n'êtes pas bête, j'aimerais vérifier avec vous vos stats avant d'avancer plus loin dans l'histoire."


translate french gracetip_216f0561:


    cr "Alors regardons ça ! Ouvrez la fenêtre de stats s'il vous plaît !"


translate french gracetip_ac943f4c:


    cr "On dirait que vous avez déjà pris des décisions qui ont affecté votre personnage."


translate french gracetip_6a85a930:


    cr "Pour l'instant ce n'est pas très important..."


translate french gracetip_e4bf9eaf:


    cr "Peut être que si vous n'aviez pas essayé de chopper les fesses de Julia dans l'avion cela aurait changé ce que les filles pensent de vous ?"


translate french gracetip_666e6ece:


    cr "... Peut être que si vous aviez choppé les fesses de Julia dans l'avion cela aurait changé la perception des filles à votre égard ?"


translate french gracetip_858181c8:


    cr "Vous voyez, toutes les statistiques peuvent changer rapidement."


translate french gracetip_737ef232:


    cr "Je vous conseille de faire plusieurs sauvegardes, avec différents choix, parce que cela va affecter de futurs évènements, très bientôt."


translate french gracetip_7d746e81:


    cr "Bon ben c'est bon du coup on peut retourner au jeu. Amusez-vous bien !"


translate french gracetip_6c4282e7:


    d "Alors... heu ... Grace c'est ça ?"


translate french gracetip_456c3940:


    grace "Oui... c'est moi..."


translate french gracetip_2a9d73d8:


    d "Tu as besoin d'aide avec quelque chose ?"


translate french gracetip_66522dcf:


    grace "Non ça va... je vais juste aller dans ma chambre me coucher... Demain va être une sacrée journée..."


translate french gracetip_d298f5af:


    d "C'est sûr..."


translate french gracetip_9430e9e5:


    grace "Oooooh...Ahhhh" with vpunch


translate french gracetip_f09681f9:


    grace "Tu es mon héros !"


translate french gracetip_7f366a24:


    d "Heu pas sûr ! Mais comme j'ai promis à ta mère que je prendrais soin de sa fille..."


translate french gracetip_d6f92c0e:


    grace "Bon... Peut être qu'il faudrait que je m'entraîne un peu plus et que je zappe mes séances piscine du soir."


translate french gracetip_6155d7c2:


    grace "Tu peux me lâcher maintenant..."


translate french gracetip_285880a7:


    cr "Ici vous avez des choix qui peuvent être cachés, dépendants des statistiques que vous avez..."


translate french gracetip_4b67e7da:


    cr "Dans ce cas précis, vous allez avoir le choix ou pas, et vous pourrez, ou non, cliquer sur les boutons en fonction de la confiance de Grace envers vous."


translate french gracetip_6b203f38:


    cr "Pour vous aider, votre EDUCATION doit être de 2 ou plus pour qu'elle ait assez confiance en vous."


translate french gracetip_bdaabba9:


    grace "Tu aurais pû me rattraper !"


translate french gracetip_ddec4435:


    d "Désolé tu es tombé trop rapidement !"


translate french gracetip_62ef3f60:


    grace "Tu veux dire que je suis grosse ?"


translate french gracetip_d7d0f724:


    d "Non non !!! Bien sûr que non ! Tu es magnifique !"


translate french sitcouch_28062e78:


    grace "Okay bon... je vais te laisser ici... Ne casse rien s'il te plaît sinon ma mère sera furieuse..."


translate french sitcouch_5e1e37ee:


    d "D'accord... Bonne nuit Grace"


translate french sitcouch_9556c425:


    grace "Bonne nuit"


translate french roomgrace_74f8e696:


    grace "Tu es fort !"


translate french roomgrace_ef94450c:


    d "Je me suis un peu entraîné..."


translate french roomgrace_0d770118:


    grace "Fort et mignon... Julia a bon goût..."


translate french roomgrace_e9b720f7:


    d "Julia ?"


translate french roomgrace_45538cff:


    grace "zzz"


translate french roomgrace_1678ca47:


    dpense "Elle s'est endormie ?"


translate french roomgrace_d0c6195d:


    dpense "Oh mon dieu..."


translate french roomgrace_14601ec4:


    dpense "Faut que je trouve où est sa chambre..."


translate french roomgrace_5015de77:


    dpense "Oui, ça doit être ça..."


translate french roomgrace_0fb213bf:


    dpense "C'est mignon !"


translate french roomgrace_19a6086b:


    dpense "Je vais la poser sur le lit..."


translate french roomgrace_3789c9b9:


    dpense "Voilà, comme ça..."


translate french roomgrace_44d8ac77:


    grace "Merci, mon héros..."


translate french roomgrace_15696b9a:


    dpense "Quoi ???"


translate french roomgrace_79191d21:


    grace "Ca fait longtemps que je n'ai pas eu un homme fort..."


translate french roomgrace_d280e70a:


    dpense "Elle pense que je suis parti ?"


translate french roomgrace_0e0b4bc1:


    dpense "Qu'est ce qu'elle est belle..."


translate french roomgrace_d6eee0b7:


    dpense "Je devrais peut être la déshabiller ?"


translate french roomgrace_748cf150:


    dpense "Non elle va penser que je suis un pervers..."


translate french roomgrace_3e2f8822:


    dpense "Dors bien belle rousse..."


translate french couch_d5603e5f:


    dpense "Bon maintenant c'est l'heure de dormir."


translate french couch_109f25a8:


    dpense "Cette journée a été bien remplie..."


translate french couch_b1b989e3:


    dpense "Demain à 9 heures qu'elle a dit... Oui Mrs. Drew..."


translate french sport_increased_203b7603:


    "Votre BUDDY a augmenté !"

translate french strings:


    old "You think I'm a babysitter ?"
    new "Vous me prenez pour une babysitter ?"


    old "Sure Mrs Drew ! I'll take care of her."
    new "Bien sûr Mrs Drew ! Je vais prendre soin d'elle !"


    old "Catch her"
    new "L'attraper"


    old "Don't"
    new "Ou pas"


    old "Do you want me to help you to your room ?"
    new "Tu veux que je t'emmène à ta chambre ?"


    old "Oh ! Yes ! sure !"
    new "Oh ! Oui ! Bien sûr !"



translate french strings:


    old "EPISODE 1 {p} \n Natural Selection"
    new "EPISODE 1 {p} \n Sélection Naturelle"



translate french strings:


    old "Save your game here, next part will be available in a few days ...."
    new "Sauvegardez votre jeu ici. La prochaine partie sera disponible dans quelques jours..."




translate french roomgrace_7e765a2f:


    grace "Un héros fort et mignon..."




translate french sport_increased_1dd09555:


    "VOTRE SPORT A AUGMENTE"




translate french e1s1_b545e893:


    dpense "Elle est incroyablement belle mais je peux pas supporter cette façon de parler..."



translate french strings:


    old "YOUR SPORT HAS INCREASED"
    new "VOTRE SPORT A AUGMENTE"




translate french e1s1_7149415c:


    grace "Mère, ce gars est trop mignon ! Je l'ai vu parler à Julia tout à l'heure et elle ne semblait pas rester insensible à ses charmes !"


translate french drewsuite_19f1ad02:


    drew "Et Grace, c'est [name], un étudiant français qui va rester avec nous à l'Academy pour ce semestre."


translate french gracetip_2ca8e556:


    grace "Alors... Il va peut être falloir que je m'entraîne un peu plus à la piscine le soir..."


translate french gracetip_b91aafb4:


    cr "Ici vous pouvez avoir des choix qui seront grisés, dépendants d'une certaine statistique..."


translate french gracetip_79574a66:


    cr "Pour vous aider, votre Education doit être de 2 ou plus pour qu'elle ait confiance en vous..."


translate french roomgrace_c95d349c:


    grace "Fort et mignon.... Normal que Julia ait craqué..."


translate french roomgrace_d4648271:


    dpense "C'est cozy !"


translate french roomgrace_20a391a1:


    dpense "Elle croît que je suis parti ?"


translate french roomgrace_3f712c16:


    dpense "Peut être que je devrais la déshabiller ?"


translate french roomgrace_e9a7858f:


    dpense "Non, elle va me prendre pour un pervers..."




translate french e1s1_e121c6a0:


    d "Chauffeur ! Est-on encore loin de l'Université ?"


translate french e1s1_40668af7:


    d "Ce n'est pas l'Université ! C'est un mur !"


translate french e1s1_d6d5b2b2:


    "Je suis Mrs. Drew, l'assistante de Mr. Orushi d'Orushi Corp. Je suis aussi la directrice de l'Université."


translate french drewsuite_6b812dd8:


    drew "Et Grace, c'est [name], un étudiant français qui va rester à l'Université pour ce semestre."


translate french drewangry_3ae2dafa:


    drew "Je dois vous prévenir que ce n'est pas un bon début si vous me parlez comme ça. Je vous rapelle que je suis la directrice de l'Université et vous avez besoin de garder votre bourse en tête..."



translate french strings:


    old "You think I'm a babysitter ? [TEMP1]"
    new "Vous me prenez pour une babysitter ? [TEMP1]"


    old "Sure Mrs Drew ! I'll take care of her. [TEMP2]"
    new "Bien sûr Mrs Drew ! Je vais prendre soin d'elle. [TEMP2]"


    old "Catch her [TEMP1]"
    new "L'attraper [TEMP1]"


    old "Don't [TEMP2]"
    new "Ou pas [TEMP2]"


    old "Do you want me to help you to your room ? [TEMP3]"
    new "Tu veux que je te monte dans ta chambre ? [TEMP3]"


    old "Oh ! Yes ! sure ! [TEMP4]"
    new "Oh ! Oui ! Bien sûr ! [TEMP4]"



translate french strings:


    old "You think I'm a babysitter ? [TEMP1!t]"
    new "Vous me prenez pour une babysitter ? [TEMP1!t]"


    old "Sure Mrs Drew ! I'll take care of her. [TEMP2!t]"
    new "Bien sûr Mrs Drew ! Je vais prendre soin d'elle. [TEMP2!t]"


    old "Catch her [TEMP1!t]"
    new "L'attraper [TEMP1!t]"


    old "Don't [TEMP2!t]"
    new "Ou pas [TEMP2!t]"


    old "Do you want me to help you to your room ? [TEMP3!t]"
    new "Tu veux que je te monte dans ta chambre ? [TEMP3!t]"


    old "Oh ! Yes ! sure ! [TEMP4!t]"
    new "Oh ! Oui ! Bien sûr ! [TEMP4!t]"




translate french e1s1_42198499:


    "Elle m'a demandé de vous laisser là, mon garçon..."


translate french e1s1_d8b3be19:


    dpense "Okay... Où je suis là ? Et c'est qui cette 'Elle' qui a demandé au chauffeur de me lâcher près d'un mur ?"


translate french e1s1_9106fdeb:


    "Bienvenue en Amérique, [name]."


translate french e1s1_295d0fd1:


    drew "Je sais tout ce que j'ai à savoir sur vous, [name]."


translate french e1s1_ab50beb6:


    drew "Vous espionner ? Vous pensez être assez important pour nous au point d'envoyer quelqu'un en France pour vous espionner ?"


translate french e1s1_e1b74faa:


    drew "Je vous en ai déjà trop dit... Demain, vous comprendrez..."


translate french e1s1_bc25ba71:


    drew "Maintenant, si vous voulez bien m'excuser, je vais vous présenter ma fille. Elle va vous présenter le dortoir et votre chambre sur le campus."


translate french e1s1_e350ad45:


    grace "Allez... Tu peux arrêter de gueuler sur moi comme ça ? J'ai un de ces mal de crâne !"


translate french e1s1_3dbeaa27:


    grace "Oh mon dieu... Okay, je vais le faire. Mais tu devrais quand même goûter ce Champagne, c'est divin !"


translate french e1s1_c1eff7a6:


    grace "Désolée, je suis Grace et tu..."


translate french drewsuite_51b54e3f:


    drew "Et Grace, c'est [name], un étudiant français qui va rester à l'Université avec nous pour ce semestre."


translate french drewsuite_0cb358b4:


    grace "Oui... D'accord, Mère..."


translate french drewangry_30cf94b3:


    drew "Je dois vous prévenir que ce n'est certainement pas un bon départ de me parler de la sorte. Pour rappel, je suis la Directrice et vous avez besoin de garder vos bourses si je puis dire..."


translate french drewangry_6ed0d999:


    d "Je serai là..."


translate french drewok_e22ffbfe:


    drew "C'est bien ce que j'espérais... J'ai fondé beaucoup d'espoirs en vous [name]. Ne me décevez pas... Vous en serez récompensé."


translate french drewok_12b3f958:


    d "Je vais essayer, Mrs. Drew"


translate french drewok_6ed0d999:


    d "Je serai là..."


translate french gracetip_8a13d7b7:


    grace "Oui... C'est moi..."


translate french gracetip_2e0cb4e0:


    grace "Nan ça va... Je vais juste aller me coucher... Demain va être difficile..."


translate french gracetip_ab50bccd:


    d "Je suis pas trop sûr de ça mais bon... Comme j'ai dit que j'allais prendre soin de toi..."


translate french gracetip_d692729b:


    grace "Alors... Va peut être falloir que je m'entraîne un peu plus et que je zappe la piscine le soir..."


translate french gracetip_fde4e366:


    d "Désolé ! J'ai pas eu le temps de te rattraper !"


translate french sitcouch_2e864f0f:


    grace "Okay bon... Je te laisse là... Ne casse rien s'il te plaît sinon ma mère va être furieuse..."


translate french roomgrace_bee99c83:


    grace "Tu es fort !"


translate french couch_4003f62c:


    dpense "Demain à 9 heures... Très bien, Mrs. Drew..."

translate french strings:


    old "Oh ! Yes ! Sure ! [TEMP4!t]"
    new "Oh ! Oui oui ! Bien sûr ![TEMP4!t]"




translate french e1s1_432555d0:


    dpense "Cette Madison semble populaire. Je n'ai aucune idée de qui elle est."


translate french e1s1_ac1be3dc:


    dpense "Et pourquoi est elle si hargneuse?"


translate french e1s1_97d011b3:


    dpense "Terriblement belle mais insupportable..."


translate french e1s1_f60858d9:


    dpense "Et à côté de ça je n'ai aucune idée d'où sont mes bagages."


translate french e1s1_473f6b00:


    d "Chauffeur! On est encore loin de l'Academy?"


translate french e1s1_ecd642ad:


    "On y est!" with vpunch


translate french e1s1_9ea7faaf:


    d "Hum... C'est pas l'université ça... C'est un mur!"


translate french e1s1_e475c27b:


    "Elle m'a demandé de vous laisser là l'ami."


translate french e1s1_7481d909:


    d "Elle?"


translate french e1s1_4b13a5b2:


    d "Qui ça elle?"


translate french e1s1_88e451f1:


    dpense "Okay. Je suis où là? et qui est cette fille qui a demandé qu'on me lâche là?"


translate french e1s1_7984c0cd:


    dpense "Je comprends rien."


translate french e1s1_709d6e47:


    d "Qui... qui êtes-vous? Et comment connaissez-vous mon nom?"


translate french e1s1_c1df6248:


    "Je suis Mrs. Drew, l'assistante de Mr. Orushi d'Orushi Corporation. Et accessoirement la directrice de l'université."


translate french e1s1_0435afa2:


    drew "Tu viens de France, un peu au-dessus de la moyenne avec de bonnes performances sportives dûes à la pratique du sport et à la génétique."


translate french e1s1_fbe90eca:


    d "Quoi? Vous m'avez espionné?"


translate french e1s1_2df3db58:


    drew "T'espionner? Tu te crois assez important pour qu'on envoit quelqu'un en France juste pour t'espionner?"


translate french e1s1_3f9e51b2:


    drew "Non. Bien sûr que non."


translate french e1s1_ff2c6a79:


    d "Le 90? 90 de quoi?"


translate french e1s1_9dfdb7ea:


    drew "J'en ai déjà trop dit. Demain, tu comprendras."


translate french e1s1_f32fa33e:


    drew "SAOULE?" with hpunch


translate french e1s1_7cad2307:


    drew "Grace! Qu'est ce que tu fais? Pourquoi bois-tu toute seule à cette heure? Tu devrais te préparer pour demain!"


translate french e1s1_edf991e2:


    grace "Oh c'est bon... T'es obligée de hurler comme ça? J'ai mal à la tête."


translate french e1s1_3c64e8bc:


    drew "Grace! Reprends-toi! On a un invité, alors change de ton et présente-toi proprement!"


translate french e1s1_6d964eef:


    grace "Oh mon dieu... Okay. Je vais le faire mais tu devrais vraiment tester ce champagne, c'est trop bon!"


translate french e1s1_2b0b620b:


    grace "Je suis désolée, je suis Grace et je..."


translate french e1s1_c989b760:


    grace "Le tripoteur!"


translate french e1s1_8c026b32:


    grace "Mère, celui-là est un pervert!"


translate french e1s1_a7185c32:


    grace "Le plouc!"


translate french e1s1_661d57e7:


    grace "Mère, ce garçon vraiment charmant! Il a parlé avec Julia dans l'avion et elle ne semblait pas insensible à ses charmes!"


translate french drewsuite_f4948315:


    drew "Allons Grace, ce n'est pas comme ça qu'on accueille un invité."


translate french drewsuite_61724c00:


    drew "Je te prie d'excuser ma fille pour son comportement, il doit y avoir une méprise."


translate french drewsuite_9435ba4d:


    drew "[name], voici donc Grace, ma fille."


translate french drewsuite_d974a255:


    drew "Et Grace, voici [name], un étudiant français qui restera avec nous à l'université ce semestre."


translate french drewsuite_b775e404:


    grace "Ouais ouais d'accord j'ai compris."


translate french drewsuite_e08c517d:


    grace "Désolée [name], j'ai bû un peu trop et j'ai tendance à dire tout haut ce que je pense quand je suis un peu emmêchée."


translate french drewsuite_862b2f2f:


    drew "Bon, maintenant que tout est clair."


translate french drewsuite_845674e8:


    drew "Je ne pense pas que tu sois en état de montrer à [name] le campus et sa chambre."


translate french drewsuite_eb162a64:


    grace "Bien sûr que si... Oof!" with vpunch


translate french drewsuite_96f9ff5a:


    drew "Jeune femme, tu as besoin d'aller dormir, et j'ai d'autres choses à faire."


translate french drewsuite_58bc0ab8:


    drew "[name], peux-tu rester ici pour la nuit afin de veiller à ce qu'elle dorme"


translate french drewsuite_22d14705:


    drew "Tu peux dormir sur le canapé pour ce soir et j'enverrais quelqu'un te chercher demain matin."


translate french drewangry_f8542dc5:


    drew "Je pense que ce n'est pas une bonne idée de me parler comme ça dès le début. Je te rapelle que je suis la directrice et que tu tiens à ce que ton dossier soit parfait pour rester ici."


translate french drewangry_ecdd06d1:


    drew "C'est bien mieux. Je dois y aller. On se voit demain à neuf heures précises. Aucun retard ne sera toléré."


translate french drewangry_c288903d:


    d "Je serais là."


translate french drewok_05586da9:


    drew "C'est ce que j'espérais entendre. J'ai beaucoup d'espoir pour toi, [name]. Ne me déçois pas et je veillerais à ce que tu sois récompensé."


translate french drewok_60e769c1:


    d "Je vais essayer, Mrs. Drew."


translate french drewok_e2d829c9:


    drew "Je dois y aller. On se voit demain à neuf heures précises. Aucun retard ne sera toléré."


translate french drewok_c288903d:


    d "Je serais là."


translate french gracetip_33a7f69e:


    cr "Donnez moi un moment. Je veux être sûr que vous compreniez bien les règles de ce jeu."


translate french gracetip_05c5b6e7:


    cr "... Peut être que si vous aviez été plus avenant envers Julia dans l'avion aurait changé le cours des choses?"


translate french gracetip_39949567:


    cr "Je vous conseille de faire plusieurs sauvegardes pour tester les différents choix, car tous affecteront les évênements qui vont suivre."


translate french gracetip_b0177253:


    cr "Allez on y retourne. Bon jeu!"


translate french gracetip_faf676c5:


    d "Alors, euh, Grace c'est ça?"


translate french gracetip_a1ed8ae4:


    grace "Oui, c'est bien ça."


translate french gracetip_8a81dd88:


    d "Tu as besoin d'aide pour quelque chose?"


translate french gracetip_e67f97c2:


    grace "Non c'est bon. Je vais juste aller dans ma chambre et dormir. Demain va être dûr."


translate french gracetip_4d710522:


    d "C'est sûr."


translate french gracetip_eb17abbf:


    grace "Oooooooh....Ahhhh" with vpunch


translate french gracetip_56de7896:


    grace "Merci de m'avoir rattrapée, monsieur le héros."


translate french gracetip_2c5bbbe4:


    d "Pas sûr pour le héros, mais j'ai dit à te mère que je veillerais sur toi donc..."


translate french gracetip_ccb7a8bc:


    grace "Faudrait peut être que je reprenne l'entraînement et que j'arrête de zapper la piscine le soir."


translate french gracetip_6522caea:


    cr "Ici vous avez des choix qui peuvent être grisés, car dépendants de certaines statistiques."


translate french gracetip_de6b2efc:


    cr "Par exemple, dans ce cas une option est dépendante de la confiance que Grace vous accorde."


translate french gracetip_b687572e:


    grace "Pourquoi tu ne m'as pas rattrapée?"


translate french gracetip_66025636:


    d "T'es tombée trop vite!"


translate french gracetip_16464349:


    grace "Tu veux dire que je suis grosse?"


translate french gracetip_3cd51a3d:


    d "Quoi? Non! T'es parfaite mais..."


translate french sitcouch_63282405:


    grace "Bon allez, je te laisse là. Ne casse rien sinon ma mère sera furieuse."


translate french sitcouch_507244c0:


    d "Evidemment. Bonne nuit Grace"


translate french sitcouch_8065de9f:


    grace "Bonne nuit."


translate french roomgrace_a49d7fcc:


    grace "Tu es fort!"


translate french roomgrace_c4cdd678:


    d "Je vais à la salle de temps en temps."


translate french roomgrace_54eeaa13:


    grace "Fort et mignon. Julia a bon goût..."


translate french roomgrace_5a7b8daf:


    d "Julia?"


translate french roomgrace_7248392c:


    dpense "Faut que je trouve sa chambre maintenant."


translate french roomgrace_fd6e80d1:


    dpense "Ca doit être ça."


translate french roomgrace_5ffba06b:


    dpense "C'est mignon!"


translate french roomgrace_a203b104:


    dpense "Je vais juste la poser sur son lit."


translate french roomgrace_fdaa5493:


    dpense "Et voilà."


translate french roomgrace_6e4512a7:


    grace "Merci mon héros."


translate french roomgrace_2c73141e:


    dpense "De quoi?"


translate french roomgrace_489910c7:


    dpense "Elle pense que je suis parti?"


translate french roomgrace_f16dac9a:


    dpense "Qu'est ce qu'elle est belle."


translate french roomgrace_4bebf18a:


    dpense "Je devrais peut être l'aider à se déshabiller?"


translate french roomgrace_308174f2:


    dpense "Non, elle va penser que je suis un pervert."


translate french couch_af05b7c2:


    dpense "Okay. Il est temps d'aller dormir."


translate french couch_760535b6:


    dpense "Cette journée était sacrément longue."


translate french couch_fd086364:


    dpense "Demain à neuf heures qu'elle a dit. Très bien Mrs Drew, Je serais là."

translate french strings:


    old "You think I'm a babysitter? [TEMP1!t]"
    new "Vous me prenez pour une baby-sitter? [TEMP1!t] "


    old "Sure Mrs. Drew. I'll take care of her. [TEMP2!t]"
    new "Bien sûre Mrs Drew. Je vais prendre soin d'elle. [TEMP2!t]"


    old "Oh! Yes, I'll do that. [TEMP4!t]"
    new "Oh! Oui, je vais faire ça. [TEMP4!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
