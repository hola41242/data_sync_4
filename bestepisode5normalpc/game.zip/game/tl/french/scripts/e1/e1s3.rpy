


translate french e1s3_c5ea222a:


    ruby "Julia ! T'as fait quoi à tes cheveux ?"


translate french e1s3_7f35a1c9:


    julia "Oh, j'en avais marre que les gens me demandent si je voulais devenir une rockstar !"


translate french e1s3_0cfbc407:


    ruby "Et ben ça te va bien ! Et la couleur ... Wahoo !"


translate french e1s3_fbaf289d:


    julia "Merci ! Et toi ? T'as viré ta tresse ?"


translate french e1s3_7deccdea:


    ruby "Ouais ! C'est pratique pour le sport mais j'en avais marre d'elle ! Faut la refaire tout le temps... Et j'avais pas beaucoup de temps ce matin vu qu'il fallait emmener Cortex voir sa chambre!"


translate french e1s3_cb399fc3:


    julia "Cortex ?"


translate french e1s3_064cabec:


    d "Elle a décidé qu'on était Minus et Cortex..."


translate french e1s3_37560315:


    julia "Oh ! Le retour du pervers ! J'espère que tu t'es bien comporté avec Ruby ! Sinon tu vas voir ce que ça fait de se faire dégommer par une fille ! T'as de la chance que je suis de bonne humeur ! Mais ne me teste pas aujourd'hui..."


translate french e1s3_de4b8843:


    ruby "Il a été parfait Julia ! Arrête ! Je l'ai emmené à sa chambre pour qu'il puisse se changer et savoir où il allait dormir. Le pauvre, il connaît personne et ses bagages ont été pris, et il savait même pas où il devait aller..."


translate french e1s3_2113284b:


    julia "Oh ! Okay... Bon écoute, je vais faire un effort..."


translate french e1s3_064cabec_1:


    d "Elle a décidé qu'on était Minus et Cortex..."


translate french e1s3_84a81e6f:


    julia "Oh ! Le gars de l'avion ! J'espère que Ruby a été sympa avec toi ! Ruby ? Tu l'as pas embêté avec toutes tes histoires non ? Le pauvre vient juste d'arriver et il a dû être bombardé d'histoires de films ou d'animaux..."


translate french e1s3_3ce36968:


    d "Hahaha ! Non, elle a été fabuleuse ! Elle m'a montré le dortoir et ma chambre que..."


translate french e1s3_36bbdfcf:


    ruby "Que j'ai préparé moi-même !"


translate french e1s3_33074fdd:


    d "Oui, la chambre qu'elle m'a préparée..."


translate french e1s3_f89ecee5:


    julia "Si ça te dit, je pourrais te faire le tour du campus que tu vois qu'est ce qu'on peut faire après les cours."


translate french e1s3_aa3d626c:


    d "Ca serait parfait !"


translate french e1s3_ccf97ed5:


    ruby "Merci, Julia ! Tu peux rester avec lui un petit peu et lui montrer le bâtiment ? Il faut que j'aille aux toilettes avant que ça commence !"


translate french e1s3_f5328420:


    julia "Bien sûr ! Vas-y !"


translate french e1s3_9c687826:


    ruby "Merci !!! A tout à l'heure !"


translate french e1s3_57666615:


    julia "Bon, puisqu'on est juste touss les deux, laisse moi te donner quelques informations sur les gens que tu vas rencontrer dans cette Academy. Tu verras, il y à plus ou moins des stars par ci par là et d'autres qui traînent à côté...."


translate french e1s3_2c3a63c7:


    d "Comment ça ?"


translate french e1s3_343aa2f3:


    julia "Attends, laisse moi te montrer !"


translate french e1s3_e957c35f:


    julia "Alors, lui c'est Steven, un des gars de l'Academy, toujours en train d'essayer de draguer la moindre fille passant à côté de lui... Il paraît que chaque soir il va conclure..."


translate french e1s3_2c3a4596:


    julia "Bon... On l'a jamais vu avec personne et toutes les filles de l'équipe l'ont déjà blacklisté..."


translate french e1s3_d7cc31de:


    d "Ah oui c'est vrai, vous avez une équipe... une équipe de quoi au fait ?"


translate french e1s3_a39a40fe:


    julia "De foot ! On fait partie de la plus importante équipe académique du pays ! Et certaines d'entre nous sont prêtes à rejoindre l'équipe nationale ! On a toutes un rêve... Arriver en équipe nationale et jouer avec des filles comme Alex Morgan ou Megan Rapinoe !"


translate french e1s3_abc66895:


    d "Oh je les ai vu jouer en France ! On a une bonne équipe nous aussi !"


translate french e1s3_7955395a:


    julia "Oui, c'est vrai ! On a regardé tous vos matchs contre notre équipe ! Bon, vous avez toujours pas gagné la coupe mais parfois c'est pas passé loin ! Vous avez de bonnes attaquantes aussi... Enfin vous aviez..."


translate french e1s3_0544436e:


    d "Ouais, je ne suis plus trop l'actualité du foot féminin pour être honnête..."


translate french e1s3_1b3fe9da:


    julia "Pas grave ! Donc dans l'équipe il y a plusieurs filles qui ont notre âge ou un petit peu plus âgées... Dans notre promo, tu as Ruby qui joue sur les côtés, C'est une bonne technicienne très rapide !"


translate french e1s3_912b21f0:


    d "Ruby ? Rapide ?"


translate french e1s3_5f857b41:


    julia "Oui oui ! Quand elle ne parle pas je peux t'assurer qu'elle peut l'être !"


translate french e1s3_8bb5d2c5:


    d "Hahaha ! Et toi tu es rapide ?"


translate french e1s3_f2a292ff:


    julia "Je joue milieu, je suis plus technique que vitesse pour créer des opportunités, avec Grace qui est juste derrière moi..."


translate french e1s3_4bf520b6:


    d "Grace... La rousse ?"


translate french e1s3_e3dc5d44:


    julia "Oui oui ! C'est notre capitaine d'équipe ! Elle joue milieu défensif et organise notre jeu. Elle joue juste derrière moi et le but c'est qu'on envoit les meilleurs ballons à nos attaquantes."


translate french e1s3_78d34c84:


    d "Vous avez de bonnes attaquantes ?"


translate french e1s3_0ac8623f:


    julia "On a la meilleure... Malheureusement, elle est extrêmement arrogante. Mais oui, elle est forte."


translate french e1s3_cbea19fa:


    julia "Ah ben tiens, quand on parle du loup..."


translate french e1s3_436a0f5b:


    d "Hey ! Je la connais elle ! On a partagé un taxi la nuit dernière ! Ouias c'est le genre moi-je moi-je... Quand elle est partie elle a dit un truc du genre ... Tout le monde connaît..."


translate french e1s3_b9d4fd80:


    julia "Madison Forrester... Ouais je sais, c'est sa phrase favorite. Bref, c'est notre joueuse star. Je dois admettre qu'on est pas en trèss bons termes elle et moi. Mais elle a des responsabilités et des problèmes qui la rendent très défensive parfois..."


translate french e1s3_7aebed3a:


    julia "Donc Madison et Ruby sont souvent ensemble. Ruby a perdu ses parents très jeune et les parents de Madison l'ont recueillie et pratiquement adoptée. Du coup Ruby a une confiance aveugle en Madison... Et Madison est trèss protectrice avec Ruby..."


translate french e1s3_a591edaa:


    julia "Sinon, le gars que tu vois là c'est Emerick..."


translate french e1s3_f43904ba:


    d "Okay... Pourquoi y'a autant de monde autour de lui ?"


translate french e1s3_aaaef7a2:


    julia "Disons que c'est le meilleur parti de la fac... Il a hérité d'une très grande fortune de son grandpère... et il aime le montrer... Les filles le détestent... Moi je m'en fous... Mais fais attention autour de lui parce qu'il connaît tout le monde et il paraît qu'il est très dûr en affaires..."


translate french e1s3_2c3a63c7_1:


    d "Comment ça ?"


translate french e1s3_06e11372:


    julia "En fait c'est un champion d'athlétisme et il connaît les grands pontes du business de la ville... Avec ça il a les fonds et les contacts... C'est pas quelqu'un avec qui tu veux avoir des problèmes quoi..."


translate french e1s3_1645ee5f:


    d "Okay... On va essayer de l'éviter..."


translate french e1s3_d23937d3:


    julia "Si tu peux ! Bon par contre voilà les problèmes..."


translate french e1s3_2bfbaaa2:


    julia "Ca c'est notre gardienne... Elizabeth. Aussi forte que mystérieuse. Elle fait partie de ce trio doré avec sa soeur et Emerick... En gros c'est les 3 plus riches du coin... Madison ne peut pas se les voir..."


translate french e1s3_9ba8ecac:


    julia "Sa jumelle est Sofia, notre défenseuse centrale ! Elle est bien plus avenante que sa soeur, mais ne te laisse pas avoir par ses charmes, elle est aussi séduisante que dangereusse ! On les appelle Rouge et Bleue entre nous vu comment elles se maquillent pour se distinguer..."


translate french e1s3_f1072b9a:


    d "Comme des Pokemons ?"


translate french e1s3_d73aa6a3:


    julia "Haha ! Oui !"


translate french e1s3_061975f3:


    julia "Bref, je pense que c'est un bon résumé du monde qui nous entoure ! J'espère que tu y trouveras ta place..."


translate french e1s3_1d017003:


    drew "A tous les étudiants, veuillez vous diriger dans l'amphithéatre !"


translate french e1s3_f58e3615:


    julia "On se voit plus tard ?"


translate french e1s3_aa7a6ace:


    d "Bien sûr !"


translate french e1s3_d9521dd1:


    sofia "Eh toi ! La prochaine fois que tu veux choper un truc ccomme le cul de Julia, sois sûr que tu pourras l'utiliser !"


translate french e1s3_c247e1f9:


    beth "C'est toi le Français qui vient d'arriver ?"


translate french e1s3_e820fa7e:


    d "Oui... Pourquoi ?"


translate french e1s3_bc8a1a1a:


    beth "Il paraît que les Français sont doués dans plusieurs domaines... J'ai hâte de voir ça !"


translate french rubyamphi_005f596e:


    ruby "Cortex ! Viens là !"


translate french rubyamphi_8a867c6a:


    d "On est beaucoup !"


translate french rubyamphi_a88a6d24:


    ruby "Oui ! Je ne sais pas ce qu'il se passe... Mais c'est la première fois qu'on nous demande d'être tous là en même temps !"


translate french rubyamphi_7ef11e91:


    d "Je suppose qu'on va le savoir très vite..."


translate french juliaamphi_e842a127:


    julia "Tu peux t'asseoir à côté de moi si tu veux !"


translate french juliaamphi_d96a003a:


    d "Okay ! Oh la vache... Il y en a du monde ! "


translate french juliaamphi_85bbaf5a:


    julia "Oui ! Je sais pas pourquoi ils nous ont tous rassemblés comme ça, c'est la première fois qu'ils nous demandent de venir tous dans l'amphithéatre comme ça !"


translate french juliaamphi_7f818c7c:


    d "Je pense qu'ils vont nous dire ce qu'il se passe..."


translate french graceamphi_222df565:


    d "Je peux m'asseoir ?"


translate french graceamphi_057221aa:


    grace "Oui, bien sûr !"


translate french graceamphi_9bf01bdc:


    d "Tu sais pourquoi ils nous ont tous emmenés ici ?"


translate french graceamphi_b12bd012:


    grace "Non, mais on va bientôt le savoir !"


translate french madisonamphi_c9538fd8:


    mad "Oh... viens pas m'embêter maintenant, c'est pas le moment..."


translate french madisonamphi_9ea9e686:


    d "Je suis pas là pour ça... Et bonjour à toi aussi..."


translate french madisonamphi_ab4f89f0:


    mad "Je comprends pas pourquoi ils nous ont demandé de venir tous ici en même temps... Je suis censée m'entraîner au gymnase..."


translate french madisonamphi_37f2ca3b:


    d "Je pense qu'on va le savoir rapidement, à mon avis..."


translate french amphi_f0f28a42:


    rufus "MIAOU !"


translate french amphi_b33469a9:


    orushi "Hum hum... Mr. Rufus s'il vous plaît !"


translate french amphi_06e35140:


    ruby "Oh, un chat qui parle !"


translate french amphi_a70fad5d:


    orushi "Bonjour chers étudiants ! Je suis Orushi, d'Orushi Corp. Vous devez vouss demander pourquoi on vouss a demandé de venir dans l'amphithéâtre dès le début de votre premier jour. Je comprend votre surprise."


translate french amphi_f3aa06c0:


    orushi "Vous faites maintenant tous partie d'un programme spécial pour lequel vouss avez été sélectionné. Ce programme d'évaluation, le système B.E.S.T, va déterminer qui, entre les 100 participants que vous êtes, va réussir à passer les tests et s'élever au dessus des autres."


translate french amphi_eb1c6786:


    orushi "Vous faites maintenant tous partie d'un programme spécial pour lequel vouss avez été sélectionné. Ce programme d'évaluation, le système B.E.S.T, va déterminer qui, entre les 100 participants que vous êtes, va réussir à passer les tests et s'élever au dessus des autres."


translate french amphi_84d39685:


    orushi "Vous allez tous être en compétition les unss contre les autres. Des tests seront passés durant le premier semestre pour déterminer qui est le meilleur d'entre vous. Les tests au ront lieu de jour comme de nuit, individuellement ou en équipe, et une annonce sera faîte quand il faut vouss rassembler..."


translate french amphi_282dc752:


    orushi "A la fin de cette compétition, la personne sélectionnée recevra le titre de B.E.S.T étudiant, un chèque de 500 000 $, et une place en tant qu'assistant de direction chez Orushi Corp."


translate french amphi_1ac4e80d:


    orushi "Je sais que c'est une place très prisée et que plusieurs d'entre vous seraien heureux de n'être ne serait-ce que stagiare dans l'entreprise. Alors ne ratez pas cette opportunité et, par dessus tout, montrez votre talent à tous pendant les tests !"


translate french amphi_b78ec9bf:


    orushi "Vous êtes 100 et, après chaque test, une partie sera éliminée. Le premier test gardera 50 étudiants parmi vous. Ce sera un test individuel où tous voss choix et actions seront notées pour améliorer votre rang dans la compétition. "


translate french amphi_e4ce80dc:


    orushi "Un rang simulé vous a été attribué, et vous allez devoir l'améliorer pour continuer l'aventure. Bon, je ne vais pas vouss retenir plus longtemps... On se voit au stade où d'autres informations vous seront données..."


translate french amphi_05980861:


    orushi "Oh ! J'avais presque oublié ! C'est aussi un test de vitesse ! Et ça commence..."


translate french amphi_6e8c0661:


    orushi "Maintenant !"

translate french strings:


    old "Seat with Ruby ?"
    new "S'asseoir avec Ruby ?"


    old "Seat with Julia ?"
    new "S'asseoir avec Julia ?"


    old "Seat with Grace ?"
    new "S'asseoir avec Grace ?"


    old "Seat with Madison ?"
    new "S'asseoir avec Madison ?"




translate french e1s3_1252b777:


    julia "Et... Minus et Cortex ???"


translate french e1s3_46523c1d:


    ruby "Ah oui... tu te rapelles de Pinky and the Braid quand on était petites ?"


translate french e1s3_757fcd56:


    julia "Euh... Oh ! Les Animaniacs ?"


translate french e1s3_681fefc6:


    ruby "Ouiiiiiiiiiii ! Ben, en français ils s'appellent Minus et Cortex !"


translate french e1s3_e476f539:


    julia "Oh... Mais comment tu sais ça toi ?"


translate french e1s3_4f767c2a:


    ruby "Ben en fait, l'année dernière, on a étudié le parcours de Steven Spielberg et il faisait partie de l'équipe qui a créé les Animaniacs et..."


translate french e1s3_b049afe0:


    julia "Okay okay okay ! Je sais pas comment tu peux garder autant d'informations dans ta petite tête..."


translate french e1s3_1252b777_1:


    julia "Et... Minus et Cortex ???"


translate french e1s3_46523c1d_1:


    ruby "Ah oui... tu te rapelles de Pinky and the Braid quand on était petites ?"


translate french e1s3_757fcd56_1:


    julia "Euh... Oh ! Les Animaniacs ?"


translate french e1s3_681fefc6_1:


    ruby "Ouiiiiiiiiiii ! Ben, en français ils s'appellent Minus et Cortex !"


translate french e1s3_e476f539_1:


    julia "Oh... Mais comment tu sais ça toi ?"


translate french e1s3_4f767c2a_1:


    ruby "Ben en fait, l'année dernière, on a étudié le parcours de Steven Spielberg et il faisait partie de l'équipe qui a créé les Animaniacs et..."


translate french e1s3_b049afe0_1:


    julia "Okay okay okay ! Je sais pas comment tu peux garder autant d'informations dans ta petite tête..."


translate french e1s3_46cf0462:


    ruby "Tu peux rester avec lui un peu et lui montrer le bâtiment ? Il faut que j'aille aux toilettes avant que ça commence !"


translate french e1s3_b1b8ddbf:


    julia "Bon, puisqu'on est tous les deux, laisse moi te faire un petit résumé sur les gens que tu vas rencontrer dans cette Academy."


translate french e1s3_6862ab50:


    julia "Tu vas voir, d'un côté y'a les stars et de l'autre ben ceux qui gravitent autour..."


translate french e1s3_1b31ae3c:


    julia "Il joue dans l'équipe masculine de foot. Ils cherchent du monde si ça te dit..."


translate french e1s3_c873f017:


    julia "Je l'ai jamais vu avec personne, et toutes les filles de l'équipe l'ont déjà blacklisté..."


translate french e1s3_ba25435e:


    d "Ah oui c'est vrai ! Tu as une équipe ! Une équipe de quoi ?"


translate french e1s3_dd0160f2:


    julia "On fait partie de la plus grande équipe académique du pays ! Et plusieurs d'entre nous sont pressenties pour rejoindre l'équipe nationale ! On a toutes le même rêve..."


translate french e1s3_2bf8680d:


    julia "Rejoindre l'équipe nationale et jouer avec des filles comme Alex Morgan ou Megan Rapinoe !"


translate french e1s3_dc1001c7:


    d "Je les ai vues jouer en France ! On a une bonne équipe nous aussi !"


translate french e1s3_3a739f09:


    julia "Oui, c'est vrai. On a regardé tous vos matchs contre notre équipe. Bon, vous avez toujours pas gagné la coupe mais parfois c'est pas passé loin ! Vous avez de bonnes attaquantes aussi, enfin vous aviez..."


translate french e1s3_7fc1ec03:


    julia "Enfin bref ! Donc dans l'équipe y'a plusieurs filles de notre âge et certaines un peu plus âgées..."


translate french e1s3_a2f9cbb1:


    julia "Dans notre promo tu as Ruby qui joue sur les côtés, c'est une bonne technicienne et elle est très rapide !"


translate french e1s3_c6be00ee:


    d "Ruby ? Rapide ?"


translate french e1s3_5d0c78ae:


    d "Hahaha ! Et toi tu es rapide ?"


translate french e1s3_55b5e56c:


    d "Grace... La rousse ?"


translate french e1s3_c16050f0:


    julia "Oui, oui ! C'est notre capitaine ! Elle joue milieu défensif et organise le jeu."


translate french e1s3_3f570464:


    julia "Elle est juste derrière moi et le but c'est d'envoyer les meilleurs ballons à nos attaquantes."


translate french e1s3_5c7eda79:


    d "Hey ! Je la connais elle ! Je l'ai rencontré dans le taxi hier soir ! Miss moi-je moi-je !"


translate french e1s3_d57cf1ce:


    d "Quand elle est partie, elle a dit un truc genre, Tout le monde connaît..."


translate french e1s3_1056edaa:


    julia "Tout le monde connaît Madison Forrester... Ouais, je sais, elle le dit tout le temps. Bref, c'est notre joueuse vedette."


translate french e1s3_ccdb04ff:


    julia "Bon je dois t'avouer qu'on s'entend pas très bien elle et moi. Mais elle a plein de responsabilités et de problèmes qui la rendent agressive..."


translate french e1s3_f572ad70:


    julia "Madison et Ruby sont souvent ensemble. Ruby a perdu ses parents très jeune et les parents de Madison l'ont recueillie et pratiquement adoptée."


translate french e1s3_af8699d8:


    julia "Du coup Ruby a une confiance aveugle en Madison... Et Madison est très protectrice en ce qui concerne Ruby... "


translate french e1s3_95cbd31a:


    julia "Le gars que tu vois là bas c'est Emerick..."


translate french e1s3_3de77385:


    julia "Disons que c'est le meilleur parti du coin... Il a hérité d'une très grande fortune à la mort de son grand père et il hésite pas à le montrer..."


translate french e1s3_402ba63a:


    julia "Les filles le détestent... Moi je m'en fous... Mais fais attention si tu es pas loin de lui, il peut être très difficile en affaires..."


translate french e1s3_435be169:


    julia "Et il a pas peur d'utiliser son argent et ses contacts pour avoir ce qu'il veut..."


translate french e1s3_57e71ef2:


    julia "C'était un champion d'athlétisme et il connaît beaucoup de choses sur le business de la ville..."


translate french e1s3_c242d05c:


    julia "Et en plus de tout ça, il a l'argent... Et les contacts... C'est pas quelqu'un avec qui tu veux avoir des problèmes..."


translate french e1s3_ae8c5b38:


    julia "Madison ne peut absolument pas le supporter vu qu'il semble être tout le temps une marche plus haute qu'elle."


translate french e1s3_4593d887:


    julia "C'est notre gardienne, Elizabeth, aussi forte que mystérieuse."


translate french e1s3_6012255c:


    julia "Elle fait partie du trio doré avec sa soeur et Emerick..."


translate french e1s3_5d771e21:


    julia "En gros, c'est les plus riches de l'Academy... et Madison les déteste..."


translate french e1s3_a385248f:


    julia "Sa jumelle est Sofia, notre défenseuse centrale."


translate french e1s3_7038dddb:


    julia "Elle est beaucoup plus avenante que sa soeur, mais ne te fais pas avoir avec ses charmes, elle est aussi séduisante que dangereuse !"


translate french e1s3_a361dbe9:


    julia "On les appelle Rouge et Bleue entre nous vu comment elles se maquillent pour se distinguer..."


translate french e1s3_82263fdf:


    d "Rouge et Bleue ? Comme des Pokémons ?"


translate french e1s3_48cb0ac4:


    d "Je vais le faire..."


translate french e1s3_b0281f40:


    drew "A tous les étudiants, veuillez vous rendre dans l'amphithéâtre !"


translate french e1s3_1ddcc86e:


    julia "Wooo, le Dragon est arrivé ! On y va !"


translate french e1s3_09b45265:


    sofia "Eh toi !"


translate french e1s3_314a06a3:


    sofia "La prochaine fois que tu veux choper un truc comme le cul de Julia, sois sûr que tu pourras l'utiliser !"


translate french e1s3_04c8ec76:


    sofia "Qui sait ? Tu pourrais avoir une récompense !"


translate french e1s3_31ed20f2:


    d "Oulà ! Retourne jouer avec l'eau Carapuce ! Tu pourrais pas tenir en apnée avec moi..."


translate french e1s3_0bd9218a:


    sofia "Carapuce ???"


translate french e1s3_08dab0a8:


    d "Ouais... au pire je peux te foutre une carabifle... ça te fera évoluer !"


translate french e1s3_35b9c1e0:


    sofia "C'est une blague ?"


translate french e1s3_11120b11:


    d "A plus tard la bleue, j'en ai d'autres à attraper !"


translate french e1s3_af8b11bb:


    d "Oh... Euh... Oui... Pourquoi ?"


translate french e1s3_885c5460:


    beth "J'ai entendu dire que les Français étaient doués dans de nombreux domaines..."


translate french e1s3_e33f6790:


    beth "J'ai hâte de voir ça !"


translate french e1s3_e921fbd3:


    d "Je vais faire de mon mieux..."


translate french rubyamphi_3f651d03:


    ruby "[name] ! Viens par là !"


translate french rubyamphi_e0dee2f2:


    d "T'as fini avec le truc de Minus et Cortex ?"


translate french rubyamphi_a14d33f1:


    ruby "Ouais ! Les autres comprennent pas trop... et je me rapelle de ton prénom maintenant !"


translate french rubyamphi_5ed010e1:


    ruby "Bon ! Je suis trop excitée ! Je sais pas ce qu'il se passe, mais c'est la première fois qu'ils nous demandent de venir tous là en même temps !"


translate french juliaamphi_f36a5ff4:


    d "Okay !"


translate french juliaamphi_87c18118:


    d "Oh la vache ! Y'en a du monde !"


translate french graceamphi_45725a3f:


    grace "Oui, bien sûr !"


translate french graceamphi_a0a36297:


    grace "Encore une fois, désolée pour mon attitude d'hier soir... Je n'aurais pas dû boire..."


translate french graceamphi_ace85e09:


    d "T'inquiète pas c'est oublié !"


translate french madisonamphi_2d925ea2:


    mad "Je comprends pas pourquoi ils ont demandés à ce qu'on soit là tous en même temps..."


translate french madisonamphi_4874636b:


    mad "Je suis censée m'entraîner au gymnase..."


translate french amphi_93de61e7:


    drew "Chers étudiants..."


translate french amphi_42e38028:


    drew "Je suis fière de vous présenter Mr. Orushi, Directeur d'Orushi Corp. et Directeur Principal du projet B.E.S.T !"


translate french amphi_b241a330:


    ruby "Oh ! Un chat qui parle ? Vous croyez que c'est Tom ?"


translate french amphi_b007ce34:


    "Ruby !!!" with vpunch


translate french amphi_edd537f7:


    ruby "Okay, okay..."


translate french amphi_a79dd47c:


    rufus "FSHHHHHHHHHHHHH"


translate french amphi_bd8ba672:


    orushi "Bonjour, chers étudiants ! Je suis Orushi, d'Orushi Corp."


translate french amphi_99c49339:


    orushi "Vous devez vous demander pourquoi on vous a tous rassemblés dans l'amphithéâtre dès le début de votre premier jour."


translate french amphi_7a42adda:


    orushi "Je comprends votre surprise."


translate french amphi_8fadeb0a:


    orushi "Vous faites tous maintenant partie d'un programme spécial pour lequel vous avez été sélectionnés."


translate french amphi_8010fc1f:


    "Quoi ?" with vpunch


translate french amphi_fd03bb4a:


    orushi "Ce programme d'évaluation, le programme B.E.S.T, va déterminer qui, parmi les 100 participants que vous êtes, réussira les tests et réussira à vaincre tous les autres "


translate french amphi_152c62ad:


    orushi "Vous serez tous les uns contre les autres durant cette compétition. Des tests seront passés pendant tout le premier semestre afin de déterminer qui est le meilleur."


translate french amphi_3e180d9d:


    orushi "Ces tests pourront avoir lieu de jour comme de nuit, en solo ou en équipe, et une annonce sera faite à chaque fois qu'il faudra pour vous prévenir de la tenue de ces tests."


translate french amphi_2b553e94:


    orushi "Je sais que c'est une place que plusieurs d'entre vous convoitent alors même que certains aimeraient ne serait-ce qu'être stagiaires au sein de l'entreprise."


translate french amphi_843ce427:


    orushi "Alors ne ratez pas cette opportunité et, par dessus tout, montrez votre talent durant ces tests !"


translate french amphi_7a414ab7:


    orushi "Vous êtes 100, et après chaque test, une partie d'entre vous sera éliminée."


translate french amphi_18d675f3:


    orushi "Le premier test gardera la moitié d'entre vous."


translate french amphi_6ff63c68:


    orushi "Ce test se fera par équipe de 2. L'ordinateur va déterminer votre co-équipier ou co-équipière pour ce test."


translate french amphi_f9c0c8f0:


    orushi "Vous aurez à finir le test parmi les 25 premières équipes au minimum pour être qualifié pour la suite du programme... ou alors vous serez éliminé."


translate french amphi_5e883d36:


    orushi "Maintenant Mrs. Drew, veuillez annoncer les équipes !"


translate french amphi_7b0099ba:


    drew "[name] avec Ruby !"


translate french amphi_17791e2a:


    ruby "Super ! On est ensemble pour celui-là !"


translate french amphi_0b246b84:


    d "Ouais ! J'espère qu'on va s'en sortir !"


translate french amphi_739bdf64:


    ruby "T'inquiète pas ! Je cours vite ! Toi fais pareil et essaye de me suivre !"


translate french amphi_882aa9f2:


    d "On verra..."


translate french amphi_7ad0cb20:


    drew "[name] avec Julia !"


translate french amphi_4378768a:


    julia "Oh ! On est ensemble !"


translate french amphi_f05c4e0f:


    d "Ouais ! J'espère que je ne vais pas te décevoir !"


translate french amphi_4bccb5b2:


    julia "Non ! Garde un bon mental ! T'es un gagnant !"


translate french amphi_f9311cf0:


    d "Okay ! Allons gagner ce test ensemble !"


translate french amphi_238ae119:


    julia "C'est ça que je veux entendre !"


translate french amphi_b19db6ac:


    drew "[name] avec Grace !"


translate french amphi_ff39ce3d:


    grace "On dirait qu'on va faire équipe pour celui-là !"


translate french amphi_9e723f6f:


    d "Oui... pas trop déçue ?"


translate french amphi_1142e283:


    grace "Bien sûr que non ! J'aurais pas pû demander meilleur équipier pour un test ! Tu es fort et tu sembles entraîné !"


translate french amphi_a33da4f1:


    d "Il va falloir que je me surpasse !"


translate french amphi_5c729483:


    grace "C'est sûr ! Allez... Allons gagner ce test !"


translate french amphi_6ec0e013:


    drew "[name] avec Madison !"


translate french amphi_3cbbdcb1:


    mad "Oh...Mon...Dieu..."


translate french amphi_e5d8bebc:


    d "Okay... Ben va falloir se supporter pour celui-là je crois..."


translate french amphi_9073a9f7:


    mad "Pas le choix... Mais peut être que c'est pas si mal... Tu es... Costaud..."


translate french amphi_0d217974:


    d "Toi aussi..."


translate french amphi_4845a04a:


    mad "On verra, tu me suis et surtout ne perds pas de temps !"


translate french amphi_0e114910:


    d "Promis !"


translate french amphi_39df151c:


    orushi "Bref, je vais pas vous garder plus longtemps..."


translate french amphi_d5a82ce4:


    orushi "Oh, j'ai failli oublier ! C'est aussi un test de vitesse ! Vous allez avoir 10 minutes et pas une seconde de plus avant que la course ne commence !"


translate french amphi_3892b171:


    orushi "La course commence sur le chemin du stade avec un gros son... Vous le reconnaîtrez..."


translate french amphi_a22e4927:


    orushi "Comme je le disais, 10 minutes pour se préparer et le compte à rebours commence..."




translate french e1s3_28fe81f1:


    d "Hey, je la connais elle ! Je l'ai rencontrée dans le taxi la nuit dernière ! Ouais, miss moi-je moi-je !"


translate french e1s3_e61cce50:


    julia "Disons que c'est le bon parti de l'Université... Il a hérité d'une grande fortune de son grand-père et ne se gène pas pour le montrer..."


translate french e1s3_2dee059e:


    d "Retourne jouer avec l'eau Carapuce ! Je pense pas que tu tiendrais avec moi..."


translate french e1s3_b01e04e8:


    sofia "C'est une blague ?"


translate french juliaamphi_b48326ec:


    julia "Tu peux t'asseoir à côté de moi si tu veux !"


translate french juliaamphi_23835985:


    d "Oh la vache, y'en a du monde ici !"


translate french graceamphi_346d228a:


    d "Je peux m'asseoir ici ?"


translate french graceamphi_4f482101:


    grace "Encore désolée pour mon attitude d'hier soir... Je n'aurais pas dû boire..."


translate french amphi_c98428d2:


    "(Etudiants) Quoi ???" with vpunch


translate french amphi_569ee4ce:


    orushi "Vous allez devoir finir parmi les 25 premières équipes ou vous serez éliminés."


translate french amphi_0367d4b5:


    orushi "Maintenant Mrs.Drew va vous donner les équipes !\nBonne chance et souvenez-vous, soyez les meilleurs et surtout le B.E.S.T!"


translate french amphi_f234158f:


    mad "Je n'ai pas le choix. Mais c'est peut être pas si mal... Tu es... bien taillé..."

translate french strings:


    old "Sit with Ruby ?"
    new "S'asseoir avec Ruby ?"


    old "Sit with Julia ?"
    new "S'asseoir avec Julia ?"


    old "Sit with Grace ?"
    new "S'asseoir avec Grace ?"


    old "Sit with Madison ?"
    new "S'asseoir avec Madison ?"




translate french e1s3_31ff91fe:


    julia "On fait parti de la plus grande équipe académique de foot féminin du pays ! Et plusieurs d'entre nous sont pressenties pour rejoindre l'équipe nationale ! On a toutes le même rêve..."




translate french e1s3_c576cf36:


    ruby "Ouais ! C'était bien pour le sport, mais j'en avais marre de devoir la refaire à chaque fois... Et j'avais pas beaucoup de temps ce matin... Fallait que j'emmène Cortex à sa chambre !"


translate french e1s3_c363762e:


    ruby "Arrête Julia ! Il a été parfait ! Je l'ai juste emmené jusqu'à sa chambre pour qu'il sâche où il allait dormir ! Le pauvre il connaît personne ici et il a même pas ses bagages."


translate french e1s3_33d2c520:


    ruby "Ouiiiii ! En fait, en France, ils appellent ça Minus et Cortex !"


translate french e1s3_c0ebf8c0:


    ruby "Ben l'année dernière on étudiait le parcours de Steven Spielberg et il s'avère qu'il faisait partie de l'équipe qui a créé les Animaniacs donc..."


translate french e1s3_33d2c520_1:


    ruby "Ouiiiii ! En fait, en France, ils appellent ça Minus et Cortex !"


translate french e1s3_c0ebf8c0_1:


    ruby "Ben l'année dernière on étudiait le parcours de Steven Spielberg et il s'avère qu'il faisait partie de l'équipe qui a créé les Animaniacs donc..."


translate french e1s3_7e033c28:


    julia "Bon, puisqu'on est juste tous les deux... Laisse moi te faire un rapide résumé des gens connus de l'Academy."


translate french e1s3_90077d39:


    julia "C'est un champion d'athlétisme et il a beaucoup de liens dans les affaires..."


translate french juliaamphi_96104f9b:


    julia "Tu peux t'asseoir à côté de moi si tu veux !"


translate french madisonamphi_2b7db42d:


    mad "Viens pas m'emmerder, c'est pas le moment...."


translate french amphi_64256f24:


    d "Oui... Pas trop déçue ?"


translate french amphi_7f8e4859:


    mad "J'ai pas le choix. Mais c'est peut être pas plus mal.... Tu es... Bien bâti..."




translate french e1s3_6ffafcc2:


    julia "Bon... Puisqu'on est juste tous les deux, laisse-moi te faire un petit tour des personnalités de l'Université."


translate french e1s3_08a0332e:


    julia "Alors là t'as Steven, un des gars de l'Université, toujours à essayer de chopper des filles et de conclure, comme il dit..."


translate french e1s3_7507cb6f:


    julia "En gros, c'est les plus riches de l'Université... et Madison les supporte pas..."




translate french e1s3_30b8e981:


    d "Bon... Je vais m'asseoir où moi ?"




translate french e1s3_3a174d23:


    ruby "Ouais ! C'est bien pour le sport, mais j'en avais marre ! Fallait la refaire à chaque fois... Et j'avais pas le temps ce matin... Fallait que j'accompagne Cortex à sa chambre ! "


translate french e1s3_bca8f35f:


    julia "Le retour du pervers... J'espère que tu t'es bien comporté avec Ruby ! Sinon tu vas sentir ce que ça fait que de se faire défoncer par une fille ! Et t'as de la chance que je suis de bonne humeur ! Reste loin de moi et tout se passera bien !"


translate french e1s3_a91c597d:


    ruby "Il a été parfait Julia ! Arrête ! Je l'ai emmenè à sa chambre pour qu'il puisse se changer et voir où il allait dormir. Le pauvre... Il connaît personne ici, il a pas ses bagages, et il savait même pas où il devait aller !"


translate french e1s3_9697caca:


    ruby "Ben en fait, l'année dernière on a étudié Steven Spielberg et il faisait partie de l'équipe qui a créé les Animaniacs..."


translate french e1s3_d6560304:


    julia "Okay okay okay ! Je sais pas comment tu peux faire entrer autant d'informations dans une si petite tête..."


translate french e1s3_e9db673a:


    julia "Oh, mais c'est le garçon de l'avion ! J'espère que Ruby a été sympa avec toi ! Ruby, tu l'as pas embêté trop avec toutes tes histoires j'espère ? Le pauvre, il vient d'arriver et il a dû entendre parler de films, d'animaux ou de la fonte des glaces en Antarctique..."


translate french e1s3_9c209af9:


    ruby "Que j'ai préparé moi-même !"


translate french e1s3_7c219f85:


    julia "Si tu veux, je peux te montrer le campus et ce qu'on peut y faire après les cours."


translate french e1s3_d6560304_1:


    julia "Okay okay okay ! Je sais pas comment tu peux faire entrer autant d'informations dans une si petite tête..."


translate french e1s3_fce2fe54:


    ruby "Tu peux rester un peu avec lui et lui expliquer comment ça marche ici ? Faut que j'aille au petit coin avant que les cours ne commencent..."


translate french e1s3_676dd9d3:


    julia "Alors, tu vois ça c'est Steven, un des gars de l'Université, qui essaye de chopper tout ce qui bouge à longueur de temps... Il paraît qu'il va conclure tous les soirs... Jamais vu avec qui que ce soit au final..."


translate french e1s3_00433e96:


    julia "On fait partie d'une des plus grandes équipes académiques du pays ! Et certaines d'entre nous sont potentiellement de futures joueuses de l'équipe nationale! On a toutes le même rêve..."


translate french e1s3_6a905540:


    julia "Oui, c'est vrai ! On a vu tous les matchs contre notre équipe ! Bon... Vous avez toujours pas gagné de coupe mais c'était parfois pas loin ! Vous avez de bonnes attaquantes aussi... Enfin vous aviez..."


translate french e1s3_5c0f1f9d:


    julia "On a la meilleure... Malheureusement elle est aussi arrogante qu'elle est forte..."


translate french e1s3_578bed5e:


    d "Okay... Et pourquoi y'à autant de monde autour de lui ?"


translate french e1s3_a109e363:


    julia "Disons que c'est le gars le plus important de l'école... Il a hérité de la grande fortune de son grand-père et il le câche pas on va dire..."


translate french e1s3_78c32aa1:


    julia "Les filles le détestent... Moi je m'en fous... Mais fais attention si tu te retrouves face à lui... Il est intraitable dans tout ce qu'il fait..."


translate french e1s3_96276d06:


    julia "Et en plus de ça, il a les fonds... Et les contacts... C'est pas quelqu'un que tu as envie de défier crois-moi..."


translate french e1s3_1e0a6dea:


    d "Okay... On va essayer de l'éviter alors !"


translate french e1s3_ff45d902:


    julia "Si tu peux ! Et maintenant... Voilà les problèmes..."


translate french e1s3_39f080a3:


    sofia "La prochaine fois que tu veux chopper quelque chose comme le cul de Julia... Sois sûr de pouvoir t'en servir après !"


translate french e1s3_20cbf439:


    sofia "Qui sait ! Tu pourrais avoir une récompense !"


translate french e1s3_a06175a5:


    d "Ouais... Au pire je peux te foutre une carabifle... Ca te fera évoluer !"


translate french e1s3_eeebd644:


    d "A plus tard la bleue, j'en ai d'autres à attraper !"


translate french madisonamphi_5d9c6a27:


    d "Je suppose qu'on va le savoir très bientôt."


translate french amphi_d6132e39:


    orushi "A la fin de cette compétition, la personne sélectionnée recevra le titre de B.E.S.T étudiant, un chèque de 500 000 $, et une place en tant qu'assistant de direction chez Orushi Corp."


translate french amphi_04c5548f:


    mad "J'ai pas le choix de toute façon... Mais c'est pas si mal vu que tu es... Sec..."


translate french amphi_1abbe7bc:


    orushi "La course commencera près du stade avec un son lourd..."




translate french e1s3_c697cc23:


    julia "Le retour du pervers... J'espère que tu t'es bien comporté avec Ruby ! Sinon tu vas sentir ce que ça fait que de se faire défoncer par une fille !"


translate french e1s3_8e0cfd62:


    julia "Et t'as de la chance que je suis de bonne humer ! Reste loin de moi et tout se passera bien !"


translate french e1s3_f2b26f55:


    ruby "Il a été parfait Julia ! Arrête ! Je l'ai emmenè à sa chambre pour qu'il puisse se changer et voir où il allait dormir."


translate french e1s3_758413b0:


    ruby "Le pauvre... Il connaît personne ici, il a pas ses bagages, et il savait même pas où il devait aller !"


translate french e1s3_3fdb3897:


    julia "Oh, mais c'est le garçon de l'avion ! J'espère que Ruby a été sympa avec toi ! Ruby, tu l'as pas embêté trop avec toutes tes histoires j'espère ?"


translate french e1s3_f465834e:


    julia "Le pauvre, il vient d'arriver et il a dû entendre parler de films, d'animaux ou de la fonte des glaces en Antarctique..."




translate french e1s3_cf35a02d:


    julia "Nous sommes l'une des meilleures équipes académiques de football du pays ! Et certains d'entre nous sont pressentis pour rejoindre l'équipe nationale !"


translate french e1s3_050733da:


    drew "Tous les étudiants, veuillez vous rendre à l'auditorium !"


translate french amphi_48029896:


    orushi "Vous devez vous demander pourquoi vous avez été convoqués à l'auditorium dès le début de votre première journée."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
