


translate french avion_3c2f4c7e:


    dpense "J'étais dans l'avion 30 minutes avant le décollage."


translate french avion_22dc7ae8:


    dpense "Je cherchais ma place dans ce jet spécialement affrêté pour les jeunes en transit pour l'Amérique."


translate french avion_53a3856f:


    dpense "Ma place était la 23 droite mais il y avait un couple avec un bébé dessus... Ils m'ont demandé si je pouvais laisser mon siège..."


translate french avion_a1938bf4:


    dpense "Je suis un bon gars donc... je les ai laissés... et je suis allé voir dans l'allée d'après s'il y avait un siège de libre..."


translate french avion_8b82e03d:


    dpense "C'est là que je suis tombé sur elle..."


translate french avion_0e0160fd:


    ji "Salut ?"


translate french avion_e95421cf:


    d "Oh euh b...bonjour"


translate french avion_f3fce131:


    ji "Je peux t'aider ?"


translate french avion_e9697244:


    d "Heu... Non pardon... désolé..."


translate french avion_205765b5:


    d "Je peux m'asseoir ici ?"


translate french avion_20a982fa:


    ji "Oui bien sûr ! C'est pas mon siège et l'avion n'est pas plein de toute façon..."


translate french avion_223a2e56:


    ji "Je viens juste de me poser y'à 30 secondes près du hublot pour respirer un petit peu..."


translate french avion_65bca321:


    d "Pour respirer ?"


translate french avion_b2c84831:


    ji "Oui, en première classe il y a une fête pour les filles de l'équipe et c'est un peu ... bruyant !"


translate french avion_80509efd:


    d "Ah... d'accord..."


translate french avion_7915eabc:


    "Les choix sont importants dans ce jeu et le personnage principal a des caractéristiques dans 4 branches différentes : B.E.S.T"


translate french avion_6fa575d7:


    "BUDDY ou amitié est l'attitude du joueur avec ses amis, cela impacte ses relations avec les autres"


translate french avion_d274e0ab:


    "EDUCATION est la culture générale du joueur, cela impacte les possibilités de dialogues et les résultats aux examens"


translate french avion_c988f80e:


    "SPORT est le niveau athlétique du joueur, requis pour atteindre certains objectifs pendant le jeu"


translate french avion_f9ed7015:


    "TEMPERAMENT est la nature du joueur, cela aura un impact sur les actions du joueur envers les autres personnages"


translate french avion_9829a9c5:


    "Certains choix amèneront à des améliorations de ces caractéristiques..."


translate french avion_f61f9868:


    "Et d'autres seront inaccessibles si vous n'avez pas le minimum requis"


translate french matte_d3e6cc48:


    "Ici votre temperament a augmenté"


translate french matte_cfa4e57e:


    "SI vous regardez dans la fenêtre des stats vous verrez que Temperament est passé de 0 à 1"


translate french matte_85fbeeda:


    "SI vous faites un choix ou un autre, une stat differente peut être influencée"


translate french matte_91b5e938:


    "Maintenant revenons à l'histoire..."


translate french matte_f9d4c0c8:


    ji "Je peux t'aider ?"


translate french matte_aa5e6e08:


    d "OH ! heu... non non merci... désolé je me suis perdu dans mes pensées en te regardant..."


translate french matte_1523fe20:


    d "..."


translate french matte_cd8e3eae:


    d "Désolé je voulais pas dire ça ..."


translate french matte_263824f1:


    ji "AHAH... T'inquiète pas tu n'es pas le premier obsédé qui me regarde comme ça !"


translate french matte_bff3ad4b:


    d "Je ne suis pas un obsédé..."


translate french matte_1523fe20_1:


    d "..."


translate french matte_f1bb6b3c:


    d "Je m'appelle [name]... désolé si mon anglais n'est pas bon mais je suis français et je vais en Amérique pour l'améliorer "


translate french matte_bd797ba0:


    ji "..."


translate french matte_8d28f053:


    julia "Julia ! Ravie de te rencontrer !"


translate french matte_fea877c1:


    d "T'es souvent embêtée par des garçons ?"


translate french matte_28efb620:


    julia "Tout le temps... avec les filles de l'équipe..."


translate french matte_ae405faf:


    d "L'équipe ?"


translate french matte_f70bd560:


    julia "Oh tu ne sais pas ? au début ce jet était juste pour nous..."


translate french matte_fe694bb4:


    julia "Mais la compagnie veut faire des économies pour son budget..."


translate french matte_41ef5221:


    julia "Du coup on a dû partager ce vol avec des étudiants et des familles à petit budget..."


translate french matte_f31d507b:


    julia "C'est pas vraiment un problème pour moi mais d'autres ne sont pas aussi sympas que moi..."


translate french matte_6f354ea0:


    d "Mais vous êtes combien ?"


translate french matte_f1a70bd0:


    julia "Ben si on compte Gabriella qui nous accompagne on doit être ..."


translate french matte_e81b7001:


    dpense "Des éclats de rire viennent du fond..."


translate french matte_3cce8ef2:


    ji "TU NE SAIS PAS CE QUE CE GARS A ESSAYE DE FAIRE ?"


translate french matte_3157f6c5:


    d "C'est qui... ???"


translate french matte_afebb7c6:


    julia "C'est mes filles... je retourne voir ce qu'elles font... à plus tard l'obsédé !"


translate french matte_ce392a47:


    d "Je ne suis pas un obsédé !"


translate french matte_15487c24:


    julia "Excuse moi..."


translate french grope_5c6f0c18:


    dpense "Je ne sais pas pourquoi mais j'ai trop envie de toucher..."


translate french grope_38cf1df9:


    dpense "Je sais que ce n'est pas bien..."


translate french grope_6cb9f1a5:


    dpense "Je ne peux pas..."


translate french grope_93427ddd:


    julia "OH SI T'EN ES UN !!!!"


translate french grope_3783fa80:


    julia "Obsédé..."


translate french grope_10de7494:


    dpense "Elle m'a tapé !"


translate french temperament_increased_d654fe5a:


    "VOTRE TEMPERAMENT A AUGMENTE"


translate french timide_66e6c047:


    "Ici votre Education a augmenté"


translate french timide_65a3784c:


    "SI vous regardez à la fenêtre des statistiques vous verrez que Education est passée de 0 à 1"


translate french timide_85fbeeda:


    "Si vous faites un choix ou un autre, une statistique différente sera influencée"


translate french timide_91b5e938:


    "Maintenant retournons à l'histoire..."


translate french timide_44dd9392:


    dpense "Elle a l'air si confiante... je suis tellement timide que je ne sais même pas comment lui parler..."


translate french timide_875aea8d:


    dpense "Peut être... Hey ! Je suis français ! et toi ?"


translate french timide_9013cbce:


    dpense "Nan c'est un peu con... Salut mon prénom est [name] ! et le tien ?"


translate french timide_69a7a5b6:


    dpense "C'est peut être un peu trop scolaire... Bonjour je m'appelle Bryan... Où est Bryan ? Bryan est dans la cuisine..."


translate french timide_ca896922:


    dpense "Putain... je sais même pas par où commencer avec une fille assise à côté de moi..."


translate french timide_5c925b1b:


    dpense "Qu'est ce que ça va être aux US avec tous les gens dans l'Academy..."


translate french timide_b463a58f:


    dpense "Une tonne de bruits venant du fond..."


translate french timide_ab76d8f2:


    ji "ET TU SAIS CE QUE CES GARS ONT ESSAYE DE FAIRE ???"


translate french timide_3157f6c5:


    d "Qui..."


translate french timide_7618e110:


    julia "C'est mes filles..."


translate french timide_83ccf072:


    julia "Excuse moi..."


translate french timide_dd8b8a53:


    julia "désolé je vais voir ce qu'elle font ! Salut !"


translate french timide_320c3073:


    d "Salut..."


translate french timide_6689b535:


    d "Je ne sais même pas comment elle s'appelle..."


translate french education_increased_205ead2d:


    "VOTRE EDUCATION A AUGMENTE"


translate french steven_cec17e94:


    dpense "Elle était jolie..."


translate french steven_37e64b70:


    dpense "..."


translate french steven_172f6531:


    "Hey mon gars t'es un sacré toi !"


translate french steven_5c0e76f8:


    d "Quoi ?"


translate french steven_a3d1931f:


    "T'arrives là et tu parles déjà avec une des filles les plus populaires de l'Academy ?"


translate french steven_928c2998:


    d "Populaire ? Comment ça ?"


translate french steven_8a22f6cb:


    "Putain et moi qui croyait que t'étais cool... le gars qui va dans un avion et rencontre Julia, LA milieu de terrain de l'Equipe, et toi t'en savais rien ?"


translate french steven_76324af9:


    d "Je...."


translate french steven_0fc22f54:


    "Tu ne sais rien Jon Snow..."


translate french steven_263cb021:


    d "Je ne ..."


translate french steven_f4ab7252:


    "Game of thrones mon gars ! Putain mais t'es pas aussi stupide que t'en as l'air quand même ? Daenerys Targaryen, Jamie, incest... et des paires de seins de partout !!!! "


translate french steven_d161cfe2:


    d "Je sais ce que c'est Game of Thrones quand même...."


translate french steven_00a8ee85:


    "Bon ben c'est déjà ça... Okay je suis Steven et toi ?"


translate french steven_adba3d07:


    d "[name]..."


translate french steven_a530b75a:


    s " Bizarre ce prénom... mais pourquoi pas après tout ! Et tu vas où comme ça ?"


translate french steven_ef342699:


    d "Bah... premier jour à l'Academy demain donc..."


translate french steven_8cca5450:


    s " Moi aussi ! Ecoute ! On se rejoint avant d'entrer... T'auras vraiment besoin de quelqu'un quand tu vas entrer dans l'arène..."


translate french steven_31bf4755:


    d "Dans quoi ?"


translate french steven_391e43c1:


    s "L'arène ! Putain mon gars on va devoir se battre face aux gosses de riche pour la victoire et la gloire !"


translate french steven_461c9417:


    s "Et tu sais ce que la gloire veut dire ? "


translate french steven_1523fe20:


    d "..."


translate french steven_e1554201:


    s "..."


translate french steven_263cb021_1:


    d "Je ne..."


translate french steven_65650b43:


    s "Sais pas ... Je sais ! La gloire veut dire LES FILLES ! Et plus de gloire veut dire ?"


translate french steven_1523fe20_1:


    d "..."


translate french steven_e1554201_1:


    s "..."


translate french steven_3a792386:


    d "Plus de filles ?"


translate french steven_42bdf55a:


    s "T'es intelligent toi non ?"


translate french steven_1523fe20_2:


    d "..."


translate french steven_ab47303d:


    s "Bref c'est sympa de parler avec toi mais j'ai d'autres trucs à faire ... des filles à aller m'occuper en fait ... donc on se voit demain !"


translate french steven_b95efa92:


    d "Je..."


translate french steven_28540ca0:


    s "Et attends moi avant d'entrer !"


translate french steven_1523fe20_3:


    d "..."


translate french steven_6235c3ee:


    dpense "Ils sont tous aussi fous que lui ?"


translate french steven_1523fe20_4:


    d "..."


translate french steven_86c73062:


    d "Je suis crevé..."


translate french sexytime1_b7f8fd90:


    julia ""


translate french sexytime1_4a885e57:


    julia ""


translate french sexytime1_d75beb82:


    julia ""


translate french sexytime1_3a06b08c:


    julia ""


translate french sexytime1_f4a014f0:


    julia ""


translate french sexytime1_62c0de79:


    julia ""


translate french sexytime1_462b3181:


    julia ""


translate french sexytime1_2ef34de2:


    julia ""


translate french sexytime1_2389a122:


    julia ""


translate french sexytime1_08daf8ff:


    julia ""


translate french sexytime1_41d4b0ad:


    julia ""


translate french reveil_5834d712:


    d "WHAAAAAAAAAAAAAAAAAAAAAA..."


translate french reveil_75d26afb:


    s "AHHHHHHHHHHHHHHHHHHHHHHH..."


translate french reveil_35678e56:


    d "Putain tu m'as fait peur !"


translate french reveil_4341cad1:


    s "T'es fou ! C'est toi qui m'a fait peur à hurler comme ça !"


translate french reveil_1523fe20:


    d "..."


translate french reveil_fa8ee0a7:


    s "Bon allez mon gars c'est l'heure d'y aller !"


translate french reveil_8c41de0c:


    s "Oublies pas ! Demain matin tu m'attends à l'entrée !"


translate french buddy_increased_203b7603:


    "VOTRE BUDDY A AUGMENTE"

translate french strings:


    old "Look at her"
    new "La mater"


    old "Stay quiet"
    new "Rester silencieux"


    old "grope her"
    new "Lui toucher le cul"


    old "I'm not a pervert !"
    new "Je ne suis pas un obsédé !"


    old "Yes sure !"
    new "Ouais bien sûr !"


    old "I don't need you, thanks !"
    new "J'ai pas besoin de toi, merci !"




translate french avion_250d212e:


    ji "Je peux t'aider ?"


translate french matte_bdba273f:


    "Plein de bruits venant du fond"


translate french steven_b9dc478d:


    s "Bizarre comme nom... mais pourquoi pas ! Et tu vas où comme ça ?"


translate french steven_7a07c8fd:


    s "Moi aussi ! Ecoute ! Demain on se rejoint avant d'entrer... tu vas vraiment avoir besoin de quelqu'un pour entrer dans l'arène."




translate french avion_bf2491da:


    dpense "J'étais dans l'avion 30 minutes avant le décollage"


translate french avion_577b4266:


    dpense "Je cherchais mon siège dans ce jet spécialement affrêté pour des jeunes en transit vers les Etats-Unis."


translate french avion_db8b5a1a:


    dpense "Mon siège était le numéro 23, mais il y avait un couple avec un bébé déjà installés... Ils m'ont demandé si je pouvais laisser ma place."


translate french avion_6bbd51df:


    dpense "Comme je suis un bon gars, j'ai accepté et je suis parti un peu plus loin pour trouver une place libre dans la prochaine allée."


translate french avion_c9141fde:


    ji "Oui, en première classe il y a une fin de soirée avec toutes les filles mais c'est un peu... bruyant !"


translate french avion_da42aa4a:


    d "Hmmmm... okay..."


translate french avion_05fb2cc7:


    "Les choix sont importants dans ce jeu et le héros a des caractéristiques dans 4 différents domaines : B.E.S.T"


translate french avion_08097147:


    "BUDDY est votre lien d'amitié avec les autres, ce qui a un impact avec les interactions que vous pourrez avoir avec eux."


translate french avion_6c80f711:


    "EDUCATION est le niveau de culture générale du héros, ce qui impacte les discussions et sujets ainsi que les notes aux examens."


translate french avion_832f9cb5:


    "SPORT est le niveau athlétique du héros, requis pour atteindre certains objectifs pendant le jeu."


translate french avion_832f9cb5_1:


    "SPORT est le niveau athlétique du héros, requis pour atteindre certains objectifs pendant le jeu."


translate french avion_64aaaa8f:


    "Certains choix amèneront à une amélioration..."


translate french avion_e248561e:


    "Et d'autres seront inaccessibles si vous n'avez pas le minimum requis."


translate french matte_ff6594cd:


    ji "ET VOUS SAVEZ CE QUE CES GARS ONT ESSAYE DE FAIRE ?"


translate french matte_7c8a480f:


    d "Qui est-ce ???"


translate french grope_1f0f7d59:


    dpense "Elle m'a défoncé ! J'y crois pas !"


translate french timide_1d396d27:


    dpense "Non, c'est pas une bonne approche. Salut, mon nom est [name]. Quel est le tien ?"


translate french timide_ef598f94:


    dpense "Un peu trop formel. Hello, my name is Bryan. Where's Bryan? Bryan is in the kitchen."


translate french timide_1baa4752:


    dpense "Putain... Je sais même pas par où commencer avec une fille qui est assise à côté de moi."


translate french timide_045b78cb:


    dpense "Qu'est ce que ça va être avec tout le monde à l'académie ?"


translate french timide_2f99d1af:


    ji "ET VOUS SAVEZ CE QUE CES GARS ONT ESSAYE DE FAIRE ?"


translate french steven_6f1ae60c:


    "T'as fait n'importe quoi mon gars !"


translate french suitesteven_5c0e76f8:


    d "De quoi ?"


translate french suitesteven_c8ef85c6:


    "T'es là, et tu parles avec une des filles les plus populaires de l'Academy ?"


translate french suitesteven_928c2998:


    d "Populaire ? Comment ça ?"


translate french suitesteven_594b5eb4:


    "Tu ne sais vraiment pas ? Je pensais que t'étais cool... Le gars qui vient dans un avion et rencontre Julia, la meilleure milieu de terrain de l'équipe."


translate french suitesteven_76324af9:


    d "Je ...."


translate french suitesteven_0fc22f54:


    "Tu ne sais rien Jon Snow..."


translate french suitesteven_263cb021:


    d "Je ne ..."


translate french suitesteven_f4ab7252:


    "Game of Thrones mec ! Putain mais t'es pas aussi stupide que t'en as l'air quand même ! Daenerys, le nain, l'inceste... et des seins partout !!!"


translate french suitesteven_d161cfe2:


    d "Je sais ce que c'est Game of Thrones merci..."


translate french suitesteven_00a8ee85:


    "Bon ben c'est un début... Je suis Steven. Et toi ?"


translate french suitesteven_adba3d07:


    d "[name]..."


translate french suitesteven_b9dc478d:


    s "Bizarre comme nom... mais pourquoi pas après tout y'en a bien qui appellent leur enfant Clitorine... Et tu vas où comme ça ?"


translate french suitesteven_ef342699:


    d "Premier jour à l'Academie demain alors ...."


translate french suitesteven_297b5d9a:


    s "AH ouais ? Moi aussi je rentre demain ! On devrait se rejoindre avant d'entrer... Tu vas vraiment avoir besoin d'avoir quelqu'un à tes côtés quand tu vas entrer dans l'arène. "


translate french suitesteven_31bf4755:


    d "Dans quoi ?"


translate french suitesteven_5d3fff64:


    s "L'arène ! Allez mec, on va se battre contre les trouducs de riches pour la victoire et la gloire !"


translate french suitesteven_461c9417:


    s "Et tu sais ce que la gloire donne ?"


translate french suitesteven_263cb021_1:


    d "Je ne ..."


translate french suitesteven_65650b43:


    s "Sais pas ... MOI je sais ! La gloire donne les nanas !!! et plus de gloire veut dire ???"


translate french suitesteven_3a792386:


    d "Plus de filles ?"


translate french suitesteven_42bdf55a:


    s "T'es intelligent toi non ?"


translate french suitesteven_ab47303d:


    s "Okay bon c'est pas tout ça mais j'ai d'autres trucs à faire ... des filles à m'occuper ... on se voit demain...."


translate french suitesteven_b95efa92:


    d "Je..."


translate french suitesteven_28540ca0:


    s "Et attends moi avant d'entrer !!!!"


translate french suitesteven_1523fe20:


    d "..."


translate french suitesteven_6235c3ee:


    dpense "Ils sont tous aussi tarés ???"


translate french suitesteven_1523fe20_1:


    d "..."


translate french suitesteven_86c73062:


    d "Elle m'a épuisé..."


translate french suitesteven_dbdac134:


    "Ce serait pas notre petite Julia qui revient de son voyage avec les ploucs ?"


translate french suitesteven_8bff0ede:


    "Elle parlait à un gars... J'espère qu'il s'est pas fait des idées..."


translate french suitesteven_f61fb44e:


    julia "Ouais, ce pervers a essayé de me toucher les fesses quand je suis passée devant lui !"


translate french suitesteven_0773b254:


    "QUOIII ???" with hpunch


translate french suitesteven_0a848397:


    "Allons Julia, pour une fois que quelqu'un l'utilise ! Tu peux remettre ta jolie ceinture de chasteté et retourner au couvent si ça te dit..."


translate french suitesteven_aa7c4879:


    julia "C'est pas marrant Madison ! C'est sûr que je n'ai pas autant de facilités que toi avec mon corps... où avec n'importe quoi d'autre !"


translate french suitesteven_d8a71b92:


    mad "Qu'est ce que tu veux dire par là ?"


translate french suitesteven_052ca63c:


    julia "Rien rien, tout le monde sait que t'es une reine de vertue... Suffit de demander à ton copain..."


translate french suitesteven_c5799a67:


    julia "Oh attend... lequel ?"


translate french suitesteven_a27962ef:


    mad "Je vais rentrer mon poing dans ta bouche ça t'apprendra quelle reine je suis..."


translate french suitesteven_0951d6fb:


    "Les filles les filles les filles... Vous vous arrêtez de suite !"


translate french suitesteven_a691676e:


    mad "Okay Grace... Mais dis à la Vierge Sacrée de calmer ses nerfs ailleurs ou d'utiliser un gode pour décharger parce que sinon c'est un des miens que j'utiliserais dans son putain de cul !"


translate french suitesteven_00bfac10:


    mad "Ruby !!!" with vpunch


translate french suitesteven_04b83816:


    ruby "Oui Maddie... J'arrive !"


translate french suitesteven_7e581acc:


    julia "Les ploucs, comme tu dis, sont plus agréables que toi Madison..."


translate french suitesteven_bf7ad4aa:


    mad "Ouais c'est sûr... Et ils sont prêts à te montrer leur sympathie si t'ouvres la bouche en grand..."


translate french suitesteven_06ebd413:


    julia "T'es dégueu..."


translate french suitesteven_a22cd55b:


    mad "Allez Julia, joue pas à la fille du couvent avec moi, sinon remets ta ceinture de chasteté..."


translate french suitesteven_aa7c4879_1:


    julia "C'est pas marrant Madison ! C'est sûr que je n'ai pas autant de facilités que toi avec mon corps... où avec n'importe quoi d'autre !"


translate french suitesteven_d8a71b92_1:


    mad "Qu'est ce que tu veux dire par là ?"


translate french suitesteven_052ca63c_1:


    julia "Rien rien, tout le monde sait que tu es une reine de vertue... Suffit de demander à ton copain..."


translate french suitesteven_c5799a67_1:


    julia "Oh attend... lequel ?"


translate french suitesteven_a27962ef_1:


    mad "Je vais rentrer mon poing dans ta bouche ça t'apprendra quelle reine je suis..."


translate french suitesteven_0951d6fb_1:


    "Les filles les filles les filles... Vous vous arrêtez de suite !"


translate french suitesteven_a691676e_1:


    mad "Okay Grace... Mais dis à la Vierge Sacrée de calmer ses nerfs ailleurs ou d'utiliser un gode pour décharger parce que sinon c'est un des miens que j'utiliserai dans son putain de cul !"


translate french suitesteven_00bfac10_1:


    mad "RUBY !!!" with vpunch


translate french suitesteven_04b83816_1:


    ruby "Oui Maddie... j'arrive !"


translate french filles_36dfd72e:


    grace "Putain les filles, c'est un vol de 8 heures .... Faites un effort pour vous entendre..."


translate french filles_d8ecb716:


    ruby "Je vais aller parler à Madison, elle est nerveuse depuis ce matin et je ne sais pas pourquoi."


translate french filles_f0a26782:


    grace "D'accord Ruby, vas y pendant que je parle à Julia."


translate french filles_7350408e:


    grace "Julia... Pourquoi tu rentres dans son jeu ? Tu sais comment elle est !"


translate french filles_73643294:


    julia "Ouais si vulgaire et extrêmement désagréable...."


translate french filles_57f124d0:


    grace "Ne répond pas à ses attaques et tout se passera bien... je la connais depuis la maternelle."


translate french filles_481de8d6:


    grace "Tu sais qu'elle a vécu des choses lourdes... et puis on est une équipe !"


translate french filles_83856101:


    grace "On vient de gagner le match de gala en Europe hier et aujourd'hui vous êtes les plus grandes ennemies au lieu de fêter ça toutes ensemble !"


translate french filles_f99947f0:


    julia "Je sais, Capitaine ! Mais elle a ce pouvoir sur moi... Elle me fait démarrer au quart de tour et je rage instantanément !"


translate french filles_91a03a6f:


    julia "Si je reste calme, c'est pour l'équipe, pour vous les filles parce que vous êtes vraiment importantes pour moi..."


translate french filles_43472939:


    grace "Ouais ben reste comme ça et c'est parfait..."


translate french filles_a0de62f8:


    grace "Bon je vais aller boire une coupe de champagne... J'ai pas acheté ces bouteilles quand on est passées en France pour rien... je dois goûter !"


translate french filles_1c3725b6:


    julia "D'accord. A tout à l'heure..."


translate french filles_574ac942:


    s "Oh les filles ! Il s'est passé quoi encore ? Toujours à se crêper le chignon entre toi et Madison."


translate french filles_39b1268e:


    julia "Steven, c'est pas le moment..."


translate french filles_f77da5db:


    julia "T'as été invité là parce que tu fais partie de la sélection de l'équipe des gars mais ça te donne pas le droit de t'occuper de nos affaires..."


translate french filles_30acbae1:


    s "Wow Julia, t'es si dure là..."


translate french filles_72df4079:


    julia "Désolé Steven, je voulais pas...."


translate french filles_1fc776c4:


    julia "Juste, laisse moi seule s'il te plaît."


translate french filles_5ccd17f4:


    s "Okay..."


translate french reveil_960aeedf:


    d "WHAAAAAAAAAAAAAAAAAAAAAA..." with vpunch


translate french reveil_2813f6c7:


    s "AHHHHHHHHHHHHHHHHHHHHHHH..." with vpunch


translate french reveil_33186bc7:


    s "On a atteri mec ! C'est l'heure d'y aller !"


translate french reveil_9e568633:


    s "Et oublies pas ! Demain matin, tu m'attends devant l'entrée !"




translate french avion_879d82e7:


    "TEMPERAMENT est en rapport avec les actions du héros, cela sera très important pour lui faire faire ce que vous voulez pendant le jeu."




translate french avion_d2c65b04:


    dpense "C'est là que je suis tombé sur elle..."


translate french avion_59864c14:


    ji "Je peux t'aider ?"


translate french avion_59c8bef9:


    d "Je peux m'asseoir ici ?"


translate french matte_ccaf5fec:


    d "OH ! eh.... non merci... désolé j'étais perdu dans mes pensées pendant que je te regardais..."


translate french matte_875b38d8:


    d "Heu pardon, c'est pas ce que je voulais dire..."


translate french matte_9e10da65:


    ji "AHAH... T'inquiète pas, t'es pas le premier obsédé qui me regarde comme ça!"


translate french matte_69db263a:


    d "Je suis [name]... désolé si mon anglais n'est pas très bon mais je suis français et je vais aux Etats-Unis pour l'améliorer."


translate french matte_73fabed3:


    julia "Tout le temps... et pareil pour les filles de l'équipe..."


translate french matte_bac589fd:


    julia "C'est mes filles... Je vais voir ce qu'elles sont en train de faire... à plus tard l'obsédé !"


translate french grope_4f934acb:


    dpense "Je ne sais pas pourquoi mais je dois toucher..."


translate french grope_f505e264:


    dpense "Elle m'a dégommé ! J'y crois pas !"


translate french timide_bb5b78a9:


    "Si vous faites un choix ou un autre, une statistique différente sera influencée."


translate french timide_fcdb1713:


    dpense "Elle paraît confiante... Je suis trop timide, je ne sais pas comment lui parler..."


translate french timide_b9ae6907:


    dpense "Peut être... Hey ! Je viens de France ! et toi ?"


translate french timide_bba6d66a:


    julia "Désolée je vais voir ce qu'elles font ! à plus tard !"


translate french suitesteven_d6ed908a:


    "Tu ne sais vraiment pas ? Je pensais que t'étais cool... le gars qui se pointe dans un avion et s'installe à côté de Julia, la meilleure milieu de l'équipe."


translate french suitesteven_3ff2064c:


    "Bon, c'est un début... okay moi c'est Steven et toi ?"


translate french suitesteven_8c708054:


    d "Entrer dans quoi ?"


translate french suitesteven_9ad63e38:


    s "L'arène ! Allez mec, on va devoir se faire notre place parmi ces trouducs de riches pour la victoire et la gloire !"


translate french suitesteven_c1279124:


    s "sais pas ... MOI JE SAIS ! La gloire veut dire les filles !!! et plus de gloire veut dire ???"


translate french suitesteven_d42966d6:


    s "T'es intelligent toi, non ?"


translate french suitesteven_d7661520:


    s "Bon c'était sympa tout ça mais j'ai des trucs à faire... des filles à aller m'occuper en fait... on se voit demain..."


translate french suitesteven_ab6debc8:


    "Elle parlait à un gars... J'espère qu'il ne s'est pas fait d'idées à son propos..."


translate french suitesteven_f4162cf2:


    julia "Ouais cet obsédé m'a choppé les fesses pendant que je passais devant lui !"


translate french suitesteven_310c856f:


    julia "C'est pas marrant Madison ! C'est sûr que je n'ai pas autant d'aisance que toi avec mon corps... ou avec quoi que ce soit d'autre !"


translate french suitesteven_9cc5a00f:


    julia "Rien rien, tout le monde sait que tu es une reine de vertue... Il suffit de demander à ton copain..."


translate french suitesteven_ab8085d8:


    mad "Je vais te rentrer mon poing au fond de ta gorge tu vas apprendre quelle reine je suis ..."


translate french suitesteven_bf916a8b:


    mad "Okay Grace... Mais dis à la Sainte Vierge de calmer ses nerfs ou d'utiliser un gode pour les relâcher avant que j'utilise un des miens dans son putain de cul !"


translate french suitesteven_3b1b65c9:


    julia "Les ploucs, comme tu dis, sont plus sympathiques que le fait de t'avoir autour Madison..."


translate french suitesteven_c2511ec3:


    mad "C'est sûr... Et je parie qu'ils sont tous prêts à te montrer leur sympathie si tu ouvres assez grand la bouche..."


translate french suitesteven_7bec8df1:


    julia "C'est pas marrant Madison ! C'est sûr que je n'ai pas autant d'aisance que toi avec mon corps... ou avec quoi que ce soit d'autre !"


translate french suitesteven_8d3b5bc8:


    julia "Rien rien, tout le monde sait que tu es une reine de vertue... Il suffit de demander à ton copain..."


translate french suitesteven_ab8085d8_1:


    mad "Je vais te rentrer mon poing au fond de ta gorge tu vas apprendre quelle reine je suis ..."


translate french suitesteven_bf916a8b_1:


    mad "Okay Grace... Mais dis à la Sainte Vierge de calmer ses nerfs ou d'utiliser un gode pour les relâcher avant que j'utilise un des miens dans son putain de cul !"


translate french filles_5dafe21b:


    ruby "Je vais aller parler à Madison, elle est nerveuse depuis ce matin et je ne sais pas pourquoi."


translate french filles_6bd44eb9:


    grace "Julia... Pourquoi tu entres dans son jeu ? Tu sais comment elle est !"


translate french filles_48e10477:


    grace "Ne répond pas à ses remarques et tout ira bien... Je la connais depuis la maternelle..."


translate french filles_9b86285c:


    julia "Je sais Capitaine ! Mais elle a ce truc sur moi... elle me fait démarrer au quart de tour !"


translate french filles_9d3b0a4a:


    julia "Si je reste calme, c'est pour l'équipe, pour vous les filles parce que vous êtes importantes pour moi..."


translate french filles_a990d152:


    grace "Bon je vais aller me prendre une coupe de ce champagne... J'ai pas acheté ces bouteilles pendant qu'on passait en France pour rien... Je me dois de les goûter !!!"


translate french filles_982e0933:


    s "Les filles ! Qu'est ce qui s'est passé encore ? Toujours à vous crêper le chignon entre toi et Madison..."


translate french filles_5cb4ada5:


    julia "Tu as été invité uniquement parce que tu fais partie de la sélection de l'équipe masculine, mais ça ne te donne pas le droit d'écouter nos conversations."


translate french filles_1e9f420c:


    julia "Je suis désolée Steven, je voulais pas le dire comme ça..."


translate french filles_72376f97:


    julia "Juste, laisse moi tranquille s'il te plaît. J'ai besoin d'être seule..."




translate french avion_f23e6bc9:


    ji "Bien sûr ! C'est pas mon siège et l'avion n'est pas plein donc..."


translate french avion_305e8489:


    "EDUCATION est la culture générale du joueur, cela impacte les possibilités de dialogues et les résultats aux examens"


translate french avion_cad008fe:


    "SPORT est le niveau athlétique du joueur, requis pour atteindre certains objectifs pendant le jeu"


translate french avion_a52cf64d:


    "TEMPERAMENT est la nature du joueur, cela aura un impact sur les actions du joueur envers les autres personnages"


translate french matte_150fd4fc:


    d "Mais vous êtes combien ?"


translate french suitesteven_3f653dd3:


    "Bon c'est un début... Moi c'est Ruby... et toi ?"


translate french suitesteven_9a320f54:


    ruby "Bizarre comme nom... Mais pourquoi pas ? Après tout y'en a qui appellent leur fille Clitorine donc... Et tu vas où comme ça ?"


translate french suitesteven_d339ba94:


    ruby "Ah ouais ? Moi aussi ! Bon écoute. On doit se rejoindre avant d'entrer. Tu vas vraiment avoir besoin de quelqu'un avec toi quand tu vas entrer là-dedans !"


translate french suitesteven_f1cac575:


    d "Hein ? Pourquoi ?"


translate french suitesteven_ebcf68fa:


    ruby "Pour les filles ! Imagines, y'à des filles partout, certaines avec des griffes acérées prêtes à tout pour la victoire et la gloire ! "


translate french suitesteven_7cb8c249:


    ruby "Et tu sais ce que la gloire donne ?"


translate french suitesteven_b9d7adbe:


    ruby "Sais pas ... MOI je sais ! La gloire attire les filles ! Et tu seras l'élu si tu réussis ! Imagine les filles à tes pieds ! Et plus de gloire veut dire ???"


translate french suitesteven_3d69d3e3:


    ruby "T'es intelligent toi, non ? Bon Cortex, t'es prêt à conquérir ce monde ?"


translate french suitesteven_70f8ce66:


    ruby "Ouais, bon peut être pas encore... Mais je vais régler ça ! Bon c'était cool de parler avec toi mais j'ai d'autres choses à faire... D'autres filles attendent mes conseils... on se voit demain..."


translate french suitesteven_8c910611:


    ruby "Et tu m'attends avant d'entrer dans l'arène !"


translate french suitesteven_9fd6da5c:


    dpense "Ils sont tous aussi tarés que cette fille ?"


translate french suitesteven_2091072f:


    julia "C'est pas drôle Madison ! Je suis pas aussi à l'aise que toi avec mon corps... ou avec les choix que je fais !"


translate french suitesteven_1b010223:


    julia "Ah ben on ne peut pas... Il est parti en te laissant seule avec un enfant et il a disparu ! Bon choix Madison !"


translate french suitesteven_1f27d426:


    mad "Ne parle pas de mon enfant ! Je vais rentrer mon poing dans ta gorge et tu apprendras quelle reine je peux être !"


translate french suitesteven_2091072f_1:


    julia "C'est pas drôle Madison ! Je suis pas aussi à l'aise que toi avec mon corps... ou avec les choix que je fais !"


translate french suitesteven_1b010223_1:


    julia "Ah ben on ne peut pas... Il est parti en te laissant seule avec un enfant et il a disparu ! Bon choix Madison !"


translate french suitesteven_1f27d426_1:


    mad "Ne parle pas de mon enfant ! Je vais rentrer mon poing dans ta gorge et tu apprendras quelle reine je peux être !"


translate french filles_f494c15e:


    grace "Ne répond pas à ses attaques et tout ira pour le mieux... Je la connais depuis la maternelle."


translate french filles_fb3145c4:


    julia "Okay... à plus tard..."


translate french filles_294ee104:


    "Les filles ! Qu'est ce qui se passe encore ? Toujours quelque chose entre toi et Madison."


translate french filles_74bb7683:


    s "Wow Julia, t'es si dûre..."


translate french reveil_926f9119:


    ruby "AHHHHHHHHHHHHHHHHHHH..." with vpunch


translate french reveil_54bc6a0e:


    ruby "Nan mais ça va pas ? C'est toi qui m'a fait peur !"


translate french reveil_61fcd58b:


    ruby "Bon on a atteri ! Allez mignon, il est temps d'y aller !"


translate french reveil_a1032ad8:


    ruby "Et oublies pas ! Demain matin, tu m'attends à l'entrée !"



translate french strings:


    old "MEANWHILE"
    new "PENDANT CE TEMPS..."


    old "HOURS LATER"
    new "QUELQUES HEURES PLUS TARD..."




translate french matte_20b35922:


    ji "Je peux faire quelque chose pour toi ?"


translate french matte_6c7fff83:


    ji "T'étais en train de me mater ?"


translate french matte_b718be2d:


    d "Hey ! Mais SI, et c'est un gros SI, je te regardais, non pas que je le faisais, est-ce que je serais à blâmer ? Après tout je ne suis qu'un homme."


translate french matte_cf80a00d:


    ji "Oh, c'est comme ça ? Donc tu penses que je ne suis pas assez jolie pour toi pour que tu aies envie de me regarder ?"


translate french matte_ab7b2ae1:


    julia "Bref... Moi c'est Julia, Monsieur Pervert."


translate french matte_ff60522b:


    d "Oh, on est même pas encore ensemble et j'ai déjà un surnom ? Je suis pas sûr d'aimer celui-ci mais bon..."


translate french matte_eb29e630:


    julia "Pas encore ensemble ? Monsieur a pris la confiance."


translate french matte_9e84d70f:


    d "J'essaye ! Bon, qu'est ce qu'une fille comme toi fait dans un jet comme ça ?"


translate french matte_83c9a1f1:


    julia "Oh tu ne sais pas ? Au début ce jet était juste pour nous..."


translate french timide_cd245f70:


    dpense "Est ce que je dis juste mon prénom et je lui demande le sien .... ou je lui parle de la fête en première classe ?"


translate french timide_c35c9e58:


    dpense "Ouais je vais faire ça, ça devrait marcher ... au pire ça brisera la glace et on pourra continuer à partir de là."


translate french timide_454c843b:


    d "Alors... tu...."


translate french timide_ff6594cd:


    ji "ET VOUS SAVEZ CE QUE CES GARS ONT ESSAYE DE FAIRE ???"


translate french suitesteven_753557be:


    "Ben... Game of thrones quand même ! Tu vas pas me dire que tu connais pas ? Daenerys Targaryen, Jamie, les dragons, l'inceste...."


translate french suitesteven_7ddaf8de:


    "Ah j'ai eu peur ! C'est bon alors ! Moi c'est Ruby et toi ?"


translate french suitesteven_486ce07e:


    ruby "Oh j'aime bien, c'est assez mignon... Pas comme ceux qui appellent leurs enfants Clitorine... nan mais qui appelle son enfant Clitorine ? "


translate french suitesteven_e66abe9c:


    ruby "Y'à des gens je te jure, ils donnent de ces prénoms à leurs enfants... beurk... mais pas le tien ! Le tien j'aime bien ! Désolée, je parle non stop... Bon tu vas où ?"


translate french suitesteven_46acb989:


    ruby "C'est la jungle !!!! Tu vas voir, y'à des filles partout qui attendent dans le noir, certaines avec des griffes acérées prêtes à tout pour la victoire et la gloire !"


translate french suitesteven_6d15a124:


    ruby "T'es intelligent toi, non ? Je vais être ta partenaire ! Non... Je vais être ton Cupidon ! Je suis Minus et tu es Cortex okay ? Alors es-tu prêt à conquérir le monde ?"


translate french suitesteven_2523c148:


    ruby "Okay... bon peut être pas encore Cortex... Je vais régler ça ! Bon c'est super sympa de discuter avec toi et tout et tout... mais les autres filles attendent mes services alors à plus tard !"


translate french suitesteven_99a38228:


    mad "Je me casse !" with vpunch


translate french suitesteven_7c3b1f00:


    ruby "Maddie... Calme-toi..."


translate french reveil_3749ddf4:


    ruby "On a atteri ! Okay Cortex, c'est l'heure d'y aller !"


translate french reveil_5fd503eb:


    ruby "Et n'oublie pas ! Demain matin, tu m'attends à l'entrée ! On va conquérir le monde ! Ou peut être l'Academy est suffisante pour le moment ? Je vais réfléchir à tout ça... "




translate french suitesteven_99a38228_1:


    mad "Je m'en vais !" with vpunch


translate french suitesteven_7c3b1f00_1:


    ruby "Maddie... calme-toi !"




translate french matte_bb5b78a9:


    "Si vous faites un choix ou un autre, une statistique différente sera affectée"


translate french timide_2c3c8e7d:


    d "Alors...Tu..."

translate french strings:


    old "Grope her"
    new "L'attraper"



translate french strings:


    old "YOUR TEMPERAMENT HAS INCREASED"
    new "VOTRE TEMPERAMENT A AUGMENTE"


    old "YOUR EDUCATION HAS INCREASED"
    new "VOTRE EDUCATION A AUGMENTE"


    old "YOUR BUDDY HAS INCREASED"
    new "VOTRE BUDDY A AUGMENTE"




translate french avion_fdbc5749:


    ji "Je viens juste de m'asseoir, y'a à peine 30 secondes, pour respirer un peu près du hublot..."




translate french matte_1a9a5bbd:


    julia "Ah tu ne savais pas ? Au début ce jet était juste pour nous ..."




translate french avion_dee15a14:


    "Les choix sont importants dans ce jeu et le personnage principal a 4 différentes branches que l'on nomme : B.E.S.T"


translate french avion_37fd5c70:


    "Certains choix amèneront à une augmentation d'une valeur..."


translate french matte_5daf5f10:


    "Si vous regardez à la fenêtre des statistiques vous verrez que le Temperament est passé de 0 à 1"


translate french matte_55fa1820:


    "Si vous faites un choix ou un autre, une statistique différente sera impactée"


translate french matte_1760d765:


    d "Je suis [name]... Désolé si mon anglais n'est pas très bon mais je suis Français et je vais aux USA pour m'améliorer."


translate french matte_a03052c8:


    d "Oh, alors on est pas encore ensemble et tu me donnes déjà un surnom ? Bon, pas sûr que j'aime celui-là..."


translate french matte_7667148e:


    d "J'essaye ! Et qu'est ce qu'une fille comme toi fait dans un jet comme ça ?"


translate french matte_cb69a6fa:


    julia "Oh tu ne sais pas ? A la base ce jet était juste pour nous..."


translate french matte_919e3327:


    julia "Mais la compagnie a décidé de faire des économies..."


translate french matte_a8f70784:


    julia "Du coup on doit partager le vol avec des étudiants et des familles à petits budgets..."


translate french timide_61433a92:


    "Si vous regardez la fenêtre des statistiques vous verrez que l'Education est passée de 0 à 1"


translate french timide_55fa1820:


    "Si vous faites un choix ou un autre, une statistique différente sera impactée"


translate french timide_375e8c32:


    dpense "Est ce que je devrais me présenter et lui demander son prénom ? Ou lui demander ce qu'il se passe à la fête en première classe ?"


translate french timide_298d44ce:


    dpense "Ouais, je pense que ça peut marcher... Au pire ça brisera la glace et on pourra continuer à partir de là... "


translate french suitesteven_92613612:


    "Ah tu ne sais pas ? Je pensais que t'étais cool... Le gars il se pointe et s'installe tranquilou à côté de Julia, une des stars de l'équipe."


translate french suitesteven_29c04876:


    "Game of Thrones ! Allons, tu ne connais pas ? Daenerys Targaryen, Jamie, les histoires d'inceste..."


translate french suitesteven_cbdaca76:


    ruby "Y'à des gens je te jure, ils donnent des prénoms bizarres à leurs enfants, mais j'aime bien le tien ! Désolée, je bafouille. Tu vas où comme ça ?"


translate french suitesteven_7e04732d:


    d "J'ai mon premier jour à l'Academy demain donc..."


translate french suitesteven_29d20134:


    ruby "Ah ouais ? Pour moi aussi c'est la rentrée ! On devrait se rejoindre avant d'y aller... Tu vas vraiment avoir besoin de quelqu'un pour t'accompagner !"


translate french suitesteven_051f879a:


    ruby "Je ne sais pas ... Moi je sais ! La gloire donne les filles ! Tu seras l'élu si tu réussis ! Imagine les filles à tes pieds ! Et plus de gloire veut dire ???"


translate french suitesteven_bcea06c2:


    ruby "Okay, on y est pas encore Cortex... Je vais gérer ça ! Bon c'était sympa de parler avec toi mais j'ai d'autres trucs à faire... Les filles m'attendent pour mes précieux conseils... A demain !"


translate french suitesteven_9064b9b7:


    ruby "Et tu m'attends avant de rentrer dans l'arène !!!"


translate french suitesteven_9610c720:


    julia "Ouais, ce gars m'a choppé le cul juste quand je suis passée devant lui !"


translate french suitesteven_4f329312:


    julia "Rien rien, tout le monde sait que tu es une reine de vertue... Suffit de demander à ton copain..."


translate french suitesteven_f2a091c1:


    julia "Ah ben on ne peut pas... Il t'a laissée seule avec ta fille et s'est barré sans laisser de traces ! Très bon choix Madison !"


translate french suitesteven_73723925:


    julia "Les ploucs, comme tu dis, sont plus sympas que t'avoir autour de moi Madison..."


translate french suitesteven_b2377a6e:


    julia "Rien rien, tout le monde sait que tu es une reine de vertue... Suffit de demander à ton copain..."


translate french suitesteven_f2a091c1_1:


    julia "Ah ben on ne peut pas... Il t'a laissée seule avec ta fille et s'est barré sans laisser de traces ! Très bon choix Madison !"


translate french filles_963cc653:


    julia "Je sais, Capitaine ! Mais elle a ce truc sur moi qui me fait démarrer au quart de tour !"


translate french filles_97d18b70:


    julia "SI je reste calme, c'est pour l'équipe, et pour vous les filles parce que vous êtes trop importantes pour moi..."


translate french filles_b69480b2:


    grace "Bon je vais aller boire une coupe de champagne... J'ai pas acheté ces bouteilles en passant en France pour rien... Je me dois de les goûter !"




translate french suitesteven_08447016:


    "Tu ne sais pas ? Je pensais que t'étais cool... Le gars qui se pointe dans un avion et va direct chopper Julia, une des têtes d'affiche de l'équipe..."


translate french suitesteven_6c43e1f6:


    julia "Les ploucs, comme tu dis, sont plus sympas que de t'avoir aux alentours Madison..."


translate french suitesteven_138c4979:


    mad "Oui c'est sûr... Et ils sauront te montrer comment ils sont sympas si tu ouvres assez grand ta putain de bouche..."




translate french suitesteven_4b0ca996:


    "T'es là, et t'es déjà en train de parler avec une des filles les plus populaires de l'Université ?"


translate french suitesteven_c1ff616e:


    d "Mon premier jour à l'Université demain donc..."


translate french reveil_eb201479:


    ruby "N'oublie pas ! Demain matin, attends-moi à l'entrée ! On va conquérir le monde ! Ou peut être juste l'Université pour le moment... Je vais penser à ça..."




translate french dream_b8e5bfe6:


    julia "C'est comme ça que tu m'imagines ?"


translate french dream_7b19b0bd:


    julia "Je suis un peu déçue..."


translate french dream_67c1772c:


    julia "J'espérais mieux de toi quand même ...."


translate french dream_ef072154:


    julia "Je vais devoir prendre les devants..."


translate french dream_0234bf95:


    julia "Je sais que tu as envie de toucher..."


translate french dream_16bce50e:


    julia "Bientôt tu vas pouvoir profiter de tout ça..."


translate french dream_e7985afa:


    julia "Mais en attendant..."


translate french dream_18805abb:


    julia "REVEILLE-TOI !" with hpunch


translate french dream_5c0e76f8:


    d "Hein ?"


translate french dream_54f6be08:


    ji "Réveille-toi !"


translate french dream_960aeedf:


    d "WHAAAAAAAAAAAAAAA...." with vpunch


translate french dream_926f9119:


    ruby "AHHHHHHHHHHHHHHHHHH..." with vpunch


translate french dream_35678e56:


    d "Tu m'as fait peur !"


translate french dream_54bc6a0e:


    ruby "Nan mais t'es fou ! C'est toi qui m'a fait peur !"


translate french dream_1523fe20:


    d "..."


translate french dream_3749ddf4:


    ruby "On a aterri ! Allez Cortex, faut y aller !"


translate french dream_eb201479:


    ruby "Et n'oublies pas ! Demain matin, tu m'attends à l'entrée ! On va conquérir le monde ! Ou peut être juste l'Université.... Faut que je me penche sur la question ..."




translate french matte_3b3626f9:


    "Si vous regardez vos statistiques, vous verrez que le Temperament a eu un +1"


translate french timide_3bde6659:


    "Si vous regardez vos statistiques, vous verrez que l'Education a eu un +1"




translate french avion_929cf346:


    ji "Oui bien sûr ! Vas-y assieds-toi !"


translate french avion_dd2965bd:


    ji "Je viens juste de me poser pour respirer un peu près de la fenêtre..."


translate french avion_b0802ea2:


    d "Pour respirer ?"


translate french avion_d59574f1:


    ji "Ouais... En première il y a une sorte de fête avec les filles mais c'est un peu... Comment dire... Bruyant ?"


translate french avion_ebbadba5:


    "Les choix sont importants dans ce jeu et le personnage principal ( que nous appellerons MC ) a 4 statistiques principales dénomées sous la forme : B.E.S.T"


translate french avion_862ea8b3:


    "B, pour BUDDY, est son taux d'amitié envers les autres et influence donc ses relations amicales"


translate french avion_8c05e44e:


    "E, pour EDUCATION, est en rapport avec sa culture générale et aura un impact sur ses choix et ses dialogues"


translate french avion_c2327bd8:


    "S, pour SPORT, montre son niveau athlétique et peut avoir certains pré-requis pour atteindre certains objectifs durant le jeu"


translate french avion_0daa0f65:


    "T, pour TEMPERAMENT, reflète les actions de MC et pourra avoir un impact sur tous les choix du jeu"


translate french matte_886e6305:


    ji "AHAH... T'inquiète pas, t'es pas le premier pervers qui me regarde comme ça !"


translate french matte_7ebe0117:


    d "Hey, et si, et c'est un grand si, j'étais en train de te regarder, pas que je l'étais non, mais si... Est-ce que je serais à blâmer ? Je ne suis qu'un homme après tout"


translate french matte_ce684cf0:


    d "Je suis [name]... Désolé si mon anglais n'est pas parfait mais je suis français et je vais aux US pour m'améliorer..."


translate french matte_5d546338:


    d "Mais vous êtes combien là-dedans ?"


translate french matte_af7767aa:


    julia "Ben si tu comptes Gabriella pour nous accompagner on doit être..."


translate french matte_acc2b90e:


    "Des bruits lourds venant de devant..."


translate french matte_a3b6f8a2:


    julia "C'est mes filles... Je vais voir ce qu'elles sont en train de faire... On se voit plus tard le pervers !"


translate french timide_67d96a22:


    "Si vous regardez les statistiques dans la fenêtre vous verrez que votre Education a obtenu un +1"


translate french timide_f0da4fbd:


    dpense "Elle a l'air sûre d'elle... Je suis à moitié intimidé... Il faut que je prenne confiance en moi... Et puis c'est une américaine..."


translate french suitesteven_9c017fbf:


    "T'es là tranquille... Et tu papotes avec une des filles les plus populaires de l'Université au calme..."


translate french suitesteven_a44e5c43:


    "Ah mais tu savais pas ? Je pensais que t'étais le genre super sûr de lui et tout... Le mec il arrive dans un avion et il s'installe avec Julia, la meilleure milieu de terrain de l'équipe..."


translate french suitesteven_aa318b6f:


    ruby "Sérieux ? Moi aussi ! Bon écoute... Faudrait qu'on se rejoigne avant que tu rentres... Tu vas vraiment avoir besoin d'aide quand tu vas être là-bas !"


translate french suitesteven_9c57e89e:


    ruby "Mouais... Peut être pas encore en fait Cortex... Je vais régler ça ! Bon c'était cool de parler avec toi mais j'ai d'autres trucs à faire... Les filles ont aussi besoin de mes conseils donc... A demain !"


translate french suitesteven_cf866db8:


    "Allez Julia, au moins quelqu'un en aura profité ! Tu peux maintenant remettre ta ceinture de chasteté et retourner au couvent..."


translate french suitesteven_8b314319:


    julia "Haha... Très drôle Madison... C'est sûr que je ne suis pas autant à l'aise que toi avec mon corps... ou avec mes choix de vie..."


translate french suitesteven_58956991:


    julia "Rien rien... Tout le monde sait que tu es une reine de vertu... Il suffit de demander à ton copain..."


translate french suitesteven_534b4206:


    julia "Ah ben non on ne peut pas... Il t'a laissée toute seule avec ta fille et a disparu ! Quel bon choix Madison !"


translate french suitesteven_686615df:


    mad "Okay Grace... Mais dis à la Sainte Vierge de calmer ses nerfs ou d'utiliser un gode pour déstresser avant que j'utilise un des miens dans son putain de cul !"


translate french suitesteven_0207512d:


    julia "Les ploucs, comme tu dis, sont largement plus agréables que toi Madison..."


translate french suitesteven_4a92e9bb:


    mad "Oh oui c'est sûr... Et ils sont même prêts à te montrer à quel point ils sont agréables si tu ouvres bien grand ta bouche..."


translate french suitesteven_0944faa3:


    mad "Allez Julia, arrêtes de jouer à la sainte nitouche avec moi ou alors va remettre ta ceinture de chasteté !"


translate french suitesteven_9be940f7:


    julia "Haha... Très drôle Madison... C'est sûr que je ne suis pas autant à l'aise que toi avec mon corps... ou avec mes choix de vie..."


translate french suitesteven_6834550e:


    julia "Ah ben non on ne peut pas... Il t'a laissée toute seule avec ta fille et a disparu ! Quel bon choix Madison !"


translate french suitesteven_956f0d4b:


    mad "Ne parle pas de ma fille ! Je vais mettre mon poing au fond de ta gorge et tu verras quelle reine de vertu je suis !"


translate french suitesteven_686615df_1:


    mad "Okay Grace... Mais dis à la Sainte Vierge de calmer ses nerfs ou d'utiliser un gode pour déstresser avant que j'utilise un des miens dans son putain de cul !"


translate french filles_a5b7a657:


    grace "Arrête de réagir à ses piques et tout ira bien... Je la connais depuis le jardin d'enfance..."


translate french filles_6cb619bc:


    grace "On vient juste de gagner un match en Europe et vous êtes là à vous battre au lieu de célébrer ça toutes ensemble !"


translate french filles_35bcedfb:


    grace "Bon c'est pas le tout mais je vais aller tester ce Champagne moi... J'ai pas acheté ces bouteilles pendant qu'on était en France pour rien... Faut que je goûte !"


translate french dream_fd67742c:


    ruby "Nan mais t'es dingo ? C'est toi qui m'a fait peur !"


translate french dream_e83ddfad:


    ruby "Bref... On a atterri ! Allez Cortex, c'est le moment d'y aller !"


translate french dream_a75ec2bd:


    ruby "Et n'oublies pas ! Demain matin tu m'attends à l'entrée ! On va conquérir le monde ! Ou juste l'Université en fait... Je sais pas encore... Je vais réfléchir à ça..."



translate french strings:


    old "Look at her [TEMP1]"
    new "La regarder [TEMP1]"


    old "Stay quiet [TEMP2]"
    new "Rester silencieux [TEMP2]"


    old "Grope her [TEMP1]"
    new "L'attraper [TEMP1]"


    old "I'm not a pervert ! [TEMP2]"
    new "Je ne suis pas un pervers ! [TEMP2]"


    old "Yes sure ! [TEMP1]"
    new "Oui bien sûr ! [TEMP1]"


    old "I don't need you, thanks ! [TEMP2]"
    new "J'ai pas besoin de toi, merci ! [TEMP2]"



translate french strings:


    old "Look at her [TEMP1!t]"
    new "La regarder [TEMP1!t]"


    old "Stay quiet [TEMP2!t]"
    new "Rester silencieux [TEMP2!t]"


    old "Grope her [TEMP1!t]"
    new "L'attraper [TEMP1!t]"


    old "I'm not a pervert ! [TEMP2!t]"
    new "Je ne suis pas un pervers ! [TEMP2!t]"


    old "Yes sure ! [TEMP1!t]"
    new "Oui bien sûr ! [TEMP1!t]"


    old "I don't need you, thanks ! [TEMP2!t]"
    new "J'ai pas besoin de toi, merci ! [TEMP2!t]"




translate french dream_ef072154_1:


    julia "Va falloir que je prenne les rennes..."


translate french dream_0234bf95_1:


    julia "Je sais que t'as envie de toucher..."


translate french dream_16bce50e_1:


    julia "Bientôt tu pourras profiter de tout ça..."


translate french dream_e7985afa_1:


    julia "Mais pour l'instant..."


translate french dream_18805abb_1:


    julia "REVEILLE-TOI !!!" with hpunch


translate french suiteavion_5c0e76f8:


    d "Quoi ?"


translate french suiteavion_54f6be08:


    ji "Réveille-toi !"


translate french suiteavion_960aeedf:


    d "WHAAAAAAAAAAAAAAAAAAAAAA..." with vpunch


translate french suiteavion_926f9119:


    ruby "AHHHHHHHHHHHHHHHHHHHHHHHH..." with vpunch


translate french suiteavion_35678e56:


    d "Tu m'as fait peur !!!"


translate french suiteavion_fd67742c:


    ruby "Nan mais t'es pas bien ??? C'est toi qui m'a fait peur !!!"


translate french suiteavion_1523fe20:


    d "..."


translate french suiteavion_e83ddfad:


    ruby "On a atterri ! Allez Cortex, c'est l'heure d'y aller !"


translate french suiteavion_a75ec2bd:


    ruby "Et n'oublies-pas ! Demain matin, attends-moi devant l'entrée ! On va conquérir le monde ! Où peut-être juste l'Université pour l'instant... Faut que j'y réfléchisse..."




translate french avion_a77ac93c:


    ji "Salut?"


translate french avion_6a17aa40:


    d "Oh salut!"


translate french avion_8adf166c:


    ji "Je peux t'aider?"


translate french avion_098df146:


    d "Oh, euh, non! Je regardais juste."


translate french avion_28d35901:


    d "Je crois que c'est mon siège. Je peux m'asseoir?"


translate french avion_ce4cc110:


    ji "Oui bien sûr! Vas-y assieds toi! Ca va être un long vol."


translate french avion_2e54462d:


    ji "Je me suis juste posée là pour prendre un peu l'air et regarder à travers la fenêtre."


translate french avion_b1b5a06e:


    d "Prendre l'air?"


translate french avion_394fe6c3:


    ji "Ouais, y'à une sorte de fête en première classe avec les filles, mais c'est assez bruyant!"


translate french avion_7c12217f:


    "Les choix sont importants dans ce jeu et le personnage principal a des caractéristiques dans 4 branches différentes : B.E.S.T"


translate french avion_6e67c913:


    "BUDDY ou amitié est l'attitude du joueur avec ses amis, cela impacte ses relations avec les autres"


translate french avion_fe1c61dc:


    "EDUCATION est la culture générale du joueur, cela impacte les possibilités de dialogues et les résultats aux examens"


translate french avion_71bf6ca1:


    "SPORT est le niveau athlétique du joueur, requis pour atteindre certains objectifs pendant le jeu"


translate french avion_5aef870f:


    "TEMPERAMENT est la nature du joueur, cela aura un impact sur les actions du joueur envers les autres personnages"


translate french avion_fd4e33a9:


    "Et d'autres seront inaccessibles si vous n'avez pas le minimum requis"


translate french matte_50d78a9e:


    "Ici votre temperament a augmenté."


translate french matte_c2ff206b:


    "Si vous regardez dans la fenêtre des stats vous verrez que Temperament est passé de 0 à 1"


translate french matte_a204a91e:


    "Selon vos choix, différentes statistiques seront impactées."


translate french matte_04c22d84:


    d "OH ! heu... non non merci... désolé je me suis perdu dans mes pensées en te regardant..."


translate french matte_161819b3:


    ji "T'étais en train de me matter?"


translate french matte_33290fa1:


    ji "AHAH... T'inquiète pas tu n'es pas le premier pervert qui me regarde comme ça !"


translate french matte_109f239c:


    d "Hey ! Mais SI, et c'est un gros SI, je te regardais, non pas que je le faisais, est-ce que je serais à blâmer ? Après tout je ne suis qu'un homme."


translate french matte_64dae949:


    d "I'm [name]. Désolé si mon anglais est pas ouf mais je suis français et je vais aux US pour m'améliorer."


translate french matte_974197f5:


    ji "Oh, c'est comme ça ? Donc tu penses que je ne suis pas assez jolie pour toi pour que tu aies envie de me regarder ?"


translate french matte_521b9be8:


    d "Oh, on est même pas encore ensemble et j'ai déjà un surnom ? Je suis pas sûr d'aimer celui-ci mais bon..."


translate french matte_f6d9c954:


    julia "Pas encore ensemble ? Monsieur a pris la confiance."


translate french matte_ef64d92c:


    d "J'essaye ! Bon, qu'est ce qu'une fille comme toi fait dans un jet comme ça ?"


translate french matte_e14ee53b:


    julia "Oh tu ne sais pas ? Au début ce jet était juste pour nous..."


translate french matte_b482344d:


    julia "Mais bon, la société essaie de faire des économies où elle peut donc..."


translate french matte_1c3b9124:


    julia "Des fois, on doit partager nos vols avec des étudiants ou des familles."


translate french matte_76905a7b:


    julia "Pas vraiment un problème pour moi mais d'autres ne sont pas aussi compatissantes."


translate french matte_71c63e4f:


    d "Vous êtes combien?"


translate french matte_00032fb4:


    julia "Ben, si on compte Gabriella, notre coach, il y a..."


translate french matte_76aa842e:


    "Des bruits venant de l'avant"


translate french matte_70a4593d:


    ji "ET VOUS SAVEZ CE QUE CES GARS ONT ESSAYE DE FAIRE ???"


translate french matte_3ddcfdcb:


    d "QUi est-ce?"


translate french matte_a1cea24a:


    julia "C'est mes filles. Je vais voir ce qu'elles font... A plus tard le pervert!"


translate french matte_be32e64a:


    d "Je ne suis pas un pervert!"


translate french matte_83ccf072:


    julia "Excuse moi..."


translate french grope_f3ad0544:


    dpense "Je sais que je ne devrais pas..."


translate french grope_4069971b:


    dpense "Mais je peux pas m'en empêcher..."


translate french grope_25b49ff5:


    julia "OH SI TU EN ES UN!"


translate french grope_e5740a5c:


    dpense "Putain! Elle m'a collé une gifle! J'y crois pas!"


translate french timide_b27c8e81:


    "Votre Education a augmenté."


translate french timide_a204a91e:


    "Selon vos choix, une statistique différente peut être affectée."


translate french timide_b6723f7d:


    dpense "Elle fait très sûre d'elle. Je suis un peu intimidé. Je dois prendre confiance en moi. Elle est américaine alors..."


translate french timide_b7e759f8:


    dpense "Je devrais peut être essayer avec un petit 'Hey! Je viens de France! Et toi?'"


translate french timide_8212f678:


    dpense "Nan c'est pas bon. 'Hey, je m'appelle [name]. Et toi?'"


translate french timide_961931c2:


    dpense "Un peu trop...basique? 'Hey! Where is Bryan? Bryan is in the kitchen!"


translate french timide_ca382aeb:


    dpense "Est ce que je ne devrais pas juste me présenter et demander ce qu'ilse passe en première classe?"


translate french timide_806583b6:


    dpense "Ouais, ça devrait être pas mal, au pire ça fera une ouverture."


translate french timide_e7cb9db9:


    d "Alors... Ravi de te rencontrer..."


translate french timide_70a4593d:


    ji "ET VOUS SAVEZ CE QUE CES GARS ONT ESSAYE DE FAIRE ???"


translate french timide_6ed3c163:


    d "C'était quoi ça?"


translate french timide_adcda054:


    julia "C'est mes filles."


translate french timide_0a12bd65:


    julia "Désolée, je vais voir ce qu'elle font. A plus tard!"


translate french timide_7fe1a0a3:


    d "A plus."


translate french timide_98834053:


    d "Je sais même pas comment elle s'appelle."


translate french steven_f0a46d58:


    dpense "Elle était jolie."


translate french steven_2b5cc8ea:


    "T'as déconné mec!"


translate french steven_79c7d4f9:


    "Ben mon gars, t'es un sacré chanceux!"


translate french suitesteven_29ac5843:


    d "De quoi?"


translate french suitesteven_c74818a4:


    "Tu viens juste de parler à l'une des filles les plus populaires de l'académie."


translate french suitesteven_445516a0:


    d "Populaire? Comment ça?"


translate french suitesteven_2e214d17:


    "Tu ne sais pas? Ah genre je pensais que tu la jouais cool. Genre le gars qui se pose dans l'avion à côté de Julia, notre meilleure milieu de terrain."


translate french suitesteven_a818720e:


    "Tu ne sais rien Jon Snow."


translate french suitesteven_12f41864:


    d "Je ne... Quoi?"


translate french suitesteven_14baaefe:


    "Ben... Game of thrones quand même ! Tu vas pas me dire que tu connais pas ? Daenerys Targaryen, Jamie, les dragons, l'inceste...."


translate french suitesteven_e8068e8a:


    d "Je connais Game of Thrones."


translate french suitesteven_b61caa41:


    "Bon ben c'est bon alors! Je suis Ruby, et toi?"


translate french suitesteven_1604c1be:


    d "[name]."


translate french suitesteven_e1f07e97:


    ruby "Oh, j'aime bien, c'est mignon. Mieux que les gens qui appellent leur fille Clitorine, n'est-ce pas?"


translate french suitesteven_30c66acb:


    ruby "Y'à des gens je te jure, ils donnent de ces noms. Mais pas le tien non! Le tien j'aime bien! Bon, tu vas où comme ça?"


translate french suitesteven_8d82ba13:


    d "Premier jour à l'académie demain..."


translate french suitesteven_94f6ab85:


    ruby "AH ouais? Moi aussi! Alors écoute ce qu'on va faire! On se rejoint à l'entrée! Il va te falloir un guide pour là-bas!"


translate french suitesteven_e3b20b7b:


    d "Pourquoi?"


translate french suitesteven_e93176d9:


    ruby "C'est la jungle !!!! Tu vas voir, y'à des filles partout qui attendent dans le noir, certaines avec des griffes acérées prêtes à tout pour la victoire et la gloire !"


translate french suitesteven_b4c5be94:


    ruby "Et tu sais ce que donne la gloire?"


translate french suitesteven_c6f1becc:


    ruby "Tu ne sais pas. Moi je sais. La gloire veut dire les FILLES! Tu seras l'élu si tu réussis! Imagine les filles à tes pieds ! Et qu'est ce que veut dire plus de gloire?"


translate french suitesteven_07bd820b:


    d "Plus de filles?"


translate french suitesteven_60fa4a54:


    ruby "T'es intelligent toi, non ? Je vais être ta partenaire ! Non... Je vais être ton Cupidon ! Je suis Minus et tu es Cortex okay ? Alors es-tu prêt à conquérir le monde ?"


translate french suitesteven_1e83bfb6:


    ruby "Okay... bon peut être pas encore Cortex... Je vais régler ça ! Bon c'est super sympa de discuter avec toi et tout et tout... mais les autres filles attendent mes services alors à plus tard !"


translate french suitesteven_b95efa92_1:


    d "Je..."


translate french suitesteven_b53beaf3:


    ruby "Et tu m'attend avant de rentrer dans l'arène!"


translate french suitesteven_dbdea2d2:


    dpense "Elles sont toutes comme ça?"


translate french suitesteven_1f5828f4:


    d "Elle m'a fatiguée."


translate french suitesteven_c0b26c1f:


    "C'est notre petite Julia qui revient de son passage chez les ploucs?"


translate french suitesteven_ece3d305:


    "Elle parlait à un gars. J'espère qu'il s'est pas fait de fausses idées..."


translate french suitesteven_1781b603:


    julia "Ouais, ce gars m'a choppé le cul juste quand je suis passée devant lui !"


translate french suitesteven_d5c9de16:


    "QUOIIIIIII??!" with hpunch


translate french suitesteven_dad3e066:


    "Allez Julia, au moins quelqu'un en aura profité ! Tu peux maintenant remettre ta ceinture de chasteté et retourner au couvent..."


translate french suitesteven_ec0ad1d8:


    julia "Haha... Très drôle Madison... C'est sûr que je ne suis pas autant à l'aise que toi avec mon corps... ou avec mes choix de vie..."


translate french suitesteven_060f387e:


    mad "Qu'est ce que tu veux dire?"


translate french suitesteven_b9a169a9:


    julia "Rien rien... Tout le monde sait que tu es une reine de vertu... Il suffit de demander à ton copain..."


translate french suitesteven_c6e5105b:


    julia "Ah ben non on ne peut pas... Il t'a laissée toute seule avec ta fille et a disparu ! Quel bon choix Madison !"


translate french suitesteven_018ba193:


    mad "Ne parle pas de ma fille ! Je vais mettre mon poing au fond de ta gorge et tu verras quelle reine de vertu je suis !"


translate french suitesteven_b468c864:


    "Les filles ! Arrêtez ça de suite!"


translate french suitesteven_80adbe6d:


    mad "Okay Grace... Mais dis à la Sainte Vierge de calmer ses nerfs ou d'utiliser un gode pour déstresser avant que j'utilise un des miens dans son putain de cul !"


translate french suitesteven_6e1984a1:


    mad "Je me casse!" with vpunch


translate french suitesteven_da1598b9:


    ruby "Maddie, calme-toi!"


translate french suitesteven_903e5d8e:


    julia "Les ploucs, comme tu dis, sont largement plus agréables que toi Madison..."


translate french suitesteven_a1560e5c:


    mad "Oh oui c'est sûr... Et ils sont même prêts à te montrer à quel point ils sont agréables si tu ouvres bien grand ta bouche..."


translate french suitesteven_b3c31478:


    mad "Allez Julia, arrêtes de jouer à la sainte nitouche avec moi ou alors va remettre ta ceinture de chasteté !"


translate french suitesteven_ec0ad1d8_1:


    julia "Haha... Très drôle Madison... C'est sûr que je ne suis pas autant à l'aise que toi avec mon corps... ou avec mes choix de vie..."


translate french suitesteven_060f387e_1:


    mad "Qu'est ce que tu veux dire?"


translate french suitesteven_b9a169a9_1:


    julia "Rien rien... Tout le monde sait que tu es une reine de vertu... Il suffit de demander à ton copain..."


translate french suitesteven_c6e5105b_1:


    julia "Ah ben non on ne peut pas... Il t'a laissée toute seule avec ta fille et a disparu ! Quel bon choix Madison !"


translate french suitesteven_018ba193_1:


    mad "Ne parle pas de ma fille ! Je vais mettre mon poing au fond de ta gorge et tu verras quelle reine de vertu je suis !"


translate french suitesteven_b468c864_1:


    "Les filles ! Arrêtez ça de suite!"


translate french suitesteven_80adbe6d_1:


    mad "Okay Grace... Mais dis à la Sainte Vierge de calmer ses nerfs ou d'utiliser un gode pour déstresser avant que j'utilise un des miens dans son putain de cul !"


translate french suitesteven_6e1984a1_1:


    mad "Je me casse!" with vpunch


translate french suitesteven_da1598b9_1:


    ruby "Maddie, calme-toi!"


translate french filles_1d7d4d72:


    grace "Putain les filles, c'est un vol de 8 heures .... Faites un effort pour vous entendre..."


translate french filles_c1b1f90f:


    grace "D'accord Ruby, vas y pendant que je parle à Julia."


translate french filles_9af21f39:


    grace "Julia... Pourquoi tu rentres dans son jeu ? Tu sais comment elle est !"


translate french filles_f4d64a4a:


    julia "Ouais si vulgaire et extrêmement désagréable..."


translate french filles_2022fcdc:


    grace "Ne répond pas à ses attaques et tout se passera bien... je la connais depuis la maternelle."


translate french filles_9328fe6e:


    grace "Tu sais qu'elle a vécu des choses lourdes... et puis on est une équipe !"


translate french filles_da9df0ba:


    grace "On vient de gagner le match de gala en Europe hier et aujourd'hui vous êtes les plus grandes ennemies au lieu de fêter ça toutes ensemble !"


translate french filles_6f2a6535:


    julia "Je sais, Capitaine ! Mais elle a ce pouvoir sur moi... Elle me fait démarrer au quart de tour et je rage instantanément !"


translate french filles_6b09a32f:


    julia "Si je reste calme, c'est pour l'équipe, pour vous les filles parce que vous êtes vraiment importantes pour moi..."


translate french filles_5f52d6a5:


    grace "Ouais ben reste comme ça et c'est parfait..."


translate french filles_1e3fbdab:


    grace "Bon je vais aller boire une coupe de champagne... J'ai pas acheté ces bouteilles quand on est passées en France pour rien... je dois goûter !"


translate french filles_239ecae8:


    julia "D'accord. A tout à l'heure..."


translate french dream_7853e24a:


    julia "Je suis un peu déçue..."


translate french dream_374d0074:


    julia "Je vais devoir prendre les devants..."


translate french dream_bc9425a5:


    julia "Je sais que tu as envie de toucher..."


translate french dream_f4bdb854:


    julia "Bientôt tu vas pouvoir profiter de tout ça..."


translate french dream_19554152:


    julia "REVEILLE-TOI !" with hpunch


translate french dream_374d0074_1:


    julia "Je vais devoir prendre les devants..."


translate french dream_bc9425a5_1:


    julia "Je sais que tu as envie de toucher..."


translate french dream_f4bdb854_1:


    julia "Bientôt tu vas pouvoir profiter de tout ça..."


translate french dream_19554152_1:


    julia "REVEILLE-TOI !" with hpunch


translate french suiteavion_29ac5843:


    d "Hein ?"


translate french suiteavion_332c64eb:


    ji "Réveille-toi !"


translate french suiteavion_d98b07ec:


    d "Tu m'as fait peur !"


translate french suiteavion_58043dd2:


    ruby "Nan mais t'es fou ! C'est toi qui m'a fait peur !"


translate french suiteavion_82a4a47b:


    ruby "On a aterri ! Allez Cortex, faut y aller !"


translate french suiteavion_22f7922c:


    ruby "Et n'oublies pas ! Demain matin, tu m'attends à l'entrée ! On va conquérir le monde ! Ou peut être juste l'Université.... Faut que je me penche sur la question ..."

translate french strings:


    old "I'm not a pervert! [TEMP2!t]"
    new "Je ne suis pas un pervert! [TEMP2!t]"


    old "Yeah, sure! [TEMP1!t]"
    new "Oui, bien sûr![TEMP1!t]"


    old "I don't need your help, thanks anyways! [TEMP2!t]"
    new "J'ai pas besoin de toi mais merci![TEMP2!t]"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
