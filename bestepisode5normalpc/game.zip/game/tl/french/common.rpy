

translate french strings:


    old "Self-voicing disabled."
    new ""


    old "Clipboard voicing enabled. "
    new ""


    old "Self-voicing enabled. "
    new ""


    old "bar"
    new ""


    old "selected"
    new ""


    old "viewport"
    new ""


    old "horizontal scroll"
    new ""


    old "vertical scroll"
    new ""


    old "activate"
    new ""


    old "deactivate"
    new ""


    old "increase"
    new ""


    old "decrease"
    new ""


    old "Font Override"
    new ""


    old "Default"
    new ""


    old "DejaVu Sans"
    new ""


    old "Opendyslexic"
    new ""


    old "Text Size Scaling"
    new ""


    old "Reset"
    new ""


    old "Line Spacing Scaling"
    new ""


    old "High Contrast Text"
    new ""


    old "Enable"
    new ""


    old "Disable"
    new ""


    old "Self-Voicing"
    new ""


    old "Off"
    new ""


    old "Text-to-speech"
    new ""


    old "Clipboard"
    new ""


    old "Debug"
    new ""


    old "Self-Voicing Volume Drop"
    new ""


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new ""


    old "{#weekday}Monday"
    new ""


    old "{#weekday}Tuesday"
    new ""


    old "{#weekday}Wednesday"
    new ""


    old "{#weekday}Thursday"
    new ""


    old "{#weekday}Friday"
    new ""


    old "{#weekday}Saturday"
    new ""


    old "{#weekday}Sunday"
    new ""


    old "{#weekday_short}Mon"
    new ""


    old "{#weekday_short}Tue"
    new ""


    old "{#weekday_short}Wed"
    new ""


    old "{#weekday_short}Thu"
    new ""


    old "{#weekday_short}Fri"
    new ""


    old "{#weekday_short}Sat"
    new ""


    old "{#weekday_short}Sun"
    new ""


    old "{#month}January"
    new ""


    old "{#month}February"
    new ""


    old "{#month}March"
    new ""


    old "{#month}April"
    new ""


    old "{#month}May"
    new ""


    old "{#month}June"
    new ""


    old "{#month}July"
    new ""


    old "{#month}August"
    new ""


    old "{#month}September"
    new ""


    old "{#month}October"
    new ""


    old "{#month}November"
    new ""


    old "{#month}December"
    new ""


    old "{#month_short}Jan"
    new ""


    old "{#month_short}Feb"
    new ""


    old "{#month_short}Mar"
    new ""


    old "{#month_short}Apr"
    new ""


    old "{#month_short}May"
    new ""


    old "{#month_short}Jun"
    new ""


    old "{#month_short}Jul"
    new ""


    old "{#month_short}Aug"
    new ""


    old "{#month_short}Sep"
    new ""


    old "{#month_short}Oct"
    new ""


    old "{#month_short}Nov"
    new ""


    old "{#month_short}Dec"
    new ""


    old "%b %d, %H:%M"
    new ""


    old "Save slot %s: [text]"
    new ""


    old "Load slot %s: [text]"
    new ""


    old "Delete slot [text]"
    new ""


    old "File page auto"
    new ""


    old "File page quick"
    new ""


    old "File page [text]"
    new ""


    old "Next file page."
    new ""


    old "Previous file page."
    new ""


    old "Quick save complete."
    new ""


    old "Quick save."
    new "Sauvegarde rapide"


    old "Quick load."
    new "Chargement rapide"


    old "Language [text]"
    new "Langue"


    old "Open [text] directory."
    new ""


    old "The interactive director is not enabled here."
    new ""


    old "⬆"
    new ""


    old "⬇"
    new ""


    old "Done"
    new ""


    old "(statement)"
    new ""


    old "(tag)"
    new ""


    old "(attributes)"
    new ""


    old "(transform)"
    new ""


    old "(transition)"
    new ""


    old "(channel)"
    new ""


    old "(filename)"
    new ""


    old "Change"
    new "Changer"


    old "Add"
    new "Ajouter"


    old "Cancel"
    new "Annuler"


    old "Remove"
    new "Supprimer"


    old "Statement:"
    new ""


    old "Tag:"
    new ""


    old "Attributes:"
    new ""


    old "Transforms:"
    new ""


    old "Behind:"
    new ""


    old "Transition:"
    new ""


    old "Channel:"
    new ""


    old "Audio Filename:"
    new ""


    old "Are you sure?"
    new "Etes vous sûr?"


    old "Are you sure you want to delete this save?"
    new "Etes vous sûr de vouloir supprimer cette sauvegarde ?"


    old "Are you sure you want to overwrite your save?"
    new "Etes vous sûr de vouloir écraser cette sauvegarde ?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Recharger vous fera perdre toute progression en cours. \nEtes vous sûr de vouloir faire cela ?"


    old "Are you sure you want to quit?"
    new "Etes vous sûr de vouloir quitter ?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Etes vous sûr de vouloir retourner au menu principal ?\nCela vous fera perdre toute progression non sauvegardée."


    old "Are you sure you want to end the replay?"
    new "Voulez vous quitter le replay ?"


    old "Are you sure you want to begin skipping?"
    new ""


    old "Are you sure you want to skip to the next choice?"
    new ""


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new ""


    old "Failed to save screenshot as %s."
    new "Failed to save screenshot as %s."


    old "Saved screenshot as %s."
    new "Saved screenshot as %s."


    old "Skip Mode"
    new ""


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new ""


    old "display"
    new ""


    old "transitions"
    new ""


    old "skip transitions"
    new ""


    old "video sprites"
    new ""


    old "show empty window"
    new ""


    old "text speed"
    new ""


    old "joystick"
    new ""


    old "joystick..."
    new ""


    old "skip"
    new ""


    old "skip unseen [text]"
    new ""


    old "skip unseen text"
    new ""


    old "begin skipping"
    new ""


    old "after choices"
    new ""


    old "skip after choices"
    new ""


    old "auto-forward time"
    new ""


    old "auto-forward"
    new ""


    old "Auto forward"
    new ""


    old "auto-forward after click"
    new ""


    old "automatic move"
    new ""


    old "wait for voice"
    new ""


    old "voice sustain"
    new ""


    old "self voicing"
    new ""


    old "self voicing volume drop"
    new ""


    old "clipboard voicing"
    new ""


    old "debug voicing"
    new ""


    old "emphasize audio"
    new ""


    old "rollback side"
    new ""


    old "gl powersave"
    new ""


    old "gl framerate"
    new ""


    old "gl tearing"
    new ""


    old "font transform"
    new ""


    old "font size"
    new ""


    old "font line spacing"
    new ""


    old "system cursor"
    new ""


    old "renderer menu"
    new ""


    old "accessibility menu"
    new ""


    old "high contrast text"
    new ""


    old "audio when minimized"
    new ""


    old "main volume"
    new "Volume général"


    old "music volume"
    new "Volume des musiques"


    old "sound volume"
    new "Volume des sons"


    old "voice volume"
    new "Volume des voix"


    old "mute main"
    new "Mute principal"


    old "mute music"
    new "Mute Musique"


    old "mute sound"
    new "Mute sons"


    old "mute voice"
    new "Mute voix"


    old "mute all"
    new "Mute tout"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new ""


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new ""


    old "Self-voicing enabled. Press 'v' to disable."
    new ""


    old "Empty Slot."
    new ""


    old "Previous"
    new "Précédent"


    old "Next"
    new "Suivant"


    old "Joystick Mapping"
    new ""


    old "Developer Menu"
    new ""


    old "Interactive Director (D)"
    new ""


    old "Reload Game (Shift+R)"
    new ""


    old "Console (Shift+O)"
    new ""


    old "Variable Viewer"
    new ""


    old "Image Location Picker"
    new ""


    old "Filename List"
    new ""


    old "Show Image Load Log (F4)"
    new ""


    old "Hide Image Load Log (F4)"
    new ""


    old "Image Attributes"
    new ""


    old "[name] [attributes] (hidden)"
    new ""


    old "[name] [attributes]"
    new ""


    old "Nothing to inspect."
    new ""


    old "Hide deleted"
    new ""


    old "Show deleted"
    new ""


    old "Return to the developer menu"
    new ""


    old "Rectangle: %r"
    new ""


    old "Mouse position: %r"
    new ""


    old "Right-click or escape to quit."
    new ""


    old "Rectangle copied to clipboard."
    new ""


    old "Position copied to clipboard."
    new ""


    old "Type to filter: "
    new ""


    old "Textures: [tex_count] ([tex_size_mb:.1f] MB)"
    new ""


    old "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"
    new ""


    old "✔ "
    new ""


    old "✘ "
    new ""


    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new ""


    old "Displayable Inspector"
    new ""


    old "Size"
    new ""


    old "Style"
    new ""


    old "Location"
    new ""


    old "Inspecting Styles of [displayable_name!q]"
    new ""


    old "displayable:"
    new ""


    old "        (no properties affect the displayable)"
    new ""


    old "        (default properties omitted)"
    new ""


    old "<repr() failed>"
    new ""


    old "a"
    new ""


    old "q"
    new ""


    old "Contacting App Store\nPlease Wait..."
    new ""


    old "The Ren'Py Updater is not supported on mobile devices."
    new ""


    old "An error is being simulated."
    new ""


    old "Either this project does not support updating, or the update status file was deleted."
    new ""


    old "This account does not have permission to perform an update."
    new ""


    old "This account does not have permission to write the update log."
    new ""


    old "Could not verify update signature."
    new ""


    old "The update file was not downloaded."
    new ""


    old "The update file does not have the correct digest - it may have been corrupted."
    new ""


    old "While unpacking {}, unknown type {}."
    new ""


    old "Updater"
    new ""


    old "An error has occured:"
    new ""


    old "Checking for updates."
    new "Recherche de mises à jour."


    old "This program is up to date."
    new "Ce programme est à jour."


    old "[u.version] is available. Do you want to install it?"
    new "[u.version] est disponible. Voulez-vous l'installer?"


    old "Preparing to download the updates."
    new "Prépare le téléchargement de la mise à jour."


    old "Downloading the updates."
    new "Télécharge la mise à jour."


    old "Unpacking the updates."
    new "Installe la mise à jour."


    old "Finishing up."
    new "Terminé."


    old "The updates have been installed. The program will restart."
    new "La mise à jour a été installée. Le programme va redémarrer."


    old "The updates have been installed."
    new "La mise à jour a été installée."


    old "The updates were cancelled."
    new "La mise à jour a été annulée."


    old "Proceed"
    new ""


    old "Image [index] of [count] locked."
    new ""


    old "prev"
    new "préc"


    old "next"
    new "suivant"


    old "slideshow"
    new ""


    old "return"
    new "retour"


    old "Renderer"
    new ""


    old "Automatically Choose"
    new ""


    old "Force GL Renderer"
    new ""


    old "Force ANGLE Renderer"
    new ""


    old "Force GLES Renderer"
    new ""


    old "Force GL2 Renderer"
    new ""


    old "Force ANGLE2 Renderer"
    new ""


    old "Force GLES2 Renderer"
    new ""


    old "Enable (No Blocklist)"
    new ""


    old "Powersave"
    new ""


    old "Framerate"
    new ""


    old "Screen"
    new ""


    old "60"
    new ""


    old "30"
    new ""


    old "Tearing"
    new ""


    old "Changes will take effect the next time this program is run."
    new "Les changements prendront effet la prochaine fois que le programme démarrera."


    old "Performance Warning"
    new ""


    old "This computer is using software rendering."
    new ""


    old "This game requires use of GL2 that can't be initialised."
    new ""


    old "This computer has a problem displaying graphics: [problem]."
    new ""


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new ""


    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new ""


    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new ""


    old "Continue, Show this warning again"
    new ""


    old "Continue, Don't show warning again"
    new ""


    old "Change render options"
    new ""


    old "Select Gamepad to Calibrate"
    new ""


    old "No Gamepads Available"
    new ""


    old "Calibrating [name] ([i]/[total])"
    new ""


    old "Press or move the '[control!s]' [kind]."
    new ""


    old "Skip (A)"
    new ""


    old "Back (B)"
    new ""


    old "Open"
    new ""


    old "Opens the traceback.txt file in a text editor."
    new ""


    old "Copy BBCode"
    new ""


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new ""


    old "Copy Markdown"
    new ""


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new ""


    old "An exception has occurred."
    new ""


    old "Rollback"
    new ""


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new ""


    old "Ignore"
    new ""


    old "Ignores the exception, allowing you to continue."
    new ""


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new ""


    old "Reload"
    new ""


    old "Reloads the game from disk, saving and restoring game state if possible."
    new ""


    old "Console"
    new ""


    old "Opens a console to allow debugging the problem."
    new ""


    old "Quits the game."
    new ""


    old "Parsing the script failed."
    new ""



translate french strings:


    old "Click to toggle attribute, right click to toggle negative attribute."
    new ""


    old "Click to set transform, right click to add to transform list."
    new ""


    old "Click to set, right click to add to behind list."
    new ""


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new ""


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new ""


    old "audio when unfocused"
    new ""


    old "web cache preload"
    new ""


    old "voice after game menu"
    new ""


    old "Speech Bubble Editor"
    new ""


    old "(hide)"
    new ""


    old "Sync downloaded."
    new ""


    old "Could not connect to the Ren'Py Sync server."
    new ""


    old "The Ren'Py Sync server timed out."
    new ""


    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new ""


    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new ""


    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new ""


    old "The sync ID is not in the correct format."
    new ""


    old "The sync could not be decrypted."
    new ""


    old "The sync belongs to a different game."
    new ""


    old "The sync contains a file with an invalid name."
    new ""


    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new ""


    old "Enter Sync ID"
    new ""


    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new ""


    old "Sync Success"
    new ""


    old "The Sync ID is:"
    new ""


    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new ""


    old "Sync Error"
    new ""



translate french strings:


    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new ""


    old "Customize director.transforms to add more transforms."
    new ""


    old "Click to set."
    new ""


    old "Customize director.transitions to add more transitions."
    new ""


    old "Customize director.audio_channels to add more channels."
    new ""


    old "Are you sure you want to continue where you left off?"
    new ""


    old "self voicing enable"
    new ""


    old "self voicing disable"
    new ""


    old "clipboard voicing enable"
    new ""


    old "clipboard voicing disable"
    new ""


    old "debug voicing enable"
    new ""


    old "debug voicing disable"
    new ""


    old "restore window position"
    new ""


    old "reset"
    new ""


    old "(clear retained bubbles)"
    new ""


    old "No update methods found."
    new ""


    old "Could not download file list: "
    new ""


    old "File list digest does not match."
    new ""


    old "Preparing to download the game data."
    new ""


    old "Downloading the game data."
    new ""


    old "The game data has been downloaded."
    new ""


    old "An error occured when trying to download game data:"
    new ""


    old "This game cannot be run until the game data has been downloaded."
    new ""


    old "Retry"
    new ""
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
