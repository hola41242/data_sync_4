

translate portuguese strings:


    old "You have entered the B.E.S.T Game"
    new "Você entrou no M.E.L.H.O.R (B.E.S.T) jogo"


    old "Start the game"
    new "Iniciar o jogo"


    old "What an ass!"
    new "Que bunda!"


    old "Grope Julia"
    new "Apalpe a Julia"


    old "Cotton Eye Joe !"
    new "Cotton Eye Joe!"


    old "Don't touch Julia"
    new "Não toque na Julia"


    old "Catch them all!"
    new "Pegue todos elas!"


    old "Catch Grace"
    new "Pegue a Grace"


    old "Life in redhead !"
    new "Vida de ruiva!"


    old "You've put Grace on her bed"
    new "Você colocou a Grace na cama dela"


    old "Show must go on !"
    new "O show deve continuar!"


    old "Finish the Prologue"
    new "Termine o Prólogo"


    old "Pinky and the Braid!"
    new "Pinky e a Trança"


    old "Play the Minus and Cortex game"
    new "Jogue o jogo do Minus e Cortex"


    old "You are the winner!"
    new "Você é o vencedor!"


    old "Finish First with Madison ?"
    new "Termine em primeiro com a Madison?"


    old "You deserve it!"
    new "Você merece!"


    old "Accept the reward"
    new "Aceite a recompensa"


    old "You're not first meh!"
    new "Você não é o primeiro, meh!"


    old "Accept the Special Reward"
    new "Aceite a Recompensa Especial"


    old "First !!!"
    new "Primeiro!!!"


    old "Finish the First Episode"
    new "Termine o Primeiro Episódio"


    old "Outstanding!"
    new "Excepcional!"


    old "Get all achievements."
    new "Obtenha todas as conquistas."


    old "Victory !!!"
    new "Vitória!!!"


    old "Win versus Grace"
    new "Vença contra a Grace"


    old "Cheater !!!"
    new "Trapaceiro!!!"


    old "Cheat versus Grace"
    new "Trapaceie contra a Grace"


    old "Day of Defeat !!!"
    new "Dia da Derrota!!!"


    old "You let Grace win... Right ?"
    new "Você deixou a Grace ganhar... Certo?"


    old "Evolution !!!"
    new "Evolução!!!"


    old "From Squirtle to Squirter"
    new "De Squirtle a Squirter"


    old "Her hero!!!"
    new "O herói dela!!!"


    old "You're Ruby's Hero..."
    new "Você é o herói da Ruby..."


    old "Hat Trick !!!"
    new "Truque do chápeu!!!"


    old "All for Madison !"
    new "Tudo pela Madison!"


    old "Harem Vibes!!!"
    new "Vibes de Harém!!!"


    old "Women likes you..."
    new "As mulheres gostam de você..."


    old "First Kiss!!!"
    new "Primeiro Beijo!!!"


    old "Grace for ever !"
    new "Grace para sempre!"


    old "Of course!!!"
    new "Claro!!!"


    old "Madison..."
    new "Madison..."


    old "Just the Beginning!"
    new "Apenas o começo!"


    old "Finish the Second Episode"
    new "Termine o Segundo Episódio"


translate portuguese strings:


    old "You tried..."
    new "Você tentou..."


    old "Meh..."
    new "Meh..."


    old "You're a genius!!!"
    new "Você é um gênio!!!"


    old "But unknown..."
    new "Mas desconhecido..."


    old "Milfs are life!!!"
    new "Milfs são vida!!!"


    old "Better with experience..."
    new "Melhor com experiência..."


translate portuguese strings:


    old "Like a virgin!"
    new "Virgem!"


    old "Touch for the very first time..."
    new "Toque pela primeira vez..."


    old "You switched!"
    new "Você trocou!"


    old "From Blue to Red..."
    new "Da Azul a Vermelha..."


    old "Road to Victory!"
    new "Caminho para a Vitória!"


    old "Finish the Third Episode"
    new "Terminar o terceiro episódio"


translate portuguese strings:


    old "Pet's Friend"
    new "Amigo dos Animais"


    old "Mewww..."
    new "Mewww..."


    old "Opportunity Missed"
    new "Oportunidade Perdida"


    old "You were on the right track..."
    new "Você estava no caminho certo..."


    old "You're the BEST!"
    new "Você é o MELHOR!"


    old "A Star is born..."
    new "Uma Estrela nasce..."


    old "Madison is the BEST!"
    new "Madison é a MELHOR!"


    old "Ally or enemy???"
    new "Aliado ou inimigo???"


    old "Man of the match!"
    new "Homem da partida!"


    old "Play it like Beckham!"
    new "Jogue como Beckham!"


translate portuguese strings:


    old "You finished Episode 4!"
    new "Você terminou o Episódio 4!"


    old "RUBYYYYYYYY!"
    new "RUBYYYYYYYY!"



translate portuguese strings:


    old "Milfy City!"
    new "Cidades das Milfs!"


    old "You like it with experience"
    new "Você gosta com experiência"


    old "You finished Episode 5!"
    new "Você terminou o Episódio 5!"


    old "Elise?"
    new "Elise?"


translate portuguese strings:


    old "Sacrifice!"
    new "Sacrifício!"


    old "She won't let you go..."
    new "Ela não vai te deixar ir..."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
