

translate portuguese strings:


    old "Achievements | {:01d}/{}"
    new "Conquistas | {:01d}/{}"


    old "Hidden Achievement"
    new "Conquista Escondida"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
