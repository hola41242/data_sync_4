





define config.menu_include_disabled = True
define flash = Fade(0.1, 0.0, 0.5, color="#fff")
image movie = Movie(size=(1920, 1080), xpos=0, ypos=0, xanchor=0, yanchor=0)
image introep41 = Movie(play="images/animation/introep41.webm",size=(450,800),xpos=0, ypos=0, xanchor=0, yanchor=0, loop=False)
image introep42 = Movie(play="images/animation/introep42.webm",size=(450, 800),yalign=0.1, loop=False)
image juliagrope moving:
    "images/imagefin/juliagrope.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.1 yalign 0.10 rotate -10

image blueacademy moving:
    "images/imagefin/blueacademy.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.1 yalign 0.40 rotate 10

image redacademy moving:
    "images/imagefin/redacademy.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.1 yalign 0.40 rotate 10

image madprem moving:
    "images/imagefin/madprem.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.1 yalign 0.70 rotate -10

image bluejob moving:
    "images/imagefin/bluejob.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.9 yalign 0.1 rotate 10

image redkiss moving:
    "images/imagefin/redkiss.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.9 yalign 0.1 rotate 10

image bluepool moving:
    "images/imagefin/bluepool.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.9 yalign 0.40 rotate -10

image pool moving:
    "images/imagefin/pool.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.1 yalign 0.90 rotate 10

image juliaphone moving:
    "images/imagefin/juliatexto.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.9 yalign 0.70 rotate 10

image gracekiss moving:
    "images/imagefin/gracekiss.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.9 yalign 0.90 rotate -10

image madishower moving:
    "images/imagefin/madishower.jpg"
    xalign 0.5
    yalign 0.9
    linear 1.0 xalign 0.9 yalign 0.40 rotate -10


default name = _("You")
define d = Character("[name]", color="#3a46ec")
define dpense = Character("[name]", color="#3a46ec", what_italic=True)
define s = Character('Steven', color="#219b21", what_color="#faf5f9")
define ji = Character('???',color="#642fa8", what_color="#faf5f9")
define cr = Character('Creators',color="#f3eded", what_color="#fcfafb", what_italic=True)
define julia = Character('Julia',color="#911696", what_color="#f8f8f8")
define mad = Character('Madison',color="#c20e0e", what_color="#f8f8f8")
define grace = Character('Grace',color="#b7d142", what_color="#f8f8f8")
define ruby = Character('Ruby',color="#a11667", what_color="#f8f8f8")
define drew = Character('Mrs Drew',color="#471515", what_color="#f8f8f8")
define orushi = Character('Mr. Orushi', color="#0f220f", what_color="#f8f8f8")
define rufus = Character('Mr. Rufus', color="#a55a1d", what_color="#f8f8f8")
define beth = Character('Elizabeth',color="#c20e0e", what_color="#f8f8f8")
define sofia = Character('Sofia',color="#642fa8", what_color="#faf5f9")
define emerick = Character('Emerick', color="#219b21", what_color="#faf5f9")
define erin = Character('Erin',color="#c20e0e", what_color="#f8f8f8")
define cha = Character('Charlotte',color="#f13b3b", what_color="#f8f8f8")
define cassie = Character('Cassie',color="#f13bb4", what_color="#f8f8f8")
define ted = Character('Ted',color="#5c3bf1", what_color="#f8f8f8")
define gaby = Character('Gabriella',color="#a11667", what_color="#f8f8f8")
define eli = Character('Elise',color="#a11667", what_color="#f8f8f8")
define hec = Character('Hector',color="#5c3bf1", what_color="#f8f8f8")
define kira = Character('Kira',color="#c20e0e", what_color="#f8f8f8")
define mac = Character('Mac',color="#5c3bf1", what_color="#f8f8f8")
define ben = Character('Ben',color="#5c3bf1", what_color="#f8f8f8")
define carmen = Character('Carmen',color="#c20e0e", what_color="#f8f8f8")
define charles = Character('Charles',color="#5c3bf1", what_color="#f8f8f8")
define marc = Character('Marc',color="#5c3bf1", what_color="#f8f8f8")
define evelyn = Character('Evelyn',color="#c20e0e", what_color="#f8f8f8")


default Buddy = 0
default Education = 0
default Sport = 0
default Temperament = 0
default Rank = 90

default persistent.trailerseen = False
default persistent.rufus1 = False
default persistent.rufus2 = False
default persistent.rufus3 = False
default persistent.rufus4 = False
default persistent.rufus5 = False
default persistent.rufus6 = False
default persistent.rufus7 = False
default persistent.rufus8 = False
default persistent.rufus9 = False
default persistent.rufus10 = False
default persistent.rufus11 = False
default persistent.rufus12 = False
default persistent.rufus13 = False
default persistent.rufus14 = False
default persistent.rufus15 = False
default persistent.rufusgame = 0
default persistent.streaming = False

default in_mini_game = False
label saving(savable=True):
    if savable:
        python:
            _autosave = True
            _game_menu_screen = "save"
            in_mini_game = False       
    else:
        python:
            _autosave = False
            _game_menu_screen = "preferences" 
            in_mini_game = True
    return




init python:
    import math
    def steam_buy():
        if achievement.steam is not None and achievement.steam.is_overlay_enabled():
            achievement.steam.activate_overlay_to_store(2722810, achievement.steam.STORE_ADD_TO_CART_AND_SHOW)
        else:
            renpy.run(OpenURL("https://store.steampowered.com/app/2722810/#game_area_purchase"))

    def steam_page():
        if achievement.steam is not None and achievement.steam.is_overlay_enabled():
            achievement.steam.activate_overlay_to_store(2722810, achievement.steam.STORE_NONE)
        else:
            renpy.run(OpenURL("https://store.steampowered.com/app/2722810/"))

    def steam_buy2():
        if achievement.steam is not None and achievement.steam.is_overlay_enabled():
            achievement.steam.activate_overlay_to_store(3468530, achievement.steam.STORE_ADD_TO_CART_AND_SHOW)
        else:
            renpy.run(OpenURL("https://store.steampowered.com/app/3468530/#game_area_purchase"))

    def steam_page2():
        if achievement.steam is not None and achievement.steam.is_overlay_enabled():
            achievement.steam.activate_overlay_to_store(3468530, achievement.steam.STORE_NONE)
        else:
            renpy.run(OpenURL("https://store.steampowered.com/app/3468530/"))


label splashscreen:
    scene warning
    show text _ ("Press click to continue") at center
    pause 10      
    scene black
    with fade
    pause 1
    if not persistent.agree:
        call screen screen_language
    else:
        return
    scene black
    with fade
    $ preferences.set_volume("music", 0.25)
    $ renpy.movie_cutscene("images/fonds/logoD.webm", stop_music=False)
    pause 2










    return

init -3 python:
    persistent.patch_installed = False
init -1 python:
    if persistent.patch_installed and not persistent.patch_first_time:
        persistent.patch_enabled = True
        persistent.patch_first_time = True
    elif not persistent.patch_installed:
        persistent.patch_first_time = False
        persistent.patch_enabled = False

default persistent.agree = False


label before_main_menu:

    if not persistent.agree:
        play music "musique/NovaNoma-Gaia.mp3" volume 1
        pause 2
        scene pres
        with fade
        ji "Hello handsome! Are you lost?"
        pause 1
        scene pres2
        with vpunch
        ji "My eyes are up here buddy!"
        scene pres3
        with dissolve
        ji "Hmmmm..."
        ji "First of all, are you 18 or older?"

        menu:
            "Yes":
                $ persistent.agree = True
                jump suitepres
            "No":
                $ renpy.quit()

        label suitepres:
        ji "Okay that's perfect! Well let's go to a more intimate spot!"
        scene julialit
        with fade
        ji "First, this Visual Novel has many scenes that contain sexual content, crude language, and some touchy subjects like drugs and alcohol."
        ji "That may not be suitable for all readers."
        ji "Are you ready?"

        menu:
            "Yes, of course I'm in!":
                jump suitepres2
            "Not for me, thanks. Ciao!":
                $ renpy.quit()

        label suitepres2:
        scene julialit2
        with dissolve
        ji "You're still here? I'll try to make your time spent here to be pleasant and hopefully... very pleasant!"
        cr "Excuse me, I'm the developer of this game."
        cr "I see you've met my girl. Let me talk with her for just a minute, please."
        cr "Sweetheart! You've already shown most of your body to them and look at that outfit! Is it normal to conduct yourself like this?"
        ji "In this kind of game... yes! You asked me to introduce the game so please let me do it!"
        ji "Look at the player. He's so shy. I already like him!"
        scene julialit3
        with dissolve
        ji "So, player, cat got your tongue?"
        ji "I hope you're going to love this game because it's made by a couple of Frenchies who love visual novels."
        ji "The game is still in development so don't hesitate to give advice or point out improvements they can make to make this game better!"
        cr "Sweetheart... My. Love. COME ON! They want to play the game already. You're talking too much!"
        ji "Okay, Mister Developer! Fine!"
        scene black
        with fade
        cr "Oh yeah, have you told him that he's going to see your tits later?"
        if persistent.streaming == True:
            ji "Maybe. If he plays his cards right..."
            ji "So have fun! Maybe we will see each other again!"
            pause 2
            $ renpy.save_persistent()
            with dissolve
            scene black
            stop music fadeout 2
            pause 2
            call screen main_menu
        scene juliadebut
        with fade
        ji "Maybe. If he plays his cards right..."

        scene juliadebut2
        with dissolve
        pause 0.5
        scene juliadebut
        with dissolve
        ji "Have fun! Maybe we will see each other again!"
        pause 2
        $ renpy.save_persistent()
        with dissolve
        scene black
        stop music fadeout 2
        pause 2
        jump before_main_menu
    else:

        call animationbestlite from _call_animationbestlite
        return


label start:
    stop music
    pause 2
    play sound "sound/coeur.wav" loop
    $ renpy.sound.set_volume(0.1)
    centered "{size=+10}{color=#1e90ff}Being Competitive...{/color}{/size}"
    centered "{size=+10}{color=#1e90ff}Wasn't my priority until now...{/color}{/size}"
    centered "{size=+10}{color=#1e90ff}To Become #1 of the 100...{/color}{/size}"
    centered "{size=+10}{color=#1e90ff}I can't fail... I have to be...{/color}{/size}"
    centered "{size=+20}{color=#1e90ff}The B.E.S.T{/color}{/size}"
    stop sound
    stop music fadeout 2
    pause 2
    jump personalize

label personalize:
    play music "musique/Stellardrone-ToTheGreatBeyond.mp3" volume 0.5
    scene testfull
    with fade
    grace "Hey !"
    grace "Hmmm. What's your name ?"
    $ name = renpy.input(_('Your First Name?') or 'Dorian')
    $ name = name.strip()
    grace "Okay [name]."

    if persistent.patch_enabled:
        grace "Oh! I see that you have purchased the Walkthrough mod!"
        grace "I want to thank you for your support and I hope you will enjoy the full experience of B.E.S.T!"
        grace "During your playthrough, with the mod activated, you will see some icons like that:"
        show expression "gui/hudbest/icon_trophy.png" at truecenter
        grace "That means the 'best' option to choose."
        hide expression "gui/hudbest/icon_trophy.png"
        grace "You will see other icons like this one:"
        show expression "gui/hudbest/icon_temperament.png" at truecenter:
            xsize 200
            ysize 200
        grace "That means you will gain a point in this statistic."
        hide expression "gui/hudbest/icon_temperament.png"
        grace "Finally you will see some icons of the girls like mine :"
        show expression "phone/assets/grace_icon.png" at truecenter:
            xsize 200
            ysize 200
        grace "That means this choice is needed to continue on the path of this girl."
        hide expression "phone/assets/grace_icon.png"
        grace "If it's your first time here, I advise you to turn it off and make the choices as you want."
        grace "It is your game though, so it's your choices!"
        menu:
            "Enable Walkthrough":
                $ persistent.patch_enabled = True
            "Disable Walkthrough":
                $ persistent.patch_enabled = False

    grace "Before we begin, I would like to know which kind of person you are, [name]."
    scene test2
    with dissolve

    if persistent.patch_enabled == True:
        $ TEMP1 = scriptm1c1
        $ TEMP2 = scriptm1c2
        $ TEMP3 = scriptm1c3
        $ TEMP4 = scriptm1c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "I'm a good friend, always there for others.[TEMP1!t]":
            call buddy_increased from _call_buddy_increased_15
            grace "Okay, Ruby can't wait to meet you!"
            grace "Well, I have all I need."
            grace "See you later !"
            jump presentation
        "I'm a good student, serious and calm.[TEMP2!t]":
            call education_increased from _call_education_increased_10
            grace "You should meet Gabriella! She loves having good students in her class."
            grace "Well, I have all I need."
            grace "See you later !"
            jump presentation
        "I'm a sports junkie, and I'm always hitting the gym![TEMP3!t]":
            call sport_increased from _call_sport_increased_14
            grace "Hmmm... you should come with me to the swimming pool. I want to see your moves!"
            grace "Well, I have all I need."
            grace "See you later!"
            jump presentation
        "I'm a ladies man, a regular Don Juan or Casanova. [TEMP4!t]":
            call temperament_increased from _call_temperament_increased_17
            grace "Oh? Well maybe you and the twins will get along..."
            grace "Well, I have all I need."
            grace "See you later!"
            jump intro

label intro:
    scene black
    with fade
    if persistent.streaming == True:
        pause 1
        ji "Fuck! Umm... I'll miss you!"
        scene intro8
        with dissolve
        "This is Elise."
        "She's my friend... with benefits, as they say."
        "We've been seeing each others for several months now."
        "Really only have one rule."
        "No strings attached."
        "Damn... I will miss that ass."
        eli "You better come back to me soon..."
        eli "I swear, [name], you better hurry back, mmmm..."
        eli "Otherwise, I'll come and get you myself."
        eli "I hope you'll find some girls there to... ahhh... explore with!"
        d "What ?"
        eli "You will meet new girls and... ahhhh... enjoy new experiences...."
        eli "And I.... ahhhhhh.... want to experience the results as soon as you're back!"
        eli "Unhh.... you're the best..."
        pause 1 
        scene black
        with fade
        jump presentation

    if _in_replay:
        show screen Replayexit
    $ renpy.music.set_volume(0.5)
    ji "Fuck ! Unhh... I will miss your dick!"

    play movie "images/animation/typh.webm" loop 
    show movie with dissolve
    ""
    "This is Elise."
    "She's my friend... with benefits, as they say."
    scene intro2
    pause 1
    stop movie

    play movie "images/animation/typh2.webm" loop 
    show movie with dissolve
    "We've been seeing each others since several months, now."
    scene intro3
    pause 1
    stop movie

    play movie "images/animation/typh3.webm" loop 
    show movie with dissolve
    "Really only have one rule."
    stop movie
    scene intro4
    with dissolve
    "No strings attached."
    pause 1
    "Damn... I will miss that ass."
    pause 1
    scene black
    with fade
    pause 1
    scene intro5
    with vpunch
    eli "You better come back to me soon..."
    scene intro8
    with dissolve
    eli "I swear, [name], you better hurry back, mmmm..."
    eli "Otherwise, I'll come and get you myself."
    pause 1 
    scene intro7
    with dissolve
    eli "I hope you'll find some girls there to... ahhh... explore with!"
    d "What ?"
    eli "You will meet new girls and... ahhhh... enjoy new experiences...."
    eli "And I.... ahhhhhh.... want to experience the results as soon as you're back!"
    eli "Unhh.... you're the best..."
    scene intro6
    with dissolve
    eli "Ah... ahhhh... ahhh..."
    with flash
    with vpunch
    with flash
    scene intro10
    with hpunch
    with dissolve
    eli "Hnghhhh..."
    d "Ahhhhhhhh! So gooood!"
    with flash
    with vpunch
    with flash
    scene intro9
    with dissolve
    with flash
    with vpunch
    with flash
    pause 1
    scene black
    with fade
    pause 1
    scene intro8
    with dissolve
    eli "Unhhh.... you're the best..."
    pause 1 
    scene black
    with fade
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    jump presentation

label presentation:
    scene black
    with fade
    pause 1 
    dpense "This is me."
    show sideheroban
    $ Achievement.add(achievement_welcome)
    $ achievement.sync()
    with dissolve
    dpense "I'm from France, and I'm going to the USA to study."
    dpense "My English is okay but I'm far from perfect. I make some mistakes and others don't bother to tell me when I do..."
    scene heroban2
    with fade
    dpense "I'm coming to the USA for a six-month exchange program."
    dpense "I'm studying Marketing and Economics at a prestigious academy."
    dpense "I applied for the program hoping to improve my English."
    dpense "The program includes going to the USA for six months, participating in the academy's way of life, and coming back with a certificate. It seemed simple enough."
    dpense "It all happened so fast."
    dpense "One day I was in France with my friends and family."
    dpense "And the next day,"
    dpense "I was on a plane to make the trip from France..."
    scene intro1179
    play movie "images/animation/intro1.webm"
    play sound "sound/Vooh.wav"
    pause 4
    scene intro1179
    with dissolve
    pause 1
    stop movie
    dpense "To America!"

    jump avion
    return

return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
