





define config.allow_underfull_grids = True


screen achievement_menu():
    tag menu





    use game_menu(__("Achievements | {:01d}/{}").format(len(persistent.my_achievements), len(achievement_name) if len(persistent.my_achievements) == len(achievement_name) else len(achievement_name) - 1), scroll="viewport"):



        style_prefix "achievements"

        frame:

            background None
            padding (20, 20, 20, 20)
            align (0.0, 0.0)

            has vpgrid

            cols 2
            spacing 10


            for t in persistent.my_achievements:

                if achievement.has(t.name):

                    frame:

                        background Solid('#0088AA')

                        has hbox
                        yalign 0.5

                        xysize (100, 100)

                        add t.image size (100, 100) yalign 0.5

                        null width 20

                        vbox:
                            spacing 0
                            yfill False

                            text t.name style 'achievements_label' color '#ffffff'
                            text t.message color '#ffffff'


            for v in achievement_name.values():

                if not achievement.has(v[0]):






                    if v[3] != 'platinum':

                        frame:

                            has hbox

                            yalign 0.5
                            xysize (100, 100)


                            add 'gui/locked_achievement.png' size (100, 100) yalign 0.5

                            null width 20

                            vbox:

                                spacing 0
                                yfill False



                                if v[3] is None:


                                    text str(v[0]) style 'achievements_label' color '#FFFFFF33'
                                    text str(v[1]) color '#FFFFFF33'

                                else:

                                    text _('Hidden Achievement') style 'achievements_label' color '#FFFFFF33'


init python:




    def achievement_notification_show():
        
        
        store.achievement_is_done = False
        if achievement_notification_list:
            store.achievement_notification_list.pop(0)


    def achievement_notification_done():
        
        
        if not achievement_notification_list:
            store.achievement_is_done = True

    config.overlay_screens.append("achievement_notification_catcher")



    def passive_function():
        
        if len(persistent.my_achievements) >= (len(achievement_name) - 1):
            Achievement.add(achievement_platinum)

define config.periodic_callback = passive_function






default achievement_notification_list = []
default achievement_is_done = False


screen achievement_notification_catcher():

    if len(achievement_notification_list) > 0 and not renpy.get_screen('achievement_notification'):
        timer 1.0 repeat True:
            action [SetVariable('achievement_is_done', False), Show('achievement_notification')]

    if not achievement_is_done:
        timer 4.0 repeat True:
            action If(len(achievement_notification_list) > 0,
                        true=[Hide("achievement_notification"), Function(achievement_notification_show)],
                        false=[Function(achievement_notification_done)])


screen achievement_notification():

    zorder 100

    if achievement_notification_list:

        button at achievement_appear:

            align (0.5, 0.1)
            background Frame("gui/boite.png", 50, 50, 50, 50)
            padding (30,20,10,20)



            has hbox
            xysize (100, 100)
            add achievement_notification_list[0].image

            null width 20

            vbox:
                yalign 0.5
                xminimum 340
                xmaximum 440
                yfill False
                xfill False

                text str(achievement_notification_list[0].name):
                    color '#2d45cc'
                    size 25

                text str(achievement_notification_list[0].message):
                    style 'victory_message_text'
                    size 20

style victory_message_text:
    color "#2d45cc"
    size 20

transform achievement_appear:
    subpixel True
    on show:
        yoffset -160.0 alpha 1.0
        easein 0.2 yoffset 5.0
        easeout 0.1 yoffset 0.0

    on hide:
        yoffset 0.0
        easein 0.2 yoffset 5.0
        easeout 0.1 yoffset -160.0
        alpha 0.0


style achievements_vbox is vbox
style achievements_text is text
style achievements_frame is frame

style achievements_vbox:
    minimum (330, 100)
    maximum (360, 100)
    spacing 2
    yfill False

style achievements_label:
    size 26
    outlines [(1, '#00000022', 0, 1)]
    yalign 0.5

style achievements_text:
    size 16
    yalign 0.5

style achievements_locked_text:
    color "#555555"
    size 16

style achievements_frame:
    background Solid('#444444')
    minimum (500, 140)
    align (0.5, 0.5)
    padding (15, 15, 15, 15)



screen achievement_menu():
    tag menu


    variant "touch"


    use game_menu(_("Achievements | {:01d}/{}".format(len(persistent.my_achievements), len(achievement_name) if len(persistent.my_achievements) == len(achievement_name) else len(achievement_name) - 1)), scroll="viewport"):



        style_prefix "achievements"

        frame:

            background None
            padding (10, 10, 10, 10)
            align (0.0, 0.0)

            has vpgrid

            cols 1
            spacing 3


            for t in persistent.my_achievements:

                if achievement.has(t.name):

                    frame:

                        background Solid('#0088AA')

                        has hbox

                        yalign 0.5
                        xysize (50, 50)

                        add t.image size (50, 50) yalign 0.5

                        null width 15

                        vbox:

                            spacing 0
                            yfill False

                            text t.name style 'achievements_label' color '#000000'
                            text t.message color '#000000'


            for v in achievement_name.values():

                if not achievement.has(v[0]):

                    if v[3] != 'platinum':

                        frame:

                            has hbox

                            yalign 0.5
                            xysize (50, 50)

                            add 'gui/locked_achievement.png' size (50, 50) yalign 0.5

                            null width 15

                            vbox:
                                spacing 0
                                yfill False

                                if v[3] is None:

                                    text str(v[0]) style 'achievements_label' color '#FFFFFF33'
                                    text str(v[1]) color '#FFFFFF33'

                                else:

                                    text _('Hidden Achievement') style 'achievements_label' color '#FFFFFF33'


style achievements_vbox:
    variant 'small'
    xysize (300, 80)

style achievements_label:
    variant 'small'
    size 16

style achievements_text:
    variant 'small'
    size 16

style achievements_locked_text:
    variant 'small'
    size 16

style achievements_frame:
    variant 'small'
    size 16
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
