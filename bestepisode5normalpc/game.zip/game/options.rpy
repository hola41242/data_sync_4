













define config.name = _("B.E.S.T")





define gui.show_name = True




define config.version = "Episode5"





define gui.about = _p(

"Credits for music :\n" 
"(Source: https://soundcloud.com //"
"Licence: https://creativecommons.org/licenses/by/3.0/deed.fr //"
"Téléchargement: https://www.auboutdufil.com):\n"
"\n"
" Aerocity - Stranger"
" Amaria - Lovely Swindler"
" Cjbeards - Fire And Thunder"
" Jens East - Daybreak feat Henk"
" KaiEngel - TheRun"
" Keys of Moon - The Success"
" Lyvo - Home"
" Markvard - Desire"
" MaxKoMusic - Ode To The Winners"
" Meydan - Changes"
" Niwel - Bad Love"
" Nomyn - Fragments"
" NovaNoma - Gaia"
" Pachyderm - Never Knew Me at All"
" PhilippWeigl - Subdivision Of The Masses"
" PunchDeck - Destabilized"
" Rexlambo - Stay With Me"
" Sacrifice - EliLortomy"
" Stellardrone - To The Great Beyond"
" Vexento - Now"
" Vexento - Spark"
"\n"
"\nCredits for Scripts \n:"
"\n"
"\nBadMustard for saves and galleries //"
"\nElckarow for the phone //"
"\nAngel Seraph for achievements"
"\n"
"\nEnglish Translation : SaintBlackMoor // Spanish Translation : Mustadio"
"\n // Italian Translation : Eagle1900 // Russian Translation : Pretender"
"\n // Chinese Translation : V // Portuguese Translation : Heathens"
"\n"
"\nWith the precious advices of Drooskati, UncleNanard and SecretGame"
)







define build.name = "B.E.S.T"








define config.has_sound = True
define config.has_music = True
define config.has_voice = False













define config.main_menu_music = "musique/keepin.ogg"
define config.main_menu_music_fadein = 2.0










define config.enter_transition = dissolve
define config.exit_transition = dissolve




define config.intra_transition = dissolve




define config.after_load_transition = None




define config.end_game_transition = None
















define config.window = "auto"




define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)







default preferences.text_cps = 0





default preferences.afm_time = 15
















define config.save_directory = "beststeam"






define config.window_icon = "gui/icone.png"






init python:




















    build.archive("DLC", "all")
    build.classify('game/DLC/**.**', 'DLC')
    build.classify('game/tl/french/DLC/**.**', 'DLC')
    build.classify('game/tl/spanish/DLC/**.**', 'DLC')
    build.classify('game/tl/russian/DLC/**.**', 'DLC')
    build.classify('game/tl/italian/DLC/**.**', 'DLC')
    build.classify('game/tl/schinese/DLC/**.**', 'DLC')
    build.classify('game/tl/tchinese/DLC/**.**', 'DLC')
    build.classify('game/tl/portuguese/DLC/**.**', 'DLC')
    build.classify('game/tl/japanese/DLC/**.**', 'DLC')
    build.package('DLC','zip','DLC')


    build.archive("scripts", "all")
    build.classify('game/scripts/**.**', 'scripts')
    build.classify('game/script.rpy', 'scripts')
    build.archive("images", "all")
    build.classify('game/images/**.**', 'images')


    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)










    build.documentation('*.html')
    build.documentation('*.txt')












define build.itch_project = "dolyla/best"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
