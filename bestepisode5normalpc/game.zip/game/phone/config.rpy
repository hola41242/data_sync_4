python early in phone.config:
    from renpy import store
    from store import Dissolve, _warper, _, phone, Transform
    _constant = True


    basedir = "phone/assets/"


    overlay_screens = [ ]


    quick_menu = True


    enter_transition = Dissolve(0.6, time_warp=_warper.ease)


    exit_transition = Dissolve(0.6, time_warp=_warper.ease)


    intra_transition = Dissolve(0.1)


    time_format = _("%H:%M")


    date_format = _("%m/%d/%Y")


    textbox_radius = 15


    call_history_lenght = 20



    message_text_tags = {
        "emoji", "alpha", "color", "u", "i", "b", "a"
    } 


    status_bar = True


    hide_status_bar_screens = []




    layer_at_transforms = { }



    applications_pages = 4





    data = {
        "call_history": list,
        "group_chats": list,
        "background_image": lambda: None,
        "calendars": list,
    }

    def _generate_applications_dict():
        rv = {
            i: phone.application._generate_applications_page()
            for i in range(applications_pages)
        }
        rv[None] = phone.application._generate_bottom_applications_page()
        rv["max"] = 0
        return rv

    data["applications"] = _generate_applications_dict


    lowest_brightness = 0.3





















    discussion_callbacks = [ ]


    video_call_layer = "phone_video_call"


    video_call_layer_transform_properties = {
        "align": (0.5, 1.0),
        "ysize": 1.0,
        "fit": "contain"
    }

init -1400 python in phone.config:
    from store import BrightnessMatrix
    layer_at_transforms[None] = Transform(matrixcolor=BrightnessMatrix(-0.03), blur=5)
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
