init offset = -120

init python in phone.system:
    from renpy import store

    from pygame_sdl2.power import get_power_info    
    def get_battery_level():
        if battery_level is not None: return int(battery_level)
        return max(get_power_info().percent, 0)

    from socket import gethostbyname, gethostname
    CONNECTED = 1
    NO_INTERNET = 2
    NOT_CONNECTED = 3
    AIRPLANE_MODE = 4
    CELLULAR_DATA = 5

    renpy.const("phone.system.CONNECTED")
    renpy.const("phone.system.NO_INTERNET")
    renpy.const("phone.system.NOT_CONNECTED")
    renpy.const("phone.system.AIRPLANE_MODE")
    renpy.const("phone.system.CELLULAR_DATA")

    def get_internet_connection_state():
        
        
        
        
        
        
        
        
        
        
        
        
        
        if airplane_mode: return AIRPLANE_MODE
        
        return CONNECTED

    from datetime import datetime
    def get_date():
        if date is not None: return date
        return datetime.now()


default phone.system.date = None
default phone.system.battery_level = None
default phone.system.wifi = None



default phone.system.locked = False

default phone.system.airplane_mode = False
default phone.system.bluetooth = False
default phone.system.rotation_locked = False
default phone.system.cellular_data = False
default phone.system.internet_connection = True
default phone.system.at_list = []
default phone.system.dark_mode = False
default phone.system.flashlight = False


default phone.system.brightness = 1.0
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
