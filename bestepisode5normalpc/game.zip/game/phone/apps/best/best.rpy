
init python:
    import random

    mastermindPlaces = []
    mastermindObjects = []
    mastermindHints = []
    mastermindRandomPlaces = []
    mastermindRandomObjects = []
    correctNumbers = []
    currentHints = []
    chosenNumbers = [0, 0, 0, 0]
    goodSlotsValues = [0, 0, 0, 0]
    currentFoundObject = None
    targetRoom = None

    class MastermindPlace:
        currentPlace = None
        previousPlace = None
        counter = 0
        
        def __init__(self, placeName, img = "", linkedRooms=[]):
            self.placeName = placeName
            self.img = img
            self.linkedRooms = linkedRooms
            
            MastermindPlace.counter += 1
            self.id = MastermindPlace.counter
        
        def defineAsCurrentPlace(self):
            MastermindPlace.currentPlace = self
        
        def getObjects(self):
            objects = []
            
            for elt in mastermindObjects:
                if elt.parentPlace.id == self.id:
                    objects.append(elt)
            
            return objects
        
        def hasObjects(self):
            for elt in mastermindObjects:
                if elt.parentPlace.id == self.id:
                    return True
            return False
        
        def getHints(self):
            hints = []
            for elt in mastermindHints:
                if elt.linkedPlace.id == self.id:
                    hints.append(elt)
            return hints
        
        def isOneObjectFound(self):
            for elt in self.getObjects():
                if elt.isFound:
                    return True
            return False
        
        def findPlaceById(wantedId=0):
            for elt in mastermindPlaces:
                if elt.id == wantedId:
                    return elt
            return False
        
        def setCurrentPlace(self):
            MastermindPlace.previousPlace = MastermindPlace.currentPlace
            MastermindPlace.currentPlace = self
        
        def chosenRandomObjectHere(self):
            for elt in self.getObjects():
                if elt in mastermindRandomObjects:
                    return elt
            return False








    class MastermindObject:
        counter = 0
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        def __init__(self, objectName, parentPlace, hotspot, linkedNumber = 0, number = 0, isFound = False):
            self.objectName = objectName
            self.parentPlace = parentPlace
            self.linkedNumber = linkedNumber
            self.hotspot = hotspot
            self.number = number
            self.isFound = isFound
            
            MastermindObject.counter += 1
            self.id = MastermindObject.counter
        
        def find(self):
            self.isFound = True

    class MastermindHint:
        counter = 0
        
        def __init__(self, text, linkedPlace, isFound = False):
            self.text = text
            self.linkedPlace = linkedPlace
            self.isFound = isFound
            
            MastermindHint.counter += 1
            self.id = MastermindHint.counter
        
        def find(self):
            self.isFound = True

    def areFoundAllObjects():
        for elt in mastermindRandomObjects:
            if not elt.isFound:
                return False
        return True

    def areHintsInCorrectOrders(hints):
        counter = 0
        for index, elt in enumerate(hints):
            if mastermindRandomObjects[index] == elt:
                counter += 1
        
        return counter >= 4

    def hasObjectWithThisNumberAlreadyBeenChosen(obj):
        for elt in mastermindRandomObjects:
            if elt.linkedNumber == obj.linkedNumber:
                return True
        return False

    def hasWonMastermind():
        return chosenNumbers == correctNumbers and 0 not in chosenNumbers

    def end_mastermind():
        store._window_hide()
        
        phone.show_layer_at([], reset=True)
        renpy.hide_screen("phone_mastermindnumbers")
        
        
        
        phone.set_current_screen(None)
        
        store._window_auto = True


    mastermindPlaces.append(MastermindPlace(_("Affair"), "phone/assets/mastermind_best/affair.png"))
    mastermindPlaces.append(MastermindPlace(_("Bowling"), "phone/assets/mastermind_best/bowling.png"))
    mastermindPlaces.append(MastermindPlace(_("Dance"), "phone/assets/mastermind_best/danse.png"))
    mastermindPlaces.append(MastermindPlace(_("Library"), "phone/assets/mastermind_best/bibli.png"))
    mastermindPlaces.append(MastermindPlace(_("Auditorium"), "phone/assets/mastermind_best/auditorium.png"))
    mastermindPlaces.append(MastermindPlace(_("Museum"), "phone/assets/mastermind_best/musee.png"))
    mastermindPlaces.append(MastermindPlace(_("Port"), "phone/assets/mastermind_best/port.png"))
    mastermindPlaces.append(MastermindPlace(_("Gym"), "phone/assets/mastermind_best/gym.png"))
    mastermindPlaces.append(MastermindPlace(_("Park"), "phone/assets/mastermind_best/park.png"))

    mastermindPlaces[4].setCurrentPlace()



    mastermindPlaces[4].linkedRooms = [mastermindPlaces[0], mastermindPlaces[1], mastermindPlaces[2], mastermindPlaces[3], mastermindPlaces[5], mastermindPlaces[6], mastermindPlaces[7], mastermindPlaces[8]]

    mastermindPlaces[0].linkedRooms = [mastermindPlaces[3], mastermindPlaces[1], mastermindPlaces[4]]

    mastermindPlaces[1].linkedRooms = [mastermindPlaces[0], mastermindPlaces[5], mastermindPlaces[4]]

    mastermindPlaces[3].linkedRooms = [mastermindPlaces[6], mastermindPlaces[0], mastermindPlaces[4]]

    mastermindPlaces[6].linkedRooms = [mastermindPlaces[3], mastermindPlaces[4], mastermindPlaces[8]]

    mastermindPlaces[5].linkedRooms = [mastermindPlaces[1], mastermindPlaces[2], mastermindPlaces[4]]

    mastermindPlaces[2].linkedRooms = [mastermindPlaces[5], mastermindPlaces[4], mastermindPlaces[7]]

    mastermindPlaces[7].linkedRooms = [mastermindPlaces[4], mastermindPlaces[8], mastermindPlaces[2]]

    mastermindPlaces[8].linkedRooms = [mastermindPlaces[4], mastermindPlaces[6], mastermindPlaces[7]]






    mastermindObjects.append(MastermindObject("Left window", mastermindPlaces[0], (62, 377, 159, 164), 1, 1))
    mastermindObjects.append(MastermindObject("Parasol", mastermindPlaces[0], (941, 584, 417, 339), 2, 3))
    mastermindObjects.append(MastermindObject("Bench", mastermindPlaces[0], (923, 454, 155, 120), 3, 2))
    mastermindObjects.append(MastermindObject("Statue", mastermindPlaces[0], (1371, 119, 548, 955), 4, 4))




    mastermindObjects.append(MastermindObject("Keels", mastermindPlaces[1], (1621, 237, 209, 159), 5, 4))
    mastermindObjects.append(MastermindObject("Fan", mastermindPlaces[1], (150, 112, 122, 111), 6, 1))
    mastermindObjects.append(MastermindObject("Balls", mastermindPlaces[1], (354, 656, 256, 420), 7, 3))
    mastermindObjects.append(MastermindObject("Ball giver", mastermindPlaces[1], (525, 361, 277, 99), 8, 2))



    mastermindObjects.append(MastermindObject("Bin", mastermindPlaces[2], (522, 705, 48, 50), 9, 1))
    mastermindObjects.append(MastermindObject("Middle of room", mastermindPlaces[2], (816, 506, 261, 250), 7, 2))
    mastermindObjects.append(MastermindObject("Boxes", mastermindPlaces[2], (1158, 545, 199, 214), 5, 3))
    mastermindObjects.append(MastermindObject("Cups", mastermindPlaces[2], (1559, 470, 248, 94), 3, 4))



    mastermindObjects.append(MastermindObject("Computer", mastermindPlaces[3], (44, 534, 283, 388), 2, 1))
    mastermindObjects.append(MastermindObject("Books 1", mastermindPlaces[3], (544, 561, 133, 82), 4, 2))
    mastermindObjects.append(MastermindObject("Books 2", mastermindPlaces[3], (875, 457, 160, 102), 6, 3))
    mastermindObjects.append(MastermindObject("Books 3", mastermindPlaces[3], (1549, 920, 198, 117), 8, 4))



    mastermindObjects.append(MastermindObject("Left painting", mastermindPlaces[5], (0, 347, 48, 240), 3, 1))
    mastermindObjects.append(MastermindObject("Circular painting", mastermindPlaces[5], (1018, 423, 61, 142), 5, 2))
    mastermindObjects.append(MastermindObject("Sofa", mastermindPlaces[5], (1327, 701, 588, 264), 7, 4))
    mastermindObjects.append(MastermindObject("Right painting", mastermindPlaces[5], (1789, 448, 98, 120), 9, 3))



    mastermindObjects.append(MastermindObject("Binoculars", mastermindPlaces[6], (707, 321, 94, 172), 1, 1))
    mastermindObjects.append(MastermindObject("Front bin", mastermindPlaces[6], (961, 328, 101, 258), 3, 2))
    mastermindObjects.append(MastermindObject("Back bin", mastermindPlaces[6], (1226, 348, 42, 89), 5, 3))
    mastermindObjects.append(MastermindObject("Stairs", mastermindPlaces[6], (1525, 391, 319, 685), 7, 4))



    mastermindObjects.append(MastermindObject("Machine 1", mastermindPlaces[7], (253, 572, 364, 501), 6, 1))
    mastermindObjects.append(MastermindObject("Treadmill", mastermindPlaces[7], (786, 765, 720, 227), 5, 2))
    mastermindObjects.append(MastermindObject("Machine 2", mastermindPlaces[7], (1164, 370, 173, 220), 4, 3))
    mastermindObjects.append(MastermindObject("Treadmill 2", mastermindPlaces[7], (1678, 555, 92, 97), 3, 4))

    mastermindObjects.append(MastermindObject("Bench 1", mastermindPlaces[8], (435, 679, 276, 317), 2, 1))
    mastermindObjects.append(MastermindObject("Bin in park", mastermindPlaces[8], (1045, 758, 54, 84), 1, 2))
    mastermindObjects.append(MastermindObject("Bin and bench", mastermindPlaces[8], (1194, 742, 128, 82), 4, 3))
    mastermindObjects.append(MastermindObject("Bush", mastermindPlaces[8], (1725, 625, 191, 217), 4, 4))

    mastermindHints.append(MastermindHint(__("A maze of glass and steel where dreams are priced and ambitions are signed."), mastermindPlaces[0]))
    mastermindHints.append(MastermindHint(__("A place where every move strives to turn the unfinished into a spare."), mastermindPlaces[1]))
    mastermindHints.append(MastermindHint(__("A space where every step composes a melody and every movement brings the rhythm to life."), mastermindPlaces[2]))
    mastermindHints.append(MastermindHint(__("A sanctuary where words whisper secrets and pages keep time in memory."), mastermindPlaces[3]))
    mastermindHints.append(MastermindHint(__("Tes connaissances s'accumulent ici"), mastermindPlaces[4]))
    mastermindHints.append(MastermindHint(__("A vault where time stands still and every artifact whispers echoes of an immortal past."), mastermindPlaces[5]))
    mastermindHints.append(MastermindHint(__("A theater where ropes sing in the wind and every departure promises an adventure to tell."), mastermindPlaces[6]))
    mastermindHints.append(MastermindHint(__("A temple where every effort shapes determination and every drop of sweat writes perseverance."), mastermindPlaces[7]))
    mastermindHints.append(MastermindHint(__("A haven where nature paints living pictures and the wind tells forgotten tales."), mastermindPlaces[8]))


    def initMastermind():
        tempPlaceDisqualifier = []
        randomIndex = -1
        for i in range(4):
            
            randomIndex = random.randrange(0, len(mastermindPlaces))
            while randomIndex in tempPlaceDisqualifier:
                randomIndex = random.randrange(0, len(mastermindPlaces))
            
            
            while (not mastermindPlaces[randomIndex].hasObjects()) or randomIndex == 4:
                
                randomIndex = random.randrange(0, len(mastermindPlaces))
                while randomIndex in tempPlaceDisqualifier:
                    randomIndex = random.randrange(0, len(mastermindPlaces))
            
            
            mastermindRandomPlaces.append(mastermindPlaces[randomIndex])
            tempPlaceDisqualifier.append(randomIndex)
        
        
        tempPlaceDisqualifier = []
        randomIndex = -1
        
        
        for elt in mastermindRandomPlaces:
            
            objectsOfCurrentPlace = elt.getObjects()
            
            
            randomIndex = random.randrange(0, len(objectsOfCurrentPlace))
            
            while hasObjectWithThisNumberAlreadyBeenChosen(objectsOfCurrentPlace[randomIndex]):
                randomIndex = random.randrange(0, len(objectsOfCurrentPlace))
            
            
            mastermindRandomObjects.append(objectsOfCurrentPlace[randomIndex])
        
        
        for elt in mastermindRandomObjects:
            correctNumbers.append(elt.linkedNumber)
        
        
        for elt in mastermindRandomPlaces:
            currentHints.append(elt.getHints())
        
        
        random.shuffle(currentHints)
        
        while areHintsInCorrectOrders(currentHints):
            random.shuffle(currentHints)



transform blur_effect:
    blur 25.0

screen phone_best():
    timer 0.1 action If(g_time < 2000, true = SetVariable("g_time", g_time + 0.1), false = [SetVariable("g_time", 2000), Jump("masterepreuveep4")]) repeat True





    if bonus_mother == True:
        timer 0.1 action If(grace_time < 1200, true = SetVariable("grace_time", grace_time + 0.1), false = [SetVariable("grace_time", 1200), Jump("gracefintrialep4")]) repeat True

    if emerick_win == False:
        timer 0.1 action If(em_time < 900, true = SetVariable("em_time", em_time + 0.1), false = [SetVariable("em_time", 900), Call("emericktrialep4")]) repeat True












    use _phone():
        style_prefix "phone_best"


        vbox:

            use app_base():
                style_prefix "app_base"


            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                background None




                grid 1 3:

                    yoffset 1
                    xfill True
                    yfill True


























                    button:

                        action Show("mastermind_map", dissolve, False)




                        xfill True
                        yfill True
                        yalign 0.5

                        background "phone/assets/mastermind_best/map_best_app_idle.png"
                        hover_background "phone/assets/mastermind_best/map_best_app_hover.png"











                        text _("Minimap") size 25:
                            color "#fff"
                            outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]
                            xalign 0.5
                            yalign 0.5


                    button:



                        xfill True
                        yfill True
                        yalign 0.5



                        background "phone/assets/mastermind_best/hints_best_app_idle.png"
                        hover_background "phone/assets/mastermind_best/hints_best_app_hover.png"
                        action PhoneMenu("phone_mastermindhints")

                        text _("Hints") size 25:
                            color "#fff"
                            outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]
                            xalign 0.5
                            yalign 0.5


                    if areFoundAllObjects():
                        button:



                            xfill True
                            yfill True
                            yalign 0.5

                            background "#6d2929"
                            hover_background "#792d2d"

                            action PhoneMenu("phone_mastermindnumbers")

                            text _("Mastermind") size 25:
                                color "#fff"
                                outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]
                                xalign 0.5
                                yalign 0.5

style phone_best_side is empty:
    xfill True
    yfill True

style phone_best_frame is empty:
    xfill True

style phone_best_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"

screen phone_mastermindhints():
    python:
        isFoundAllNumbers = True
        strFoundNumbers = ""

        for index, elt in enumerate(correctNumbers):
            if index != len(correctNumbers)-1:
                strFoundNumbers += str(elt) + " ; "
            else:
                strFoundNumbers += str(elt)

    use _phone():
        style_prefix "phone_mastermindhints"
        timer 0.1 action If(g_time < 2000, true = SetVariable("g_time", g_time + 0.1), false = [SetVariable("g_time", 2000), Jump("masterepreuveep4")]) repeat True
        if bonus_mother == True:
            timer 0.1 action If(grace_time < 1200, true = SetVariable("grace_time", grace_time + 0.1), false = [SetVariable("grace_time", 1200), Jump("gracefintrialep4")]) repeat True

        if emerick_win == False:
            timer 0.1 action If(em_time < 900, true = SetVariable("em_time", em_time + 0.1), false = [SetVariable("em_time", 900), Call("emericktrialep4")]) repeat True
        vbox:
            use app_base():
                style_prefix "app_base"


            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                background None
                xpadding 15
                ypadding 10

                vbox:
                    spacing 20

                    for index, elt in enumerate(currentHints):

                        if not elt[0].linkedPlace.isOneObjectFound():
                            $ isFoundAllNumbers = False
                            text __("{b}Hint ") + str(index+1) + _("{/b}: ") + __(elt[0].text) size 20:
                                color "#373737"
                        else:
                            vbox:
                                text __("{s}{b}Hint ") + str(index+1) + _("{/b}: ") + __(elt[0].text) + "{/s}" size 20:
                                    color "#373737"


                                python:

                                    numberLinkedToHint = -1


                                    for elt2 in elt[0].linkedPlace.getObjects():
                                        
                                        if elt2 in mastermindRandomObjects:
                                            numberLinkedToHint = elt2.linkedNumber

                                text __("Found number: {b}") + str(numberLinkedToHint) + "{/b}" size 20:
                                    color "#373737"














style phone_mastermindhints_side is empty:
    xfill True
    yfill True

style phone_mastermindhints_frame is empty:
    xfill True

style phone_mastermindhints_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"








screen mastermind_map(comesFromPhone=False):
    style_prefix "mastermind_map"
    if comesFromPhone:
        $ PhoneReturn()



    add MastermindPlace.currentPlace.img at blur_effect

    button:
        background None
        xfill True
        yfill True

        action [Hide("mastermind_map"), Show("mastermind_room", dissolve, MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())]

        has frame
        xfill True
        yfill True
        background None


        button:
            xsize 1280
            ysize 900
            xalign 0.5
            yalign 0.5
            background "#37373700"
            action Show("mastermind_map", dissolve)

            add "phone/assets/mastermind_best/map3trans1280.png"


            button:
                xsize 201
                ysize 113
                xalign 0.88
                yalign 0.3

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[0].id:
                        if bonus_places and mastermindPlaces[0] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/affairmapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/affairmap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/affairmap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/affairmap_hover.jpg"
                        hover "phone/assets/mastermind_best/affairmap_hover.jpg"


                    if MastermindPlace.currentPlace.id == mastermindPlaces[0].id:
                        action [Function(mastermindPlaces[0].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[0].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[0] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[0] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[0].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[0] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[0] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]
                text _("Affair") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.88
                yalign 0.66

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[1].id:
                        if bonus_places and mastermindPlaces[1] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/bowlingmapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/bowlingmap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/bowlingmap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/bowlingmap_hover.jpg"
                        hover "phone/assets/mastermind_best/bowlingmap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[1].id:
                        action [Function(mastermindPlaces[1].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[1].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[1] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[1] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[1].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[1] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[1] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]
                text _("Bowling") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.5
                yalign 0.5

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[4].id:
                        if bonus_places and mastermindPlaces[4] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/auditoriummapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/auditoriummap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/auditoriummap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/auditoriummap_hover.jpg"
                        hover "phone/assets/mastermind_best/auditoriummap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[4].id:
                        action [Function(mastermindPlaces[4].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[4].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[4] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[4] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[4].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[4] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[4] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]
                text _("Auditorium") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]
                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.66
                yalign 0.1

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[3].id:
                        if bonus_places and mastermindPlaces[3] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/biblimapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/biblimap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/biblimap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/biblimap_hover.jpg"
                        hover "phone/assets/mastermind_best/biblimap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[3].id:
                        action [Function(mastermindPlaces[3].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[3].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[3] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[3] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[3].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[3] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[3] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]
                text _("Library") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.66
                yalign 0.9

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[5].id:
                        if bonus_places and mastermindPlaces[5] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/museemapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/museemap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/museemap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/museemap_hover.jpg"
                        hover "phone/assets/mastermind_best/museemap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[5].id:
                        action [Function(mastermindPlaces[5].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[5].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[5] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[5] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[5].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[5] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[5] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]

                text _("Museum") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.33
                yalign 0.1

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[6].id:
                        if bonus_places and mastermindPlaces[6] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/portmapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/portmap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/portmap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/portmap_hover.jpg"
                        hover "phone/assets/mastermind_best/portmap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[6].id:
                        action [Function(mastermindPlaces[6].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[6].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[6] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[6] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[6].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[6] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[6] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]

                text _("Port") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.33
                yalign 0.9

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[2].id:
                        if bonus_places and mastermindPlaces[2] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/dansemapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/dansemap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/dansemap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/dansemap_hover.jpg"
                        hover "phone/assets/mastermind_best/dansemap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[2].id:
                        action [Function(mastermindPlaces[2].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[2].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[2].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]

                text _("Dance") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.12
                yalign 0.33

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[8].id:
                        if bonus_places and mastermindPlaces[8] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/parkmapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/parkmap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/parkmap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/parkmap_hover.jpg"
                        hover "phone/assets/mastermind_best/parkmap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[8].id:
                        action [Function(mastermindPlaces[8].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[8].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[8] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[8] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[8].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[8] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[8] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]

                text _("Park") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            button:
                xsize 201
                ysize 113
                xalign 0.12
                yalign 0.66

                action NullAction()

                imagebutton:
                    if not MastermindPlace.currentPlace.id == mastermindPlaces[7].id:
                        if bonus_places and mastermindPlaces[7] in mastermindRandomPlaces:
                            idle "phone/assets/mastermind_best/gymmapblue_idle.jpg"
                            hover "phone/assets/mastermind_best/gymmap_hover.jpg"
                        else:
                            auto "phone/assets/mastermind_best/gymmap_%s.jpg"
                    else:
                        idle "phone/assets/mastermind_best/gymmap_hover.jpg"
                        hover "phone/assets/mastermind_best/gymmap_hover.jpg"

                    if MastermindPlace.currentPlace.id == mastermindPlaces[7].id:
                        action [Function(mastermindPlaces[7].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), Jump("changerPiece")]
                    else:
                        if bonus_speed == True:
                            action [Function(mastermindPlaces[7].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (60 if mastermindPlaces[7] in MastermindPlace.currentPlace.linkedRooms else 120)), SetVariable("em_time", em_time + (60 if mastermindPlaces[7] in MastermindPlace.currentPlace.linkedRooms else 120)), Jump("changerPiece")]
                        else:
                            action [Function(mastermindPlaces[7].setCurrentPlace), Function(renpy.restart_interaction), Hide("mastermind_map"), SetVariable("g_time", g_time + (120 if mastermindPlaces[7] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("em_time", em_time + (120 if mastermindPlaces[7] in MastermindPlace.currentPlace.linkedRooms else 240)), SetVariable("grace_time", grace_time + (120 if mastermindPlaces[2] in MastermindPlace.currentPlace.linkedRooms else 240)), Jump("changerPiece")]

                text _("Gym") size 30:
                    color "#fff"
                    outlines [ (absolute(2), "#373737", absolute(0), absolute(0)) ]


                    xalign 0.5
                    yalign 0.5


            imagebutton:
                xalign 1.0
                yalign 0.0
                anchor (0.5, 0.5)
                auto "phone/assets/no_%s.png"


                action [Hide("mastermind_map"), Show("mastermind_room", dissolve, MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())]

style mastermind_map_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"

init python:
    hintBalls = [False, False, False, False]

    def resetMastermind():
        for index, elt in enumerate(chosenNumbers):
            chosenNumbers[index] = 0
        for index, elt in enumerate(hintBalls):
            hintBalls[index] = 0
















































































































































































































































































































































































































































init python:
    previousSlotValues = [0, 0, 0, 0]

    def dragged_func_phonemastermind(dragged_items, dropped_on):
        if dropped_on is not None and (dropped_on.drag_name == "ballslot1" or dropped_on.drag_name == "ballslot2" or dropped_on.drag_name == "ballslot3" or dropped_on.drag_name == "ballslot4"):
            
            if (dragged_items[0].drag_name == "ball1" or dragged_items[0].drag_name == "ball2" or dragged_items[0].drag_name == "ball3" or dragged_items[0].drag_name == "ball4" or dragged_items[0].drag_name == "ball5" or dragged_items[0].drag_name == "ball6" or dragged_items[0].drag_name == "ball7" or dragged_items[0].drag_name == "ball8" or dragged_items[0].drag_name == "ball9") and dropped_on.drag_name == "ballslot1":
                dragged_items[0].snap(dropped_on.x, dropped_on.y)
                
                
                for index, elt in enumerate(chosenNumbers):
                    if elt == int(dragged_items[0].drag_name[-1]):
                        chosenNumbers[index] = 0
                
                chosenNumbers[0] = int(dragged_items[0].drag_name[-1])
                if chosenNumbers[0] == correctNumbers[0]:
                    
                    
                    hintBalls[0] = True
                else:
                    hintBalls[0] = False
            
            
            
            elif (dragged_items[0].drag_name == "ball1" or dragged_items[0].drag_name == "ball2" or dragged_items[0].drag_name == "ball3" or dragged_items[0].drag_name == "ball4" or dragged_items[0].drag_name == "ball5" or dragged_items[0].drag_name == "ball6" or dragged_items[0].drag_name == "ball7" or dragged_items[0].drag_name == "ball8" or dragged_items[0].drag_name == "ball9") and dropped_on.drag_name == "ballslot2":
                dragged_items[0].snap(dropped_on.x, dropped_on.y)
                
                
                for index, elt in enumerate(chosenNumbers):
                    if elt == int(dragged_items[0].drag_name[-1]):
                        chosenNumbers[index] = 0
                chosenNumbers[1] = int(dragged_items[0].drag_name[-1])
                if chosenNumbers[1] == correctNumbers[1]:
                    
                    
                    hintBalls[1] = True
                else:
                    hintBalls[1] = False
            
            
            
            elif (dragged_items[0].drag_name == "ball1" or dragged_items[0].drag_name == "ball2" or dragged_items[0].drag_name == "ball3" or dragged_items[0].drag_name == "ball4" or dragged_items[0].drag_name == "ball5" or dragged_items[0].drag_name == "ball6" or dragged_items[0].drag_name == "ball7" or dragged_items[0].drag_name == "ball8" or dragged_items[0].drag_name == "ball9") and dropped_on.drag_name == "ballslot3":
                dragged_items[0].snap(dropped_on.x, dropped_on.y)
                
                
                for index, elt in enumerate(chosenNumbers):
                    if elt == int(dragged_items[0].drag_name[-1]):
                        chosenNumbers[index] = 0
                chosenNumbers[2] = int(dragged_items[0].drag_name[-1])
                if chosenNumbers[2] == correctNumbers[2]:
                    
                    
                    hintBalls[2] = True
                else:
                    hintBalls[2] = False
            
            
            
            elif (dragged_items[0].drag_name == "ball1" or dragged_items[0].drag_name == "ball2" or dragged_items[0].drag_name == "ball3" or dragged_items[0].drag_name == "ball4" or dragged_items[0].drag_name == "ball5" or dragged_items[0].drag_name == "ball6" or dragged_items[0].drag_name == "ball7" or dragged_items[0].drag_name == "ball8" or dragged_items[0].drag_name == "ball9") and dropped_on.drag_name == "ballslot4":
                dragged_items[0].snap(dropped_on.x, dropped_on.y)
                
                
                for index, elt in enumerate(chosenNumbers):
                    if elt == int(dragged_items[0].drag_name[-1]):
                        chosenNumbers[index] = 0
                chosenNumbers[3] = int(dragged_items[0].drag_name[-1])
                if chosenNumbers[3] == correctNumbers[3]:
                    
                    
                    hintBalls[3] = True
                else:
                    hintBalls[3] = False
            
            
            renpy.restart_interaction()
        
        
        else:
            if dragged_items[0].drag_name == "ball1":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 1:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(20, 60)
                
                
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball2":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 2:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(0, 160)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball3":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 3:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(0, 250)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball4":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 4:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(0, 340)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball5":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 5:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(240, 60)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball6":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 6:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(260, 160)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball7":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 7:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(260, 250)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball8":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 8:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(260, 340)
                renpy.restart_interaction()
            elif dragged_items[0].drag_name == "ball9":
                for index, elt in enumerate(chosenNumbers):
                    if chosenNumbers[index] == 9:
                        chosenNumbers[index] = 0
                dragged_items[0].snap(130, 0)
                renpy.restart_interaction()
        
        if chosenNumbers[0] != correctNumbers[0]:
            hintBalls[0] = False
        if chosenNumbers[1] != correctNumbers[1]:
            hintBalls[1] = False
        if chosenNumbers[2] != correctNumbers[2]:
            hintBalls[2] = False
        if chosenNumbers[3] != correctNumbers[3]:
            hintBalls[3] = False
        
        if 0 not in chosenNumbers:
            renpy.restart_interaction()

init python:
    def fermerPhone():
        renpy.notify("Lala notif")



    def nettoyerLayers():
        
        
        
        renpy.show_layer_at(None, layer="master")

screen phone_mastermindnumbers():



    use _phone():
        style_prefix "phone_mastermindhints"

        vbox:

            use app_base([Function(resetMastermind)]):
                style_prefix "app_base"
                text _("B.E.S.T") xalign 0.5 text_align 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                background "phone/assets/bgmaster.png"
                xfill True
                yfill True
                xpadding 10
                ypadding 10





                imagebutton:
                    xalign 0.5
                    yalign 1.0
                    auto "phone/assets/replay_%s.png"

                    action [Function(resetMastermind), Function(renpy.restart_interaction), PhoneReturn(), PhoneMenu("phone_mastermindnumbers")]

                if hasWonMastermind():
                    imagebutton:
                        xalign 0.8
                        yalign 1.0
                        auto "phone/assets/yes_%s.png"





                        action PhoneReturn()



                if (hintBalls[0] and 0 not in chosenNumbers) or hasWonMastermind():
                    add "phone/assets/mastermind_best/mastermindballs/mastermindgreenball.png":
                        xalign 0.5
                        yalign 0.18

                if (hintBalls[1] and 0 not in chosenNumbers) or hasWonMastermind():
                    add "phone/assets/mastermind_best/mastermindballs/mastermindgreenball.png":
                        xalign 0.5
                        yalign 0.4

                if (hintBalls[2] and 0 not in chosenNumbers) or hasWonMastermind():
                    add "phone/assets/mastermind_best/mastermindballs/mastermindgreenball.png":
                        xalign 0.5
                        yalign 0.61

                if (hintBalls[3] and 0 not in chosenNumbers) or hasWonMastermind():
                    add "phone/assets/mastermind_best/mastermindballs/mastermindgreenball.png":
                        xalign 0.5
                        yalign 0.825


                draggroup:


                    drag:
                        xalign 0.5
                        yalign 0.2
                        drag_name "ballslot1"
                        drag_raise False
                        dragged dragged_func_phonemastermind
                        if not hasWonMastermind():
                            add "phone/assets/mastermind_best/mastermindballs/mastermindemptywhiteball.png"
                        else:
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball" + str(correctNumbers[0]) + ".png"
                        draggable False
                        if hasWonMastermind():
                            droppable False


                    drag:
                        xalign 0.5
                        yalign 0.4
                        drag_name "ballslot2"
                        drag_raise False
                        dragged dragged_func_phonemastermind
                        if not hasWonMastermind():
                            add "phone/assets/mastermind_best/mastermindballs/mastermindemptywhiteball.png"
                        else:
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball" + str(correctNumbers[1]) + ".png"
                        draggable False
                        if hasWonMastermind():
                            droppable False


                    drag:
                        xalign 0.5
                        yalign 0.6
                        drag_name "ballslot3"
                        drag_raise False
                        dragged dragged_func_phonemastermind
                        if not hasWonMastermind():
                            add "phone/assets/mastermind_best/mastermindballs/mastermindemptywhiteball.png"
                        else:
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball" + str(correctNumbers[2]) + ".png"
                        draggable False
                        if hasWonMastermind():
                            droppable False


                    drag:
                        xalign 0.5
                        yalign 0.8
                        drag_name "ballslot4"
                        drag_raise False
                        dragged dragged_func_phonemastermind
                        if not hasWonMastermind():
                            add "phone/assets/mastermind_best/mastermindballs/mastermindemptywhiteball.png"
                        else:
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball" + str(correctNumbers[3]) + ".png"
                        draggable False
                        if hasWonMastermind():
                            droppable False



                    if not (hasWonMastermind() and 1 in correctNumbers):
                        drag:

                            xpos 20
                            ypos 60
                            drag_raise True
                            drag_name "ball1"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball1.png"


                    if not (hasWonMastermind() and 2 in correctNumbers):
                        drag:
                            ypos 160
                            xpos 0
                            drag_raise True
                            drag_name "ball2"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball2.png"


                    if not (hasWonMastermind() and 3 in correctNumbers):
                        drag:

                            ypos 250
                            xpos 0
                            drag_raise True
                            drag_name "ball3"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball3.png"


                    if not (hasWonMastermind() and 4 in correctNumbers):
                        drag:

                            ypos 340
                            xpos 0
                            drag_raise True
                            drag_name "ball4"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball4.png"


                    if not (hasWonMastermind() and 5 in correctNumbers):
                        drag:

                            ypos 60
                            xpos 240
                            drag_raise True
                            drag_name "ball5"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball5.png"


                    if not (hasWonMastermind() and 6 in correctNumbers):
                        drag:

                            ypos 160
                            xpos 260
                            drag_raise True
                            drag_name "ball6"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball6.png"


                    if not (hasWonMastermind() and 7 in correctNumbers):
                        drag:

                            ypos 250
                            xpos 260
                            drag_raise True
                            drag_name "ball7"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball7.png"


                    if not (hasWonMastermind() and 8 in correctNumbers):
                        drag:

                            ypos 340
                            xpos 260
                            drag_raise True
                            drag_name "ball8"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball8.png"


                    if not (hasWonMastermind() and 9 in correctNumbers):
                        drag:

                            ypos 0
                            xpos 130
                            drag_raise True
                            drag_name "ball9"
                            dragged dragged_func_phonemastermind
                            add "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball9.png"






style phone_mastermindnumbers_side is empty:
    xfill True
    yfill True




style phone_mastermindnumbers_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"

init python:
    def areFound3Hints():
        counter = 0
        for elt in mastermindRandomObjects:
            if elt.isFound:
                counter += 1
        return counter >= 3

    def getNotFoundObject():
        for elt in mastermindRandomObjects:
            if not elt.isFound:
                return elt

screen mastermind_room(room, objects):



    style_prefix "mastermind_room"

    timer 0.1 action If(g_time < 2000, true = SetVariable("g_time", g_time + 0.1), false = [SetVariable("g_time", 2000), Jump("masterepreuveep4")]) repeat True
    if bonus_mother == True:
        timer 0.1 action If(grace_time < 1200, true = SetVariable("grace_time", grace_time + 0.1), false = [SetVariable("grace_time", 1200), Jump("gracefintrialep4")]) repeat True
    if emerick_win == False:
        timer 0.1 action If(em_time < 900, true = SetVariable("em_time", em_time + 0.1), false = [SetVariable("em_time", 900), Call("emericktrialep4")]) repeat True

    python:
        tempRoomNameHovered = str(room.img)
        tempRoomNameRed = str(room.img)
        currentCorrectObject = None

        tempRoomNameHovered = tempRoomNameHovered.replace(".png", "hot.png")

        if bonus_objects:
            for elt in mastermindRandomObjects:
                if elt.parentPlace == room:
                    currentCorrectObject = elt
            if currentCorrectObject is not None:
                tempRoomNameRed = tempRoomNameRed.replace(".png", "hotred_" + str(currentCorrectObject.number) + ".png")





    frame:
        background None
        xfill True
        yfill True




        has imagemap
        xoffset -6
        yoffset -6
        if bonus_objects and currentCorrectObject is not None:
            idle tempRoomNameRed
        else:
            idle room.img
        hover tempRoomNameHovered

        for elt in objects:
            if elt in mastermindRandomObjects:
                if not elt.isFound:
                    hotspot elt.hotspot clicked [Function(elt.find), Function(renpy.restart_interaction), SetVariable("currentFoundObject", elt), Jump("trouveUnObjet")]
                else:
                    hotspot elt.hotspot clicked [Function(renpy.restart_interaction), Jump("plusRienDansCetObjet")]
            else:
                hotspot elt.hotspot clicked [Function(renpy.restart_interaction), Jump("rienDansCetObjet")]















        if not hasWonMastermind():
            imagebutton:
                xalign 0.85
                yalign 0.05
                auto "phone/assets/mastermind_best/map_120_%s.png"

                action [FileTakeScreenshot(), Show("mastermind_map", dissolve)]


        if not hasWonMastermind():
            imagebutton:
                xalign 0.95
                yalign 0.05
                auto "phone/assets/about_120_%s.png"
                action PhoneMenu("phone_mastermindhints")


        if areFoundAllObjects() and MastermindPlace.currentPlace.id == mastermindPlaces[4].id and not hasWonMastermind():
            imagebutton:
                xalign 0.5
                yalign 0.85
                auto "phone/assets/game_120_%s.png"

                if bonus_master == True:
                    action Jump("rubypown")
                else:
                    action PhoneMenu("phone_mastermindnumbers")

        if hasWonMastermind():
            imagebutton:
                xalign 0.5
                yalign 0.5
                auto "phone/assets/star_360_%s.png"

                action Jump("masterepreuveep4")

















































































style mastermind_room_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
