































































































































screen phone_gallery():
    use _phone():
        style_prefix "phone_gallery"


        vbox:
            use app_base():
                style_prefix "app_base"

                if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and (phoneTheme == "#fff" or phoneTheme == "#ffffff"):
                    text _("Gallery") size 19 color "#373737" xalign 0.5 text_align 0.5
                else:
                    text _("Gallery") size 19 color "#fff" xalign 0.5 text_align 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True


                has frame


                if ('phoneTheme' in vars() or 'phoneTheme' in globals()):
                    background phoneTheme
                else:
                    background "#8cb5ef"

                xfill True


                vbox:
                    xalign 0.5
                    xfill True
















                    hbox:
                        xalign 0.5
                        spacing 30








                        textbutton _("Replays"):
                            text_size 30
                            text_color "#4A84BE"
                            background None
                            action NullAction()

                        textbutton _("Extras"):
                            background None
                            text_size 30
                            text_color "#373737"
                            text_hover_color "#4A84BE"
                            action [PhoneReturn(), PhoneMenu("phone_extras")]













                    vbox:
                        xalign 0.5
                        xfill True
                        spacing 15

                        for elt in Replay_items:
                            $ replayName = elt.name.replace("{color=#FFFFFF}", "").replace("{/color}", "")

                            if renpy.seen_label(elt.replay):
                                vbox:
                                    xalign 0.5
                                    button:
                                        frame:
                                            xalign 0.5
                                            xpadding 2
                                            ypadding 2
                                            background None
                                            xfill True

                                            add elt.thumbs:
                                                xalign 0.5
                                                fit "contain"
                                                xsize 310

                                        hover_background "#40ACD9"

                                        action Replay(elt.replay)

                                    hbox:
                                        xfill True
                                        text replayName size 20:
                                            color "#ffffff"
                                            xalign 0.5

                            else:
                                frame:
                                    xalign 0.5
                                    xpadding 2
                                    ypadding 2
                                    background None

                                    add "gallery0":
                                        fit "contain"
                                        xsize 310











style phone_gallery_side is empty:
    xfill True
    yfill True

style phone_gallery_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"

screen phone_extras():
    use _phone():
        style_prefix "phone_extras"


        vbox:




            use app_base():
                style_prefix "app_base"
                text _("Gallery") size 19 color "#373737" xalign 0.5 text_align 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame

                if ('phoneTheme' in vars() or 'phoneTheme' in globals()):
                    background phoneTheme
                else:

                    background "#ffffff"
                xfill True
                xalign 0.5


                vbox:
                    spacing 15
                    xfill True
                    xalign 0.5


                    hbox:
                        spacing 30
                        xalign 0.5

                        textbutton _("Replays"):
                            background None
                            text_size 30
                            text_color "#373737"
                            text_hover_color "#4A84BE"
                            action [PhoneReturn(), PhoneMenu("phone_gallery")]

                        textbutton _("Extras"):
                            text_size 30
                            text_color "#4A84BE"
                            background None
                            action NullAction()





















                    vbox:
                        xfill True
                        spacing 20
                        xalign 0.5

                        for elt in gallery_items:
                            $ elt.refresh_lock()

                            if elt.is_locked:
                                add elt.locked:
                                    xalign 0.5
                                    fit "contain"
                                    xsize 310

                            else:






                                button:
                                    frame:
                                        xfill True
                                        xalign 0.5
                                        xpadding 2
                                        ypadding 2
                                        background None

                                        add elt.thumb:
                                            xalign 0.5
                                            fit "contain"
                                            xsize 310

                                    hover_background "#40ACD9"
                                    action Show("gallery_closeup", dissolve, elt.images)

style phone_extras_side is empty:
    xfill True
    yfill True

style phone_extras_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
