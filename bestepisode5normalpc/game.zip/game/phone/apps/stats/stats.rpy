screen phone_stats():












    use _phone(usePhoneTheme=True):
        style_prefix "phone_stats"

        side "t c":
            use app_base():
                style_prefix "app_base"


                if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and (phoneTheme == "#fff" or phoneTheme == "#ffffff"):
                    text _("Stats") size 19 color "#373737" xalign 0.5 text_align 0.5
                else:
                    text _("Stats") size 19 color "#fff" xalign 0.5 text_align 0.5
            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                xpadding 20
                ypadding 20







                vbox:
                    spacing 25

                    hbox:
                        vbox:





                            text "Buddy" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"
                            text "Education" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"
                            text "Sport" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"
                            text "Temperament" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"

                        vbox:
                            xalign 1.0





                            text "[Buddy]" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"
                            text "[Education]" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"
                            text "[Sport]" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"
                            text "[Temperament]" size 25:
                                outlines [ (3, "#000000d8", 1, 1) ]
                                color "#ffffff"

                    hbox:
                        add Solid("#fff"):
                            xysize (1.0, 2) nearest True

                vbox:
                    yalign 0.5
                    xalign 0.5
                    yoffset 100
                    spacing 20

                    hbox:
                        xalign 0.5
                        xfill False
                        add "phone/assets/leaderboard.png"

                    hbox:
                        xalign 0.5
                        xfill False
                        text _("B.E.S.T RANK") size 35:
                            outlines [ (3, "#000000d8", 1, 1) ]
                            color "#ffffff"
                    hbox:
                        xalign 0.5
                        xfill False
                        text "[Rank]" size 105:
                            outlines [ (3, "#000000d8", 1, 1) ]
                            color "#ffffff"

style phone_stats_side is empty:
    xfill True
    yfill True

style phone_stats_frame is empty:
    xfill True

style phone_stats_hbox:
    xfill True

style phone_stats_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
