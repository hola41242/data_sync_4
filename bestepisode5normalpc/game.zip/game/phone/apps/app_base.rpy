screen app_base(action=NullAction()):
    style_prefix "app_base"

    frame:
        if ('phoneTheme' in vars() or 'phoneTheme' in globals()):
            background phoneTheme
        else:
            background "#8cb5ef"

        ysize 50 + (gui.phone_status_bar_height * bool(phone.config.status_bar))
        top_padding 10 + (gui.phone_status_bar_height * bool(phone.config.status_bar))
        imagebutton auto "phone/assets/Back_%s.png":
            top_padding -5
            action (action, PhoneReturn())
            sensitive phone.menu

        transclude

style app_base_frame is empty:

    background "#fff"
    xfill True
    xpadding 10
    bottom_padding 10

style app_base_hbox is empty:
    spacing 5
    align (0.5, 0.5)

style app_base_text is empty:
    yalign 0.5

    color "#373737" size 19
    font phone.config.basedir + "Aller_Rg.ttf"

style app_base_button is empty:
    yalign 0.5
    xalign 0.0

style app_base_button_text is app_base_text:
    color "#ffffff"
    size 18
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
