screen phone_list():
    default group_chats = phone.data[pov_key]["group_chats"]

    use _phone(usePhoneTheme=True):
        style_prefix "phone_list"
        default characters = phone.character.get_all()


        vbox:
            use app_base():
                style_prefix "app_base"


                if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and (phoneTheme == "#fff" or phoneTheme == "#ffffff"):
                    text _("Contacts") size 19 color "#373737" xalign 0.5 text_align 0.5
                else:
                    text _("Contacts") size 19 color "#fff" xalign 0.5 text_align 0.5
            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame







                vbox:













                    $ group_chat = phone.group_chat.group_chat("ruby2")
                    button:
                        if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                            action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Ruby"))
                        else:
                            action (
                                    SetField(phone.discussion, "_group_chat", group_chat),
                                    SetField(group_chat, "unread", False),
                                    PhoneMenu("phone_discussion")
                                )

                        hbox:
                            add group_chat.icon at _fits(46) yalign 0.5

                            fixed:
                                yalign 0.5
                                spacing 10

                                hbox:
                                    yalign 0.5
                                    xalign 0.5
                                    xoffset -25
                                    text _("Minus"):
                                        if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                            color "#fff"
                                        size 20
                                if ('rubyphonep4inter' in vars() or 'rubyphonep4inter' in globals()):
                                    if rubyphonep4inter:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("rubyphonep4inter")
                                                    )

                                if ('rubytelpretrial' in vars() or 'rubytelpretrial' in globals()) and Episode4:
                                    if rubytelpretrial:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("rubytelpretrial")
                                                    )











                    if Gracepath:
                        add Solid("#000"):
                            xysize (1.0, 1) nearest True

                        $ group_chat = phone.group_chat.group_chat("grace1")
                        button:
                            if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                                action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Grace"))
                            else:
                                action (
                                        SetField(phone.discussion, "_group_chat", group_chat),
                                        SetField(group_chat, "unread", False),
                                        PhoneMenu("phone_discussion")
                                    )

                            hbox:
                                add group_chat.icon at _fits(46) yalign 0.5

                                fixed:
                                    yalign 0.5
                                    spacing 10

                                    hbox:
                                        yalign 0.5
                                        xalign 0.5
                                        xoffset -25
                                        text _("Grace"):
                                            if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                                color "#fff"
                                            size 20

                                    if gracephoneep3s4 == True:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                    SetField(phone.discussion, "_group_chat", group_chat),
                                                    SetField(group_chat, "unread", False),
                                                    Jump("gracephoneep3s4")
                                                    )

                                    if ('gracephonep4intro' in vars() or 'gracephonep4intro' in globals()):
                                        if gracephonep4intro == True:
                                            hbox:
                                                yalign 0.5
                                                xalign 1.0
                                                imagebutton auto "phone/assets/Email_%s.png":
                                                    action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("gracephonep4intro")
                                                        )

                                    if ('gracephonep4inter' in vars() or 'gracephonep4inter' in globals()):
                                        if gracephonep4inter == True:
                                            hbox:
                                                yalign 0.5
                                                xalign 1.0
                                                imagebutton auto "phone/assets/Email_%s.png":
                                                    action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("gracephonep4inter")
                                                        )

                    add Solid("#000"):
                        xysize (1.0, 1) nearest True

                    $ group_chat = phone.group_chat.group_chat("julia1")
                    button:
                        if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                            action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Julia"))
                        else:
                            action (
                                    SetField(phone.discussion, "_group_chat", group_chat),
                                    SetField(group_chat, "unread", False),
                                    PhoneMenu("phone_discussion")
                                )

                        hbox:
                            add group_chat.icon at _fits(46) yalign 0.5

                            fixed:
                                yalign 0.5
                                spacing 10

                                hbox:
                                    yalign 0.5
                                    xalign 0.5
                                    xoffset -25
                                    text _("Julia"):
                                        if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                            color "#fff"
                                        size 20

                                if juliaphoneep3s4:
                                    hbox:
                                        yalign 0.5
                                        xalign 1.0
                                        imagebutton auto "phone/assets/Email_%s.png":
                                            action (
                                                    SetField(phone.discussion, "_group_chat", group_chat),
                                                    SetField(group_chat, "unread", False),
                                                    Jump("juliaphoneep3s4")
                                                )

                                if ('juliaphonep4intro' in vars() or 'juliaphonep4intro' in globals()):
                                    if juliaphonep4intro == True:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("juliaphonep4intro")
                                                        )

                                if ('juliaphonep4inter' in vars() or 'juliaphonep4inter' in globals()) and Episode4:
                                    if juliaphonep4inter == True:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("juliaphonep4inter")
                                                        )

                                if ('juliaphonep5intro' in vars() or 'juliaphonep5intro' in globals()) and Episode5:
                                    if juliaphonep5intro == True:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("juliaphonep5intro")
                                                        )

                    if Madisonphone:
                        add Solid("#000"):
                            xysize (1.0, 1) nearest True

                        $ group_chat = phone.group_chat.group_chat("mad1")
                        button:
                            if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                                action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Madison"))
                            else:
                                action (
                                        SetField(phone.discussion, "_group_chat", group_chat),
                                        SetField(group_chat, "unread", False),
                                        PhoneMenu("phone_discussion")
                                    )


                            hbox:
                                add group_chat.icon at _fits(46) yalign 0.5

                                fixed:
                                    yalign 0.5
                                    spacing 10

                                    hbox:
                                        yalign 0.5
                                        xalign 0.5
                                        xoffset -25
                                        text _("Madison"):
                                            if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                                color "#fff"
                                            size 20

                                    if madphoneep3s4:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("madphoneep3s4")
                                                    )

                    if BlueRelation:
                        add Solid("#000"):
                            xysize (1.0, 1) nearest True

                        $ group_chat = phone.group_chat.group_chat("sofia1")
                        button:
                            if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                                action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Sofia"))
                            else:
                                action (
                                        SetField(phone.discussion, "_group_chat", group_chat),
                                        SetField(group_chat, "unread", False),
                                        PhoneMenu("phone_discussion")
                                    )


                            hbox:
                                add group_chat.icon at _fits(46) yalign 0.5

                                fixed:
                                    yalign 0.5
                                    spacing 10

                                    hbox:
                                        yalign 0.5
                                        xalign 0.5
                                        xoffset -25
                                        text _("Sofia"):
                                            if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                                color "#fff"
                                            size 20

                                    if bluephoneep3s4:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("bluephoneep3s4")
                                                    )

                                    if ('bluephonep4inter' in vars() or 'bluephonep4inter' in globals()):
                                        if bluephonep4inter == True:
                                            hbox:
                                                yalign 0.5
                                                xalign 1.0
                                                imagebutton auto "phone/assets/Email_%s.png":
                                                    action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("bluephonep4inter")
                                                        )

                                    if ('bluephoneep5' in vars() or 'bluephoneep5' in globals()):
                                        if bluephoneep5 == True:
                                            hbox:
                                                yalign 0.5
                                                xalign 1.0
                                                imagebutton auto "phone/assets/Email_%s.png":
                                                    action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("bluephoneep5")
                                                        )

                    add Solid("#000"):
                        xysize (1.0, 1) nearest True

                    $ group_chat = phone.group_chat.group_chat("eli1")
                    button:
                        if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                            action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Elise"))
                        else:
                            action (
                                    SetField(phone.discussion, "_group_chat", group_chat),
                                    SetField(group_chat, "unread", False),
                                    PhoneMenu("phone_discussion")
                                )


                        hbox:
                            add group_chat.icon at _fits(46) yalign 0.5

                            fixed:
                                yalign 0.5
                                spacing 10

                                hbox:
                                    yalign 0.5
                                    xalign 0.5
                                    xoffset -25
                                    text _("Elise"):
                                        if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                            color "#fff"
                                        size 20











                    if GabyPath:
                        add Solid("#000"):
                            xysize (1.0, 1) nearest True

                        $ group_chat = phone.group_chat.group_chat("gaby1")
                        button:
                            if ('Episode4' in vars() or 'Episode4' in globals()) and Episode4:
                                action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Gabriella"))
                            else:
                                action (
                                        SetField(phone.discussion, "_group_chat", group_chat),
                                        SetField(group_chat, "unread", False),
                                        PhoneMenu("phone_discussion")
                                    )


                            hbox:
                                add group_chat.icon at _fits(46) yalign 0.5

                                fixed:
                                    yalign 0.5
                                    spacing 10

                                    hbox:
                                        yalign 0.5
                                        xalign 0.5
                                        xoffset -25
                                        text _("Gabriella"):
                                            if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                                color "#fff"
                                            size 20

                                    if ('gabyphoneep3s4' in vars() or 'gabyphoneep3s4' in globals()) and gabyphoneep3s4:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("gabyphoneep3s4")
                                                    )

                                    if ('gabyphonep4intro' in vars() or 'gabyphonep4intro' in globals()) and gabyphonep4intro:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("gabyphonep4intro")
                                                    )

                    if ('redep4' in vars() or 'redep4' in globals()) and redep4:
                        add Solid("#000"):
                            xysize (1.0, 1) nearest True

                        $ group_chat = phone.group_chat.group_chat("red")
                        button:
                            if ('Episode5' in vars() or 'Episode5' in globals()) and Episode5:
                                action PhoneMenu("phone_biosclicked", CharacterBio.findCharacterByName("Elizabeth"))
                            else:
                                action (
                                        SetField(phone.discussion, "_group_chat", group_chat),
                                        SetField(group_chat, "unread", False),
                                        PhoneMenu("phone_discussion")
                                    )


                            hbox:
                                add group_chat.icon at _fits(46) yalign 0.5

                                fixed:
                                    yalign 0.5
                                    spacing 10

                                    hbox:
                                        yalign 0.5
                                        xalign 0.5
                                        xoffset -25
                                        text _("Elizabeth"):
                                            if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and phoneTheme == "#EA3680":
                                                color "#fff"
                                            size 20

                                    if ('redphonep5intro' in vars() or 'redphonep5intro' in globals()) and redphonep5intro:
                                        hbox:
                                            yalign 0.5
                                            xalign 1.0
                                            imagebutton auto "phone/assets/Email_%s.png":
                                                action (
                                                        SetField(phone.discussion, "_group_chat", group_chat),
                                                        SetField(group_chat, "unread", False),
                                                        Jump("redphonep5intro")
                                                    )

























































style phone_list_side is empty:
    xfill True
    yfill True

style phone_list_frame is empty:
    padding (10, 0, 10, 0)

style phone_list_vbox is empty:
    xfill True
    spacing 0

style phone_list_button is empty:
    xfill True
    hover_background Solid("#e4e4e4")
    ysize 60
    padding (10, 7)

style phone_list_hbox is empty:
    spacing 6

style phone_list_text is empty:
    outlines [ ]

    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"

style phone_list_no_friends is phone_contacts_text:
    color "#000"
    size 20

style phone_list_date_text is phone_contacts_text:
    color "#9d9d9d"
    size 14
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
