transform animUnlockSpecialization:
    xalign 0.5
    yalign 0.5
    linear 0.3 zoom 0.9
    linear 0.7 zoom 1.05
    linear 0.7 zoom 0.9
    repeat

transform animIdleUnlocked:
    linear 0.0 alpha 1.0
    linear 0.7 alpha 0.6
    linear 0.7 alpha 1.0
    repeat

init python:
    skillTreeTutoCounter = 0
    skillTreeTutoLines = [_("Welcome to the B.E.S.T profile"), _("Once you reach 10 points in a stat, you can activate it"), _("Your specialization will have effects during the B.E.S.T contest")]

screen phone_skilltree():
    python:
        if skillTreeTutoCounter >= len(skillTreeTutoLines):
            firstTimeSkillTree = False
            skillTreeTutoCounter = 0

        unlockBuddy = False
        unlockSport = False
        unlockTemperament = False
        unlockEducation = False

        if Buddy >= 10 and firstTimeUnlockedBuddySpecialization:
            unlockBuddy = True
        if Sport >= 10 and firstTimeUnlockedSportSpecialization:
            unlockSport = True
        if Temperament >= 10 and firstTimeUnlockedTemperamentSpecialization:
            unlockTemperament = True
        if Education >= 10 and firstTimeUnlockedEducationSpecialization:
            unlockEducation = True

    use _phone(usePhoneTheme=False):
        style_prefix "phone_skilltree"
        vbox:









            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame

                background "phone/assets/arbre_talents/galaxy_background_skilltree.png"
                if firstTimeSkillTree:
                    xpadding 15
                    ypadding 20
                else:
                    xpadding 10
                    ypadding 10
                yfill True
                xfill True


                if firstTimeSkillTree and (skillTreeTutoCounter < len(skillTreeTutoLines)):
                    button:
                        xfill True
                        yfill True
                        action [SetVariable("skillTreeTutoCounter", skillTreeTutoCounter+1), Function(renpy.restart_interaction)]











                        text skillTreeTutoLines[skillTreeTutoCounter] size 25 color "#fff":
                            yalign 0.5
                            xalign 0.5

                        text _("{i}Click to continue{/i}") size 20 color "#fff" at animIdleUnlocked:
                            xalign 0.5
                            yalign 1.0


                elif unlockBuddy:
                    button:
                        xfill True
                        yfill True
                        action [SetVariable("firstTimeUnlockedBuddySpecialization", False), Function(renpy.restart_interaction)]

                        vbox at animUnlockSpecialization:
                            spacing 25
                            xalign 0.5
                            yalign 0.5

                            text _("You have unlocked the {color=#d90000}Buddy{/color} specialization! You can now enable it!") size 22 color "#fff"

                        text _("Click to continue") size 20 color "#fff" at animIdleUnlocked:
                            xalign 0.5
                            yalign 1.0

                elif unlockTemperament:
                    button:
                        xfill True
                        yfill True
                        action [SetVariable("firstTimeUnlockedTemperamentSpecialization", False), Function(renpy.restart_interaction)]

                        vbox at animUnlockSpecialization:
                            spacing 25
                            xalign 0.5
                            yalign 0.5

                            text _("You have unlocked the {color=#d90000}Temperament{/color} specialization! You can now enable it!") size 22 color "#fff"

                        text _("Click to continue") size 20 color "#fff" at animIdleUnlocked:
                            xalign 0.5
                            yalign 1.0

                elif unlockSport:
                    button:
                        xfill True
                        yfill True
                        action [SetVariable("firstTimeUnlockedSportSpecialization", False), Function(renpy.restart_interaction)]

                        vbox at animUnlockSpecialization:
                            spacing 25
                            xalign 0.5
                            yalign 0.5

                            text _("You have unlocked the {color=#d90000}Sport{/color} specialization! You can now enable it!") size 22 color "#fff"

                        text _("Click to continue") size 20 color "#fff" at animIdleUnlocked:
                            xalign 0.5
                            yalign 1.0


                elif unlockEducation:
                    button:
                        xfill True
                        yfill True
                        action [SetVariable("firstTimeUnlockedEducationSpecialization", False), Function(renpy.restart_interaction)]

                        vbox at animUnlockSpecialization:
                            spacing 25
                            xalign 0.5
                            yalign 0.5

                            text _("You have unlocked the {color=#d90000}Education{/color} specialization! You can now enable it!") size 22 color "#fff"

                        text _("Click to continue") size 20 color "#fff" at animIdleUnlocked:
                            xalign 0.5
                            yalign 1.0


                else:

                    frame:
                        background None
                        xalign 0.5
                        yalign 0.045
                        xsize 100
                        ysize 100


                        if Buddy >= 10 and (not isEnabledBuddySpecialization):
                            imagebutton at animIdleUnlocked:
                                idle "phone/assets/arbre_talents/unlocked_circle.png"
                                hover "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action [SetVariable("isEnabledBuddySpecialization", True), Function(renpy.notify, _("Buddy specialization enabled!")), Function(renpy.restart_interaction)]
                        elif Buddy >= 10 and isEnabledBuddySpecialization:
                            imagebutton:
                                idle "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()
                        else:
                            imagebutton:
                                idle "phone/assets/arbre_talents/locked_circle.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()


                        text "[Buddy]" size 20 color "#fff":


                            xalign 0.5
                            yalign 0.5


                    if Buddy >= 10 and isEnabledBuddySpecialization:
                        add "phone/assets/arbre_talents/vertical_blue_branch.png":
                            xalign 0.5


                            yalign 0.28
                    else:
                        add "phone/assets/arbre_talents/vertical_black_branch.png":
                            xalign 0.5


                            yalign 0.28


                    text _("Buddy") size 20 color "#fff":
                        xalign 0.5

                        yalign 0.20


                    frame:
                        xalign 0.0
                        yalign 0.4
                        xsize 100
                        ysize 100
                        background None


                        if Temperament >= 10 and (not isEnabledTemperamentSpecialization):
                            imagebutton at animIdleUnlocked:
                                idle "phone/assets/arbre_talents/unlocked_circle.png"
                                hover "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action [SetVariable("isEnabledTemperamentSpecialization", True), Function(renpy.notify, _("Temperament specialization enabled!")), Function(renpy.restart_interaction)]
                        elif Temperament >= 10 and isEnabledTemperamentSpecialization:
                            imagebutton:
                                idle "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()
                        else:
                            imagebutton:
                                idle "phone/assets/arbre_talents/locked_circle.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()


                        text "[Temperament]" size 20 color "#fff":


                            xalign 0.5
                            yalign 0.5


                    if Temperament >= 10 and isEnabledTemperamentSpecialization:
                        add "phone/assets/arbre_talents/horizontal_blue_branch.png":
                            xalign 0.35

                            yalign 0.416
                    else:
                        add "phone/assets/arbre_talents/horizontal_black_branch.png":
                            xalign 0.35

                            yalign 0.416


                    text _("Temp.") size 20 color "#fff":
                        xalign 0.05

                        yalign 0.51


                    frame:
                        xalign 1.0
                        yalign 0.4
                        xsize 100
                        ysize 100
                        background None


                        if Education >= 10 and (not isEnabledEducationSpecialization):
                            imagebutton at animIdleUnlocked:
                                idle "phone/assets/arbre_talents/unlocked_circle.png"
                                hover "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action [SetVariable("isEnabledEducationSpecialization", True), Function(renpy.notify, _("Education specialization enabled!")), Function(renpy.restart_interaction)]
                        elif Education >= 10 and isEnabledEducationSpecialization:
                            imagebutton:
                                idle "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()
                        else:
                            imagebutton:
                                idle "phone/assets/arbre_talents/locked_circle.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()


                        text "[Education]" size 20 color "#fff":


                            xalign 0.5
                            yalign 0.5


                    if Education >= 10 and isEnabledEducationSpecialization:
                        add "phone/assets/arbre_talents/horizontal_blue_branch.png":
                            xalign 0.65

                            yalign 0.416
                    else:
                        add "phone/assets/arbre_talents/horizontal_black_branch.png":
                            xalign 0.65

                            yalign 0.416


                    text _("Educ.") size 20 color "#fff":
                        xalign 0.95

                        yalign 0.51


                    frame:
                        background None
                        xalign 0.5
                        yalign 0.7
                        xsize 100
                        ysize 100


                        if Sport >= 10 and (not isEnabledSportSpecialization):
                            imagebutton at animIdleUnlocked:
                                idle "phone/assets/arbre_talents/unlocked_circle.png"
                                hover "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action [SetVariable("isEnabledSportSpecialization", True), Function(renpy.notify, _("Sport specialization enabled!")), Function(renpy.restart_interaction)]
                        elif Sport >= 10 and isEnabledSportSpecialization:
                            imagebutton:
                                idle "phone/assets/arbre_talents/red_circle_enabled.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()
                        else:
                            imagebutton:
                                idle "phone/assets/arbre_talents/locked_circle.png"


                                xalign 0.5
                                yalign 0.5
                                action NullAction()


                        text "[Sport]" size 20 color "#fff":


                            xalign 0.5
                            yalign 0.5


                    if Sport >= 10 and isEnabledSportSpecialization:
                        add "phone/assets/arbre_talents/vertical_blue_branch.png":
                            xalign 0.5

                            yalign 0.53
                    else:
                        add "phone/assets/arbre_talents/vertical_black_branch.png":
                            xalign 0.5

                            yalign 0.53


                    text _("Sport") size 20 color "#fff":
                        xalign 0.5

                        yalign 0.77


                    text _("Get at least {color=#d90000}10 points{/color} of a {color=#d90000}stat{/color} to unlock its {color=#d90000}specialization{/color}!") size 20 color "#fff":
                        yalign 1.0
                        xalign 0.5

                imagebutton auto "phone/assets/Back_%s.png":
                    xalign 0.0
                    yalign 0.03

                    action PhoneReturn()












style phone_skilltree_text is empty:
    outlines [ ]
    color "#525252"
    size 18

    font "gui/HKModular-Bold.ttf"
    justify True
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
