init -100 python in phone.calendar:
    from renpy import store
    from store import _, At, _fits, phone
    from store.phone import system, config
    import calendar

    MONDAY = calendar.MONDAY
    TUESDAY = calendar.TUESDAY
    WEDNESDAY = calendar.WEDNESDAY
    THURSDAY = calendar.THURSDAY
    FRIDAY = calendar.FRIDAY
    SATURDAY = calendar.SATURDAY
    SUNDAY = calendar.SUNDAY

    renpy.const("phone.calendar.MONDAY")
    renpy.const("phone.calendar.TUESDAY")
    renpy.const("phone.calendar.WEDNESDAY")
    renpy.const("phone.calendar.THURSDAY")
    renpy.const("phone.calendar.FRIDAY")
    renpy.const("phone.calendar.SATURDAY")
    renpy.const("phone.calendar.SUNDAY")

    days = (
        _("Monday"),
        _("Tuesday"),
        _("Wednesday"),
        _("Thursday"),
        _("Friday"),
        _("Saturday"),
        _("Sunday")
    )

    renpy.const("phone.calendar.days")

    months = (
        "",
        _("January"),
        _("February"),
        _("March"),
        _("April"),
        _("May"),
        _("June"),
        _("July"),
        _("August"),
        _("September"),
        _("October"),
        _("November"),
        _("December")
    )

    renpy.const("phone.calendar.months")

    class _CalendarEntry(object):
        def __init__(self, day):
            self.day = day
            self.description = None

    class Calendar(calendar.Calendar):
        def __init__(self, month, year=2017, first_day=SUNDAY):
            super(Calendar, self).__init__(first_day)
            
            self.month = month
            self.month_name = months[month]
            self.year = year 
            
            self._m1_calendar__days = [ ]
            self.start_offset = self.end_offset = 0
            
            end = False
            for d in self.itermonthdays(year, month):
                if d == 0:
                    self._m1_calendar__days.append(None)
                    if not end:
                        self.start_offset += 1
                    else:
                        self.end_offset += 1
                else:
                    self._m1_calendar__days.append(_CalendarEntry(d))
                    end = True
        
        def is_day_passed(self, day):
            if not 0 < day <= self.lenght(): return False
            date = system.get_date()
            return (self.year, self.month, day) < (date.year, date.month, date.day)
        
        def lenght(self, offsets=False):
            if offsets: return len(self._m1_calendar__days)
            return self.lenght(True) - self.end_offset - self.start_offset
        
        def get_week_days(self):
            return get_week_days(self.firstweekday)
        
        @property
        def rows(self):
            return self.lenght(True) // 7
        
        def __getitem__(self, i):
            return self._m1_calendar__days[self.start_offset:self.lenght(True) - self.end_offset][i - 1]
        
        def __iter__(self):
            return iter(self._m1_calendar__days)

    def get_week_days(first_day=SUNDAY):
        for i in range(first_day, 7):
            yield days[i]
        
        for i in range(0, first_day):
            yield days[i]

    def day_name(year, month, day):
        return days[calendar.weekday(year, month, day)]

    def add_calendar(calendar, key=None):
        if renpy.is_init_phase():
            phone._run_on_start(renpy.partial(add_calendar, calendar, key), ("_phone_add_calendar", calendar.month, calendar.year, key))
        else:
            key = character.character(key).key
            store.phone.data[key]["calendars"].append(calendar)

    def add_calendar_to_all_characters(calendar):
        if renpy.is_init_phase():
            phone._run_on_start(renpy.partial(add_calendar_to_all_characters, calendar), ("_phone_add_calendar", calendar.month, calendar.year))
        else:
            l = calendar.lenght(False)
            
            for key in character._characters:
                _calendar = Calendar(calendar.month, calendar.year, calendar.firstweekday)
                for i in range(l):
                    _calendar[i].description = calendar[i].description
                
                add_calendar(_calendar, key)

    _calendar_button_background = At(config.basedir + "circle.png", store._fits(None))

    def get_calendar(year, month, key=None):
        key = character.character(key).key
        for calendar in data[key]["calendars"]:
            if calendar.year == year and calendar.month == month:
                return calendar
        return None

screen phone_calendars():
    default calendars = phone.data[pov_key]["calendars"]
    default m = len(calendars) - 1
    default n = m
    default selected_entry = None

    $ calendar = calendars[n]

    use _phone():
        style_prefix "phone_calendar"

        side "t c":
            use app_base():
                style_prefix "app_base"
                text _("Calendar") xalign 0.5 text_align 0.5

            grid 7 calendar.rows + 1 at Flatten xalign 0.5:
                for day in calendar.get_week_days():
                    text __(day)[0] style "phone_calendar_days_text"

                for entry in calendar:
                    if entry is None:
                        null width gui.phone_calendar_button_size
                    else:
                        button:

                            at transform:
                                subpixel True yoffset -15
                                on idle:
                                    matrixcolor BrightnessMatrix(0.0)
                                on hover:
                                    matrixcolor BrightnessMatrix(-0.1)
                                on selected_idle:
                                    matrixcolor BrightnessMatrix(-0.1)
                                on selected_hover:
                                    matrixcolor BrightnessMatrix(-0.2)
                            if calendar.is_day_passed(entry.day):
                                background Transform(phone.calendar._calendar_button_background, matrixcolor=TintMatrix("#9e9e9e"))
                            else:
                                hover_background Transform(phone.calendar._calendar_button_background, matrixcolor=TintMatrix("#e0e0e0"))
                                selected_background Transform(phone.calendar._calendar_button_background, matrixcolor=TintMatrix("#e0e0e0"))
                            action (
                                If(
                                    selected_entry is not entry,
                                    SetScreenVariable("selected_entry", entry),
                                    SetScreenVariable("selected_entry", None)
                                ),
                                SelectedIf(selected_entry is entry)
                            )
                            text str(entry.day) style "phone_calendar_button_text"

                            if entry.description is not None:
                                frame style "empty" align (1.0, 0.0) xysize (16, 16):
                                    background Transform(phone.calendar._calendar_button_background, matrixcolor=TintMatrix("#8f8f8fff"))
                                    text "?" style "phone_calendar_button_text_special":

                                        at transform:
                                            subpixel True
        vbox style_prefix "phone_calendar_notes" yalign 1.0:
            spacing 5

            side "l c r" xalign 0.5:
                textbutton "<" action If(n != 0, (SetScreenVariable("n", n - 1), SetScreenVariable("selected_entry", None)))
                text _("[calendar.month_name]-[calendar.year]") size 25 xalign 0.5 text_align 0.5
                textbutton ">" action If(n != m, (SetScreenVariable("n", n + 1), SetScreenVariable("selected_entry", None)))

            frame:
                has vbox spacing 3 at Flatten
                text _("Notes:") size 22

                viewport:
                    draggable True mousewheel True

                    if selected_entry is not None:
                        if selected_entry.description is not None:
                            text selected_entry.description
                        else:
                            text _("No description provided.")

style phone_calendar_side is empty:
    yfill True xfill True

style phone_calendar_grid is empty:
    spacing 10

style phone_calendar_button is empty:
    xysize (gui.phone_calendar_button_size, gui.phone_calendar_button_size)

style phone_calendar_button_text is empty:
    color "#000"
    outlines []
    size 16
    align (0.5, 0.5) text_align 0.5
    font phone.config.basedir + "Aller_Rg.ttf"

style phone_calendar_button_text_special is phone_calendar_button_text:
    size 12

style phone_calendar_days_text is phone_calendar_button_text:
    size 17

style phone_calendar_notes_side is empty:
    xsize 0.9 xfill True

style phone_calendar_notes_text is empty:
    font "DejaVuSans.ttf"
    color "#000" outlines []
    size 18

style phone_calendar_notes_button is empty:
    yalign 0.5
style phone_calendar_notes_button_text is phone_calendar_notes_text:
    size 21

style phone_calendar_notes_frame is empty:
    background RoundedFrame("#e0e0e0", radius=(0, 25, 0, 25))
    padding (13, 7, 13, 0)
    xfill True ysize 180

style phone_calendar_notes_vbox is empty:
    xfill True

init -50 python in phone.calendar:
    from store.phone import character

init python in phone:
    renpy_config.start_callbacks.append(lambda: setattr(calendar, "data", data))
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
