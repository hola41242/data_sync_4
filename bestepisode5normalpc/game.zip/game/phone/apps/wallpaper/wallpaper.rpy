default wallpapers = [ "phone/assets/ecranbestphone1.png" ]
default currentWallpaper = 0
default currentSelectedWallpaper = store.currentWallpaper

init python:
    def nextWallpaper():
        if store.currentSelectedWallpaper+1 < len(store.wallpapers):
            store.currentSelectedWallpaper += 1
        else:
            store.currentSelectedWallpaper = 0
    def previousWallpaper():
        if store.currentSelectedWallpaper-1 >= 0:
            store.currentSelectedWallpaper -= 1
        else:
            store.currentSelectedWallpaper = len(store.wallpapers)-1
    def setNewWallpaper(newWallpaper):
        store.currentWallpaper = newWallpaper
        renpy.notify(_("Your wallpaper was changed!"))

screen phone_wallpaper():
    use _phone():
        style_prefix "phone_wallpaper"

        side "t c":
            use app_base():
                style_prefix "app_base"


                if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and (phoneTheme == "#fff" or phoneTheme == "#ffffff"):
                    text _("Wallpaper") size 19 color "#373737" xalign 0.5 text_align 0.5
                else:
                    text _("Wallpaper") size 19 color "#fff" xalign 0.5 text_align 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                xpadding 20
                ypadding 20
                background store.wallpapers[store.currentSelectedWallpaper]

                hbox:
                    yalign 0.4


                    vbox:
                        xalign 0.0

                        imagebutton:
                            idle "phone/assets/Back72.png"
                            hover "phone/assets/Back72_hover.png"
                            action Function(previousWallpaper)


                    vbox:
                        xalign 1.0

                        imagebutton:
                            auto "phone/assets/Next_%s.png"
                            action Function(nextWallpaper)

                hbox:
                    yfill True

                    vbox:
                        yalign 0.99
                        xalign 0.5

                        imagebutton:
                            auto "phone/assets/Yes_%s.png"
                            action Function(setNewWallpaper, currentSelectedWallpaper)

style phone_wallpaper_side is empty:
    xfill True
    yfill True

style phone_wallpaper_frame is empty:
    xfill True
    yfill True

style phone_wallpaper_hbox is empty:
    xfill True
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
