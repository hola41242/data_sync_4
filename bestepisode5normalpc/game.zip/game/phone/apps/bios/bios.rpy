init python:



    class CharacterBio:
        def __init__(self, name, bio, hearts, characterPhoto = "", isUnlocked = False, isLoveInterest = False, characterIcon=""):
            self.name = name
            self.bio = bio
            self.hearts = hearts 
            self.characterPhoto = characterPhoto
            self.isUnlocked = isUnlocked
            self.isLoveInterest = isLoveInterest
            self.characterIcon = characterIcon
        
        def upgradeHearts(self):
            self.hearts += 1
        
        def unlock(self):
            self.isUnlocked = True
        
        def findCharacterByName(name):
            for elt in characterBios:
                if elt.name == name:
                    return elt
            return False

    def init_bios():
        
        characterBios.append(CharacterBio("[name]", _("[name]:\n\nJust a regular guy trying to navigate through life and make sense of everything. Sometimes lucky, sometimes clumsy, but always trying to do the right thing... most of the time.")
    , 0, "phone/assets/bios/herosbios.png", True, False, "phone/assets/bios/mc_icon.png"))
        characterBios.append(CharacterBio("Ruby", _("Ruby Suyin:\n\nPlayful and funny, Ruby charms everyone with her spontaneity and natural charisma. A bit scatterbrained but genuine, she lives in the moment and brightens the story with her joyful spirit.")
    , 2, "phone/assets/bios/rubybios.png", True, True, "phone/assets/bios/ruby_icon.png"))
        characterBios.append(CharacterBio("Madison", _("Madison Forrester:\n\nHeiress of the powerful Forrester family, Madison juggles family duties, studies, and motherhood. Strong yet conflicted, she hides her doubts behind a polished facade.")
    , 1, "phone/assets/bios/madibios.png", True, True, "phone/assets/bios/madi_icon.png")) 
        characterBios.append(CharacterBio("Grace", _("Grace Drew:\n\nGrace is kind and selfless, always striving to meet her mother’s high expectations. Her warmth hides the pressure she feels to balance duty and her own desires.")
    , 2, "phone/assets/bios/gracebios.png", True, True, "phone/assets/bios/grace_icon.png")) 
        characterBios.append(CharacterBio("Julia", _("Julia Carter:\n\nReserved and enigmatic, Julia carries a quiet strength that hints at untold stories. Her thoughtful gaze and calm demeanor conceal a world of emotions and secrets, making her both captivating and elusive.")
    , 1, "phone/assets/bios/juliabios.png", True, True, "phone/assets/bios/julia_icon.png"))
        characterBios.append(CharacterBio("Elise", _("Elise Moreau:\n\nElise is the hero's steadfast friend, always ready with sharp wit and sound advice. Loyal and resourceful, she’s a reliable ally who values honesty and isn’t afraid to speak her mind.")
    , 4, "phone/assets/bios/elisebios.png", True, True, "phone/assets/bios/elise_icon.png"))
        characterBios.append(CharacterBio("Gabriella", _("Gabriella Fernandez:\n\nGabriella is a reserved and solitary professor, torn between her strict principles and her growing feelings for the protagonist. Her loneliness fuels her inner turmoil.")
    , 1, "phone/assets/bios/gabybios.png", True, True, "phone/assets/bios/gaby_icon.png"))
        characterBios.append(CharacterBio("Charlotte", _("Charlotte Sinclair:\n\nCharlotte is a free spirit with a rebellious streak, unafraid to challenge norms and live life on her own terms. Her boldness hides a deep desire for connection.")
    , 1, "phone/assets/bios/charlottebios.png", True, True, "phone/assets/bios/charlotte_icon.png"))
        characterBios.append(CharacterBio("Elizabeth", _("Elizabeth ‘Beth’ Da Fonseca:\n\nElisabeth, known as Red, is confident and assertive, always taking charge of any situation. Her dominant personality masks a softer side she rarely shows.")
    , 0, "phone/assets/bios/redbios.png", True, True, "phone/assets/bios/red_icon.png")) 
        characterBios.append(CharacterBio("Sofia", _("Sofia Da Fonseca:\n\nOutgoing and carefree, Sofia embraces life with a lighthearted charm. She’s known for her quick wit and an open mind, often breaking the tension with her humor and spontaneity.")
    , 0, "phone/assets/bios/bluebios.png", True, True, "phone/assets/bios/sofia_icon.png")) 
        characterBios.append(CharacterBio("Kira", _("Kira Orushi:\n\nAdventurous and headstrong, Kira thrives on independence and freedom. As an Orushi, she balances high expectations with her rebellious charm.")
    , 1, "phone/assets/bios/kirabios.png", True, True, "phone/assets/bios/kira_icon.png"))
        characterBios.append(CharacterBio("Emerick", _("Emerick Orushi:\n\nEmerick is cunning and arrogant, always scheming to maintain his status. As a member of the Orushi family, he wields influence but often underestimates those around him.")
    , 0, "phone/assets/bios/emerick_bios.png", True, False, "phone/assets/bios/emerick_icon.png"))
        characterBios.append(CharacterBio("Steven", _("Steven Johnson:\n\nThe captain of the men’s football team, Steven commands respect with his natural authority and calm demeanor. His leadership skills and steady presence make him a cornerstone for his team, both on and off the field.")
    , 0, "phone/assets/bios/stevenbios.png", True, False, "phone/assets/bios/steven_icon.png"))
        characterBios.append(CharacterBio("Mac", _("Mac Harper:\n\nFriendly and easygoing, Mac is the type of guy who can get along with anyone. His laid-back attitude often hides his competitive spirit, which shines through when it comes to sports or a challenge he can’t resist.")
    , 0, "phone/assets/bios/macbios.png", True, False, "phone/assets/bios/mac_icon.png"))
        characterBios.append(CharacterBio("Ben", _("Ben Baker:\n\nLoyal and hardworking, Ben is the kind of person who puts others before himself. Though he often downplays his own achievements, his determination and dedication make him a dependable friend and teammate.")
    , 0, "phone/assets/bios/benbios.png", True, False, "phone/assets/bios/ben_icon.png"))
        characterBios.append(CharacterBio("Hector", _("Hector Alvarez:\n\nRuthlessly ambitious, Hector is willing to do whatever it takes to get ahead. As Emerick’s loyal follower, he often finds himself executing questionable plans, putting his own morals aside to stay in his good graces.")
    , 0, "phone/assets/bios/hectorbios.png", True, False, "phone/assets/bios/hector_icon.png"))
        characterBios.append(CharacterBio("Ted", _("Ted Forrester:\n\nTed is Madison's brother, loyal to the Forrester legacy but often clashing with her over family expectations. His sense of duty masks a more calculating side.")
    , 0, "phone/assets/bios/tedbios.png", False, False, "phone/assets/bios/ted_icon.png"))
        characterBios.append(CharacterBio("Cassie", _("Cassie Forrester:\n\nCassie is Madison’s young daughter, full of energy and curiosity. Her cheerful spirit brings light to Madison’s demanding life, even as she navigates the complexities of her family.")
    , 0, "phone/assets/bios/cassiebios.png", False, False, "phone/assets/bios/cassie_icon.png")) 
        characterBios.append(CharacterBio("Mrs. Drew", _("Mrs. Drew:\n\nMrs. Drew is Grace’s demanding mother, holding her daughter to the highest standards. Behind her strictness lies a deep desire to see Grace succeed, even at the cost of personal warmth.")
    , 1, "phone/assets/bios/drewbios.png", True, False, "phone/assets/bios/drew_icon.png"))
        characterBios.append(CharacterBio("Mr. Orushi", _("Mr. Orushi:\n\nMr. Orushi is the patriarch of the Orushi family, a calculating and authoritative figure who demands loyalty and excellence from everyone around him. His ambition and influence shape both his family and the city.")
    , 0, True, False))
        characterBios.append(CharacterBio("Charles", _("Charles Forrester:\n\nCharles Forrester is the proud patriarch of the Forrester family. Ambitious and commanding, he strives to maintain his family’s dominance in the city, often at the expense of personal relationships")
    , 0, "phone/assets/bios/charlesbios.png", False, False, "phone/assets/bios/charles_icon.png"))
        characterBios.append(CharacterBio("Carmen", _("Carmen Forrester:\n\nCarmen Forrester is the graceful matriarch of the Forrester family. Often acting as a peacemaker, she balances her loyalty to her husband with her compassion for her children.")
    , 0, "phone/assets/bios/carmenbios.png", False, False, "phone/assets/bios/carmen_icon.png"))





screen phone_bios():
    use _phone(usePhoneTheme=True):
        style_prefix "phone_bios"


        vbox:
            use app_base():
                style_prefix "app_base"


                if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and (phoneTheme == "#fff" or phoneTheme == "#ffffff"):
                    text _("Bios") size 19 color "#373737" xalign 0.5 text_align 0.5
                else:
                    text _("Bios") size 19 color "#fff" xalign 0.5 text_align 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame

                if ('phoneTheme' in vars() or 'phoneTheme' in globals()):
                    background phoneTheme
                else:
                    background "#8cb5ef"

                xpadding 15
                ypadding 10


                vbox:
                    spacing 10

                    grid 4 3:
                        xfill True

                        python:
                            loveInterestBios = []
                            nonLoveInterestBios = []
                            for elt in characterBios:
                                if elt.isLoveInterest or elt.name == "[name]":
                                    loveInterestBios.append(elt)
                                else:
                                    nonLoveInterestBios.append(elt)

                        for elt in loveInterestBios:
                            if elt.isUnlocked:
                                button:
                                    background None
                                    hover_background "#cacaca"

                                    if elt.characterIcon != "":
                                        add elt.characterIcon:
                                            fit "contain"
                                    else:
                                        add "phone/assets/default_icon.png":
                                            fit "contain"

                                    action PhoneMenu("phone_biosclicked", elt)

                    frame:
                        background "#3b3b3bff"
                        xfill True
                        ysize 2

                    grid 5 5:
                        xfill True

                        for elt in nonLoveInterestBios:
                            if elt.isUnlocked:
                                button:
                                    background None
                                    hover_background "#cacaca"

                                    if elt.characterIcon != "":
                                        add elt.characterIcon:
                                            fit "contain"
                                    else:
                                        add "phone/assets/default_icon.png":
                                            fit "contain"

                                    action PhoneMenu("phone_biosclicked", elt)

style phone_bios_side is empty:
    xfill True
    yfill True




style phone_bios_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"

screen phone_biosclicked(profile, action=NullAction()):
    use _phone():
        style_prefix "phone_biosclicked"


        vbox:




            viewport:

                draggable True
                mousewheel True
                yfill True

                has frame

                background profile.characterPhoto



                vbox:
                    spacing 15


                    frame:
                        xfill True

                        xpadding 15
                        ypadding 40


                        has hbox
                        xfill True














                        vbox:

                            spacing 20
                            yalign 0.5


                            hbox:
                                if profile.name == "[name]":
                                    text profile.name + " " size 30:
                                        color "#000"
                                else:
                                    text profile.name size 30:
                                        color "#000"


                            if profile.isLoveInterest:
                                $ remainingHearts = 5 - profile.hearts
                                $ relationship_status = " "
                                hbox:
                                    spacing 5

                                    for i in range(profile.hearts):
                                        add "phone/assets/emojis/heart.png":
                                            fit "contain"
                                            xsize 25

                                    for i in range(remainingHearts):
                                        add "phone/assets/emojis/whiteheart_outline.png":
                                            fit "contain"
                                            xsize 25

                                hbox:
                                    spacing 5
                                    xsize 200
                                    if profile.hearts == 0:
                                        $ relationship_status = _("She barely knows you...")
                                    elif profile.hearts == 1:
                                        $ relationship_status = _("You're becoming friends.")
                                    elif profile.hearts == 2:
                                        $ relationship_status = _("You're starting to mean something to her.")
                                    elif profile.hearts == 3:
                                        $ relationship_status = _("You shared a kiss.")
                                    elif profile.hearts == 4:
                                        $ relationship_status = _("A deep bond is forming between you.")
                                    elif profile.hearts == 5:
                                        $ relationship_status = _("Madly in love.")

                                    text "[relationship_status!t]" size 18 italic True color "#525252"


                    frame:

                        xpadding 20



                        has vbox
                        text profile.bio size 18:
                            xsize 200
                            color "#373737"
                            text_align 0.0

                        imagebutton auto "phone/assets/Back_%s.png":
                            top_padding 30
                            action (action, PhoneReturn())
                            sensitive phone.menu















style phone_biosclicked_side is empty:
    xfill True
    yfill True

style phone_biosclicked_frame is empty:
    xfill True

style phone_biosclicked_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
