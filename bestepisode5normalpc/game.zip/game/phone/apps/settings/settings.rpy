screen phone_settings():
    use _phone():
        style_prefix "phone_settings"


        vbox:
            use app_base():
                style_prefix "app_base"


                if ('phoneTheme' in vars() or 'phoneTheme' in globals()) and (phoneTheme == "#fff" or phoneTheme == "#ffffff"):
                    text _("Settings") size 19 color "#373737" xalign 0.5 text_align 0.5:
                        font phone.config.basedir + "Aller_Rg.ttf"
                else:
                    text _("Settings") size 19 color "#fff" xalign 0.5 text_align 0.5:
                        font phone.config.basedir + "Aller_Rg.ttf"

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                xpadding 20
                ypadding 10
                background "#252525"







                vbox:
                    spacing 10


                    vbox:
                        spacing 10

                        hbox:
                            if persistent.patch_installed:
                                vbox:
                                    style_prefix "radio"
                                    text _("Walkthrough"):
                                        font "gui/Genos-Bold.ttf"

                                    textbutton _("ON") action [SetField(persistent, "patch_enabled", True), SelectedIf(persistent.patch_enabled)]
                                    textbutton _("OFF") action [SetField(persistent, "patch_enabled", False), SelectedIf(not persistent.patch_enabled)]

                        vbox:


                            text _("Textbox Transparency")
                            bar value FieldValue(persistent, "textbox_transparency", range=1.0, style="slider")


                        vbox:

                            if config.has_music:
                                text _("Music Volume")

                                hbox:
                                    bar value Preference("music volume")

                            if config.has_sound:

                                text _("Sound Volume")

                                hbox:
                                    bar value Preference("sound volume")

                                    if config.sample_sound:
                                        textbutton _("Test") action Play("sound", config.sample_sound)

                            textbutton _("Mute All"):
                                action Preference("all mute", "toggle")
                                style "mute_all_button"


                    if ('phoneTheme' in vars() or 'phoneTheme' in globals()):

                        vbox:
                            spacing 10

                            text _("Phone Theme") size 30:
                                font "gui/Genos-Bold.ttf"
                                color "#fff"


                            hbox:
                                spacing 5


                                if phoneTheme == "#ffffff":
                                    button:
                                        xsize 41
                                        ysize 41
                                        background "#0099CC"
                                        action NullAction()

                                        add Solid("#ffffff"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5
                                else:
                                    button:
                                        xsize 41
                                        ysize 41
                                        background None
                                        hover_background "#0099CC"
                                        action [SetVariable("phoneTheme", "#ffffff"), renpy.restart_interaction]

                                        add Solid("#ffffff"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5


                                if phoneTheme == "#8cb5ef":
                                    button:
                                        xsize 41
                                        ysize 41
                                        background "#0099CC"
                                        action NullAction()

                                        add Solid("#8cb5ef"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5
                                else:
                                    button:
                                        xsize 41
                                        ysize 41
                                        background None
                                        hover_background "#0099CC"
                                        action [SetVariable("phoneTheme", "#b5cef2"), renpy.restart_interaction]

                                        add Solid("#8cb5ef"):
                                            xalign 0.5
                                            yalign 0.5
                                            xsize 38
                                            ysize 38


                                if phoneTheme == "#EA3680":
                                    button:
                                        xsize 41
                                        ysize 41
                                        background "#0099CC"
                                        action NullAction()

                                        add Solid("#EA3680"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5
                                else:
                                    button:
                                        xsize 41
                                        ysize 41
                                        background None
                                        hover_background "#0099CC"
                                        action [SetVariable("phoneTheme", "#EA3680"), renpy.restart_interaction]

                                        add Solid("#EA3680"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5
























































                                if phoneTheme == "#b7b7b7":
                                    button:
                                        xsize 41
                                        ysize 41
                                        background "#0099CC"
                                        action NullAction()

                                        add Solid("#b7b7b7"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5
                                else:
                                    button:
                                        xsize 41
                                        ysize 41
                                        background None
                                        hover_background "#0099CC"
                                        action [SetVariable("phoneTheme", "#b7b7b7"), renpy.restart_interaction]

                                        add Solid("#b7b7b7"):
                                            xsize 38
                                            ysize 38
                                            xalign 0.5
                                            yalign 0.5

                    add Solid("#252525"):

                        ysize 260

style phone_settings_side is empty:
    xfill True
    yfill True

style phone_settings_frame is empty:
    xfill True

style phone_settings_text is empty:
    outlines [ ]

    color "#fff"
    size 25

    font "gui/Genos-Bold.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
