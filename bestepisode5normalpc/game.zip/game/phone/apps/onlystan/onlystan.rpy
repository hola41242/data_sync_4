init python:
    from copy import deepcopy



    onlystanComments = []
    onlystanPosts = []
    onlystanProfiles = []


    class OnlystanProfile:
        counter = 0
        
        def __init__(self, name, nickname, bio = "No bio yet!", profilePhoto = None, contacts = []):
            self.name = name
            self.nickname = nickname
            self.profilePhoto = profilePhoto
            self.bio = bio
            self.contacts = contacts
            
            OnlystanProfile.counter += 1
            self.id = OnlystanProfile.counter
        
        def findProfileByNickname(nick):
            for elt in onlystanProfiles:
                if elt.nickname == nick:
                    return elt
            return False
        
        def findProfileID(profileID):
            for elt in onlystanProfiles:
                if elt.id == profileID:
                    return elt
            return False
        
        def getAllPosts(self):
            posts = []
            if ('onlystanV2' in vars() or 'onlystanV2' in globals()) and onlystanV2:
                for elt in onlystanPostsInScript:
                    if elt.posterID == self.id:
                        posts.append(elt)
            else:
                for elt in onlystanPosts:
                    if elt.posterID == self.id:
                        posts.append(elt)
            return posts
        
        
        
        
        
        
        
        
        def getAllComments(self):
            comments = []
            for elt in onlystanComments:
                if elt.senderID == self.id:
                    comments.append(elt)
            return comments
        
        def getAllContacts(self):
            contacts = []
            for elt in self.contacts:
                contacts.append()
            return contacts
        
        def hasInContacts(self, profileID):
            for elt in self.contacts:
                if profileID == elt.id:
                    return True
            return False
        
        def addContact(self, contactID):
            self.contacts.append(contactID)

    class OnlystanComment:
        counter = 0
        
        def __init__(self, text, senderID, postID, isMCComment=False):
            self.text = text
            self.senderID = senderID
            self.postID = postID
            self.isMCComment = isMCComment
            
            OnlystanComment.counter += 1
            self.id = OnlystanComment.counter
        
        def getPost(self):
            post = False
            for elt in onlystanPosts:
                if elt.id == self.postID:
                    return elt
            return False
        
        def getSender(self):
            for elt in onlystanProfiles:
                if elt.id == self.senderID:
                    return elt
            return False

    class OnlystanComment2:
        def __init__(self, text, senderID, postTag, isMCComment=False):
            self.text = text
            self.senderID = senderID
            self.postTag = postTag
            self.isMCComment = isMCComment
            
            self.id = len(onlystanCommentsInScript)+1
        
        def getPost(self):
            post = False
            for elt in onlystanPostsInScript:
                if elt.tag == self.postTag:
                    return elt
            return False
        
        def getSender(self):
            for elt in onlystanProfiles:
                if elt.id == self.senderID:
                    return elt
            return False

    class OnlystanPost:
        counter = 0
        
        def __init__(self, text, title, posterID, image = None, mcComment = "", commentSent = False):
            self.text = text
            self.title = title
            self.image = image
            self.mcComment = mcComment
            self.posterID = posterID
            self.commentSent = commentSent
            
            OnlystanPost.counter += 1
            self.id = OnlystanPost.counter
            
            if mcComment != "":
                self.commentToSend = OnlystanComment(self.mcComment, 1, self.id, True)
            else:
                self.commentToSend = None
        
        def getAllComments(self):
            comments = []
            
            for elt in onlystanComments:
                if elt.postID == self.id:
                    comments.append(elt)
            return comments
        
        def getPoster(self):
            for elt in onlystanProfiles:
                if elt.id == self.posterID:
                    return elt
            return False
        
        def getAllCommentators(self):
            comments = self.getAllComments()
            commentators = []
            for elt in comments:
                commentators.append(elt.getSender())
            return commentators
        
        def sendMCComment(self):
            onlystanComments.append(self.commentToSend)
            self.commentSent = True

    class OnlystanPost2:
        def __init__(self, text, title, posterID, image = None, tag = "", mcComment = "", commentSent = False):
            self.text = text
            self.title = title
            self.image = image
            self.mcComment = mcComment
            self.posterID = posterID
            self.commentSent = commentSent
            self.tag = tag
            
            self.id = len(onlystanPostsInScript)+1
            
            if mcComment != "":
                self.commentToSend = OnlystanComment2(self.mcComment, 1, self.tag, True)
            else:
                self.commentToSend = None
        
        def getAllComments(self):
            comments = []
            
            for elt in onlystanCommentsInScript:
                if elt.postTag == self.tag:
                    comments.append(elt)
            return comments
        
        def getPoster(self):
            for elt in onlystanProfiles:
                if elt.id == self.posterID:
                    return elt
            return False
        
        def getAllCommentators(self):
            comments = self.getAllComments()
            commentators = []
            for elt in comments:
                commentators.append(elt.getSender())
            return commentators
        
        def sendMCComment(self):
            onlystanCommentsInScript.append(self.commentToSend)
            self.commentSent = True


    def init_onlystan():
        onlystanProfiles.append(OnlystanProfile("[name]", "[nickname]", _("A simple boy who just want to meet friends here :)"), "phone/assets/mciconbig.png"))
        onlystanProfiles.append(OnlystanProfile("Fanny", "funnyfanny", _("A simple girl who likes simple things"), "phone/assets/fannyprofilephoto.png"))
        onlystanProfiles.append(OnlystanProfile("Mark Bicdeek", "markbicdeek", _("Pretty girls out there!")))
        onlystanProfiles.append(OnlystanProfile("Joe Hyujkawk", "joehyujkawk", _("Here to meet beautiful young girls 🤤!")))
        
        onlystanProfiles.append(OnlystanProfile("Ben Dover", "bendover", _("Just a flexible guy looking for fun!")))
        onlystanProfiles.append(OnlystanProfile("Anita Hug", "anitahug", _("Feeling lonely, let's chat and share good vibes ❤️!")))
        onlystanProfiles.append(OnlystanProfile("Mike Oxmall", "mikeoxmall", _("Big dreams, small beginnings. Let's connect!")))
        onlystanProfiles.append(OnlystanProfile("Hugh Jass", "hughjass", _("I bring the sass to OnlyStan 😎.")))
        onlystanProfiles.append(OnlystanProfile("Pat Myback", "patmyback", _("Always here to support you 😉.")))
        onlystanProfiles.append(OnlystanProfile("Ivana Tinkle", "ivanatinkle", _("Busy and bubbly, ready for fun! 💦")))
        onlystanProfiles.append(OnlystanProfile("Willie B. Hardigan", "williebhardigan", _("Just a guy with a big heart (and maybe more...) 😏.")))
        onlystanProfiles.append(OnlystanProfile("Seymour Butts", "seymourbutts", _("What can I say? I'm a cheeky kind of guy 😜!")))
        
        
        onlystanProfiles[0].addContact(2)
        
        
        onlystanPosts.append(OnlystanPost(_("Hello! My name is Fanny and I am new here. Tell me what you like in the comments ;)"), _("Hi everyone :)!"), 2, "phone/assets/fanny.png", _("Very beautiful! I'm very happy to meet you there 😊")))
        onlystanPosts.append(OnlystanPost("", _("Beach day! 🌴🏖️"), 2, "phone/assets/fannyplaya.jpg", _("Take me with you next time 😂! I love your outfit btw")))
        onlystanPosts.append(OnlystanPost("", _("Preparing for a party with my best friend 💕"), 2, "phone/assets/fannyprepa.jpg", _("A party? Count me in! Just tell me where and when, I’ll bring the good vibes 🎉!")))
        
        
        
        
        
        
        
        
        
        
        onlystanComments.append(OnlystanComment(_("Pretty girl 🤤"), 3, 1))
        onlystanComments.append(OnlystanComment(_("Hey ! I love your body... Would you like to get to know each other 😉?"), 4, 1))
        onlystanComments.append(OnlystanComment(_("My D is still so hard seeing you 🥵🥵"), 3, 2))
        onlystanComments.append(OnlystanComment(_("I am so honoured to breath the same air as you 🥵😍"), 4, 3))
        
        
        onlystanComments.append(OnlystanComment(_("I'm bending over backwards just to comment here 😉"), 5, 1))  
        onlystanComments.append(OnlystanComment(_("You look like someone who needs a hug 🥰"), 6, 1))  
        onlystanComments.append(OnlystanComment(_("Ben, you're always bending over for attention 🤦‍♀️"), 6, 1))  
        onlystanComments.append(OnlystanComment(_("Anita, don’t be so mean! Everyone deserves a little flexibility 😏"), 7, 1))  
        
        
        onlystanComments.append(OnlystanComment(_("Wow, this is small talk at its finest 😏"), 7, 2))  
        onlystanComments.append(OnlystanComment(_("This beach photo is making waves 🌊!"), 8, 2))  
        onlystanComments.append(OnlystanComment(_("Hugh, you're just fishing for compliments again 🎣"), 12, 2))  
        onlystanComments.append(OnlystanComment(_("Seymour, let him enjoy the tide, it's not every day we get such views 😎"), 9, 2))  
        
        
        onlystanComments.append(OnlystanComment(_("Party with friends? Save me a spot next time! 🎉"), 11, 3))  
        onlystanComments.append(OnlystanComment(_("Willie, you weren't invited last time for a reason... 😒"), 10, 3))  
        onlystanComments.append(OnlystanComment(_("Ivana, don't be salty, we all know Willie likes to party hard 😉"), 6, 3))  
        onlystanComments.append(OnlystanComment(_("Anita, you're the life of the party, admit it ❤️!"), 5, 3))  
        
        
        onlystanComments.append(OnlystanComment(_("Hard to resist such beauty 😏🔥"), 11, 1))  
        onlystanComments.append(OnlystanComment(_("Always here to have your back ❤️"), 9, 2))  
        onlystanComments.append(OnlystanComment(_("Cheeky post! Keep them coming 😜"), 12, 2))  
        onlystanComments.append(OnlystanComment(_("This made me tinkle with laughter 💦"), 10, 3))  



    def addOnlystanPost(text, title, posterID, image = None, tag = "", mcComment = "", commentSent = False):
        global onlystanPostsInScript, onlystanCommentsInScript
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        onlystanPostsInScript.append(OnlystanPost2(text, title, posterID, image, tag, mcComment, commentSent))
        return True

    def addOnlystanComment(text, senderID, postTag, isMCComment=False):
        global onlystanCommentsInScript
        
        
        if len(onlystanCommentsInScript) > 0:
            onlystanCommentsInScript = [elt for elt in onlystanCommentsInScript if elt.text != text]
        onlystanCommentsInScript.append(OnlystanComment2(text, senderID, postTag, isMCComment))
        return True

    def findPostByTag(tag):
        for elt in onlystanPostsInScript:
            if elt.tag == tag:
                return elt
        return False

    def existsPost(tag):
        for elt in onlystanPostsInScript:
            if elt.tag == tag:
                return True
        return False

    init_onlystan()

screen phone_onlystan():
    use _phone():
        style_prefix "phone_onlystan"


        vbox:
            use app_base():
                style_prefix "app_base"

                add "phone/assets/oslogofulltext.png":
                    fit "contain"
                    xsize 120
                    xalign 0.5
                    yalign 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                xpadding 15
                ypadding 10
                background "#fff"


                vbox:
                    spacing 25


                    vbox:
                        spacing 15
                        xfill True










                        hbox:
                            xfill True

                            text __("Welcome back, ") + str(onlystanProfiles[0].nickname) + "!" size 30:
                                color "#373737"
                                xalign 0.5


                    if ('onlystanV2' in vars() or 'onlystanV2' in globals()) and onlystanV2 == True:
                        $ sortedPosts = sorted(onlystanPostsInScript, key=lambda post: post.id, reverse=True)
                    else:
                        $ sortedPosts = sorted(onlystanPosts, key=lambda post: post.id, reverse=True)

                    for elt in sortedPosts:

                        vbox:
                            spacing 7


                            hbox:
                                xfill True


                                button:
                                    hbox:
                                        spacing 20

                                        if elt.getPoster().profilePhoto is not None:
                                            add elt.getPoster().profilePhoto:
                                                fit "contain"
                                                xsize 60
                                        else:
                                            add "phone/assets/default_icon.png":
                                                fit "contain"
                                                xsize 60


                                        vbox:
                                            text elt.getPoster().name size 20:
                                                color "#000000"

                                            text "@" + elt.getPoster().nickname size 14:
                                                color "#373737"

                                    action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", elt.getPoster())]


                            vbox:
                                xfill True
                                spacing 7


                                if elt.title != "":
                                    text elt.title size 22:
                                        color "#373737"


                                if elt.image is not None:
                                    imagebutton:

                                        at transform:
                                            xsize 1.0 subpixel True
                                            fit "scale-down"
                                        idle elt.image
                                        background "#525252"
                                        padding (15, 15)
                                        action Show("_phone_image", dissolve, img=elt.image)

                                if elt.text != "":
                                    text "[elt.text!t]" size 15:
                                        color "#373737"


                                hbox:
                                    textbutton _("See comments"):
                                        text_size 20
                                        text_color "#4285f4"
                                        text_hover_color "#75a2eb"
                                        action [PhoneReturn(), PhoneMenu("phone_onlystanpostcomment", elt)]


                    vbox:
                        xfill True
                        add Solid("#ffffff"):
                            ysize 70


            fixed:
                frame:
                    xalign 0.0
                    yalign 1.0
                    background "#f2f2f2"

                    has hbox
                    xalign 0.5
                    xfill True







                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/home_idle.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action NullAction()
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/list42.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystancontacts")]
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/osmcprofilebutton.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", onlystanProfiles[0])]

style phone_onlystan_side is empty:
    xfill True
    yfill True

style phone_onlystan_frame is empty:
    xfill True




style phone_onlystan_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"


screen phone_onlystanpostcomment(post):
    use _phone():
        style_prefix "phone_onlystanpostcomment"


        vbox:
            use app_base():
                style_prefix "app_base"

                add "phone/assets/oslogofulltext.png":
                    fit "contain"
                    xsize 120
                    xalign 0.5
                    yalign 0.5
            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame
                xpadding 15
                ypadding 15
                background "#fff"


                vbox:
                    spacing 40


                    vbox:
                        spacing 7


                        hbox:
                            xfill True


                            button:
                                hbox:
                                    spacing 20

                                    if post.getPoster().profilePhoto is not None:
                                        add post.getPoster().profilePhoto:
                                            fit "contain"
                                            xsize 60
                                    else:
                                        add "phone/assets/default_icon.png":
                                            fit "contain"
                                            xsize 60


                                    vbox:
                                        text post.getPoster().name size 20:
                                            color "#000000"

                                        text "@" + post.getPoster().nickname size 14:
                                            color "#373737"

                                action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", post.getPoster())]


                        vbox:
                            xfill True
                            spacing 7


                            if post.title != "":
                                text "[post.title!t]" size 22:
                                    color "#373737"


                            if post.image is not None:
                                imagebutton:

                                    at transform:
                                        xsize 1.0 subpixel True
                                        fit "scale-down"
                                    background "#525252"
                                    padding (15, 15)
                                    idle post.image
                                    action Show("_phone_image", dissolve, img=post.image)


                            if post.text != "":
                                text "[post.text!t]" size 15:
                                    color "#373737"


                    vbox:
                        spacing 20


                        text _("Comments") size 30:
                            color "#373737"

                        $ currentComments = post.getAllComments()


                        vbox:
                            xfill True
                            spacing 20

                            if not currentComments:
                                text _("No comments") size 23:
                                    color "#696969"
                                    xalign 0.5

                            else:
                                for elt in currentComments:

                                    hbox:
                                        spacing 15


                                        button:
                                            if elt.getSender().profilePhoto is not None:
                                                add elt.getSender().profilePhoto:
                                                    fit "contain"
                                                    xsize 40
                                            else:
                                                add "phone/assets/default_icon.png":
                                                    fit "contain"
                                                    xsize 40
                                            action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", elt.getSender())]


                                        vbox:
                                            spacing 7
                                            textbutton "{b}@" + str(elt.getSender().nickname) + "{/b}":
                                                text_size 14
                                                text_color "#373737"
                                                action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", elt.getSender())]

                                            text "[elt.text!t]" size 14:
                                                color "#373737"

                        vbox:
                            if post.mcComment != "" and not post.commentSent:
                                textbutton _("+ Add comment"):
                                    text_size 20
                                    text_color "#4285f4"
                                    text_hover_color "#75a2eb"
                                    action [Function(post.sendMCComment), Function(renpy.restart_interaction)]



                    vbox:
                        xfill True
                        add Solid("#ffffff"):
                            ysize 200


            fixed:
                frame:
                    xalign 0.0
                    yalign 1.0
                    background "#f2f2f2"

                    has hbox
                    xalign 0.5
                    xfill True

                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/home_idle.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystan")]
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/list42.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystancontacts")]
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/osmcprofilebutton.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", onlystanProfiles[0])]









style phone_onlystanpostcomment_side is empty:
    xfill True
    yfill True

style phone_onlystanpostcomment_frame is empty:
    xfill True

style phone_onlystanpostcomment_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"


screen phone_onlystanprofile(profile):
    use _phone():
        style_prefix "phone_onlystanprofile"


        vbox:
            use app_base():
                style_prefix "app_base"

                add "phone/assets/oslogofulltext.png":
                    fit "contain"
                    xsize 120
                    xalign 0.5
                    yalign 0.5
            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame


                background "#fff"


                vbox:
                    spacing 15


                    frame:
                        background "#f2f2f2"
                        xpadding 15
                        ypadding 15


                        has vbox
                        xfill True
                        spacing 15


                        hbox:
                            xfill True


                            vbox:
                                spacing 15


                                if profile.profilePhoto is not None:
                                    add profile.profilePhoto:
                                        fit "contain"
                                        xsize 100
                                else:
                                    add "phone/assets/default_icon.png":
                                        fit "contain"
                                        xsize 100


                                vbox:
                                    text profile.name size 20:
                                        color "#000"

                                    text "@" + profile.nickname size 14:
                                        color "#373737"










                        hbox:
                            text "[profile.bio!t]" size 17:
                                color "#373737"


                    frame:
                        xpadding 15
                        ypadding 15

                        has vbox
                        spacing 15
                        xfill True

                        $ sortedPosts = sorted(profile.getAllPosts(), key=lambda post: post.id, reverse=True)


                        if not sortedPosts:
                            text _("No posts") size 30:
                                color "#373737"
                                xalign 0.5

                        else:

                            text _("Posts") size 30:
                                color "#373737"

                            vbox:
                                spacing 25
                                xfill True


                                for elt in sortedPosts:

                                    vbox:
                                        spacing 7


                                        hbox:
                                            xfill True


                                            button:
                                                hbox:
                                                    spacing 20

                                                    if elt.getPoster().profilePhoto is not None:
                                                        add elt.getPoster().profilePhoto:
                                                            fit "contain"
                                                            xsize 60
                                                    else:
                                                        add "phone/assets/default_icon.png":
                                                            fit "contain"
                                                            xsize 60


                                                    vbox:
                                                        text elt.getPoster().name size 20:
                                                            color "#000000"

                                                        text "@" + elt.getPoster().nickname size 14:
                                                            color "#373737"

                                                action NullAction()


                                            hbox:
                                                xalign 1.0


                                        vbox:
                                            xfill True
                                            spacing 7


                                            if elt.title != "":
                                                text "[elt.title!t]" size 22:
                                                    color "#373737"


                                            if elt.image is not None:
                                                imagebutton:

                                                    at transform:
                                                        xsize 1.0 subpixel True
                                                        fit "scale-down"
                                                    background "#525252"
                                                    padding (15, 15)
                                                    idle elt.image
                                                    action Show("_phone_image", dissolve, img=elt.image)


                                            if elt.text != "":
                                                text "[elt.text!t]" size 15:
                                                    color "#373737"


                                            hbox:
                                                textbutton _("See comments"):
                                                    text_size 20
                                                    text_color "#4285f4"
                                                    text_hover_color "#75a2eb"
                                                    action [PhoneReturn(), PhoneMenu("phone_onlystanpostcomment", elt)]


                    vbox:
                        xfill True
                        add Solid("#ffffff"):
                            ysize 200


            fixed:
                frame:
                    xalign 0.0
                    yalign 1.0
                    background "#f2f2f2"

                    has hbox
                    xalign 0.5
                    xfill True

                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/home_idle.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystan")]
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/list42.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystancontacts")]
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/osmcprofilebutton.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            if profile.id == onlystanProfiles[0].id:
                                action NullAction()
                            else:
                                action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", onlystanProfiles[0])]

style phone_onlystanprofile_side is empty:
    xfill True
    yfill True

style phone_onlystanprofile_frame is empty:
    xfill True

style phone_onlystanprofile_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"


screen phone_onlystancontacts():
    use _phone():
        style_prefix "phone_onlystancontacts"


        vbox:
            use app_base():
                style_prefix "app_base"

                add "phone/assets/oslogofulltext.png":
                    fit "contain"
                    xsize 120
                    xalign 0.5
                    yalign 0.5

            viewport:
                draggable True
                mousewheel True
                yfill True

                has frame


                background "#fff"


                vbox:
                    spacing 25

                    frame:
                        xpadding 15
                        ypadding 15


                        text _("Contacts") size 30:
                            color "#373737"


                    vbox:
                        for elt in onlystanProfiles[0].contacts:
                            $ currentProfile = OnlystanProfile.findProfileID(elt)

                            button:
                                background "#fff"
                                hover_background "#c4c4c4"
                                action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", currentProfile)]

                                has frame
                                xpadding 15
                                ypadding 15
                                xfill False
                                background None

                                hbox:
                                    xfill True


                                    hbox:
                                        spacing 20

                                        if currentProfile.profilePhoto is not None:
                                            add currentProfile.profilePhoto:
                                                fit "contain"
                                                xsize 60
                                        else:
                                            add "phone/assets/default_icon.png":
                                                fit "contain"
                                                xsize 60


                                        vbox:
                                            yalign 0.5

                                            text currentProfile.name size 20:
                                                color "#000000"

                                            text "@" + str([currentProfile.nickname]) size 14:
                                                color "#373737"











                    vbox:
                        xfill True
                        add Solid("#ffffff"):
                            ysize 340


            fixed:
                frame:
                    xalign 0.0
                    yalign 1.0
                    background "#f2f2f2"

                    has hbox
                    xalign 0.5
                    xfill True

                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/home_idle.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystan")]
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/list42.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action NullAction()
                    hbox:
                        xalign 0.5
                        imagebutton:
                            idle "phone/assets/osmcprofilebutton.png"
                            padding (10, 10)
                            background "#f2f2f2"
                            hover_background "#c4c4c4"
                            action [PhoneReturn(), PhoneMenu("phone_onlystanprofile", onlystanProfiles[0])]

style phone_onlystancontacts_side is empty:
    xfill True
    yfill True

style phone_onlystancontacts_frame is empty:
    xfill True

style phone_onlystancontacts_text is empty:
    outlines [ ]
    color "#525252"
    size 18
    font phone.config.basedir + "Aller_Rg.ttf"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
