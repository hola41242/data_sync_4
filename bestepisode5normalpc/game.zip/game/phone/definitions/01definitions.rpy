

default pc_d = phone.character.Character("[name]", phone.config.basedir + "mciconbig.png", "d", 35, "#484848")
default pc_sofia = phone.character.Character("Sofia", phone.config.basedir + "sofia_icon.png", "sofia", 20, "#a327d6")
default pc_grace = phone.character.Character("Grace", phone.config.basedir + "grace_icon.png", "grace", 40, "#c41935")
default pc_julia = phone.character.Character("Julia", phone.config.basedir + "julia_icon.png", "julia", 45, "#9b3d8d")
default pc_ruby = phone.character.Character("Ruby", phone.config.basedir + "ruby_icon.png", "ruby", 50, "#126bd1")
default pc_elise = phone.character.Character("Elise", phone.config.basedir + "elisep.png", "elise", 40, "#c41935")
default pc_ji = phone.character.Character("???", phone.config.basedir + "default_icon.png", "ji", 40, "#3019c4")
default pc_mad = phone.character.Character("Madison", phone.config.basedir + "mad.png", "mad", 40, "#c41935")
default pc_gaby = phone.character.Character("Gabriella", phone.config.basedir + "gaby.png", "gaby", 50, "#126bd1")

default pc_kira = phone.character.Character("Kira", phone.config.basedir + "kira_icon.png", "kira", 25, "#a327d6")
default pc_red = phone.character.Character("Red", phone.config.basedir + "beth_icon.png", "beth", 25, "#d62727")
default pc_cha = phone.character.Character("Charlotte", phone.config.basedir + "charlotte_icon.png", "cha", 50, "#98249a")
default pc_evelyn = phone.character.Character("Evelyn", phone.config.basedir + "evelyneport1.png", "evelyn", 50, "#c41616")
default pov_key = "d"


define phone_ruby = Character("Ruby", screen="phone_say", who_style="phone_say_label", what_style="phone_say_dialogue")
define phone_d = Character("[name]", screen="phone_say", who_style="phone_say_label", what_style="phone_say_dialogue")











init 700 init phone register:
    define "Ruby":
        add "ruby" add "d"
        icon phone.config.basedir + "ruby_icon.png"
        as discussion_ruby key "ruby1"

init 700 init phone register:
    define "Minus":
        add "ruby" add "d"
        icon phone.config.basedir + "ruby_icon.png"
        as discussion_ruby2 key "ruby2"

init 700 init phone register:
    define "Grace":
        add "grace" add "d"
        icon phone.config.basedir + "grace_icon.png"
        as discussion_grace key "grace1"

init 700 init phone register:
    define "Sofia":
        add "sofia" add "d"
        icon phone.config.basedir + "sofia_icon.png"
        as discussion_sofia key "sofia1"

init 700 init phone register:
    define "Elise":
        add "elise" add "d"
        icon phone.config.basedir + "elisep.png"
        as discussion_eli key "eli1"

init 700 init phone register:
    define "???":
        add "ji" add "d"
        icon phone.config.basedir + "default_icon.png"
        as discussion_ji key "ji1"

init 700 init phone register:
    define "Julia":
        add "julia" add "d"
        icon phone.config.basedir + "julia_icon.png"
        as discussion_julia key "julia1"

init 700 init phone register:
    define "Madison": 
        icon phone.config.basedir + "mad.png"
        as discussion_mad key "mad1"

init 700 init phone register:
    define "Gabriella":
        icon phone.config.basedir + "gaby.png"
        as discussion_gaby key "gaby1"

init 700 init phone register:
    define "Kira":

        icon phone.config.basedir + "kira_icon.png"
        as discussion_kira key "kira2"

init 700 init phone register:
    define "Red":
        icon phone.config.basedir + "beth_icon.png"
        as discussion_red key "red"

init 700 init phone register:
    define "Charlotte":
        icon phone.config.basedir + "charlotte_icon.png"
        as discussion_cha key "cha1"

init 700 init phone register:
    define "Evelyn":
        icon phone.config.basedir + "evelyneport1.png"
        as discussion_evelyn key "evelyn1"

label phone_discussion_ruby:
    phone discussion "ruby1":
        time year 2023 month 9 day 2 hour 22 minute 30 
        "ruby" "Can you hear me, now ?"
        "d" "Yes ! You know this is only text, right ?"
        "ruby" "Good ! Of course , mister serious, haha !"
        "ruby" "Are you ready for tomorrow ?"
        "d" "For what ?"
        "ruby" "Economics class !"
        "d" "Oh ! Yeah ! Sure..."
        "ruby" "Don't worry... Gabriella is an angel..."
        "d" "Gabriella... The Milf ?"
        "ruby" "Ahah ! Yeah... But don't tell her that please..."
        "ruby" "I'm not sure she would be pleased by that..."
        "d" "No I won't ! I'm not stupid !"
        "ruby" "And with Julia ???"
        "d" "What's about Julia ?"
        "ruby" "Come on !!! You two were all around the campus together this afternoon !"
        "d" "How do you know that ?"
        "ruby" "I've got my eyes everywhere"
        image "ruby" Movie(play="phone/assets/rubyeyes.webm")
        "d" "You are crazy !"
        "ruby" "I know !"
        "ruby" "So ???"
        "d" "So... what ?"
        "ruby" "Julia !!!"
        menu:
            "I'm not interested by her...":
                $ JuliaPath = False
                "d" "I'm not interested in her..."
                "ruby" "Oh..."
            "She's cute...":
                $ JuliaPath = True
                "d" "She's cute..."
                "ruby" "Great ! I think she likes you too !"
                "d" "How do you know that ?"
                "ruby" "Told you... I'm everywhere !"
        "ruby" "Okay... time to sleep !"
        "ruby" "See ya Cortex !"
        "d" "See you... Minus..."
    phone end discussion

    return

label phone_discussion_grace:
    phone discussion "grace1":
        time year 2023 month 9 day 2 hour 22 minute 35 
        "grace" "Hey !"
        "d" "Hey... ! "
        "grace" "Sorry for my mom..."
        "d" "Don't worry ! there's really no problem..."
        "grace" "May I ask you a question ?"
        "d" "Sure you can !"
        "grace" "Okay..."
        "grace" "Were you trying to kiss me ?"
        menu: 
            "Yes...":
                $ Gracepath = True
                "d" "Yes..."
                "d" "I couldn't resist..."
                if GraceBlue == True:
                    "grace" "Even if you just spent time with Blue ?"
                    "d" "Oh you heard that ?"
                    "grace" "How could I miss it... I could hear her moans all around the pool !"
                    "d" "Sorry..."
                else:
                    "d" "Sorry if it was too pushy..."
                    "grace" "NO ! I mean..."
            "No...":
                $ Gracepath = False
                "d" "No..."
                "grace" "Oh ?"
                "grace" "Okay..."
        "grace" "I should sleep... It's late..."
        "d" "Yeah me too..."
        "grace" "See you tomorrow !"
        "d" "Sure ! See you tomorrow !"
        "d" "Good night Grace..."
        "grace" "Good night [name]"        
    phone end discussion

    return

label phone_discussion_sofia:
    phone discussion "sofia1":
        time year 2023 month 9 day 2 hour 22 minute 40 
        "sofia" "Hey my lord !"
        "d" "I didn't think you would text me tonight ! "
        "sofia" "Yeah I know..."
        "sofia" "I can't forget what you did to me earlier..."
        "sofia" "My pussy is so sore..."
        "d" "I told you ! "
        "sofia" "I know... I know..."
        "sofia" "But I need more..."
        "sofia" "Well, I think I need rest..."
        "d" "Will you come to the party Friday ?"
        "sofia" "Of course ! You ?"
        "d" "Sure !"
        "sofia" "Seems we might spend some time together..."

        menu: 
            "Can't wait...":
                "d" "Can't wait !"
                "sofia" "Me neither..."
                "sofia" "Take this for your waiting time !"
                image "sofia" "phone/assets/sofiacall.jpg"

            "I don't care...":
                "d" "I don't care... "
                "sofia" "Oh ? Okay..."
                "d" "..."

        "sofia" "See you ! Handsome..."
        "d" "See you, my slutty one..."   

    phone end discussion

    return

label phone_discussion_eli:
    phone discussion "eli1":
        time year 2023 month 9 day 3 hour 14 minute 00
        "elise" "Hey the american ! Tell me when you're here !"
        "d" "Yes ? Leonardo speaking ?"
    phone end discussion

    return

label phone_discussion_ruby2:
    phone discussion "ruby2":
        time year 2023 month 9 day 3 hour 15 minute 00
        "ruby" "Hey! Are you asleep?"
        "d" "Nah, I was about to go do a little training at the stadium."
        "ruby" "Oh...."
        "d" "Why? What's up?"
        "ruby" "Well, I don't have anything to wear to the party."
        "ruby" "I was thinking of going to Red's Store to try on some nice dresses."
        "d" "Uh, yeah... and?"
        "ruby" "Well, I wanted your opinion on what you think looks good on me!"
        "d" "Oh, okay. Well..."
        menu:
            "Sure. I'll come with.[TEMP1!t]":
                $ Redstore = True
                "d" "I would happy to help"
                "ruby" "Really? You're coming for real?"
                "d" "Yeah. I said I was. I'll be there."
                "ruby" "Ohhh, that's awesome!!!"
                "ruby" "Give me ten minutes and I'll meet you in front of the store?"
                "d" "Sounds good, see you in a bit."

            "I have to workout first.[TEMP2!t]":
                $ Redstore = False
                "d" "I'm sorry, I really need to focus on my training. Maybe next time?"
                "ruby" "No? Pretty please with a cherry on top? "
                "d" "Okay, okay. You win. We can go when I am done training."
                "ruby" "Ohhh, that's awesome! Thank you!"
                "ruby" "We'll meet in front of the store, okay?"
                "d" "Okay, see ya!"
                "ruby" "I'll be waiting!"

    phone end discussion

    return

label phone_discussion_ji:
    phone discussion "ji1":
        time year 2023 month 9 day 3 hour 23 minute 10
        "ji" "Continue like that [name], you're doing great."
        "d" "Who are you?"
        "ji" "Someone that can help you... or not..."
        "ji" "All will depend on you."
        "d" "where did you get my phone number?"
        "ji" "This question isn't relevant..."
        "ji" "Do as I say and you will win this contest."
        "ji" "Don't and..."
        "ji" "You won't... And your girls neither"
        "d" "What? My girls?"
        "ji" "You will have some fresh news soon."
        "ji" "Keep the good work [name]"
        "d" "But what's your name?"
    phone end discussion

    return

label phone_discussion_julia:
    phone discussion "julia1":
        time year 2023 month 9 day 4 hour 8 minute 35
        "d" "Hey! How's it going?"
        "julia" "Hi! My back's still a bit sore..."
        "d" "Oh... Hope you're up for the next game!"
        "julia" "Yeah... I'm gonna stay in today."
        "julia" "I already called the academy to let them know I got hurt yesterday."
        "d" "Oh... okay."
        "d" "What about Grace's party?"
        "julia" "I'll be there, but I won't stay late."
        "d" "Ah..."
        "d" "So... see you there?"
        "julia" "Definitely! See ya!"
    phone end discussion

    return

label phone_discussion_mad:

    $ phone.group_chat.group_chat("mad1").add_character(["mad", "d"])
    phone discussion "mad1":
        time year 2023 month 9 day 5 hour 17 minute 35
        "d" "Hi Madison, it's [name]!"
        "d" "Just a quick message to check if this is the right number..."
        "mad" "It is."
        "d" "Okay..."
        "d" "How was your afternoon?"
        "mad" "Apart from the kilo of modeling clay on my fingers..."
        "mad" "It's fine!"
        "mad" "I'm running late though..."
        "d" "Okay, I won't bother you any longer! See you later!"
        "mad" "++"
    phone end discussion

    return

label phone_discussion_gaby:
    $ phone.group_chat.group_chat("gaby1").add_character(["gaby", "d"])
    phone discussion "gaby1":
        time year 2023 month 9 day 5 hour 17 minute 35
        "d" "Hi Gabriella, it's [name]!"
        "d" "Just a quick message to check if this is the right number..."
        "gaby" "I told you only in case of emergency!"
        "d" "Uh... Yes, but how do I know if it's the right number?"
        "d" "In an emergency, I might not have time to check!"
        "gaby" "Fair point..."
        "gaby" "Enjoy your evening!"
        "gaby" "And be on time tomorrow!"
        "d" "No worries!"
    phone end discussion

    return

label phone_discussion_kira:
    $ phone.group_chat.group_chat("kira2").add_character(["kira", "d"])
    $ phone.menu = False
    phone discussion "kira2":
        time year 2023 month 9 day 6 hour 21 minute 55
        "kira" "Hey! Just got your contact info from OS!"
        "d" "Oh okay!"
        "kira" "We're heading to Palazio tomorrow."
        "kira" "Wanna come with us?"
        menu:
            "Sure. I'll come along!":
                $ KiraPalazio = True
                "d" "That'd be awesome, yeah!"
                "kira" "I'll send you the address if you want."
                "d" "Great!"

            "No, thank you!":
                $ KiraPalazio = False
                "kira" "Oh? Alright."
                "d" "I'd rather rest up for the competition."
                "kira" "No worries. I get it!"
        if madipath == False and Gracepath == False:
            "kira" "Hummm... Totally out of place but..."
            "kira" "Do you have had an affair with Red at the party? "
            menu:
                "Yes":
                    $ Redpath = True
                    "d" "Yeah. Why?"
                    "kira" "Oh, just to know. I was curious if it was true!"
                    "d" "Okay..."
                "No":
                    $ Redpath = False
                    "d" "No. Why?"
                    "kira" "Oh, just to know. I was just curious!"
                    "d" "Okay..."

            "kira" "Well, see you!"
            "d" "See you!"


    phone end discussion

    return

label phone_discussion_beth:
    $ phone.group_chat.group_chat("red").add_character(["beth", "d"])
    $ phone.menu = False
    phone discussion "red":
        time year 2023 month 9 day 7 hour 23 minute 00
        "d" "Here’s the message you asked for!"
        "beth" "Perfect."
        "d" "That’s it?"
        "beth" "What were you expecting?"
        "beth" "This way I don’t have to enter your info manually. It does everything by itself."
        "d" "Oh..."
        "d" "I mean, we could have used this as an excuse to talk... get to know each other..."
        "d" "Right?"
        "beth" "No."
        "d" "Well, I guess tonight’s not the night I’ll get a photo of you then?"
        "beth" "A photo? Why would I send you a photo?"
        "d" "I don’t know. So I can have something of yours."
        "beth" "Something of mine."
        "beth" "Let me think about it."
        "d" "Take your time, I’m patient."
        "beth" "Yeah, sure. Keep dreaming..."
        image "beth" "phone/assets/redphone1.png"
        "beth" "This is all you will have from me."
        "d" "Wait, seriously? A cleavage shot... and a toilet in the background?"
        "d" "You’re truly one of a kind, Beth."
        "beth" "Take it or leave it."
        "d" "Oh, I’m keeping it. It’ll be the highlight of my collection."
        "beth" "Good night, [name]. Enjoy staring at your phone."
        "d" "Good night, Beth."
        $ wallpapers.append("phone/assets/redphone1.jpg")
        $ renpy.notify (_("A wallpaper has been added"))      
    phone end discussion

    return

label phone_discussion_cha:
    $ phone.group_chat.group_chat("cha1").add_character(["cha", "d"])
    $ phone.menu = False
    phone discussion "cha1":
        time year 2023 month 9 day 7 hour 23 minute 20
        "cha" "Hey, you!"
        "d" "Yeah?"
        "cha" "You think I didn't see you spying on us at the Palazio earlier?"
        "d" "That's nonsense!"
        "cha" "Yeah, yeah..."
        "cha" "I totally figured out that Gabriella was talking about you, you know!"
        "d" "I have no idea what you're talking about."
        "cha" "Of course you don’t."
        "cha" "I'm gonna set something up. You'll thank me later!"
        "d" "What are you gonna do?"
        "cha" "I have my little idea. Anyway, good night!"
        "d" "Good night!"

    phone end discussion

    return

label phone_discussion_evelyn:
    $ phone.group_chat.group_chat("evelyn1").add_character(["evelyn", "d"])
    $ phone.menu = False
    phone discussion "evelyn1":
        time year 2023 month 9 day 9 hour 20 minute 10
        "d" "Hi Evelyn, it's me from the Palazio. I just wanted to say you really caught my attention last night."
        "evelyn" "Well, well. I wasn’t sure if you’d actually message me."
        "d" "I almost didn’t, but then I thought, what’s life without a little risk?"
        "evelyn" "A bold move. I like that."
        "d" "And here I thought you might enjoy a little intrigue in your day."
        "evelyn" "Intrigue… and confidence. You might be onto something."
        "evelyn" "Why don’t we see if you’re as bold in person as you are over text?"
        "d" "Sounds like a challenge. What do you have in mind?"
        "evelyn" "There’s a cozy café on River Street. Meet me there tomorrow night. 7 PM."
        "d" "I’ll be there."
        "evelyn" "Good. I’ll see you then."
        $ Evelyncafe = True
    phone end discussion

    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
