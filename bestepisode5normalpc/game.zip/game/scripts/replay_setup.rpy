


init python:

    maxthumbx = config.screen_width / (3 + 1)
    maxthumby = config.screen_height / (3 + 1)

    replay_page = 0

    class ReplayItem:
        def __init__(self, thumbs, replay, name):
            self.thumbs = thumbs
            self.replay = replay
            self.name = name
        
        def num_replay(self):
            return len(self.thumbs)



    Replay_items = []
    Replay_items.append(ReplayItem(["Rthumb1"], "intro", "{color=#FFFFFF}Intro{/color}"))
    Replay_items.append(ReplayItem(["Rthumb2"], "dream", "{color=#FFFFFF}Dream{/color}"))
    Replay_items.append(ReplayItem(["Rthumb3"], "redkiss", "{color=#FFFFFF}Redkiss{/color}"))
    Replay_items.append(ReplayItem(["Rthumb4"], "bluejob", "{color=#FFFFFF}Bluejob{/color}"))
    Replay_items.append(ReplayItem(["Rthumb5"], "sofiapool", "{color=#FFFFFF}Evolution{/color}"))
    Replay_items.append(ReplayItem(["Rthumb6"], "gracekiss2", "{color=#FFFFFF}First Kiss{/color}"))
    Replay_items.append(ReplayItem(["Rthumb7"], "vestiairesfinep2", "{color=#FFFFFF}One Time Thing{/color}"))
    Replay_items.append(ReplayItem(["Rthumb8"], "redshop", "{color=#FFFFFF}Redshop{/color}"))
    Replay_items.append(ReplayItem(["Rthumb9"], "Charlottetime", "{color=#FFFFFF}Back to the back{/color}"))
    Replay_items.append(ReplayItem(["Rthumb10"], "bluebathsequence", "{color=#FFFFFF}Make Up{/color}"))
    Replay_items.append(ReplayItem(["Rthumb11"], "stay_with_beth", "{color=#FFFFFF}Poker Face{/color}"))
    Replay_items.append(ReplayItem(["Rthumb12"], "fingraceep3", "{color=#FFFFFF}Like a virgin...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb13"], "ep4elevator", "{color=#FFFFFF}Up and Down...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb14"], "madicarep4", "{color=#FFFFFF}Two Time...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb15"], "ep4p2s1", "{color=#FFFFFF}First Time...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb16"], "ep4p2s2", "{color=#FFFFFF}Second round...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb17"], "redep5s1", "{color=#FFFFFF}Game of Control...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb18"], "sexygracee5s2", "{color=#FFFFFF}Natural Climbing...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb19"], "e5s5_massage_chagaby", "{color=#FFFFFF}Milfy City...{/color}"))
    Replay_items.append(ReplayItem(["Rthumb20"], "e5s5_massage_gaby_main", "{color=#FFFFFF}Recovery...{/color}"))








image black = "#000000"


image replay_locked = "images/replay/gallery0.jpg"




image Rthumb1 = ("images/replay/intro.jpg")
image Rthumb2 = ("images/replay/juliadream.jpg")
image Rthumb3 = ("images/replay/j27.jpg")
image Rthumb4 = ("images/replay/k18.jpg")
image Rthumb5 = ("images/replay/pool87.jpg")
image Rthumb6 = ("images/replay/fingrace28.jpg")
image Rthumb7 = ("images/replay/finmad8.jpg")
image Rthumb8 = ("images/replay/redshop.jpg")
image Rthumb9 = ("images/replay/charep.jpg")
image Rthumb10 = ("images/replay/bluebathscreen2.jpg")
image Rthumb11 = ("images/replay/finred14.jpg")
image Rthumb12 = ("images/replay/grace1.jpg")
image Rthumb13 = ("images/replay/ascensor.jpg")
image Rthumb14 = ("images/replay/madipreviewep4.jpg")
image Rthumb15 = ("images/replay/gracesexep43.jpg")
image Rthumb16 = ("images/replay/bluejob2.jpg")
image Rthumb17 = ("images/replay/e5s1red28.jpg")
image Rthumb18 = ("images/replay/e5s2grace21_edited.jpg")
image Rthumb19 = ("images/replay/e5gabycha8_edited.jpg")
image Rthumb20 = ("images/replay/e5gaby37_edited.jpg")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
