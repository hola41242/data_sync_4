label e1s4:

show text _ ("2 minutes before the race starts...") at truecenter
with dissolve
pause 3
scene i1
with dissolve
dpense "The girls went to change in the locker room."
scene i2
with dissolve
dpense "I don't have any gear, thankfully I'm wearing sweatpants..."
scene i3
with dissolve
dpense "Well... they told me to take the path to the small forest towards the stadium..."
scene i4
with dissolve
dpense "I'm going to follow the others who seem to be going that way..."
scene black
with dissolve
pause 1

$ renpy.movie_cutscene("images/animation/trial.webm", stop_music=False)

scene i5
with dissolve
dpense "Wow, this is something else..."
dpense "Well, looks like I'll have to jump, do the beam, and climb a super-high wall..."
scene i6
with dissolve
dpense "It's like an obstacle course..."

scene black
with dissolve
pause 1
show text _ ("1 minute before the race starts...") at truecenter
pause 2
scene i7
with dissolve
d "What are they doing?"
dpense "Didn't he say the race starts in exactly 10 minutes?"
scene i8
with dissolve
play music "musique/PunchDeck_Destabilized.mp3" volume 0.20
d "Oh yeah... okay..."
scene i10
with dissolve
pause 2
scene i91980
with dissolve
pause 2

if madtrial == True:
    scene i15
    with dissolve
    mad "Be ready, as soon as the bell rings we go straight..."
    d "I'm ready for it... Nice outfit..."
    scene i13:
        xalign 0.0
        linear 5.0 yalign 0.5
        linear 1.0 yalign 0.1
        repeat 1
    with dissolve
    mad "Yeah, well keep your eyes in front of you!"

if rubytrial == True:
    scene i17
    with dissolve
    ruby "Did you miss me?"
    d "Um, yeah let's say that... I was mostly worried you'd be late."
    scene i14:
        xalign 0.0
        linear 5.0 yalign 0.5
        linear 1.0 yalign 0.1
        repeat 1
    with dissolve
    pause 2
    ruby "Well, actually Grace was struggling with her outfit... so we lost a bit of time..."
    d "Hum... talking about outfit... What is this one ?"
    ruby "Oh !!! It's my Kimono Style !"
    d "Kimono Style ? But we're not on a tatami !"
    ruby "I know but my running outfit is... I lost it..."
    d "Ruby..."
    scene i19
    with dissolve
    pause 1
    ruby "Don't worry ! That will increase my agility !"

if juliatrial == True:
    scene i16
    with dissolve
    julia "So, are you ready?"
    d "Yeah, I can't wait to see what you're capable of!"
    scene i11
    with dissolve
    pause 2
    julia "It's more about what YOU are capable of!"
    d "Don't worry about me."

if gracetrial == True:
    scene i18
    with dissolve
    grace "Sorry, we almost ran late..."
    d "As long as you're here before the race starts it's all good!"
    scene i12:
        xalign 0.0
        linear 5.0 yalign 0.5
        linear 1.0 yalign 0.1
        repeat 1
    with dissolve
    pause 2
    grace "My outfit wasn't very easy to put on..."
    d "It looks amazing! You look like Lara Croft!"
    grace "Yeah, well I'm not as agile as her!"
    d "And yet look at what's in front of us!"
    grace "We'll take it step by step and it should be okay."

scene i20
with dissolve
pause 1
d "You're stretching ?"
scene i21
with dissolve
pause 1
ruby "Yeah ! Don't know what we will have to do so..."
scene i22
with dissolve
pause 1
ruby "Do you think they'll play a certain sound for the start of the race?"
d "I'm not sure it's really that important..."
scene i23
with dissolve
pause 1
ruby "No, but I mean, will it be like a song, like 'I'm a survivor'? Or a big horn? Or something else..."

play sound "sound/air-horn-club-sample_1.mp3" volume 1.0

scene i24
with dissolve
ruby "That answers my question."
scene i25
with dissolve
d "Huh???"
scene i26
with dissolve
pause 2
scene i27
with dissolve
pause 2
scene i28
with dissolve
pause 2
scene i29
with dissolve
pause 2
scene i30
with dissolve
dpense "Okay..."
pause 2
scene i31
with dissolve
dpense "Have to jump..."
pause 2
scene i32
with dissolve
dpense "Don't waste time...."
pause 2
scene i33
with dissolve
dpense "Don't fall now..."
pause 2
scene i34
with dissolve
dpense "Madison..."
pause 1
scene i35
with dissolve
dpense "She's fast !!!"
pause 1
scene i36
with dissolve
pause 1
scene i37
with dissolve
pause 1
scene i38
with dissolve
pause 1
scene i39
with dissolve
with hpunch
julia "AHHHHH !"
if persistent.patch_enabled:
    if persistent.rufus5 == False:
        $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))

if persistent.patch_enabled == True:
    $ TEMP1 = e1s4m1c1
    $ TEMP2 = e1s4m1c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""

if madtrial == True:
    menu:
        "Help Julia [TEMP1!t]":
            scene i40
            with dissolve
            pause 1
            scene i41
            with dissolve
            if Pervert == True:
                julia "Pervert... but a gentleman !"
                d "I'm not..."
                julia "I know Handsome !"
            else:
                julia "Thank you !"
                d "No problem..."
                julia "I knew you were a gentleman !"
            call buddy_increased from _call_buddy_increased_3
            $ Rank = Rank-10
            $ Aidejulia = True
            $ Aidepoutre = False
            jump trial2
        "Continue [TEMP2!t]":

            if persistent.rufus5 == False:
                scene i401 with dissolve
                show screen chat5() with dissolve
            else:
                scene i401
                with dissolve
            dpense "I must join Madison !"
            $ Aidejulia = False
            $ Aidepoutre = False
            $ Rank = Rank-5
            call sport_increased from _call_sport_increased_15
            hide screen chat5
            jump trial2
else:
    menu:
        "Help Julia [TEMP1!t]":
            scene i40
            with dissolve
            pause 1
            scene i41
            with dissolve
            if Pervert == True:
                julia "Pervert... but a gentleman !"
                d "I'm not..."
                julia "I know Handsome !"
            else:
                julia "Thank you !"
                d "No problem..."
                julia "I knew you were a gentleman !"
            call buddy_increased from _call_buddy_increased_4
            $ Rank = Rank-10
            $ Aidejulia = True
        "Continue [TEMP2!t]":

            if persistent.rufus5 == False:
                scene i401 with dissolve
                show screen chat5() with dissolve
            else:
                scene i401
                with dissolve
            pause 2
            dpense "I must join Madison !"
            call sport_increased from _call_sport_increased_16
            $ Rank = Rank-5
            $ Aidejulia = False
            $ Aidepoutre = False
            jump trial2

    if persistent.patch_enabled == True:
        $ TEMP1 = e1s4m2c1
        $ TEMP2 = e1s4m2c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Help the girls [TEMP1!t]":
            d "Gimme your hand, girls!"
            scene i42
            with dissolve
            pause 1
            scene i43
            with dissolve
            pause 1
            grace "Thanks !"
            scene i44
            with dissolve
            pause 1
            scene i45
            with dissolve
            pause 1
            ruby "Gracias !"
            call sport_increased from _call_sport_increased_2
            $ Aidepoutre = True
            jump trial2
        "Continue [TEMP2!t]":

            $ Aidepoutre = False
            jump trial2

label trial2:

scene i46
with dissolve
pause 2
scene i47
with dissolve
pause 2
scene i48
with dissolve
pause 2
scene black
with dissolve
pause 1
scene i49
with dissolve
pause 1

if persistent.patch_enabled == True:
    $ TEMP1 = e1s4m3c1
    $ TEMP2 = e1s4m3c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""
menu:
    "Do it like Madison [TEMP1!t]" if Temperament >= 3:
        scene i50
        with dissolve
        pause 2
        scene i51
        with dissolve
        with vpunch
        pause 2
        $ Rank = Rank-5
        $ Aidemur = False
        call sport_increased from _call_sport_increased_3
        jump trial3
    "Help the girls [TEMP2!t]":

        d "Jump ! I'll give you a boost !"
        scene i52
        with dissolve
        pause 2
        scene i54
        with dissolve
        pause 2
        scene i57
        with dissolve
        pause 2
        scene i53
        with dissolve
        pause 2
        scene i55
        with dissolve
        pause 2
        call buddy_increased from _call_buddy_increased_5
        $ Aidemur = True
        $ Rank = Rank-10
        scene i56
        with dissolve
        pause 2
        scene i50
        with dissolve
        pause 2
        scene i51
        with dissolve
        with vpunch
        pause 2

        jump trial3

label trial3:

if madtrial == True:
    scene i58
    with dissolve
    pause 1.0
    scene i59
    with dissolve
    pause 1

    if persistent.patch_enabled == True:
        $ TEMP1 = e1s4m4c1
        $ TEMP2 = e1s4m4c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Join Madison [TEMP1!t]" if Sport >=3:
            scene i60
            with dissolve
            pause 1
            d "Madison ! Where is the stadium ?"
            mad "Just after the hill !"
            call education_increased from _call_education_increased_4
            scene i61
            with dissolve
            pause 2
            scene black
            with dissolve
            pause 2
            jump trial4
        "Encourage Madison [TEMP2!t]":


            d "Come on Madison ! We can do it !"
            call buddy_increased from _call_buddy_increased_6
            scene black
            with dissolve
            pause 2
            jump trial4
else:

    scene i63
    with dissolve
    pause 1
    scene i62
    with dissolve
    pause 1

    if persistent.patch_enabled == True:
        $ TEMP1 = e1s4m5c1
        $ TEMP2 = e1s4m5c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Join Julia [TEMP1!t]" if Sport >= 4:
            scene i63
            with dissolve
            pause 1
            d "Julia ! Where is the stadium ?"
            if Aidejulia == True:
                julia "Just after the hill !"
                $ Rank = Rank-10
                call sport_increased from _call_sport_increased_5
                scene i64
                with dissolve
                pause 2
                scene black
                with dissolve
                pause 2
                jump trial4
            else:

                scene i63
                with dissolve
                pause 1
                julia "You didn't help me... Why should I help you ?"
                julia "Now... Go away !"
                dpense "Okay... she's angry at me..."
                $ Rank = Rank-5
                scene black
                with dissolve
                pause 1
                d "Come on girls ! We can do it !"
                call buddy_increased from _call_buddy_increased_7
                scene i65
                with dissolve
                pause 2
                scene black
                with dissolve
                pause 2
                jump trial4
        "Encourage Girls [TEMP2!t]":


            d "Come on girls ! We can do it !"
            call buddy_increased from _call_buddy_increased_16
            scene i65
            with dissolve
            pause 2
            scene black
            with dissolve
            pause 2
            jump trial4

label trial4:

stop music fadeout 2
pause 2
play music "musique/Stellardrone-ToTheGreatBeyond.mp3" volume 0.2
scene black
with dissolve
pause 1

drew "YOU MUST FIND YOUR LUGGAGE AND LEAVE WITH IT WHEN YOU REACH THE AUDITORIUM."
pause 1

if madtrial == True:
    scene i66
    with dissolve
    pause 2
    scene i68
    with dissolve
    pause 2
    d "Hum... Okay... But where do we find the luggage in a big stadium like this ?"
    scene i67
    with dissolve
    pause 2
    mad "Open your eyes, Genius..."
    scene i69
    with dissolve
    pause 2
    d "Hum ? Oh !!!"
    scene black
    $ renpy.movie_cutscene("images/animation/sacs.webm", stop_music=False)
    scene i70
    with dissolve
    pause 2
    mad "No...!"
    scene i71
    with dissolve
    pause 2
    mad "No, no, no, no !"
    scene i72
    with dissolve
    pause 1
    mad "Run !!!" with hpunch
    scene i73
    with dissolve
    pause 1
    scene i74
    with dissolve
    pause 1
    scene i75
    with dissolve
    pause 1
    scene i76
    with dissolve
    pause 1
    emerick "Madison ! Don't run ! You will lose as always !"
    mad "You shouldn't be so confident dickhead !"
    dpense "Wow... Seems they're not friends..."
    scene i77
    with dissolve
    pause 2
    mad "But how do we know which one is ours?"
    d "I don't know."
    mad "There are numbers on each one."
    scene i78
    with dissolve
    pause 1
    d "Numbers ?"
    dpense "Come on [name]... Think !"
    dpense "There must be a clue somewhere..."
    scene i79
    with dissolve
    pause 1

    if persistent.patch_enabled == True:
        $ TEMP1 = e1s4m6c1
        $ TEMP2 = e1s4m6c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Remember [TEMP1!t]" if Education >= 2:
            play sound "sound/Rewind.mp3" volume 1.0
            scene black
            with dissolve
            pause 1
            scene e22
            with dissolve
            drew "You're just a number in a file. In this case, you're the 90th."
            pause 1
            scene e19
            with dissolve
            d "90th ? 90th of what ?"
            pause 1
            drew "I've already told you too much... Tomorrow you will understand."
            pause 1
            scene black
            with dissolve
            pause 1
            scene i80
            with dissolve
            pause 1
            d "Wait, Ms. Drew told me I'm number 90!"
            mad "Number 90 of what?"
            d "I don't know, but she said I'd understand what it means today!"
            mad "If you're 90, then I must have a number too!"
            scene i81
            with dissolve
            pause 1
            d "84...67...90...Is this it? Yes!"
            d "I found mine!"
            scene i82
            with dissolve
            pause 1
            scene i83
            with dissolve
            pause 1
            mad "Come on, Madison, think..."
            d "If she told me that, she must have given you a clue too..."
            scene i84
            with dissolve
            pause 1
            mad "Number 10 ! "
            mad "She usually calls me the 10 of spades ! Cause I'm number 10 in the team !"
            scene black
            with dissolve
            pause 1
            mad "Got it!"
            $ Rank = Rank-20
            $ prem = True
            jump trial5
        "Wait for girls [TEMP2!t]":

            scene i80
            with dissolve
            pause 1
            d "Girls will arrive...Grace may know what to do !"
            scene black
            with dissolve
            pause 1
            scene i85
            with dissolve
            pause 1
            grace "My mom gave all of us a number! I didn't understand why it was important but now I know!"
            grace "All bags have a number... you must find yours !"
            d "A number?"
            grace "Yes! When you saw her, she must have told you something! Remember!"
            scene i78
            with dissolve
            pause 1
            dpense "Come on [name]... Think !"
            dpense "You must have a clue somewhere..."
            scene i79
            with dissolve
            pause 1
            scene black
            with dissolve
            play sound "sound/Rewind.mp3" volume 1.0
            pause 1
            scene e22
            with dissolve
            drew "You're just a number in a file. In this case, you're the 90th."
            pause 1
            scene e19
            with dissolve
            d "90th ? 90th of what ?"
            pause 1
            drew "I've already told you too much... Tomorrow you will understand."
            pause 1
            scene black
            with dissolve
            pause 2
            scene i82
            with dissolve
            pause 1
            d "The 90 ! I got it"
            $ Rank = Rank-5
            $ prem = False
            jump trial5
else:


    scene i68
    with dissolve
    pause 2
    d "Luggage ? What luggage ?"
    scene i86
    with dissolve
    pause 1
    scene i87
    with dissolve
    pause 1
    ruby "I think there is something over there !"
    scene i69
    with dissolve
    pause 2
    scene black
    $ renpy.movie_cutscene("images/animation/sacs.webm", stop_music=False)
    scene i85
    with dissolve
    pause 1
    grace "My mom gave all of us a number ! I didn't understand why it was important but now I know!"
    grace "It's our team number girls !"
    grace "All bags have a number... you must find yours !"
    d "A number?"
    grace "Yes! When you saw her, she must have told you something! Remember!"
    scene i78
    with dissolve
    pause 1
    dpense "Come on [name]... Think !"
    dpense "You must have a clue somewhere..."
    scene i79
    with dissolve
    pause 1
    scene black
    with dissolve
    pause 1
    play sound "sound/Rewind.mp3" volume 1.0
    scene e22
    with dissolve
    drew "You're just a number in a file. In this case, you're the 90th."
    pause 1
    scene e19
    with dissolve
    d "90th ? 90th of what ?"
    pause 1
    drew "I've already told you too much... Tomorrow you will understand."
    pause 1
    scene black
    with dissolve
    pause 2
    scene i82
    with dissolve
    pause 1
    d "The 90 ! I got it"
    grace "I have mine too !"
    ruby "Yes ! Me too !"
    julia "Same here !"
    $ Rank = Rank-5
    $ prem = False
    jump trial5

label trial5:


if madtrial == True:
    scene i88
    with dissolve
    pause 1
    mad "Quick ! The auditorium!"
    d "Do we have to go back the way we came?"
    mad "Seems like it!"
    scene i89
    with dissolve
    pause 1
    d "Where are the others?"
    mad "I don't know... but as long as we run towards the auditorium, we can win!"
    d "Have you seen Emerick?"
    mad "Not since we were looking for the bags..."
    d "Same here..."
    scene black
    with dissolve
    stop music fadeout 2
    pause 2

    if prem == True:
        play music "musique/Vexento_Now.mp3" volume 0.2
        $ Achievement.add(achievement_win)
        $ achievement.grant("win")
        $ achievement.sync()
        $ Rank = Rank-40
        scene i91
        with dissolve
        pause 1
        scene i92
        with dissolve
        pause 1
        scene i93
        with dissolve
        pause 1
        scene i94
        with dissolve
        pause 1
        scene i95
        with dissolve
        pause 1
        mad "Did we win??"
        d "Looks like it!"
        scene i96
        with dissolve
        pause 1
        scene i97
        with dissolve
        pause 2
        mad "Oh, that's amazing!"
        scene i98
        with dissolve
        d "Waah ! We've done it !"
        pause 1
        dpense "She's so cheerful when she wins !"
        scene i99
        with dissolve
        d "Madison... You..."
        pause 2
        dpense "This is another Madison..."
        scene i100
        with dissolve
        mad "Hush..."
        pause 2
        dpense "I could do anything for these eyes and lips..."
        scene i101
        with dissolve
        pause 2
        mad "You..."
        scene i102
        with dissolve
        pause 2
        mad "Sorry... I shouldn't..."
        play sound "sound/Scratch.mp3" volume 1
        stop music
        scene i103 with hpunch
        with dissolve
        emerick "Madison... Madison... Madison..."
        play music "musique/Sacrifice-EliLortomy bad guy.mp3" volume 0.2
        scene black
        $ renpy.movie_cutscene("images/animation/animemer.webm", stop_music=False)
        scene i104
        pause 1
        scene i105
        with dissolve
        pause 1
        emerick "Hey lovebirds ! Did you really think you won ?"
        emerick "Ahahahahah !"
        scene i106
        with dissolve
        pause 2
        mad "Oh shit..."
        scene i107 with hpunch
        with dissolve
        pause 2
        d "Meh..."
        scene i108
        with dissolve
        pause 1
        emerick "Nice try, Maddie... But as always, you're still behind me."
        scene i109
        with dissolve
        pause 1
        emerick "But you, Frenchy, impressed me."
        scene i110
        with dissolve
        pause 1
        mad "Be careful with him... His tongue is even more dangerous when he gives compliments..."
        d "Don't worry. I wasn't planning on being buddies with someone like him."
        scene i111
        with dissolve
        pause 1
        mad "You're going up in my estimation, though!"
        mad "Keep it up and I might be able to tolerate you!"
        d "Yeah... I'm not sure I really want that..."
        scene i112
        with dissolve
        pause 2
        scene black
        with dissolve
        scene i113
        with dissolve
        pause 2
        if Grope == True:
            scene i114
            with dissolve
            sofia "See you later, Groper..."
            scene i115
            with dissolve
            scene i116
            with dissolve
            scene i115
            with dissolve
            pause 2
        jump trialfin
    else:
        play music "musique/Sacrifice-EliLortomy bad guy.mp3" volume 0.2
        scene i91
        with dissolve
        pause 1
        scene i92
        with dissolve
        pause 1
        scene i93
        with dissolve
        pause 1
        scene i94
        with dissolve
        pause 1
        scene i95
        with dissolve
        pause 1
        $ Rank = Rank-30
        scene i105
        with dissolve
        pause 1
        emerick "Well then, Madison? We're far behind this time! As always, actually!"
        mad "Don't push your luck!"
        scene i108
        with dissolve
        pause 1
        emerick "The tigress is showing her claws, watch out!"
        grace "Emerick, go away."
        scene i109
        with dissolve
        pause 1
        emerick "Okay...But we're not done yet...I'm going to show everyone that I'm the B.E.S.T"
        scene i110
        with dissolve
        pause 1
        mad "Yeah, yeah, whatever..."
        jump trialfin
else:

    scene i90
    with dissolve
    pause 1
    grace "Quick ! The auditorium!"
    d "Do we have to go back the way we came??"
    grace "Seems like it!"
    scene black
    with dissolve
    stop music fadeout 2
    pause 2
    $ Rank = Rank-25
    play music "musique/Sacrifice-EliLortomy bad guy.mp3" volume 0.2
    scene i105
    with dissolve
    pause 1
    emerick "Well then, Madison? We're far behind this time! As always, actually!"
    mad "Don't push your luck!"
    scene i108
    with dissolve
    pause 1
    emerick "The tigress is showing her claws, watch out!"
    grace "Emerick, go away."
    scene i109
    with dissolve
    pause 1
    emerick "Okay...But we're not done yet...I'm going to show everyone that I'm the B.E.S.T"
    scene i110
    with dissolve
    pause 1
    mad "Yeah, yeah, whatever..."
    jump trialfin

label trialfin:

scene black
with fade
pause 2
$ renpy.movie_cutscene("images/glitch.webm", stop_music=False)
pause 2
"Clap... clap... clap"
scene i117
with dissolve
scene i118
with dissolve
scene i117
with dissolve
scene i118
with dissolve
scene i117
with dissolve
scene i118
with dissolve
scene i119
with dissolve
pause 1
orushi "Dear students! You have finished the challenge! Congratulations to all of you!"
orushi "I must say, some of you gave up at the Great Wall, while others couldn't find which suitcase to take!"
orushi "Anyway, here are the results of the challenge and your new rank in the competition!"
scene black
with fade
pause 2

show text _ ("YOUR NEW RANK IS [Rank] !") at truecenter
pause 3
hide screen gameUI
show screen gameUIBEST
pause 1
scene i120
with fade
pause 1
orushi "As you can see, both your individual and collective actions are taken into account in this competition."
orushi "Therefore, the top 50 are qualified for the next stage!"
orushi "Once again, congratulations to all of you!"
scene i121
with dissolve
pause 1
orushi "I'm giving you the rest of the afternoon off."
orushi "See you soon..."
rufus "Meow..."
scene black
with fade
$ renpy.movie_cutscene("images/glitch.webm", stop_music=False)
scene i113
with dissolve
stop music fadeout 2
grace "Girls ! Let's go change."
play music "musique/Rexlambo-StayWithMe.mp3" volume 0.2
d "See you later."
scene black
with dissolve
scene i122
with dissolve
pause 1
dpense "I should go see where the locker room is..."

jump reward

label reward:

if Aidejulia == True:
    julia "Hey handsome !"
    scene i123
    with dissolve
    pause 1
    d " Hmm ?"
    julia "Thank you for your help during the trial !"
    scene i124
    with dissolve
    pause 2

    scene black
    with dissolve
    pause 2

if Aidepoutre == True:
    scene i123
    with dissolve
    pause 1
    grace "Let me reward you for your help, my white knight..."
    scene i125
    with dissolve
    pause 2
    d "Oh ? ..."

    scene black
    with dissolve
    pause 2

if Aidemur == True:
    scene i123
    with dissolve
    pause 1
    ruby "I knew I could count on you Cortex !"
    scene i126
    with dissolve
    pause 2
    d "Always Minus... Always !"

    scene black
    with dissolve
    pause 2

jump final1

label final1:

scene j1
with dissolve
pause 3
scene j2
with dissolve
pause 3 
scene j3
with dissolve
pause 3  
scene j4
with dissolve
pause 3  
scene j5
with dissolve
pause 3  
scene j6
with dissolve
dpense "What a day..."
scene j7
with dissolve
dpense "A trial, some opponents, the girls..."
scene j8
with dissolve
dpense "This ranking... All of this is insane..."
$ Refusebj = False
$ Refusek = False

if sofiabj == True:
    jump sofiabj
else:
    if bethfk == True:
        jump bethfk

label sofiabj:
    play sound "sound/Scratch.mp3" volume 1.0
    scene k1
    with hpunch
    with dissolve
    d "Waaaah ! What are you doing here ?"
    sofia "Well... I must say you've made a great impression today..."
    scene k2
    with dissolve
    sofia "And... When I have those... Impressions..."
    sofia "I need to satisfy my..."
    scene k3
    with dissolve
    sofia "Curiosity..."
    sofia "So... Tell me Mister Frenchie..."
    scene k4
    with dissolve
    sofia "Is there something you have that can satisfy me ?"
    scene k5
    with dissolve
    sofia "Or will you continue to grope the ass of a little virgin... "
    sofia "While you could play with an entire..."
    sofia "And sexy body..."
    scene k6
    with dissolve
    d "So, is it a habit for girls to come into the locker room ?"
    d "Or was it just the opportunity to see a fresh guy nude ?"
    if persistent.streaming == True:
        sofia "Hmm, is it a habit of Frenchie to let girls see all the package shamelessly ?"
        d "Hey! You came here! I didn't ask you for anything!"
        scene k8
        with dissolve
        sofia "And the package isn't as big as I expected..."
        sofia "Not sure you will make me... how did you say it ? A Squirter ???"
        scene k9
        with dissolve
        d "I was in the cold shower..."
        jump bluechoix
    scene k7
    with dissolve
    sofia "Hmm, is it a habit of Frenchie to let girls see all the package shamelessly ?"
    d "Hey! You came here! I didn't ask you for anything!"
    scene k8
    with dissolve
    sofia "And the package isn't as big as I expected..."
    sofia "Not sure you will make me... how did you say it ? A Squirter ???"
    scene k9
    with dissolve
    d "I was in the cold shower..."

    label bluechoix:
        pause 1
    scene k10
    with dissolve
    pause 2
    if persistent.patch_enabled == True:
        $ TEMP1 = e1s4m7c1
        $ TEMP2 = e1s4m7c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Provoke her [TEMP1!t]":
            jump bluejob
            label bluejob:
                if _in_replay:
                    show screen Replayexit
                scene k10
                with dissolve
                d "So... maybe you can do something about it ?"
                d "Or this mouth is only for chit-chatting ?"
                sofia "Oh... Does someone have balls ?"
                sofia "I don't have the habit of playing with the losers..."
                sofia "But with what I saw earlier..."
                sofia "I think you deserve a consolation prize..."
                $ Achievement.add(achievement_specialreward)
                $ achievement.grant("specialreward")
                $ achievement.sync()
                scene k11
                with dissolve
                sofia "And what if I add some..."
                if persistent.streaming == True:
                    sofia "Motivation..."
                    sofia "For our little guy there..."
                    d "I think you can do more..."
                    sofia "Ballzy and greedy... What a man !"
                    sofia "Okay Frenchie... Do you want to play ?"
                    sofia "Let's see how long you can hold on against me..."
                    scene k5
                    with dissolve
                    sofia "And if you impress me... Just a little..."
                    sofia "Maybe I will let you play with me..."
                    sofia "So... deal ?"
                    d "We have a deal Blue..."
                    sofia "Sofia... I have a name little asshole..."
                    sofia "Now... no more talking... Action..."
                    pause 1 
                    scene black
                    with dissolve
                    pause 1
                    scene k24
                    with dissolve
                    mad "Asshole..."
                    mad "All the same..."

                    scene black
                    with dissolve
                    jump finchoixblue
                scene k12
                with dissolve
                sofia "Motivation..."
                scene k13
                with dissolve
                sofia "For our little guy there..."
                scene k14
                with dissolve
                d "I think you can do more..."
                sofia "Ballzy and greedy... What a man !"
                scene k15
                with dissolve
                sofia "Okay Frenchie... Do you want to play ?"
                sofia "Let's see how long you can hold on against me..."
                scene k16
                with dissolve
                sofia "And if you impress me... Just a little..."
                sofia "Maybe I will let you play with me..."
                sofia "So... deal ?"
                d "We have a deal Blue..."
                scene k17
                with dissolve
                sofia "Sofia... I have a name little asshole..."
                sofia "And I would advise you not to joke about it while I'm playing with your dick in my hand..."
                scene k18
                with dissolve
                sofia "Now... no more talking... Action..."
                scene k23
                with dissolve
                pause 2.0
                scene k24
                with dissolve
                mad "Asshole..."
                mad "All the same..."

                scene black
                with dissolve
                pause 1.0
                scene r000
                with dissolve
                pause 2
                $ renpy.movie_cutscene("images/animation/hj1.webm", loops=2, stop_music=False)
                scene r060
                with dissolve
                pause 2
                d "Come on Sofia you can do better !"
                sofia "I think I could tell you the same !"
                pause 1
                $ renpy.movie_cutscene("images/animation/hj2.webm", loops=2, stop_music=False)
                scene r060
                with dissolve
                d "You asked for it..."
                scene k19
                with dissolve
                sofia "Ohhh..."
                scene k20
                with dissolve
                sofia "What the..."
                scene k21
                with dissolve
                sofia "Fuck ?"
                scene k22
                with dissolve
                sofia "Okay... Now we're talking !"
                d "So... Impressed ?"
                sofia "Nope..."
                d "Not even a little ?"
                sofia "Maybe..."
                scene r150
                with dissolve
                sofia "Let's see how you'll handle this..."
                pause 1.0
                $ renpy.movie_cutscene("images/animation/lick.webm", loops=2, stop_music=False)
                scene r150
                with dissolve
                d "Wow... You know how to use your tongue !"
                sofia "Not only my tongue!"
                d "Ohhh ?"
                scene k28
                with dissolve
                pause 1
                scene k27
                with dissolve
                pause 1
                scene k29
                with dissolve
                pause 1
                scene k27
                with dissolve
                pause 1
                scene k28
                with dissolve
                pause 1
                scene k30
                with dissolve
                sofia "So ?"
                d "Not bad... But maybe you could do it faster ?"
                sofia "Do you think you can give me orders in this position ?"
                d "Didn't your mother tell you not to talk with your mouth full?"
                sofia "Shut up..."
                scene k28
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k29
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k28
                with dissolve
                dpense "That mouth... I want to fuck it like a barbarian..."
                scene k28
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k29
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k28
                with dissolve
                dpense "Is this a vacuum ??? I'm already on the edge !"
                scene k28
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k29
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k28
                with dissolve
                pause 0.2
                scene k30
                with dissolve
                pause 1.0
                d "I can't hold on any longer!"
                scene k30
                with dissolve
                sofia "Don't ! Come on Frenchie ! Give it to me !"
                dpense "Sure I will give it to you... all in your fucking mouth !"
                scene k28
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k29
                with dissolve
                pause 0.2
                scene k27
                with dissolve
                pause 0.2
                scene k28
                with dissolve
                pause 0.2
                scene k30
                with dissolve
                d "Ahhhhhhhhhhh !!!"
                with flash
                with hpunch
                with flash
                scene k31
                with flash
                with dissolve
                with hpunch
                with flash
                d "Ohhh..."
                with flash
                scene k32
                with dissolve
                d "My god... You drained me..."
                sofia "Humhum..."
                scene k33
                with dissolve
                sofia "{i}Gulp{/i}"
                scene k34
                with dissolve
                sofia "Not bad !"
                label finchoixblue:
                    pause 1
                scene k35
                with dissolve
                sofia "Well... Now that our little arrangement is settled... Keep scoring during the competition..."
                d "I will..."
                sofia "I hope... Cause I really, really want to play again with our common buddy..."
                d "You won't want to stop after this..."

                scene k36
                with dissolve
                sofia "That's not my intention !"
                sofia "See ya Frenchie !"
                d "Yeah yeah..."
                dpense "I don't know what I just got myself into..."
                $ Bluepath = True
                $ Redpath = False
                $ renpy.notify(_("New Scene Gallery added"))
                $ renpy.end_replay()
                jump final
        "Tell her to go away [TEMP2!t]":



            $ Refusebj = True
            $ Bluepath = False
            $ Redpath = False
            scene k10
            with dissolve
            d "So if you have nothing to do... Maybe you can go fly a kite ?"
            sofia "Are you kidding me ?"
            d "Nope..."
            scene k37
            with dissolve
            sofia "Don't... Ever... Try talking to me again bastard !!!"
            d "Don't worry ! I won't !"
            scene k25
            with dissolve
            mad "{i}Giggle{/i}"
            mad "Maybe he's a good one..."
            scene black
            with dissolve
            pause 2


            jump final

label bethfk:

    scene j9
    with dissolve
    dpense "Orushi..."
    dpense "Even the cat is weird !!!!"
    scene j10
    with dissolve
    dpense "The girls like me..."
    dpense "But I don't know if I can be their B.E.S.T..."
    scene j11
    with dissolve
    dpense "This Emerick seems like trouble..."
    dpense "I must stay alert around him..."
    scene j12
    with dissolve
    dpense "And the twins..."
    dpense "They're so..."
    pause 1
    play sound "sound/Scratch.mp3" volume 1.0
    with hpunch
    scene j14:
        xalign 0.0
        linear 5.0 yalign 0.9
        linear 3.0 yalign 0.0
        repeat 1
    with dissolve
    d "Ahhhhhh !!!!"
    beth "Surprise !"
    beth "I told you I'm watching you..."
    beth "And I must say that I'm really pleased with what I've seen so far..."
    beth "I have seen how you take care of your girls..."
    d "My... Girls ?"
    scene j20
    with dissolve
    beth "Yeah... Little Ruby... The Captain... Even Holy, Marie, Julia..."
    beth "So sad I don't have someone like you to take care of me..."
    beth "My needs..."
    scene j21
    with dissolve
    beth "Someone who can handle me..."
    beth "Who can see very..."
    beth "Deeply..."
    beth "Into my..."
    beth "Eyes..."
    scene j22
    with dissolve
    beth "But what if..."
    beth "I would like to try..."
    beth "And see how a French..."
    beth "Kiss..."

    if persistent.patch_enabled == True:
        $ TEMP1 = e1s4m8c1
        $ TEMP2 = e1s4m8c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Go for the kiss [TEMP1!t]":

            jump redkiss
            label redkiss:
                if _in_replay:
                    show screen Replayexit

                $ Achievement.add(achievement_reward)
                $ achievement.grant("reward")
                $ achievement.sync()
                $ Redpath = True
                $ Bluepath = False

                scene j23
                with dissolve
                dpense "Waahhhh... I must be dreaming...."
                dpense "Her tongue... those lips... that body..."
                dpense "OMG... I want to..."
                scene twinvest
                with hpunch
                with dissolve
                beth "Ohhh..."
                scene twinvest2
                $ renpy.movie_cutscene("images/animation/redkissslow.webm", stop_music=False)
                scene twinvest2
                with dissolve
                beth "Ah, Someone becomes greedy..."
                beth "I think I just said a kiss..."
                scene j19
                with dissolve
                beth "Now if you excuse me..."
                d "Where are you going ?"
                beth "I have some errands to run, but..."
                scene j22
                with dissolve
                beth "When I decide you deserve it..."
                beth "You better be ready..."
                dpense "I am... Now !"
                beth "But... until then..."
                scene j32
                with dissolve
                beth "Down, boy !"
                scene j33
                with dissolve
                d "Come on !!!"
                dpense "I don't know what I just got myself into..."
                scene j36
                with dissolve
                ruby "{i}Stupid Cortex...{/i}"
                pause 2
                $ renpy.notify(_("New Scene Gallery added"))
                $ renpy.end_replay()
                jump final
        "Refuse [TEMP2!t]":


            $ Refusek = True
            $ Redpath = False
            $ Bluepath = False
            scene j21
            with dissolve
            d "I don't know what's gotten into you..."
            d "But I don't want my lips to go anywhere near yours..."
            scene j35
            with dissolve
            beth "Anywhere ? Do you really think just anybody can touch this body ?"
            beth "Hear me, Frenchie One. It will be a cold day in hell before you have this opportunity again..."
            scene j34
            with dissolve
            d "I don't know. I heard Global Warming is having the opposite effect in hell. So, bring your snow shoes, Salami! It will slide !"
            scene j37
            with dissolve
            ruby "{i} He's incredible... {/i}"

            jump final

label final:

$ Achievement.add(achievement_episode1)
$ achievement.grant("episode1")
$ achievement.sync()
stop music fadeout 2
pause 2
scene black
with dissolve
pause 1

if Bluepath == True:
    play sound "sound/Phone.mp3" volume 0.2
    play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
    pause 6
    "M ? Yeah..."
    pause 2
    "He's under control..."
    pause 2
    "He won't be a threat to you anymore..."
    pause 2
    "I will do my best to keep him away from these girls..."
    pause 2
    "Yeah I know..."
    pause 2
    "See you during the tournament..."
    pause 2
    "Later..."
    play sound "sound/appelfini.mp3" volume 0.2
    stop music fadeout 2
    pause 2
    call animationbest from _call_animationbest
    pause 2
    jump e2s1
else:

    if Redpath == True:
        play sound "sound/Phone.mp3" volume 0.2
        play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
        pause 6
        "M ? Yeah..."
        pause 2
        "He's under control..."
        pause 2
        "He won't be a threat to you anymore..."
        pause 2
        "I will do my best to keep him away from these girls..."
        pause 2
        "Yeah I know..."
        pause 2
        "See you during the tournament..."
        pause 2
        "Later..."
        play sound "sound/appelfini.mp3" volume 0.2
        stop music fadeout 2
        pause 2
        call animationbest from _call_animationbest_1
        pause 2
        jump e2s1
    else:

        stop music fadeout 2.0
        pause 2
        jump e2s1

label rufusg5:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img5"):
        show img5
        hide img5
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus5 = True
    hide screen chat5
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
