label animationbest:
    scene black
    $ renpy.movie_cutscene("images/glitch.webm")
    scene ecranbest with zoomout
    pause 2
    $ renpy.movie_cutscene("images/glitch.webm")
    scene black
    pause 1
return

label animationbestlite:
    scene black
    $ renpy.movie_cutscene("images/glitch.webm")
    scene ecranbest with zoomout
    pause 1
    scene black
    with dissolve
    pause 2
return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
