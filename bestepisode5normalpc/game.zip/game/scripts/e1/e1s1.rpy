label e1s1:
    pause 2
    play music "musique/Meydan-Changes.mp3" volume 0.1 fadein 2
    scene black
    pause 2
    with fade
    show text _ ("EPISODE 1 {p} \n Natural Selection") at truecenter
    pause 2
    with dissolve
    pause 2
    hide text
    show text "{i}La raison du plus fort est toujours la meilleure{/i} : \n Jean de la Fontaine \n" at truecenter
    with dissolve
    pause 3
    hide text
    show text "{i}Harder Better Faster Stronger {/i} : \n Daft Punk\n" at truecenter
    with dissolve
    pause 3
    hide text
    pause 2
    with dissolve

    dpense "That Madison girl seems popular. I don't have a clue about her though."
    pause 1
    dpense "Why was she so mean?"
    pause 1
    scene e11
    with dissolve
    dpense "She's incredibly beautiful but I can't stand dealing with her..."
    pause 1
    scene e12
    with dissolve
    dpense "And I don't know where my luggage is."
    pause 1
    scene e13
    with dissolve
    d "Driver ! How far are we from the University?"
    pause 1
    scene e14
    with dissolve
    "We've arrived, sir." with vpunch

    pause 1
    d "That's not the university. That's a wall!"
    scene e15
    with dissolve
    pause 1
    "She asked me to drop you off here, buddy."
    pause 1
    scene e16
    with dissolve
    d "She?"
    pause 1
    d "Who is she?"
    pause 1 
    scene e17
    with dissolve
    d "He's gone!"
    pause 1
    dpense "Okay. Where am I ? Who is this 'She' the driver mentioned and why did she have me dropped off at a wall?"
    pause 1
    dpense "I have no clue what is going on."
    pause 1
    with vpunch
    "Welcome to America, [name]"
    scene e18
    with dissolve
    pause 2
    scene e19
    with dissolve
    d "Who...who are you? And how do you know my name?"
    pause 1
    scene e20
    with dissolve
    "I'm Mrs. Drew, Mr. Orushi's assistant from Orushi Corp. I'm also the dean of the university."
    pause 1
    drew "I know everything I need to know about you, [name]."
    pause 1
    drew "You're from France, a slightly above average student, with decent athletic skills due to a lifetime of sports and good genetics."
    pause 1
    scene e21
    with dissolve
    d "What? Are you spying on me?"
    pause 1
    scene e22
    with dissolve
    drew "Spying on you? Do you think you're important enough for us to send someone to France just to spy on you, kid?"
    pause 1
    drew "No. Of course not."
    pause 1
    drew "You're just a number in a file. In this case, you're the 90th."
    pause 1
    scene e19
    with dissolve
    d "90th? The 90th what?"
    pause 1
    drew "I've already told you enough. Tomorrow, you will understand fully."
    pause 1
    scene e23
    with dissolve
    drew "Now, if you'll excuse me, I will introduce you to my daughter. She will show you to your dormitory and room on campus."
    pause 1
    drew "Please come in."
    scene black
    $ renpy.movie_cutscene("images/animation/maison.webm", stop_music=False)
    scene e25
    with dissolve
    drew "You will see my daughter is kind and..."

    drew "DRUNK?" with hpunch
    scene e26
    with dissolve
    pause 1
    drew "Grace! What are you doing? Why are you drinking alone at this hour? You should be getting ready for tomorrow!"
    scene e24
    with dissolve
    pause 1
    grace "C'mon... can you stop yelling at me please? I've got a killer headache."
    scene e24
    with dissolve
    pause 1
    scene e27
    with dissolve
    drew "Grace! Be mindful of yourself! We have a guest, so please tone it down and introduce yourself properly!"
    pause 1
    grace "Oh my gosh... okay. I will, but you gotta try this Champagne, it's awesome!"
    pause 1
    scene e28
    with dissolve
    grace "Sorry, I'm Grace and you are..."


    if Grope == True:
        scene e29
        with dissolve
        grace "The Groper!"
        with vpunch
        pause 1  
        scene e30
        with dissolve
        grace "Mom, this guy's a pervert!"
        pause 1
        jump drewsuite
    else:

        scene e29
        with dissolve
        grace "The Redneck!"
        with vpunch
        pause 1  
        scene e31
        with dissolve
        grace "Mom, this guy is really charming! He talked to Julia on the plane and even she doesn't seem immune to his charms!"
        pause 1
        call education_increased from _call_education_increased_1
        jump drewsuite

    label drewsuite:
        scene e32
        with dissolve
        drew "Come on Grace, that's not a proper way to greet a guest."
        pause 1
        grace "But..."
        pause 1
        drew "No buts!"
        with hpunch
        scene e33
        with dissolve
        drew "I apologize on behalf of my daughter, it must have been a misunderstanding."
        scene e34
        with dissolve
        pause 1
        drew "[name], this is Grace, my daughter."
        scene e35
        with dissolve
        pause 1
        drew "And Grace, this is [name], a French exchange student who will be staying with us at the university for this semester."
        pause 1
        grace "Okay, okay, Mom. I get it."
        pause 1
        scene e36
        with dissolve
        grace "I'm sorry [name], I had a little too much to drink and I tend to get excited easily when I'm tipsy."
        pause 1
        scene e37
        with dissolve
        drew "Now that that's taken care of."
        pause 1
        drew "I don't think you're in any state to show [name] his room and the dormitory, Grace."
        pause 1
        scene e38
        with dissolve
        grace "Sure I can... Oof!" with vpunch
        scene e39
        with dissolve
        pause 1
        drew "You need to get some rest young lady, and I've got a lot on my plate."
        pause 1
        scene e40
        with dissolve
        drew "[name], could you stay here for the night and keep an eye on Grace to make sure she doesn't keep drinking?"
        pause 1
        drew "You can sleep on the couch and I'll have someone show you to your room tomorrow morning."
        pause 1
        scene e41
        with dissolve

        if persistent.patch_enabled == True:
            $ TEMP1 = e1s1m1c1
            $ TEMP2 = e1s1m1c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
        menu:
            "You think I'm a babysitter? [TEMP1!t]":

                call temperament_increased from _call_temperament_increased_3
                jump drewangry
            "Sure Mrs. Drew. I'll take care of her. [TEMP2!t]":

                call education_increased from _call_education_increased_2
                jump drewok

        label drewangry:
            scene e42
            with dissolve
            drew "I must advise you that it's not a good start if you talk to me like that. I must remind you that I'm the dean of the university, and you need to keep your record clean as an exchange student."
            pause 2
            scene e44
            with dissolve
            d "I'm sorry Mrs. Drew."
            pause 1
            scene e45
            with dissolve
            drew "Much better young man. I must be heading out. See you tomorrow at nine sharp. Tardiness will not be tolerated."
            pause 1 
            d "I'll be there."
            jump gracetip

        label drewok:
            scene e43
            with dissolve
            drew "That's what I was hoping to hear. I have placed a lot of trust in you, [name]. Don't disappoint me and I will make sure you are rewarded."
            pause 1
            scene e44
            with dissolve
            d "I will try, Mrs. Drew."
            pause 1
            scene e45
            with dissolve
            drew "I must be heading out. See you tomorrow at nine sharp. Tardiness will not be tolerated."
            pause 1 
            d "I'll be there."
            jump gracetip

    label gracetip:

        scene e46
        with dissolve

        pause 2

        scene e47
        with dissolve

        cr "Just give me a moment. I want to make sure you fully understand the rules of this game."
        cr "Although I believe you're smart, I'd like to check your stats before you proceed further in the story."
        cr "So let's take a look! Please open the stats window."
        show screen gameUI

        pause 2

        cr "It looks like you've already made some decisions that have affected your character."
        cr "For now, it doesn't matter too much..."
        if Grope == True:
            cr "... but maybe not trying to grope Julia on the plane could have changed the perception of the other girls?"
        else:
            cr "... but maybe being more forward with Julia on the plane could have changed the perception of the other girls?"
        cr "You see, all the statistics can change relatively quickly."
        cr "I would advise you to make multiple saves, with different choices, as it will affect future events."
        cr "Okay, let's get back to the game now. Have fun!"


        pause 2

        scene e48
        with dissolve

        d "So, um, Grace right?"
        grace "Yep, that's me."
        d "Do you need help with anything?"
        grace "No I'm good. I'm just going to head to my room and sleep. Tomorrow is going to be a tough one."
        scene e49
        with dissolve
        d "Sure thing."
        scene e50
        with dissolve
        grace "Oooooh...ahhhh " with vpunch

        if persistent.patch_enabled == True:
            $ TEMP1 = e1s1m2c1
            $ TEMP2 = e1s1m2c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""

        menu:
            "Catch her [TEMP1!t]":


                scene e51
                with dissolve
                call sport_increased from _call_sport_increased
                grace "Thanks for the save, hero!"
                d "I'm not sure about being a hero, but I did tell your mother that I would take care of you."
                scene e52
                with dissolve
                grace "Maybe I should focus on training and stop skipping the evening swims in the pool."
                $ Piscine = True
                $ Achievement.add(achievement_hero)
                $ achievement.grant("hero")
                $ achievement.sync()
                pause 1

                grace "You can let me go now..."

                pause 1

                cr "Here you have some choices that may be hidden, depending on the required statistics."
                cr "In this case, you will may have the choice or not, and the option could open up depending on how much she trusts you."
                cr "To help you out, your Education level must be 2 or higher for her to trust you."

                pause 1

                if persistent.patch_enabled == True:
                    $ TEMP3 = e1s1m3c1
                    $ TEMP4 = e1s1m3c2
                else:
                    $ TEMP3 = ""
                    $ TEMP4 = ""
                menu:
                    "Do you want me to help you to your room ? [TEMP3!t]" if Education >= 2:
                        call sport_increased from _call_sport_increased_4
                        jump roomgrace
                    "Oh! Yes, I'll do that. [TEMP4!t]":

                        jump sitcouch
            "Don't [TEMP2!t]":


                scene e67
                with dissolve
                if persistent.patch_enabled:
                    if persistent.rufus2 == False:
                        $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
                $ Piscine = False
                grace "Why didn't you catch me?!"
                d "Sorry you fell too quickly!"
                if persistent.rufus2 == False:
                    scene e68 with dissolve
                    show screen chat2() with dissolve
                else:
                    scene e68
                    with dissolve
                grace "Are you saying I'm fat?"
                d "What, no! Of course not! You're gorgeous!"
                hide screen chat2
                jump sitcouch



        label sitcouch:

            scene e69
            with dissolve
            grace "Okay well, I'll leave you here. Don't break anything please or my mother will be furious."
            d "Sure thing. Goodnight, Grace."
            grace "Goodnight."
            jump couch

        label roomgrace:
            scene e53
            with dissolve
            pause 1
            grace "You're strong!"
            scene e54
            with dissolve
            d "I may go to the gym from time to time."
            scene e55
            with dissolve
            grace "Strong and handsome. Julia has good taste..."
            scene e56
            with dissolve
            d "Julia?"
            grace "zzzz"
            dpense "Is she sleeping ?"
            dpense "Oh my god..."
            scene e57
            with dissolve
            dpense "I need to find out where her room is."
            scene black
            with dissolve
            dpense "Yes, this must be her room."
            if persistent.patch_enabled:
                if persistent.rufus3 == False:
                    $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
            scene e59
            with dissolve
            pause 1
            dpense "It looks cozy!"
            scene e60
            with dissolve
            pause 1
            dpense "I'll just put her on her bed."
            scene e61
            with dissolve
            pause 1
            dpense "There you go."
            if persistent.rufus3 == False:
                scene e62 with dissolve
                show screen chat3() with dissolve
            else:
                scene e62
                with dissolve
            grace "Thank you, my hero!"
            with hpunch
            dpense "What?"
            hide screen chat3
            scene e64
            with dissolve
            pause 1
            grace "A strong and handsome hero..."
            scene e63
            with dissolve
            pause 1
            dpense "Does she think I'm gone?"
            scene e64
            with dissolve
            pause 1
            dpense "She's beautiful."
            scene e65
            with dissolve
            pause 1
            dpense "Maybe I should help her undress?"
            dpense "No, she will think I'm a pervert."
            scene e66
            with dissolve
            pause 1
            dpense "Sleep well, redhead..."
            $ Achievement.add(achievement_redhead)
            $ achievement.grant("redhead")
            $ achievement.sync()
            jump couch

    label couch:

        scene e70
        with dissolve
        dpense "Okay. I think it's time for bed."
        scene e71
        with dissolve
        dpense "That day was pretty eventful."
        scene e72
        with dissolve
        dpense "Tomorrow at nine she said. All right, Mrs. Drew, I won't let you down."

    scene black
    with dissolve
    pause 2

    jump e1s2

label sport_increased:
    $ Sport += 1
    $ renpy.notify (_("YOUR SPORT HAS INCREASED"))
    return

label rufusg2:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img2"):
        show img2
        hide img2
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus2 = True
    hide screen chat2
    return

label rufusg3:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img3"):
        show img3
        hide img3
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus3 = True
    hide screen chat3
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
