label e1s3:
scene black
with dissolve
stop music fadeout 2.0
pause 2
play music "musique/Vexento-Spark.mp3" volume 0.20
pause 4
$ renpy.movie_cutscene("images/animation/entree.webm", stop_music=False)
scene h1
with dissolve
pause 2
ruby "Julia! What did you do to your hair?"
scene h2
with dissolve
julia "Oh, I was tired of people asking me if I wanted to become a rockstar!"
pause 1
scene h3
with dissolve
ruby "Well, it looks good on you! And the color...Wow!"
pause 1
scene h4
with dissolve
julia "Thank you! And did you get rid of your braid?"
pause 1
ruby "Yes! It's suitable for sports, but I was tired of it! I had to redo it every time...And I didn't have much time this morning...Had to take Cortex to his room!"
scene h5
with dissolve
julia "Cortex?"
pause 1
if Grope == True:
    scene h7
    with dissolve
    d "She decided we were Minus and Cortex..."
    pause 1
    scene h8
    with dissolve
    julia "The return of the pervert... I hope you behaved well with Ruby! Otherwise, you'll see what it feels like to get beat up by a woman!"
    julia "You're lucky I'm in a good mood! But don't test me today... Stay away from me and everything will be fine!"
    pause 1
    scene h9
    with dissolve
    ruby "He was perfect, Julia! Stop it! I took him to his room so he could change and see where he was going to sleep."
    ruby "Poor guy, he doesn't know anyone here, and his luggage was taken without him knowing where to go..."
    pause 1
    julia "Oh! Okay... Well, listen, I'm going to make an effort..."
    scene h11
    with dissolve
    julia "And... Minus and Cortex ???"
    pause 1
    scene h12
    with dissolve
    ruby "Oh yeah...Do you remember Pinky and The Brain when we were kids ?"
    pause 1
    julia "Hum... Oh ! The Animaniacs ?"
    pause 1
    scene h13
    with dissolve
    ruby "Yeeees ! Well, in French it's called Minus and Cortex !"
    pause 1
    scene h14
    with dissolve
    julia "Oh... But how do you know that ?"
    scene h15
    with dissolve
    ruby "Well, last year we studied Steven Spielberg and he was part of the team that created the Animaniacs and..."
    julia "Okay okay okay ! I don't know how you keep so much information in your little head..."
else:
    scene h6
    with dissolve
    d "She decided we were Minus and Cortex..."
    pause 1
    julia "Oh, it's the guy from the plane! I hope Ruby was friendly to you! Ruby, you didn't bore him too much with all your stories, did you?"
    julia "Poor thing just arrived and probably got bombarded with stories about movies, animals, or melting ice in Antarctica..."
    scene h10
    with dissolve
    d "Hahaha! No, really, she was nice! She showed me the dorm and my room that..."
    scene h13
    with dissolve
    ruby "That I got ready myself!"
    d "Yes, the room she prepared for me..."
    scene h15
    with dissolve
    julia "If you want, I can show you around the campus so you can see what we can do after class."
    $ Tour = True
    d "That would be perfect!"
    scene h11
    with dissolve
    julia "And... Minus and Cortex ???"
    pause 1
    scene h12
    with dissolve
    ruby "Oh yeah...Do you remember Pinky and The Brain when we were kids ?"
    pause 1
    julia "Hum... Oh ! The Animaniacs ?"
    pause 1
    scene h13
    with dissolve
    ruby "Yeeees ! Well, in French it's called Minus and Cortex !"
    pause 1
    scene h14
    with dissolve
    julia "Oh... But how do you know that ?"
    scene h15
    with dissolve
    ruby "Well last year we studied Steven Spielberg and he was part of the team that created the Animaniacs and..."
    julia "Okay okay okay ! I don't know how you keep so much information in your little head..."

scene h16
with dissolve
ruby "Can you stay with him for a bit and show him around? I need to go to the restroom class starts!"
julia "Of course, go ahead!"
ruby "Thanks!!! See you later!"
scene h17
with dissolve
julia "Well, since it's just us, let me give you a quick rundown of the people at the University."
scene h18
with dissolve
julia "You'll see that some are more or less the 'stars' around here, and others are kind of the outsiders..."
scene h19
with dissolve
pause 1
d "What do you mean?"
scene h20
with dissolve
julia "Wait, let me show you!"
scene black
$ renpy.movie_cutscene("images/animation/stevenpres2.webm", stop_music=False)
scene h21
with dissolve
julia "So, you see that's Steven, one of the guys from the University, constantly hitting on girls and trying to hook up, as he says..."
scene h22
with dissolve
julia "He plays on the men's soccer team. They're looking for teammates, so you can try if you like."
julia "I've never seen him with anyone, and all the girls on the team have already blacklisted him..."
d "Oh yes, that's right, you have your team...Are you good?"
scene h23
with dissolve
julia "We're one of the top academic team of soccer in the country! And some of us are expected to join the national team!"
scene h24
with dissolve
julia "Anyway ! So in the team, you have several girls our age and some a little older..."
scene black
$ renpy.movie_cutscene("images/animation/rubypres2.webm", stop_music=False)
scene h25
with dissolve
julia "In our class, you have Ruby who plays winger, she's a great technician and very fast!"
d "Ruby ? Fast ?"
julia "Yes, when she's not talking, I assure you she can be!!!"
scene h23
with dissolve
d "Hahaha ! And are you fast?"
scene h19
with dissolve
julia "I'm a midfielder, I play more technically to create opportunities, with Grace behind who..."
scene h26
with dissolve
d "Grace...The redhead?"
scene h27
with dissolve
julia "Yes, yes ! She's our captain! She plays defensive midfield and organizes the game. "
scene h28
with dissolve
julia "She plays just behind me and the goal is to send the best balls to our attackers."
scene h29
with dissolve
d "Do you have good attackers?"
julia "We have the best... Unfortunately, she's extremely arrogant. But yes, she's strong."
scene h30
with dissolve
julia "Well, speak of the devil..."
scene h31
with dissolve
d "Hey, I know her! I met her in the taxi last night! Yeah, she's really full of herself!"
scene madisonnight:
    xalign 0.0
    linear 5.0 yalign 0.5
    linear 1.0 yalign 0.1
    repeat 1
d "When she left, she said something like, 'Everyone knows...'"
julia "Everyone knows Madison Forrester... Yeah, I know, she says it a lot. Anyway, she's our star player."
scene h32
with dissolve
julia " I have to admit, I don't really get along with her. But she has a lot of issues and responsibilities that make her defensive sometimes..."
scene h33
with dissolve
julia "Madison and Ruby are often together. Ruby lost her parents when she was little, and Madison's parents took her in and practically adopted her."
scene h34
with dissolve
julia "So Ruby has blind faith in Madison... And Madison is pretty protective of Ruby..."
scene h35
with dissolve
julia "The guy you see there is Emerick..."
d "Okay... Why does he have so many people around him?"
julia "Let's just say he's a hot commodity in the school... He inherited a substantial fortune from his grandfather and isn't afraid to flaunt it...."
scene h36
with dissolve
julia "The girls hate him... I don't care... But you have to be careful around him because he's ruthless in everything he does."
julia "And he's not afraid to use his money and connections to get what he wants"
d "What do you mean?"
julia "He was a track and field champion and has good knowledge of all things about business..."
julia " And on top of that, he has funds... And contacts... He's not someone you want to cross paths with..."
julia " Madison especially can't stand him because he always seems to be one step ahead of her."
scene h23
with dissolve
d "Okay... We'll try to avoid him then!"
julia "If you can! And now, here comes the problems..."
stop music fadeout 2
pause 2
play music "musique/Markvard-Desire.mp3" volume 0.20

scene h38
with dissolve
pause 2
scene h37
with dissolve
pause 2
scene h40:
    xalign 0.0
    linear 5.0 yalign 0.5
    linear 1.0 yalign 0.1
    repeat 1
julia "This is our goalkeeper, Elizabeth, as tough as she is mysterious."
julia " She's part of the 'winning trio' with her sister and Emerick..."
julia " Basically, they're the richest ones at the University... And Madison can't stand them..."
scene h41:
    xalign 0.0
    linear 5.0 yalign 0.5
    linear 1.0 yalign 0.1
    repeat 1
julia " Her twin sister is Sofia, our central defender."
julia " She's much more approachable than her sister, but don't let her charming ways fool you, she's as seductive as she is formidable!"
julia " We call them Red and Blue among ourselves because of how they distinguish themselves..."
scene h42
with dissolve
d "Red and Blue ? Like Pokémon ?"
scene h43
with dissolve
julia "Haha! Yeah!"
julia "Anyway, I think you have a good overview of the world around us now! I hope you'll manage to find your place among..."
d "I'll do it..."
scene h44
with dissolve
with vpunch
drew "All students, please proceed to the auditorium!"
julia "Wooo, The Dragon is here ! Let's go !"
scene black
with dissolve
pause 1
$ rubytrial = False
$ juliatrial = False
$ gracetrial = False
$ madtrial = False

if Grope == True:
    scene h48
    with dissolve
    sofia "Eh you !"
    pause 1
    scene h47
    with dissolve
    sofia "Next time you want to grab something like Julia's ass, be sure you can back it up !"
    scene h46
    with dissolve
    sofia "Who knows ? Maybe you'll get a reward !"
    scene h45
    with dissolve
    $ sofiabj = True
    d "Hold your horses Squirtle ! I think you can't handle me..."
    scene h49
    with dissolve
    sofia "Squirtle ?"
    scene h50
    with dissolve
    d "Yep... And what if I made you a Squirter ? Maybe you will evolve !"
    scene h51
    with dissolve
    sofia "Is this a joke ?"
    d "Later Blue one, I have someone to catch up with!"
    $ bethfk = False
else:
    scene h52
    with dissolve
    beth "Are you the French guy who just arrived?"
    d "Oh...Hum...Yes...Why?"
    scene h53
    with dissolve
    beth "I heard that the French are talented in many areas..."
    scene h54
    with dissolve
    beth "I can't wait to see you in action !"
    scene h55
    with dissolve
    d "I'll do my best..."
    $ bethfk = True
    $ sofiabj = False

d "Hum... Where am I going to go and sit ?"
scene black
call screen choixfille1()     


label rubyamphi:
    $ rubytrial = True
    scene h57
    with dissolve
    ruby "[name] ! Come here!"
    d " Are you done with the Pinky and the Braid thing ?"
    ruby "Yes ! Others don't get it...and I remember your name now !"
    ruby "Well ! I'm so excited ! I don't know what's going on, but it's the first time they asked all of us to be here at the same time !"
    d "I guess we'll find out very soon..."
    jump amphi

label juliaamphi:
    $ juliatrial = True
    scene h56
    with dissolve
    julia "You can come and sit with me if you want!"
    d "Okay!"
    d "Holy cow, there are a lot of people here!"
    julia "Yes! I don't know why they've gathered us all like this, but it's the first time they've asked us to come to the lecture hall like this!"
    d "I think they'll tell us what's going on very soon..."
    jump amphi

label graceamphi:
    $ gracetrial = True
    scene h58
    with dissolve
    d "Can I sit here?"
    grace "Yes, of course !"
    grace "Again, sorry for my attitude last night... I shouldn't drink..."
    d "Don't worry that's forgotten !"
    d "Do you know why they've brought us all here?"
    grace "No, but we'll find out soon enough!"
    jump amphi

label madisonamphi:
    $ madtrial = True
    scene h59
    with dissolve
    mad "Don't come to bother me now, it's not the time..."
    d "I'm not here for that... And good morning to you too..."
    mad "I don't understand why they're asking all of us to be here at the same time..."
    mad "I have training to do at the gym..."
    $ Gym = True
    d "I think we'll find out very soon."
    jump amphi

label amphi:
scene black
with dissolve
stop music fadeout 2
pause 2
play music "musique/KaiEngel-TheRun.mp3" volume 0.20
scene h60
with dissolve
drew "Dear students..."
scene h61
with dissolve
drew "I'm proud to present you Mr. Orushi, Director of Orushi Corp. and Main Director of the B.E.S.T project !"
scene black
$ renpy.movie_cutscene("images/animation/animoro.webm", stop_music=False)
$ renpy.movie_cutscene("images/glitch.webm", stop_music=False)
scene h62
with dissolve
rufus "MEOW"
scene h63
with dissolve
orushi "Ahem... Mr. Rufus, please!"
ruby "Oh, a talking cat ! Is that Tom ?"
"Ruby !!!" with vpunch
ruby "Okay, okay..."
scene h64
with dissolve
rufus "FSHHHHHHHHHHHHH"
scene h65
with dissolve
orushi "Good day, dear students! I am Orushi, from Orushi Corp."
scene h66
with dissolve
orushi "You must be wondering why you have been brought to the auditorium right at the beginning of your first day."
orushi "I understand your surprise."
orushi "You are now part of a special program for which you have been selected."
"(Students) What ?" with vpunch
scene h67
with dissolve
orushi "This evaluation program, the B.E.S.T, will determine among the 100 participants that you are, one single student who will succeed in passing the tests and stand out among all the others."
orushi "You will all be competing against each other. Tests will be held throughout the first semester to determine who among you is the best."
orushi "They may take place during the day or at night, individually or in teams, and an announcement will be made when it's time to gather..."
scene h68
with dissolve
orushi "At the end of this competition, the selected person will receive the title of B.E.S.T student, a check for $500,000, and a position within Orushi Corp as an assistant to the director."
orushi "I know that this is a coveted position and that many of you are asking just to become interns at Orushi Corp."
scene h69
with dissolve
orushi "So don't miss this opportunity and, above all, show all your talent during the tests."
scene h70
with dissolve
orushi "There are 100 of you and, after each test, a portion will be eliminated."
scene h71
with dissolve
orushi "The first test will keep 50 students among you."
scene h74
with dissolve
orushi "This will be a duo-team test. The computer will determine your teammate for this trial."
scene h72
with dissolve
orushi "You will have to finish the trial and be in the 25 first teams or you will be eliminated."
scene h73
with dissolve
orushi "Now Mrs. Drew will tell you who the teams are!\nGood luck and remember, always be your BEST!"
scene black
with dissolve
pause 1

if rubytrial == True:

    drew "[name] with Ruby !"
    scene h57
    with dissolve
    ruby "Great ! We're together for this one !"
    d "Yeah ! I hope we'll do well !"
    ruby "Don't worry ! I run fast ! You go and follow me ... if you can !"
    d "We'll see..."

if juliatrial == True:
    drew "[name] with Julia !"
    scene h56
    with dissolve
    julia "Oh ! We're together !"
    d "Yeah ! I hope I won't disappoint you !"
    julia "No ! You have to keep a good mindset ! You're a winner !"
    d "Okay ! We'll win this trial together !"
    julia "That's what I want to hear !"

if gracetrial == True:
    drew "[name] with Grace !"
    scene h58
    with dissolve
    grace "It seems we are on the same team for this one !"
    d "Yes... Are you not disappointed ?"
    grace "Of course not ! I couldn't have wished for a better teammate for a trial ! You're strong and seem trained !"
    d "I have to show you my better side !"
    grace "Sure ! Let's win this !"

if madtrial == True:
    drew "[name] with Madison !"
    scene h59
    with dissolve
    mad "Oh...My...God...."
    d "Okay... We have to be together for this one..."
    mad "I don't have a choice. But maybe it's good that ... You're... Fit...."
    d "You too..."
    mad "We will see, just follow me and don't waste any time !"
    d "I won't."

scene h75
with dissolve
orushi "Anyway, I won't keep you waiting any longer..."
scene h76
with dissolve
orushi "Oh, I almost forgot ! This will also be a speed test ! You will have 10 minutes before the start of the course."
orushi "The course will begin near the stadium with a loud sound... You will recognize it..."
orushi "As I just said, ten minutes to prepare and the countdown starts..."
scene h77
with dissolve
orushi "Now!"
pause 2
stop music fadeout 2
scene black
with dissolve
pause 2
jump e1s4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
