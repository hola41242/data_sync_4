label e1s2:
stop music fadeout 2
pause 2
scene black
with fade
scene f1
with dissolve
pause 2 
scene f2
with dissolve
pause 2 
scene black
with fade
play music "musique/Amaria_LovelySwindler.mp3" volume 0.20
pause 1
"…And you were alone with him all night?"
pause 1
"Well, yeah, why?"
pause 1
"I don't know, it's strange, isn't it? You just met him, your mom says he's sleeping here, and suddenly a guy is staying on your couch for the night..."
pause 1
"Yeah, it was definitely strange, but he made an impression on me... in a good way."
pause 1
"That's my Cortex, he doesn't seem like it, but yes, he seems to be quite the guy!"
pause 1
"Your Cortex?"
pause 1
"I'll explain it to you later. Well, it's 8 o'clock, I should wake him up. Uh... darn, what was his name again? Oh well... "
pause 1
"COOOOOORTEEEEEX!!!!" with hpunch
scene f3
with vpunch
d "Whaaaaaaaaaaaaaaaaaa!"
scene f4
with dissolve
pause 1
scene f5
with dissolve
pause 1
scene f6
with dissolve
pause 1 
scene f7
with dissolve
pause 1
ruby "Ahaha, I know I'm drop-dead gorgeous, but I never thought about the literal meaning of that expression!"
scene f8
with dissolve
pause 1
scene f9
with dissolve
pause 1
d "Hey, what are you doing here?"
pause 1
scene f10
with dissolve
ruby "Well, Mrs. Drew asked me to take you to your room, and it's better to obey her right away or... well, shall we go?"
pause 1
d "Wait, what about Grace?"
pause 1
scene f11
with dissolve
grace "Yes?"
pause 1
scene f12
with dissolve
grace "Don't worry about me, I still have an hour to get ready. I don't know what's going on, but we better be on time getting to the university. Hurry up or my mother will complain and we don't want to upset her on the first day of classes!"
pause 1
scene f13
with dissolve
ruby "Yes! Let's go, let's go, let's go!"
pause 1
d "I'm coming..."
pause 1
scene black
with fade


scene f14
with dissolve
pause 1
d "So you're at the university too. What are you studying?"
pause 1
scene f15
with dissolve
ruby "I'm studying cinema, in all it's forms. It's super exciting! Do you know that an experiment was done to see if Jack could have stayed on the door with Rose?"
pause 1
scene f16
with dissolve
d "What are you talking about? Titanic? Really?"
pause 1 
scene f17
with dissolve
ruby "Yeah! She was so selfish. Oh Jack I'm freezing..."
pause 1 
scene f18
with dissolve
ruby "Okay, Rose, I will try to stay alive in the freezing cold water.."
pause 1
scene f19
with dissolve
d "Are you for real?"
pause 1 
scene f20
with dissolve
ruby "Okay okay, but it's super interesting I swear!"
pause 1
d "I can imagine. And what do you like about cinema?"
pause 1
scene f21
with dissolve
ruby "I like how it makes me feel. For example, I love horror movies. I love watching them, but I cover my eyes as soon as there's something scary! You know, like a jumpscare."
pause 1
ruby "It's like I have a big ball in my stomach that explodes, my breathing stops and I have a hard time recovering. Anyway, I love it, but I'm too easily scared!"
pause 1

if persistent.patch_enabled == True:
    $ TEMP1 = e1s2m1c1
    $ TEMP2 = e1s2m1c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""

menu:
    "Invite her someday to cinema [TEMP1!t]":

        jump propcineruby
    "Not interested [TEMP2!t]":
        $ cinema = False
        jump fincineruby


label propcineruby:
scene f22
with dissolve
d "Well, if you want, we could go watch a movie together at the theater someday. It could be really fun but I don't want to pressure you into anything..."
call buddy_increased from _call_buddy_increased_1
$ cinema = True
pause 1
scene f23
with dissolve
ruby "Yes! Definitely yes!"
pause 1
d "Um..."
pause 1
scene f24
with dissolve
ruby "I've never been invited to the movie theatre even though I love it. So, yes, I accept your invitation, Cortex!"
pause 1
d "Haha! Okay, we'll go to the cinema together and I'll even let you choose the movie!"
pause 1
scene f25
with dissolve
ruby "And can you get me some popcorn to make it like a real movie experience?"
pause 1
d "Yeah sure... I'll buy you a big tub of popcorn if you want!"
pause 1
scene f26
with dissolve
ruby "I knew I made the right choice in picking you as my Cortex, I was sure of it!"
pause 1
d "Yeah... probably."
pause 1
jump fincineruby

label fincineruby:
scene f27
with dissolve
ruby "Alright, we're almost there. I'll show you your room!"
pause 1
stop music fadeout 2.0
scene black
with dissolve
pause 1
jump discoverroom




label discoverroom:
ruby "Go check out your room! I'll be there in ten minutes. My braid is a mess and I have to redo it!"
pause 1
play music "musique/Vexento_Now.mp3" volume 0.20
scene g1
with dissolve
pause 2
scene g2
with dissolve
pause 2
scene g3
with dissolve
pause 2
scene g4
with dissolve
pause 2
scene g5
with dissolve
pause 2
scene g6
with dissolve
pause 2
d "Whaaaaa! What is all this?"
scene g7
with dissolve
pause 1
d "I better not touch anything. She will be here in about ten minutes... what should I do in the meantime?"
if persistent.patch_enabled:
    if persistent.rufus4 == False:
        $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
scene g10
with dissolve
pause 1

if persistent.patch_enabled == True:
    $ TEMP1 = e1s2m2c1
    $ TEMP2 = e1s2m2c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""

menu:
    "Do push-ups [TEMP1!t]":

        call sport_increased from _call_sport_increased_1
        scene g11
        with dissolve
        d "Inhale..."
        pause 1 
        scene g12
        with dissolve
        d "Shhhh! Exhale..."
        pause 1
        scene g11
        with dissolve
        d "Inhale..."
        pause 1 
        scene g12
        with dissolve
        d "Shhhh! Exhale..."
        pause 1
        scene black
        with dissolve
        pause 2 

        show text _ ("30 push-ups later...") at truecenter
        pause 2

        scene g12
        with dissolve
        d "Shhhh! Exhale..."
        pause 1
        jump rubychambre
    "Go to the bathroom [TEMP2!t]":


        call temperament_increased from _call_temperament_increased_4
        scene g14
        with dissolve
        d "You talking to me?"
        d "Okay buddy, you have to show them how great you are!"
        d "Who's the best?"
        d "I'm the best!"
        jump rubychambre
    "Wait for Ruby":
        if persistent.rufus4 == False:
            scene g13 with dissolve
            show screen chat4() with dissolve
        else:
            scene g13
            with dissolve
        d "I hope she will explain to me why we are all alone in a bedroom..."
        pause 2
        jump rubychambre

label rubychambre:
scene g13
with dissolve
d "Okay that's enough!"
hide screen chat4
scene g8
with dissolve
d "I will have to rearrange this room. To make it feel like my own..."
pause 1
scene g9
with dissolve
d "I don't know why I have my own room but I will make it feel like home!"
pause 1
scene g15
with pushleft
ruby "Well, last week I was asked to furnish and decorate a room for a French guy who would arrive this week."
pause 1
scene g16
with dissolve
ruby "So I took a bit of everything that came my way... but I don't even know what you like! So you should definitely redecorate it..."
pause 1
scene g17
with dissolve
ruby "Anyway, do that when you have time. It's already quarter to nine, so we got to go! Get changed quickly and we'll go!"
pause 1
scene g18
with dissolve
d "Change? I don't even have my stuff! And where's your braid? Why did you change it?"
pause 1
scene g19
with dissolve
ruby "Oh my braid wasn't good, and I needed to do it quickly. Do you like it ?"
pause 1 
d "Hmm... I do like it but it changes your appearance a lot."
pause 1
ruby "Thanks, but you have to get ready. Check the wardrobe, I found some items for you. You'll find something you like, I'm sure!"
pause 1
ruby "Besides, it's all I could gather from the lost and found. Go ahead, try something on, and show me how it fits!"
pause 1
scene g20
with dissolve
d "Huh?"
pause 1
ruby "Chop chop!"
scene g22
with dissolve
pause 1
d "Okay ... what do we have here?"
pause 1 
d "Do you really want me to wear this?!"
pause 1
scene g22
with dissolve
ruby "Yeah come on! Don't act like a child!"
pause 1 
d "But..."
pause 1 
ruby "Let's go, we're already running late !"
pause 1 
d "Okay..."

jump menuvetement





label menuvetement:
$ Stripruby = False

if persistent.patch_enabled == True:
    $ TEMP1 = e1s2m3c1
    $ TEMP2 = e1s2m3c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""

menu:
    "Undress in front of her [TEMP1!t]":
        jump tenuefier
    "Ask her to turn around [TEMP2!t]":

        jump tenueshy


label tenuefier:
    scene g23
    with dissolve
    call temperament_increased from _call_temperament_increased_5
    ruby "Oh my god, oh my god, oh my god!"
    pause 1
    d "What's wrong?"
    scene g24
    with dissolve
    ruby "I'm sorry, but you're undressing in front of me and I didn't even think to close my eyes!"
    d "Ruby..."
    ruby "Oh, what my Mom must think about me? I should have turned away, but I didn't and..."
    d "Ruby..."
    scene g25
    with dissolve
    ruby "Not that you're not handsome... NO! You're definitely handsome but now that you're half naked, and it's not appropriate to leer at a... well-built man... like this..."
    scene g25
    with dissolve
    pause 2
    d "RUBY!!!" with vpunch
    ruby "Oh... yes?"
    d "Could you turn around please?"
    scene g27
    with dissolve
    ruby "Oh yes! Sure sure..."
    ruby "Whaaa... is it suddenly getting hot in here?"
    pause 1
    $ Stripruby = True
    jump rubydepart

label tenueshy:
    scene g23
    with dissolve
    d "Could you turn around please?"
    call education_increased from _call_education_increased_3
    ruby "Oh yes! Sure sure..."
    scene g27
    with dissolve
    ruby "Whaaa... is it suddenly getting hot in here?"

    jump rubydepart

label rubydepart:

scene black
with dissolve
pause 2
d "Okay! You can look now! To infinity and beyond!"
scene g28
with dissolve
ruby "Oh great! I was sure you'd find something that fit and looked good! And you have Toy Story in France too?"
pause 1
d "Hmm... you think we don't have movies?"
scene g29
with dissolve
ruby "NO! No, of course not, but I've never looked into it..."
pause 1
ruby "Did you know that Toy Story is the first movie fully animated in 3D?"
d "No, but that's interesting!"
scene g30
with dissolve
ruby "Yeah, I know! Last year we learned a lot of things about it! For example, there were more than a hundred and ten thousand frames in the movie..."
ruby "And it took from two to fifteen hours for each frame to render. So they had farm of machines to work on five hundred years of rendering time just to make the film!"
d "Ruby?"
ruby "Yes?"
d "Didn't you say we are in a hurry?"
scene g31
with dissolve
ruby "Oh! Yes! Yes, well... Cortex, are you ready to go?"

if persistent.patch_enabled == True:
    $ TEMP1 = e1s2m4c1
    $ TEMP2 = e1s2m4c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""

menu:
    "Yes Minus! [TEMP1!t]":
        call buddy_increased from _call_buddy_increased_2
        $ Achievement.add(achievement_friend)
        $ achievement.grant("friend")
        $ achievement.sync()
        jump e1s3
    "Nope [TEMP2!t]":
        ruby "Doesn't matter! We have to go! We can't be late!"
        jump e1s3

label rufusg4:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img4"):
        show img4
        hide img4
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus4 = True
    hide screen chat4
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
