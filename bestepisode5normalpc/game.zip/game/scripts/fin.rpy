label fin:
    stop music fadeout 2
    pause 2
    hide screen gameUIBEST
    scene testfull
    with fade
    pause 1 
    grace "Hey you ! Did you like the game, so far ?"
    grace "If you did, this is just the start, so be prepared for an exciting and far reaching story ahead."



















    scene black
    with fade
    pause 1            
    jump e3intro

label fingrace:
    scene test2
    with dissolve
    grace "Thank you for choosing this game. We hope you had a good time with us."

    scene black
    with fade
    pause 1
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" 
    pause 1.25
    scene coming
    with zoomout
    pause 4
    scene coming1
    with fade
    pause 1
    ji "Be careful [name]..."
    pause 2
    scene black
    with fade
    pause 0.5
    scene madgymep3 with dissolve:
        xalign 0.0
        linear 5.0 yalign 0.9
        linear 3.0 yalign 0.0
        repeat 1
    mad "Dad... Why do you want to meet him ?"
    mad "..."
    mad "I will..."
    pause 2
    scene black
    with fade
    pause 0.5
    scene coming2
    with dissolve
    ji "Do you go to the party tonight ?"
    pause 2.0
    scene black
    with fade
    pause 0.5
    scene sad1
    with dissolve
    ji "Mum..."
    scene sad2
    with dissolve
    pause 2 
    scene black
    with fade
    pause 1
    scene coming3
    with dissolve
    ruby "I have to find a dress..."
    if cinema == True:
        ruby "And another for our theater night !"
    pause 1.0
    scene black
    with fade
    pause 0.5
    scene gracenight
    with dissolve
    grace "You're the only one I want tonight..."
    pause 1
    scene episode3teaser
    with dissolve
    pause 5 
    stop music fadeout 5
    scene black
    with fade
    pause 2
    call animationbest from _call_animationbest_2
    jump e3intro
    pause 1  
    scene black
    with dissolve
    pause 2
    scene julialit4
    with fade
    julia "Hey there ! It seems you've reached the end of this update ! I hope you liked it !"
    julia "When the update is released, the Creators add it to the different websites..."
    cr "Yes, I'll do that when I understand how all of this works..."
    julia "Okay, so...If you like the game, the girls, or even the Creators, please consider showing your support !"
    julia "Tell them what you like, what you want to see in the game, which character is your favorite..."
    julia "By giving money to show your support, Creators can buy me clothes and I really LOVE clothes !!!"
    cr "You don't want a Maserati and some maids at your becken call too ???"
    julia "Well, if you're offering... Just kidding ! They can also buy new hardware to speed up the creation process... More money is more content..."
    cr "Yes you're right... one rendering or animation takes time, and we don't have a workstation from NASA..."
    scene julialit5
    with dissolve
    julia "Just please think about it !"
    julia "Well I'm not gonna keep you any longer..."
    julia "I really hope you'll come back when a new update is released !"
    julia "See you later !"
    stop music fadeout 2
    scene black with fade
    pause 2
    jump e3intro
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
