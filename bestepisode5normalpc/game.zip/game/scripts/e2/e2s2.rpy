label e2s2:
    stop music
    pause 1
    play music "musique/Vexento_Now.mp3" 
    scene c1
    with fade
    pause 1
    scene c2
    with dissolve
    pause 1 
    scene c3
    with dissolve
    pause 1 
    scene c4
    with dissolve
    d "Why are you wearing a knit cap?"
    scene c5
    with dissolve
    julia "Well... Actually, I love my hair color, but there are people I don't want to run into who might see me from afar... So, I prefer to stay incognito..."
    scene c6
    with dissolve
    d "Do you have issues?"
    scene c5
    with dissolve
    julia "Um... Not really..."
    julia "So, are you starting to get used to life here?"
    scene c6
    with dissolve
    d "Oh, you know, I've only been here for 2 days... I haven't really had much time to see anything!"
    scene c7
    with dissolve
    d "But I would really like to explore a bit, and take advantage of the fact that I have some time to get my bearings..."
    scene c8
    with dissolve
    d "With all the competition, classes about to start, and all the people I'm meeting... I can barely figure out where I am!"
    scene c9
    with dissolve
    julia "I can imagine! It must be quite a shock for you..."
    scene c10
    with dissolve
    d "Yeah, well... Actually, I just came to study..."
    scene c11
    with dissolve
    d "And now I'm caught up in the B.E.S.T program, I'm in a university dorm room that I didn't request, I've already met the principal, her daughter, you, and the others..."
    scene c12
    with dissolve
    d "I don't even know where to begin, and the classes haven't even started yet!"
    scene c13
    with dissolve
    julia "Haha! And it's not over yet! At the end of the week, there's the integration party."
    julia "It's like a big celebration with games, lots of people everywhere... it often ends up in a wild party... in every sense of the word... I hope you have a strong stomach!"
    scene c14
    with dissolve

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s2m1c1
        $ TEMP2 = e2s2m1c2
        $ TEMP3 = e2s2m1c3
        $ TEMP4 = e2s2m1c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""
    menu:
        "Buddy [TEMP1!t]":

            call buddy_increased from _call_buddy_increased_10
            scene c15
            with dissolve
            d "As long as I have people with me, it's fine! And I'm not the type to go overboard either!"
            d "Basically, I enjoy these kinds of parties when we're having fun!"
            scene c19
            with dissolve
            julia "I totally agree! It's not really my kind of party... I'm a bit of a loner..."
            julia "But I make an effort, and every year I come by to see how it's going and how the newcomers are integrating..."
        "Education [TEMP2!t]":

            call education_increased from _call_education_increased_7
            scene c16
            with dissolve
            d "Oh, you know, at these parties, you just have to avoid going overboard... Otherwise, you'll have a massive hangover the next day, and bad habits can quickly form..."
            d "And that affects your grades..."
            scene c20
            with dissolve
            julia "You take your classes very seriously, huh?"
            d "Well, yeah... no choice... Besides, if my grades aren't good, I won't be able to stay, and everything I've done so far would have been for nothing, so..."
            julia "I understand..."
        "Sport [TEMP3!t]":

            call sport_increased from _call_sport_increased_8
            scene c17
            with dissolve
            d "I only drink very little alcohol to keep in good physical condition... Sports first! Damn!"
            scene c21
            with dissolve
            julia "Oh wow! So, is Mr. already a high-level athlete?"
            scene c22
            with dissolve
            d "Nah, but I attach great importance to keeping my body in good shape to achieve the best possible performance."
            d "If I could, I would only eat turkey rice and olive oil for the good fats every day... But here, I'm afraid I might go from Blastoise to Muk..."
            scene c23
            with dissolve
            julia "Haha! For now, I'd say you're more like a Machop!"
            scene c24
            with dissolve
            d "Hey!"
        "Temperament [TEMP4!t]":

            call temperament_increased from _call_temperament_increased_10
            scene c18
            with dissolve
            d "Drinks and pretty girls? That's all I need! It promises to be a great evening!"
            scene c23
            with dissolve
            julia "Don't get ahead of yourself, Don Juan! Just because you show up doesn't mean all the girls will be at your feet!"
            julia "And you still have to hold your liquor... and don't forget there are classes the next day!"
            scene c24
            with dissolve
            d "It takes more than that to scare me! I'm going to show them who's the king of the dance floor! They'll all be dazzled by my French Touch!"
            julia "Yeah, right..."

    scene c25
    with dissolve
    julia "Anyway, almost everyone will be at this party! Usually, Madison organizes the event, but she didn't mention it to me this year..."
    julia "I think it's more difficult for her with her daughter at the moment... So, I don't even know where it will take place... Maybe you'll get more information from the others!"
    d "But you'll still come, right?"
    scene c26
    with dissolve
    julia "Yes! It's almost obligatory to make at least an appearance, otherwise, you'll be seen as anti-social... But I probably won't stay long..."
    d "We'll see... I bet Ruby will be fully into it again!"
    scene c27
    with dissolve
    julia "Oh, for sure! Every year she organizes little games with the girls... She's usually the one who makes these parties fun..."
    julia "Otherwise, we have to deal with the obnoxious guys who come to hit on you..."
    scene c28
    with dissolve
    d "Obnoxious guys?"
    scene c29
    with dissolve
    julia "Yeah, you have Steven's gang... the football guys... At every party, they come and try to outdo each other with stupid challenges to prove who's the alpha male..."
    julia "And, of course, we become their targets... but every year they try... and every year they get rejected!"
    scene c30
    with dissolve

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s2m2c1
        $ TEMP2 = e2s2m2c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Ask about her love life [TEMP1!t]":
            call temperament_increased from _call_temperament_increased_11
            d "But earlier in the park, you said you've never kissed anyone..."
            julia "Yes..."
            d "So, you've never had a boyfriend?"
            scene c31
            with dissolve
            julia "Not really... I've never felt any affection for a guy, actually... Well... I'm not sure..."
            d "Do you prefer girls then?"
            scene c32
            with dissolve
            julia "What? No! It's just that I haven't met someone who could truly interest me... Well, not yet! But it will come when it comes, honestly, it's not really a problem."
            scene c33
            with dissolve
            julia "After all, I want to explore this part of myself with someone I trust and who will help me discover it in the best way..."
        "Ask about the others [TEMP2!t]":

            call buddy_increased from _call_buddy_increased_11
            d "And the other girls? Are they also reluctant when it comes to being approached?"
            scene c34
            with dissolve
            julia "Hmm... Grace likes being approached without it going too far... She's a sweet girl..."
            julia "She won't directly say no to someone who asks her to dance or talks to her... But as soon as things start to heat up, she escapes..."
            d "She escapes?"
            scene c35
            with dissolve
            julia "Yes! Either she calls a friend to keep the guy occupied while she finds another place to go, or she leaves directly without any explanation... So, yeah... she's slippery!"
            d "Haha! And what about Ruby?"
            scene c36
            with dissolve
            julia "Oh, Ruby is different! She doesn't have time to hang out with guys because she wants to take care of everything..."
            julia "She'll be playing with us, making sure nothing is missing in the kitchen, she'll even sometimes prepare a bag with condoms and other little things for the partygoers..."
            julia "But because of that, she doesn't enjoy herself as much as she should..."
            d "I see what you mean!"
            julia "And then, on the other hand, you'll have some girls who are much less... picky... But I'll let you have the opportunity to find out for yourself... if you want!"
            scene c37
            with dissolve
            d "I'll see how it goes..."

    scene c38
    with dissolve
    pause 2

    if Redpath or Bluepath:
        julia "Earlier in the park, the girls were talking about something... about the twins... What were they talking about?"

        if Grope == True:

            if persistent.patch_enabled == True:
                $ TEMP1 = e2s2m3c1
                $ TEMP2 = e2s2m3c2
            else:
                $ TEMP1 = ""
                $ TEMP2 = ""
            menu:
                "I like Blue [TEMP1!t]":

                    $ Bluepath = True
                    scene c39
                    with dissolve
                    d "I really like Blue..."
                    scene c40
                    with dissolve
                    julia "Huh?"
                    scene c41
                    with dissolve
                    d "Yeah! She's special, I don't know what to say..."
                    scene c44
                    with dissolve
                    julia "Hmm... I understand why Madison said that then... It's going to be harder for you to be accepted by Maddie now!"
                    d "We'll see how it goes..."
                "I don't like Blue [TEMP2!t]":

                    $ Bluepath = False
                    scene c39
                    with dissolve
                    d "Well, I have the twin in blue who approached me... but I'm not interested in her..."
                    scene c40
                    with dissolve
                    julia "Oh really?"
                    scene c42
                    with dissolve
                    d "Yeah... She's not my type, those kind of girls... Let her go with the football guys and the obnoxious ones, as you say!"
                    scene c43
                    with dissolve
                    julia "Haha! Well, you're scoring points with Maddie there! It'll be easier for you to be accepted by her if you're not with the twins! Even more so if you brush them off!"
                    d "We'll see how it goes..."

        if Grope == False:

            if persistent.patch_enabled == True:
                $ TEMP1 = e2s2m4c1
                $ TEMP2 = e2s2m4c2
            else:
                $ TEMP1 = ""
                $ TEMP2 = ""

            menu:
                "I like Red [TEMP1!t]":

                    $ Redpath = True
                    scene c39
                    with dissolve
                    d "I really like Red..."
                    scene c40
                    with dissolve
                    julia "Huh?"
                    scene c41
                    with dissolve
                    d "Yeah! She's special, I don't know what to say..."
                    scene c44
                    with dissolve
                    julia "Hmm... I understand why Ruby said that then... It's going to be harder for you to be accepted by Maddie now!"
                    d "We'll see how it goes..."
                "I don't like Red [TEMP2!t]":
                    $ Redpath = False
                    scene c39
                    with dissolve
                    d "Well, I have the twin in red who approached me... but I'm not interested in her..."
                    scene c40
                    with dissolve
                    julia "Oh really?"
                    scene c42
                    with dissolve
                    d "Yeah... She's not my type, those kind of girls... Let her go with the football guys and the obnoxious ones, as you say!"
                    scene c43
                    with dissolve
                    julia "Haha! Well, you're scoring points with Maddie there! It'll be easier for you to be accepted by her if you're not with the twins! Even more so if you brush them off!"
                    d "We'll see how it goes..."

    scene black
    with fade
    pause 2 
    scene c51
    with dissolve
    pause 2
    scene c50
    with dissolve
    pause 2
    scene c47
    with dissolve
    pause 2
    scene c48
    with dissolve
    pause 2
    scene c49
    with dissolve
    pause 2
    julia "Anyway, there's the campus swimming pool! Grace spends most of her afternoons there training."
    scene c45
    with dissolve
    julia "If you don't know where she is... Well, just go there, you'll probably find her!"
    pause 2
    scene c46
    with dissolve
    d "Okay!"
    pause 2
    scene c56
    with dissolve
    julia "Next to it, you have the gym... We passed by there earlier to change. That's where you'll mostly find Madison..."
    julia "She trains there regularly. You'll probably run into Steven and the others too... But well..."
    scene c30
    with dissolve
    d "And you don't go there?"
    scene c9
    with dissolve
    julia "Actually... Between classes and... Well, no, I don't really have the time..."
    d "Okay."
    scene c52
    with dissolve
    julia "Over there, you have The Grand Theater and the shops... You'll find everything you need if you need clothes or feel like going to the nearby pub."
    d "Wow, it's like a mini city, isn't it?"
    scene c53
    with dissolve
    julia "Yeah, you can see it that way! But I have to warn you... Most of the businesses are owned by the Emerick family or the Twins..."
    d "Do they have that much money?"
    scene c54
    with dissolve
    julia "Um... Yeah, even more than you can imagine... But their parents make them work to learn the value of money, from what I understand..."
    julia "So, Red takes care of the clothing store that she manages and gives good advice... As for Emerick... You'll see his little schemes soon enough..."
    d "And what about Blue?"
    julia "Oh, she's much less interested in money and more interested in... well, human relationships, let's say!"
    scene c55
    with dissolve
    julia "But she's often at the cinema or the bowling alley! And she also trains for the team... At least, no one can fault her for that..."
    scene c57
    with dissolve
    d "And what do you do in all of this?"
    scene c58
    with dissolve
    julia "Me? Um..."
    scene c59
    with dissolve
    scene c60
    with dissolve
    scene c61
    with dissolve
    julia "Oh, well, we've arrived at the library, and it's already getting late!"
    julia "I have to leave you here! If you have any questions, don't hesitate to send me a message! "
    julia "And besides, we'll see each other tomorrow in economics class!"
    scene c62
    with dissolve
    d "Uh... Yeah... Okay!"
    julia "See you tomorrow then!"
    d "See ya!"
    scene c63
    with dissolve
    dpense "Strangely, she didn't answer my questions about what she does..."
    pause 1

    $ Gracephone = False
    $ Bluephone = False
    $ Madisonphone = False
    $ Redphone = False
    $ Erinphone = False
    $ Gabyphone = False

    label menumya:
        show screen gameUIBEST

        if persistent.patch_enabled == True:
            $ TEMP1 = e2s2m5c1
            $ TEMP2 = e2s2m5c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""


        menu:
            "Visit the swimming pool [TEMP1!t]" if Piscine == True or Bluepath == True:
                jump pool
            "Return to my room [TEMP2!t]":
                $ Gracepath = False
                $ MeetErin = False
                jump e2s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
