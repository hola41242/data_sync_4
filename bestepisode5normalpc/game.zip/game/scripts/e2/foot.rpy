label foot:
    show screen gameUIBEST
    stop music fadeout 2
    pause 2 
    play music "musique/Vexento_Now.mp3" 
    scene foot1
    with fade
    dpense "In the locker room, it's always the same routine..."
    dpense "First the left leg... always..."
    scene foot2
    with dissolve
    dpense "Then the right leg... always..."
    scene foot18
    with dissolve
    dpense "And after that, it's time to focus on the goal."
    if madiruby == True:
        scene foot3
        with dissolve
        mad "Move out of the way!" with hpunch
        d "Huh?"
        scene foot4
        with dissolve
        d "What are you doing here?"
        scene foot5
        with dissolve
        with vpunch
        mad "Well, the twins showed up in the girls' locker room, so I need a quiet place... And it seems you've found a locker room just for yourself..."
        scene foot6
        with dissolve
        mad "Anyway..."
        scene foot7
        with dissolve
        dpense "Is she really going to change here? In front of me?"
        scene foot8
        with dissolve
        pause 1 
        if persistent.streaming == True:
            jump madivestfin
        scene foot9
        with dissolve
        mad "What? Have you never seen a woman before or something?"
        scene foot10:
            xalign 0.0
            linear 5.0 yalign 0.5
            linear 1.0 yalign 0.1
            repeat 1
        with dissolve
        d "Uh... yeah..."
        label madivestfin:
            pause 1
        scene foot11
        with dissolve
        mad "Enjoying the view, are you?"
        scene foot12
        with dissolve
        d "Well, you just came in here and started changing right in front of me..."
        scene foot13
        with dissolve
        mad "We're on the same team..."
        scene foot14
        with dissolve
        mad "So I have nothing to hide from you..."
        dpense "Well, she's certainly not hiding anything now..."
        dpense "She's really beautiful..."
        dpense "And so athletic... I wouldn't want to play against her..."
        scene foot15
        with dissolve
        mad "Alright, let's get going..."
        scene foot16
        with dissolve
        mad "By the way, who's the hottie now?"
        d "Huh?"
        scene foot17
        with dissolve
        mad "..."
        scene foot16
        with dissolve
        dpense "Ah, I see! It was comparing her to Ruby earlier that made her come to me... She's competitive and it's getting to her..."
        dpense "Don't worry, Madison... You're the hottie... There's no doubt about that..."

    scene foot18
    with dissolve
    d "Let's go..."
    scene foot19
    with dissolve
    d "There's a match to win..."
    scene black
    with fade
    pause 1
    scene foot20
    with fade
    pause 1
    mad "Okay Girls ! I hope you're ready !"
    ruby "Sure !!!"
    pause 1  
    scene foot21
    with dissolve
    mad "It looks like the first matches are over..."
    pause 1 
    scene foot22
    with dissolve
    julia "Yeah, Steven won his first match."
    pause 1 
    scene foot23
    with dissolve
    grace "It seems Emerick won too."
    pause 1 
    scene foot24
    with dissolve
    d "Do you know the opposing team?"
    mad "No... Who cares ?"
    pause 1 
    scene foot25
    with dissolve
    mad "One goal : Win !"
    pause 1 
    scene foot26
    with dissolve
    mad "Do as I say, and it'll be a breeze."
    mad "Stay at the back and move up as soon as we get the ball..."
    d "Okay..."
    pause 1 
    orushi "Dear participants, the rules are simple..." with hpunch
    scene foot27
    with dissolve
    orushi "The first team to score 3 points wins..."
    orushi "No goalkeeper... "
    scene score
    with fade
    orushi "You'll be playing on half of the soccer field."
    orushi "The first team in alphabetical order kicks off."
    orushi "May the best team win."
    stop music fadeout 2
    pause 1
    play sound "sound/Sifflet.mp3"
    scene foot28
    with dissolve
    pause 0.2 
    scene foot29
    with dissolve
    pause 0.2 
    scene foot30
    with dissolve
    pause 0.2 
    scene foot31
    with dissolve
    d "Here we go..."
    pause 1 
    scene foot32vite
    with dissolve
    pause 0.1
    scene foot33vite
    with dissolve
    pause 0.1 
    scene foot32vite
    with dissolve
    pause 0.1 
    scene foot33vite
    with dissolve
    pause 0.1 
    scene foot34
    with dissolve
    dpense "Julia charges at her..."
    scene foot35
    with dissolve
    play music "musique/Jens_East_-_Daybreak_feat_Henk.mp3" 
    dpense "What ????"
    scene foot36vite
    with dissolve
    pause 0.5 
    scene foot37
    with dissolve
    pause 0.5  
    scene foot38
    with dissolve
    with flash
    with vpunch
    with flash
    pause 1 
    scene foot39
    with hpunch
    with dissolve
    pause 1 
    scene foot40
    with dissolve
    dpense "She didn't hold back..."
    pause 1 
    scene foot41
    with dissolve
    dpense "Okay, Madison said: once we have the ball, you move forward..."
    dpense "So..."
    pause 1 
    scene foot42
    with dissolve
    dpense "I move forward..."
    pause 1 
    scene foot43
    with dissolve
    pause 1 
    scene foot44
    with dissolve
    pause 1 
    scene foot45
    with dissolve
    dpense "She passes the ball to Ruby..."
    scene foot46vite
    with pushleft
    pause 1 
    scene foot47
    with pushleft
    with hpunch
    dpense "Nice control..."
    scene foot48
    with dissolve
    pause 1 
    scene foot49
    with dissolve
    pause 1 
    scene foot50
    with dissolve
    pause 1 
    scene foot51
    with dissolve
    pause 1 
    scene foot52
    with dissolve
    with hpunch
    dpense "She's passing it to me..."
    scene foot53vite
    with pushright
    pause 1 
    scene foot54
    with pushright
    with hpunch
    pause 1 
    scene foot55
    with dissolve
    dpense "It's my turn to play..."
    scene foot56
    $ renpy.movie_cutscene("images/animation/foot1.webm", stop_music=False)
    scene foot56
    with dissolve
    $ Soloplay = True
    $ Juliaplay = True
    $ Madiplay = True
    $ MadiGoal = 0
    $ McGoal = 0

    if persistent.patch_enabled == True:
        $ TEMP1 = e2footm1c1
        $ TEMP2 = e2footm1c2
        $ TEMP3 = e2footm1c3
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""

    menu:

        "Play solo [TEMP1!t]" if Sport > 4 and Soloplay == True:
            jump solofoot1
        "Pass it to Julia [TEMP2!t]":
            jump juliafoot1
        "Pass it to Madison [TEMP3!t]":
            jump madisonfoot1

    label solofoot1:
        scene foot57
        with dissolve
        pause 1 
        scene foot58
        with dissolve
        dpense "Right..."
        pause 1 
        scene foot59
        with dissolve
        dpense "Left..."
        pause 1 
        scene foot60
        with dissolve
        pause 1 
        scene foot61
        with dissolve
        dpense "Right..."
        pause 1 
        scene foot62
        with dissolve
        dpense "And left !!!!"
        pause 1 
        scene foot63
        with dissolve
        pause 1 
        scene foot64
        with dissolve
        dpense "Come on, we need to score the first one!"
        pause 1 
        scene foot65
        with dissolve
        d "Go for it!" with hpunch
        pause 1  
        if Sport > 8:
            scene foot66
            $ renpy.movie_cutscene("images/animation/foot2a.webm", stop_music=False)
            scene foot66
            with dissolve
            pause 1
            scene foot76
            with dissolve
            play sound "sound/Sifflet.mp3"
            d "Yes !"
            $ McGoal = McGoal+1
            ruby "Well done [name]!"
            scene score1
            with hpunch
            orushi "0 - 1 for team H..."
            orushi "Team H, your turn to engage..."
            $ Soloplay = False
            jump footpart2
        else:

            scene foot67
            $ renpy.movie_cutscene("images/animation/foot2b.webm", stop_music=False)
            scene foot67
            with dissolve
            pause 1
            scene foot77
            with dissolve
            d "Shit..."
            scene foot69
            with dissolve
            pause 1 
            scene foot78
            with dissolve
            d "Huh ???"
            scene black
            $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
            scene foot68
            with dissolve
            pause 1
            scene foot70
            with hpunch
            pause 1 
            scene foot71
            with dissolve
            pause 0.2 
            scene foot72 with hpunch
            with dissolve
            mad "Hyaaaaaaaa..."
            with flash
            with hpunch
            with flash
            pause 0.5
            scene foot73
            with dissolve
            pause 0.2 
            scene foot74
            with dissolve
            pause 1 
            scene foot75
            with dissolve
            play sound "sound/Sifflet.mp3"
            mad "Yes !"
            mad "And that's 1!"
            $ MadiGoal = MadiGoal+1
            pause 1.0
            scene score1
            with hpunch
            orushi "0 - 1 for team H..."
            orushi "Team H, your turn to engage..."
            $ Soloplay = False
            jump footpart2

    label juliafoot1:
        $ Juliaplay = False
        scene foot79
        with dissolve
        d "Julia ! For you !"
        scene black
        $ renpy.movie_cutscene("images/animation/foot4.webm", stop_music=False)
        scene foot80
        with dissolve
        pause 1 
        scene foot81
        with dissolve
        pause 1 
        scene foot82
        with dissolve
        dpense "She's jongling ???"
        scene foot83
        with dissolve
        julia "Hop !"
        scene foot84
        with dissolve
        julia "Hop !"
        scene foot85
        with dissolve
        pause 1
        scene foot86
        with dissolve
        pause 1 
        scene foot87
        with dissolve
        pause 1 
        if madiruby == True:
            $ renpy.movie_cutscene("images/animation/foot6.webm", stop_music=False)
            scene foot88
            with dissolve
            dpense "It's high !"
            pause 1 
            scene foot89
            with dissolve
            dpense "I'm going to try a bicycle kick!"
            if Sport > 9:
                scene foot90
                with dissolve
                d "Go for it !" with hpunch
                scene foot73
                with dissolve
                pause 0.2 
                scene foot74
                with dissolve
                pause 0.5 
                scene foot94
                with dissolve
                pause 1
                scene foot76
                with dissolve
                play sound "sound/Sifflet.mp3"
                d "Yes !"
                $ McGoal = McGoal+1
                scene foot106
                with dissolve
                ruby "Well done [name]!"
                scene score1
                with hpunch
                orushi "0 - 1 for team H..."
                orushi "Team H, your turn to engage..."
                jump footpart2
            else:

                scene foot91
                with dissolve
                d "Too high !!!"
                scene black
                $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
                scene foot70
                with dissolve
                with vpunch
                scene foot92
                with dissolve
                ruby "Han !!!!"
                with hpunch
                with flash
                with hpunch
                scene foot93
                with dissolve
                pause 0.5 
                scene foot73
                with dissolve
                pause 0.2 
                scene foot74
                with dissolve
                pause 0.5 
                scene foot94
                with dissolve
                pause 1
                scene foot76
                with dissolve
                play sound "sound/Sifflet.mp3" 
                d "Yes !"
                scene foot106
                with dissolve
                d "Well done Ruby!"
                scene foot107
                with dissolve
                ruby "Did you see that?"
                scene score1
                with hpunch
                orushi "0 - 1 for team H..."
                orushi "Team H, your turn to engage..."
                jump footpart2
        else:

            scene foot95
            with dissolve
            mad "And this is the first one !!!"
            scene black
            $ renpy.movie_cutscene("images/animation/footmaditir1.webm", stop_music=False)
            scene foot66
            with dissolve
            pause 1 
            scene foot26
            with dissolve
            pause 1
            scene foot76
            with dissolve
            play sound "sound/Sifflet.mp3" 
            d "Yes !"
            $ MadiGoal = MadiGoal+1
            scene foot106
            with dissolve
            d "Well done Madison!"
            scene foot107
            with dissolve
            ruby "You're too strong Maddie !"
            scene score1
            with hpunch
            orushi "0 - 1 for team H..."
            orushi "Team H, your turn to engage..."
            jump footpart2

    label madisonfoot1:
        $ Madiplay = False
        scene foot85
        with dissolve
        pause 1
        scene foot86
        with dissolve
        pause 1 
        scene foot87
        with dissolve
        scene foot95
        with dissolve
        mad "And this is the first one !!!"
        scene black
        $ renpy.movie_cutscene("images/animation/footmaditir1.webm", stop_music=False)
        scene foot66
        with dissolve
        pause 1 
        scene foot26
        with dissolve
        pause 1
        scene foot76
        with dissolve
        play sound "sound/Sifflet.mp3"
        d "Yes !"
        $ MadiGoal = MadiGoal+1
        d "Well done Madison!"
        scene foot107
        with dissolve
        ruby "You're too strong Maddie !"
        scene score1
        with hpunch
        orushi "0 - 1 for team H..."
        orushi "Team H, your turn to engage..."
        jump footpart2


label footpart2:

    scene foot25
    with dissolve
    mad "It's our turn to engage so... We go allin !"
    grace "Okay !"
    scene foot26
    with dissolve
    mad "Let's go for the second goal !!!"
    pause 1 
    scene foot102
    with dissolve
    pause 1
    scene foot103
    with dissolve
    pause 1 
    scene foot104
    with dissolve
    dpense "That's a tsunami who advance on the field..."
    scene foot105
    with dissolve
    pause 1
    scene foot54
    with dissolve
    pause 1

    if persistent.patch_enabled == True:
        $ TEMP1 = e2footm2c1
        $ TEMP2 = e2footm2c2
        $ TEMP3 = e2footm2c3
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""

    menu:

        "Play solo [TEMP1!t]" if Sport > 4 and Soloplay == True:
            jump solofoot2
        "Pass it to Julia [TEMP2!t]" if Juliaplay == True:
            jump juliafoot2
        "Pass it to Madison [TEMP3!t]" if Madiplay == True:
            jump madisonfoot2

    label solofoot2:
        scene foot57
        with dissolve
        pause 1 
        scene foot58
        with dissolve
        dpense "Right..."
        pause 1 
        scene foot59
        with dissolve
        dpense "Left..."
        pause 1 
        scene foot60
        with dissolve
        pause 1 
        scene foot61
        with dissolve
        dpense "Right..."
        pause 1 
        scene foot62
        with dissolve
        dpense "And left !!!!"
        pause 1 
        scene foot63
        with dissolve
        pause 1 
        scene foot64
        with dissolve
        dpense "Come on, we need to score again!"
        pause 1 
        scene foot65
        with dissolve
        d "Go for it!" with hpunch
        pause 1  
        if Sport > 8:
            scene foot66
            $ renpy.movie_cutscene("images/animation/foot2a.webm", stop_music=False)
            scene foot66
            with dissolve
            pause 1
            scene foot76
            with dissolve
            play sound "sound/Sifflet.mp3" 
            d "Yes !"
            $ McGoal = McGoal+1
            ruby "Well done [name]!"
            scene score2
            with hpunch
            orushi "0 - 2 for team H..."
            orushi "Team D, your turn to engage..."
            $ Soloplay = False
            jump footpart3
        else:

            scene foot67
            $ renpy.movie_cutscene("images/animation/foot2b.webm", stop_music=False)
            scene foot67
            with dissolve
            pause 1
            scene foot77
            with dissolve
            d "Shit..."
            scene foot69
            with dissolve
            pause 1 
            scene foot78
            with dissolve
            d "Huh ???"
            scene black
            $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
            scene foot68
            with dissolve
            pause 1
            scene foot70
            with hpunch
            pause 1 
            scene foot71
            with dissolve
            pause 0.2 
            scene foot72 with hpunch
            with dissolve
            mad "Hyaaaaaaaa..."
            with flash
            with hpunch
            with flash
            pause 0.5
            scene foot73
            with dissolve
            pause 0.2 
            scene foot74
            with dissolve
            pause 1 
            scene foot75
            with dissolve
            play sound "sound/Sifflet.mp3"
            mad "Yes !"
            mad "And that's 2!"
            $ MadiGoal = MadiGoal+1
            pause 1.0
            scene score2
            with hpunch
            orushi "0 - 2 for team H..."
            orushi "Team D, your turn to engage..."
            $ Soloplay = False
            jump footpart3

    label juliafoot2:
        $ Juliaplay = False
        scene foot79
        with dissolve
        d "Julia ! For you !"
        scene black
        $ renpy.movie_cutscene("images/animation/foot4.webm", stop_music=False)
        scene foot80
        with dissolve
        pause 1 
        scene foot81
        with dissolve
        pause 1 
        scene foot82
        with dissolve
        dpense "She's jongling ???"
        scene foot83
        with dissolve
        julia "Hop !"
        scene foot84
        with dissolve
        julia "Hop !"
        scene foot85
        with dissolve
        pause 1
        scene foot86
        with dissolve
        pause 1 
        scene foot87
        with dissolve
        pause 1 
        if madiruby == True:
            scene foot88
            $ renpy.movie_cutscene("images/animation/foot6.webm", stop_music=False)
            scene foot88
            with dissolve
            dpense "It's high !"
            pause 1 
            scene foot89
            with dissolve
            dpense "I'm going to try a bicycle kick!"
            if Sport > 9:
                scene foot90
                with dissolve
                d "Go for it !" with hpunch
                scene foot73
                with dissolve
                pause 0.2 
                scene foot74
                with dissolve
                pause 0.5 
                scene foot94
                with dissolve
                pause 1
                scene foot76
                with dissolve
                play sound "sound/Sifflet.mp3"
                d "Yes !"
                $ McGoal = McGoal+1
                scene foot106
                with dissolve
                ruby "Well done [name]!"
                scene score2
                with hpunch
                orushi "0 - 2 for team H..."
                orushi "Team D, your turn to engage..."
                jump footpart3
            else:

                scene foot91
                with dissolve
                d "Too high !!!"
                scene black
                $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
                scene foot70
                with dissolve
                with vpunch
                scene foot92
                with dissolve
                ruby "Han !!!!"
                with hpunch
                with flash
                with hpunch
                scene foot93
                with dissolve
                pause 0.5
                scene foot73
                with dissolve
                pause 0.2 
                scene foot74
                with dissolve
                pause 0.5 
                scene foot94
                with dissolve
                pause 1
                scene foot76
                with dissolve
                play sound "sound/Sifflet.mp3"
                d "Yes !"
                scene foot106
                with dissolve
                d "Well done Ruby!"
                scene foot107
                with dissolve
                ruby "Did you see that?"
                scene score2
                with hpunch
                orushi "0 - 2 for team H..."
                orushi "Team D, your turn to engage..."
                jump footpart3
        else:

            scene foot95
            with dissolve
            mad "And this is the second !!!"
            scene black
            $ renpy.movie_cutscene("images/animation/footmaditir1.webm", stop_music=False)
            scene foot66
            with dissolve
            pause 1 
            scene foot26
            with dissolve
            pause 1
            scene foot76
            with dissolve
            play sound "sound/Sifflet.mp3"
            d "Yes !"
            $ MadiGoal = MadiGoal+1
            d "Well done Madison!"
            scene foot107
            with dissolve
            ruby "You're too strong Maddie !"
            scene score2
            with hpunch
            orushi "0 - 2 for team H..."
            orushi "Team D, your turn to engage..."
            jump footpart3

    label madisonfoot2:
        $ Madiplay = False
        scene foot85
        with dissolve
        pause 1
        scene foot86
        with dissolve
        pause 1 
        scene foot87
        with dissolve
        scene foot95
        with dissolve
        mad "And this is second !!!"
        scene black
        $ renpy.movie_cutscene("images/animation/footmaditir1.webm", stop_music=False)
        scene foot66
        with dissolve
        pause 1 
        scene foot26
        with dissolve
        pause 1
        scene foot76
        with dissolve
        play sound "sound/Sifflet.mp3" 
        d "Yes !"
        $ MadiGoal = MadiGoal+1
        d "Well done Madison!"
        scene foot107
        with dissolve
        ruby "You're too strong Maddie !"
        scene score2
        with hpunch
        orushi "0 - 2 for team H..."
        orushi "Team D, your turn to engage..."
        jump footpart3

label footpart3:

    scene foot25
    with dissolve
    mad "It's the last one..."
    d "Yeah !"
    if madiruby == True:
        mad "[name]?"
        d "Yeah ?"
        mad "When you have the ball..."
        mad "Pass it to me !"
        d "Okay..."
        $ Supermad = True
    else:
        $ Supermad = False
    scene foot26
    with dissolve
    mad "Let's go for victory!!!"
    ruby "Yeah !!!"
    scene foot97
    with dissolve
    pause 1
    scene foot98
    with dissolve
    pause 1 
    scene foot99
    with dissolve
    d "Good job Grace !"
    scene foot100
    with dissolve
    pause 0.5
    scene foot101
    with dissolve
    dpense "Tunnel !"
    pause 0.2 
    scene foot102
    with dissolve
    d "Super Grace !"
    scene foot103
    with dissolve
    pause 1
    scene foot95
    with dissolve
    pause 1

    if persistent.patch_enabled == True:
        $ TEMP1 = e2footm3c1
        $ TEMP2 = e2footm3c2
        $ TEMP3 = e2footm3c3
        $ TEMP4 = e2footm3c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "Play with Madison [TEMP1!t]" if Supermad == True:
            jump Supermad

        "Play with Julia [TEMP2!t]" if Juliaplay == True:
            jump juliafoot3

        "Play solo [TEMP3!t]" if Sport > 4 and Soloplay == True:
            jump solofoot3
        "Play with Ruby [TEMP4!t]":

            jump rubyfoot3

    label Supermad:
        scene foot87
        with hpunch
        with dissolve
        pause 1 
        scene foot96
        with dissolve
        mad "I will show them why they call me the tigress !"
        scene foot87
        with dissolve
        mad "Hyaaaaaaaaaaaaaaa!!!!"
        with vpunch
        with flash
        scene black
        $ renpy.movie_cutscene("images/animation/footmaditir2.webm", stop_music=False)
        scene foot112
        with dissolve
        play sound "sound/Sifflet.mp3" 
        mad "Victory !"
        $ MadiGoal = MadiGoal+1
        $ MadVictory = True
        pause 1
        scene score3
        with hpunch
        orushi "0 - 3 for team H..."
        orushi "Team D, you are eliminated..."
        jump finfoot1

    label juliafoot3:
        $ Juliaplay = False
        scene foot79
        with dissolve
        d "Julia ! For you !"
        scene black
        $ renpy.movie_cutscene("images/animation/foot4.webm", stop_music=False)
        scene foot80
        with dissolve
        pause 1 
        scene foot81
        with dissolve
        pause 1 
        scene foot82
        with dissolve
        dpense "She's jongling ???"
        scene foot83
        with dissolve
        julia "Hop !"
        scene foot84
        with dissolve
        julia "Hop !"
        scene foot85
        with dissolve
        pause 1
        scene foot86
        with dissolve
        pause 1 
        scene foot87
        with dissolve
        pause 1 
        if madiruby == True:
            $ renpy.movie_cutscene("images/animation/foot6.webm", stop_music=False)
            scene foot88
            with dissolve
            dpense "It's high !"
            pause 1 
            scene foot89
            with dissolve
            dpense "I'm going to try a bicycle kick!"
            if Sport > 9:
                scene foot90
                with dissolve
                d "Go for it !" with hpunch
                scene foot73
                with dissolve
                pause 0.2 
                scene foot74
                with dissolve
                pause 0.5 
                scene foot94
                with dissolve
                pause 1
                scene foot76
                with dissolve
                play sound "sound/Sifflet.mp3" 
                d "Yes !"
                $ McGoal = McGoal+1
                scene foot106
                with dissolve
                ruby "Well done [name]!"
                scene score3
                with hpunch
                orushi "0 - 3 for team H..."
                orushi "Team D, you are eliminated..."
                jump footpart3
            else:

                scene foot91
                with dissolve
                d "Too high !!!"
                scene black
                $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
                scene foot70
                with dissolve
                with vpunch
                scene foot92
                with dissolve
                ruby "Han !!!!"
                with hpunch
                with flash
                with hpunch
                scene foot93
                with dissolve
                pause 0.5 
                scene foot73
                with dissolve
                pause 0.2 
                scene foot74
                with dissolve
                pause 0.5 
                scene foot94
                with dissolve
                pause 1
                scene foot76
                with dissolve
                play sound "sound/Sifflet.mp3" 
                d "Yes !"
                scene foot106
                with dissolve
                d "Well done Ruby!"
                scene foot107
                with dissolve
                ruby "Did you see that?"
                scene score3
                with hpunch
                orushi "0 - 3 for team H..."
                orushi "Team D, you are eliminated..."
                jump finfoot1
        else:

            scene foot95
            with dissolve
            mad "And this is the third !!!"
            scene black
            $ renpy.movie_cutscene("images/animation/footmaditir1.webm", stop_music=False)
            scene foot66
            with dissolve
            pause 1 
            scene foot26
            with dissolve
            pause 1
            scene foot76
            with dissolve
            play sound "sound/Sifflet.mp3" 
            d "Yes !"
            $ MadiGoal = MadiGoal+1
            d "Well done Madison!"
            scene foot107
            with dissolve
            ruby "You're too strong Maddie !"
            scene score3
            with hpunch
            orushi "0 - 3 for team H..."
            orushi "Team D, you are eliminated..."
            jump finfoot1

    label solofoot3:
        scene foot57
        with dissolve
        pause 1 
        scene foot58
        with dissolve
        dpense "Right..."
        pause 1 
        scene foot59
        with dissolve
        dpense "Left..."
        pause 1 
        scene foot60
        with dissolve
        pause 1 
        scene foot61
        with dissolve
        dpense "Right..."
        pause 1 
        scene foot62
        with dissolve
        dpense "And left !!!!"
        pause 1 
        scene foot63
        with dissolve
        pause 1 
        scene foot64
        with dissolve
        dpense "Come on, we need to score again!"
        pause 1 
        scene foot65
        with dissolve
        d "Go for it!" with hpunch
        pause 1  
        if Sport > 8:
            scene foot66
            $ renpy.movie_cutscene("images/animation/foot2a.webm", stop_music=False)
            scene foot66
            with dissolve
            pause 1
            scene foot76
            with dissolve
            play sound "sound/Sifflet.mp3"
            d "Yes !"
            $ McGoal = McGoal+1
            ruby "Well done [name]!"
            scene score3
            with hpunch
            orushi "0 - 3 for team H..."
            orushi "Team D, you are eliminated..."
            jump finfoot1
        else:

            scene foot67
            $ renpy.movie_cutscene("images/animation/foot2b.webm", stop_music=False)
            scene foot67
            with dissolve
            pause 1
            scene foot77
            with dissolve
            d "Shit..."
            scene foot69
            with dissolve
            pause 1 
            scene foot78
            with dissolve
            d "Huh ???"
            scene black
            $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
            scene foot68
            with dissolve
            pause 1
            scene foot70
            with hpunch
            pause 1 
            scene foot71
            with dissolve
            pause 0.2 
            scene foot72 with hpunch
            with dissolve
            mad "Hyaaaaaaaa..."
            with flash
            with hpunch
            with flash
            pause 0.5
            scene foot73
            with dissolve
            pause 0.2 
            scene foot74
            with dissolve
            pause 1 
            scene foot75
            with dissolve
            play sound "sound/Sifflet.mp3"
            mad "Yes !"
            mad "And that's 3!"
            $ MadiGoal = MadiGoal+1
            pause 1.0
            scene score3
            with hpunch
            orushi "0 - 3 for team H..."
            orushi "Team D, you are eliminated..."
            jump finfoot1

    label rubyfoot3:
        scene foot47
        with dissolve
        with hpunch
        dpense "Nice control..."
        pause 1 
        scene foot48
        with dissolve
        pause 1 
        scene foot49
        with dissolve
        pause 1 
        scene foot50
        with dissolve
        pause 1 
        scene foot51
        with dissolve
        pause 1 
        scene foot52
        with dissolve
        with hpunch
        dpense "She's passing it to me..."
        pause 1 
        scene foot53vite
        with dissolve
        pause 1 
        scene foot63
        with dissolve
        d "And this is for the third goal !!!" with hpunch
        scene foot64
        with dissolve
        pause 0.5 
        scene foot65
        with dissolve
        pause 0.2
        scene foot66
        $ renpy.movie_cutscene("images/animation/foot2a.webm", stop_music=False)
        scene foot66
        with dissolve
        play sound "sound/Sifflet.mp3"
        $ McGoal = McGoal+1
        pause 1
        scene score3
        with hpunch
        orushi "0 - 3 for team H..."
        orushi "Team D, you are eliminated..."
        jump finfoot1

label finfoot1:
    scene foot107
    with dissolve
    ruby "We are the winners !!!"
    scene foot108
    with dissolve
    ruby "Ahahahahah !"
    scene foot109
    with dissolve
    ruby "I'm so proud of you..."
    if McGoal == 0:
        ruby "Even if you don't have score any goal !"
        $ Achievement.add(achievement_rubydesolation)
        $ achievement.grant("rubydesolation")
        $ achievement.sync()
    if McGoal > 0:
        scene foot110
        with dissolve
        grace "You even score a goal !"
        if McGoal > 1:
            scene foot111
            with dissolve
            julia "And more..."
            $ Achievement.add(achievement_haremvibe)
            $ achievement.grant("haremvibe")
            $ achievement.sync()


    orushi "Well, that's the end of this match..."
    orushi "The best scorer is :"
    if McGoal > MadiGoal:
        orushi "Student [name]!"
        $ Rank = Rank-5
    if MadiGoal > McGoal:
        orushi "Student Madison!"
        $ Rank = Rank+5
        if Rank > 50:
            $ Rank = 50
    if MadiGoal == 3:
        $ Achievement.add(achievement_hattrick)
        $ achievement.grant("hattrick")
        $ achievement.sync()
    orushi "The next match will take place on Monday..."
    orushi "Until then... You're free..."
    orushi "End of transmission..."
    stop music fadeout 2 
    scene black
    with fade

    scene fingrace1
    with fade
    dpense "A good thing done..."
    scene fingrace2
    with dissolve
    dpense "It was an easy match, and the girls were fantastic..."
    scene fingrace3
    with dissolve
    dpense "Grace's passes, Julia's footwork, Madison's strikes... I had almost nothing to do."
    scene fingrace4
    with dissolve
    dpense "The next match will surely be more challenging..."
    scene fingrace5
    with dissolve
    dpense "In the meantime, back to the locker room..."
    if Gracephone == True:
        play music "musique/Vexento_Now.mp3" volume 0.20
        scene fingrace7
        with dissolve
        pause 2
        scene fingrace8
        with dissolve
        pause 2
        scene fingrace9
        with dissolve
        pause 2
        grace "[name] !!!"
        scene black
        $ renpy.movie_cutscene("images/animation/gracerun.webm", stop_music=False)
        scene fingrace6
        with dissolve
        grace "[name] wait !!!"
        scene fingrace10
        with dissolve
        d "Hummm ?"
        grace "You were awesome today..."
        grace "Between the choice challenge..."

        if BlueTrust == True:
            scene fingrace11
            with dissolve
            d "I didn't do much; it was mostly Blue who helped me... She knew where the last ball was..."
            d "I don't know how, but something tells me her sister isn't a stranger to all of this..."
            grace "Oh..."
            scene fingrace13
            with dissolve
            grace "You're close to Blue..."
            scene fingrace14
            with dissolve
            grace "The pool, and now this..."

            if persistent.patch_enabled == True:
                $ TEMP1 = e2footm4c1
                $ TEMP2 = e2footm4c2
            else:
                $ TEMP1 = ""
                $ TEMP2 = ""

            menu:
                "You mean more to me [TEMP1!t]":
                    jump gracekiss
                "I like her, yes... [TEMP2!t]":
                    jump graceleave
        else:
            scene fingrace11
            with dissolve
            d "I didn't do much; it was mostly Ruby who helped me."
            jump gracekiss

        label gracekiss:
            scene fingrace12
            with dissolve
            grace "Please close your eyes!"
            d "Huh?"
            scene fingrace11
            with dissolve
            grace "Close your eyes..."
            d "Okay..."
            scene fingrace15
            with dissolve
            grace "There's something I want to do, but I don't have the courage..."
            scene fingrace16
            with dissolve

            if persistent.patch_enabled == True:
                $ TEMP1 = e2footm5c1
                $ TEMP2 = e2footm5c2
            else:
                $ TEMP1 = ""
                $ TEMP2 = ""

            menu:
                "Let her continue [TEMP1!t]":
                    d "Go ahead, do it!"
                    jump gracekiss2
                "Don't [TEMP2!t]":
                    d "We shouldn't..."
                    jump graceleave

        label gracekiss2:
            if _in_replay:
                show screen Replayexit      
            scene fingrace17
            with dissolve
            grace "It'll be easier if you have your eyes closed..."
            d "If you say so..."
            scene fingrace18
            $ renpy.movie_cutscene("images/animation/graceprekiss.webm", stop_music=False)
            pause 1
            grace "Since you arrived, Ruby has been happy..."
            scene fingrace19
            with dissolve
            grace "Julia has changed her hairstyle three times already..."
            grace "Even Madison is more... pleasant..."
            d "Uh..."
            scene fingrace20
            with dissolve
            grace "Shh..."
            scene fingrace22
            with dissolve
            grace "You've been a gentleman at my place..."
            scene fingrace21
            with dissolve
            grace "I'm glad we met..."
            grace "And as a result..."
            scene fingrace24
            with dissolve
            pause 1
            scene fingrace25
            $ renpy.movie_cutscene("images/animation/gracekiss.webm", stop_music=False)
            scene fingrace25
            pause 1
            d "You just kissed me..."
            grace "Yeah... And it was great..."
            scene fingrace26
            with dissolve
            grace "I'm so happy !!! I never thought I could do it..."
            d "You know that I wanted to do it since I saw you ?"
            scene fingrace27
            with dissolve
            grace "Oh ?"
            grace "Now you can do it when you want..."
            d "In that case..."
            scene fingrace28
            with dissolve
            pause 1 
            play movie "images/animation/gracekiss2.webm" loop 
            show movie with dissolve
            dpense "I can feel her heart beating so strongly..."
            dpense "Don't worry Grace, I will take care of you..."
            dpense "You're the most beautiful woman I ever met..."
            dpense "And you think so much about others that you forget about yourself..."
            dpense "I'll be there for you..."
            scene fingrace29
            with dissolve
            stop movie
            grace "That was... unexpected..."
            grace "But very pleasant too !"
            grace "I have to go... See you tomorrow ? In class ?"
            d "Yeah ! Sure !"
            scene fingrace30
            with dissolve
            grace "Oh ! Don't forget my party tomorrow !"
            d "Don't worry ! I won't !"
            scene fingrace31
            with dissolve
            dpense "I can't believe I'm with this goddess..."
            dpense "How lucky I am..."
            $ Achievement.add(achievement_firstkiss)
            $ achievement.grant("firstkiss")
            $ achievement.sync()
            stop music fadeout 2.0
            dpense "Well... Back to the locker room..."
            pause 1
            $ Gracepath = True
            play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
            scene fingrace23
            with dissolve
            pause 1
            beth "Shit..."
            scene fingrace32
            with dissolve
            pause 2
            scene black
            with dissolve
            pause 1
            $ renpy.notify(_("New Scene Gallery added"))
            $ renpy.end_replay()
            stop music fadeout 2.0
            pause 1 
            jump vestiairesfinep21

        label graceleave:
            scene fingrace12
            with dissolve
            grace "Ohhh... Hummm... I should leave, I have some errands to do for the party tomorrow..."
            scene fingrace30
            with dissolve
            grace "See you in class in the morning !"
            scene fingrace31
            with dissolve
            if persistent.patch_enabled:
                if persistent.rufus9 == False:
                    $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
            d "Oh... Okay ! See you tomorrow !"
            stop music fadeout 2.0
            $ Gracepath = False
            pause 1
            play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
            if persistent.rufus9 == False:
                scene fingrace23 with dissolve
                show screen chat9() with dissolve
            else:
                scene fingrace23
                with dissolve
            pause 1
            if Bluepath == True:
                beth "Good job sis..."
            hide screen chat9
            scene fingrace33
            with dissolve
            pause 2
            scene black
            with dissolve
            pause 1
            stop music fadeout 2.0
            pause 1 
            jump vestiairesfinep21
    else:

        $ Gracepath = False
        jump vestiairesfinep21


label vestiairesfinep21:
    scene black
    with fade
    play music "musique/Nomyn-Fragments.mp3" volume 0.2
    pause 1
    if madiruby == True:
        scene madplus1
        with dissolve
        d "Damn, we really showed them!"
        scene madplus2
        with dissolve
        d "And you girls, you were really amazing!"
        scene madplus3
        with dissolve
        mad "Meh..."
        d "But seriously... You didn't tell me you were this good!"
        scene madplus4
        with dissolve
        mad "It was a game... Well, I wouldn't even call it a game, actually..."
        scene madplus6
        with dissolve
        mad "Next time, it'll be completely different..."
        scene madplus7
        with dissolve
        d "Yeah, but can't we celebrate anyway?"
        mad "Go ahead, be my guest!"
        scene madplus8
        with dissolve
        pause 1
        scene madplus9
        with dissolve
        pause 1
        scene madplus10
        with dissolve
        pause 1
        scene madplus11
        with dissolve

        if persistent.patch_enabled == True:
            $ TEMP1 = e2footm6c1
            $ TEMP2 = e2footm6c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""

        menu:
            "Give her a hug [TEMP1!t]":
                jump madicalin
            "Leave her alone [TEMP2!t]":
                jump madinocalin
    else:
        $ madipath = False
        jump chambrefinep2

    label madinocalin:
        scene madplus12
        with dissolve
        mad "Uh??? What are you doing here?"
        d "Well, a celebration!"
        scene madplus13
        with dissolve
        with hpunch
        mad "Yeah, yeah... see you later..."
        scene madplus14
        with dissolve
        d "Hey !!!"
        scene madplus15
        with dissolve
        d "It's not easy with her..."
        $ madipath = False
        jump chambrefinep2

    label madicalin:
        scene madplus16
        with dissolve
        mad "Uh??? What are you doing here?"
        d "Well, a team celebration?"
        mad "And do you need to stick to me like that?"
        d "Let go for once... Madison..."

        if Bluepath or Redpath:
            scene madplus20
            with dissolve
            mad "No, sorry... I'd rather leave before one of the twins shows up and suggests something involving more people..."
            scene madplus13
            with dissolve
            with hpunch
            d "What?"
            scene madplus14
            with dissolve
            mad "Yeah, yeah... See you later..."
            scene madplus15
            with dissolve
            d "It's not easy with her..."
            $ madipath = False
            jump chambrefinep2
        else:

            scene madplus17
            with dissolve
            mad "I can't let go as I want, [name]..."
            scene madplus18
            with dissolve
            mad "My life is such a mess that I can't let anything or anyone into it right now..."
            mad "I have my daughter, my studies, the competition... Nothing will disrupt my..."
            d "You're not alone..."
            d "And I don't intend to disrupt your life..."
            d "But I can make it better..."
            scene madplus19
            with dissolve
            mad "Yes..."
            mad "No..."
            mad "I..."
            scene madplus20
            with dissolve
            mad "Can't..."
            d "Don't worry..."
            d "We have time..."
            scene madplus21
            with dissolve
            mad "Sorry..."
            scene madplus22
            with dissolve
            d "Alright, I'm going to the shower... See you later?"
            scene madplus23
            with dissolve
            mad "Hmm? Oh, yeah, sure..."
            scene madplus24
            with dissolve
            pause 1

            if madiconf == True:
                scene madplus23
                with dissolve
                pause 1
                mad "Oh, to hell with it!"
                pause 1
                scene black
                with fade
                jump vestiairesfinep2
            else:
                $ madipath = False
                scene black
                with fade
                jump chambrefinep2

label vestiairesfinep2:
    if _in_replay:
        $ madiconf = True
        $ Bluepath = False
        show screen Replayexit
    if madiconf==True and Bluepath==False:
        scene j3
        with fade
        pause 1 
        scene j5
        with dissolve
        pause 1 
        play music "musique/Lyvo-Home.mp3" volume 0.2
        scene finmad1
        with dissolve
        pause 2 
        if persistent.streaming == True:
            jump finmadi1
        scene finmad2
        with dissolve
        pause 1 
        scene finmad3
        with dissolve
        pause 2
        scene finmad4
        with dissolve
        pause 2 
        scene finmad5
        with dissolve
        pause 2
        scene finmad6
        with dissolve
        label finmadi1:
            pause 1
        d "No... Is this a joke?"
        scene finmad7
        with hpunch
        with dissolve
        pause 1 
        scene finmad8
        with dissolve
        mad "Shh! Listen, I've had a stressful morning, and after all of this, I..."
        mad "Need to relieve some tension..."
        mad "You know what I mean?"
        scene finmad7
        with dissolve
        pause 0.2
        scene finmad10
        with dissolve
        pause 0.2
        scene finmad7
        with dissolve
        pause 0.2 
        scene finmad10
        with dissolve
        pause 0.2
        scene finmad9
        with dissolve
        pause 0.2
        mad "So, you have a choice, either I leave, and we end it here..."
        mad "Or we have a little fun together... You and me..."
        if persistent.streaming == True:
            jump finmadi2
        scene finmad11
        with dissolve
        pause 1
        mad "And of course... Nobody must know anything about this... And, this won't happen again..."
        label finmadi2:
            pause 1
        scene finmad12
        with dissolve
        mad "So ?"

        if persistent.patch_enabled == True:
            $ TEMP1 = e2footm7c1
            $ TEMP2 = e2footm7c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""

        menu:
            "Accept [TEMP1!t]":
                jump madifinep2
            "Refuse [TEMP2!t]":
                jump madileaveep2
    else:

        $ madipath = False
        jump chambrefinep2

label madileaveep2:
    if persistent.streaming == True:
        scene black
        with dissolve
        jump madifin3
    scene finmad29
    with dissolve
    label madifin3:
        pause 1
    mad "What a disappointement..."
    $ madipath = False
    stop music fadeout 2 
    scene black
    with fade
    pause 1
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    jump chambrefinep2

label madifinep2:
    $ madipath = True
    mad "Don't waste time..."
    if persistent.streaming == True:
        jump madifin4

    scene finmad14
    with dissolve
    pause 1 
    scene finmad15
    with dissolve
    pause 1 
    mad "Hum ? You're already ready to go, nice!"
    d "I..."
    mad "Shhhh..."
    label madifin4:
        pause 1
    scene finmad16
    with dissolve
    mad "Go ahead [name] ! Show me what you can do!"
    dpense "This girl..."
    scene finmad17
    with dissolve
    mad "And go for it ! I'm not made of sugar!"
    if persistent.streaming == True:
        scene black
        with dissolve
        pause 1
        jump madifin5
    play movie "images/animation/lev2madep2.webm" loop 
    show movie with dissolve
    pause 1
    dpense "Wah... She's tight !"
    dpense "And wet as fuck !"
    mad "Go on [name] ! Harder !"
    pause 1
    stop movie
    play movie "images/animation/lev1madep2.webm" loop 
    show movie with dissolve
    pause 1
    mad "Yes..."
    pause 2
    mad "Deeper..."
    pause 2
    mad "Hummm..."
    scene finmad18
    with dissolve
    stop movie
    mad "Like that... Continue..."
    scene finmad19
    with dissolve
    play movie "images/animation/lev2madep2.webm" loop 
    show movie with dissolve
    mad "Hum... You're really not bad..."
    pause 2 
    stop movie
    scene finmad19
    with dissolve
    mad "And what if you show me your athletic skills ?"
    d "How ?"
    mad "Hold me !"
    scene finmad21
    with dissolve
    pause 1 
    play movie "images/animation/madport3.webm" loop 
    show movie with dissolve
    mad "Oh Fuck... Yes !!!"
    dpense "That pussy... She sucks me in more and more..."
    pause 2
    mad "Again [name]... That's so good !!!"
    dpense "She's shaking..."
    pause 1
    stop movie 
    play movie "images/animation/madport2.webm" loop 
    show movie with dissolve
    pause 1
    mad "Oh my god... I'm very close to..."
    dpense "I'm not far behind..."
    pause 2
    mad "Humpfff... Continue [name] !"
    mad "Don't you dare stop now !"
    pause 2
    stop movie
    play movie "images/animation/madport1.webm" loop 
    show movie with dissolve
    pause 1
    mad "Again ! Yes ! Again !"
    pause 1
    mad "I want more ! I want..."
    pause 1
    with flash
    with vpunch
    mad "Ahhhhhhhh !"
    with flash
    with vpunch
    mad "Yeeeeeeeeessssss !"
    with flash
    with vpunch
    scene finmad23
    stop movie
    with flash
    with vpunch
    mad "Oh fuck... [name]!"
    with vpunch
    with flash
    with vpunch
    pause 1 
    scene finmad20
    with dissolve
    mad "You... Humpff... "
    pause 1 
    mad "I... Fshhhhh..."
    pause 1
    d "Speechless ?"
    mad "Shhh !!!"
    pause 1
    mad "You didn't finish ?"
    d "No..."
    mad "Okay..."
    scene finmad24
    with dissolve
    mad "Do it on my tits..."
    pause 1
    mad "Come on... Release your hot load on my tits !"
    with flash
    with hpunch
    scene finmad25
    with dissolve
    with flash
    with vpunch
    pause 1 
    scene finmad26
    with dissolve
    d "Fuck..."
    pause 1
    mad "Wow... What a load..."
    pause 1 
    scene finmad27:
        xalign 0.0
        linear 6.0 yalign 0.99
        linear 3.0 yalign 0.0
        repeat 1
    mad "Erkk..."
    $ Achievement.add(achievement_onetime)
    $ achievement.grant("onetime")
    $ achievement.sync()
    pause 1 
    mad "I should go wash it..."
    d "You can take my shower... I'm finished..."
    mad "No... It smells... Sex..."
    scene finmad28
    with dissolve
    label madifin5:
        pause 1
    mad "Thank you [name]..."
    d "Hummm... You're welcome ?"
    mad "Oh and..."
    mad "Of course... This is a one-time thing !"
    mad "Dont get ideas..."
    scene black
    with fade
    d "Of course..."
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    stop music fadeout 2 
    pause 2
    jump chambrefinep2

label chambrefinep2:
    scene black
    with fade
    stop music fadeout 2.0
    pause 1 
    play music "musique/NovaNoma-Gaia.mp3" volume 0.2
    scene a1
    with fade
    pause 1
    scene d3
    with dissolve
    pause 1 
    with hpunch
    d "A message ?"
    call phone_discussion_eli from _call_phone_discussion_eli
    d "Just have to wait..."
    with hpunch
    phone discussion "eli1":
        time year 2023 month 9 day 3 hour 14 minute 01
        "elise" "Ahah ! So funny !"
        "d" ":) So how are you ?"
        "elise" "Oh wait I will call you !"      
        "d" "?"
    phone end discussion
    pause 1 
    scene black
    play movie "images/animation/d4_1.webm" loop 
    show movie with dissolve
    eli "Can you see me ?"
    d "Yes !"
    eli "Good !"
    eli "It's so nice to see you!"
    d "Haha... I haven't changed in a week either, you know!"
    eli "But I miss our calls!"
    d "Well, yeah..."
    eli "So, how's it going in America?"
    pause 1 
    dpense "I tell her everything about the Academy and the B.E.S.T. All that's happened from the beginning."
    eli "Wahhh.... What a story !"
    eli "Wait a second, I'm getting on my bed !"
    scene black
    with dissolve
    stop movie
    pause 1
    play movie "images/animation/d42.webm" loop 
    show movie with dissolve
    eli "Did you meet some girls ?"
    d "I met some girls on the plane..."
    if Grope == True:
        d "I groped one... Julia... I don't know why but when she was in front of me... My hand was drawn by her butt... "
        show juliagrope moving
        pause 1
    d "The first day some twins talked to me... One is Blue and other is Red..."
    if Grope == True:
        d "The Blue one tried to impress me..."
        show blueacademy moving
        pause 1
    else:
        d "The Red one tried to challenge me... "
        show redacademy moving
        pause 1
    d "Then I did the first trial of the B.E.S.T with:"
    if rubytrial == True:
        d "Ruby..."
    if juliatrial == True:
        d "Julia..."
    if gracetrial == True:
        d "Grace..."
    if madtrial == True:
        d "Madison..."
    d "That was an obstacle course in teamwork..."
    if prem == True:
        d "I almost won the challenge..."
        show madprem moving
        pause 1
    if Bluepath == True:
        d "During my shower in the locker room... The Blue twin came and gives me a blowjob as a reward... "
        if persistent.streaming == True:
            jump elisechoix1
        show bluejob moving
        label elisechoix1:
            pause 1
        eli "No !!!! You're serious ???"
        d "Yeah ! I had just finished my shower when she arrived!"
        eli "What a slut !"
        d "Hum... Yes and no..."
        eli "Oh ?"
        d "Yeah... i think she wants to help me during the competition..."
        d "Not sure why but..."
    if Redpath == True:
        d "During my shower in the locker room... The Red twin came and was hot as fuck to try a french kiss... "
        show redkiss moving
        pause 1
        eli "No !!!! You're kidding ???"
        d "Yeah ! I had just finished my shower when she arrived!"
        eli "What a slut !"
        d "Hum... Yes and no..."
        eli "Oh ?"
        d "Yeah... I think she wants to dominate me during the competition..."
        d "To have an advantage or something..."
    d "Then I've gone to a park with the girls..."
    d "They asked me who was my favourite between them..."
    d "You know the girltalk as usual..."
    d "So I told them that [chosen] is my favourite..."
    eli "Oh ! What did she say ?"
    d "She was happy..."
    if helpgabi == True:
        d "I told them that I have a kink for Milfs..."
        eli "Wow wow wow... How did you come to this kind of discussion ? "
        d "Well, Ruby gave us the rules of the Visual Novels..."
        eli "What ?"
        d "Yeah... No... Well... The subject was about the kinks of the players and she said something about the Milfs..."
        eli "Hum... Okay..."
        d "Then they talked about their teacher who is a very beautiful woman but it seems that she is alone... or something like that..."
        d "And they decided that she will be my milf..."
        eli "Are they crazy ?"
        d "Yeah a little..."
    if MeetErin == True:
        d "Then, at the swimming pool I met Gabriella...The teacher..."
        if Bluepath == True:
            d "And I met the Blue twin and give her some kind of domination introduction..."
            if persistent.streaming == True:
                jump elisechoix2
            show bluepool moving
            label elisechoix2:
                pause 1
            eli "You're kidding ?"
            d "No ! I swear ! I promised her that I would made her squirting and..."
            eli "You did ???"
            d "Yes ! Just with my fingers !"
            eli "Ohhh...."
            d "She liked that and I think she likes me now cause she tries to help me during the last trial..."
            eli "Okay..."
        if McFavor == True:
            d "I won a race in the swimming pool against Grace... Now she owes me a favor..."
            show pool moving
            pause 1
        if GraceFavor == True:
            d "I lost a race in the swimming pool against Grace... Now I owe her a favor..."
            show pool moving
            pause 1
    if JuliaPath == True:
        d "Ruby asked me if I like Julia so I told her that she is an interesting girl..."
        show juliaphone moving
        pause 1
        d "Then I had some messages from Julia yesterday night and I think we really get along well..."
    d "Today was a tough one too..."
    d "I was on team with Ruby, Madison, Julia and Grace..."
    d "And we had to play a football match..."
    d "But before that there was a game to know which team will participate and which one won't..."
    if BlueTrust == True:
        d "I listened to the advice of Blue and I won the game... I owe her one..."
    if BlueTrust == False:
        d "I listened to the advice of Ruby and I won the game..."
    d "Then we played the match..."
    d "We won it 3-0..."
    eli "Oh ! Congratulations !"
    d "That was an easy match..."
    d "I don't know who will be our next opponents..."
    if Gracepath == True:
        d "After the match Grace came to me and we kissed..."
        show gracekiss moving
        pause 1
        d "That was awesome..."
        eli "Someone is already in love ?"
        d "No... But... She's fantastic..."
    if madipath == True:
        d "In the shower Madison was excited after the match and...And, to relieve some stress... "
        if persistent.streaming == True:
            jump elisechoix4
        show madishower moving
        label elisechoix4:
            pause 1
        d "She asked me to fuck her..."
        eli "Noooooooo !"
        d "Yes... It was great but she said it was a one-time thing so..."
        eli "Hummm... Was she as great as me ?"
        d "It was... different... Don't worry I haven't forgot you !"
    eli "Oh my god... You've been there 4 days and you're already messing around with a lot of girls..."
    d "Yeah..."
    eli "Be careful Casanova... Or it's going to end badly..."
    d "Don't worry! I've got this!"
    eli "Yeah yeah... Every time you say that... It was worse..."
    eli "Well... It's 11PM here so I need to get some sleep..."
    eli "I miss you my friend..."
    d "I miss you too..."
    eli "I'll call you soon !"
    d "I'm waiting for your call !"
    eli "See ya ! Kiss !"
    d "Good night Elise..."
    scene black
    with dissolve
    stop movie
    pause 2
    with fade
    stop music fadeout 2.0
    pause 2

label finep2:
    play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
    pause 1
    scene walkblue1
    with fade
    pause 1
    scene black
    $ renpy.movie_cutscene("images/animation/walkblue.webm", stop_music=False)
    scene walkblue2
    with dissolve
    pause 1 
    scene walkblue3
    with dissolve
    pause 1 
    scene walkblue4
    with dissolve
    pause 1 
    scene walkblue5
    with dissolve
    pause 1 
    emerick "I want you to take care of him..."
    scene walkblue6
    with dissolve
    pause 1
    ji "Don't worry... he'll leave that field on a stretcher..."
    scene walkblue7
    with dissolve
    pause 1
    sofia "Oh no..."
    scene black
    with fade
    pause 1 
    sofia "[name]..."
    pause 2 
    stop music fadeout 2.0
    jump e3intro

label rufusg9:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img9"):
        show img9
        hide img9
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus9 = True
    hide screen chat9
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
