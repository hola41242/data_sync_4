label e2s4:
    show screen gameUIBEST
    pause 2
    ji "Uncle Ted! I want to watch Paw Patrol!"
    ted "Nah, Cassie, it's not cartoon time right now."
    cassie "But I really want to watch!"
    ted "No, no..."
    scene e2s41
    with fade
    cassie "Please, please, please!!!"
    ted "I said no, Cassie! It's already 8:30 AM, and..."
    scene e2s42
    with hpunch
    with dissolve
    mad "8:30 ???"
    play music "musique/Vendredi_Follow_me.mp3" 
    scene e2s43
    with vpunch
    with dissolve
    mad "Damn, I'm gonna be late!"
    scene e2s44
    with hpunch
    with dissolve
    pause 1
    scene e2s45
    with dissolve
    mad "What should I wear?"
    mad "Oh, this will do!"
    scene e2s46
    with dissolve
    mad "Ted! Is Cassie dressed?"
    ted "Yeah, yeah..."
    mad "Don't forget to drop her off at school!"
    ted "Yeah, yeah..."
    mad "And make sure she has her snack!"
    ted "Yeah, yeah..."
    scene e2s47
    with dissolve
    mad "Yeah, yeah... Yeah, yeah... Does he know how to say anything else?"
    scene e2s48
    with dissolve
    mad "Cassie, I'm leaving! See you tonight, sweetheart!"
    cassie "See you tonight, Mom! And I get my bedtime story tonight, right? You promised!"
    mad "Of course! Promise!"
    cassie "Yeah!"
    scene e2s49
    with dissolve
    mad "Alright, a new day..."
    scene e2s410
    with dissolve
    pause 1
    scene e2s411
    with dissolve
    pause 1
    scene black
    with fade
    pause 1
    scene e2s412
    with fade
    pause 1
    scene e2s413
    with dissolve
    mad "Here we go again..."
    mad "Economics class..."
    scene e2s414
    with dissolve
    mad "Training..."
    mad "Picking up Cassie from school..."
    scene e2s415
    with dissolve
    mad "And I have to deal with these two..."
    beth "Well, Madison, did you forget to get dressed this morning?"
    sofia "Or did Mom and Dad stop buying you dresses?"
    scene e2s416
    with dissolve
    mad "You see this one?"
    scene e2s417
    with dissolve
    mad "Shove it where the sun don't shine."
    scene e2s418
    with dissolve
    pause 1
    scene e2s419
    with dissolve
    ruby "Hey there!"
    mad "Hi, Ruby..."
    ruby "Tough morning?"
    scene e2s420
    with dissolve
    mad "Yeah, I woke up late, didn't even have time to get ready or give Cassie a kiss before I had to leave..."
    mad "So I just grabbed the first things I could find..."
    scene e2s421
    with dissolve
    ruby "Oh, you know, you don't need to dress up like a diva every day, right?"
    mad "Yeah, I know, but still..."
    mad "And my brother, I have to repeat everything to him a hundred times..."
    mad "Exhausting..."
    ruby "You should take a breather..."
    ruby "And maybe meet someone new!"
    scene e2s420
    with dissolve
    mad "I don't have time for that!"
    mad "And who would want a single mother with a useless brother, a crazy schedule, and a completely chaotic life..."
    scene e2s422
    with dissolve
    ruby "I might have a little idea..."
    mad "Huh?"
    ruby "Oh, never mind..."
    scene e2s423
    with dissolve
    d "Okay, this is the right classroom..."
    scene e2s424
    with dissolve
    d "But where should I sit?"

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s4m1c1
        $ TEMP2 = e2s4m1c2
        $ TEMP3 = e2s4m1c3
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""

    menu:
        "Sit with Madison and Ruby [TEMP1!t]":
            $ madiruby = True
            jump madiruby
        "Sit with Grace and Julia [TEMP2!t]":
            $ madiruby = False
            jump gracejulia
        "Sit with the twins [TEMP3!t]" if Bluepath or Redpath:
            $ madiruby = False
            jump sittwins

    label madiruby:
        scene e2s446
        with dissolve
        d "Mind if I sit here, Ladies ?"
        scene e2s452
        with dissolve
        ruby "Of course!"
        scene e2s451
        with dissolve
        mad "Yes, yes, of course..."
        scene e2s453
        with dissolve
        d "It feels strange to be here... in a classroom..."
        scene e2s455
        with dissolve
        ruby "Surrounded by girls..."
        d "Huh? Um... yeah, that too!"
        scene e2s454
        with dissolve
        mad "It doesn't seem like you mind..."
        d "No, not at all..."
        scene e2s456
        with dissolve
        ruby "No wonder! The guy's sitting next to a hottie..."
        ruby "He's not going to complain, right?"
        mad "Ruby... Stop it!"
        d "She's not wrong!"
        scene e2s457
        with dissolve
        mad "Oh, really?"
        d "I didn't say you were the hottie!"
        scene e2s458
        with dissolve
        mad "Oh!"
        scene e2s459
        with dissolve
        ruby "Oh?"
        jump suitecours

    label gracejulia:
        scene e2s450
        with dissolve
        d "Mind if I sit here, Ladies ?"
        scene e2s449
        with dissolve
        grace "Of course!"
        scene e2s448
        with dissolve
        julia "Yes, yes, of course..."
        scene e2s460
        with dissolve
        d "It feels strange to be here... in a classroom..."
        scene e2s461
        with dissolve
        julia "Is this your first class, then?"
        d "Yes... I hope the teacher will be nice!"
        scene e2s462
        with dissolve
        julia "Don't worry... She's cool..."
        julia "As long as you don't disrupt her class!"
        d "Okay..."

        if Gracepath == True:
            scene e2s463
            with dissolve
            grace "I'm still sorry about my mom yesterday..."
            d "Don't worry... It happens..."
            scene e2s464
            with dissolve
            grace "I really enjoyed that time with you..."
            d "I hope there will be more..."
            scene e2s465
            with dissolve
            grace "Me too..."

        jump suitecours

    label sittwins:
        scene e2s425
        with dissolve
        d "Mind if I sit here, Ladies?"
        scene e2s426
        with dissolve
        beth "Of course, with pleasure!"
        scene e2s427
        with dissolve
        sofia "Uh... Yes, of course!"
        scene e2s428
        with dissolve
        sofia "So, is this your first class?"
        d "Yes... I don't even know what to bring..."
        scene e2s429
        with dissolve
        beth "It's always like that the first time..."
        beth "A bit painful... But once you get going..."
        beth "You'll want more..."
        scene e2s430
        with dissolve
        sofia "Don't worry about my sister... She doesn't bite... Well, maybe not..."
        scene e2s431
        with dissolve
        d "Oh, I'm not afraid! It's not with her mouth that she'll get to me..."
        scene e2s432
        with dissolve
        beth "Oh yeah? Are you sure?"
        scene e2s466
        with dissolve
        beth "They say I'm not bad with my mouth, though..."
        beth "Unless you prefer..."
        scene e2s433
        with dissolve
        beth "Closer and..."
        beth "Rougher..."
        scene e2s434
        with dissolve
        sofia "Or that we fulfill all your desires..."
        sofia "Even the most unspoken ones..."
        scene e2s467
        with dissolve
        sofia "By going further and..."
        sofia "Deeper into..."
        sofia "Things..."
        scene e2s435
        with dissolve
        d "Uh..."
        pause 1
        jump suitecours

    label suitecours:
        scene e2s436
        with dissolve
        with hpunch
        gaby "Hello, everyone!"
        scene e2s437
        with dissolve
        gaby "I'm Gabriella, your economics teacher..."
        scene e2s438
        with dissolve
        gaby "Some of you may know me as the coach of the women's soccer team..."
        gaby "While others are complete strangers to me..."
        scene e2s439
        with dissolve
        gaby "Let's not beat around the bush... I like it when people are direct and straightforward with me... If you're not here to work or if you're not interested..."
        gaby "You can leave right now..."
        scene e2s440
        with dissolve
        gaby "For the rest of you..."
        gaby "Well, I'm always available to answer your questions, and I'll be happy to help you!"
        scene e2s441
        with dissolve
        gaby "I see that the French student is among us... [name], is that right?"
        d "Yes, ma'am..."
        gaby "Very well, I see that you're starting to find your way around and that you haven't gotten lost this time..."
        scene e2s440
        with dissolve
        if MeetErin == True:
            gaby "And dressed appropriately this time!"
            d "Yes..."
        gaby "So, how are these first days going for you?"

        if persistent.patch_enabled == True:
            $ TEMP1 = e2s4m2c1
            $ TEMP2 = e2s4m2c2
            $ TEMP3 = e2s4m2c3
            $ TEMP4 = e2s4m2c4
        else:

            $ TEMP1 = ""
            $ TEMP2 = ""
            $ TEMP3 = ""
            $ TEMP4 = ""

        menu:
            "Buddy [TEMP1!t]":
                call buddy_increased from _call_buddy_increased_14
                d "I've met some wonderful people since I arrived, and I must admit I don't yet know what I should do to thank them for their hospitality..."
                ruby "Awww! That's so sweet!!!"
                scene e2s441
                with dissolve
                gaby "You girls... always too kind!"
                gaby "Very well..."
            "Education [TEMP2!t]":

                call education_increased from _call_education_increased_9
                d "You know, I don't believe there's such a thing as a good or bad situation..."
                scene e2s441
                with dissolve
                gaby "Interesting!"
                scene e2s443
                gaby "Do you think the world isn't black and white? That it's not all black or all white?"
                d "I don't know... I just think we shouldn't always see the glass as half empty..."
                gaby "Very well..."
            "Sport [TEMP3!t]":

                call sport_increased from _call_sport_increased_13
                d "I have the competition on my mind... The rest, for now, is a bit above me..."
                scene e2s442
                with dissolve
                gaby "The B.E.S.T? You're a part of it?"
                d "Well, I'm as surprised as you are... but yes..."
                gaby "Very well..."
            "Temperament [TEMP4!t]":

                call temperament_increased from _call_temperament_increased_16
                d "Well, listen, I'm living my best life right now! I'm meeting girls from all over, I'm in the B.E.S.T... and seriously, having such a beautiful teacher is really nice... it makes me want to come to class!"
                scene e2s442
                with dissolve
                gaby "Uh... I wasn't expecting that..."
                d "Haha! I'm full of surprises!"
                scene e2s441
                with dissolve
                gaby "And cheeky too..."
                gaby "Very well..."

        scene e2s444
        with dissolve
        gaby "So, I see you've started to form some Franco-American relationships..."
        gaby "Who can tell me, except [name], what gift France gave to the United States to celebrate American independence?"

        if madiruby == True:
            scene e2s457
            with dissolve
            d "Do you trust me?"
            if Bluepath or Redpath:
                scene e2s458
                with dissolve
                mad "Not particularly..."
                d "The Statue of Liberty."
                scene e2s457
                with dissolve
                mad "Are you sure?"
                d "Yes, yes..."
                emerick "The Statue of Liberty!" with hpunch
                scene e2s458
                with dissolve
                d "Oh damn..."
                scene e2s444
                with dissolve
                gaby "Yes, that's correct, Emerick..."
                mad "I'm sorry..."
                $ madiconf = False
            else:

                scene e2s457
                with dissolve
                mad "Uh... Yes..."
                d "The Statue of Liberty."
                mad "Okay."
                mad "The Statue of Liberty?"
                scene e2s444
                with dissolve
                gaby "Yes!"
                emerick "Damn, I knew it!"
                gaby "Please mind your language, Emerick!"
                emerick "Sorry, ma'am!"
                scene e2s454
                with dissolve
                mad "Thank you !"
                $ madiconf = True
        else:

            dpense "The Statue of Liberty"
            emerick "The Statue of Liberty!" with hpunch
            d "Oh damn..."
            scene e2s444
            with dissolve
            gaby "Yes, that's correct, Emerick..."
            $ madiconf = False

        scene e2s443
        with dissolve
        gaby "Okay, today's class will focus on the general principles of economics..."
        scene black
        with fade
        pause 1 
        scene e2s439
        with dissolve
        gaby "And so, it's all about supply and demand..."
        drew "To all B.E.S.T. participants..." with hpunch
        scene e2s445
        with dissolve
        drew "You are requested to gather at the center of the stadium in 10 minutes..."
        drew "I repeat..."
        drew "All B.E.S.T. participants must gather at the center of the stadium in 10 minutes..."
        scene e2s440
        with dissolve
        gaby "Well, I guess the class is over..."
        gaby "Good luck to everyone!"

        scene black
        with fade
        stop music fadeout 2
        pause 3 

        play music "musique/Stellardrone-ToTheGreatBeyond.mp3"
        play movie "images/animation/troupe.webm" loop 
        show movie with dissolve
        orushi "Welcome, dear participants of B.E.S.T..."
        orushi "There are now only 50 of you left in this competition that will reward the best among you..."
        orushi "First and foremost, I want to congratulate you on successfully completing the first challenge..."
        orushi "Today, we have a somewhat special challenge in store for you..."
        orushi "Indeed, I've decided to add a bonus challenge to the selection process..."
        orushi "This challenge will not be elimination-based..."
        orushi "Considering the performances of both male and female teams in football..."
        orushi "I thought it would be interesting to bring out your team spirit..."
        orushi "While evaluating your athletic abilities..."
        orushi "So, we've organized a tournament..."
        orushi "Which will consist of several direct elimination matches..."
        orushi "Ultimately, it will determine the most outstanding team..."
        orushi "Of course, if there's no elimination, there still needs to be something at stake..."
        orushi "So, we've decided to reward the team that wins this tournament with a special bonus..."
        orushi "See for yourselves..."
        stop movie 
        scene black
        pause 1
        play movie "images/animation/maison2.webm" loop 
        show movie with dissolve
        orushi "The winning team will get to enjoy this house, located not far from the campus, throughout the duration of B.E.S.T..."
        orushi "The house has five individual bedrooms and all the necessary comforts for training, resting, and preparing for the upcoming B.E.S.T challenges under the best possible conditions..."
        orushi "Of course, all this comes at a price..."
        stop movie 
        scene black with fade
        scene e2s497
        with fade
        orushi "And as you may have understood, you'll be competing in teams of 5 to earn this privilege..."
        scene e2s498
        with fade
        orushi "This is to assess your motivation, performance, and the level of connection you have with others..."
        scene e2s499
        with fade
        orushi "You will compose your own teams..."
        scene e2s4100
        with fade
        orushi "Just a piece of advice: think about optimizing your players..."
        orushi "There's nothing for the losers..."
        scene e2s468
        with dissolve
        orushi "To form your teams, the computer has selected captains who will choose their teammates for this challenge..."
        orushi "Here is the list of players selected as captains:"
        orushi "Student Steven..."
        scene e2s469
        with dissolve
        s "Yes, sir..."
        orushi "You will be the captain of Team A..."
        scene e2s471
        with dissolve
        s "Very well, sir..."
        orushi "Student Emerick..."
        scene e2s470
        with dissolve
        emerick "Yes, sir..."
        scene e2s472
        with dissolve
        orushi "You will be the captain of Team B..."
        scene black
        with fade
        pause 1       
        orushi "Student Madison..."
        scene e2s473
        with dissolve
        mad "Yes, sir..."
        orushi "You will be the captain of Team H..."
        scene e2s474
        with dissolve
        mad "Alright..."
        orushi "Now that the captains are designated, please, one by one, in the order mentioned earlier, choose a teammate..."
        scene e2s475
        with fade
        s "Okay, so I choose Mac!"
        scene e2s476
        with dissolve
        emerick "I choose Elizabeth!"
        scene e2s477
        with dissolve
        emerick "Did you manage to do it?"
        beth "Yes, normally all the balls are placed in order... except the last ones..."
        scene e2s478
        with dissolve
        pause 1 
        scene e2s479
        with dissolve
        pause 1
        scene e2s480
        with flash
        with hpunch
        pause 1 
        scene e2s481
        with fade

        ji "I choose Marc!"
        ji "I choose Eden!"
        ji "I choose Luis!"
        ji "I choose Brandon!"
        ji "I choose Emilia!"


        pause 1

        if prem == True:
            scene e2s482
            with dissolve
            mad "I choose [name]!"
            scene e2s483
            with dissolve
            d "Wow! I didn't expect you to choose me!"
            mad "We did well in the first challenge... let's hope we succeed in the second one..."
            pause 1
            scene e2s484
            with dissolve
            s "Hector!"
            scene e2s485
            with dissolve
            emerick "Sofia!"
            scene e2s486
            with dissolve
            mad "Grace!"
            scene e2s487
            with dissolve
            s "Ben!"
            scene e2s488
            with dissolve
            mad "Ruby!"
            scene e2s489
            with dissolve
            mad "Julia!"
            scene e2s492
            with dissolve
            pause 1 
        else:
            scene e2s482
            with dissolve
            pause 1 
            mad "I choose Grace!"
            scene e2s486
            with dissolve
            pause 1 
            scene e2s484
            with dissolve
            s "Hector!"
            scene e2s485
            with dissolve
            emerick "Sofia!"
            scene e2s488
            with dissolve
            mad "Ruby!"
            scene e2s487
            with dissolve
            s "Ben!"
            scene e2s489
            with dissolve
            mad "Julia!"
            scene e2s490
            with dissolve
            ruby "Madison, take [name]!"
            scene e2s491
            with dissolve
            mad "Are you sure ?"
            ruby "Of course !"
            mad "Okay... I choose [name]!"
            scene e2s492
            with dissolve
            d "Thank you..."
            mad "You can greet Ruby..."

        orushi "Very well! Now that your teams are formed... we will have to proceed with a drawing..."
        orushi "You are 10 teams, but only 8 will be able to participate in this tournament..."
        scene e2s494
        with dissolve
        if persistent.patch_enabled:
            if persistent.rufus8 == False:
                $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
        orushi "Behind you, there are some cups with a ball below..."
        orushi "8 black balls and two white balls..."
        if persistent.rufus8 == False:
            scene e2s493 with dissolve
            show screen chat8() with dissolve
        else:
            scene e2s493
            with dissolve
        orushi "So, each of you will take a turn in order to choose a cup and show the ball you have drawn..."
        orushi "Anyone from your team can go and draw the ball..."
        orushi "If you draw a black ball, you qualify! If you draw a white ball, you won't participate in this tournament..."
        hide screen chat8
        scene e2s495
        with dissolve
        mad "Oh damn, I'm not good at this..."
        ruby "What do you mean?"
        mad "Well, let's just say luck isn't usually on my side..."
        ruby "Ah... well... Same here!"
        scene e2s496
        with dissolve
        if Bluepath == True:
            with hpunch
            d "Oh?"
            pause 1
            phone discussion "sofia1":
                time year 2023 month 9 day 3 hour 10 minute 30
                "sofia" "Take the last one !!!"
                "d" "What ?"
                "sofia" "Do as I say if you want to continue !!!"
                $ BlueHelp = True
            phone end discussion
        else:
            $ BlueHelp = False
        d "I can do it if you want..."
        mad "You?"
        d "Yes... At worst, if we don't get to play, you can blame it on me!"
        scene e2s4101
        with dissolve
        mad "Well... Okay..."
        scene e2s4102
        with dissolve
        ruby "Wait... I have an idea..."
        scene e2s4103
        with dissolve
        julia "What is it?"
        ruby "There will be only three of you left in the end if I understand the order correctly..."
        julia "Uh... Yeah... We're Team H, the 8th team..."
        ruby "Okay... Let's see how the results turn out..."
        emerick "I'll go first !"
        scene e2s4104
        with dissolve
        pause 1 
        scene e2s4105
        with dissolve
        pause 1 
        scene e2s4106
        with dissolve
        emerick "Black ball!"
        orushi "Qualified team!"
        scene e2s4107
        with dissolve
        s "Black ball!"
        orushi "Qualified team!"
        scene e2s4108
        with dissolve
        ji "Black!"
        orushi "Qualified team!"
        scene e2s4109
        with dissolve
        ji "Black!"
        orushi "Qualified team!"
        scene e2s4110
        with dissolve
        ji "Black!"
        orushi "Qualified team!"
        scene e2s4111
        with dissolve
        ji "Black!"
        orushi "Qualified team!"
        scene e2s4112
        with dissolve
        ji "Black!"
        orushi "Qualified team!"
        orushi "So, seven teams are now qualified..."
        scene e2s4113
        with dissolve
        orushi "There is only one black ball left among the last three bags..."
        orushi "Team H, please continue..."

        if BlueHelp == True:

            if persistent.patch_enabled == True:
                $ TEMP1 = e2s4m3c1
                $ TEMP2 = e2s4m3c2
            else:
                $ TEMP1 = ""
                $ TEMP2 = ""


            menu:
                "Trust Blue [TEMP1!t]":
                    scene e2s4114
                    with dissolve
                    dpense "I will trust Blue..."
                    scene e2s4115
                    with dissolve
                    d "I will take the last one..."
                    scene e2s4117
                    with dissolve
                    mad "Oh my god ! [name] what are you doing ?"
                    scene e2s4116
                    with dissolve
                    d "I don't know !"
                    scene e2s4118
                    with dissolve
                    mad "Is he serious ?"
                    jump bluesolve
                "Do not trust Blue [TEMP2!t]":
                    scene e2s4114
                    with dissolve
                    dpense "It could be a trap..."
                    jump rusolve

        label rusolve:
            $ BlueTrust = False
            scene e2s4119
            with dissolve
            ruby "Mr. Orushi?"
            orushi "Yes?"
            ruby "Could we let the next player take our place? We want to give the next player a chance to draw a ball on our behalf and then draw our own ball..."
            orushi "Hmmm... As Emerick went before Steven... I don't see any issue with that..."
            scene e2s4120
            with dissolve
            pause 0.5
            scene e2s4121
            with dissolve
            emerick "What is she doing?"
            d "Why are you asking him that?"
            scene e2s4119
            with dissolve
            ruby "Trust me!"
            scene e2s4113
            with dissolve
            ruby "Tell me... Which ball would you have drawn?"
            d "I don't know, I have a one in three chance of picking the right one!"
            ruby "That's the principle... 33 per cent..."

            menu:
                "Left":
                    $ lefttable = True
                    $ centertable = False
                    $ righttable = False
                    d "The left one..."
                "Center":
                    $ centertable = True
                    $ lefttable = False
                    $ righttable = False
                    d "The center one..."
                "Right":
                    $ righttable = True
                    $ centertable = False
                    $ lefttable = False
                    d "The right one..."

            if lefttable == True:
                scene e2s4122
                with dissolve
                ji "I will choose the center one !"
                d "Okay..."
                ruby "Wait..."
                pause 1
                scene e2s4124
                with dissolve
                ji "White..."
                orushi "Team Eliminated !"
                jump lefttable

            if centertable == True:
                scene e2s4123
                with dissolve
                ji "I will choose the left one !"
                d "Okay..."
                ruby "Wait..."
                pause 1
                scene e2s4124
                with dissolve
                ji "White..."
                orushi "Team Eliminated !"
                jump centerright

            if righttable == True:
                scene e2s4123
                with dissolve
                ji "I will choose the left one !"
                d "Okay..."
                ruby "Wait..."
                pause 1
                scene e2s4124
                with dissolve
                ji "White..."
                orushi "Team Eliminated !"
                jump centerright

            label centerright:
                scene e2s4125
                with dissolve
                mad "Oh my God... I would have done like everyone else and drawn our ball in order..."
                grace "Yes, I would have done the same..."
                julia "But why did you do that, Ruby?"
                ruby "A hunch..."
                d "But what do we do now? I have a fifty-fifty chance of losing!"
                scene e2s4126
                with dissolve
                ruby "No... that's where you're wrong!"
                d "Huh?"
                ruby "When you started, you had a one in three chance that the black ball was the one you chose, right?"
                d "Well, yes..."
                scene e2s4127
                with dissolve
                ruby "Well, now you have a two in three chance that it's on the one you didn't pick!"
                d "Huh?"
                scene e2s4128
                with dissolve
                ruby "Trust me and take the other ball..."
                scene e2s4115
                with dissolve
                d "What's this madness?"
                scene e2s4116
                with dissolve
                d "She's completely crazy..."
                scene e2s4129
                with dissolve
                stop music fadeout 1
                d "Alright... Let's go..."
                scene e2s4130
                with dissolve
                pause 1
                scene e2s4131
                with dissolve
                dpense "I don't want to see..."
                pause 1 
                scene e2s4132
                with dissolve
                pause 1
                play music "musique/MaxKoMusic-OdeToTheWinners.mp3"                
                pause 0.75 
                scene e2s4133
                with dissolve
                orushi "Black ball! Qualified team!"
                with hpunch
                scene e2s4134
                with dissolve
                d "Huh???"
                scene e2s4135
                with dissolve
                pause 1
                ruby "See, I told you!"
                scene e2s4118
                with dissolve
                mad "You're insane!"
                ruby "I had a feeling! Thanks for trusting me!"
                jump resulttable

            label lefttable:
                scene e2s4126
                with dissolve
                d "What do we do now? I have a fifty-fifty chance of losing!"
                ruby "No... that's where you're wrong!"
                d "Huh?"
                ruby "When you started, you had a one in three chance that the black ball was the one you chose, right?"
                d "Well, yes..."
                scene e2s4127
                with dissolve
                ruby "Well, now you have a two in three chance that it's on the one you didn't pick!"
                d "Huh?"
                scene e2s4128
                with dissolve
                ruby "Trust me and take the other ball..."
                scene e2s4115
                with dissolve
                d "What's this madness?"
                scene e2s4116
                with dissolve
                d "She's completely crazy..."
                scene e2s4129
                with dissolve
                stop music fadeout 1
                d "Alright... Let's go..."
                scene e2s4130
                with dissolve
                pause 1
                scene e2s4131
                with dissolve
                dpense "I don't want to see..."
                pause 1 
                scene e2s4132
                with dissolve
                pause 1
                play music "musique/MaxKoMusic-OdeToTheWinners.mp3"                
                pause 0.75  
                scene e2s4133
                with dissolve
                orushi "Black ball! Qualified team!"
                with hpunch
                scene e2s4134
                with dissolve
                d "Huh???"
                scene e2s4135
                with dissolve
                pause 1
                ruby "See, I told you!"
                scene e2s4118
                with dissolve
                mad "You're insane!"
                ruby "I had a feeling! Thanks for trusting me!"
                jump resulttable

        label bluesolve:
            d "What if she's wrong?"
            d "She's completely crazy..."
            scene e2s4129
            with dissolve
            stop music fadeout 1
            d "Alright... Let's go..."
            scene e2s4130
            with dissolve
            pause 1
            scene e2s4131
            with dissolve
            dpense "I don't want to see..."
            pause 1 
            scene e2s4132
            with dissolve
            pause 1 
            play music "musique/MaxKoMusic-OdeToTheWinners.mp3"                
            pause 0.5 
            scene e2s4133
            with dissolve
            pause 1
            orushi "Black ball! Qualified team!"
            with hpunch
            scene e2s4134
            with dissolve
            pause 1
            d "Huh???"
            pause 1
            scene e2s4135
            with dissolve
            pause 1
            scene e2s4118
            with dissolve
            mad "You're insane!"
            $ BlueTrust = True
            jump resulttable

        label resulttable:
            scene e2s4136
            with dissolve
            orushi "Now that all the tournament teams have been designated, we will begin the first matches..."
            orushi "Matches will be like this:"
            scene e2s4137
            with dissolve
            orushi "A versus C"
            orushi "B versus E"
            orushi "D versus H"
            orushi "F versus G"
            scene e2s4138
            with dissolve
            orushi "Please, go to the locker room to retrieve your uniforms and get ready for the matches..."
            if BlueTrust == True:
                phone discussion "sofia1":
                    time year 2023 month 9 day 3 hour 10 minute 40
                    "d" "Thank you!!!"
                    "sofia" "You owe me one..."
                    $ BlueRelation = True
                phone end discussion
            mad "Okay! Let's go, everyone!"
            scene black
            with fade
            pause 1

        jump foot


label rufusg8:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img8"):
        show img8
        hide img8
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus8 = True
    hide screen chat8
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
