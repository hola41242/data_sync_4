label e2s3:
show screen gameUIBEST
stop music fadeout 2
pause 1 
play music "musique/Vexento_Now.mp3" 
scene black
with fade
pause 2 
scene d1
with dissolve
pause 2 
scene d2
with dissolve
pause 2 
scene d3
with dissolve
pause 0.5
scene d4
with dissolve
pause 0.5 
scene d3
with dissolve
pause 0.5 
scene d4
with dissolve
pause 0.5 
scene d3
with dissolve
pause 0.5 
d "Who could this be ?"
scene d5
with dissolve
pause 1
call phone_discussion_ruby from _call_phone_discussion_ruby
pause 2

if Gracephone == True:
    d "Oh ? Another message !"
    call phone_discussion_grace from _call_phone_discussion_grace

d "Okay... Got to be fresh for tomorrow..."

if Bluephone == True:
    d "Again ?"
    call phone_discussion_sofia from _call_phone_discussion_sofia

d "Now... Rest !"

scene black
with fade
pause 2  

scene e2s31
with fade
if persistent.patch_enabled:
    if persistent.rufus7 == False:
        $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
julia "{i}Hey, I just met you...{/i}"
scene e2s34
with dissolve
julia "{i}And this is crazy...{/i}"
scene e2s35
with dissolve
julia "{i}But here's my number...{/i}"
scene e2s36
with dissolve
julia "{i}So call me, maybe?{/i}"
scene e2s37
with dissolve
ji "This is the first time I heard you singing like that!"
with hpunch
scene e2s38
with dissolve
julia "Huh? Um... yeah..."
scene e2s39
with dissolve
ji "There's a guy behind this, isn't there?"
scene e2s311
with dissolve
julia "What?... No, not at all... What are you imagining?"
scene e2s310
with dissolve
ji "Come on, stop it... I've never seen you so cheerful and lively!"
scene e2s312
with dissolve
ji "I can tell when a friend is excited about a guy!"
scene e2s313
with dissolve
julia "Well, it's nothing... It's just a guy I met..."
ji "So, what's he like?"
if persistent.rufus7 == False:
    scene e2s314 with dissolve
    show screen chat7() with dissolve
else:
    scene e2s314
    with dissolve
julia "Charlotte!!!"
cha "What's wrong??? He must be really good-looking to have caught your eye!"
julia "Well... not really... I don't know... I just like him, that's all..."
cha "Do you know what he thinks of you?"
hide screen chat7

if JuliaPath == True:
    scene e2s315
    with dissolve
    julia "I think he likes me... but I'm not really sure..."
    scene e2s317
    with dissolve
    cha "Awesome! Well, there you go... Miss is stepping into the big leagues!"
    scene e2s318
    with dissolve
    julia "What do you mean?"
    cha "Do you want me to spell it out for you???"
    cha "A guy... a girl... in love..."
    scene e2s314
    with dissolve
    julia "Oh, stop it... we're not there yet..."
    cha "I'd be really curious to meet him, you know..."
    cha "For you to be in this state, it must be worth it..."
    scene e2s317
    with dissolve
    julia "You'll probably meet him at some point..."
    scene e2s319
    with dissolve
    cha "Yeah... Well, you go take care of the guys' table over there; I'll go count the cash!"
    julia "Alright..."
else:
    scene e2s316
    with dissolve
    julia "I think he just sees me as a friend..."
    scene e2s314
    with dissolve
    cha "Oh damn... Well, that's not a good start..."
    julia "Well, it's not really a start, to be honest..."
    cha "Still, if he's as great as you say, I'd like to meet him!"
    cha "For you to be in this state, it must be worth it..."
    scene e2s317
    with dissolve
    julia "You'll probably meet him at some point..."
    scene e2s319
    with dissolve
    cha "Yeah... Well, you go take care of the guys' table over there; I'll go count the cash!"
    julia "Alright..."

scene e2s320
with dissolve
julia "Please, gentlemen, we're closing..."
scene e2s321
with dissolve
ji "The customer is always right, isn't that what they say?"
scene e2s322
with dissolve
julia "What do you mean?"
ji "If I decide we're staying here, then we're staying, right guys?"
scene e2s323
with dissolve
ji "Yeah!!!"
scene e2s324
with dissolve
julia "Listen, I'm just asking you to leave so I can go home..."
scene e2s325
with dissolve
ji "We don't give a damn about what you want!"
scene e2s326
with dissolve
ji "Maybe you could show us your little behind, and maybe we'll leave you alone... Right, guys?"
scene e2s323
with dissolve
ji "Yeah!!!"
scene e2s327
with dissolve
s "Guys, out... You heard the lady..."
ji "But, dude! She's the one flirting with us..."
scene e2s328
with dissolve
s "I said out!"
scene e2s329
with dissolve
ji "Alright, Captain! No need to yell at us!!!"
scene e2s330
with dissolve
ji "And you, you haven't heard the last of this..."
scene e2s331
with dissolve
s "I'm sorry, Julia... These guys are on edge..."
julia "Yes..."
scene e2s332
with dissolve
s "Don't hold it against them... And if they give you any more trouble, tell me..."
scene e2s333
with dissolve
julia "..."
scene e2s334
with dissolve
cha "What's he doing here?"
julia "He came to collect his gang... I suppose they're going to practice..."
cha "At this hour?"
julia "Yeah... they had poor results at the end of the season, so they want to make up for it..."
cha "Some of them might lose their scholarships!"
julia "That's possible..."
scene e2s335
with dissolve
cha "Those new outfits reveals so much..."
julia "Can't we use the older ones ?"
cha "You heard the Boss... We have to wear this to attract new customers..."
julia "Yeah... But..."
cha "Come on, let's go..."
julia "Okay..."
scene e2s336
with dissolve
cha "You'll keep me updated about that mysterious stranger, right?"
julia "Um... Yeah, don't worry..."
cha "And tomorrow, you'll be alone at the start of your shift! I'll be there around mid-evening."
cha "I have some accounting to finish before tomorrow night..."
julia "Alright... I'll be here..."
scene e2s337
with dissolve
cha "See you tomorrow!"
julia "See you."

stop music fadeout 2.0
scene black
with fade
pause 2 
scene e2s338
with dissolve
play music "musique/Meydan-Changes.mp3"
scene black
$ renpy.movie_cutscene("images/animation/juliarentre_2.webm", stop_music=False)
scene black with dissolve








scene e2s339
with dissolve
pause 2 
scene e2s340
with dissolve
pause 2 
scene e2s341
with dissolve
pause 2 
scene e2s342
with dissolve
pause 2 
scene e2s343
with dissolve
pause 2 
scene e2s344
with dissolve
julia "It must be cold by now... "
julia "And my coffee..."
scene e2s345
with dissolve
julia "Fucking high heels..."
scene e2s346
with dissolve
julia "Well, I'll have to juggle tomorrow... classes, the restaurant..."
scene e2s347
with dissolve
pause 2
if persistent.streaming == True:
    jump suitejuliatel
scene e2s348
with dissolve
label suitejuliatel:
    pause 2
scene e2s349
with dissolve
julia "He hasn't texted me..."
scene e2s350
with dissolve
julia "Should I text him?"

if JuliaPath == True:
    scene e2s352
    with dissolve
    julia "Damn, I don't even know what to do in this case..."
    scene e2s351
    with dissolve
    julia "I'm really clueless..."
    scene e2s352
    with dissolve
    julia "Well, let's give it a shot..."
    julia "Hi !"
    scene e2s353
    with dissolve
    julia "Hi... isn't there a dumber way to start..."
    scene e2s354
    with dissolve
    julia "Shit, he replied!"
    julia "What do I do? What do I do? What do I do?"
    d "Hey, hello!"
    scene e2s356
    with dissolve
    julia "Well... he's using clichés too..."
    scene e2s357
    with dissolve
    julia "What should I say to him?... 'How are you?' Nah, that's lame..."
    julia "Did you have a good day?"
    julia "Nah, that's not better... Sounds like his mom talking..."
    julia "Oh my goodness..."
    scene e2s358
    with dissolve
    julia "Ahhh! Another message!"
    d "I'm tired from my day... Thanks for the tour anyway!"
    julia "You're welcome."
    julia "I hope I didn't forget anything."
    d "Don't worry, you were perfect! And if I need info, I'll know who to ask!"
    julia "Yeah..."
    d "Alright, I'll let you sleep! You must be tired of spending all your time at the library..."
    scene e2s359
    with dissolve
    julia "You can't even imagine..."
    scene e2s358
    with dissolve
    d "Goodnight, Julia."
    julia "Goodnight, [name]."
    scene e2s360
    with dissolve
    pause 2
    scene e2s361
    with dissolve
    pause 1 
    scene e2s362
    $ renpy.movie_cutscene("images/animation/juliadort.webm", stop_music=False)
    scene black
    with dissolve

    pause 2 
    stop music fadeout 2
else:




    scene e2s351
    with dissolve
    julia "No, he doesn't care..."
    scene black
    $ renpy.movie_cutscene("images/animation/juliadort2.webm", stop_music=False)
    scene black
    pause 2
    stop music fadeout 2


jump e2s4

label rufusg7:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img7"):
        show img7
        hide img7
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus7 = True
    hide screen chat7
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
