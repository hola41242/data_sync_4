label e2s1:
    scene black
    if rubytrial == True:
        $ chosen = "Ruby"
    if juliatrial == True:
        $ chosen = "Julia"
    if gracetrial == True:
        $ chosen = "Grace"
    if madtrial == True:
        $ chosen = "Madison"
    pause 2
    with fade
    stop music fadeout 2.0
    with fade
    play music "musique/Pachyderm-NeverKnewMeatAll.mp3"
    show text _ ("EPISODE 2 {p} \n Double Trouble") at truecenter
    pause 2
    with dissolve
    pause 2
    hide text
    show text "{i}On ne peut pas tromper mille fois mille personnes{/i} : \n Emile \n" at truecenter
    with dissolve
    pause 3
    hide text
    show text "{i}You have to be aware ! {/i} : \n Jean Claude Van Damme \n" at truecenter
    with dissolve
    pause 3
    hide text
    pause 4
    scene a1
    with dissolve
    pause 2
    scene a2
    with dissolve
    pause 2    


    dpense "Whaaaaa... What a day!"
    scene a3
    with dissolve
    dpense "It's incredible... This competition that came out of nowhere, all these girls, it was my first day and I didn't even have any classes..."
    pause 1 
    scene a4
    with vpunch
    with dissolve
    pause 1
    scene a5
    pause 1
    scene a6
    with dissolve
    pause 1
    dpense "But it really wore me out... I still need to tidy up all this mess!"

    scene a7
    with dissolve
    dpense "My phone! Well, I don't have any contacts here... I'll have to ask the girls for their numbers..."
    dpense "Okay... let's go !"
    pause 1
    scene a8
    with dissolve
    d "{i} Here we are. Born to be kings. {/i}"
    scene a10
    with dissolve
    pause 0.2
    scene a11
    with dissolve
    pause 0.2
    scene a10
    with dissolve
    pause 0.2
    scene a11
    with dissolve
    pause 0.2
    scene a10
    with dissolve
    scene a9
    with dissolve
    d "{i} We're the princes of the universe. {/i}"
    scene a12
    with dissolve
    d "{i} I am immortal. I have inside me blood of kings. {/i}"
    scene a13
    with dissolve
    d "{i} I have no rival. No man can be my equal. {/i}"
    scene a14
    with dissolve
    pause 1
    scene a15
    with dissolve
    pause 1
    scene a16
    with dissolve
    pause 1 
    scene a17
    with dissolve
    pause 1
    scene a18
    with dissolve
    d "{i} Take me to the future of your world. {/i}"
    scene a19
    with dissolve
    pause 1 
    scene a20
    with dissolve
    pause 1 
    scene a21
    with dissolve
    pause 1 
    scene a22
    with dissolve
    pause 1 
    with hpunch
    scene a23
    with dissolve
    pause 1
    ruby "What a show ! So now I have to call you Highlander ?"
    scene a24
    with dissolve
    d "Na..."
    scene a25
    with dissolve
    ruby "We'll see! Come on, grab your stuff, others are waiting for us..."
    d "Yes..."
    scene a28
    with dissolve
    ruby "Oh? Do you have a phone?"
    d "Uh, yeah... Well, I don't have any contacts in it since I don't know anyone here, but yeah... I have a phone..."
    scene a26
    with dissolve
    ruby "Cool!!! Wait, let me send you my contact through scanning!"
    scene a29
    with dissolve
    d "Uh... Okay."
    $ renpy.notify (_("NEW CONTACT ADDED"))
    $ Rubyphone = True

    scene a27
    with dissolve
    ruby "Well... We'll test it later to see if it works!"
    scene a30
    with dissolve
    ruby "Come on, let's go join the others!"
    d "I'm coming..."
    scene black
    with dissolve
    stop music fadeout 2.0
    with fade
    pause 2       
    play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
    pause 3
    scene a31
    with fade
    pause 2 
    scene a32
    with dissolve
    pause 2 
    scene a37
    with dissolve
    pause 2 
    scene a39
    with dissolve
    pause 2 
    scene a40
    with dissolve
    pause 2 
    scene a41
    with dissolve
    pause 2 
    scene a43
    with dissolve
    emerick "You asked to see me, Uncle?"
    scene a42
    with dissolve
    orushi "Yes... I saw the results of the first test..."
    scene a33
    with dissolve
    orushi "You did well..."
    scene a44
    with dissolve
    emerick "Obviously! I wasn't going to lose to that bunch of losers!"
    scene a35
    with dissolve
    pause 0.2
    scene a36
    with dissolve
    with vpunch
    orushi "Enough!"
    scene a38
    with dissolve
    rufus "FSHHHHHHHHHHHHHHHH"
    scene a34
    with dissolve
    orushi "I know one of your vipers sneaked off to prepare your bag so you just have to grab it without looking for it!"
    orushi "You're lucky the tigress was busy looking for hers!"
    orushi "Next time, I won't let that slide!"
    scene a45
    with dissolve
    emerick "Yes, Uncle..."
    orushi "And that French guy? He wasn't bad at all..."
    scene a46
    with dissolve
    emerick "He's just a weakling compared to me..."
    orushi "Weakling or not, you should be wary of him..."
    scene a47
    with dissolve
    emerick "I'll take care of him..."
    orushi "You better win the upcoming tournament..."
    emerick "It's as good as done..."
    scene a33
    with dissolve
    pause 1
    scene a31
    with dissolve
    pause 1 
    stop music fadeout 2.0
    scene black
    with fade
    pause 2       
    play music "musique/Keys_of_Moon_-_The_Success.mp3" 
    pause 1


    scene a48
    with dissolve
    pause 2
    scene a49
    with dissolve
    pause 2
    scene a50
    with dissolve
    pause 2
    scene a51
    with dissolve
    pause 2
    scene a52
    with dissolve
    pause 2
    scene a53
    with dissolve
    pause 2
    scene a54
    with dissolve
    pause 2
    scene a55
    with dissolve
    pause 2
    scene a56
    with dissolve
    pause 2
    scene a57
    with dissolve
    ruby "Well, we're just missing Madison... she'll be here soon..."
    scene a58
    with dissolve
    julia "It's okay if she doesn't come, you know..."
    scene a59
    with dissolve
    grace "Julia! Come on, cut her some slack! She's busy taking care of her daughter! You know it's hard for her to manage everything!"
    grace "And on top of that, her brother is doing who knows what..."
    grace "And her parents are always demanding things from her... I have the same problem with my mom..."
    scene a60
    with dissolve
    grace "Always telling me, 'Grace, don't do that! Grace, you're the captain, you have to set an example!'"
    grace "'Grace, you have to get the best grades!' Grace, Grace, Grace..."
    scene a61
    with dissolve
    julia "It must be tough for you to deal with..."
    grace "Nah!!! As long as I have the team, you girls, and something to help me escape a little, it's all good!"
    scene a62
    with dissolve
    grace "By the way, I bought some good wine from France... You'll love it!!!"
    scene a63
    with dissolve
    ruby "What are you thinking? We're on campus!!!"
    scene a64
    with dissolve
    grace "Oh, come on, Ruby, don't be such a buzzkill!"
    scene a65
    with dissolve
    ruby "Seriously, Grace, if you want to drink, go ahead... But not here..."
    scene a66
    with dissolve
    grace "What do you think, [name]?"

    scene a67
    with dissolve

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s1m1c1
        $ TEMP2 = e2s1m1c2
        $ TEMP3 = e2s1m1c3
        $ TEMP4 = e2s1m1c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "Buddy [TEMP1!t]":
            call buddy_increased from _call_buddy_increased_8
            scene a68
            with dissolve
            d "You shouldn't drink here... It could cause problems."
            grace "Okay, I'll put it away..."
        "Education [TEMP2!t]":
            call education_increased from _call_education_increased_5
            scene a68
            with dissolve
            d "I'm not really a fan of women who drink, to be honest..."
            grace "Yeah, I guess it's not very sexy... Okay, let's see each other tonight lovely bottle..."
        "Sport [TEMP3!t]":
            call sport_increased from _call_sport_increased_6
            scene a68
            with dissolve
            d "It's not good for your physical performance, you know that?"
            grace "Haha, you sound like my coach! Okay, bye-bye wine from vineyards... Hello protein drink!"
        "Temperament [TEMP4!t]":
            call temperament_increased from _call_temperament_increased_8
            scene a69
            with dissolve
            d "I'm not going to tell you what to do... But sometimes it feels good to relieve some pressure!"
            scene a71
            with dissolve
            grace "Now there's someone who understands how this world works! But Ruby is right... I shouldn't keep this bottle here..."
            scene a70
            with dissolve
            scene a71
            with dissolve


    scene black
    with fade
    pause 1
    scene a72
    with dissolve
    pause 2
    scene a76
    with dissolve
    pause 0.5
    scene a77
    with dissolve
    pause 0.5
    scene a78
    with dissolve
    d "Who is... ?"
    scene a73
    with dissolve
    pause 2 
    scene a74
    with dissolve
    pause 2 
    scene a75
    with dissolve
    pause 2 
    scene black
    with fade
    scene r118
    $ renpy.movie_cutscene("images/animation/madi.webm", stop_music=False)
    scene r118
    pause 2
    dpense "Um... It's not the same woman without her ponytail... Whaaa !"
    scene madi:
        xalign 0
        linear 5.0 yalign 0.9
        linear 2.0 yalign 0.01
        repeat 1
    mad "Why are you guys looking at me like that? Do I have something on my outfit?"
    scene a79
    with dissolve
    pause 0.5
    scene a80
    with dissolve
    pause 0.5 
    scene a81
    with dissolve
    pause 0.5
    scene tousspec025
    with dissolve
    pause 2
    scene a83
    with dissolve
    grace "No!!! You look stunning Maddie... I don't understand how you're still single..."
    scene a84
    with dissolve
    mad "Speak for yourselves girls! I have a child to take care of, a family to avoid, and competitions to win..."
    scene a85
    with dissolve
    mad "No room for anyone else... And besides, at this age guys don't want to deal with all these problems... Right [name]?"

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s1m2c1
        $ TEMP2 = e2s1m2c2
        $ TEMP3 = e2s1m2c3
        $ TEMP4 = e2s1m2c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "Buddy [TEMP1!t]":
            call buddy_increased from _call_buddy_increased_9
            scene a87
            with dissolve
            d "If you need help, we can also assist you in managing all this... You're not alone!"
            scene a89
            with dissolve
            mad "That's kind of you..."
            scene a90
            with dissolve
            ruby "Obviously he's kind! What did you think?"
            scene a91
            with dissolve
            mad "I don't know..."
        "Education [TEMP2!t]":
            call education_increased from _call_education_increased_6
            scene a86
            with dissolve
            d "If you want advice on anything, I'm available..."
            scene a92
            with dissolve
            mad "Because you know about child education?"
            mad "Or crisis management in the forties for parents hungry for power and wealth?"
            scene a90
            with dissolve
            ruby "Hey! He didn't attack you!!!"
            scene a89
            with dissolve
            mad "Yes, I know... Forgive me [name]..."
        "Sport [TEMP3!t]":
            call sport_increased from _call_sport_increased_7
            scene a86
            with dissolve
            d "We need to focus on the competition, the rest should not impact us."
            scene a89
            with dissolve
            mad "You're right... The B.E.S.T... The team... That's what's important..."
            scene a90
            with dissolve
            ruby "And if worse comes to worst, you have us if you need us! You know I'm here for you!"
            scene a91
            with dissolve
            mad "Little... I know you're there for me when I need you..."
        "Temperament [TEMP4!t]":
            call temperament_increased from _call_temperament_increased_9
            scene a88
            with dissolve
            d "I wouldn't have any trouble dealing with all these inconveniences..."
            d "After all, if you want to be with someone, you take everything that makes that person who they are!"
            scene a92
            with dissolve
            mad "Hmm... You sound sure of yourself... I wonder how you would deal with all of this..."
            scene a86
            with dissolve
            d "You can't know until you try."
            scene a89
            with dissolve
            mad "That's true..."

    scene black
    with fade
    pause 1
    scene a93
    with dissolve
    ruby "It's crazy all that's happening to us!"
    scene a94
    with dissolve
    julia "What do you mean?"
    scene a95
    with dissolve
    ruby "Well, I don't know about you guys, but I feel like we're experiencing something special..."
    ruby "Like we're part of something big... With stories, confrontations... Tests..."
    scene a96
    with dissolve
    ruby "Even our meeting with [name] is special! We meet him on a plane and he ends up being my roommate, he sleeps at Grace's the first night..."
    ruby "He does the first B.E.S.T test with [chosen] and he's almost close to winning in the end! It's like he's a hero in a visual novel!"
    play sound "sound/suspense.mp3"
    scene a94
    with dissolve
    julia "What's that?"
    scene a96
    with dissolve
    ruby "A Visual Novel hero!"
    play sound "sound/suspense.mp3"     
    scene a97
    with dissolve
    grace "Huh?"
    scene a98
    with dissolve
    ruby "A VI-SU-AL-NO-VEL hero!"
    play sound "sound/suspense.mp3"   
    scene a99
    with dissolve
    mad "A ?"
    scene a100
    with dissolve
    ruby "Visual Novel! A choose-your-own-adventure novel!"
    play sound "sound/suspense.mp3"
    scene a101
    with dissolve
    d "Ah! A Vizoual Nouvel!"
    play sound "sound/suspense.mp3"    
    scene a102
    with dissolve
    ruby "..."
    ruby "Yeah, maybe an Adult VN actually..."
    scene a101
    with dissolve
    d "What exactly is an Adult VN?"
    scene a103
    with dissolve
    ruby "Oh my god, you really don't know anything?"
    scene a104
    with dissolve
    mad "Well, go on and explain!"
    scene a105
    with dissolve
    stop music fadeout 1.0
    ruby "Okay!!!"

    cr "Ruby will explain what is a Visual Novel to the girls."
    cr "Please not that you can miss some content later if you don't follow this conversation."
    cr "Do you want to see her explanation?"
    menu:
        "Yes":
            $ rubyvn = True
        "No":
            $ rubyvn = False
            $ helpgabi = True

    if rubyvn == False:
        jump finrubyvn


    play music "musique/Amaria_LovelySwindler.mp3" volume 0.2
    scene a106
    with dissolve
    ruby "A visual novel is a game where you make choices that influence the story..."
    scene a107
    with dissolve
    ruby "Like whether to go left..."
    scene a108
    with dissolve
    ruby "Or right... And each choice creates a branch that can take the story in one direction..."
    scene a109
    with dissolve
    ruby "Or another!"
    scene a110
    with dissolve
    ruby "Not to be confused with a Kinetic Novel which is a straight line in terms of events. Basically, with a Kinetic Novel, you follow an adventure..."
    scene a111
    with dissolve
    ruby "With a visual novel, you are a full-fledged actor since you decide what you want to do with each choice offered!"
    ruby "And in adult visual novels, some things are more..."
    scene a112
    with dissolve
    ruby "Sexy..."
    ruby "And topics that are a bit more difficult that are addressed like alcoholism... Addiction... Questions about sexuality..."
    ruby "Sometimes even more twisted subjects... But we won't go further into these details!!!"
    scene a113
    with dissolve
    ruby "There are 7 rules to follow in an adult visual novel!"
    scene a114
    with dissolve
    d "What do you mean by 7 rules?"
    scene a115
    with dissolve
    ruby "Well, actually, there are more, but I like the number 7, so... ANYWAY! I'm the one explaining, so I decided!"
    scene a116
    with dissolve
    ruby "Rule #1: The hero must be charismatic! He must have character! He should not become a doormat in front of everyone he meets and say yes to everything..."
    ruby "That fits [name] well, don't you think?"
    scene a121
    with dissolve
    play sound "sound/Scratch.mp3" volume 0.5
    mad "Why does he have to be the hero? Why can't it be a girl?" with hpunch
    scene a123
    with dissolve
    julia "Yeah, why is the hero always a boy?"
    scene a124
    with dissolve
    ruby "That's not always the case! I know plenty of games where the hero is actually a heroine..."
    ruby "but since we're in the adult sector, the majority of players are... men..."
    scene a121
    with dissolve
    mad "That doesn't explain why [name] is the hero of your story..."
    ruby "Maddie..."
    mad "Okay, fine... Continue!"
    scene a117
    with dissolve
    ruby "Rule #2: The hero must have Lis that he will cling to, like the player who will grow attached to them."
    play sound "sound/suspense.mp3" 
    scene a123
    with dissolve
    julia "Lis?"
    scene a124
    with dissolve
    ruby "Li... Love interests!!!! Basically conquests!"
    scene a122
    with dissolve
    grace "And how do they know they're Lis?"
    scene a124
    with dissolve
    ruby "They don't! They meet the hero naturally! Like how we met [name] on the plane!"
    scene a122
    with dissolve
    grace "So every girl the hero meets becomes a Li?"
    scene a110
    with dissolve
    ruby "No! And I didn't say they had to be girls! There are games where the hero is gay or otherwise..."
    ruby "But here, for example, [name] has met quite a few girls since he's been here!"
    ruby "Maybe he already has a connection with some of them! And then some of the hero's acquaintances can become 'casual' or 'side chicks'..."
    if Redpath == True:
        ruby "Like one of the twins in the locker room..."
        scene a123
        with dissolve
        julia "Huuu ?"
    if Bluepath == True:
        scene a92
        with dissolve
        mad "Yeah...Like one of the twins under the shower..."
        scene a123
        with dissolve
        julia "Huuu ?"
    scene a125
    with dissolve
    grace "[name], if you had eyes for someone after just one day here, who would it be?"
    scene a77
    with dissolve
    d "Hummm..."
    scene black
    hide screen gameUIBEST
    call screen choixfille2()

    label rubychoix2:
        $ chosen = "Ruby"
        jump chosenkiss

    label gracechoix2:
        $ chosen = "Grace"
        jump chosenkiss

    label madisonchoix2:
        $ chosen = "Madison"
        jump chosenkiss

    label juliachoix2:
        $ chosen = "Julia"
        jump chosenkiss

label chosenkiss:
    show screen gameUIBEST()
    scene a77
    with fade
    chosen "Oh, that's cute !!!"
    if chosen == "Ruby":
        scene rubykiss
        with dissolve
    if chosen == "Grace":
        scene gracekissparc
        with dissolve
    if chosen == "Madison":
        if Bluepath == True:
            mad "But I'm not Blue so.. Go back to your viper !"
        else:
            scene madisonkiss
            with dissolve
    if chosen == "Julia":
        scene juliakiss
        with dissolve

    pause 2

    scene a118
    with dissolve
    ruby "Well, that's all good, but let's move on to rule number 3!"
    ruby "Love interests can have a past, but it's even better if they're virgins!"
    scene a126
    with dissolve
    play sound "sound/Scratch.mp3" volume 0.5
    mad "What???"
    scene a127
    with dissolve
    ruby "Yes... Obviously, you can't say you are... You have a daughter, so..."
    scene a126
    with dissolve
    mad "So I can't be a love interest?"
    scene a128
    with dissolve
    ruby "Did you want to be one?"
    scene a129
    with dissolve
    mad "No, but have you seen me? If I were in that kind of game, I sure hope so! I wouldn't be just a 'side chick'!"
    scene a130
    with dissolve
    grace "Hahaha!"
    scene a128
    with dissolve
    ruby "No, but it's not that you can't be a love interest if you're not a virgin! It's just that players prefer girls who are 'pures' to girls who have been around..."
    scene a131
    with dissolve
    mad "That's ridiculous... I don't like your game..."
    scene a132
    with dissolve
    ruby "For example, here we're not doing too badly! [name] would have four girls, and three of them are virgins!"
    scene a94
    with dissolve
    julia "Okay, we don't need to be reminded of that, Ruby..."
    scene a83
    with dissolve
    grace "Yeah... Sometimes I wonder if I should 'open up' a bit more..."
    scene a119
    with dissolve
    ruby "It's not a big deal, girls! It's even better for the players... And at least we won't be blamed for the 4th rule!!!"
    scene a129
    with dissolve
    mad "And what's the fourth rule? Not allowed to have children?"
    scene a100
    with dissolve
    ruby "No!!!"
    scene a107
    with dissolve
    ruby "The fourth rule is : No TMI!!!"
    play sound "sound/suspense.mp3" 
    scene a114
    with dissolve
    d "What?"
    scene a98
    with dissolve
    ruby "TMI! Too Much Information!!! Too much past kills the present!"
    scene a122
    with dissolve
    grace "I don't really understand..."
    scene a110
    with dissolve
    ruby "Basically, the player who plays this game... doesn't want to know how many guys you've kissed..."
    scene a112
    with dissolve
    ruby "Or more... before meeting him... It doesn't interest him! It's like saying : Oh wow, yours is bigger than Edward's."
    scene a115
    with dissolve
    ruby "That's not interesting! Or hearing... I've had 100 guys, but you're the best I've had..."
    scene a108
    with dissolve
    ruby "Apart from looking like a slut, it doesn't add anything for the player except a certain feeling towards the girl!"
    scene a109
    with dissolve
    ruby "Sometimes it goes so far as to quit the game because the player absolutely doesn't want to hear about it! So, No TMI, No Problem!"
    scene a104
    with dissolve
    mad "But do I have the right to have had a life anyway?"
    scene a128
    with dissolve
    ruby "Of course! But your romance with the hero should not come into conflict with a previous romance that may have existed!"
    ruby "After all, in real life, no one wants to be compared to someone else during their relationship or a sexual act... Even less so in a game..."
    scene a133
    with dissolve
    julia "Well, it's easier when you're a virgin!"
    scene a127
    with dissolve
    ruby "Yes, but you shouldn't say something like, 'Oh, I've kissed other guys before, but it's different with you"
    scene a133
    with dissolve
    julia "Meh... Well, I haven't done that either!!"
    scene a120
    with dissolve
    ruby "Anyway, 5th rule!!!"
    scene a134
    with dissolve
    d "It sounds like we're giving birth to a Gremlin... Can't feed after midnight... Can't put in water... Can't expose to sunlight..."
    scene a95
    with dissolve
    ruby "Oh!!! You know Gremlins??? It's a movie by Steven Spielberg!!! And did you know that..."
    scene a101
    with dissolve
    d "Ruby!!!" with hpunch
    scene a103
    with dissolve
    ruby "Oh sorry... Alright, the 5th rule: You gotta have a Milf!"
    scene a130
    with dissolve
    grace "Ahahahaahahah! Maddie, that one's for you!"
    scene a135
    with dissolve
    play sound "sound/Scratch.mp3" volume 0.5
    mad "I'm not a Milf!" with hpunch
    scene a133
    with dissolve
    julia "Technically... You could be one!"
    scene a135
    with dissolve
    mad "But stop it, I'm 22, I'm not a Milf... Gabriella could be one if you want!"
    scene a97
    with dissolve
    grace "The teacher?"
    scene a92
    with dissolve
    mad "Yeah!"
    scene a114
    with dissolve
    d "I don't know her!"
    scene a124
    with dissolve
    ruby "Oh don't worry, you'll see her tomorrow!!!"
    scene a129
    with dissolve
    mad "So what should your Milf be like?"
    scene a102
    with dissolve
    ruby "It's better if she's neglected by her husband...If she hasn't been touched in a while..."
    ruby "if she's a bit of a lost soul that the hero will rescue..."
    scene a66
    with dissolve
    grace "And [name] is going to rescue Gabriella? I mean, she could fit in that category, but I don't see [name] with a 35-year-old woman!"

    scene a67
    with dissolve

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s1m3c1
        $ TEMP2 = e2s1m3c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "I'm not a fan of older women.":
            grace "I told you so!"
            $ helpgabi = False
        "Age has nothing to do with feelings. [TEMP1!t]":
            julia "That's nicely said...It's romantic!"
            $ helpgabi = True
        "Milfs are life! [TEMP2!t]":
            mad "Don't look at me when you say that!!!!"
            $ helpgabi = True
    scene a108
    with dissolve
    ruby "Anyway, we need a Milf...because it creates other dynamics with the player, often with taboos or other things that titillate their imagination..."
    scene a104
    with dissolve
    mad "Meh...at the same time, guys' imagination is mostly located at their waist level...and not much more..."
    scene a107
    with dissolve
    ruby "This brings us to the penultimate rule: not all fetishes are for everyone!"
    scene a97
    with dissolve
    grace "Fetishes?"
    scene a103
    with dissolve
    ruby "Yeah..."
    scene a94
    with dissolve
    julia "What is it?"
    scene a109
    with dissolve
    ruby "Uh... for example, some players are foot fetishists... they love scenes featuring feet or stockings or some other body part..."
    ruby "Others like BDSM... Others can't stand lesbian scenes... And don't even get me started on NTR..."
    play sound "sound/suspense.mp3" 
    scene a114
    with dissolve
    d "NTR?"
    scene a110
    with dissolve
    ruby "Yeah, NTR... It comes from 'netorare'... Basically the principle of cheating, or being cheated on in the game..."
    ruby "Some people like it... Others hate it... And it creates conflicts between two teams who argue about what's best according to them..."
    scene a111
    with dissolve
    ruby "So to avoid all that: Anything related to fetishism or an opinion that is a bit more personal or specific to the player's personality must be OPTIONAL!"
    scene a97
    with dissolve
    grace "I don't really see how you do that..."
    scene a96
    with dissolve
    ruby "Uh... Okay, an example: Grace, stand up!"
    scene a122
    with dissolve
    grace "Okay!"
    scene a136
    with dissolve
    ruby "Now kiss me!"
    scene a137
    with dissolve
    grace "Huh???"
    with hpunch
    ruby "Come on, kiss me! Just a little kiss!"
    scene a138
    with dissolve
    grace "Well, if you want, but I don't see how it sets an example!"
    scene a141
    with dissolve
    ruby "Stop!"
    with hpunch
    ruby "[name], would you like to see us kiss?"
    scene a88
    with dissolve

    if persistent.patch_enabled == True:
        $ TEMP1 = e2s1m4c1
        $ TEMP2 = e2s1m4c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Yes, definitely! [TEMP1!t]":
            $ lesb_cont = True
            scene a104
            with dissolve
            mad "Of course he said yes... Two girls kissing and he's hard in seconds!"

            scene a140
            with dissolve
            pause 1
            scene a139
            with dissolve
            pause 1
            scene a142
            with dissolve
            pause 2 
            scene a143
            with dissolve
            pause 1
            ruby "That wasn't bad..."
            scene a144
            with dissolve
            grace "Yeah..."
            scene a145
            with dissolve
            ruby "See, we gave him a choice! That's the principle. If he didn't want to see us kiss, he could have said no and it would be done."
        "No, I don't like it. [TEMP2!t]":
            $ lesb_cont = False
            scene a145
            with dissolve
            ruby "See, we gave him a choice! That's the principle. If he wanted to see us kiss, he could have said yes and we would have done it."

    ruby "But at least we respect what he likes and wants to see when he plays!"
    grace "I understand better now!"
    scene a107
    with dissolve
    ruby "And finally, the last rule: the most important of all!"
    scene a146
    with dissolve
    mad "I bet it's going to be ALL SEX, everywhere, all the time, with anyone!"
    scene a147
    with dissolve
    grace "No, I say the characters should have huge boobs, an ultra-round butt, and plump lips..."
    scene a148
    with dissolve
    julia "Or there should be dramas! Things that scare, things that make you cry..."
    scene a149
    with dissolve
    play sound "sound/Wrong.mp3" volume 0.5
    ruby "POOOOOOOOOOOOTTTTTTTTT….You are the weakest link… goodbye!"
    scene a134
    with dissolve
    d "Huh?"
    scene a110
    with dissolve
    ruby "Sex should be integrated and support the story, not the other way around!"
    d "What do you mean?"
    ruby "Basically, the story should come first. Sex should only be one aspect of the game and should not become the main element."
    ruby "Otherwise, everything else becomes meaningless."
    scene a115
    with dissolve
    ruby "In that case, you might as well make a game where the hero is an amnesiac who enters the house of his aunt/neighbor/landlord (pick one), and sees 2-3-4 girls inside..."
    ruby "And has a harem without ever leaving the house, with sex scenes every 5 seconds and no story behind it..."
    ruby "Sure, it might be cool for the fast-food player, but for a player involved in the story, it's repulsive."
    scene a108
    with dissolve
    ruby "The hero becomes a machine with no feelings, and the girls become meat..."
    play sound "sound/Bell.mp3"
    ruby "In short, we can summarize this rule as: the players don't want realism... they want magic!"
    scene a148
    with dissolve
    julia "Oh..."
    d "Well..."
    scene a105
    with dissolve
    ruby "But all of this was just a hypothetical scenario of what it would be like if we were in an adult visual novel!"
    scene a92
    with dissolve
    mad "Yeah, cause [name] as the hero and me as the Milf..."
    scene a130
    with dissolve
    grace "She can't get over this Milf thing!!!"
    scene a150
    with dissolve

label finrubyvn:

    julia "Well, girls, as much as I'd love to stay and chat, I still need to go to the library to get my textbooks..."
    scene a151
    with dissolve
    grace "And I have to go to the pool..."
    scene a152
    with dissolve
    d "Julia..."
    julia "Yes?"
    d "You said you would give me a tour of the campus this afternoon... Do you still have time?"
    scene a153
    with dissolve
    julia "Oh, come with me! I'll show you around on the way to the library, so you can see the different parts of the University!"
    d "Thank you very much..."
    scene a154
    with dissolve
    julia "See you later, girls!"
    grace "See you later! Have fun, and [name], don't take advantage of her too much!"
    scene a155
    with dissolve
    grace "Just because you're the hero and she's a virgin, doesn't mean you should jump on her!"
    julia "Grace..."
    scene a156
    with dissolve
    grace "I'm outta here!!!"
    play sound "sound/Whoosh.mp3" volume 0.50
    scene a157
    with dissolve
    julia "Hum... Do you have a phone ?"
    d "Yes, I just got it from my bag..."
    julia "Let me add you !"
    $ renpy.notify (_("NEW CONTACT ADDED"))
    $ Juliaphone = True
    julia "Okay... Let's go..."
    scene black
    with fade
    stop music fadeout 2
    pause 2

    jump e2s2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
