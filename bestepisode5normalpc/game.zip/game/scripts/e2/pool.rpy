label pool:
    show screen gameUIBEST
    stop music fadeout 2.0
    play music "musique/Meydan-Changes.mp3" 
    scene pool1
    with fade
    dpense "Let's see what we have here."
    scene pool2
    with dissolve
    ji "Hey boy... You're not allowed to enter here in your street clothes !"
    with hpunch
    scene pool3
    with dissolve
    dpense "Who..."
    pause 1
    $ renpy.movie_cutscene("images/animation/erin.webm", stop_music=False)
    dpense "Whaaa... Okay..."
    scene pool4
    with dissolve
    ji "You can buy swim trunks at the entrance..."
    d "Oh... Hum... Yeah... Thank you !"
    scene pool6
    with dissolve
    ji "You're welcome... Have fun !"
    d "Yeah... Yeah..."
    scene pool7
    with dissolve
    dpense "That woman was a rocket ! No... a space rocket !..."
    scene pool5:
        xalign 0.0
        linear 5.0 yalign 0.9
        linear 3.0 yalign 0.0
        repeat 1
    dpense "What am I saying ? An atomic bomb!"
    $ MeetErin = True
    scene pool7
    dpense "Better go buy some swim trunks..."
    scene black
    with fade

    show text _ ("5 MINUTES LATER") at truecenter
    with fade
    pause 2 
    hide text
    with fade
    pause 1
    scene pool8
    with fade
    dpense "Now we're ready !"


    if Bluepath == True:
        scene pool9
        with dissolve
        pause 2
        scene pool10
        with dissolve
        sofia "Come with me... You wanted to see me evolve... I'm already all wet..."

        if persistent.patch_enabled == True:
            $ TEMP1 = e2poolm1c1
            $ TEMP2 = e2poolm1c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""

        menu:
            "Follow her. [TEMP1!t]":
                scene pool11
                with dissolve
                d "Where do you want to go ?"
                sofia "I know a place where we can hide..."
                d "Okay... Let's go !"
                pause 1 
                scene black
                with fade
                $ renpy.movie_cutscene("images/animation/gracepool.webm", stop_music=False)
                $ GraceBlue = True

                jump sofiapool
            "Reject her. [TEMP2!t]":
                scene pool12
                with dissolve
                d "No, thanks! I have a beautiful mermaid waiting for me!"
                scene pool11
                with dissolve
                sofia "You don't know what you are missing..."
                $ Bluepath = False
                pause 1 
                scene black
                with fade
                $ renpy.movie_cutscene("images/animation/gracepool.webm", stop_music=False)
                $ GraceBlue = False
                $ BlueRelation = False
                jump pool2
    else:


        scene pool12
        with dissolve
        sofia "What are you doing here, Frenchie? Don't you have something better to do than being a voyeur at the pool?"
        d "Don't worry! I'm not here for you... I don't see what I'd do with you anyway..."
        pause 1 
        scene black
        with fade
        $ renpy.movie_cutscene("images/animation/gracepool.webm", stop_music=False)
        $ GraceBlue = False
        $ BlueRelation = False

label pool2:
    scene pool13
    with dissolve
    d "So, this is where you train?"
    scene pool14
    with dissolve
    grace "Oh ? Uh... yes..."
    d "Julia showed me around a bit, and I thought coming to relax at the pool would be the best way to unwind after these crazy two days..."
    scene pool13
    with dissolve
    grace "I know nothing better than the feeling of water on my body to recharge myself..."

    if persistent.patch_enabled == True:
        $ TEMP1 = e2poolm2c1
        $ TEMP2 = e2poolm2c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Sport [TEMP1!t]":
            call sport_increased from _call_sport_increased_9
            d "Do you train here every evening?"
            scene pool15
            with dissolve
            grace "Yes, it helps me stay in shape and in good condition for the matches."
            d "Do you have a specific training routine?"
            scene pool16
            with dissolve
            grace "Well, I relax first, then I swim laps, and sometimes I try to pick up some speed..."
        "Temperament [TEMP2!t]":

            call temperament_increased from _call_temperament_increased_12
            d "That's because you've never experienced my massages!"
            scene pool15
            with dissolve
            grace "You seem pretty sure of yourself!"
            d "Of course! Compared to water, my hands are more agile and can relax your entire body with a simple touch..."
            scene pool16
            with dissolve
            grace "Oh yeah ? I'd like to see that !"
            d "We'll see... if you deserve it !"

    scene pool17
    with dissolve
    grace "And do you train a bit?"
    d "Not really..."
    scene pool18:
        xalign 0.0
        linear 5.0 yalign 0.9
        linear 3.0 yalign 0.0
        repeat 1
    dpense "What a goddess..."
    scene pool19
    with dissolve
    grace "You don't do any sports outside of classes?"
    scene pool20
    with dissolve
    d "Well, I haven't had much opportunity here..."
    d "Back in France, I used to play soccer and do rock climbing..."
    grace "Rock climbing?"
    scene pool21
    with dissolve
    d "Yeah! Out in nature, on cliffs, small mountains..."
    grace "That takes endurance! It's super dangerous!"
    d "You need to have a good grip, but most importantly, you always have to prioritize your safety..."
    d "And yes, it requires some endurance... But playing soccer gave me some cardio, so I'm good with that!"
    scene pool22
    with dissolve
    grace "You're good?"
    d "Uh... yeah..."
    scene pool23
    with dissolve
    grace "Alright, Mr. I'm Good... I propose a deal!"
    d "Hmm?"
    grace "Two laps in the pool, the loser owes the winner a favor, anytime, anywhere..."
    d "What kind of favor?"
    scene pool24
    with dissolve
    grace "Hmm... Let's just say I'll think about it..."
    d "Okay... So if I win..."
    scene pool25
    with dissolve
    grace "You won't win!"
    d "Haha! So, when I win... I can ask you for almost anything?"
    scene pool26
    with dissolve
    grace "More or less, yes... but it works both ways!"
    d "Both ways?"
    grace "As I'll win... I can ask you for anything too!"
    d "Sure, sure..."
    scene pool27
    with dissolve
    grace "We'll see about that!"
    d "Alright!"
    scene black
    with fade
    pause 1
    scene pool28
    with dissolve
    grace "On your marks!"
    dpense "I can't mess this up!"
    grace "At 3, go!"
    d "Ready!"
    grace "1..."
    grace "2..."
    grace "3!"
    scene pool29
    with dissolve
    pause 2    
    scene pool33
    with dissolve
    label nage:

        if persistent.patch_enabled == True:
            $ TEMP1 = e2poolm3c1
            $ TEMP2 = e2poolm3c2
            $ TEMP3 = e2poolm3c3
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
            $ TEMP3 = ""

        menu:
            "Go faster [TEMP1!t]" if Sport >= 5:
                call sport_increased from _call_sport_increased_10
                scene pool34
                with dissolve
                jump nage2

            "Watch her [TEMP2!t]" if Temperament >= 5:
                call temperament_increased from _call_temperament_increased_13
                scene pool30
                with dissolve
                jump nage2
            "Swim normally [TEMP3!t]":

                call buddy_increased from _call_buddy_increased_12
                scene pool33
                with dissolve
                jump nage2

    label nage2:
        dpense "I need to go faster than her!"
        scene pool35
        with dissolve
        pause 1

        if persistent.patch_enabled == True:
            $ TEMP1 = e2poolm4c1
            $ TEMP2 = e2poolm4c2
            $ TEMP3 = e2poolm4c3
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
            $ TEMP3 = ""

        menu:
            "Go even faster [TEMP1!t]" if Sport >= 7:
                call sport_increased from _call_sport_increased_11
                $ Cheat = False
                scene pool32
                with dissolve
                pause 1
                scene pool37
                with dissolve
                pause 1 
                scene pool42
                with dissolve
                pause 1 
                scene pool38
                with dissolve
                pause 1
                jump nage3

            "Cheat [TEMP2!t]" if Temperament >= 7:
                $ Cheat = True
                call temperament_increased from _call_temperament_increased_14
                scene pool30
                with dissolve
                pause 1
                scene pool37
                with dissolve
                pause 1 
                scene pool36
                with dissolve
                pause 1 
                scene pool38
                with dissolve
                pause 1
                jump nage3
            "Swim normally [TEMP3!t]":

                call education_increased from _call_education_increased_8
                $ Cheat = False
                scene pool31
                with dissolve
                pause 1
                scene pool37
                with dissolve
                pause 1 
                scene pool36
                with dissolve
                pause 1 
                scene pool42
                with dissolve
                pause 1
                scene pool38
                with dissolve
                pause 1
                jump nage3

    label nage3:
        scene pool39
        with dissolve
        pause 1
        dpense "It's the final sprint!"

        if persistent.patch_enabled == True:
            $ TEMP1 = e2poolm5c1
            $ TEMP2 = e2poolm5c2
            $ TEMP3 = e2poolm5c3
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
            $ TEMP3 = ""

        menu:
            "Sprint [TEMP1!t]" if Sport >= 8:
                scene pool41
                with dissolve
                pause 1
                scene pool42
                with dissolve
                pause 1 
                scene pool44
                with dissolve
                pause 1          
                d "VICTORY !!!"
                scene black
                with fade
                pause 1
                jump victory

            "Win [TEMP2!t]" if Cheat == True:
                scene pool40
                with dissolve
                pause 1
                scene pool41
                with dissolve
                pause 1
                scene pool42
                with dissolve
                pause 1 
                d "VICTORY !!!"
                scene pool45
                with dissolve
                pause 1             
                grace "CHEATER !!!"
                scene black
                with fade
                pause 1
                jump cheater
            "Let her win [TEMP3!t]":

                scene pool40
                with dissolve
                pause 1
                scene pool41
                with dissolve
                pause 1
                scene pool43
                with dissolve
                pause 1 
                scene pool44
                with dissolve
                pause 1             
                grace "VICTORY !!!"
                scene black
                with fade
                pause 1
                jump defeat

    label victory:
        call sport_increased from _call_sport_increased_12
        $ Achievement.add(achievement_victory)
        $ achievement.grant("victory")
        $ achievement.sync()
        scene pool46
        with dissolve
        grace "Wow! You impressed me! I couldn't keep up with you!"
        d "You did great! I thought I wouldn't win in the end!"
        grace "Yeah... So, I owe you a favor..."
        d "Haha! You were the one who proposed it, right?"
        scene pool47
        with dissolve
        grace "Yeah, well, I didn't expect such a fierce competition!"
        d "I warned you!"
        grace "Nanaaa! Mr. I'm too proud!"
        d "What am I going to ask you for..."
        scene pool48
        with dissolve
        grace "Don't be too hard on me, though..."
        d "Hmmm..."
        dpense "If you only knew how hard it is right now..."
        d "I'll save this favor for later, is that okay?"
        scene pool49
        with dissolve
        grace "Okay...!"
        $ McFavor = True
        $ GraceFavor = False
        $ McFavorCheat = False
        jump endpool

    label cheater:
        call temperament_increased from _call_temperament_increased_15
        $ Achievement.add(achievement_cheater)
        $ achievement.grant("cheater")
        $ achievement.sync()
        scene pool46
        with dissolve
        grace "You cheated !!!"
        d "It wasn't written in the rules that we have to touch the wall !"
        grace "Nonsense!"
        d "Well, what?"
        scene pool47
        with dissolve
        grace "Okay... Let's say we BOTH have the right to ask a favor from each other... okay?"
        d "Sounds good to me!"
        scene pool48
        with dissolve
        grace "Don't be too hard on me, though..."
        d "Hmmm..."
        dpense "If you only knew how hard it is right now..."
        d "I'll save this favor for later, is that okay?"
        scene pool49
        with dissolve
        grace "Okay...!"
        $ McFavor = False
        $ McFavorCheat = True
        $ GraceFavor = True
        jump endpool

    label defeat:
        call buddy_increased from _call_buddy_increased_13
        $ Achievement.add(achievement_defeat)
        $ achievement.grant("defeat")
        $ achievement.sync()
        scene pool46
        with dissolve
        grace "I won! Ahahah!"
        d "There was nothing I could do, you were really too strong!"
        grace "Yeah, I know!"
        d "Still, I put up a good fight!"
        scene pool47
        with dissolve
        grace "Yeah, sure... So, what am I going to ask you for?"
        dpense "Ask me anything you want..."
        scene pool48
        with dissolve
        grace "I'll save it for later, if you don't mind..."
        scene pool49
        with dissolve
        d "No problem!"
        $ McFavor = False
        $ GraceFavor = True
        $ McFavorCheat = False
        jump endpool

label endpool:

    scene black
    with fade
    pause 1
    scene pool50
    with dissolve
    d "You were right, though... It feels good to be in the pool like this... even after a race, it's very relaxing..."
    grace "I told you! It helps me relieve stress and not think about everyday worries..."
    d "Your mother stresses you out?"
    scene pool51
    with dissolve
    grace "Yes... Basically, I have to be the perfect daughter for Madame the University Director..."
    grace "It's super overwhelming..."
    d "Yeah, I understand..."
    scene pool52
    with dissolve
    grace "If I don't have the best grades, if I'm not the captain of the soccer team..."
    grace "If I don't have a boyfriend from a well-respected family..."
    scene pool53
    with dissolve
    d "Oh, she's pressuring you about that too?"
    grace "Yes... Basically, I have to be perfect in all areas and ready to marry a boy from the best family around to make alliances between families..."
    grace "That's how it works here..."
    d "And do you already have a suitor?"
    scene pool54
    with dissolve
    grace "Several! But I still haven't found the right one..."
    grace "And my mother keeps pushing me to choose someone like Emerick or others from families like the Orushi..."
    scene pool55
    with dissolve
    d "What if someone..."
    scene pool56
    with dissolve
    d "Was interested in you..."
    scene pool57
    with dissolve
    d "But wasn't from that kind of background..."
    scene pool58
    with dissolve
    grace "My mother would be..."
    scene pool59
    with dissolve
    grace "Really displeased..."
    scene pool60
    with dissolve
    d "But would you..."
    scene pool61
    with dissolve
    d "Be?"
    pause 2
    ji "Ahem, ahem..." with hpunch
    scene pool62:
        xalign 0.0
        linear 5.0 yalign 0.9
        linear 3.0 yalign 0.0
        repeat 1
    with dissolve
    drew "Grace! Would you please get out of the water and join me quickly... we have dinner tonight!"
    scene pool63
    with dissolve
    grace "Yes, Mother..."
    scene pool64
    with dissolve
    dpense "Phew, that was close..."
    drew "And as for you, [name]... Don't forget that I'm watching you... Do you understand?"
    d "Yes, Mrs. Drew..."
    dpense "This won't be easy..."
    scene pool65
    with dissolve
    grace "Hey, [name]!"
    d "Hmm?"
    grace "Do you have a phone?"
    d "Uh... yes..."
    grace "Here, add me to your contacts later !"
    $ renpy.notify (_("NEW CONTACT ADDED"))
    $ Gracephone = True
    d "Hey ! Do you know something about a party at the end of the week ?"
    scene pool66
    with dissolve
    grace "Yeah ! I will host it ! In my house !"
    grace "You'll come ?"
    $ Fest = True
    scene pool67
    with dissolve
    d "Of course !"
    grace "Okay ! So... See you tomorrow!"
    d "See ya!"
    stop music fadeout 2
    $ Piscine = True
    scene black
    with fade
    pause 1
    jump e2s3

label sofiapool:
    if _in_replay:
        show screen Replayexit

    scene black
    with fade
    pause 1
    scene pool68
    with dissolve
    if persistent.patch_enabled:
        if persistent.rufus6 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
    d "Where are we ?"
    sofia "That's the old auditorium..."
    if persistent.rufus6 == False:
        scene pool69 with dissolve
        show screen chat6() with dissolve
    else:
        scene pool69
        with dissolve
    sofia "No one uses it anymore... sometimes the student council..."
    sofia "As a member of the council I have the key..."
    stop music fadeout 2 
    pause 1
    hide screen chat6
    scene pool70
    with dissolve
    sofia "So... Will you show me what you're able to do ?"
    play music "musique/Lyvo-Home.mp3"
    scene pool71
    with dissolve
    d "You're not ready..."
    sofia "Oh ? And you think you can handle me easily ?"
    if persistent.streaming == True:
        d "I will make you squirt until you beg me to fuck you..."
        scene pool75
        with dissolve
        sofia "Yes... Do it..."
        scene pool79
        with dissolve
        sofia "Do what you want with me..."
        d "Lie down on the desk !"
        sofia "Hummmm...."
        sofia "I can't wait to feel your touch..."
        sofia "Please... Play with me.... I'm your toy..."
        scene pool81
        with dissolve
        sofia "Ahhhhhhhhhhhh...."
        dpense "She's totally under my control..."
        dpense "She let me do exactly what I want..."
        dpense "I think she feels a lot of pleasure to be under my domination..."
        scene pool78
        with dissolve
        sofia "Oh... I'm already coming! Don't stop !"
        scene pool81
        with dissolve
        sofia "Ahhhhh !!!! "
        sofia "Make me cum my lord..."
        dpense "She becomes totally crazy..."
        scene pool87
        with dissolve
        sofia "Ohhhhhh ! I'm gonna COME !!!!"
        with flash
        with hpunch
        scene black
        with dissolve
        pause 1
        jump finblueep2
    scene black
    $ renpy.movie_cutscene("images/animation/sofia1.webm", stop_music=False)
    pause 0.2
    scene pool72
    with dissolve
    pause 0.1
    scene pool73
    with dissolve
    pause 0.1
    d "I will make you my bitch and you will scream my name until I have finished with you..."
    scene pool72
    with dissolve
    pause 0.1
    scene pool73
    with dissolve
    pause 0.1
    sofia "Ahhh..."
    scene pool74
    with dissolve
    d "I will make you squirt until you beg me to fuck you..."
    scene pool75
    with dissolve
    sofia "Yes... Do it..."
    scene pool76
    with dissolve
    d "I will make you my slut and you will swallow all my cum directly down your throat..."
    sofia "Oh yes... I'll do it !"
    scene black
    $ renpy.movie_cutscene("images/animation/sofia2.webm", stop_music=False)
    pause 0.2
    scene pool77
    with dissolve
    d "I will treat you like my personal bitch... You will respond to all my desires..."
    scene pool79
    with dissolve
    sofia "Do what you want with me..."
    d "Lie down on the desk !"
    sofia "Hummmm...."
    scene black
    $ renpy.movie_cutscene("images/animation/sofia3.webm", stop_music=False)
    scene pool80
    with dissolve
    sofia "I can't wait to feel your touch..."
    sofia "Please... Play with me.... I'm your toy..."
    scene black
    $ renpy.movie_cutscene("images/animation/sofia4.webm", stop_music=False)
    scene pool81
    with dissolve
    sofia "Ahhhhhhhhhhhh...."
    dpense "She's totally under my control..."
    dpense "She let me do exactly what I want..."
    dpense "I think she feels a lot of pleasure to be under my domination..."
    scene pool78
    with dissolve
    sofia "Oh... I'm already coming! Don't stop !"
    scene black
    $ renpy.movie_cutscene("images/animation/sofia5.webm", stop_music=False)
    scene pool81
    with dissolve
    sofia " Ahhhhh !!!! "
    sofia " Gimme your dick ! "
    scene pool82
    with dissolve
    sofia "Make me cum my lord..."
    sofia "And cum on me when I do..."
    sofia "I want to feel you on my face"
    dpense "She becomes totally crazy..."
    scene black
    $ renpy.movie_cutscene("images/animation/sofia6.webm", stop_music=False)
    scene pool83
    with dissolve
    pause 0.3
    scene pool84
    with dissolve
    pause 0.3
    sofia "I love your dick !! Hummmmmmmm...."
    scene pool83
    with dissolve
    pause 0.3
    scene pool84
    with dissolve
    pause 0.3
    scene pool83
    with dissolve
    pause 0.3
    scene pool84
    with dissolve
    pause 0.3
    scene black
    with fade
    scene pool85
    with dissolve
    pause 0.1 
    scene pool86
    with dissolve
    pause 0.1
    scene pool85
    with dissolve
    pause 0.1 
    scene pool86
    with dissolve
    pause 0.1
    sofia "Oh yes keep going like that !"
    scene pool85
    with dissolve
    pause 0.1 
    scene pool86
    with dissolve
    pause 0.1
    scene pool85
    with dissolve
    pause 0.1 
    scene pool86
    with dissolve
    pause 0.1
    sofia "Like that ! Like that ! Like that !"
    scene pool85
    with dissolve
    pause 0.1 
    scene pool86
    with dissolve
    pause 0.1
    scene pool85
    with dissolve
    pause 0.1 
    scene pool86
    with dissolve
    pause 0.1
    scene pool87
    with dissolve
    sofia "Ohhhhhh ! I'm gonna COME !!!!"
    with flash
    with hpunch
    scene pool88
    with dissolve
    sofia "Ahhhh ! AHHHHHHHHH ! ......"
    with flash
    with hpunch
    scene pool89
    with dissolve
    sofia "MYYYYYYYYYYYYYYY GGGGGGGGGGOOOOOOOOOOOODDDDDDDDDDD !!!"
    pause 1
    scene pool87
    with dissolve
    d "I'm coming too !!!"
    with dissolve
    with flash
    with hpunch
    scene pool90
    with dissolve
    with flash
    with hpunch
    d "Ahhhhhhhhh...."
    with flash
    with vpunch
    with flash
    pause 1
    scene pool91
    with dissolve
    pause 1
    sofia "Slimy yet satisfying !"
    pause 1
    scene black
    with fade
    pause 1
    label finblueep2:
        pause 1
    scene pool92
    with dissolve
    d "I told you that I would make you squirt !"
    $ Achievement.add(achievement_evolve)
    $ achievement.grant("evolve")
    $ achievement.sync()
    sofia "Yeah..."
    d "You were good..."
    sofia "You weren't too bad either..."
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    pause 1
    scene pool93
    with dissolve
    sofia "Do you have a phone ?"
    d "Sure... Why ?"
    sofia "Easier to keep in contact..."
    $ renpy.notify (_("NEW CONTACT ADDED"))
    pause 1
    $ Bluephone = True
    sofia "Well... See you later ?"
    d "Yeah... Sure..."
    scene black
    with fade
    pause 1 
    scene pool8
    with dissolve
    dpense "I hope Blue wasn't too loud..."
    stop music fadeout 2
    scene black
    with fade
    pause 1
    play music "musique/Meydan-Changes.mp3" 
    $ BlueRelation = True
    jump pool2

label rufusg6:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img6"):
        show img6
        hide img6
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus6 = True
    hide screen chat6
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
