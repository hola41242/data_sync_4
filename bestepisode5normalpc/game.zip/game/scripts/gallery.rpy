screen gallery():
    tag menu

    use game_menu(_("Rufus Found : [persistent.rufusgame] / 15")):

        frame:
            yoffset -50
            background "gui/frame2.png"
            padding (10, 10, 10, 30)
            align (0.0, 0.0)
            $ start = gallery_page * maxperpage
            $ end = min(start + maxperpage - 1, len(gallery_items) - 1)


            grid maxnumx maxnumy:
                xfill True
                yfill True
                spacing 10

                for i in range(start, end + 1):
                    $ gallery_items[i].refresh_lock()
                    if gallery_items[i].is_locked:
                        add gallery_items[i].locked:
                            xalign 0.5
                            yalign 0.5
                    else:
                        imagebutton idle gallery_items[i].thumb:
                            style "gallery_button"
                            action Show("gallery_closeup", dissolve, gallery_items[i].images)
                            xalign 0.5
                            yalign 0.5

                for i in range(end - start + 1, maxperpage):
                    null


            grid maxnumx maxnumy:
                xfill True
                yfill True
                spacing 10

                for i in range(start, end + 1):
                    hbox:
                        spacing maxthumbx - 20
                        xalign 0.1
                        yalign 1.06
                        text gallery_items[i].name

                for i in range(end - start + 1, maxperpage):
                    null


            if gallery_page > 0:
                textbutton "{color=#2735b4ff}Previous{/color}":
                    action SetVariable("gallery_page", gallery_page - 1)
                    xalign 0.1
                    yalign 0.98
                    yoffset 100
                    background "#ffffff00"
            if (gallery_page + 1) * maxperpage < len(gallery_items):
                textbutton "{color=#2735b4ff}Next{/color}":
                    action SetVariable("gallery_page", gallery_page + 1)
                    xalign 0.9
                    yalign 0.98
                    yoffset 100
                    background "#2735b400"







screen gallery_closeup(images):
    zorder 1
    imagebutton idle images[closeup_page]:
        action [SetVariable("closeup_page", 0), Hide("gallery_closeup", dissolve)]
        xalign 0.5
        yalign 0.98
        background "#ffffffff"

style gallery_button:
    hover_background "images/gallery/thumbs/hover.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
