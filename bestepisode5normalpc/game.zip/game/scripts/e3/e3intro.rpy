label e3intro:
    pause 2
    with fade
    stop music fadeout 2.0
    with fade
    play music "musique/NaanMoons-APenthouseInTheDesert.mp3" volume 0.2
    pause 2.0
    scene introe31
    with dissolve
    pause 2
    scene introe32
    with dissolve
    pause 2
    scene ruby1
    with dissolve
    pause 1
    ruby "Hmpfff"
    play movie "images/animation/rubya1.webm" loop volume(0)
    show movie with dissolve
    ruby "I really don't know what to wear. With the party at Grace's..."
    if cinema == True:
        ruby "and the movie night with [name]..."
    stop movie
    ruby "I'm gonna have to pull out all the stops."
    scene ruby2
    with dissolve
    pause 1
    play movie "images/animation/rubya2.webm" loop volume(0)
    show movie with dissolve
    ruby "Should I wear something more sexy..."
    ruby "or classy?"
    stop movie
    ruby "What about you ladies?"
    scene ruby3
    with dissolve
    pause 1
    ruby "What do you think?"
    scene ruby4
    with dissolve
    pause 1
    ruby "Something..."
    scene ruby5
    with dissolve
    pause 1
    ruby "A little bit cyber?"
    scene ruby6
    with dissolve
    pause 1
    ruby "Or something more elegant?"
    scene ruby7
    with hpunch
    with dissolve
    pause 1
    ruby "Ohhh... I should go buy some new dresses!"
    scene ruby8
    with dissolve
    pause 1
    ruby "Maybe [name] would like to come with me?"
    ruby "I would really like it if he helped me choose."
    scene ruby9
    with dissolve
    pause 1
    ruby "I bet he's sleeping."
    $ Training = False
    if persistent.patch_enabled == True:
        $ TEMP1 = e3intro1
        $ TEMP2 = e3intro2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    call phone_discussion_ruby2 from _call_phone_discussion_ruby2
    pause 1
    if Redstore == True:
        scene ruby9
        with dissolve
        pause 1 
        scene black
        with fade
        stop music fadeout 2
        pause 1
        jump e3s1a
    if Redstore == False:
        scene ruby10
        with dissolve
        pause 1
        scene black
        with fade
        stop music fadeout 2
        pause 1
        jump e3s1b
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
