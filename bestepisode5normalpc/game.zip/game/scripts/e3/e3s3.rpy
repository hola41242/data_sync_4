label e3s3:
    stop music fadeout 2 
    scene black
    with fade
    pause 1
    scene e2s340
    with fade
    pause 1 
    scene e2s341
    with fade
    pause 1 
    scene e3s3a2
    with dissolve
    julia "Well, here we are. This is my place!"
    d "It's nice!"
    julia "Oh, it's nothing special, but it's all I need and it's affordable."
    scene e3s3a1
    with dissolve
    julia "Then again, it's not in the fanciest neighborhoods, as you might have noticed..."
    d "I don't really know the neighborhoods yet, but yeah, the alley we passed through was a bit sketchy."
    julia "Well, just think that I go through there every day after my shift!"
    d "That doesn't seem very safe..."
    d "Why didn't you tell me you had a job?"
    scene e3s3a3
    with dissolve
    julia "Let's just say I'm not in the same financial situation as the others."
    julia "I have a scholarship that allows me to continue my studies at the university."
    julia "Between the rent and... other issues I have to deal with, I have to work to pay for all of it."
    julia "I'm not like Madison or the twins, I don't have my parents to support me."
    d "Where are your parents?"
    scene e3s3a4
    with dissolve
    julia "Uh... I don't know where my father is. I've never met him."
    julia "And my mother is very sick."
    scene e3s3a5
    with dissolve
    julia "She has bone cancer and doesn't have much time left..."
    d "I'm so sorry, my apologies."
    julia "Since she doesn't really have insurance, I have to help pay for her care."
    d "That's a lot to have on your shoulders."
    scene e3s3a6
    with dissolve
    julia "Yes, that's why I keep to myself a bit. I have enough on my plate with all of that."
    julia "When I hear others complaining about trivial things..."
    scene e3s3a7
    with dissolve
    julia "Or when Madison yells at me for no reason, I admit I find it hard to keep my cool."
    d "I understand."
    julia "But I won't let it stop me from living and..."
    scene e3s3a8
    with vpunch
    julia "Ouch!"
    d "What's wrong?"
    julia "The back pain is still pretty bad! I must have really done a number on it in when I fell."
    scene e3s3a9
    with dissolve
    d "Wait, lie down on the bed."
    julia "Huh?"
    d "I'll give you massage. It'll help."
    scene e3s3a10
    with dissolve
    julia "You know how to do that?"
    d "Yeah, I took a sports therapy course and I promise it will relieve the pain."
    julia "Um, okay, we can try..."
    d "Lie down."
    julia "Okay."
    scene black
    with fade
    play music "musique/Nomyn-Fragments.mp3" volume 0.2
    pause 1
    $ renpy.movie_cutscene("images/animation/juliamassage.webm", stop_music=False)
    scene e3s3a11
    with dissolve
    d "Honestly... You look like a corpse in that position!"
    julia "Hey!" with hpunch
    julia "I'll have you know that really hurts!"
    scene e3s3a12
    with dissolve
    d "Yeah, sorry. Just let me do this, you'll feel better afterward, you'll see."
    julia "I hope so..."
    scene e3s3a13
    with dissolve
    d "You're really tense!"
    julia "I'm not really used to lying down with someone on my bed..."
    scene e3s3a14
    with dissolve
    julia "I think I'd be more comfortable sitting up."
    d "Do whatever you want. I just want you to relax."
    scene e3s3a15
    with dissolve
    julia "This is much better."
    d "If you say so."
    scene e3s3a16
    with dissolve
    julia "A bit lower..."
    scene e3s3a17
    with dissolve
    julia "Yeah..."
    julia "Just like that"
    d "It will be easier if you take off your top."
    scene e3s3a18
    with dissolve
    pause 2 
    scene e3s3a19
    with dissolve
    julia "Uh... Yeah, that makes sense."
    scene e3s3a20
    with dissolve
    pause 1
    scene black
    with dissolve
    pause 1 
    scene e3s3a21
    with dissolve
    d "Don't worry. Do your best to loosen and relax your muscles."
    julia "I'll try."
    scene e3s3a22
    with dissolve
    julia "Ah, that feels good..."
    d "I told you."
    d "Now, relax."
    scene e3s3a23
    with dissolve
    julia "Um, yes, there..."
    julia "A little lower... There..."
    scene e3s3a24
    with dissolve
    julia "That's perfect."
    d "Do you want me to continue further?"
    if Grope == True:
        scene e3s3a26
        with dissolve
        julia "I think you've already massaged my lower half enough on the plane."
        d "Oh... I'm sorry. That was out of line on my part."
        julia "But thanks anyway."
        jump finjuliaep2
    scene e3s3a25
    with dissolve
    julia "I don't know if..."
    scene e3s3a27
    with dissolve
    julia "Ah, that really feels good..."
    scene e3s3a30
    with dissolve
    d "You know, you have a beautiful body."
    julia "Uh... Thanks?"
    play movie "images/animation/juliamassage2.webm" volume(0)
    show movie with dissolve
    d "You're muscular with beautiful curves, and your skin is soft."
    julia "Ah..."
    scene e3s3a29
    with dissolve
    stop movie 
    d "Let me take care of you, Julia."
    julia "Hmm..."
    scene e3s3a31
    with dissolve
    scene e3s3a32
    $ renpy.movie_cutscene("images/animation/juliamassage3.webm", stop_music=False)
    d "I want you to trust me, to be someone you can rely on."
    d "Let me discover the real Julia. The blossom that's just waiting to flourish."
    scene e3s3a28
    with dissolve
    julia "Oh..."
    d "I'll be here for you if you need me."
    scene e3s3a33
    with dissolve
    julia "I..."
    scene e3s3a34
    with dissolve
    julia "Ah!"

label finjuliaep2:
    julia "Thank you. I think that's enough for tonight. I already feel much better."
    d "Don't hesitate to tell me when you need my expert hands!"
    julia "Yes, thank you. Really."
    scene e3s3a35
    with dissolve
    d "I'll head out then. I still have to get back home and I promised Ruby I'd send her a message when I get back. I don't want her to worry!"
    julia "Oh yes! You can be sure she won't sleep until she has heard from you."
    julia "She's like that with people she cares about."
    scene e3s3a36
    with dissolve
    d "I should hurry home then."
    julia "Yes, you better."
    d "See you tomorrow, Julia."
    julia "See you tomorrow... [name]."
    scene black
    with fade
    pause 2
    jump e3s4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
