label e3s1b:

    call sport_increased from _call_sport_increased_17
    pause 1 
    play music "musique/Stellardrone-ToTheGreatBeyond.mp3" volume 0.2
    scene black
    with dissolve
    pause 1
    scene e3s1b1
    with dissolve
    pause 1 
    d "I have to work harder to catch up with the others."
    scene e3s1b2
    with dissolve
    pause 1
    d "I need to improve."
    scene black
    play movie "images/animation/ballout.webm" volume(0)
    show movie with dissolve
    pause 0.5
    stop movie
    scene e3s1b1
    with dissolve
    d "The next match is going to be more challenging."
    scene e3s1b2
    with dissolve
    pause 1
    d "I have to give it my all and leave it all out there."
    scene black
    play movie "images/animation/ballout.webm" volume(0)
    show movie with dissolve
    pause 0.5
    stop movie
    ji "Not bad."
    ji "Would be better if it was in the cage."
    ji "You need to work on your footwork."
    scene e3s1b4
    with hpunch
    with dissolve
    d "Huh???"
    gaby "Your footwork. The way you move your feet."
    scene e3s1b5
    with dissolve
    gaby "Plant your lead foot when you shoot and lean forward as much as you can so you can transfer all the force to the ball."
    d "Transfer all the force?"
    gaby "Yes. If you lean backward, the ball will fly up. If you lean forward, the ball will take all the power, and you can put more spin on it."
    d "Uh, I didn't know that."
    scene e3s1b6
    with dissolve
    gaby "Go ahead, try!"
    d "..."
    scene black
    play movie "images/animation/ballin.webm" volume(0)
    show movie with dissolve
    pause 0.5
    stop movie
    scene e3s1b6
    with dissolve
    d "I can't quite get it. I'm not connecting clean enough on the ball."
    gaby "You will get it."
    d "How do you know all this?"
    scene e3s1b7
    with dissolve
    gaby "I'm a coach, you know... And there was a time when I played a lot too..."
    gaby "I was young then."
    d "You still are young though."
    scene e3s1b8
    with dissolve
    gaby "Well, I guess I am. It's just not the same anymore."
    gaby "I don't have the same body I did before."
    scene e3s1b17
    with dissolve
    gaby "The passage of time, as they say..."
    if persistent.patch_enabled == True:
        $ TEMP1 = e3s1bc1
        $ TEMP2 = e3s1bc2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Education[TEMP1!t]":
            call education_increased from _call_education_increased_11
            scene black
            play movie "images/animation/gabyfootw.webm" volume(0)
            show movie with dissolve
            d "If I may, I think you underestimate yourself."
            d "You're absolutely gorgeous. Even time would be too stunned to pass you by."
            d "Any man would be crazy not to notice a woman as lovely as you."
            d "Sorry, I shouldn't have said anything."
            stop movie
            scene e3s1b9
            with dissolve
            gaby "I must admit I didn't expect that from one of my students..."
            gaby "It's very flattering. I don't think it's very appropriate to say to your coach though."
            gaby "Even though I'd like if everyone felt the same way as you."
            d "I wasn't trying to flatter you. I'm just telling you what I think."
            scene e3s1b10
            with dissolve
            gaby "Keep it to yourself then. It could cause trouble if someone overheard you saying such things to a teacher. Neither of us would want that, would we?"
        "Temperament[TEMP2!t]":
            call temperament_increased from _call_temperament_increased_7
            scene black
            play movie "images/animation/gabyfootw.webm" volume(0)
            show movie with dissolve
            d "You used to be in better shape?! I caught a glimpse of you in a swimsuit the other day and let me tell you, you have an incredible body!"
            gaby "What are you talking about?"
            d "I mean, seriously! You're a bombshell! I don't know how else to put it."
            d "If I were lucky enough to be your man, I'd want the world to know! And trust me, I wouldn't miss chance to appreciate and explore that gorgeous body of yours."
            stop movie
            scene e3s1b9
            with dissolve
            gaby "I don't believe this conversation is very appropriate, Mister [name]."
            d "I know it's not but it's the truth! I mean, just look at you! If you look in the mirror and don't see an absolute beauty, you must be blind! I don't know what may have happened before to make you think this way."
            d "But it's absurd!"
            d "If some idiot mistreated you in the past, you need to let it go. Hold your head high and move forward because you're clearly too beautiful to think this way!"
            scene e3s1b10
            with dissolve
            gaby "Um... I think I should go."
    gaby "Well, get back to your training. You're on the right path."
    scene e3s1b11
    with dissolve
    d "I will give my best."
    d "Any last advice for the upcoming match?"
    gaby "Oh? Hmm... Play with the bar."
    scene e3s1b12
    with dissolve
    d "The bar?"
    scene e3s1b13
    with dissolve
    gaby "See you later, young man."
    d "Uh, Yeah... See you later."
    scene e3s1b14
    with dissolve
    d "What did she mean by playing with the bar?"
    d "Well, first, position my body more forward..."
    scene black
    with fade
    pause 1
    scene e3s1b15
    with dissolve
    gaby "He's quite audacious, but that kid is right."
    gaby "I need to stop thinking like this..."
    scene e3s1b16
    with dissolve
    gaby "Nevertheless, it's been a long time since someone spoke to me like that."
    gaby "Come on, Gaby. Pull yourself together. He's just a student..."
    $ Training = True
    stop music fadeout 2 
    scene black
    with fade
    pause 1

    jump e3s1a
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
