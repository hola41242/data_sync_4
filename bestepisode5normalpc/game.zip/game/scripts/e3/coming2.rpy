label coming2:
    jump ep3intro
    scene black
    with fade
    pause 1
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" 
    pause 1.25
    scene coming
    with zoomout
    pause 4
    scene black
    with fade
    pause 0.5
    scene madgymep3 with dissolve:
        xalign 0.0
        linear 5.0 yalign 0.9
        linear 3.0 yalign 0.0
        repeat 1
    mad "Dad... Why do you want to meet him ?"
    mad "..."
    mad "I will..."
    pause 2
    scene black
    with fade
    pause 0.5
    scene sad1
    with dissolve
    ji "Mum..."
    scene sad2
    with dissolve
    pause 2 
    scene black
    with fade
    pause 1
    scene gracenight
    with dissolve
    grace "You're the only one I want tonight..."
    pause 1
    scene episode3teaser
    with dissolve
    pause 5 
    stop music fadeout 5
    scene black
    with fade
    pause 2
    jump ep3intro
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
