label e3s1a:
    play music "musique/Vexento_Now.mp3" volume 0.2
    pause 1 
    scene e3s1a1
    with fade
    pause 2 
    scene e3s1a2
    with dissolve
    pause 1 
    scene e3s1a3
    $ renpy.movie_cutscene("images/animation/introe3s1a.webm", stop_music=False)
    scene e3s1a3
    pause 1
    ruby "Come on! Don't be like that! You'll see, it's going to be fun!"
    scene e3s1a5
    with dissolve
    d "Hmm, I'm not too sure about that..."
    scene e3s1a5
    with dissolve
    ruby "It will! Red is super professional! I'm sure she'll find us some really neat stuff for the party tomorrow!"
    scene e3s1a6
    with dissolve
    d "Us?"
    ruby "Of course! Tomorrow is a theme party. Didn't someone tell you?"
    scene e3s1a7
    with dissolve
    d "Uh... no?"
    ruby "It's a chic and provocative party!"
    d "What does that mean?"
    scene e3s1a8
    with dissolve
    ruby "Well, it's often about dressing up both fancy and sexy, or with something that stands out."
    d "And how do you expect me to be chic and provocative?"
    scene e3s1a9
    with dissolve
    beth "Don't worry, I'm here to help."
    d "What?"
    ruby "Thank you, Elizabeth!"
    scene e3s1a10
    with dissolve
    beth "You're welcome. It is my job, you know."
    beth "Ruby, do you know what style you're looking for?"
    scene e3s1a11
    with dissolve
    ruby "Actually, for once, I really have no idea."
    beth "I'll see what I have for you, feel free to look around in the meantime."
    ruby "Okay!"
    scene e3s1a12
    with dissolve
    ruby "See, I told you! When we are in her store, she completely changes!"
    d "Hmm..."
    scene e3s1a13
    with dissolve
    ruby "Well, we still need to find something. Any ideas?"
    $ Rubybuddy = False
    $ Rubysexy = False
    if persistent.patch_enabled == True:
        $ TEMP1 = e3s1c1
        $ TEMP2 = e3s1c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    if Redstore == True:
        menu:
            "Buddy [TEMP1!t]":
                call buddy_increased from _call_buddy_increased_17
                d "Anything you wear will look great on you. I'm sure of it!"
                ruby "Oh! You're too sweet!"
                $ Rubybuddy = True
            "Temperament [TEMP2!t]":
                call temperament_increased from _call_temperament_increased_6
                d "I'd like you to wear something that highlights your body. You're stunning but you don't show it off enough!"
                ruby "Oh? Uh, I'll try..."
                $ Rubysexy = True
    scene e3s1a14
    with dissolve
    beth "Come here, I've found quite a few things for you to try on!"
    ruby "On our way!"
    scene e3s1a15
    with dissolve
    beth "Here, Ruby, you can use this fitting room."
    ruby "Okay! Thank you, Elizabeth!"
    scene e3s1a16
    with dissolve
    with vpunch
    d "Now is the fun part!"
    pause 1
    if persistent.patch_enabled == True:
        $ TEMP1 = e3s1ac1
        $ TEMP2 = e3s1ac2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    if Redpath == True:
        scene e3s1a17
        with dissolve
        menu:
            "Follow Red[TEMP1!t]":
                stop music fadeout 2
                if _in_replay:
                    show screen Replayexit
                scene e3s1a46
                with dissolve
                beth "Come over here [name], I've got some things for you to try too!"
                play music "musique/PunchDeck_Destabilized.mp3" volume 0.2
                $ renpy.movie_cutscene("images/animation/redstore1.webm", stop_music=False)
                jump redshop
            "Stay with Ruby[TEMP2!t]":
                scene e3s1a18
                with dissolve
                pause 1
                jump rubyshop
label rubyshop:
    $ rubyhelp = False
    if ('Stripruby' in vars() or 'Stripruby' in globals()) and Stripruby == True:
        scene e3s1a20
        with dissolve
        ruby "You can look, it doesn't bother me!"
        d "What do you mean?"
        scene e3s1a21
        with dissolve
        ruby "You've changed in front of me in your room and I didn't close my eyes... So, it's only fair!"
        d "Uh..."
        scene e3s1a22
        with dissolve
        ruby "Look who's being shy now..."
        d "I'm not being shy!"
        scene e3s1a23
        with dissolve
        ruby "Then come help me out of my dress.."
        d "What?"
        scene e3s1a24
        with dissolve
        ruby "My dress. The zipper is stuck and I can't reach to get it open!"
        d "Oh... Okay!"
        ruby "Ahh"
        scene e3s1a25
        with dissolve
        ruby "Hummm...."
        scene e3s1a26
        with dissolve
        ruby "Ohhh..."
        scene e3s1a27
        with dissolve
        pause 1
        scene e3s1a28
        with dissolve
        pause 1 
        scene e3s1a29
        with dissolve
        ruby "Uhhhh"
        scene e3s1a30
        with dissolve
        pause 1 
        scene e3s1a31
        with dissolve
        ruby "Euh...."
        scene e3s1a32
        with dissolve
        ruby "Thank you."
        ruby "Go have a seat. I'll show you my favorites and you tell me which you like!"
        $ rubyhelp = True
        d "Sounds good to me!"
        scene black
        with fade
    else:
        scene e3s1a19
        with dissolve
        pause 1
        jump rubyshop2

label rubyshop2:
    scene black
    with dissolve
    pause 1
    ruby "What do you think?"
    with dissolve
    scene rubydress1_edited:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    d "Not bad, but I'm not sure if it's what you call chic and provocative."
    ruby "Yeah. You're probably right."
    scene black
    with dissolve
    pause 1
    with dissolve
    scene rubydress2_edited:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    d "Wow..."
    scene black
    with dissolve
    pause 1
    with dissolve
    scene rubydress3_edited:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    d "Stunning!"
    scene black
    with dissolve
    pause 1
    with dissolve
    scene rubydress4_edited:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    d "How is this possible? Everything looks good on you!"
    ruby "Which one do you prefer?"
    d "Honestly... I can't decide. You looking stunning in all of them!"
    ruby "Okay... then I'll choose, and you get to be surprised tomorrow night!"
    d "I like the sound of that!"
    scene black
    with fade
    pause 1
    jump mcshop

label redshop:
    scene e3s1a47
    with dissolve
    pause 1 
    scene e3s1a48
    with dissolve
    pause 1 
    scene e3s1a49 with vpunch
    with dissolve
    pause 1 
    scene e3s1a50
    with dissolve
    d "What the..."
    scene e3s1a51
    with dissolve
    beth "shhhhh"
    scene e3s1a52 with hpunch
    with dissolve
    pause 1 
    scene e3s1a53
    with dissolve
    pause 1 
    scene e3s1a54
    with dissolve
    ruby "What's happened?"
    scene e3s1a55
    with dissolve
    d "Nothing, I was just surprised by some of the outfits!"
    scene e3s1a56
    with dissolve
    pause 1 
    scene redhj2a
    with dissolve
    pause 1 
    scene redhj2b
    $ renpy.movie_cutscene("images/animation/redhj2.webm", stop_music=False)
    scene redhj2b
    ruby "Oh! Okay! You know you don't have to wear something weird. Just do you, but chic and provocative!"
    scene black
    with dissolve
    pause 1
    play movie "images/animation/redhj1.webm" loop volume(0)
    show movie with dissolve
    pause 2
    beth "I will have to take care of it if I want you to be fast..."
    pause 1 
    stop movie
    scene e3s1a56
    with dissolve
    beth "And I don't want you to trash my cabin... So..."
    scene e3s1a57
    play movie "images/animation/redbj24.webm" loop volume(0)
    show movie with dissolve
    d "Fuck, she goes deep!"
    ruby "What?"
    d "Hum... I said your thoughts are deep!"
    ruby "Oh... You think so?"
    stop movie
    play movie "images/animation/redbj22.webm" loop volume(0)
    show movie with dissolve
    d "I... I... can't..."
    ruby "Don't worry. You can share what you're thinking with me!"
    d "Share? You don't mind?"
    stop movie
    play movie "images/animation/redbj2.webm" loop volume(0)
    show movie with dissolve
    beth "Humhum..."
    ruby "Of course!"
    stop movie 
    scene e3s1a57
    with flash
    with hpunch
    d "Ahhhhhhh! It feels so good!"
    with flash
    with vpunch
    ruby "I didn't realize it would have this effect."
    d "I feel empty!"
    scene e3s1a58
    with dissolve
    ruby "That's the principle! Empty yourself to be relax! "
    d "You know nothing, Jon Snow."
    ruby "Hey! That's my phrase!"
    d "Well... I am happy with nothing!"
    stop music fadeout 2
    $ rubyhelp = False
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    pause 2
    play music "musique/Vexento_Now.mp3" volume 0.2
    jump rubyshop2

label mcshop:
    scene e3s1a33
    with dissolve
    ruby "And what about you?"
    scene e3s1a34
    with dissolve
    beth "Don't worry about him. I'll bring his outfit directly to the party! I know exactly what he needs!"
    scene e3s1a35
    with dissolve
    d "Uh... Are you sure?"
    scene e3s1a36
    with dissolve
    ruby "Ah, I love it! We can both be surprised!"
    d "I'm not sure that I..."
    scene e3s1a35
    with dissolve
    beth "Yes, yes! Trust me! Even Emerick won't look as good as you tomorrow night!"
    d "But what if..."
    scene e3s1a36
    with dissolve
    ruby "That works for me! We need to showcase my Cortex properly. He needs to be mesmerizing!"
    scene e3s1a35
    with dissolve
    beth "I promise, Ruby!"
    scene e3s1a37
    with dissolve
    ruby "Great! Well, I have to go. It's getting late, and I want to be well rested for tomorrow!"
    scene e3s1a38
    with dissolve
    ruby "[name], are you coming?"
    d "Hmm, I was planning on getting a bite to eat somewhere before heading back."
    ruby "Oh? Well, if you head down the block, there are a few restaurants."
    scene e3s1a39
    with dissolve
    d "Perfect! Thanks for the heads up."
    ruby "So, can I expect a text when you get home?"
    d "Uh... yeah, if you want..."
    scene e3s1a40
    with dissolve
    ruby "I know I sound a bit overprotective, but I don't like leaving people I care about alone at night."
    d "Oh? That's kind of you! You don't need to worry about me, I'll be fine."
    scene e3s1a41
    with dissolve
    ruby "Okay, then. I'll see you tomorrow!"
    d "See you tomorrow!"
    scene black
    with fade
    pause 1 
    scene e3s1a39
    with dissolve
    d "You don't have a suit for me, do you?"
    if Redpath == True:
        scene e3s1a42
        with dissolve
        beth "Of course, I do. I'll bring it tomorrow!"
        d "Seriously?"
        scene e3s1a43
        with dissolve
        beth "Absolutely! I told you if you satisfied me, you would be rewarded."
        beth "You certainly did... giving me everything earlier."
        beth "So, we'll see each other tomorrow before the party, and I'll give it to you then."
        scene e3s1a45
        with dissolve
        d "Works for me! See you tomorrow, Elizabeth!"
        beth "See you tomorrow!"
        scene black
        with fade
        pause 1
        jump e3s2
    scene e3s1a44
    with dissolve
    beth "Of course not. Figure it out yourself."
    d "Are you serious?"
    beth "You don't know who you're up against, Frenchy. You'll understand soon."
    scene e3s1a45
    with dissolve
    d "Uh... okay. See you tomorrow, I suppose."
    beth "See you tomorrow."
    scene black
    with fade
    pause 1
    jump e3s2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
