label e3s2:
    stop music fadeout 2 
    pause 1
    play music "musique/Stellardrone-ToTheGreatBeyond.mp3" volume 0.2
    scene e3s21
    with dissolve
    dpense "This city is fairly large, actually."
    scene e3s26
    with dissolve
    pause 2
    scene e3s25
    with dissolve
    dpense "I could easily get lost."
    scene e3s22
    with dissolve
    dpense "I'm starting to get pretty hungry..."
    scene e3s23
    with dissolve
    pause 1
    scene e3s27 with hpunch
    with dissolve
    d "Fuckkkkk!!!"
    scene e3s28 with hpunch
    with dissolve
    with flash
    pause 1 
    scene e3s29 with vpunch
    with dissolve
    ji "[name]!"
    scene e3s210
    with dissolve
    ji "Watch out! I could have run you over!"
    d "Gabriella?"
    scene e3s211
    with dissolve
    gaby "Yes?"
    if Training == True:
        scene e3s212:
            xalign 0.0
            linear 5.0 yalign 0.9
            linear 3.0 yalign 0.0
            repeat 1
        d "When I mentioned that you should be proud of your body.."
        gaby "What are you implying?"
        d "Oh, it's nothing..."
    scene e3s213
    with dissolve
    gaby "What brings you here all alone?"
    d "Well, I was heading home..."
    scene e3s214
    with dissolve
    d "but I started getting pretty hungry, so I was looking for a place to get some food."
    scene e3s215
    with dissolve
    gaby "Oh... umm, there's a charming ice cream parlor around the corner, and they serve food."
    d "And you?"
    scene e3s216
    with dissolve
    gaby "What do you mean, me?"
    d "Where are you headed like this?"
    scene e3s217
    with dissolve
    gaby "Oh! Well, I'm meeting some friends at the pub a bit further down."
    gaby "Getting some fresh air. Trying to clear my mind."
    d "And having fun?"
    scene e3s218
    with dissolve
    gaby "What are you suggesting?"
    d "You often seem so serious. You should enjoy yourself more."
    d "Once again, ma'am, with all due respect, you have your entire life ahead of you."
    d "You should cherish it and allow yourself to live a little."
    scene e3s219
    with dissolve
    gaby "Easier said than done!"
    d "Maybe I could be of help."
    scene e3s220
    with dissolve
    gaby "Excuse me?"
    d "No, I mean... if you ever felt like experiencing something new, going out, exploring..."
    d "You could let me know, and I'd be more than willing to accompany you!"
    scene e3s221
    with dissolve
    gaby "I'll give it some thought."
    gaby "Well, I shouldn't keep my friends waiting..."
    gaby "Will you find your way?"
    scene e3s222
    with dissolve
    d "You mentioned it's at the end of this street, right? Around the corner?"
    gaby "Yes, that's correct."
    d "Well then, I'll go that way and see if I find that ice cream parlor."
    scene e3s223
    with dissolve
    gaby "Hmm... You're not familiar with the city, are you?"
    gaby "Here, take my number. If you ever encounter any trouble, don't hesitate to call me."
    gaby "Only in case of an emergency, alright?"
    d "Uh, yes... I understand."
    $ renpy.notify (_("NEW CONTACT ADDED"))
    $ Gabyphone = True
    scene e3s224
    with dissolve
    gaby "Oh, by the way, don't share it with anyone..."
    gaby "I trust you."
    d "It's a promise."
    scene e3s225
    with dissolve
    gaby "Alright, have a good evening, [name]."
    scene e3s226
    with dissolve
    dpense "You too, Gabriella."
    scene e3s227
    with dissolve
    dpense "Excellent! I got the teacher's number!!!"
    dpense "Ahahaha!"
    dpense "If Ruby only knew about this."
    scene e3s228
    with dissolve
    dpense "Alright, now to head to the corner of the street..."
    scene black
    with fade
    stop music fadeout 2
    pause 2
    play music "<from 86.0>musique/KaiEngel-TheRun.mp3" volume 0.2 fadein 10
    pause 2
    pause 1
    scene e3s2a1
    with fade
    pause 2
    scene e3s2a2
    with dissolve
    pause 2 
    scene e3s2a3
    with dissolve
    hec "Hey guys! The boss is out!"
    pause 1
    hec "Wanna dine and dash? It'll teach that jerk a lesson..."
    pause 1
    scene e3s2a4
    with dissolve
    "Yeah!"
    scene e3s2a6
    with dissolve
    pause 1 
    scene e3s2a5
    with dissolve
    "Ahahahah !"
    scene e3s2a7
    with dissolve
    julia "Hey!!!"
    julia "Come back here! You need to pay!"
    with hpunch
    scene e3s2a8
    with dissolve
    julia "Bastards!"
    pause 1
    scene e3s2a9
    with dissolve
    pause 1 
    scene e3s2a10
    with dissolve
    pause 1
    julia "Humpff..."
    scene e3s2a11
    with dissolve
    hec "Go away dirty slut!"
    scene e3s2a12
    with dissolve
    julia "Stop!"
    scene e3s2a13
    with dissolve
    with hpunch
    julia "You have to pay!"
    scene e3s2a14
    with vpunch
    hec "Let go of me Pinkie!"
    hec "You'll get what you deserve!"
    scene e3s2a15
    with dissolve
    pause 1 
    scene e3s2a16
    $ renpy.movie_cutscene("images/animation/juliachute.webm", stop_music=False)
    scene e3s2a16
    pause 1 
    scene e3s2a18
    with vpunch
    julia "Outch!"
    scene e3s2a19
    with dissolve
    hec "I told you to let us go Pinkie!"
    scene e3s2a20
    with dissolve
    hec "Isn't it enough?"
    scene e2s2a22
    with dissolve
    julia "Huh?"
    scene e2s2a23
    with dissolve
    julia "No! I..."
    scene e2s2a27
    with vpunch
    hec "Take that bitch!"
    scene e2s2a24
    with dissolve
    julia "Hiiiii!"
    stop music fadeout 2
    scene black
    with fade
    pause 1
    play sound "sound/coeur.wav" loop
    pause 3 
    scene e2s2a25
    with fade
    stop sound fadeout 1
    julia "Huh?"
    scene e2s2a26
    with dissolve
    julia "What the..."
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" volume 0.2
    pause 0.75 
    scene e2s2a28
    with hpunch
    hec "What are you?"
    scene e2s2a29
    with dissolve
    julia "[name]!"
    scene e2s2a30
    with dissolve
    d "What's wrong with you? Attacking a woman like that?"
    scene e2s2a31
    with dissolve
    hec "Let me go! It's none of your business!"
    scene e2s2a32
    with dissolve
    d "She's my friend, so it is my business."
    scene e2s2a33
    with dissolve
    hec "And what are you going to do, huh? I didn't touch her. If you hit me there will be witnesses. If you get in trouble with the cops..."
    scene e2s2a34
    with dissolve
    hec "You can say goodbye to university. Frenchie."
    scene e2s2a26
    with dissolve
    julia "Forget it, [name]... He's not worth the trouble."
    scene e2s2a35
    with dissolve
    hec "That's right. We'll see each other on the field, you hicks."
    hec "And then we'll see who hits harder."
    scene black
    with fade
    pause 1 
    scene e2s2a36
    with dissolve
    d "Are you okay?"
    scene e2s2a37
    with dissolve
    julia "Uh, yeah... You didn't have to get involved."
    d "I wasn't going to let him hit you either."
    scene e2s2a38
    with dissolve
    julia "Well, thanks..."
    scene black
    with fade
    scene e2s2a39
    with dissolve
    cha "Julia? Are you okay?"
    scene e2s2a40
    with dissolve
    cha "I saw the scene. My God."
    julia "Yes, yes, you don't need to worry."
    scene e2s2a41
    with dissolve
    cha "Thank you, young man, for helping her... Mister???"
    d "[name]."
    scene e2s2a42
    with dissolve
    cha "Thanks again, [name]. I shouldn't have left her alone to handle the evening shift."
    scene e2s2a43
    with dissolve
    cha "Let's go back to the shop."
    scene e2s2a44
    with dissolve
    pause 2 
    scene e2s2a45
    with dissolve
    ji "Interesting..."
    pause 2
    scene black
    with fade
    stop music fadeout 2
    pause 2
    play music "musique/NovaNoma-Gaia.mp3" volume 0.2
    scene e3s2fin1
    with fade
    d "You work here?"
    julia "Yes..."
    d "Why didn't you tell me?!"
    scene e3s2fin2
    with dissolve
    cha "Wait, let's go inside. It will do everyone good to have some hot chocolate..."
    scene e3s2fin3
    with dissolve
    cha "Handsome, strong, and brave! I understand why you were singing. If you don't make a move on him soon, I'll do it myself!"
    $ CharlottePath = False
    if JuliaPath == False:
        julia "Please, feel free."
        scene e3s2fin4
        with dissolve
        cha "Seriously?"
        julia "Yeah, he's all yours."
    if JuliaPath == True:
        julia "Do you think I should?"
        scene e3s2fin4
        with dissolve
        cha "A guy like that... Believe me, you won't find ten in the whole city. You should definitely make a move."
        scene e3s2fin5
        with dissolve
        julia "..."

    pause 1 
    scene black
    with fade
    scene e3s2fin6
    with fade
    cha "I'm really sorry, Julia. I came as fast as I could after I finished with the accounting, but it takes time."
    julia "It's not your fault."
    scene e3s2fin7
    with dissolve
    cha "Well, I won't let you open alone anymore."
    julia "You can't do anything about it. There will always be jerks who try not to pay or give us a hard time... Especially with these clothes."
    scene e3s2fin8
    with dissolve
    julia "Ouch!"
    d "Did you hurt yourself?"
    julia "I think I tweaked my back. It must be from when I fell earlier."
    scene e3s2fin9
    with dissolve
    cha "Listen, Julia. Take the rest of the evening off. Don't worry I'll pay you your whole shift and you let me know how you are doing Monday, okay?"
    julia "Uh, are you sure..."
    cha "Yes, of course! Go on!"
    if JuliaPath == True:
        scene e3s2fin10
        with dissolve
        julia "Well, see you tomorrow in class?"
        cha "Wait, you're not going to walk home alone after all that?"
        scene e3s2fin11
        with dissolve
        julia "Huh?"
        scene e3s2fin12
        with dissolve
        cha "[name]... Can you walk her home just in case those guys are still around? She's in pain too, the poor thing..."
        if persistent.patch_enabled == True:
            $ TEMP1 = e3s2c1
            $ TEMP2 = e3s2c2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
        menu:
            "Yes, of course.[TEMP1!t]":
                call buddy_increased from _call_buddy_increased_18
                d "Absolutely!"
                scene e3s2fin13
                with dissolve
                julia "Thanks, Charlotte, and thanks, [name]..."
                d "You're welcome, I couldn't just leave you like this."
                scene e3s2fin14
                with dissolve
                cha "Oh, Julia! Take care! At least I'm sure you're in good hands!"
                julia "Uh... yeah. See you on Monday!"
                pause 1
                scene black
                with fade
                pause 1
                jump e3s3
            "I'd rather not...[TEMP2!t]":
                scene e3s2fin8
                with dissolve
                call temperament_increased from _call_temperament_increased_18
                d "Sorry, Julia. It's been a long day and I just came here to eat. I just finished training, and..."
                julia "Oh... Yeah, sure, no problem."
                $ JuliaPath = False
    if JuliaPath == False:
        scene e3s2fin8
        with dissolve
        julia "Well, see you tomorrow in class?"
        d "Yeah! See you tomorrow!"
        julia "See you..."

    scene black
    with fade
    pause 1 
    scene e3s2fin15
    with fade
    cha "Well, good thing you were there."
    cha "Poor Julia..."
    d "Yeah."
    cha "And besides that. I've never seen you around here!"
    scene e3s2fin16
    with dissolve
    cha "I would've remembered someone like you!"
    d "I just arrived in the US. I'm from France."
    cha "Ah. Your first time in the States?"
    d "Yeah..."
    d "Well, thank you!"
    scene e3s2fin17
    with dissolve
    cha "Don't be shy! I don't bite! Well, maybe, if you ask nice..."
    d "It's just that I'm not quite comfortable talking to people here yet. It's nothing personal."
    scene e3s2fin18
    with dissolve
    cha "Yeah, I understand. Meeting so many different people and losing your bearings."
    d "Exactly. And what's happen with your glasses? Some times you wear them, some times you don't."
    cha "Oh? I only use them at work for reading and look more... Mature! But for a guy who doesn't talks to others..."
    scene e3s2fin19
    with dissolve
    cha "That didn't stop you from putting yourself in danger for a girl you've only known for a few days."
    d "Well... When you put it that way, it does sound a bit foolish. I just acted on instinct though."
    cha "Foolish? Maybe. I'd say it was impressive. It's not every day I see someone have the courage to intervene and defend a lady."
    cha "So it piques my curiosity."
    d "Oh, really?"
    scene e3s2fin20
    with dissolve
    cha "Of course! It makes me want to know more about you. Where you come from, what your life has been like, your journey..."
    d "It's not that interesting, you know."
    cha "To me, it is! You helped Julia, so you're a hero! You can relax with me!"
    d "Uh..."
    cha "Hey, I'm not sixty, you know! Do you think I look old?"
    if helpgabi == False:
        scene e3s2fin21
        with dissolve
        d "No disrespect but... You're not really my type. I prefer to leave it at that."
        cha "Huh?"
        d "Thanks again for the hot chocolate."
        scene e3s2fin22
        with dissolve
        cha "Um... okay."
        cha "What a strange boy."
        $ CharlottePath = False
        scene black
        with fade
        pause 1
        jump e3s4
    if helpgabi == True:
        d "Old? No way! Age doesn't really matter anyways, does it?"
        cha "Go on, tell me more..."
        scene e3s2fin23
        with dissolve
        d "If I were to go out with an older woman, either as friends or maybe more, I think I would be proud to have you at my side. So I don't think age matters here."
        cha "Proud?"
        scene e3s2fin24
        with dissolve
        d "Yeah! Having an active woman who runs her own business,"
        scene e3s2fin26
        with dissolve
        d "an attractive woman to explore the city with,"
        scene e3s2fin25
        with dissolve
        d "an experienced woman with whom I can explore many possibilities..."
        scene e3s2fin27 with hpunch
        with dissolve
        cha "Okay, okay, I get it..."
        cha "Listen, it's getting late. I have work to do."
        cha "Are you going to the party tomorrow night?"
        d "Yes."
        cha "Then stop by before you go. I'll be here all afternoon doing inventory."
        if persistent.patch_enabled == True:
            $ TEMP1 = e3s2bc1
            $ TEMP2 = e3s2bc2
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
        menu:
            "Okay, I'll stop in.[TEMP1!t]":
                cha "Perfect. So, see you tomorrow?"
                scene e3s2fin22
                with dissolve
                d "See you then, Charlotte."
                cha "See you, [name]."
                scene black
                with fade
                pause 1
                $ CharlottePath = True
                jump e3s4
            "Uh... no, thanks![TEMP2!t]":
                scene e3s2fin21
                with dissolve
                d "No disrespect but... you're not really my type. I prefer to leave it at that."
                cha "Huh?"
                d "Thanks again for the hot chocolate..."
                scene e3s2fin22
                with dissolve
                cha "Um, okay."
                cha "What a strange boy..."
                scene black
                with fade
                pause 1
                $ CharlottePath = False
                jump e3s4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
