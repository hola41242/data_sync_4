label e3s4:
    scene d1
    with fade
    d "Okay."
    d "I promised Ruby I would message her when I get back home."
    scene d2
    with dissolve
    pause 1
    phone discussion "ruby2":
        time year 2023 month 9 day 3 hour 23 minute 00
        "d" "Minus... you awake?"
        "ruby" "Of course! I was worried about you!"
        "d" "You're so sweet!"
        "ruby" "?"
        "ruby" "You think so?"
        "d" "Absolutely! I couldn't ask for a better friend!"
        "ruby" "I know I'm the B.E.S.T !"
        "d" "Ahah! For sure! So... I'm back in my room."
        "ruby" "Great! I'm relieved!"
        "d" "Good night, my acolyte!"
        "ruby" "Sweet dreams, my partner!"
    phone end discussion
    pause 1 
    d "???" with hpunch
    d "Another message?"
    call phone_discussion_ji from _call_phone_discussion_ji
    d "No response..."
    d "Finally... I can get some rest. Something tells me that tomorrow will not be an average day."
    scene black
    with fade
    pause 1
    dpense "Let the surprises come. After all, it's in the unexpected that the true adventure lies."
    stop music fadeout 2
    pause 2
    $ Achievement.add(achievement_episode2)
    $ achievement.grant("episode2")
    $ achievement.sync()
    pause 1
    jump ep3intro
    with fade
    show text _ ("SAVE NOW") at truecenter
    pause 5
    with dissolve
    hide text
    pause 3
    jump ep3intro
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
