label epreuvetab:
    scene black
    pause 1
    hide screen gameUIBEST
    scene interfacetablet
    with fade
    pause 1

    $ originalrank = Rank
    image antique = "antique.jpg"
    image reines = "reines.jpg"
    image ecrivain = "ecrivain.jpg"
    image chiffres = "chiffres.jpg"
    image explorateur = "explorateur.jpg"
    image australie = "australie.jpg"
    image lara2 = "lara2.jpg"
    image encre = "encre.jpg"
    image points = "points.jpg"
    image interro = "interro.jpg"

    image tablet_text = ParameterizedText(xalign=0.65, yalign=0.20, outlines = [ (2, "#291897d8") ])
    image aprestablet_text = ParameterizedText(size = +100,xalign=0.5, yalign=0.5, outlines = [ (2, "#291897d8") ])
    image tablet_name = ParameterizedText(xalign=0.10, yalign=0.07,size=+80, outlines = [ (2, "#291897d8") ])
    image tablet_rank = ParameterizedText(xalign=0.17, yalign=0.24,size=+80, outlines = [ (2, "#291897d8") ])

    transform alpha_dissolve:
        alpha 0.0
        linear 0.5 alpha 1.0
        on hide:
            linear 0.5 alpha 0

    show tablet_name "[name]"
    show tablet_rank "[Rank]"
    pause 2

    init:
        $ timer_range = 180
        $ timer = 180
        $ timer_jump = 'timer_end'

    screen countdown:
        timer 0.01 repeat True action If(timer > 0, true=SetVariable('timer', timer - 0.01), false=[Hide('countdown'), Jump(timer_jump)])

        bar value timer range timer_range xalign 0.5 yalign 0.05 xmaximum 500 at alpha_dissolve

    $ questions = [
        {
            "question": _("What is the only Wonder of the ancient world still visible?"),
        },
        {
            "question": _("In a traditional deck of cards,""\nwhich queen holds her scepter with both hands?"),
        },
        {
            "question": _("Who wrote '1984'?"),
        },
        {
            "question": _("What is the missing number?""\n16 06 68 88 ?? 98"),
        },
        {
            "question": _("What was the name of the first widely available web browser?"),
        },
        {
            "question": _("What is the capital of Australia?"),
        },
        {
            "question": _("Who is hidden behind this image?"),
        },
        {
            "question": _("If you mix red and blue,""\nwhat color do you get?"),
        },
        {
            "question": _("Press the POINT"),
        },
        {
            "question": _("The answer is obvious"),
        },
    ]



    show screen countdown
    $ config.rollback_enabled = False

    $ renpy.block_rollback()
    $ question_number = 0
    $ score = 0
    jump epreuve2


label question0:
    show tablet_text (q['question'])
    show antique:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "The Colossus of Rhodes":
            $ question_number += 1
        "The Great Pyramid of Giza[TEMP1!t]":

            $ score += 1
            $ question_number += 1
        "The Lighthouse of Alexandria":

            $ question_number += 1
        "The Temple of Artemis":

            $ question_number += 1


    hide tablet_text
    hide antique
    pause 1
    jump epreuve2


label question1:
    show tablet_text (q['question'])
    show reines:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "The Queen of Clubs[TEMP1!t]":
            $ question_number += 1
            $ score += 1
        "The Queen of Spades":

            $ question_number += 1
        "The Queen of Hearts":

            $ question_number += 1
        "The Queen of Diamonds":

            $ question_number += 1

    hide tablet_text
    hide reines
    pause 1
    jump epreuve2

label question2:
    show tablet_text (q['question'])
    show ecrivain:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "J. R. R. Tolkien":
            $ question_number += 1
        "George R. R. Martin":

            $ question_number += 1
        "George Orwell[TEMP1!t]":

            $ score += 1
            $ question_number += 1
        "Stephen King":

            $ question_number += 1

    hide tablet_text
    hide ecrivain
    pause 1
    jump epreuve2

label question3:
    show tablet_text (q['question'])
    show screen pass()
    show chiffres:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    if bonuseduca == True:
        show screen bonuseduc()
    $ reponse3 = renpy.input(q['question'], allow="1234567890")
    if reponse3 == "78" or "87":
        $ score += 1
        $ question_number += 1
    else:
        $ question_number += 1

    hide tablet_text
    hide chiffres
    pause 1
    jump epreuve2

label question4:
    show tablet_text (q['question'])
    show explorateur:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "Internet Explorer":
            $ question_number += 1
        "Mosaic[TEMP1!t]":

            $ score += 1
            $ question_number += 1
        "Netscape Navigator":

            $ question_number += 1
        "Google Chrome":

            $ question_number += 1

    hide tablet_text
    hide explorateur
    pause 1
    jump epreuve2

label question5:
    show tablet_text (q['question'])
    show australie:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "Canberra[TEMP1!t]":
            $ score += 1
            $ question_number += 1
        "Sydney":

            $ question_number += 1
        "Melbourne":

            $ question_number += 1
        "Perth":

            $ question_number += 1

    hide tablet_text
    hide australie
    pause 1
    jump epreuve2

label question6:
    show tablet_text (q['question'])
    show lara2:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "Mona Lisa":
            $ question_number += 1
        "Aya Brea":

            $ question_number += 1
        "Lara Croft[TEMP1!t]":

            $ score += 1
            $ question_number += 1
        "Katniss Everdeen":

            $ question_number += 1

    hide tablet_text
    hide lara2
    pause 1
    jump epreuve2

label question7:
    show tablet_text (q['question'])
    show encre:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    menu:
        "Violet[TEMP1!t]":
            $ question_number += 1
            $ score += 1
        "Orange":


            $ question_number += 1
        "Green":


            $ question_number += 1
        "Pink":

            $ question_number += 1

    hide tablet_text
    hide encre
    pause 1
    jump epreuve2

label question8:
    show screen point()
    show tablet_text (q['question'])
    show points:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    show screen pass() 
    if bonuseduca == True:
        show screen bonuseduc() 
    $ renpy.pause(180.0, hard=True)
    if point == True:
        $ question_number += 1
        $ score += 1
        hide tablet_text
        hide points
        pause 1
        jump epreuve2
    else:
        hide screen point
        hide points
        $ question_number += 1
        jump epreuve2

label passeepreuve:
    $ question_number += 1
    hide screen pass
    hide screen point 
    hide points
    hide chiffres
    hide interro

    jump epreuve2


label point:
    $ point = True
    hide screen point
    return


label question9:
    show screen pass()
    show tablet_text (q['question'])
    show interro:
        xsize 0.60
        ysize 0.60
        xpos 0.33
        ypos 0.30
    if bonuseduca == True:
        show screen bonuseduc()
    $ reponse9 = renpy.input(q['question'], allow="顯而易見显而易见óabcdefghijklmnopqrstuvwxyzéàèçабвгдежзиклмнопрстуфхчщшьъэюя !?")
    if reponse9 == "obvious" or reponse9 == "evidente" or reponse9 == "вопрос" or reponse9 == "óbvia" or reponse9 == "obvia" or reponse9 == "ovvia" or reponse9 == "显而易见" or reponse9 == "顯而易見" or reponse9 == "明白":
        $ score += 1
        $ question_number += 1
    else:
        $ question_number += 1
    hide interro
    hide tablet_text
    pause 1
    jump epreuve2






label epreuve2:
    hide screen pass 
    hide screen bonuseduc   
    while question_number < len(questions) and timer > 0:
        $ renpy.block_rollback()
        $ q = questions[question_number]
        if question_number == 0:
            jump question0
        if question_number == 1:
            jump question1
        if question_number == 2:
            jump question2
        if question_number == 3:
            jump question3
        if question_number == 4:
            jump question4
        if question_number == 5:
            jump question5
        if question_number == 6:
            jump question6
        if question_number == 7:
            jump question7
        if question_number == 8:
            jump question8
        if question_number == 9:
            jump question9


label timer_good:
    $ renpy.block_rollback()
    hide screen countdown   
    show tablet_text _ ("You finished on time! Your score is [score] / 10.")
    pause 2
    jump reconfigepreuve

label timer_end:
    $ renpy.block_rollback()
    hide lara
    hide encre
    hide interro
    hide points
    hide screen pass
    hide screen point
    hide screen countdown
    show tablet_text _ ("You did not finish on time. Your score is [score] / 10.")
    pause 2
    jump reconfigepreuve



label reconfigepreuve:
    $ config.rollback_enabled = True

    scene black
    with fade
    if score > 5:
        $ Rank = Rank/2
    if score < 5:
        $ Rank = int(Rank+10)

    show aprestablet_text _ ("Your new rank is :")
    with fade
    pause 2
    if Rank%2 == 0:
        $ Rank = Rank
    else:
        $ Rank = int(Rank+0.5)
    python:
        Rank = math.ceil(Rank)
    hide aprestablet_text
    with fade
    pause 1
    show aprestablet_text "[Rank]" with fade
    pause 3
    hide aprestablet_text
    with fade
    pause 2
    jump postepreuve
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
