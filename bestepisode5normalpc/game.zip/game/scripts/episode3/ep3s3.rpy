label ep3s3:
    scene black
    with fade
    pause 1 
    show text _ ("10:30 AM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/FRR0010-FunkMe-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s3r1
    with fade
    dpense "Another day... another class..."
    dpense "They're all here."
    scene ep3s3r2
    with dissolve
    dpense "Blue seems a little bit... different today."
    scene ep3s3r3:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    dpense "Is she waiting for me?"
    dpense "She isn't wearing her blue makeup."
    scene ep3s3r4
    with dissolve
    dpense "The girls all look pretty today."
    dpense "Even Madison, with her new haircut."
    dpense "What's with all the haircuts lately?"
    scene e3s3r5
    with dissolve
    dpense "Red is with Steven..."
    dpense "Probably plotting against someone..."
    scene ep3s3r5
    with dissolve
    dpense "Those two together..."
    dpense "I'll try to avoid them..."
    dpense "I really don't need any trouble inside the Academy..."
    if Redpath == True:
        scene ep3s3r8
        with dissolve
        beth "Hey, handsome!"
        d "Hmm?"
        beth "Listen, there's going to be a challenge during the next class."
        d "How do you know?"
        beth "Never mind that. Just remember, it's going to involve some questions."
        beth "For the answers, never choose answer D..."
        d "Huh?"
        scene ep3s3r9
        with dissolve
        beth "A, B, C, D... Never D! Do you understand?"
        d "But how do you know this?"
        beth "Just trust me, that's all!"
        d "Okay..."
    if Bluepath == False:
        $ BlueRelation = False
    if BlueRelation == True:
        scene ep3s3r6
        with dissolve
        sofia "I can help you with the next test."
        d "How so?"
        sofia "There, during the class, there's going to be a test at the end."
        d "A test?"
        sofia "Yes. Anyway, there'll be a question where you need to find the point in the image."
        d "Uh... Okay."
        scene ep3s3r7
        with dissolve
        sofia "Click on the dot in the question."
        d "What do you mean click on the dot?"
        sofia "Gosh, you're slow!"
        sofia "Anyway, when you have the question about points, don't look at the image, just press on the dot, that's it."
        d "Alright, I'll try."
        sofia "You need to succeed. And I'll do everything to help."
        d "Uh... Thank you?"
        sofia "See you later."
    scene ep3s3r10
    with dissolve
    pause 2
    gaby "Good morning, everyone."
    scene ep3s3r11:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    gaby "Please sit one per table, please!"
    pause 1
    d "Okay."
    scene ep3s3r12
    with dissolve
    pause 2
    scene ep3s3r13
    with dissolve
    pause 2
    scene ep3s3r14
    with dissolve
    pause 2
    scene ep3s3r15
    with dissolve
    pause 2
    scene ep3s3r16
    with dissolve
    gaby "Today we are going to talk a bit about commerce, particularly its origins."
    gaby "What do you think is one of the earliest forms of commerce?"
    $ GabyProf = 0
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3s3c1
    else:
        $ TEMP1 = ""
    menu:
        "The appearance of money?":
            d "The arrival of money?"
            scene ep3s3r19
            with dissolve
            gaby "Hmm, it's a good idea but it's still too recent."
            gaby "Money and the associated economy were rather established by the Romans with their markets."
            jump suitecourseco0
        "Gifts?":
            d "Gifts between tribes?"
            scene ep3s3r19
            with dissolve
            gaby "Well, that's not a bad answer, but the concept of commerce implies an exchange."
            gaby "Even though gifts were often used during rituals to obtain protection, divine or strategic among tribes."
            gaby "It wasn't quite what one might call commerce."
            jump suitecourseco0
        "Barter?[TEMP1!t]":
            d "Barter?"
            scene ep3s3r17
            with dissolve
            gaby "That's an excellent answer!"
            $ GabyProf += 1
            call education_increased from _call_education_increased_12
            gaby "Barter was a means of exchange for many tribes beginning to settle in villages during their sedentarization."
            gaby "It established notions of value, quantity, and ownership."
            gaby "All these concepts are still relevant today, notably found in the stock market with the value of a share, the number of shares, and the owners of these shares."
            jump suitecourseco
        "Prostitution?":
            d "Prostitution?"
            scene ep3s3r18
            with dissolve
            gaby "What?"
            d "Well, using one's body to earn money!"
            gaby "Oh!"
            gaby "I hadn't thought of that at all. But it could indeed have been correct, except that prostitution as we know it only appeared much later."
            gaby "With the emergence of money, civilizations, and communal life."
            gaby "Previously, such relations were rather... bestial and dictated by instincts and the tribe."
            jump suitecourseco0

label suitecourseco0:
    scene ep3s3r20
    with dissolve
    gaby "No, it was barter."
    gaby "Barter was for many tribes beginning to settle in villages during their sedentarization a means of exchange."
    gaby "It established notions of value, quantity, and ownership."
    gaby "All these concepts are still relevant today, notably found in the stock market with the value of a share, the number of shares, and the owners of these shares."

label suitecourseco:
    $ GabyPath = False
    scene ep3s3r21
    with dissolve
    gaby "So you see, it is in the past that we find the bases of what we have today."
    scene ep3s3r22
    with dissolve
    gaby "Knowing the origins of something to understand its workings or its effects is often the best way to learn and evolve."
    scene ep3s3r23
    with dissolve
    gaby "On this subject, there is an exhibition at the museum tomorrow on the Jurassic and life in the Neolithic."

    if persistent.patch_enabled == True:
        $ TEMP1 = ep3s3c2
        $ TEMP2 = ep3s3c3
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    if GabyProf == 1:
        scene ep3s3r26
        with dissolve
        gaby "[name], since you gave the right answer, would you like to accompany me to this exhibition?"
        scene ep3s3r27
        with dissolve
        pause 1
        menu:
            "Yes[TEMP1!t]":
                d "I would be delighted!"
                $ GabyPath = True
                scene ep3s3r28
                with dissolve
                pause 2
                gaby "Perfect. Come see me at the end of the class."
                d "Okay, ma'am."
                jump preepreuve
            "No[TEMP2!t]":

                d "Ah no I'm sorry, but I already have plans tomorrow."
                $ GabyPath = False
                scene ep3s3r29
                with dissolve
                pause 2
                gaby "Oh? Anyone else?"
                scene ep3s3r23
                with dissolve
                pause 2
                ji "Me, ma'am!"
                gaby "Very well..."
                jump preepreuve

    scene ep3s3r23
    with dissolve
    gaby "Does anyone want to accompany me?"
    ji "Me, ma'am!" with hpunch
    ji "I would like to as well!" with hpunch
    if helpgabi == True:
        scene ep3s3r24
        with dissolve
        pause 2
        scene ep3s3r25
        with dissolve
        pause 2
        ruby "madam! Don't you think it would be interesting for our newly arrived student from France to see new places in a city he doesn't know?"
        ruby "After all, how can you know a city without knowing its origins, and what better place than a museum could show him that?"
        ruby "That's what you just said, right?"
        gaby "You're right!"
        scene ep3s3r30
        with dissolve
        pause 0.5
        scene ep3s3r31
        with dissolve
        pause 0.5
        scene ep3s3r30
        with dissolve
        pause 1
        gaby "[name], would you like to accompany me to this exhibition?"
        scene ep3s3r27
        with dissolve
        pause 1
        menu:
            "Yes[TEMP1!t]":
                d "I would be delighted!"
                $ GabyPath = True
                scene ep3s3r28
                with dissolve
                pause 2
                gaby "Perfect. Come see me at the end of the class."
                d "Okay, ma'am."
                jump preepreuve
            "No[TEMP2!t]":

                d "Ah no I'm sorry, but I already have plans tomorrow."
                $ GabyPath = False
                scene ep3s3r29
                with dissolve
                pause 2
                gaby "Oh? Anyone else?"
                scene ep3s3r23
                with dissolve
                pause 2
                ji "Me, ma'am!"
                gaby "Very well..."
                jump preepreuve

    gaby "Very well, come see me after the class."
    scene black
    with fade
    pause 1
    jump preepreuve

label preepreuve:
    scene ep3s3r16
    with dissolve
    pause 2
    gaby "So we have seen that..."
    scene e2s445
    with hpunch
    stop music fadeout 2
    drew "To all participants of the B.E.S.T!"
    play music "musique/MAK0079-TheHero39sQuest-stockmusic-net.mp3" volume 0.2 fadein 2
    drew "You will receive a tablet on which you will have to answer questions."
    drew "These questions will allow us to assess your logic, your sense of deduction, and your general knowledge."
    drew "Being the B.E.S.T means having a sharp mind for the challenges around us."
    drew "You will therefore have 3 minutes at the start of the test to answer the ten questions that will be posed to you."
    scene ep3tabletava
    with dissolve
    drew "You can skip a question if you don't know the answer."
    drew "Not answering a question does not mean elimination."
    drew "However, your total score will be evaluated and the last ten students in the ranking will be eliminated."
    scene ep3tabletavant
    with dissolve
    drew "I repeat, you have three minutes to answer the ten questions."
    drew "You can skip questions, but your score will be evaluated at the end and the last ten will be eliminated."
    drew "Good luck to all."
    scene black
    $ renpy.movie_cutscene("images/animation/tablet.webm", stop_music=False)
    pause 1 
    "If you want, you can skip this quiz with the minimal score needed to continue the adventure."
    "Please note that you won't obtain better rank or extra points."
    $ renpy.take_screenshot()
    $ renpy.save("9-1", "PRETRIAL")
    "A save has been made in slot 9-1 to backup."
    menu:
        "Do you want to skip the quiz?"
        "Yes":
            $ score = 5
            if Rank>40:
                $ Rank = 40
            jump postepreuve
        "No":
            pass
    pause 1
    $ bonuseduca = False
    if Education > 7:
        $ bonuseduca = True
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3s3c1
    else:
        $ TEMP1 = ""
    jump epreuvetab

label postepreuve:
    if score == 10:
        $ Achievement.add(achievement_quizzpro)
        $ achievement.grant("quizzpro")
        $ achievement.sync()
        call education_increased from _call_education_increased_13
    if Rank > 40:
        jump gameover
    $ config.rollback_enabled = True
    show screen gameUIBEST
    scene ep3tabletavant
    with fade
    gaby "You can put away your tablet."
    gaby "That concludes our class for today."
    if GabyPath == True:
        scene ep3s3r17
        with dissolve
        gaby "[name], could you stay with me for a couple of minutes?"
        d "Sure!"
        jump gabimusee1
    else:
        gaby "Have a good day everyone!"
        $ gabimusee = False
        scene black
        with fade
        jump afterepreuve

label gabimusee1:
    scene ep3s3r32
    with dissolve
    gaby "Tomorrow I will wait for you at the museum around 2PM. Does that work for you?"
    scene ep3s3r33
    with dissolve
    gaby "I know you have a party tonight, so I don't expect you to be up early."
    d "That works for me!"
    gaby "I hope you'll enjoy the visit."
    d "Don't worry, as long as I'm with you, I'd be happy anywhere in the world."
    scene ep3s3r34
    with dissolve
    gaby "That's a bit cheesy... Don't get ahead of yourself, young man."
    gaby "This is just a visit, not a date."
    d "And why can't it be both?"
    scene ep3s3r35
    with dissolve
    with vpunch
    gaby "What? No!"
    scene ep3s3r36
    with dissolve
    d "Haha! See you tomorrow, my lady!"
    scene ep3s3r37
    with dissolve
    gaby "My lady?"
    scene ep3s3r38
    with dissolve
    pause 1 
    scene ep3s3r39
    with dissolve
    gaby "..."
    $ gabimusee = True
    scene black
    with fade
    pause 1
    jump afterepreuve

label afterepreuve:
    stop music fadeout 2
    pause 1 
    play music "musique/ARS0038-BackToLife-stockmusic-net.mp3" volume 0.2 fadein 2

    scene ep3s3r40
    with fade
    d "So, ladies, how'd it go?"
    mad "Smooth, it was pretty easy."
    scene ep3s3r41
    with dissolve
    ruby "Yeah, not bad!"
    grace "I struggled with a few questions though."
    scene ep3s3r42
    with dissolve
    mad "What ranks did you guys end up in?"
    ruby "I got 13th!"
    grace "31st for me..."
    mad "I'm 2nd... Guess who's first..."
    scene ep3s3r43
    with dissolve
    d "Hum?"
    scene ep3s3r44
    with dissolve
    pause 1
    scene ep3s3r45
    with dissolve
    with hpunch
    emerick "Who's the B.E.S.T ?"
    "You!"
    grace "Emerick..."
    scene ep3s3r46
    with dissolve
    grace "And you, [name]?"
    d "I'm in place [Rank]."
    grace "Great!"
    if Gracepath == True:
        scene ep3s3r47
        with dissolve
        pause 1 
        scene ep3s3r48
        with dissolve
        pause 1
    scene ep3s3r49
    with dissolve
    with hpunch
    ruby "Julia got excused, I think she's ranked 15th..."
    mad "Excused?"
    mad "Right, she wasn’t around today."
    ruby "Yeah, I heard Mrs. Drew talking about some assault earlier."
    d "I was there last night..."
    scene ep3s3r50
    with dissolve
    grace "What?"
    d "On my way home last night, I came across Hector and his crew assaulting Julia."
    grace "Seriously?"
    scene ep3s3r51
    with dissolve
    grace "That jerk!"
    d "When I stepped in, they took off, but her back was in some pain."
    ruby "Hmm... That explains it."
    scene ep3s3r52
    with dissolve
    ruby "Brrrrrrrrr... If I were stronger, I'd grab 'em down below and turn them into mush."
    scene ep3s3r53
    with dissolve
    with hpunch
    ruby "I'd start by squashing them into a paste..."
    ruby "Then I'd grind them up until they burst..."
    scene ep3s3r54
    with dissolve
    with hpunch
    ruby "I'd slice them into pieces and toss 'em in the blender..."
    ruby "I..."
    d "Ruby?"
    d "Aren't you getting a bit carried away?"
    scene ep3s3r55
    with dissolve
    with hpunch
    ruby "Oh? Yeah... Sorry..."
    mad "Don't worry, we're gonna crush them on the field!"
    ruby "What?"
    scene ep3s3r56
    with dissolve
    mad "The draw's been made... They're our next opponents..."
    ruby "Oh?"
    ruby "Okay!"
    ruby "Well... We've got work to do for tonight!"
    scene ep3s3r57
    with dissolve
    ruby "Ready to head out, Grace?"
    grace "Right behind you."
    mad "I've got my daughter this afternoon, I'll catch up with you tonight."
    grace "No worries."
    ruby "So... See you tonight?"
    mad "See you!"
    scene ep3s3r58
    with dissolve
    d "Later!"
    dpense "Still got some time before tonight."
    dpense "I could keep training, or..."
    dpense "Maybe just chill a bit before tonight. It’s gonna be quite the evening!"
    $ Training2 = False
    scene black
    with fade
    pause 1
    jump ep3s4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
