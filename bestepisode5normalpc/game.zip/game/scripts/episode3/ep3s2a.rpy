label ep3s2a:

    show text _ ("9:00 AM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/VED0018-Smiles-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s2ar1
    with fade
    ruby "Where could it possibly be? I was sure I left them right here..."
    scene ep3s2ar2
    with dissolve
    ruby "Ugh, it’s nowhere to be found! Come on, it's not like I would have used them... No, that can't be right..."
    scene ep3s2ar3
    with dissolve
    d "Looking for something in particular? Need a hand?"
    scene ep3s2ar4
    with dissolve
    ruby "Oh, uh... No, well yes... It’s just that, you know, I had plans and... they’ve vanished."
    scene ep3s2ar5
    with dissolve
    d "Want me to help you look for them?"
    scene ep3s2ar6
    with dissolve
    ruby "No, let's drop it. If I keep searching, I'll be late. We can’t keep the day waiting."
    scene ep3s2ar7
    with dissolve
    ruby "I haven’t even had breakfast yet... Today's going to be a marathon."
    scene ep3s2ar8
    with dissolve
    ruby "Especially with everything I’ve got to set up for tonight. Nothing's ready, absolutely nothing!"
    d "What have you got planned, exactly?"
    scene ep3s2ar9
    with dissolve
    ruby "It’s a surprise!"
    d "Okay, okay! Guess I'll see tonight then!"
    scene ep3s2ar10
    with dissolve
    ruby "Exactly! Well, shall we get going then?"
    d "You're not forgetting anything?"
    scene ep3s2ar11
    with dissolve
    ruby "Huh?"
    scene ep3s2ar12
    with dissolve
    ruby "Oh... OH!"
    ruby "I even forgot to get dressed!"
    scene ep3s2ar13
    with dissolve
    ruby "You know what, give me two minutes and we will swing by the cafeteria! Grab a quick breakfast."
    d "Sounds good to me."
    scene black
    with fade
    pause 1
    show text _ ("Ten minutes later...") at truecenter
    pause 2
    with dissolve
    dpense "Didn't she say two minutes?"
    pause 2
    hide text
    pause 1
    ruby "Okay, I'm ready!"
    scene ep3s2ar14
    with fade
    pause 1 
    scene ep3s2ar15
    $ renpy.movie_cutscene("images/animation/rubyep3.webm", stop_music=False)
    scene ep3s2ar15
    with dissolve
    pause 1
    ruby "Let's hit it!"
    pause 1
    scene black
    with fade
    pause 1

    show text _ ("9:30 AM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    scene cafet1
    with fade
    pause 2
    scene cafet2
    with dissolve
    pause 2 
    scene cafet3
    with dissolve
    with vpunch
    ruby "Ah, that hits the spot!"
    scene cafet4
    with dissolve
    d "Yeah, a good fruit juice in the morning, and we're set for a great day!"
    scene cafet5
    with dissolve
    ruby "Great day, great day... We've got class in a few minutes, then I need to head back home to grab everything I've prepared for the party."
    ruby "And then, this afternoon, I still need to set up the games for tonight and get dressed!"
    d "So, which dress are you thinking of wearing?"
    scene cafet6
    with dissolve
    ruby "You'll see! I told you, you should have chosen!"
    d "Any hints on the games you’ve got planned?"
    scene cafet7
    with dissolve
    ruby "Uh... No, that would be cheating!"
    scene cafet8
    with dissolve
    ruby "But don’t worry, you won’t be bored!"
    d "I can't wait to see it!"
    ruby "Well, guess we should head to class then."
    scene cafet9
    with dissolve
    ruby "I hope Gabriella is in a good mood!"
    d "Oh, I didn’t tell you!"
    scene cafet10
    with dissolve
    ruby "What?"
    d "I ran into her last night on her motorcycle!"
    scene cafet11
    with dissolve
    ruby "She has a motorcycle?"
    d "Yeah! She almost ran me over because I wasn’t paying attention..."
    scene cafet12
    with dissolve
    ruby "And then?"
    d "Well, I ended up getting her number!"
    scene cafet13
    with dissolve
    ruby "No way!"
    d "I swear!"
    scene cafet14
    with dissolve
    ruby "I told you! Even fate is trying to set you up with her!"
    d "Oh, come on, that’s ridiculous!"
    scene cafet12
    with dissolve
    ruby "Well, it's just a contact for now, but it's progress!"
    ruby "I should become Cupid. I think I have a knack for it!"
    d "You're getting ahead of yourself there."
    ruby "Uh... Yeah, we'll see!"
    scene cafet15
    with dissolve
    ruby "Still, I can't wait to see what happens next with her!"
    d "You're relentless, you know that? There's no next step, there isn’t even a first step."
    ruby "Yeah, yeah, that's what you say..."
    ruby "But you have the phone number of your Milf!"
    d "Ruby..."
    stop music fadeout 2.0
    scene black
    with fade
    pause 1
    $ rubymorning = True
    jump ep3s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
