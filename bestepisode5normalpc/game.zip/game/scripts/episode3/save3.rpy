label save3:
    pause 2
    with fade
    stop music fadeout 2.0
    with fade
    show text _ ("SAVE NOW") at truecenter
    "Please save your game here..."
    pause 3
    with dissolve
    hide text
    pause 1
    jump coming3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
