label ep3s1:
    show text _ ("8:30 AM") at truecenter
    pause 2
    with dissolve
    pause 2
    hide text
    pause 1
    scene ep3s1r1
    with fade
    pause 1
    scene ep3s1r2
    with dissolve
    pause 1
    dpense "Hmm... What a refreshing night's sleep. Today's looking busy, but I'm up for it."
    scene ep3s1r3
    with dissolve
    dpense "There’s that big party tonight. I've got to make a good impression. There'll be folks I've never met, and of course, the girls will be there."
    scene ep3s1r4
    with dissolve
    dpense "It’s going to be one for the books."
    dpense "I'm gonna check in on Julia. Hope she's doing okay."
    dpense "After what she went through yesterday. She must not be feeling great today."
    call phone_discussion_julia from _call_phone_discussion_julia
    dpense "It's not surprising that she stays at home a little."
    scene ep3s1r5
    with dissolve
    dpense "Now... Focus on the day ahead!"
    scene ep3s1r6
    with dissolve
    pause 1
    if cinema == True:
        scene ep3s1r7
        with dissolve
        dpense "Ruby's handling all the arrangements. Maybe I should swing by her place for breakfast before class? She'll need the energy!"
    if madipath == True:
        scene ep3s1r8
        with dissolve
        dpense "There’s the tournament on Monday. I’m not quite where I want to be yet... Maybe I should hit the gym before classes start?"
    if Gracepath == True:
        scene ep3s1r9
        with dissolve
        dpense "Should I go to pick up Grace? After yesterday... I think we need to talk."
    scene ep3s1r9
    with dissolve
    dpense "Alright, whatever comes my way, I’m ready."
    $ madidiner = False
    $ rubymorning = False
    $ Madisonphone = False
    scene black
    with fade
    pause 1
    stop music fadeout 2.0
    call screen choixep3s2()
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
