label ep3s4:
    stop music fadeout 2
    call screen choixep3s4()

label Training2:
    scene black
    with fade
    pause 1
    show text _ ("14:30") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/FB07-SportActionTrailer-Chursin.mp3" volume 0.2 fadein 2
    scene ep3s4r1
    with fade
    pause 0.5 
    scene ep3s4r2
    $ renpy.movie_cutscene("images/animation/ep3s4intro.webm", stop_music=False)
    scene ep3s4r2
    pause 1
    scene ep3s4r3
    with hpunch
    dpense "Plant the foot in the ground..."
    pause 1 
    scene ep3s4r4
    with dissolve
    dpense "If I want to score, I need to put more force into it..."
    pause 1 
    ji "HEY!" with vpunch
    scene ep3s4r5
    with dissolve
    pause 0.5
    scene ep3s4r6
    with dissolve
    pause 0.5
    scene ep3s4r7
    $ renpy.movie_cutscene("images/animation/mira149.webm", stop_music=False)
    scene ep3s4r7
    ji "If you plan to win, you need to put more effort into it, huh!"
    scene ep3s4r8
    with dissolve
    ji "Pass me the ball!"
    scene ep3s4r9
    pause 1.5 
    scene ep3s4r10
    $ renpy.movie_cutscene("images/animation/rebond.webm", stop_music=False)
    scene ep3s4r10
    with hpunch
    pause 0.5
    scene ep3s4r12
    with dissolve
    pause 0.5
    scene ep3s4r11
    $ renpy.movie_cutscene("images/animation/miracourt.webm", stop_music=False)
    scene ep3s4r11
    with dissolve
    ji "Look at that!"
    pause 1
    scene ep3s4r13
    with dissolve
    play sound "sound/tirlong.wav" volume 1
    pause 0.5
    scene ep3s4r14
    with hpunch
    pause 0.5
    scene ep3s4r15
    with dissolve
    pause 0.5
    scene ep3s4r16
    with dissolve
    d "What the..."
    scene ep3s4r17
    play sound "sound/voom.wav" volume 1
    $ renpy.movie_cutscene("images/animation/voum.webm", stop_music=False)
    scene ep3s4r17
    with dissolve
    scene ep3s4r18
    with dissolve
    pause 0.5
    scene ep3s4r19
    with dissolve
    d "Hum ?"
    scene ep3s4r20
    with dissolve
    pause 0.5
    scene ep3s4r21
    with dissolve
    pause 0.5
    scene ep3s4r22
    with dissolve
    d "But..."
    scene ep3s4r23
    with dissolve
    pause 0.5
    scene ep3s4r24
    with dissolve
    pause 1
    scene ep3s4r25
    with dissolve
    d "Who are you ?"
    scene ep3s4r26
    with dissolve
    ji "Knowing who I am won't help you at all."
    scene ep3s4r27
    with dissolve
    ji "Keep training because I really look forward to facing you."
    scene ep3s4r28
    with dissolve
    ji "See you in the finals..."
    scene ep3s4r29
    with dissolve
    ji "If you make it that far."
    scene ep3s4r25
    with dissolve
    d "O...kay..."
    scene ep3s4r2
    with dissolve
    dpense "I'll really need to level up..."
    dpense "That girl has some shot..."
    dpense "I almost felt the wind turn around the ball..."
    dpense "Come on... Let's get back to it!"
    scene ep3s4r3
    with hpunch
    pause 2
    $ Training2 = True
    stop music fadeout 2
    scene black
    with fade
    pause 2
    jump Chambreep3

label Chambreep3:
    scene black
    with fade
    pause 1
    show text _ ("17:30") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/ALM0113-InLoveWithYou-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s4r30
    with fade
    dpense "Humm... What time is it?"
    scene ep3s4r31
    dpense "5:30 PM"
    dpense "I should be heading out soon."
    dpense "Maybe I should send a message to Elise before she goes to bed..."
    phone discussion "eli1":
        time year 2023 month 9 day 5 hour 17 minute 32
        "d" "Hey! Are you awake?"
    phone end discussion
    dpense "..."
    dpense "No response?"
    scene ep3s4r30
    with dissolve
    dpense "That's strange... She usually replies within three seconds..."
    dpense "Does anyone else need anything?"
    dpense "Ruby must be busy... I won't bother her..."
    scene ep3s4r31
    with dissolve
    dpense "Who should I send a message to?"

    $ gracephoneep3s4 = False
    $ juliaphoneep3s4 = False
    $ bluephoneep3s4 = False
    $ gabyphoneep3s4 = False
    $ madphoneep3s4 = False



    python hide:

        gc = phone.group_chat.group_chat("ruby1")
        for c in tuple (gc._characters):
            gc.remove_character(c)
        gc = phone.group_chat.group_chat("mad1")
        for c in tuple (gc._characters):
            gc.remove_character(c)
        gc = phone.group_chat.group_chat("gaby1")
        for c in tuple (gc._characters):
            gc.remove_character(c)
        if BlueRelation == False:
            gc = phone.group_chat.group_chat("sofia1")
            for c in tuple (gc._characters):
                gc.remove_character(c)
        if Gracepath == False:
            gc = phone.group_chat.group_chat("grace1")
            for c in tuple (gc._characters):
                gc.remove_character(c)

    if Gracepath == True:
        $ gracephoneep3s4 = True
    if JuliaPath == True:
        $ juliaphoneep3s4 = True
    if BlueRelation == True:
        $ bluephoneep3s4 = True
    if GabyPath == True:
        $ gabyphoneep3s4 = True
    if Madisonphone == True:
        $ madphoneep3s4 = True

    hide screen gameUIBEST

    dpense "Oh! There is an update of my phone!"
    dpense "New feature : Send messages by 'contacts' application!"
    dpense "Okay I will try it..."

    $ gracerubyphone = False
    $ blueprepphone = False

show screen telephone()

label Choixtelep3s4:

    menu:
        "Pass":










            jump departsoiree

label gracephoneep3s4:
    $ phone.menu = False
    phone discussion "grace1":
        time year 2023 month 9 day 5 hour 17 minute 35
        "d" "You guys doing okay?"
        "grace" "Yeah, we're good! We're almost done :)"
        "d" "You need anything?"
        "grace" "Nope!"
        "grace" "Ruby thought of everything as usual!"
        "d" "Okay... Well, see you later then!"
        "grace" "Yes! See you later!"
        "grace" "I can't wait to see you already!"
        image "grace" "phone/assets/gracerubyphone.webp"
    phone end discussion
    pause 1
    $ gracephoneep3s4 = False
    $ wallpapers.append("phone/assets/gracerubyphone.png")
    $ renpy.notify (_("A wallpaper has been added"))
    dpense "Those lips..."
    dpense "Well, looks like they're doing fine..."
    jump Choixtelep3s4

label juliaphoneep3s4:
    $ phone.menu = False
    phone discussion "julia1":
        time year 2023 month 9 day 5 hour 17 minute 35
        "d" "Feeling better?"
        "julia" "Still a bit of back pain, but I'm okay..."
        "d" "If you need massages, I'm here!"
        "julia" "Haha! No, it's okay!"
        "julia" "I'm getting ready for tonight..."
        "d" "Well, don't hesitate if you need anything!"
        "julia" "I'll remember that!"
        "julia" "See you tonight!"
        "d" "See you tonight!"
    phone end discussion
    pause 1
    $ juliaphoneep3s4 = False
    dpense "I hope she'll be okay tonight..."
    jump Choixtelep3s4

label madphoneep3s4:
    $ phone.menu = False
    call phone_discussion_mad from _call_phone_discussion_mad
    pause 1
    $ madphoneep3s4 = False
    dpense "I'm dumb, she said she was with her daughter..."
    dpense "She must be busy often..."
    dpense "I think I'll need to change the way I approach her..."
    jump Choixtelep3s4

label bluephoneep3s4:
    $ phone.menu = False
    phone discussion "sofia1":
        time year 2023 month 9 day 5 hour 17 minute 35
        "d" "Are you ready for tonight?"
        "sofia" "I'm not even dressed yet..."
        "d" "Seriously?"
        image "sofia" "phone/assets/blueprep.webp"
        "d" "Stay like that, it works for me!"
        "sofia" "If only I could..."
        "d" "I won't bother you any longer then!"
        "sofia" "Oh, you're not bothering me!"
        image "sofia" "phone/assets/blueprep2.webp"
        "d" "Tease!"
        "sofia" "You have no idea how much!"
        "sofia" "Alright, see you later!"
        "d" "See you later!"
    phone end discussion
    $ bluephoneep3s4 = False
    $ wallpapers.append("phone/assets/blueprep.png")
    $ wallpapers.append("phone/assets/blueprep2.png")
    $ renpy.notify (_("A wallpaper has been added"))
    dpense "She has really changed..."
    dpense "Something happened..."
    jump Choixtelep3s4

label gabyphoneep3s4:
    $ phone.menu = False
    call phone_discussion_gaby from _call_phone_discussion_gaby
    $ gabyphoneep3s4 = False
    dpense "Well... At least I checked!"
    dpense "I must not forget my appointment with her tomorrow though..."
    dpense "Otherwise, she'll kill me!"
    jump Choixtelep3s4

label departsoiree:
    scene ep3s1r9
    with dissolve
    dpense "Okay, let's go!"
    hide screen telephone
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3s4c1
        $ TEMP2 = ep3s4c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    if CharlottePath == True:
        dpense "Charlotte asked me to go to the shop before the party..."
        menu:
            "Join her[TEMP1!t]":
                scene black
                with fade
                pause 1
                jump Charlottetime
            "Or not[TEMP2!t]":
                scene black
                with fade
                pause 1
                $ CharlottePath = False
                jump ArriveeFete

label ArriveeFete:
    stop music fadeout 2
    scene black
    with fade
    pause 1
    d "Now... The party!"
    $ gracephoneep3s4 = False
    $ juliaphoneep3s4 = False
    $ bluephoneep3s4 = False
    $ gabyphoneep3s4 = False
    $ madphoneep3s4 = False
    d "Let's get it started..."
    pause 1
    jump ep319h

label Charlottetime:
    stop music fadeout 2
    if _in_replay:
        show screen Replayexit
    scene black
    with fade
    pause 1
    play music "musique/ALM0187-RomanticLoveStory-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s4r40
    with fade
    pause 1 
    scene ep3s4r41
    with dissolve
    with hpunch
    dpense "It's closed..."
    scene ep3s4r42
    with dissolve
    dpense "But the lights are on..."
    scene ep3s4r43
    with dissolve
    dpense "She said she had some things to count, I think..."
    dpense "Maybe there's a door around back?"
    scene ep3s4r44
    with dissolve
    dpense "The back door..."
    dpense "It's open."
    scene ep3s4r44a
    with dissolve
    pause 1 
    scene ep3s4r45
    with dissolve
    pause 1 
    scene ep3s4r46
    with dissolve
    pause 1
    scene ep3s4r47
    with dissolve
    pause 1
    scene ep3s4r48
    with dissolve
    pause 1
    scene ep3s4r49
    with dissolve
    d "So this is where you're hiding?"
    scene ep3s4r50
    with dissolve
    with vpunch
    cha "Huh?"
    scene ep3s4r51
    with dissolve
    with hpunch
    cha "Ahhh!"
    scene ep3s4r52
    with dissolve
    with vpunch
    d "Dont worry! I got THIS!... Ekhm I mean I GOT YOU!!"
    scene ep3s4r53
    with dissolve
    with hpunch
    cha "Oh?"
    scene ep3s4r54
    with dissolve
    cha "You scared me!"
    scene ep3s4r55
    with dissolve
    d "Sorry! That wasn't my intention."
    cha "Are you comfortable there?"
    d "What do you mean?"
    cha "You can let go of my breasts, you know..."
    scene ep3s4r56
    with dissolve
    d "Oh! Yes, sorry!"
    cha "Wait, while you're here, hold me. I need to count the back of the shelf."
    d "Uh... Yes, okay."
    scene ep3s4r58
    with dissolve
    cha "Hold me tight, okay!"
    scene ep3s4r59
    with dissolve
    d "Yes, yes!"
    scene ep3s4r60
    with dissolve
    dpense "What an ass..."
    dpense "Wait..."
    scene ep3s4r61
    with dissolve
    dpense "She didn't wear any panties?" with hpunch
    dpense "She did it on purpose, it can't be..."
    scene ep3s4r62
    with dissolve
    cha "Wait, I need to lean in a bit more to see the back."
    scene ep3s4r63
    with dissolve
    dpense "Is she serious?"
    dpense "She wants to play..."
    stop music fadeout 1
    pause 1
    scene ep3s4r64
    with dissolve
    dpense "Then let's play!"
    play music "musique/MYO0038-RebelSpirit-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s4r65
    with dissolve
    cha "Oh?"
    cha "What the...?"
    scene ep3s4r66
    with dissolve
    cha "Ah!"
    play movie "images/animation/animcha1.webm" loop volume(0)
    show movie with dissolve
    cha "Hummm..."
    cha "Yes... Go on..."
    cha "I knew you were going to enjoy the view."
    cha "I thought that you... Humpfff..."
    cha "Would know how to take your chance... Haaa..."
    stop movie
    scene ep3s4r66
    with dissolve
    pause 1 
    scene ep3s4r67
    with dissolve
    cha "You're really good at this... Ohhh!"
    scene ep3s4r68
    with dissolve
    cha "Yes! Just right there!"
    scene ep3s4r69
    with hpunch
    cha "Do it! Eat that pussy!"
    cha "Oh my god that's great..."
    play movie "images/animation/animcha2.webm" loop volume(0)
    show movie with dissolve
    dpense "She's dripping wet..."
    dpense "I never thought I could lick a woman's pussy like that..."
    dpense "She tastes so good..."
    dpense "I never had a woman like that in my life..."
    dpense "She's so aroused..."
    scene black
    with fade
    stop movie
    scene ep3s4r70
    with hpunch
    cha "Okay big boy."
    scene ep3s4r71
    with dissolve
    cha "Show me what you can do."
    scene ep3s4r72
    with dissolve
    cha "Take those clothes off so I can check out your hot body!"
    scene ep3s4r73
    with dissolve
    pause 1
    scene black
    with fade
    scene ep3s4r74
    with dissolve
    cha "Yaa.... That's what I thought..."
    scene ep3s4r75
    with dissolve
    cha "So muscular..."
    scene ep3s4r76
    with dissolve
    cha "You even smell strong."
    cha "I..."
    d "Enough talking..."
    scene ep3s4r77
    with vpunch
    cha "Whaaa!"
    cha "You like to take charge?"
    scene ep3s4r78
    with dissolve
    d "I'm not here for chit-chatting..."
    scene ep3s4r79
    with dissolve
    d "I think it's time to free some beauties from their prison."
    scene ep3s4r80
    with dissolve
    pause 1 
    scene ep3s4r81
    $ renpy.movie_cutscene("images/animation/animcha3.webm", stop_music=False)
    scene ep3s4r81
    pause 1 
    d "Oh my god, these are some great tits!"
    scene ep3s4r82
    with dissolve
    cha "Yeah... Fondle them... Play with them..."
    d "I don't have time to play..."
    scene ep3s4r92
    with hpunch
    d "You wanted a young stud..."
    d "Here it comes..."
    scene black
    play movie "images/animation/animcha4.webm" loop volume(0)
    show movie with dissolve
    cha "Ahhhhhhhhhh ! You're more than a boy right there!"
    cha "Ahhh..."
    cha "Yesss... I feel you... Filling up my tight pussy..."
    dpense "Sure it's surprisingly tight..."
    cha "Go on [name]! Stretch me!"
    cha "Give it to me harder!"
    stop movie
    scene black
    play movie "images/animation/animcha4fin.webm" loop volume(0)
    show movie with dissolve
    d "Take this!"
    cha "Oh my god! Oh my god! Oh my god!"
    d "You wanted it!"
    cha "Yes! Yes! More! More!"
    d "I'm coming!"
    cha "I'm coming too!!!"
    d "Turn around I will cum on your back!"
    stop movie
    scene ep3s4r83
    with dissolve
    cha "Give me your hot cum [name]!"
    cha "I want to feel it on my skin!"
    d "Ahhhhh !!!"
    scene ep3s4r84
    with dissolve
    with flash
    with hpunch
    scene ep3s4r85
    with dissolve
    with flash
    with vpunch
    pause 1 
    scene ep3s4r86
    with dissolve
    stop music fadeout 2
    d "That was good!"
    cha "Yeah..."
    cha "Feeling empty now..."
    play music "musique/MYO0038-RebelSpirit-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s4r87
    with dissolve
    d "Good! Cause it's not finished!"
    pause 1
    cha "What?" with hpunch
    pause 1
    cha "MY ASS!"
    pause 1
    cha "Be careful I..."
    scene ep3s4r89
    with hpunch
    cha "Ahhhhhhh!"
    play movie "images/animation/animcha5.webm" loop volume(0)
    show movie with dissolve
    cha "Oh my god! You're really stretching my ass..."
    cha "Fuck that ass [name]! Fuck! Fuckkkkkkkkkkk!"
    cha "You have so much left..."
    cha "You're still hard as rock !"
    d "I won't last long! You're so tight!"
    cha "Cum in me!"
    cha "Fill my ass up!"
    d "Ahhhhhhhhhhhhh!"
    stop movie
    with flash
    with hpunch
    scene ep3s4r88
    with dissolve
    with flash
    with vpunch
    cha "AHhhhhhhhhhhhhhhhhh!"
    cha "I'm coming!!!!"
    with flash
    with vpunch
    with flash
    with vpunch
    pause 1 
    scene ep3s4r90
    with dissolve
    d "That's what I call a good gaping!"
    cha "'I won't be able to sit today..."
    d "I can't stay, I have to..."
    scene ep3s4r91
    with dissolve
    cha "Yeah yeah..."
    cha "Go to your party..."
    cha "See you soon!"
    d "Yeah, see ya!"
    cha "Not too soon..."
    scene black
    with fade
    $ Achievement.add(achievement_milf)
    $ achievement.grant("milf")
    $ achievement.sync()
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    pause 2
    jump ArriveeFete
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
