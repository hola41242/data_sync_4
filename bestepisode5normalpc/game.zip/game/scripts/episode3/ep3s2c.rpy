label ep3s2c:
    show text _ ("9:00 AM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/ALM0063-EternalLove-stockmusic-net.mp3" volume 0.2 fadein 2
    scene maisongrace1
    with fade
    pause 2 
    scene maisongrace2
    with dissolve
    pause 2 
    scene maisongrace3
    with dissolve
    pause 2 
    scene maisongrace4
    with dissolve
    pause 2 
    scene maisongrace5
    with dissolve
    d "Good morning, Mrs. Drew."
    scene maisongrace6
    with dissolve
    drew "Oh! [name]! You really caught me by surprise."
    drew "What brings you here?"
    d "I've come to see Grace."
    scene maisongrace7
    with dissolve
    drew "She's just finishing up; she’ll be right down."
    drew "You two seem to have grown quite close recently…"
    d "Yes, we’ve been spending a lot of time together."
    scene maisongrace8
    with dissolve
    drew "Worry not, I find it quite endearing."
    drew "Keep her close. Take her far in this competition."
    d "Agreed?"
    scene maisongrace9
    with dissolve
    drew "I’ve been watching, you know. And I must say, I'm quite impressed."
    d "Really?"
    scene maisongrace10
    with dissolve
    drew "Yes, I sincerely hope both of you succeed."
    drew "Though I'm keeping an eye on you."
    scene maisongrace11
    with dissolve
    drew "For now, I’m content with you dating my daughter."
    drew "But remember, she needs to win."
    d "And me?"
    drew "Well, you should win together."
    scene maisongrace12
    with dissolve
    drew "I know how to show gratitude. The farther you go, the greater your rewards will be."
    d "Rewards?"
    scene maisongrace13
    with dissolve
    drew "For now, your reward is seeing my daughter whenever you wish."
    drew "But be aware, you've caught more eyes than just hers…"
    drew "Now go, she’s waiting. And don’t be late."
    d "Understood."
    scene maisongrace14
    with dissolve
    drew "Oh, and before you go… The first answer is Gizeh..."
    dpense "What does that mean?"
    scene maisongrace15
    with dissolve
    drew "You'll understand when the time comes."
    drew "Consider it a little bonus."
    d "Understood."
    scene maisongrace16
    with dissolve
    dpense "What did she mean by that?"
    dpense "Strange…"
    scene maisongrace17
    with dissolve
    dpense "Well, off to Grace's room…"
    scene black
    with fade
    pause 1
    scene gracechambre1
    with fade
    pause 2 
    scene gracechambre2
    with dissolve
    pause 1 
    grace "Oh, [name]."
    scene gracechambre3
    with dissolve
    d "I hope I’m not interrupting?"
    grace "Not at all, I was just finishing getting ready."
    d "You look stunning."
    scene gracechambre4
    with dissolve
    grace "Stop, you’ll make me blush."
    d "May I kiss you?"
    scene gracechambre5
    with dissolve
    grace "May? It's practically a must!"
    scene gracechambre6
    with dissolve
    pause 1
    scene gracechambre7
    $ renpy.movie_cutscene("images/animation/gracechambre.webm", stop_music=False)
    scene gracechambre7
    pause 2
    d "Your mother seems to have given us her blessing."
    scene gracechambre8
    with dissolve
    grace "Really? What exactly did she say?"
    d "She noticed we’ve been spending a lot of time together and…"
    scene gracechambre9
    with dissolve
    grace "I actually wanted to talk to you about that."
    scene gracechambre10
    with dissolve
    grace "Listen, while we’re in this competition, let’s keep it our little secret."
    d "Why?"
    scene gracechambre11
    with dissolve
    grace "Everything here can be used against us."
    scene gracechambre12
    with dissolve
    grace "And tonight… After the party, we’ll have plenty of time to…"
    scene gracechambre13
    with dissolve
    grace "Ahhh! I love it when your hands brush against me."
    scene gracechambre14
    with dissolve
    d "And I adore the feel of your skin."
    scene gracechambre15
    with dissolve
    grace "Ah..."
    scene gracechambre16
    with dissolve
    grace "Hummmm..."
    scene gracechambre17
    with dissolve
    with vpunch
    grace "Stop, or I won’t be able to stop myself."
    grace "Tonight…"
    d "Are you ready for tonight?"
    scene gracechambre18
    with dissolve
    grace "Actually, we’re heading to class now, and then I’m meeting Ruby. We’re spending the afternoon getting everything ready."
    grace "She’s planned a lot!"
    d "Oh really? I won’t come and bother you then!"
    scene gracechambre19
    with dissolve
    grace "Better not."
    grace "Especially with Ruby. If you get in her way, you’re in for it."
    d "In for it? From Ruby?"
    grace "Oh yes, when she’s focused, it's best not to disturb her."
    d "Understood. So, what time should I arrive?"
    scene gracechambre20
    with dissolve
    grace "The party really starts at 9 PM, but you can come over at 8 PM to get ready."
    d "That works for me."
    grace "And don’t forget, tonight’s theme is chic and shock."
    d "Yes, I’m still unsure about what to wear. I don’t even know how I’ll dress."
    scene gracechambre21
    with dissolve
    grace "From what I understand, Ruby mentioned that you’d have a suit… that Red is supposed to bring."
    grace "If not, I’ve got another one. It was my father’s, so don’t worry, everything’s arranged."
    grace "Anyway, Ruby has a backup list in case something goes awry."
    grace "And she even has a backup for her backup list…"
    d "Understood."
    grace "Go downstairs... I’ll be ready in two minutes."
    stop music fadeout 2.0
    scene black
    with fade
    pause 1 
    play music "musique/MYO0046-BackFromTheEdge-stockmusic-net.mp3" volume 0.2 fadein 2
    scene gracechambre22
    with fade
    pause 2 
    scene gracechambre23
    with dissolve
    pause 2 
    scene black
    with fade
    show movie with fade
    play movie "images/animation/sortiegracemix.webm" noloop
    pause 12
    hide movie with fade
    stop movie
    scene gracesortie
    with fade
    d "Wow… you look gorgeous."
    grace "You’re not too bad yourself!"
    scene gracesortie2
    with dissolve
    grace "Come on, we shouldn’t be late."
    grace "Let’s go!"
    d "Let's go!"
    scene black
    with fade
    pause 1
    stop music fadeout 2.0
    jump ep3s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
