label coming3:
    scene black
    with fade
    pause 1
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" 
    pause 1.25
    scene coming
    with zoomout
    pause 4
    scene black
    with fade
    pause 0.5
    scene twister
    with dissolve
    "Right hand on green one!"
    pause 2
    scene black
    with fade
    pause 0.5
    scene poker
    with dissolve
    "I'm all-in!"
    pause 2
    scene black
    with fade
    pause 0.5
    scene gracenight
    with dissolve
    grace "You're the only one I want tonight..."
    pause 1
    scene episode3teaser
    with dissolve
    pause 5 
    stop music fadeout 5
    scene black
    with fade
    pause 2
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
