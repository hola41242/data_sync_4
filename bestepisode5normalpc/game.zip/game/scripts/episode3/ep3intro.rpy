label ep3intro:
    stop music fadeout 2.0
    scene black
    pause 2
    with fade
    show text _ ("EPISODE 3 {p} \n Let's get it started!") at truecenter
    pause 2
    with dissolve
    pause 2
    hide text
    pause 1
    show text _ ("8:00 AM") at truecenter
    pause 2
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/Nomyn-Fragments.mp3" volume 0.2 fadein 2
    "Look how beautiful they are together, like two little princesses come to life."
    scene ep3intros1
    with fade
    pause 1 
    scene ep3intros2
    $ renpy.movie_cutscene("images/animation/bluebed.webm", stop_music=False)
    "They're breathtaking. But what do we call them? Twins are twice the miracle I had hoped for."
    "How about we name this little queen Elizabeth? Sounds fitting, doesn't it?"
    "Elizabeth... yes, that's perfect. And for your sister... How about Sofia, a name as regal as hers?"

    "Sofia, see how your sister rides her bike? Follow her lead and you'll find it's simple."
    scene ep3intros3
    with dissolve
    "Sofia, why always blue? It’s so boyish! Your sister at least chooses vibrant red!"
    "Sofia, blue again for your drawing? Look at the lively colors your sister picks, they're full of life."

    scene black
    with fade
    sofia "Why am I always compared to her…"
    scene ep3intros4
    with fade
    "Sofia, you need to try fitting in more. Look at Elizabeth, she's got it all."
    scene black
    with fade
    sofia "Just leave me be… I want to be my own person..."
    scene ep3intros5
    with fade
    "Sofia, Sofia!!!"
    "She's stronger than you..."
    scene ep3intros6
    with dissolve
    "Sofia!"
    "Sofia!"
    scene ep3intros7
    with dissolve
    with hpunch
    beth "Sofia! Come on, we're going to be late!"

    sofia "Alright! I’m on my way…"
    scene black
    with fade
    $ persistent.streaming = False

    jump ep3s1
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
