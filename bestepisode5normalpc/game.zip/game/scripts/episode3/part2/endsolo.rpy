label endsolo:
    stop music fadeout 2
    scene black
    with fade
    pause 1
    scene endsoloep31
    with fade
    pause 1 
    dpense "Well, here I am back in my room..."
    play music "musique/Niwel_Bad_Love_Vocal_Edit Fin d'episode.mp3" volume 0.2
    scene endsoloep32
    with vpunch
    dpense "This isn't how I thought the evening would end..."
    dpense "Tomorrow I'll probably have more to do..."
    if JuliaHopital == True:
        dpense "Accompany Julia to the hospital..."
    if gabimusee == True:
        dpense "Meet Gabriella at the museum..."
    if madidiner == True:
        dpense "The rare chance to have dinner with Madison's family."
    scene endsoloep32
    with dissolve
    dpense "In any case, this evening was interesting."
    scene endsoloep33
    with dissolve
    dpense "That Kira is intriguing..."
    scene endsoloep34
    with dissolve
    dpense "But I still haven't heard from Elise..."
    scene endsoloep35
    with dissolve
    dpense "That's not like her..."
    scene endsoloep36
    with dissolve
    dpense "Let's see what happens next..."
    scene black
    with fade
    pause 2
    stop music fadeout 2.0
    pause 2
    scene endorushiep3
    with fade
    play music "musique/Cjbeards-FireAndThunderprobleme.mp3"
    orushi "Simmons! Here's Orushi!"
    orushi "How are things going with yours?"
    "We're making progress..."
    "Almost ready for phase two."
    scene endorushiep31
    with dissolve
    orushi "Already?"
    "Yeah... And on your side?"
    scene endorushiep31
    with dissolve
    orushi "We're going to speed things up a bit to be ready for the next step."
    "And the others?"
    scene endorushiep32
    with dissolve
    orushi "Same. Everyone is more or less at the same level..."
    "Perfect!"
    scene endorushiep33
    with dissolve
    orushi "Okay. See you next phase."
    "Da!"
    pause 2
    scene black
    with fade
    pause 1
    $ Achievement.add(achievement_episode3)
    $ achievement.grant("episode3")
    $ achievement.sync()
    scene black
    with fade
    pause 3
    jump introep4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
