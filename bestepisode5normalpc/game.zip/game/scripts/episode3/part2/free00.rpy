label free00:
    scene black
    with fade
    pause 1 
    show text _ ("00:00 AM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    scene 00h01
    with fade
    grace "Well, friends..."
    grace "I'm sorry, but I promised my mom I'd end the evening by midnight..."
    scene 00h02
    with dissolve
    ruby "Oh, already?"
    grace "Yes... She'll be home in about an hour, and it's better if we're not still here when she arrives..."
    scene 00h03
    with dissolve
    ruby "No problem! Come on guys! It's time for Cinderella to be changed in a maid"
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3001
        $ TEMP2 = ep3002
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    if Gracepath == True:
        scene 00h04
        with dissolve
        grace "Will you stay with me?"
        menu:
            "Yes[TEMP1!t]":
                d "Of course!"
                scene 00h05
                with dissolve
                ruby "Alright, let's head out!"
                d "I'll stay here with Grace to help her clean up!"
                scene 00h08
                with dissolve
                ruby "Yeah, yeah, sure! Clean up..."
                scene 00h07
                with dissolve
                ruby "See you tomorrow!"
                mad "See you tomorrow, everyone!"
                d "See you tomorrow!"
                grace "See you tomorrow!"
                scene black
                with fade
                pause 1
                jump fingraceep3
            "No[TEMP2!t]":
                d "No, I'd rather not..."
                scene 00h06
                with dissolve
                grace "Oh..."
                scene 00h07
                with dissolve
                ruby "Alright, see you tomorrow!"
                mad "See you tomorrow, everyone!"
                d "See you tomorrow!"
                grace "See you tomorrow!"
                scene black
                with fade
                pause 1
                $ Gracepath = False
                jump endsolo
    else:
        scene 00h07
        with dissolve
        ruby "Alright, let's head out!"
        mad "See you tomorrow, everyone!"
        d "See you tomorrow!"
        grace "See you tomorrow!"
        scene black
        with fade
        pause 1
        jump endsolo
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
