
label fingraceep3:
    stop music fadeout 2
    pause 1
    if _in_replay:
        show screen Replayexit
    scene gracefinep31
    with fade
    play music "musique/ALM0063-EternalLove-stockmusic-net.mp3" volume 0.2
    grace "Thanks for walking me to my room, [name]. I had a lot of fun tonight."
    d "Me too, Grace. It was a great evening."
    scene gracefinep32
    with dissolve
    grace "So, um, this is my room. It's not much, but it's cozy."
    dpense "Grace looks a bit nervous. It's kind of adorable."
    scene gracefinep33
    with dissolve
    grace "I'm just going to change into something more comfortable. Make yourself at home."
    scene gracefinep34
    with dissolve
    d "Take your time."
    scene gracefinep35
    with dissolve
    dpense "I can't believe I'm in Grace's room. The night has been amazing so far, and now this... I need to keep my cool."
    scene gracefinep36
    with dissolve
    stop music fadeout 1
    grace "I hope this isn't too much..." with vpunch
    pause 0.5
    play music "musique/ALG0202-EnergyRock-stockmusic-net.mp3" volume 0.2
    d "Wow!"
    scene gracefinep37
    with dissolve
    pause 1 
    scene gracefinep38
    $ renpy.movie_cutscene("images/animation/grace030.webm", stop_music=False)
    d "Grace, you look... stunning."
    scene gracefinep38
    pause 1
    scene gracefinep39 with dissolve:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    dpense "Her lingerie is absolutely breathtaking. The way it hugs her body... I need to focus."
    dpense "Her confidence is intoxicating. I'm both excited and a little scared. I don't want to mess this up."
    grace "I'm glad you like it. I was a bit worried it might be too much."
    d "It's perfect. You look incredible."
    grace "Can I sit on you?"
    d "Sure."
    scene gracefinep310
    with hpunch
    dpense "My heart is racing. I need to keep things calm."
    dpense "Her bed is so inviting, but I don't want to rush things and make her uncomfortable."
    scene gracefinep311
    with dissolve
    grace "You know, I've never really been alone with a boy in my room before."
    d "I feel honored to be the first."
    dpense "She's so close... I can smell her perfume. It's intoxicating."
    dpense "I need to control myself. I don't want to scare her off."
    scene gracefinep312
    with dissolve
    grace "You know... you're the only one I wanted to be with tonight."
    d "Grace..."
    dpense "Hearing her say that makes my heart skip a beat. She really wants this too."
    grace "Can we... kiss again?"
    d "I'd love that."
    scene gracefinep313
    with dissolve
    stop music fadeout 2
    grace "Mmm... Your kisses always make me feel so warm inside."
    dpense "Her lips are so soft, and the way she responds... It's like she was made for this."
    dpense "Every kiss feels like a promise of something more, something deeper."
    play music "musique/AIE0550-YouAreTheOneINeed-stockmusic-net.mp3" volume 0.2 fadein 2
    scene gracefinep314
    with dissolve
    grace "Your touch... It's like you know exactly what I need."
    scene gracefinep315
    with dissolve
    grace "Oh, that feels so nice..."

    scene gracefinep316
    with dissolve
    dpense "Her skin is incredibly soft. The way she reacts to my touch is driving me wild."
    scene gracefinep3caress1
    with vpunch
    grace "Oh..."

    pause 2
    scene gracefinep3caress2
    $ renpy.movie_cutscene("images/animation/gracecaress.webm", stop_music=False)
    scene gracefinep3caress2
    dpense "I want to explore every inch of her, but I need to be gentle. This is her first time."
    d "Grace, may I...?"
    grace "Yes, please."
    scene gracefinep317
    with dissolve
    d "Let me take care of you."
    dpense "I want to take my time, make this unforgettable for her."
    scene gracefinep318
    with dissolve
    grace "Okay... I'm a little nervous."
    d "Don't worry, just focus on how it feels."
    scene gracefinep319
    with dissolve
    d "How does this feel?"
    scene gracefinep320
    with dissolve
    grace "Oh... That feels wonderful. Your hands are so warm."
    scene gracefinep321
    with dissolve
    dpense "Her skin is so soft. I can feel her starting to relax under my touch."
    scene gracefinep322
    with dissolve
    grace "Ahhh..." with hpunch
    scene gracefinep323
    with dissolve
    grace "Hummmm..."
    scene gracefinep324
    with dissolve
    dpense "She becomes wet..."
    scene gracefinep325
    with dissolve
    d "And this?"
    scene gracefinep326
    with dissolve
    grace "Slowly...Please..."
    scene gracefinep327
    with dissolve
    grace "Oh my god!" with hpunch
    grace "Your fingers are so gentle. It's like you're reading my mind."
    dpense "I want to make her feel things she's never felt before."
    pause 1
    d "Now, just enjoy this..."
    scene black
    play movie "images/animation/gracecuni2.webm" loop
    show movie with flash
    grace "Oh..."
    grace "Oh my God..."
    grace "[name]..."
    grace "That's..."
    grace "Amazing..."
    dpense "Her taste is intoxicating. The way she responds to my tongue... It's driving me wild."
    play movie "images/animation/gracecuni1.webm" loop
    show movie with dissolve
    grace "I never knew it could feel like this... It's like my whole body is alive."
    dpense "Her moans are like music to my ears. I want to give her everything."
    grace "Don't stop... Please, don't stop..."
    dpense "I can feel her trembling, she's so responsive. I want to make her feel every sensation, every moment."
    grace "I'm... I'm going to... Ahhh!"
    dpense "She tastes so sweet. I can feel her climax building."
    with flash
    with hpunch
    scene gracecuni2
    stop movie
    with flash
    with hpunch
    pause 0.5
    scene gracecuni1
    with vpunch
    grace "AHHHHHHHHH!"
    with flash
    scene gracefinep328
    with hpunch
    with flash
    grace "MY GOOOOOOOOOOOOOODDDDDDDDDDD!"
    with hpunch
    with flash
    pause 2
    scene gracefinep329
    with dissolve
    grace "Oh my... I can't... That was... Wow...."
    dpense "Seeing her like this, completely satisfied... It's amazing."
    dpense "I've never felt closer to anyone in my life."
    scene gracefinep330
    with dissolve
    stop music fadeout 2
    grace "I... I think I might have had a bit too much to drink earlier. I'm feeling queasy..."
    play music "musique/ALM0063-EternalLove-stockmusic-net.mp3" volume 0.2
    d "It's okay, Grace. Tonight was perfect."
    dpense "I wanted more, but I can see she's overwhelmed. I need to be patient."
    scene gracefinep331
    with dissolve
    grace "I really enjoyed that, but I think I need to stay like that. My stomach feels a bit off."
    d "Of course, let's just rest."
    scene gracefinep332
    with dissolve
    dpense "Holding her in my arms like this... I never want this moment to end."
    dpense "Her warmth, her softness... I feel so close to her."
    grace "Thank you, [name]. This was the best night of my life."
    d "Mine too, Grace. Mine too."
    dpense "Her gratitude is touching. I want to protect her, make her happy."
    scene gracefinep333
    with dissolve
    grace "You should go now, my mother should come back soon and I don't want you to have problems with her..."
    d "You're right..."
    dpense "I can hear her breathing slow as she falls asleep in my arms. This is perfect."
    dpense "I want to cherish this moment, remember every detail."
    d "Sweet dreams, Grace."
    $ Achievement.add(achievement_virgin)
    $ achievement.grant("virgin")
    $ achievement.sync()
    scene black
    with fade
    pause 1
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()

    jump endsolo
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
