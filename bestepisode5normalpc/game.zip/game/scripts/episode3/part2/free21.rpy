label free21:
    stop music fadeout 2
    scene black
    with fade
    pause 1 
    show text _ ("9:00 PM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1

    if bluebathsequence == True:
        jump bluebathsequence

    if freepokersequence == True:
        jump freepokersequence
    else:

        jump twistersequence


label bluebathsequence:
    if _in_replay:
        show screen Replayexit
    play music "musique/ALM0063-EternalLove-stockmusic-net.mp3" volume 0.2
    scene free21blue1
    with fade
    pause 2
    scene free21blue2
    with dissolve
    pause 2
    scene free21blue3
    with dissolve
    pause 2
    sofia "There you are..."
    sofia "Hurry up, we don't have much time..."
    scene free21blue4
    with hpunch
    sofia "Ah!"
    d "Is this what you want?"
    dpense "She's always so eager..."
    sofia "What I want..."
    sofia "I want a man..."
    sofia "Who knows how to take me..."
    sofia "Who leads me and..."
    scene free21blue5
    with hpunch
    sofia "AH!"
    dpense "She's driving me crazy..."
    d "You're already excited before we even start..."
    sofia "I've been excited since you made me... in the lecture hall..."
    sofia "Since I felt your fingers..."
    scene free21blue6
    with dissolve
    d "These fingers?"
    dpense "I love how she reacts..."
    sofia "Mmm..."
    d "You're soaking wet!"
    sofia "I told you!"
    sofia "But it's not your fingers I want today!"
    sofia "I want you!"
    sofia "So hurry up, we don't have much time!"
    scene bluebathscreen1
    with dissolve
    d "Let me take this off..."
    sofia "Go ahead!"
    scene black
    with dissolve
    play movie "images/animation/bluebathmix.webm" loop volume(0)
    show movie with dissolve
    dpense "It's so wet, it slides right off..."
    sofia "Mmm..."
    sofia "Keep going..."
    sofia "Like that!"
    sofia "Oh my God, it feels so good..."
    dpense "She's incredible..."
    sofia "I can feel you deep inside me..."
    sofia "Ohhhhhhh"
    sofia "More! More!"
    sofia "Faster!"
    sofia "Harder!"
    dpense "She's wild!"
    sofia "Come on, I can feel it coming!"
    d "Me too, I can feel it building up."
    sofia "I want to feel you... inside me! Do it!"
    sofia "Fill me up!"
    sofia "Yes! I can feel you swelling!!!"
    d "Ahhhhhhhhhhh !!!"
    stop movie
    with flash
    with hpunch
    scene bluebathscreen2
    with dissolve
    with flash
    with vpunch
    dpense "This is unreal..."
    sofia "Oh my God!!!"
    sofia "That feels incredible..."
    scene bluebathscreen1
    with dissolve
    sofia "You can do whatever you want with me..."
    sofia "I'm yours..."
    scene bluebathend
    with dissolve
    sofia "Wow, that was intense..."
    dpense "I can't believe how amazing that was..."
    sofia "Now go join the others..."
    sofia "I'll see you later..."
    dpense "I can't wait for the next time..."
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    $ bluelove = True

    menu:
        "Go play Poker" if invitepoker == True:
            stop music fadeout 2
            scene black
            with dissolve
            pause 1
            jump freepokersequence
        "Go play Twister":
            stop music fadeout 2
            scene black
            with dissolve
            pause 1
            jump twistersequence

label freepokersequence:
    pause 1
    play music "musique/MYO0046-BackFromTheEdge-stockmusic-net.mp3" volume 0.2
    $ pokerparty = True
    scene pokerparty1
    with fade
    emerick "Ah, finally..."
    emerick "The guy manages to crash the game and takes his sweet time..."
    emerick "I hope you at least know how to play..."
    scene pokerparty2
    with dissolve
    emerick "We start with 1000 dollars... And always bet a minimum of 100 when you want to continue, no calling."
    emerick "We only raise once, meaning we don't go above 200."
    emerick "We're playing Texas Hold'em: 2 cards, 5 on the board. You know it or need a refresher?"
    menu:
        "I need a refresher":
            d "Can you refresh my memory? It's been a while since I played..."
            emerick "Red, can you explain it to him?"
            beth "Okay, you guys go ahead for the first round, I'll explain as we go..."
            $ bethhelp = True
            jump firsthand
        "No, I'm good":
            d "Don't worry, I know how to play."
            emerick "Well, we'll see about that!"
            jump firsthand

label firsthand:
    scene pokerparty72
    with dissolve
    dpense "7 and 2..."
    if bethhelp == True:
        beth "You can choose to bet 100 to play your hand or fold..."
        beth "7 and 2 is the worst hand you can have... Fold, it's easier."
        beth "Let's wait for a better hand."
        jump foldfirst
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3211
        $ TEMP2 = ep3212
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Bet[TEMP1!t]":
            jump raisefirst
        "Fold[TEMP2!t]":
            jump foldfirst

label raisefirst:
    scene pokerpartycartes
    with dissolve
    d "Hum..."
    scene pokerpartybet100
    with dissolve
    d "I bet 100"
    $ moneypoker = moneypoker - 100
    emerick "I'm in..."
    scene pokerpartyfold1
    with dissolve
    hec "I fold..."
    ben "I fold..."
    mac "I'm in..."
    scene pokerpartyboard
    with dissolve
    beth "The board..."
    beth "Seven of hearts. King of Spades. Queen of Clubs."
    dpense "I've got a pair of 7s..."
    dpense "But the king and queen..."
    scene pokerpartyemerick1
    with dissolve
    emerick "Not bad..."
    scene pokerpartymac1
    with dissolve
    mac "Hmm..."
    scene pokerpartycartes2
    with dissolve
    dpense "It's my turn to act first."
    menu:
        "Bet":
            jump betfirst
        "Fold[TEMP2!t]":
            jump foldfirst

label foldfirst:
    d "Fold."
    scene pokerpartyemerick1
    with dissolve
    emerick "Ah! Folding already..."
    d "I'll wait a bit before cleaning you out..."
    emerick "Yeah, sure..."
    scene black
    with fade
    pause 1
    jump secondhand

label betfirst:
    d "I bet 100..."
    $ moneypoker = moneypoker - 100
    emerick "I'm in..."
    mac "I'm in..."
    scene pokerpartyboard
    with dissolve
    beth "The turn..."
    scene partypokerboardturn
    with dissolve
    beth "Two of Hearts."
    dpense "I've got two pairs now..."
    emerick "A brick..."
    scene pokerpartymacangry
    with dissolve
    mac "You talk too much, seriously!"
    emerick "Yeah? Why, does it bother you?"
    mac "No, no..."
    scene pokerparty72
    with dissolve
    menu:
        "Bet":
            jump betfirstturn
        "Fold[TEMP2!t]":
            jump foldfirst

label betfirstturn:
    scene pokerpartymcturn
    with dissolve
    d "I bet 100..."
    $ moneypoker = moneypoker - 100
    scene pokerpartyemeraise
    with dissolve
    emerick "I raise..."
    mac "Call..."
    menu:
        "Call":
            jump callraiseturnfirst
        "Fold[TEMP2!t]":
            jump foldfirst

label callraiseturnfirst:
    d "I call..."
    $ moneypoker = moneypoker - 100
    scene partypokerboardturn
    with dissolve
    dpense "Come on... The river..."
    beth "And the river."
    scene pokerpartyboardriver
    with dissolve
    beth "Eight of Clubs."
    dpense "An 8... doesn't help much"
    dpense "I still have two pairs..."
    menu:
        "Bet":
            jump betfirstriver
        "Fold[TEMP2!t]":
            jump foldfirst

label betfirstriver:
    d "I bet 100..."
    $ moneypoker = moneypoker - 100
    scene pokerpartyemeraise
    with dissolve
    emerick "I raise..."
    mac "I fold..."
    emerick "Ah, here we go! Mr. Pro folds!"
    scene pokerpartymac1
    with dissolve
    mac "..."
    scene pokerpartyemerick1
    with dissolve
    emerick "And you, Frenchie?"
    emerick "Do you call or are you folding like Mac?"
    menu:
        "Call":
            jump endfirst
        "Fold[TEMP2!t]":
            jump foldfirst

label endfirst:
    d "I call!"
    $ moneypoker = moneypoker - 100
    emerick "Alright!"
    beth "Guys, show your hands!"
    scene pokerpartyfinfirst1
    with dissolve
    emerick "Two pair, King-Queen!"
    d "Damn..."
    scene pokerpartyfinfirst2
    with dissolve
    hec "7 and 2..."
    ben "Pfft..."
    d "What?"
    mac "Nothing, nothing..."
    emerick "This is off to a good start!"
    scene black
    with fade
    pause 1
    jump secondhand

label secondhand:
    scene black
    with fade
    pause 1 
    show text _ ("A few hands later...") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    scene pokerpartyfinben
    with dissolve
    ben "It's impossible to be this lucky..." with hpunch
    scene pokerpartyfinben2
    with dissolve
    emerick "That's the game, Ben!"
    scene pokerpartyfinben3
    with dissolve
    ben "Yeah, yeah... Well, I'm out, guys..."
    mac "Good night, Ben!"
    hec "Night..."
    scene pokerpartyfinben4
    with dissolve
    emerick "Alright guys, how much do you have left?"
    hec "400..."
    dpense "I have [moneypoker]$..."
    dpense "Gotta manage this..."
    d "[moneypoker]..."
    emerick "And you, Mac?"
    mac "I've been steady at 1000 since the beginning..."
    emerick "Let's keep going!"
    scene pokerpartyaa
    with dissolve
    dpense "Aces!"
    dpense "Now that's interesting!"
    if bethhelp == True:
        beth "You have the best hand in the game."
        beth "You need to bet when you have the advantage."
        beth "You act last, let's see what the others do..."
    scene pokerpartyemerick1
    with dissolve
    emerick "I bet 100!"
    hec "I call..."
    mac "I call..."
    if bethhelp == True:
        beth "Go ahead, raise!"
    menu:
        "Call":
            $ moneypoker = moneypoker - 100
            jump callsecond
        "Raise":

            $ moneypoker = moneypoker - 200
            jump raisesecond
        "Fold[TEMP2!t]":

            jump foldsecond

label callsecond:
    scene pokerpartybet100
    with dissolve
    d "I call..."
    if bethhelp == True:
        beth "Well... At least they won't see you coming..."
    jump boardsecond

label foldsecond:
    scene pokerpartyfold1
    with dissolve
    d "I don't feel it..."
    if bethhelp == True:
        beth "Are you serious?"
        d "What?"
        beth "Never mind..."
    $ pokersequence22 = True
    jump free22

label raisesecond:
    scene pokerpartycartes
    with dissolve
    d "I raise!"
    if bethhelp == True:
        beth "Perfect."
    emerick "I call..."
    hec "I call..."
    mac "I call..."
    jump boardsecond

label boardsecond:
    beth "The board guys..."
    scene pokerpartyboard2
    with dissolve
    beth "Nine of Clubs. Jack of Spades. Queen of Spades."
    dpense "Hmm..."
    if bethhelp == True:
        beth "Yeah... this board is not in your favor... Nine-Jack-Queen..."
        beth "You're already beaten by two pairs, trips, straights... there's even a flush possible at the end..."
        beth "Wait to see what the others do..."
    emerick "I bet 100!"
    scene hectorallin
    with dissolve
    hec "I'm all in!"
    emerick "Oh-oh! Someone's got a hand!"
    scene macfold2
    with dissolve
    mac "I fold."
    dpense "What do I do?"
    if bethhelp == True:
        beth "Fold... This smells like trouble..."
        beth "In poker, if you have a doubt... there's no doubt..."
        beth "You're clearly not in a good position..."
        beth "Save what you have left, you can still come back later..."
    menu:
        "Call":
            scene mcchipsboard
            with dissolve
            $ moneypoker = moneypoker - 200
            if moneypoker == 0:
                d "All in!"
                $ allin = True
                jump turnsecond
            else:
                d "I call!"
                emerick "I call!"
                jump turnsecond

        "Raise" if moneypoker>200:
            scene mcchipsboard
            with dissolve
            $ moneypoker = moneypoker - 200
            if moneypoker == 0:
                d "All in!"
                $ allin = True
                jump turnsecond
            else:

                d "I raise!"
                emerick "I call!"
                jump turnsecond
        "Fold[TEMP2!t]":

            scene pokerpartyfold1
            with dissolve
            d "I fold..."
            emerick "Well Hector's all in... Show your hand!"
            scene hectorset
            with dissolve
            hec "Set of 9s!"
            emerick "Oh yeah!"
            scene emeshow2
            with dissolve
            emerick "Not bad... I've got King-Jack..."
            sofia "Here's the turn..."
            scene turn2
            with dissolve
            sofia "2 of Hearts..."
            emerick "You're still good, Hector!"
            hec "No bad beat... No bad beat..."
            emerick "Come on! We want the river!"
            sofia "Here's the river..."
            scene river2
            with dissolve
            sofia " Ten of Spades..."
            emerick "BOOM!!!" with vpunch
            scene emerickhappy
            with dissolve
            emerick "Straight, baby!" with hpunch
            hec "Damn it..."
            emerick "Oh come on Hector, it's not that bad!"
            scene hecpart
            with dissolve
            hec "Go to hell!"
            emerick "Haha! Let's keep going!"
            scene black
            with fade
            pause 1
            $ pokersequence22 = True
            jump free22

label turnsecond:
    if allin == True:
        emerick "Well guys, you're both all in... Show your hands!"
        scene hectorset
        with dissolve
        hec "Set of 9s!"
        d "Pocket aces!"
        emerick "Oh yeah!"
        scene emeshow2
        with dissolve
        emerick "Not bad... I've got King-Jack..."
        sofia "Here's the turn..."
        scene turn2
        with dissolve
        sofia "2 of Hearts..."
        emerick "You're still good, Hector!"
        hec "No bad beat... No bad beat..."
        dpense "I need an ace..."
        emerick "Come on! We want the river!"
        sofia "Here's the river..."
        scene river2
        with dissolve
        sofia "Ten of Spades..."
        emerick "BOOM!!!" with vpunch
        scene emerickhappy
        with dissolve
        emerick "Straight, baby!" with hpunch
        hec "Damn it..."
        emerick "Oh come on Hector, it's not that bad!"
        scene hecpart
        with dissolve
        hec "Go to hell!"
        emerick "And thank you for coming, Frenchie! Thanks for your money!"
        $ pokerlost = True
        jump free22
    else:

        sofia "Here's the turn..."
        scene turn2
        with dissolve
        sofia "2 of Hearts..."

    emerick "I bet 100!"
    menu:
        "Call":
            $ moneypoker = moneypoker - 100
            if moneypoker == 0:
                d "All in!"
                $ allin = True
                jump riversecond
            else:
                d "I call..."
                jump riversecond

        "Raise" if moneypoker>200:
            $ moneypoker = moneypoker - 200
            if moneypoker == 0:
                d "All in!"
                $ allin = True
                jump riversecond
            else:

                d "I raise!"
                emerick "I call!"
                jump riversecond
        "Fold[TEMP2!t]":

            scene pokerpartyfold1
            with dissolve
            d "I fold..."
            emerick "Well Hector's all in... Show your hand!"
            scene showturn
            with dissolve
            hec "Set of 9s!"
            emerick "Oh yeah!"
            emerick "Not bad... I've got King-Jack..."
            emerick "You're still good, Hector!"
            hec "No bad beat... No bad beat..."
            emerick "Come on! We want the river!"
            sofia "Here's the river..."
            scene river2
            with dissolve
            sofia "Ten of Spades..."
            emerick "BOOM!!!" with vpunch
            scene emerickhappy
            with dissolve
            emerick "Straight, baby!" with hpunch
            hec "Damn it..."
            emerick "Oh come on Hector, it's not that bad!"
            scene hecpart
            with dissolve
            hec "Go to hell!"
            emerick "Haha! Let's keep going!"
            scene black
            with fade
            pause 1
            $ pokersequence22 = True
            jump free22

label riversecond:
    if allin == True:
        emerick "Well guys, you're both all in... Show your hands!"
        scene showturn
        with dissolve
        hec "Set of 9s!"
        d "Pocket aces!"
        emerick "Oh yeah!"
        emerick "Not bad... I've got King-Jack..."
        emerick "You're still good, Hector!"
        hec "No bad beat... No bad beat..."
        dpense "I need an ace..."
        emerick "Come on! We want the river!"
        sofia "Here's the river..."
        scene river2
        with dissolve
        sofia "Ten of Spades..."
        emerick "BOOM!!!" with vpunch
        scene emerickhappy
        with dissolve
        emerick "Straight, baby!" with hpunch
        hec "Damn it..."
        emerick "Oh come on Hector, it's not that bad!"
        scene hecpart
        with dissolve
        hec "Go to hell!"
        emerick "And thank you for coming, Frenchie! Thanks for your money!"
        $ pokerlost = True
        jump free22
    else:

        sofia "Here's the river..."
        scene river2
        with dissolve
        sofia "Ten of Spades..."
        emerick "I bet 100!"
    menu:
        "Call":
            $ moneypoker = moneypoker - 100
            d "I call..."
            if moneypoker == 0:
                d "All in!"
                $ allin = True
            jump finalsecond

        "Raise" if moneypoker>200:
            $ moneypoker = moneypoker - 200
            if moneypoker == 0:
                d "All in!"
                $ allin = True
                jump finalsecond
            else:

                d "I raise!"
                emerick "I call!"
                jump finalsecond
        "Fold[TEMP2!t]":

            scene pokerpartyfold1
            with dissolve
            d "I fold..."
            emerick "Well Hector's all in... Show your hand!"
            scene hideriver2
            with dissolve
            hec "Set of 9s!"
            emerick "Oh yeah!"
            emerick "Not bad... But..."
            scene showriver2
            with dissolve
            emerick "BOOM!!!" with vpunch
            scene emerickhappy
            with dissolve
            emerick "Straight, baby!" with hpunch
            hec "Damn it..."
            emerick "Oh come on Hector, it's not that bad!"
            scene hecpart
            with dissolve
            hec "Go to hell!"
            emerick "Haha! Let's keep going!"
            scene black
            with fade
            pause 1
            $ pokersequence22 = True
            jump free22

label finalsecond:

    emerick "Well Hector's all in... Show your hand!"
    scene hideriver2
    with dissolve
    hec "Set of 9s!"
    emerick "Oh yeah!"
    emerick "Not bad... But..."
    scene showriver2
    with dissolve
    emerick "BOOM!!!" with vpunch
    scene emerickhappy
    with dissolve
    emerick "Straight, baby!" with hpunch
    hec "Damn it..."
    emerick "Oh come on Hector, it's not that bad!"
    scene hecpart
    with dissolve
    hec "Go to hell!"
    if allin == True:
        emerick "And thank you for coming, Frenchie! Thanks for your money!"
        scene black
        with fade
        pause 1
        $ pokerlost = True
        jump free22
    else:
        emerick "Haha! Let's keep going!"
        scene black
        with fade
        pause 1
        $ pokersequence22 = True
        jump free22

label twistersequence:
    play music "musique/ARS0038-BackToLife-stockmusic-net.mp3" volume 0.2
    scene twister1
    with fade
    pause 2 
    scene twister2
    with dissolve
    ruby "Alright, let's get started!"
    ruby "Who wants to play?"
    scene twister3
    with dissolve
    kira "I'm in!"
    s "Me too!"
    scene twister4
    with dissolve
    ruby "Okay! Steven, Kira...."
    ruby "[name] ?"
    scene twister5
    with dissolve
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3191
        $ TEMP2 = ep3192
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Yeah, I'm in[TEMP1!t]":
            jump twister1
        "No, thanks":
            scene black
            with fade
            jump free22

label twister1:
    scene twister6
    with dissolve
    mad "Oh, come on, count me in too!"
    ruby "Great!"
    scene twister7
    with dissolve
    ruby "So I'll be the one spinning the wheel!"
    ruby "And when someone falls, they're out and get a forfeit!"
    dpense "I hope she doesn't go too far with these forfeits..."
    scene twister8
    with dissolve
    dpense "Madison's athletic body and those impressive breasts are definitely going to be a distraction..."
    scene twister9
    with dissolve
    dpense "And Kira... that slim figure with such a round, perfect butt. This is going to be interesting."
    scene twister10
    with dissolve
    pause 2 
    scene twister11
    with dissolve
    ruby "Alright, let's get started!"
    scene twister12
    with dissolve
    ruby "First spin... Right hand red!" with hpunch
    scene twister13
    with vpunch
    kira "Easy enough."
    s "Got it."
    d "Alright, here we go."
    mad "Piece of cake!"
    scene twister11
    with dissolve
    ruby "Next spin... Left foot green!" with hpunch
    scene twister14
    with dissolve
    kira "Stretching a bit now."
    s "Not too bad."
    d "I can manage this."
    mad "Feeling good so far!"
    dpense "Madison's stretch shows off her athletic build. She's really fit."
    dpense "Kira's movements accentuate her curves. That ass is something else."
    ruby "Right foot blue!" with hpunch
    scene twister15
    with dissolve
    kira "Getting tricky."
    s "Whoa, almost lost my balance!"
    d "Careful, Steven!"
    mad "I'm good, I'm good."
    ruby "Left hand yellow!" with hpunch
    scene twister16
    with dissolve
    kira "Okay, this is tough."
    s "I'm slipping!"
    d "Hold on, Steven!"
    mad "Focus, Steven!"
    scene twister17
    with flash
    with vpunch
    ruby "Steven, you're out!"
    s "Damn it!"
    scene twister18
    with dissolve
    ruby "Forfeit time! You have to run around the house in your underwear."
    s "Seriously?"
    s "Alright, a bet's a bet."
    scene black
    with fade
    pause 1
    scene twister19
    with fade
    s "I'll be back soon!"
    scene black
    with fade
    "laughs"
    scene twister11
    with fade
    ruby "Alright, let's keep going!"
    ruby "Three players left!"
    ruby "Next spin... Right hand green!" with hpunch
    scene twister20
    with dissolve
    kira "Got it."
    d "Easy enough."
    mad "Still in the game."
    scene twister21
    with dissolve
    dpense "Madison's endurance is impressive. She looks amazing."
    dpense "Kira's focus is admirable, and her figure is stunning."
    ruby "Left foot red!" with hpunch
    scene twister22
    with dissolve
    kira "Almost lost it there!"
    d "Careful!"
    mad "Still stable."
    ruby "Right foot yellow!" with hpunch
    scene twister23
    with dissolve
    kira "I'm feeling the strain."
    d "Just a bit more."
    mad "I've got this."
    dpense "Madison's détermination is clear."
    scene twister24
    with flash
    with dissolve
    ruby "Kira, you're out!"
    scene twister25
    with dissolve
    kira "Oh well, it was fun while it lasted."
    ruby "Kira, your forfeit is..."
    ruby "You have to kiss anyone you want!"
    scene twister26
    kira "Hmm, interesting..."
    kira "Alright, I choose [name]!"

    if madipath == True:
        scene twister27
        with dissolve
        mad "Really, Kira?"
        mad "You just had to pick [name], didn't you?"
        kira "Why? Jealous?"
        scene twister28
        with dissolve
        mad "Me? NO!"
        mad "Do what you want..."

    scene twister29
    with dissolve
    pause 2 
    scene twister30
    with dissolve
    dpense "This kiss is something..."
    if madipath == True:
        scene twister32
        with dissolve
        dpense "but Madison's reaction is even more intriguing."
    scene twister31
    with dissolve
    ruby "Okay, let's move on! Two players left... [name] and Madison!"
    scene twister33
    with dissolve
    ruby "We will complicate things!"
    ruby "Next spin... Both hands blue!" with hpunch
    scene twister34
    with dissolve
    mad "Stretching..."
    d "Almost there..."
    dpense "Madison's stretch shows off her impressive physique. She's so close I can feel her body heat."
    ruby "Right foot green!" with hpunch
    scene twister35
    with dissolve
    mad "Close one!"
    d "Just a bit more..."
    dpense "Our bodies are getting closer, the tension is palpable."
    ruby "Left foot yellow!" with hpunch
    scene twister36
    with dissolve
    mad "Holding steady..."
    d "Almost lost it there!"
    dpense "Madison's body is pressing against mine, her curves are impossible to ignore."
    ruby "Okay it's gonna be harder!"
    ruby "Both hands blue! But not the same!" with hpunch
    scene twister37
    with dissolve
    mad "This is getting intense!"
    d "Tell me about it..."
    dpense "We're so close... I can feel her breath on my skin..."
    scene twister38
    with dissolve
    dpense "Her body is pressed against mine, and I can't help but notice how soft she feels."
    dpense "Our faces are inches apart, and I can see the spark in her eyes. This game is getting more intense than I expected."
    mad "Looks like it's just you and me..."
    d "Yeah... This is... interesting."
    dpense "Her body is practically molded to mine, the tension is electric."
    scene black
    with flash
    scene twister39
    with vpunch
    with flash
    ruby "Madison, you're out! [name], you win!"
    scene twister40
    with dissolve
    mad "Damn, that was close."
    d "Good game, Madison."
    scene twister41
    with dissolve
    ruby "Alright [name], you're the Twister champion!"
    scene twister42
    with dissolve
    mad "I guess I'll be taking my forfeit now."
    ruby "Madison, your forfeit is to... hmm... what should it be?"
    dpense "Let's see what she comes up with..."
    ruby "How about... you have to kiss [name] too?"
    mad "Oh, that's easy."
    scene twister43
    with dissolve
    ruby "No, not just a peck. A real kiss."

    if madipath == True:
        mad "Oh, you mean like this?"
        mad "Come here, [name]."
        scene twisterkiss1
        with dissolve
        pause 1 
        scene twisterkiss2
        $ renpy.movie_cutscene("images/animation/twisterkiss.webm", stop_music=False)
        scene twisterkiss2
        dpense "Wow, she's really going for it... I can feel every inch of her body against mine. This is intense."
    else:
        mad "Alright then."
        scene twister44
        with dissolve
        dpense "Her lips are so soft... This feels nice, but I can't help but wonder if it could be more."

    scene twister46
    with dissolve
    ruby "Alright. Steven should be back any moment now."
    call sport_increased from _call_sport_increased_18
    if madipath == True:
        dpense "Madison's gaze lingers on me, and I can't help but wonder what she's thinking."
    scene black
    with fade
    pause 1 
    jump free22
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
