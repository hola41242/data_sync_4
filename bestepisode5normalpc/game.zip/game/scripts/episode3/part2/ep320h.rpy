label ep320h:
    scene black
    with fade
    pause 1 
    show text _ ("8:00 PM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/ARS0038-BackToLife-stockmusic-net.mp3" volume 0.2
    scene 20h03
    with dissolve
    pause 2
    scene 20h04
    with dissolve
    pause 2
    scene 20h05
    with dissolve
    pause 2
    scene 20h06
    with dissolve
    emerick "So, are you ready to party with me tonight guys?"
    "Yeah!"
    scene 20h01
    with pushdown
    pause 2
    scene 20h02
    with dissolve
    pause 2
    scene 20h07
    with dissolve
    pause 2 
    scene 20h11:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    emerick "Frenchie! You know how to dress now?"
    scene 20h08
    with dissolve
    emerick "The clothes do not make the man you know?"
    scene 20h09
    with dissolve
    hec "Well, the White Knight..."
    hec "You don't have your Pinkie with you?"
    scene 20h10
    with vpunch
    mad "You should shut up Hector, or I'll make sure you regret opening your mouth!"
    emerick "Well, well... Madison defending the oppressed..."
    scene 20h12
    with dissolve
    pause 0.1 
    scene 20h13
    with dissolve
    pause 0.1
    scene 20h12
    with dissolve
    pause 0.1 
    scene 20h13
    with dissolve
    pause 0.1 
    scene 20h15
    with dissolve
    pause 0.1
    scene 20h14
    with dissolve
    pause 0.1
    scene 20h15
    with dissolve
    pause 0.1 
    scene 20h14
    with dissolve
    pause 0.1
    scene 20h16
    with dissolve
    pause 1
    scene 20h17
    with dissolve
    pause 2 
    scene 20h18
    with dissolve
    pause 2 
    scene 20h19
    with dissolve
    julia "We've seen it all..."
    scene 20h20
    with dissolve
    julia "But thanks Madison... I appreciate the support."
    scene 20h21
    with dissolve
    d "Alright... You need to tell me something..."
    ruby "What?"
    d "Do you all really have a problem with hair or something?"
    scene 20h22
    with dissolve
    ruby "Huh?"
    d "Well you, Madison, Julia... soon Grace will have blue hair too..."
    ruby "Hasn't anyone told you that women often change?"
    d "Huh?"
    ruby "Well yeah... If something... Or someone causes a change in a woman..."
    ruby "She changes..."
    d "And what makes you all change like this one by one?"
    scene 20h23
    with dissolve
    ruby "Guess, big dummy!"
    ruby "And there's also a group effect!"
    ruby "Kind of like menstrual cycle synchronization..."
    d "Ruby..." with hpunch
    scene 20h22
    with dissolve
    ruby "What?"
    scene 20h08
    with vpunch
    emerick "Alright, there's a table waiting for us guys!"
    "Yeah!"
    scene 20h24
    with dissolve
    emerick "Of course, I wasn't talking about you, Frenchie."
    d "..."
    "You're right, dear cousin, go lock yourself up and go play with your limp dicks!" with vpunch
    stop music fadeout 2
    scene 20h25
    with dissolve
    d "Who..."
    play music "musique/FB01-DropItNow-Labes.mp3" volume 0.2
    scene 20h26
    with dissolve
    "And while you're at it, try not to scam them too much!"
    scene 20h27
    with dissolve
    "The poor guys, they already have no honor, it would be worse if you took their money..."
    scene 20h28
    with dissolve
    ruby "The Princess has arrived..."
    scene 20h29
    with dissolve
    d "The Princess?"
    scene 20h30:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    ruby "Yes... Let me introduce you to..."
    ruby "Kira Orushi."
    d "Orushi?" with hpunch
    ruby "Yep... His daughter."
    ruby "She's Emerick's cousin and... How to say..."
    scene 20h32
    with dissolve
    ruby "He shrinks when she's around."
    ruby "If Emerick acts like a big shot with his influence..."
    ruby "Kira can kick him out of any place with just a snap of her fingers."
    scene 20h31
    with dissolve
    d "Really?"
    scene 20h33
    with dissolve
    ruby "Yes... Look at them walking away with their heads down."
    ruby "They look like beaten dogs..."
    d "But why..."
    scene 20h34
    with dissolve
    ruby "She's one of the most powerful girls in the country..."
    ruby "Influencer, power, her father's company that she inherits..."
    scene 20h35
    with dissolve
    ruby "And a lot of businesses she runs masterfully."
    ruby "She controls her image perfectly..."
    ruby "And..."
    scene 20h36
    with dissolve
    kira "And I haven't introduced myself yet!"
    kira "I'm Kira. And I welcome you to our country!"
    if Training2 == True:
        kira "Sorry again for earlier on the field..."
        kira "But I wanted to shake you up a bit... I'm sure you can do better."
    scene 20h37
    with dissolve
    kira "Alright, let's enjoy this evening?"
    scene 20h38
    with dissolve
    ruby "Uh, yes..."
    kira "Don't worry Ruby, everything will be fine! And I trust you, I'm sure you've prepared some great things for all of us!"
    scene 20h39
    with dissolve
    ruby "Yes, yes! So, in fact, every hour there will be activities offered in various places of the house"
    ruby "You just have to walk around and you can choose which activity you want to participate in!"
    ruby "And if you don't know what to do or if you get lost..."
    scene 20h40
    with dissolve
    ruby "Come ask me!"
    kira "Great! I can't wait to see it all!"
    scene 20h41
    with dissolve
    grace "So I think it's time to get this evening started!"
    "Yeah!" with hpunch
    stop music fadeout 2
    scene black
    with fade
    play music "musique/FRR0010-FunkMe-stockmusic-net.mp3" fadein 2 volume 0.2

    $ moneypoker = 0
    $ allin = False
    $ pokerlost = False
    $ pokersequence22 = False
    $ enterpoker = True
    $ invitepoker = False
    $ bluebathinvite20 = False
    $ bluebath20 = False
    $ pregnancy = False
    $ juliadiscuss20 = True
    $ madigracediscuss20 = True
    $ rubydiscuss20 = True
    $ kiradiscuss20 = True
    $ debilesdiscuss20 = True
    $ reddiscuss20 = False
    $ bluediscuss20 = False
    $ emerickdiscuss20 = True
    $ bethhelp = False
    $ bluelove = False
    if BlueRelation == True:
        $ bluediscuss20 = True
    if Redpath == True:
        $ reddiscuss20 = True
    $ bluebathsequence = False
    $ freepokersequence = False
    $ pokerparty = False


    $ juliadiscuss20_progress = 0
    $ rubydiscuss20_progress = 0
    $ madigracediscuss20_progress = 0
    $ kiradiscuss20_progress = 0
    $ debilesdiscuss20_progress = 0
    $ emerickdiscuss20_progress = 0
    $ emerick20_access = False

    if BlueRelation:
        $ bluediscuss20_progress = 0
    if Redpath:
        $ reddiscuss20_progress = 0




    jump free20
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
