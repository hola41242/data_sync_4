label free20:

    $ expanded = False

    label free20main:

        if bluebathinvite20 == True:
            phone discussion "sofia1":
                time year 2023 month 9 day 5 hour 20 minute 30
                "sofia" "Meet me in the bathroom up there"
                "d" "Um... Why?"
                "sofia" "Hurry up... We don't have much time..."
            phone end discussion

            dpense "My heart skipped a beat at her words. I didn't expect this from Sofia. Should I go?"
            if persistent.patch_enabled == True:
                $ TEMP1 = ep3201
                $ TEMP2 = ep3202
            else:
                $ TEMP1 = ""
                $ TEMP2 = ""
            menu:
                "Accept[TEMP1!t]":
                    phone discussion "sofia1":
                        time year 2023 month 9 day 5 hour 20 minute 31
                        "d" "Okay... I'll be right there."
                    phone end discussion
                    $ bluebath20 = True
                    $ bluebathinvite20 = False
                    jump free20main
                "Decline[TEMP2!t]":

                    phone discussion "sofia1":
                        time year 2023 month 9 day 5 hour 20 minute 31
                        "d" "I'm not sure if that's a good idea..."
                        "sofia" "I understand... Maybe some other time then."
                    phone end discussion

                    $ bluebath20 = False
                    $ bluebathinvite20 = False
                    $ bluediscuss20_progress = 2
                    jump free20main

        call screen free20main() with fade

    label free20garden:
        call screen free20garden() with fade  

    label free20poker:
        if enterpoker == True:
            scene poker
            with fade
            pause 2 
            scene free20poker1
            with dissolve
            emerick "You're not invited, Frenchie! You can go back to your harem!"
            d "What's your problem, Emerick?"
            scene free20poker2
            with dissolve
            emerick "My problem? You're not invited so... Fuck off!"
            d "I'm just here to have a good time, same as everyone else."
            emerick "I don't care!"
            scene black
            with dissolve
            pause 0.5
            $ kiradiscuss20_progress = 1
            $ enterpoker = False
        call screen free20poker() with fade 

    label free201st:
        call screen free201st() with fade


label julia20:
    scene free20main1
    with fade
    pause 2 
    scene free20main2
    with dissolve
    julia "Hi!"
    d "Hi! Is your back feeling better?"
    scene free20main3
    with dissolve
    julia "It's better, but I'm still taking it easy."
    julia "I think I'll stay for a bit for the girls, but I won't be able to do everything Ruby has planned..."
    d "Haha! I don't know what I'm going to do yet!"
    scene free20main5
    with dissolve
    julia "Have fun, that's the main thing!"
    d "We'll try!"
    if JuliaPath == True:
        d "Are you drinking something?"
        julia "No, better not with the medication..."
        d "Okay!"
        d "Oh, by the way, I love your new haircut!"
        scene free20main4
        with dissolve
        julia "Oh? Thanks!"
        d "You like changing your hairstyle, don't you? Every time I see you, you have a new one!"
        julia "Hmm... Well, actually this time it's because that jerk called me Pinkie and it pissed me off..."
        d "Oh... I understand..."
        julia "So he will probably leave me alone now."
        scene free20main6
        with dissolve
        julia "And honestly, I kind of like it this way so maybe I'll keep it this time!"
        d "Haha! It's up to you!"
        d "Though it's kind of funny to see you change hairstyles..."
        d "I like thinking of what you'll look like next. It's always a fun surprise!"
        scene free20main7
        with dissolve
        julia "A surprise?"
        d "Yes! You're a bit unpredictable, but don't worry. I like that!"
        scene free20main8
        with dissolve
        julia "You like unpredictable girls?"
        d "I like girls who surprise me."
        scene free20main9
        with dissolve
        julia "Noted!"
    scene free20main2
    with dissolve
    d "I'm going to see what the others are doing! See you later?"
    julia "See you later!"
    scene black
    with dissolve
    pause 0.5
    $ juliadiscuss20 = False
    $ juliadiscuss20_progress = 2
    jump free20

label ruby20:
    if rubydiscuss20 == True:
        scene free20ruby1
        with fade
        ruby "Hey! So are you ready for tonight?"
        d "Sure!"
        scene free20ruby2
        with dissolve
        ruby "Well, the first activity I have planned is to play Twistplay!"
        d "Oh my god... It's been a long time since I've played this..."
        scene free20ruby3
        with dissolve
        ruby "It's like riding a bike! Don't worry, it's just for fun!"
        ruby "There are no prizes to win, just fun!"
        ruby "So..."
        $ rubydiscuss20 = False

    scene free20ruby4
    with dissolve
    ruby "Do you want to play Twistplay?"
    menu:
        "Yes (Advance time and ends free-roam)":
            $ rubydiscuss20_progress = 2
            d "Yes, of course!"
            scene black
            with dissolve
            pause 0.5
            jump free21
        "No, maybe later...":
            $ rubydiscuss20_progress = 1
            d "No thanks"
            scene black
            with dissolve
            pause 0.5
            jump free20


label gracemadison20:
    scene free20mg1
    with fade
    mad "And he doesn't even tell me she has been sick all day until I asked about the puke on her clothes!"
    mad "He didn't even change her out of them. I swear!"
    scene free20mg2
    with dissolve
    grace "You really can't trust him..."
    scene free20mg3
    with dissolve
    mad "I don't trust any man in my life anymore!"
    mad "I've told you! Better to be alone than in bad company!"
    scene free20mg4
    with hpunch
    grace "They're not all like that though!"
    mad "If you manage to find one that's not like that, you better hold on to him!"

    if Gracepath == True:
        scene free20mg5
        with dissolve
        grace "You never know, we might find someone who can satisfy us."
        mad "Like a perfect guy falling from the sky? That's not gonna happen, hun!"
        scene free20mg6
        with dissolve
        grace "Why wait for him to fall?"
        grace "I could just meet him in the sky!"
        scene free20mg7
        with dissolve
        mad "Huh???"
        scene free20mg8
        with dissolve
        pause 2
    scene free20mg9
    with dissolve
    d "What are you talking about?"
    mad "Oh you know, responsibilities, relationship, kids."
    mad "Just some girl talk!"
    scene free20mg10
    with dissolve
    grace "Hey [name]! Would you like to have children?"
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3203
        $ TEMP2 = ep3204
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Yes[TEMP1!t]":
            d "Someday, yes! But I'm not in a hurry!"
            $ pregnancy = True
            mad "Yeah, he's young, he has plenty of time!"
            grace "Yes, that's true. It's good to know though!"
        "No[TEMP2!t]":
            d "No, honestly, I don't think kids are for me."
            $ pregnancy = False
            mad "At least he's honest..."
            grace "You never know, he could change his mind later."
            d "I don't know... Anyway, for now, it's definitely not in my plans!"

    scene free20mg11
    with dissolve
    mad "I've got my hands full with mine for now!"
    scene free20mg12
    with dissolve
    grace "Haha! I can imagine! Plus, your brother is more work than help!"
    d "Her brother?"
    scene free20mg13
    with dissolve
    grace "Yeah, her brother takes care of her daughter when she's at the Academy or traveling for matches..."
    mad "But it's not going well!"
    mad "The guy is slumped on the couch all day, and when it comes to taking care of a little one... He's nowhere to be found."
    scene free20mg14
    with dissolve
    grace "Come on, Maddie! Relax and have a drink, it'll be better!"
    mad "Yeah, you're right! Let's stop thinking about it and enjoy the evening!"
    grace "That's right! Let's toast to..."
    scene free20mg15
    with dissolve
    grace "To what?"
    d "To our meeting?"
    scene free20mg16
    with dissolve
    grace "Yeah, that's it! To our meeting, to this competition, and to this year which will surely be full of surprises!"
    scene black
    with fade
    "Cheers!" with hpunch
    pause 1
    $ madigracediscuss20 = False
    $ madigracediscuss20_progress = 2
    jump free20

label kira20:
    scene free20mira
    with fade
    pause 2 
    scene free20mira2
    with dissolve
    pause 2
    scene free20mira3
    with dissolve
    kira "Hey! [name], right?"
    scene free20mira5
    with dissolve
    d "Yes!"
    scene free20mira6
    with dissolve
    kira "Let me introduce you to Fanny!"
    d "Nice to meet you!"
    scene free20mira7
    with dissolve
    kira "Oh, don't worry, she doesn't understand anything you're saying!"
    d "Huh?"
    scene free20mira8
    with dissolve
    kira "Yeah, she's from another country, and she doesn't speak our language."
    d "Uh... So why is she here then?"
    kira "Well, our school has foreign exchange programs for languages. You know, for international trade."
    scene free20mira9
    with dissolve
    kira "So I'm her host but she doesn't seem interesting in learning our language"
    kira "She has a perfect figure, ideal bod and pretty face though."
    kira "So, I took the opportunity to become her OSM."
    d "Her OSM?"
    scene free20mira10
    with dissolve
    kira "OnlyStan Manager!"
    d "What's that?"
    kira "Um... Do you know OnlyStan?"
    scene free20mira9
    with dissolve
    d "I've heard about it. It's that content creator platform that's kind of..."
    kira "Adult, yeah. It hosts a bit of everything though!"
    kira "And since she doesn't know what she wants to do."
    kira "I opened an account for her on there to make her some money!"
    d "How so?"
    scene free20mira10
    with dissolve
    kira "Basically, she doesn't touch the account, I manage it."
    kira "I prepare a weekly schedule for her like. Monday you go to the beach and take bikini photos."
    kira "Tuesday you go to the pool... Wednesday you take photos of yourself in bed..."
    d "And she does it?"
    kira "Well, yes! She was already spending her time on her phone pouting anyway."
    kira "We're not changing anything... We're just making money with her photos!"
    scene free20mira9
    with dissolve
    d "Um... What if they ask for more risqué stuff?"
    kira "Oh, that's up to her! I pass on the requests, and she decides if she wants to do them or not."
    d "Oh..."
    kira " I mean, that's what you do if you want to make good money. Subs are good, but photos with a more personal request is how you really earn."
    d "Isn't that close to prostitution?"
    scene free20mira11
    with dissolve
    kira "Well, I guess that makes me the hottest and prettiest pimp you've met!"
    d "I didn't mean it like that. It's just that you are making money of her body"
    scene free20mira12
    with dissolve
    kira "Haha! Well, she's not complaining!"
    d "Well, if she doesn't speak the language, she can't..."
    kira "And she gets 80 percent of what she makes, I only take 20 percent for managing, organizing, and responding to messages for her."
    d "Oh, so it's not her responding?"
    scene free20mira13
    with dissolve
    kira "Nope! She couldn't!"
    kira "So I pretend to be her and I encourage the guys who talk to her to like her photos and check out the new ones."
    d "It sounds like a pretty good setup."
    kira "Yeah, it also trains me for other projects! I won't do this all my life! It's more of a hobby."
    d "Weird hobby though!"
    scene free20mira12
    with dissolve
    kira "Haha! Okay, I'm going to tell her to take a photo now, you'll see!"
    kira "Fanny! Go to the middle of the room, I'm going to take a picture of you."
    "Okay."
    scene free20mira14
    with dissolve
    kira "See, she does what I say!"
    kira "Now, show more of your butt!"
    scene free20mira15
    d "Okay... I'll leave you two to it! See you later?"
    kira "Yeah! And check out her OnlyStan if you're interested!"
    d "Uh... I'll think about it!"
    scene black
    with dissolve
    pause 1
    $ kiradiscuss20 = False
    $ kiradiscuss20_progress = 2
    jump free201st

label debiles20:
    scene free20debiles1
    with fade
    mac "And then the guy calls me all the way to the river!"
    ben "Damn!"
    scene free20debiles2
    with dissolve
    mac "Yeah, and I had pocket aces, you see!"
    ben "Damn!"
    mac "Well, he hit his flush, don't worry!"
    mac "And my aces got cracked again!"
    ben "Damn!"
    scene free20debiles3
    with dissolve
    mac "Yeah! I swear, these guys don't know how to play!"
    ben "Yeah, same here the other day..."
    "Well then?" with hpunch
    scene free20debiles4
    with dissolve
    d "Huh?"
    scene free20debiles5
    with dissolve
    s "You're not waiting for Steven?"
    "Yeah!" with hpunch
    s "The king of the party is here!"
    "Yeah!" with hpunch
    scene free20debiles6
    with dissolve
    d "The king of the party?"
    sofia "Yeah, the guy thinks he's hot stuff..."
    scene free20debiles7
    with dissolve
    d "Huh?"
    scene free20debiles8
    with dissolve
    sofia "Basically, these guys throw a party every year and think it's the best party they can attend..."
    sofia "But in the end, they just end up with each other, don't plan anything, drink, and pass out on their couch..."
    scene free20debiles9
    with dissolve
    sofia "The kings of the party."
    d "Meh..."
    scene free20debiles10
    with dissolve
    s "Let's show these girls what a real man is!"
    "Yeah!" with hpunch
    scene black
    with dissolve
    pause 1
    $ debilesdiscuss20 = False
    $ debilesdiscuss20_progress = 2
    jump free20garden

label blue20:
    scene free20blue
    with fade
    pause 2 
    scene free20blue1
    with dissolve
    d "What are you doing here all alone?"
    scene free20blue2
    with dissolve
    sofia "I'm getting some fresh air before everyone starts getting excited!"
    d "Getting excited?"
    sofia "Yeah, you know. The alcohol, the games..."
    d "You don't like that too much?"
    scene free20blue3
    with dissolve
    sofia "I do, I do... But I also like when I can have a bit of peace and quiet sometimes."
    d "Is something bothering you?"
    sofia "Ah. Uh..."
    dpense "She's clearly troubled by something."
    dpense "Maybe I should say something to make her feel better."
    d "I'm not sure why you decided not to wear the blue makeup but you look really good without it."
    scene free20blue4
    with dissolve
    sofia "Really?"
    d "Yes... I don't know how to say it, but it's like something in you has changed."
    sofia "Yes... Well, not yet."
    d "And are you going to change your hairstyle like the others?"
    scene free20blue5
    with dissolve
    sofia "Uh... I haven't thought about it yet."
    scene free20blue6
    with dissolve
    d "Haha! I'm just kidding! It's just that all the girls seem to be changing, and I thought you might want to stand out from..."
    scene free20blue7
    with dissolve
    sofia "My sister..."
    d "Uh... No, I was going to say from the others, but."
    sofia "Oh. Yes. I don't know."
    sofia "I'm going to head up to the washroom before the party really gets going. Take a minute to clear my head, you know?"
    scene free20blue8
    with dissolve
    d "Ah? Okay!"
    d "See you later then?"
    sofia "Yes, see you later!"
    dpense "She has a problem with her sister?"
    dpense "Weird..."
    scene black
    with dissolve
    pause 1
    $ bluediscuss20 = False
    $ bluebathinvite20 = True
    $ bluediscuss20_progress = 1
    jump free20garden

label red20:
    scene free20red1
    with fade
    pause 2
    scene free20red2
    with dissolve
    beth "Do you want to play?"
    d "Did you hear the boss?"
    scene free20red3
    with dissolve
    beth "Yeah, but that's not a big deal. He can't refuse me anything. And certainly not having someone at the table to play."
    beth "So, do you want to play?"
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3205
        $ TEMP2 = ep3206
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Yes[TEMP1!t]":
            d "Yeah, that would be cool!"
            scene free20red4
            with dissolve
            beth "Cool! Listen, I'll put $1000 on the table for you as the buy-in."
            beth "If you win, you give me back the $1000 and keep the rest."
            scene free20red6
            with dissolve
            beth "If you lose... you'll have to make it up to me in another way."
            d "Okay!"
            scene free20red5
            with dissolve
            beth "Perfect!"
            scene black
            with dissolve
            pause 1
            $ moneypoker = 1000
            $ invitepoker = True
            $ reddiscuss20 = False
            $ emerick20_access = True
            $ reddiscuss20_progress = 2
            jump free20poker
        "No[TEMP2!t]":

            d "No, I'm good."
            d "I don't want to hang out with guys like that..."
            scene free20red4
            with dissolve
            beth "Are you sure? I can lend you the money if you're short!"
            d "No, I'm not interested."
            scene free20red5
            with dissolve
            beth "Okay!"
            scene black
            with dissolve
            pause 1
            $ reddiscuss20 = False
            $ reddiscuss20_progress = 2
            jump free20poker

label emerick20:
    scene free20emerick1
    with fade
    if emerickdiscuss20 == True:
        emerick "It seems someone has decided to vouch for you..."
        emerick "Anyway... You can play with us if you want."
    emerick "We play for 2 hours, so you can't leave until we're done!"
    emerick "Are you sure you want to play against us?"
    menu:
        "Yes (Advance time and ends free-roam)":
            d "Yeah. I'm excited to see how good you are."
            scene free20emerick2
            with dissolve
            emerick "Don't be too confident..."
            scene black
            with dissolve
            pause 1
            $ pokerroom = True
            $ emerickdiscuss20 = False
            $ emerickdiscuss20_progress = 2
            jump freepoker21
        "No, maybe later...":
            d "Uh... Uh... Uh... No!"
            d "I don't want to spend the whole evening here."
            scene free20emerick2
            with dissolve
            emerick "Then why did you come here to waste our time?"
            scene black
            with dissolve
            pause 1
            $ pokerroom = False
            $ emerickdiscuss20 = False
            $ emerickdiscuss20_progress = 1
            jump free20poker

label kira20poker:
    scene free20mira16
    with fade
    d "Kira... Could you help me with your cousin?"
    kira "Huh?"
    d "He doesn't want me to play poker with him and his guys."
    kira "Oh?"
    scene free20mira17
    with dissolve
    kira "Don't worry, I'll tell him that I'm inviting you."
    kira "He can't refuse."
    d "Are you sure?"
    kira "Yes, yes! Go ahead, I told you!"
    d "Oh, great, thanks!"
    scene black
    with dissolve
    pause 1
    $ moneypoker = 1000
    $ invitepoker = True
    $ kiradiscuss20_progress = 2
    $ emerick20_access = True
    jump free201st

label bluebath21:
    $ bluebathsequence = True
    jump free21

label freepoker21:
    $ freepokersequence = True
    jump free21
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
