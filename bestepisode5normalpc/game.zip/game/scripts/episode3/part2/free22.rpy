label free22:
    stop music fadeout 2
    scene black
    with fade
    pause 1 
    show text _ ("10:00 PM") at truecenter
    play music "musique/Amaria_LovelySwindler.mp3" volume 0.2
    with dissolve
    pause 2
    hide text
    pause 1
    if pokerparty == True:
        scene ep322h1
        with fade
        kira "You already lost?"
        if pokerlost == True:
            scene ep322h2
            with dissolve
            d "Yeah... Your cousin is too lucky..."
            scene ep322h3
            with dissolve
            kira "Just admit you don't know how to play!"
            scene ep322h4
            with dissolve
            d "Uh..."
        if pokersequence22 == True:
            scene ep322h2
            with dissolve
            d "No no, we're just taking a break!"
            scene ep322h3
            with dissolve
            kira "Oh okay!"
            scene ep322h5
            with dissolve
            kira "If I can give you a piece of advice..."
            kira "Emerick knows what he's doing."
            kira "But if you think you have an advantage at some point..."
            kira "Make him believe that he has it..."
            scene ep322h6
            with dissolve
            kira "He'll give you everything..."
            d "What do you mean?"
            kira "Play on his pride"
            scene ep322h7
            with dissolve
            d "Okay... I'll try."

    scene ep322h8
    with dissolve
    ruby "Let's put on some music?" with hpunch
    scene ep322h9
    with dissolve
    grace "Yes, it's too quiet here!"
    ruby "Wait, I'll move this table a bit so we can dance!"
    d "Dance?"
    scene ep322h10
    with dissolve
    ruby "Yes! Don't you like it?"
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3191
        $ TEMP2 = ep3192
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Yes, I do![TEMP1!t]":
            d "Yes, I do! But I didn't know you liked to dance!"
            $ herodanse = True
            jump danse22
        "Uh, not really!":
            d "Uh, no... It's not for me... But I didn't know you liked to dance!"
            $ herodanse = False
            jump danse22

label danse22:
    scene ep322h11
    with dissolve
    ruby "Me ? No !!!" with vpunch
    ruby "But Grace..."
    d "Really?"
    ruby "Wait, sit down... and watch!"
    stop music fadeout 2
    scene ep322h12
    with vpunch
    with dissolve
    pause 1
    scene black with dissolve
    play music "musique/MYO0042-ThroughTheClouds-stockmusic-net.mp3" volume 0.2
    play movie "images/animation/gracedanse.webm" loop
    show movie with fade
    d "Huh?"

    d "Wow!!! I didn't expect that!"
    ruby "I told you!"
    dpense "This rhythm..."
    dpense "Those moves..."
    dpense "She is truly a goddess..."
    dpense "The way she flows with the music..."
    dpense "It's like she's telling a story with every step..."
    dpense "I can't take my eyes off her..."
    dpense "Each movement is mesmerizing..."
    dpense "Grace is captivating everyone in the room..."
    stop movie
    scene ep322h13
    with dissolve
    grace "What did you think?"
    d "You were..."
    d "Magnificent..."
    scene ep322h14
    with dissolve
    grace "Thank you!"
    scene ep322h15
    with dissolve
    hec "Oh well, there's definitely some talent here!"
    stop music fadeout 2
    scene ep322h16
    with dissolve
    play music "musique/MYO0031-ActionSportsEnergeticRockTrailer-stockmusic-net.mp3" volume 0.2
    kira "The show's not over yet!"
    scene ep322h17
    with dissolve
    d "Huh?"
    scene black
    play movie "images/animation/miradanse.webm" loop
    show movie with fade
    dpense "Oh..."
    dpense "My..."
    dpense "God..."
    dpense "What an ass..."
    dpense "Fuck..."
    dpense "The things I would do to her..."
    d "Okay okay... You're good too!"
    stop movie
    scene ep322h18
    with dissolve
    kira "Ahah! I know!"
    scene ep322h19
    with dissolve
    hec "Take notes, Frenchie!"
    stop music fadeout 3
    if herodanse == True:
        scene ep322h21
        with dissolve
        d "Hmm..."
        scene ep322h20
        with dissolve
        d "Minus?"
        ruby "Yes?"
        d "Go ahead... Turn up the volume!"
        ruby "Oh? Okay!"
        play sound "sound/Long swoosh.wav" volume 1
        scene black
        with fade
        pause 2
        play sound "sound/Vooh.wav" volume 1
        scene herodance1
        pause 3
        scene herodance2
        play music "musique/MYO0035-Keepin39Up-stockmusic-net.mp3" volume 0.2
        $ renpy.movie_cutscene("images/animation/heroopendanse.webm", stop_music=False)
        scene herodance2
        with dissolve
        pause 1
        dpense "And now..."
        scene herodanse3
        $ renpy.movie_cutscene("images/animation/heroopendanse2.webm", stop_music=False)
        with flash
        scene herodanse3
        with flash
        d "Show Time!"
        scene herodanse4:
            xalign 0
            linear 6 xalign 0.99
        pause 7  
        scene black
        play movie "images/animation/herodanse.webm" loop
        show movie with fade
        ruby "Show them [name]!"
        grace "Wooooh !"
        ruby "[name]! [name]! [name]!"
        stop movie
        scene herodanse6
        with dissolve
        ruby "So awesome! Where did you learn to do that?"
        scene herodanse5
        with dissolve
        d "Oh... I like going out and dancing with my friends, you know..."
        grace "It was so good!"
        d "Haha! Thank you!"
        scene herodanse7
        with dissolve
        call buddy_increased from _call_buddy_increased_19
        hec "Hmpfff..."
    else:
        scene ep322h21
        with dissolve
        d "Yeah yeah..."
        dpense "You are talking to me like I care..."

    stop music fadeout 2   
    scene black
    with fade
    pause 1
    jump free23
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
