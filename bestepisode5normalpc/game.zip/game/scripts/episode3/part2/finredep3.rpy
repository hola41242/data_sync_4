
label afterpoker:

    scene afterpoker1
    with dissolve
    emerick "Damn it, a royal versus my four of a kind!" with hpunch
    d "Good game, Emerick."
    scene afterpoker2
    with dissolve
    emerick "Good game? You think this is just a game? I was supposed to win!" with hpunch
    d "Luck was on my side, I guess."
    scene afterpoker3
    with dissolve
    emerick "Luck? Don't kid yourself. I don't lose. This isn't over."
    dpense "Emerick looks furious. He's not taking this loss well."
    scene afterpoker4
    with dissolve
    beth "Impressive, [name]."
    dpense "Beth's been eyeing me all night. I wonder what she's up to."
    beth "Care to stay a bit longer?"
    if persistent.patch_enabled == True:
        $ TEMP1 = ep3003
        $ TEMP2 = ep3004
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Sure, why not?[TEMP1!t]":
            jump stay_with_beth
        "No, thanks.[TEMP2!t]":
            jump free00

label stay_with_beth:
    if _in_replay:
        show screen Replayexit
    scene finred01
    with dissolve
    beth "Good. I knew you'd make the right choice."
    stop music fadeout 2
    dpense "There's something about her... So commanding, so irresistible."
    scene finred02
    with dissolve
    play music "musique/ALG0012-AtmosphericRock-stockmusic-net.mp3" volume 0.2
    beth "Sit down."
    dpense "Her tone leaves no room for argument."
    scene finred3
    with dissolve
    beth "Good boy."
    beth "You know, [name], I've been watching you."
    scene finred4
    with dissolve
    beth "I like what I see."
    dpense "She's so confident, so dominant. It's both intimidating and thrilling."
    scene finred5
    with dissolve
    beth "Come here."
    scene finred6
    with dissolve
    beth "Now."
    dpense "I can't resist her. Her authority is magnetic."
    scene finred7
    with dissolve
    beth "Get on your knees."
    d "Yes, Beth."
    scene finred8
    with dissolve
    dpense "I've never seen anyone so commanding. Her dominance is overpowering."
    scene finred9
    with vpunch
    beth "Eat me."
    dpense "Her words send a shiver down my spine."
    scene finred10
    with dissolve
    dpense "Her scent is intoxicating. The taste of her is overwhelming."
    beth "Yes, just like that. Don't stop."
    scene finred11
    with dissolve
    dpense "She presses my head against her, taking control. It's intense, but I love it."
    beth "You're doing well. Keep going."
    scene finred12
    with dissolve
    dpense "Her dominance is turning me on even more. I want to please her, to make her feel incredible."
    scene finred13
    with dissolve
    beth "I'm close... Don't you dare stop now!"
    dpense "I can feel her body trembling. She's so close."
    beth "Ahh... Yes! Just like that!"
    with flash
    with hpunch
    scene finred14
    with flash
    pause 1
    with hpunch
    scene finred15
    with flash
    with hpunch
    with flash
    dpense "Her orgasm is powerful. She grips my head, holding me in place."
    scene finred16
    with dissolve
    beth "Now, it's your turn."
    beth "Lie back on the table."
    scene finred17
    with dissolve
    dpense "She's taking full control. It's exhilarating."
    beth "I'm going to ride you until I come again."
    dpense "Her confidence is intoxicating. I can't wait to feel her on top of me."
    scene black
    with fade
    pause 0.5 
    play movie "images/animation/redanimpoker1.webm" loop
    show movie with fade
    dpense "Her movements are perfect. She's in total control, and it feels amazing."
    beth "Yes, just like that. Don't move."
    dpense "I can feel myself getting closer. Her dominance is pushing me to the edge."
    scene black with fade
    play movie "images/animation/redanimpoker3.webm" loop
    show movie with fade
    beth "I'm coming again. Don't you dare finish before me!"
    dpense "Her words, her control... It's too much. I'm going to..."
    scene black with fade
    play movie "images/animation/redanimpoker2.webm" loop
    show movie with fade
    beth "Now!"
    dpense "I can't hold back any longer."
    stop movie
    with flash
    scene finred18 with hpunch
    d "Ahhhhh!!!!"
    with flash
    with hpunch
    scene finred19 with hpunch
    d "Oh my god!"
    with flash
    with hpunch
    with flash
    scene finred20 with hpunch
    d "Fshhh..."
    stop music fadeout 2
    dpense "Wait, what's she doing?"
    scene finred21 with vpunch
    play sound "sound/Select.wav" volume 2
    beth "Surprise!"
    play music "musique/MYO0046-BackFromTheEdge-stockmusic-net.mp3" volume 0.2
    scene finred2
    with dissolve
    pause 0.5
    scene finred1
    $ renpy.movie_cutscene("images/animation/garageopen.webm", stop_music=False)
    scene finred1
    with dissolve
    beth "We have audience. Just smile!"
    d "Whattt?" with hpunch
    ruby "Oh my God!"
    grace "What the...?"
    mad "Disgusting!"
    scene black
    with fade
    pause 1
    $ Gracepath = False
    $ madipath = False
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    if bluelove == True:
        scene finred23
        with dissolve
        sofia "Hey girls! What are you..."
        scene finred24
        with dissolve
        sofia "[name]???"
        scene finred25
        with dissolve
        sofia "How could you?!"
        $ bluelove = False
        scene finred26
        with dissolve
        dpense "Sofia..."
        scene finred27
        with dissolve
        $ Achievement.add(achievement_heartbreaker)
        $ achievement.grant("heartbreaker")
        $ achievement.sync()
        dpense "No..."
        scene black
        with fade
        pause 1.0
    scene finred28
    with fade
    pause 2
    scene finred29
    with dissolve
    beth "You..."
    beth "Are..."
    beth "Mine!"
    pause 2
    beth "I think you can go home now."
    d "Meh..."
    $ Redpath = True
    scene black
    with dissolve
    pause 2 
    stop music fadeout 2
    pause 2
    jump endsolo
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
