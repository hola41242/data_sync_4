init python:

    expanded_hud = True


    free20_tracking = [
        ("Julia", "juliadiscuss20_progress"),
        ("Ruby", "rubydiscuss20_progress"),
        ("Madison & Grace", "madigracediscuss20_progress"),
        ("Kira", "kiradiscuss20_progress"),
        ("Ben & Mac", "debilesdiscuss20_progress"),
        ("Emerick", "emerickdiscuss20_progress", "emerick20_access"),
        ("Sofia", "bluediscuss20_progress", "BlueRelation"),
    ]


    def get_free20_progress_list():
        progress = []
        for entry in free20_tracking:
            name = entry[0]
            varname = entry[1]
            condition = True
            if len(entry) > 2:
                condition = globals().get(entry[2], False)
            if condition:
                value = globals().get(varname, 0)
                seen = value == 2
                progress.append((name, seen, value))  
        return progress


    def get_free20_summary():
        progress = get_free20_progress_list()
        done = sum(1 for _, val, _ in progress if val)
        total = len(progress)
        return done, total

transform hud_appear:
    alpha 0.0
    xoffset 50
    linear 0.3 alpha 1.0 xoffset 0

transform hud_hover:
    on hover:
        linear 0.15 zoom 1.05
    on idle:
        linear 0.15 zoom 1.0

screen free20_hud(current_location=""):

    if not expanded_hud:
        frame:
            xalign 0.99
            yalign 0.5
            background Frame("#00000088", 10, 10)
            padding (10, 10)
            xmaximum 60

            has button
            action SetVariable("expanded_hud", True)
            background None
            padding (5, 5)
            xalign 0.5
            yalign 0.5

            text "☰" size 30 color "#FFFFFF" font "DejaVuSans.ttf"

    else:
        frame at hud_appear:
            xalign 0.99
            xoffset 20
            yalign 0.5
            background Frame("#00000088", 10, 10)
            padding (10, 10)
            xmaximum 320

            has vbox
            textbutton "✖" action SetVariable("expanded_hud", False) text_size 20 text_color "#FFFFFF"

            $ done, total = get_free20_summary()
            text _("Progress: [done]/[total] scenes") size 22 color "#FFFFFF"

            null height 10

            vbox:
                for name, seen, value in get_free20_progress_list():
                    $ icon = "✅" if seen else ("⌛" if value == 1 else "▶️")
                    text "[icon] [name]" size 18 color "#FFFFFF"

            null height 10
            text _("Quick Travel:") size 22 color "#FFFFFF"

            if current_location == "free20main":
                textbutton _("🌳 Garden") at hud_hover:
                    background None
                    hover_background None
                    action Jump("free20garden")
                    text_size 16
                    text_color "#A0E060"
                    text_outlines [(1, "#000", 0, 0)]

                textbutton _("🎲 Poker Room") at hud_hover:
                    background None
                    hover_background None
                    action Jump("free20poker")
                    text_size 16
                    text_color "#FF6666"
                    text_outlines [(1, "#000", 0, 0)]

                textbutton _("⬆️ Upstairs") at hud_hover:
                    background None
                    hover_background None
                    action Jump("free201st")
                    text_size 16
                    text_color "#FFFFFF"
                    text_outlines [(1, "#000", 0, 0)]
            else:
                textbutton _("🏠 Back to Living Room") at hud_hover:
                    background None
                    hover_background None
                    action Jump("free20main")
                    text_size 16
                    text_color "#88CCFF"
                    text_outlines [(1, "#000", 0, 0)]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
