label free23:
    $ JuliaHopital = False
    stop music fadeout 2
    scene black
    with fade
    pause 1 
    show text _ ("11:00 PM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1

    if pokersequence22 == True:
        jump poker23
    else:
        jump filles23

label poker23:
    play music "musique/Sacrifice-EliLortomy bad guy.mp3" volume 0.2
    scene poker231
    with fade
    mac "Damn, this is impossible!" with vpunch
    emerick "Haha!"
    mac "Busted my aces again!"
    scene poker232
    with dissolve
    mac "I'm going to stop playing them!"
    emerick "That's the game!"
    mac "Yeah yeah... It's crap!"
    scene poker233
    with dissolve
    emerick "It's just the two of us now, Frenchie!"
    scene poker234
    with dissolve
    dpense "I've managed to build up to $2000 in the few hands I've played..."
    emerick "Alright, it's heads-up!"
    scene poker235
    with dissolve
    beth "It's your turn to speak [name]."
    d "I call."
    scene poker236
    with dissolve
    emerick "Hmm..."
    emerick "I raise."
    d "Call."
    scene poker237
    with dissolve
    beth "The board..."
    scene poker238
    with dissolve
    beth "Ace of hearts, Ten of spades, King of spades."
    d "I bet 100."
    emerick "I raise."
    d "Hmm..."
    d "Call."
    beth "The turn..."
    scene poker239
    with dissolve
    beth "Ace of spades."
    d "Hmm..."
    scene poker240
    with dissolve
    dpense "Kira told me to play on his confidence..."
    dpense "How do I do that?"
    scene poker241
    with dissolve
    emerick "So, have you decided?"
    emerick "You're not going to fold, are you?"
    dpense "He seems very confident..."
    scene poker240
    with dissolve
    d "I can't remember..."
    d "A flush is better than a straight, right?"
    scene poker241
    with dissolve
    emerick "Haha!"
    emerick "Yes!"
    emerick "Do you have one or the other?"
    d "No, no, just wanted to know..."
    emerick "Hmm..."
    emerick "Listen, Frenchie, we're not going to spend all night here."
    emerick "So I propose something!"
    scene poker242
    with dissolve
    emerick "Let's go all in and see who wins!"
    emerick "What do you say?"
    emerick "How much do you have? 2000?"
    d "Yeah..."
    scene poker243
    with hpunch
    emerick "Alright, I put in 2000 and that's it."
    d "Uh..."
    d "Okay..."
    scene poker244
    with dissolve
    d "I call..."
    emerick "Do you know why I'm proposing this?"
    scene poker245
    with dissolve
    menu:
        "Because you're sure you'll win?":
            d "Because you're sure you'll win?"
            emerick "Obviously!"
        "Because you trust yourself?":
            d "Because you trust yourself and your game?"
            emerick "Haha! Always!"
        "Because you're crazy?":
            d "Because you're crazy?"
            emerick "You have to be a little, right?"
            emerick "But no... It's because I know I'm going to win!"
    emerick "Alright! The river, Beth!"
    scene poker239
    with dissolve
    beth "The river..."
    scene poker246
    with dissolve
    beth "The two of hearts..."
    beth "Show your cards, gentlemen!"
    scene poker247
    with dissolve
    emerick "Four of a kind, baby!" with vpunch
    d "Wow!!! Four of a kind...."
    d "A four of a kind is rare..."
    scene poker248
    with dissolve
    emerick "Yeah, man!"
    emerick "Nice try anyway!"
    scene poker249
    with dissolve
    d "Wow, that's crazy..."
    d "I thought you had just an Ace..."
    d "Okay... Maybe a full house..."
    emerick "Haha, I know how to play!"
    scene poker250
    with dissolve
    stop music fadeout 2
    d "Yes..."
    play music "musique/PAW0052-OffRoad-stockmusic-net.mp3" volume 0.2
    d "Nice hand anyway..."
    d "Do you know why I asked you if a flush was stronger than a straight?"
    emerick "Uh... no!"
    scene poker251
    with hpunch
    d "Well... Because I had..."
    play sound "sound/Long swoosh.wav" volume 2
    scene poker252
    with vpunch
    d "Both..."
    d "Royal Straight flush!" with vpunch
    scene poker253
    with dissolve
    emerick "Whattttt?" with hpunch
    emerick "Are you kidding me?"
    jump afterpoker

label filles23:
    pause 1 
    scene black
    with fade
    play music "musique/Aerocity-Stranger.mp3" volume 0.2
    pause 1 
    if JuliaPath == True:
        scene free23julia1
        with fade
        pause 1 
        scene free23julia2
        with dissolve
        hec "Come on. It was just a joke!"
        julia "Leave me alone, Hector."
        hec "Don't play the prude. I'm sure there's plenty of fun to be had under that dress!"
        julia "I told you to leave me alone!"
        scene free23julia3
        with dissolve
        hec "You got all dolled up, it would be a shame if no one took advantage!"
        hec "Come on, let's go somewhere a bit more private!"
        scene free23julia4
        with dissolve
        d "I think she told you to leave her alone."
        scene free23julia5
        with dissolve
        hec "Damn, you're always here!" with hpunch
        hec "Like a mosquito, man!"
        scene free23julia6
        with dissolve
        hec "Fine, I'll leave you with your princess... She seems frigid anyway."
        scene free23julia7
        with dissolve
        d "Are you okay?"
        scene free23julia8
        with dissolve
        julia "Yes, yes... I'm used to them. Don't worry."
        julia "But that's kind of you. Thank you."
        scene free23julia9
        with dissolve
        julia "For being there for me again..."
        d "Oh, it's nothing. I can't stand him anyway."
        scene free23julia10
        with dissolve
        julia "Ahaha! Neither can I."
        scene free23julia11
        with dissolve
        julia "Hey..."
        d "?"
        julia "This might sound weird but..."
        scene free23julia12
        with dissolve
        julia "Would you come with me to the hospital tomorrow?"
        d "What do you mean? Are you sick?"
        scene free23julia13
        with dissolve
        julia "No. I just want to visit my mother."
        julia "And I could really use someone with me considering the test results..."
        d "They're not good?"
        scene free23julia14
        with dissolve
        julia "No. Not at all."
        julia "She only has a few days left..."
        julia "I had come to terms with it but now I think it's the end."
        scene free23julia15
        with dissolve
        d "I'll be there for you."
        scene free23julia16
        with dissolve
        julia "Thank you [name]."
        julia "That means a lot to me."
        d "Don't hesitate if you need anything."
        julia "I don't want to impose..."
        scene free23julia17
        with dissolve
        d "That's what friends are for, right?"
        d "I mean, we're friends?"
        scene free23julia18
        with dissolve
        julia "We are friends!"
        if Grope == True:
            scene free23julia19
            with dissolve
            julia "Even if I'm not sure a friend grabs his friend's butt on the first day they meet..."
            d "Oh! Uh..."
            scene free23julia20
            with dissolve
            julia "Haha, I'm teasing you..."
            d "Well, to be fair, it is a nice one."
            scene free23julia21
            with dissolve
            julia "Haha, I know it! You can look but you can't touch"
        scene free23julia21
        with dissolve
        d "So as friends, let's enjoy the rest of this evening!"
        julia "You're right. I won't stay much longer anyway."
        d "Let's go!"
        $ JuliaHopital = True
        scene black
        with fade
        stop music fadeout 2
        pause 2
    play music "musique/MAS4685-Feel-GoodCinematicHope-stockmusic-net.mp3" volume 0.2
    scene ifiever1
    with fade
    ruby "I have never... Um..."
    scene ifiever2
    with dissolve
    ruby "Bought an erotic toy!"
    scene ifiever3
    with dissolve
    kira "You can say a dildo, you know!"
    ruby "Uh..."
    mad "Let her say what she wants, Kira!"
    mad "She has her own world with all her cute stuff!"
    scene ifiever4
    with dissolve
    kira "And you're going to tell me that among all your plushies, you don't have a little bunny to rub against from time to time?"
    ruby "Uh... No..."
    scene ifiever5
    with dissolve
    kira "I don't know how you girls do it, but if I don't get a bit of pleasure from time to time, I get aggressive!"
    kira "By the way, I bought one of those toys... You should see the thing..."
    scene ifiever7
    with dissolve
    grace "What does it look like?"
    mad "Grace?" with hpunch
    scene ifiever8
    with dissolve
    grace "What? I'm just curious!"
    scene ifiever6
    with dissolve
    kira "Haha! It's long, big, and ribbed..."
    kira "I haven't tested it yet, but I've heard good things about it, so... We'll see..."
    kira "And you, Madison? What's your favorite?"
    kira "I can see you with a little vibrating duck in your bath!"
    scene ifiever9
    with dissolve
    mad "For my daughter to play with? No thanks!"
    mad "And it's none of your business!"
    kira "There we go... Madison Forrester playing the prude!"
    scene ifiever10
    with dissolve
    mad "I am not a prude!"
    kira "Yeah, yeah..."
    scene ifiever11
    with dissolve
    d "What are you talking about here?"
    scene ifiever12
    with dissolve
    ruby "Toys!"
    mad "Intimate stuff..."
    kira "Dildos and touching ourselves!"
    d "Ouch... Okay..."
    scene ifiever13
    with dissolve
    grace "It's simpler for guys, I suppose..."
    d "How so?"
    grace "Well, when you feel like it, you can easily get pleasure, right? It's pretty quick..."
    d "Um... I think, like girls, it depends on the person... And we still need to be stimulated!"
    scene ifiever14
    with dissolve
    kira "Oh, definitely... And did you know that both men and women can be both visual, auditory, or tactile depending on the situation?"
    ruby "What do you mean?"
    scene ifiever16
    with dissolve
    kira "Basically... Guys often react quickly to visual stimuli, like the sight of your body."
    kira "For many women, sounds, words, and even certain kinds of touch can be more arousing."
    ruby "Ah! So how does that work?"
    scene ifiever15
    with dissolve
    kira "I'll let you discover that! It's important to know what turns you on and communicate that with your partner."
    scene ifiever17
    with dissolve
    grace "How do you know all this, Kira?"
    kira "Well... I experiment and do my research. There's so much to learn about our bodies and sexuality."
    scene ifiever18
    with dissolve
    kira "People can be so puritanical. They find sex so taboo that they are embarrassed to accept their bodies and sexuality."
    kira "But it's completely natural and healthy to explore it."
    scene ifiever19
    with dissolve
    grace "I envy you..."
    kira "If I can give you some advice..."
    scene ifiever20
    with dissolve
    kira "When you're ready to explore that part of yourself with someone, make sure to wear your best lingerie, let go, and enjoy the moment with the person you've chosen."
    kira "That way, you won't have any regrets!"
    if Gracepath == True:
        scene ifiever21
        with dissolve
        grace "Um... Okay..."
    scene black
    with fade
    pause 1
    jump free00
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
