label ep319h:
    play music "musique/MYO0013-HipHopAndRockCinematicTrailer3-stockmusic-net.mp3" volume 0.2 fadein 2
    scene black
    with fade
    pause 1 
    show text _ ("7:30 PM") at truecenter
    with dissolve
    pause 2
    hide text
    pause 1
    scene 19h1
    with dissolve
    dpense "There are already so many people..."
    scene 19h2
    with dissolve
    dpense "And they're all dressed up..."
    scene 19h3
    with dissolve
    dpense "Who's that girl who..."
    scene 19h4
    $ renpy.movie_cutscene("images/animation/ep319ha1.webm", stop_music=False)
    with vpunch
    scene 19h4
    with dissolve
    d "Ruby???"
    dpense "Is that really Ruby? She looks so different..."
    scene 19h5
    with dissolve
    ruby "Yes? Oh, you're already here?"
    d "Wow! You look stunning!"
    dpense "I can't believe how beautiful she looks tonight."
    scene 19h6
    with dissolve
    ruby "Oh?"
    scene 19h7
    with dissolve
    ruby "Thank you!"
    scene 19h8
    with dissolve
    ruby "So, for tonight, we've prepared a lot of things. I hope you won't get bored."
    d "What exactly have you prepared?"
    dpense "Please don't let it be too embarrassing..."
    scene 19h9
    with dissolve
    ruby "You'll see."
    ruby "Basically, the whole evening is divided by the hour."
    ruby "And every hour, I've organized different little games."
    scene 19h10
    with dissolve
    ruby "You can join in, or not, it's up to you."
    dpense "Games? This could be interesting or a disaster..."
    scene 19h11
    with dissolve
    ruby "I won't force you to do anything. Anyway, you're free to roam around the house."
    ruby "As usual at these parties, you're likely to meet people in different places."
    scene 19h10
    with dissolve
    ruby "Some will even be in the garage playing poker, so don't hesitate to wander around!"
    ruby "But I do hope to see you at one of my games."
    dpense "I should at least try one of her games, just to see what it's like."

    d "Well, I guess I'd better go get ready too..."
    dpense "I need to make sure I look decent..."
    scene 19h12
    with dissolve
    ruby "Grace should be waiting for you inside."
    ruby "Go see her, she'll tell you where to get ready."
    d "Okay. Well, see you later?"
    ruby "See you later!"
    scene 19h14
    with dissolve
    dpense "I hope I don't mess this up..."
    scene 19h13
    with dissolve
    pause 1 
    scene 19h15
    with dissolve

    d "You look beautiful..."
    grace "Thank you."
    if Gracepath == True:
        scene 19h16
        with dissolve
        pause 1
        scene 19h17
        with dissolve
        pause 1
        scene 19h18
        with hpunch

        dpense "I want to kiss her so badly, but we can't risk being seen..."
        if persistent.patch_enabled == True:
            $ TEMP1 = ep3191
            $ TEMP2 = ep3192
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""
        menu:
            "Kiss her[TEMP1!t]":
                grace "We won't be able to do this much when everyone is here."
                grace "I'll take advantage of it now."
                d "Yes, let's try to be discreet."
                scene 19h26
                with dissolve
                dpense "Her lips are so soft... This moment is too short."
                d "It's going to be hard not to jump on you during the party!"
                scene 19h23
                with dissolve
                grace "Yes..."
                dpense "I want her so much, but we have to be careful..."
            "Or not[TEMP2!t]":
                scene 19h19
                with dissolve
                d "Be careful, someone might see us."
                d "Better not tempt fate."
                scene 19h20
                with dissolve
                grace "Yes, you're right."
                dpense "I hate having to hold back, but it's necessary..."

        scene 19h21
        with dissolve
        grace "For the whole evening, I'll let you do whatever you want."
        dpense "Anything I want? This could be fun..."
        grace "Anyway, I won't have much of a choice."
        scene 19h22
        with dissolve
        d "Anything I want?"
        grace "Within reason, of course!"
        scene 19h23
        with dissolve
        grace "But I know how Ruby's games are designed and if you have to kiss a girl..."
        grace "Or dance closely with another..."
        scene 19h22
        with dissolve
        grace "Ruby has planned dares, so I won't hold it against you."
        grace "The more you act like a single guy..."
        grace "The less people will have doubts about us."
        scene 19h21
        with dissolve
        d "I agree."
        dpense "Playing the single guy could be tricky, but it's for the best..."
        scene 19h24
        with dissolve
        grace "But after the party, you're all mine!"
        dpense "I can't wait for that..."


    d "Do you know if Red left something for me?"
    scene 19h25
    with dissolve
    if Redpath == True:
        grace "Yes, she left your costume in the room upstairs."
        grace "Just go upstairs, take the left door, and it should be in the wardrobe."
        d "Alright, alright. Thanks!"
        dpense "I hope the costume looks good..."
    else:
        grace "No, but don't worry."
        grace "Go upstairs, to the room on your left."
        grace "You can take the costume I mentioned from the wardrobe."
        grace "It was my dad's. I think it'll fit you perfectly."
        d "Thank you very much, Grace!"
        dpense "I hope it fits well..."

    grace "You're welcome! Now go!"
    scene 19h27
    dpense "Time to get ready for whatever this night brings..."



    if madipath == True:
        scene 19h28
        with dissolve
        grace "Maybe I should've warned him about Madison..."
        scene black
        with fade
        pause 1
        stop music fadeout 2
        jump ep319hmadison
    else:

        scene black
        with fade
        pause 1
        stop music fadeout 2
        jump ep319hsolo

label ep319hmadison:

    scene 19h30
    with fade
    play music "musique/Nomyn-Fragments.mp3" volume 0.2 fadein 2
    pause 2
    scene 19h31
    with dissolve
    dpense "Those legs..."
    scene 19h32
    with dissolve
    dpense "And that body... She must have worked so hard to maintain her figure."
    scene 19h33
    with dissolve
    d "Madison?"
    dpense "What's she doing here?"
    scene 19h281
    with dissolve
    pause 1 
    scene 19h29
    $ renpy.movie_cutscene("images/animation/19hmadi1.webm", stop_music=False)
    scene 19h29
    pause 1 
    mad "Yes?"
    scene 19h34
    with dissolve
    mad "Oh! That's you?"
    d "Sorry... I was looking for my suit but I can come back later and..."
    scene 19h35
    with dissolve
    mad "No no. Now you're here, help me put my necklace on."
    d "This one on the bed?"
    mad "Yeah... You see another one?"
    d "Hummm...no..."
    scene 19h36
    with dissolve
    d "Okay..."
    d "You're really beautiful."
    dpense "Her beauty is undeniable, but it's her strength that captivates me the most."
    stop music fadeout 2
    scene 19h37
    with dissolve
    mad "You're trembling."
    play music "musique/ALG0012-AtmosphericRock-stockmusic-net.mp3" volume 0.2
    d "Yeah... I'm not used to touching such a wonderful woman..."
    dpense "She must think I'm just like the others. I need to show her I'm different."
    scene 19h38
    with dissolve
    mad "I told you this was a one time thing..."
    d "I know."
    dpense "But every moment with her feels like a gift I don't deserve."
    scene 19h39
    with dissolve
    mad "And we shouldn't do it again..."
    mad "Even if our desires are here..."
    dpense "She's so guarded. Who can blame her after what she's been through?"
    scene 19h40
    mad "We must..."
    mad "Restrain ourselves."
    mad "But..."
    scene 19h41
    with hpunch
    mad "You can't continue like this..."
    d "I know..."
    mad "And I can't either."
    dpense "I need to be patient. She needs time to trust again."
    scene 19h42
    with dissolve
    mad "This is bad, stop giving me compliments..."
    d "I can't..."
    mad "Stop saying what I need to hear..."
    d "I won't..."
    mad "Stop..."
    dpense "She's scared to let anyone in. I have to find a way to break through that wall."
    pause 1 
    scene 19h43
    with hpunch
    mad "I have some girls waiting for me!"
    dpense "I know she's just trying to push me away, but I can't give up on her."
    pause 1
    stop music fadeout 2
    scene 19h44
    with dissolve
    dpense "I guess I'm on my own for now."
    scene black
    with fade
    pause 1
    jump ep320h

label ep319hsolo:
    scene 19h44
    with dissolve
    dpense "I guess I'm on my own for now."
    scene black
    with fade
    pause 1
    jump ep320h
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
