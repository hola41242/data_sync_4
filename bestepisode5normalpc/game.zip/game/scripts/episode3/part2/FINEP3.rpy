label FINEP3:
    pause 2
    with fade
    show text _ ("SAVE NOW") at truecenter
    "Please save your game here..."
    pause 3
    with dissolve
    stop music fadeout 2.0
    hide text
    pause 2
    scene black
    with fade
    pause 1
    jump introep4
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" 
    pause 1.25
    scene coming
    with zoomout
    pause 4
    scene black
    with fade
    pause 0.5
    scene endorushiep34
    with fade
    gaby "And what a guy like you would do with a woman like me ?"
    pause 2
    scene black
    with fade
    pause 0.5
    scene sad1
    with dissolve
    ji "Mum..."
    scene sad2
    with dissolve
    pause 2 
    scene black
    with fade
    pause 1
    scene h44
    with dissolve
    drew "You have a new trial these afternoon"
    drew "You have to choose your partner for this one [name]."
    pause 2
    scene black
    with fade
    pause 0.5
    scene foot20
    with dissolve
    mad "Okay guys... We can't lose this match!"
    pause 2
    scene comingepisode4
    with dissolve
    pause 5 
    stop music fadeout 5
    scene black
    with fade
    pause 2    
    jump introep4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
