label ep3s2b:
    show text _ ("9:00 AM") at truecenter
    pause 2
    with dissolve
    pause 2
    hide text
    pause 1
    play music "musique/FB01-DropItNow-Labes.mp3" volume 0.2 fadein 2
    scene ep3s2br1
    with fade
    pause 2
    scene ep3s2br2
    with dissolve
    pause 2
    scene black
    play movie "images/animation/maditrain1.webm" loop
    show movie with fade
    ""
    scene black with fade
    stop movie
    scene black
    play movie "images/animation/maditrain2.webm" loop
    show movie with fade
    ""
    scene black with fade
    stop movie  
    scene black
    scene ep3s2br3
    with fade
    pause 2 
    scene ep3s2br4
    with dissolve
    mad "Yeah? What do you want, Dad?"
    "Madison, who's this French guy you've teamed up with for the comp?"
    scene ep3s2br5
    with dissolve
    mad "How'd you even find out? And what's it matter to you?"
    "I just don't want my daughter hanging out with guys who can't pull their weight to win!"
    scene ep3s2br6
    with dissolve
    "You've got a daughter, remember. And her 'dad', if that's what you can call him, isn't around to support her."
    mad "She's my responsibility, not yours. I don't need your approval on how I live my life or who I spend my time with."
    "I want you to bring this French guy over for dinner tomorrow night. It might be your chance to show some responsibility."
    "Don't make me regret giving you this opportunity."
    scene ep3s2br7
    with dissolve
    mad "But why do you even want to see him?"
    scene ep3s2br8
    with dissolve
    "Tomorrow night, 7 PM."
    scene ep3s2br9
    with dissolve
    mad "..."
    scene ep3s2br10
    with dissolve
    mad "What are you doing here?"
    scene ep3s2br11
    with dissolve
    mad "Actually, you're just in time; I need to talk to you."
    d "Everything okay? I don't want to intrude."
    mad "My dad wants to meet you tomorrow night at seven for dinner. Think you can make it?"
    scene ep3s2br12
    with dissolve
    d "Me? Why?"
    scene ep3s2br13
    with dissolve
    mad "Don't ask, just say yes..."
    d "Uh, yeah, no problem. Just need to figure out how to get to your place."
    mad "Don't worry about that; I'll pick you up."
    mad "Here, give me your number. It'll be easier if I need to call you."
    d "Sure."
    $ renpy.notify (_("NEW CONTACT ADDED"))
    $ Madisonphone = True
    scene ep3s2br14
    with dissolve
    mad "Thanks. For... you know, being there. We'll do this dinner. My dad's not gonna dictate how I run my life."
    mad "Listen, about tomorrow night... My dad, he's got issues with my choices, especially about my daughter."
    scene ep3s2br15
    with dissolve
    mad "He never accepted my past relationship, much less the fact that I'm a single mom."
    d "I get it. Must be tough for you. Just know, you don't have to justify yourself to me, or anyone else for that matter."
    mad "Thanks. That... means a lot, you know."
    scene ep3s2br16
    with dissolve
    d "I really appreciate you picking me up. And I'm here, no matter what your dad thinks."
    scene ep3s2br17
    with dissolve
    mad "My dad has this way of... well, he's putting a lot of stock in this meeting with you."
    mad "After our success at the B.E.S.T., he sees you as a disruptive element."
    mad "It's a bit awkward, but he wants to see you tomorrow night."
    d "I understand. Does it bother you if I come?"
    scene ep3s2br15
    with dissolve
    mad "No, on the contrary. It could be interesting. Mom will handle dinner, as usual. My dad, though, will probably try to take over. Just... stay calm."
    d "Got it."
    d "Can't wait to see who we're up against Monday."
    scene ep3s2br13
    with dissolve
    mad "Oh! You haven't been told?"
    d "About what?"
    mad "The draw's been made."
    d "And?"
    mad "Guess..."
    scene madigym1
    with dissolve
    mad "The boys' soccer team... They're tough."
    scene madigym2
    with dissolve
    mad "Steven, their captain, knows how to motivate his team, and he's strong."
    scene madigym3
    with dissolve
    mad "Then there's Hector, that guy's sneaky and unpredictable on the field."
    d "Yeah, I know him. Had a... run-in with him yesterday."
    mad "Hmm... Might be a good thing then."
    d "How so?"
    mad "He'll probably focus on you. That'll give us a clear field."
    d "Yeah, but I think it's gonna get physical!"
    mad "Part of the game. Just watch out for any dirty tricks."
    d "We'll try."
    scene madigym4
    with dissolve
    mad "Then there's Ben, who follows Steven without question."
    scene madigym5
    with dissolve
    mad "And Mac, the goalie. A real wall."
    scene madigym6
    with dissolve
    mad "But it's their fifth player who's a mystery. We don't know who it is."
    d "A mysterious player? Complicates things."
    scene madigym7
    with dissolve
    mad "Exactly. We need to stay alert, especially with Steven and his influence on the team. He's got this... charisma, even if he's not my type of leader."
    d "We'll find a way past their defense. We have our own strength, starting with you."
    scene madigym8
    with dissolve
    mad "Appreciate the optimism. But yes, you're right. We'll show them what we're made of."
    mad "Now, I really need to get back to training. We've got a match to win, and I'm not letting my dad or these clowns distract us from our goal."
    d "I'm with you, Madison. We'll get through this together."
    scene madigym9
    with dissolve
    mad "Thanks, really. For everything."
    d "You know, I was thinking..."
    d "When Emerick won the obstacle course, no one really saw him tackle the obstacles. Weird, right?"
    mad "Now that you mention it... It was like he disappeared, then reappeared at the end, with no one knowing how."
    d "We saw him coming from a different path to the stadium, by the time we looked for our bag he was already gone. Didn't even try."
    mad "The rules of this competition are so vague, it's frustrating."
    d "These ambiguities in the rules, can we use them to our advantage? To counter Emerick, I mean."
    scene madigym10
    with dissolve
    mad "That's an idea. If the rules aren't clear, it means there are grey areas to explore."
    mad "Maybe we can find a way to turn them against him, especially if he's relying on them for his schemes."
    d "Exactly. We should start looking for loopholes, points we could question or exploit."
    d "If Emerick is playing with the rules, nothing stops us from doing the same, but in a legit way."
    mad "Agreed. We might even discuss it with the others, see if they've noticed any irregularities."
    scene madigym11
    with dissolve
    mad "But for now, let's focus on our prep for the match. We'll need all our strength and strategy for this."
    d "Yeah."
    mad "It's about time for class with Gabriella."
    d "Let's go."
    stop music fadeout 2
    $ madidiner = True
    jump ep3s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
