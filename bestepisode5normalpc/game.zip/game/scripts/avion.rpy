label avion:

scene black
with fade
$ renpy.movie_cutscene("images/animation/aviona.webm", stop_music=False)
scene julia1
with fade
pause 2
scene julia2
with dissolve
ji "Hello?"
d "Uhh, hello."
ji "May I help you?"
d " Oh, uh, sorry! Just looking."
d "I think this is my seat. Mind if I sit?"
scene julia3
with dissolve
ji "Yes, of course. Please, sit and relax. It's going to be a long flight."
ji "I just sat here by myself to clear my head and be near the window."
scene julia4
with dissolve
d "Clear your head?"
scene julia6
with dissolve
ji "Yeah, there's a bit of party in first class with the girls, but it's kind of noisy."
d "Hmm... okay..."

scene julia5
with dissolve

show screen gameUI

"Choices matter in this game and you have four attributes in four branches: B.E.S.T"
"BUDDY is about your social ability and will have an impact on his interactions with other characters."
"EDUCATION is about your general knowledge and will have an impact on tests and dialogues."
"SPORT is about your athletic level and is needed to complete certain objectives during the game."
"TEMPERAMENT is about your attitude and ego and it will be vital for you to achieve the BEST outcome in the game."
"Some choices will lead to an upgrade..."
"And some choices will be unavailable if you don't meet the minimum attribute required."

$ Pervert = False

if persistent.patch_enabled == True:
    $ TEMP1 = avionm1c1
    $ TEMP2 = avionm1c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""


menu:
    "Look at her [TEMP1!t]":
        jump matte
    "Stay quiet [TEMP2!t]":
        jump timide

label matte:

    scene juliaperv
    with dissolve

    call temperament_increased from _call_temperament_increased

    show screen gameUI
    "Your temperament has increased."
    "If you look at the stat window you will see that Temperament got a +1"
    "Depending on the choices you make, different attributes will grow."

    ji "Can I help you with something?"
    with vpunch
    scene juliaperv2

    d "Oh! Uh, no no, it's okay. Thank you. Sorry, I got lost in thought while looking at you..."
    ji "Were you checking me out?"
    d "I'm sorry I didn't mean..."

    scene juliaperv3
    with dissolve

    ji "Ahaha... don't worry about it. You're not the first to perv on me like that."
    d "I'm not a pervert..."
    $ Pervert = True
    d "Hey, let's say I was checking you out, and I wasn't, that wouldn't be so bad, would it? I'm only human after all"
    d "I'm [name]. Sorry if my English isn't good but I'm French and I'm going to the US to improve it."

    scene juliaperv2
    with dissolve

    ji "Oh, is that so? So you are saying I'm not attractive enough for you to check out? "
    julia "I'm Julia by the way, Mr. Pervert."
    d "Oh, so we're not even together yet and I already have a pet name? I don't know if I like this one though."

    scene juliaperv5
    with dissolve

    julia "Yet? Aren't we confident?"
    d "I try! So what is a girl like you doing in a jet like this ? "
    julia "Oh you don't know? In the beginning this jet was just for us."

    scene juliaperv6
    with dissolve

    julia "But now, the academy is trying to save money where they can."
    julia "Sometimes, we have to share this plane with some students or families."
    julia "Not a problem for me but others are not as friendly as me."
    d "How many of you are there?"
    julia " Well, if you count Gabriella, our guide, there are...."
    with vpunch

    "Loud noises coming from the forward cabin"
    ji "AND YOU KNOW WHAT THESE GUYS TRIED TO DO?!"
    d "Who are they?"
    with vpunch
    scene juliaperv7
    with dissolve

    julia "Those are my girls. I need to check in on them... see ya perv!"
    d "I'm not a pervert!"
    julia "Excuse me..."

    scene juliaperv8
    with dissolve
    $ Grope = False

    if persistent.patch_enabled == True:
        $ TEMP1 = avionm2c1
        $ TEMP2 = avionm2c2
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""

    menu:
        "Grope her [TEMP1!t]":
            jump grope
        "I'm not a pervert! [TEMP2!t]":
            jump juliapart

label grope:
    $ Achievement.add(achievement_groper)
    $ achievement.grant("groper")
    $ achievement.sync()
    dpense "I really shouldn't but it's so nice..."
    dpense "I know it's bad..."
    dpense "I can't stop myself..."

    call temperament_increased from _call_temperament_increased_1
    $ Grope = True

    scene juliaperv9
    with hpunch
    pause 2

    scene juliaperv10
    with vpunch

    julia "OH YOU REALLY ARE A PERV!"
    pause 1

    scene juliaperv11
    with dissolve
    pause 0.5

    scene juliaperv12
    with hpunch
    pause 0.5

    scene juliaperv13
    with dissolve
    pause 0.5

    scene juliaperv14
    with dissolve
    pause 1

    scene juliaperv15
    with dissolve
    julia "Pervert..."
    pause 2

    scene juliaperv16
    with dissolve
    dpense "She hit me! I don't believe it!"
    jump steven

label juliapart:
    $ Achievement.add(achievement_redneck)
    $ achievement.grant("redneck")
    $ achievement.sync()
    scene juliaperv17
    with dissolve
    pause 2
    jump steven

label temperament_increased:
    $ Temperament += 1
    $ renpy.notify (_("YOUR TEMPERAMENT HAS INCREASED"))
    return

label timide:

    call education_increased from _call_education_increased

    show screen gameUI
    "Your Education has increased."
    "If you look at the stat window you will see that Education got a +1"
    "Depending on the choices you make, different attributes will grow."

    dpense "She seems confident. I'm a little intimidated by her. I need to be more confident. Also, she's American, so... there's that."
    scene juliaperv11
    with dissolve
    dpense "Maybe I should open with 'Hi! I'm from France! And you?'"
    dpense "No, that's not a good approach. 'Hello, my name is [name]. What's yours?'"
    dpense "Maybe too formal? 'Hello, are you hungry? Yes? Well, hi hungry, I'm [name].'"
    dpense "Do I just introduce myself and ask about the party in first class?"
    dpense "Yeah, I guess it'll be fine or at least be a good icebreaker."
    with vpunch
    d "So.. nice to meet you..."
    ji "AND YOU KNOW WHAT THESE GUYS TRIED TO DO?!"
    scene julia5
    with dissolve
    d "Who was that?"
    julia "Those are my girls."
    scene juliaperv8
    with dissolve
    julia "Excuse me..."
    $ Grope = False
    scene juliaperv17
    with dissolve
    julia "Sorry, I need to go check on what they're doing. Bye!"
    d "Bye."
    d "I didn't even get her name..."
    jump steven

label education_increased:
    $ Education += 1
    $ renpy.notify (_("YOUR EDUCATION HAS INCREASED"))
    return

label steven:
    scene steven1
    with dissolve
    dpense "She was pretty."
    dpense "..."
    stop music fadeout 2
    pause 2
    play music "musique/Amaria_LovelySwindler.mp3" volume 0.20

    if Grope == True:
        with vpunch
        "You fucked up man!"
        jump suitesteven
    else:

        with vpunch
        "Hey man, you sure are a lucky bastard!"
        jump suitesteven

label suitesteven:
    d "What?"
    scene ruby 1
    with dissolve
    "You just talked with one of the most popular girls at our university."
    d "Popular? How?"
    "You don't know? I thought you were playing it cool. The guy who got on the plane and met Julia, the best middlefielder on our team."
    d "I..."
    scene ruby 6
    with dissolve
    with hpunch
    "You know nothing Jon Snow."
    pause 1   
    scene steven4
    with dissolve
    d "I don't... what?"
    scene ruby 3
    with dissolve
    "Game of Thrones, man! Come on, do you not know about it?! Daenerys Targaryen, Jamie, incest..."
    d "I know what Game of Thrones is."
    "Well, that's good then! I'm Ruby, and you are?"
    d "[name]."
    ruby "Oh, I like it, it's kind of cute. Not like some people who call their kid Clitorine, am I right?"
    ruby "Some people I tell you, just giving their kids weird names. Not yours though! I like your name! Sorry, I'm rambling. So, where are you going?"
    scene ruby 2
    with dissolve
    d "My first day at university is tomorrow so..."
    ruby "Really? Me too! Listen, we should meet up before it starts. It will really help to have someone to guide you when you get there!"
    d "Why?"
    ruby "It's a jungle there! Come on, there are girls everywhere, just laying in wait. Some have their claws ready to fight for victory and fame!"
    scene ruby 2
    with dissolve
    ruby "And you know what fame does?"
    scene steven4
    with dissolve
    pause 0.5
    scene ruby 1
    with dissolve
    pause 0.5
    scene steven4
    with dissolve
    d "I don't..."
    scene ruby 5
    with dissolve
    ruby "Know. I know, you know nothing. Fame means GIRLS! You will be the chosen one if you succeed! Imagine girls throwing themselves at your feet! And what would more fame mean?"
    scene steven4
    with dissolve
    pause 0.5
    scene ruby 2
    with dissolve
    pause 0.5
    scene steven4
    with dissolve
    d "More girls?"
    scene ruby 6
    with dissolve
    ruby "You're quite clever, eh? I will be your wingman! Wait, no, I will be your Cupid! We will be like Pinky...wait..you're French. I'm Minus and you're Cortex okay? So are you ready to conquer the world?!"
    scene steven4
    with dissolve
    pause 0.5
    scene ruby 4
    with dissolve
    ruby "Okay, you're not ready yet Cortex. We'll fix that! Well it was pretty cool meeting you but I have some things to take care of. The other girls are awaiting my sage advice. See you tomorrow!"
    d "I..."
    scene ruby 7
    with dissolve
    ruby "And wait for me before entering the academic arena!"
    d "..."
    scene steven10
    with dissolve
    dpense "Are they all as crazy as this girl?"
    d "..."
    d "I'm exhausted."
    scene steven11
    with dissolve
    pause 0.5
    scene steven12
    with dissolve
    pause 0.5
    scene steven13
    with dissolve
    pause 0.5


    scene black
    with fade
    stop music fadeout 2


    show text _ ("MEANWHILE") at truecenter
    with dissolve
    pause 2
    hide text
    with dissolve

    play music "musique/Lyvo-Home.mp3" volume 0.2


    with fade
    scene fille1
    with dissolve
    pause 3
    scene fille2
    with fade
    pause 3
    scene fille3
    with fade
    pause 3
    scene fille4
    with fade
    pause 3
    scene ruby
    with fade
    pause 3
    scene fille5
    with fade
    pause 3
    scene fille6
    with fade
    pause 3
    scene fille7
    with fade
    pause 3
    scene madisson1
    with fade
    pause 3
    scene fille8
    with fade
    pause 3
    scene fille9
    with fade
    pause 3
    scene girls5
    with fade
    pause 3
    scene fillesscenefinal
    with fade
    pause 3


    "Is this our little Julia coming back from the boonies?"
    "She was talking to a guy. I hope he didn't get the wrong idea about you..."

    if Grope == True:
        scene juliap
        with dissolve
        julia "Yeah, this pervert groped me while I passed in front of him!"
        "WHAAAAT??!" with hpunch
        scene juliap2
        with dissolve
        "Come on Julia, someone finally got a piece! You can put your chastity belt on and go back to the convent."
        scene juliap3
        with dissolve
        julia "Haha, very funny, Madison! Not everyone can be as free as you with their body or with their choices in life!"
        scene juliap4
        with dissolve
        mad "What do you mean?"
        scene juliap5
        with dissolve
        julia "Nothing. Everybody knows that you are the queen of virtue. Only need to ask your boyfriend."
        julia "Oh wait, we can't. He left you alone with a kid and disappeared. Good choice, Madison!"
        scene juliap6
        with dissolve
        mad "Don't talk about my kid! I'm gonna shove my fist down your throat so you will know how giving of a queen I am!"
        scene juliap7
        with dissolve
        with hpunch
        "Girls, girls, girls! Stop this right now!"
        scene juliap8
        with dissolve
        mad "Okay Grace, but tell the Holy Virgin to calm her tits or use a dildo to loosen up before I shove one of mine in her fucking ass!"
        scene juliap9
        with dissolve
        mad "I'm outta here!" with vpunch
        scene juliap10
        with dissolve
        ruby "Maddie, calm down!"

        scene black
        with fade
        pause 1


        jump filles
    else:

        scene juliap
        with dissolve
        julia "The boonies, as you put it, are much nicer than being around you Madison."
        scene juliap2
        with dissolve
        mad "Yeah sure. I bet the rednecks are ready to show you how nice they are if you open your mouth enough."
        julia "You're gross..."
        mad "Come on Julia, don't play the good girl with me. Going to put your chastity belt on?"
        scene juliap3
        with dissolve
        julia "Haha, very funny, Madison! Not everyone can be as free as you with their body or with their choices in life!"
        scene juliap4
        with dissolve
        mad "What do you mean?"
        scene juliap5
        with dissolve
        julia "Nothing. Everybody knows that you are the queen of virtue. Only need to ask your boyfriend."
        julia "Oh wait, we can't. He left you alone with a kid and disappeared. Good choice, Madison!"
        scene juliap6
        with dissolve
        mad "Don't talk about my kid! I'm gonna shove my fist down your throat so you will know how giving of a queen I am!"
        scene juliap7
        with dissolve
        with hpunch
        "Girls, girls, girls! Stop this right now!"
        scene juliap8
        with dissolve
        mad "Okay Grace, but tell the Holy Virgin to calm her tits or use a dildo to loosen up before I shove one of mine in her fucking ass!"
        scene juliap9
        with dissolve
        mad "I'm outta here!" with vpunch
        scene juliap10
        with dissolve
        ruby "Maddie, calm down!"

        scene black
        with fade

        pause 1
        jump filles


label filles:

    with fade
    scene grace1
    grace "Come on girls, we're going to be on this flight for eight hours, so let's make an effort to get along."
    scene grace2
    with dissolve
    ruby "I'll go talk to Madison, she's been nervous all morning and I don't know why."
    scene grace3
    with dissolve
    grace "Okay Ruby, you do that while I talk to Julia."
    grace "Julia, don't be bothered by her little mind games, you know how she is!"
    scene grace4
    with dissolve
    julia "Yeah she can be so vulgar and unpleasant."
    grace "Just ignore her comments and everything will be fine. I've known her since kindergarten, she's just trying to get a rise out of you."
    scene grace5
    with dissolve
    grace "You know she's been through a lot and we are all on the same team here."
    grace "We just won our exhibition game in Europe yesterday, and now, you're acting like enemies instead of celebrating together!"
    scene grace6
    with dissolve
    julia "I know, Captain, but she has this power over me. She can push my buttons and I hit the roof instantly!"
    scene grace7
    with dissolve
    julia "I'm going to stay calm, for the team. I promise. For you and the girls, because this means so much to me..."
    scene grace8
    with dissolve
    grace "Yeah keep that attitude and we're good."
    scene grace9
    with dissolve
    grace "Well I'm going to have some champagne! I didn't buy these bottles when we were in France for nothing. I've got to try it!"
    julia "Okay. See you later."
    scene black
    with fade
    pause 1    
    jump reveil

label reveil:

    show text _ ("HOURS LATER") at truecenter
    with dissolve
    pause 2
    hide text
    with dissolve
    label dream:
        if _in_replay:
            show screen Replayexit
        scene juliadream1
        with fade
        julia "Is that how you imagine me?"
        scene juliadream2
        with dissolve
        julia "I'm a little disappointed."
        scene juliadream3
        with dissolve
        julia "I expected more from you..."
        if persistent.streaming == True:
            julia "I'll have to take the lead."
            julia "I know you want to touch."
            julia "Soon you'll be able to enjoy all of this."
            julia "But first..."
            scene juliadream8
            with dissolve
            julia "WAKE UP!" with hpunch
            stop music fadeout 1.0
            scene black
            with dissolve
            jump suiteavion

        scene juliadream4
        with dissolve
        julia "I'll have to take the lead."
        scene juliadream5
        with dissolve
        julia "I know you want to touch."
        scene juliadream6
        with dissolve
        julia "Soon you'll be able to enjoy all of this."
        scene juliadream7
        with dissolve
        julia "But first..."
        scene juliadream8
        with dissolve
        julia "WAKE UP!" with hpunch
        stop music fadeout 1.0
        scene black
        with dissolve
        $ renpy.notify(_("New Scene Gallery added"))
        $ renpy.end_replay()
        label suiteavion:
            pause 1
    pause 1 
    d "What?"
    ji "Wake up!"
    play music "musique/Amaria_LovelySwindler.mp3" volume 0.20
    scene reveil
    with dissolve
    pause 1
    scene reveil2
    with dissolve
    pause 1
    scene ruby 8
    with dissolve
    pause 1
    scene reveil4
    with dissolve
    d "WHAAAAAAAAAAAAAAAAAAAAAA..." with vpunch
    scene ruby 9
    with dissolve
    pause 1
    ruby "AHHHHHHHHHHHHHHHHHHHHHHH..." with vpunch
    scene ruby 10
    with dissolve
    d "You scared me!"
    ruby "Are you crazy? You who scared me!"
    d "..."
    scene ruby 5
    with dissolve
    ruby "We've landed! Okay Cortex, it's time to go!"
    ruby "Don't forget, tomorrow morning, wait for me at the entrance! We will conquer the world! Or maybe the academy is enough for now . I will think about it."

if persistent.patch_enabled == True:
    $ TEMP1 = avionm3c1
    $ TEMP2 = avionm3c2
else:
    $ TEMP1 = ""
    $ TEMP2 = ""

menu:
    "Yeah, sure! [TEMP1!t]":
        call buddy_increased from _call_buddy_increased
        jump aeroport
    "I don't need your help, thanks anyways! [TEMP2!t]":
        call temperament_increased from _call_temperament_increased_2
        jump aeroport

label buddy_increased:
    $ Buddy += 1
    $ renpy.notify (_("YOUR BUDDY HAS INCREASED"))
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
