label e5s2:
    $ Training3 = False


label kira_vs_emerick:
    play music "musique/MAK0233-HybridActionPercussion-stockmusic-net.mp3" volume 0.2
    pause 2
    scene e5s2ke1
    with fade
    pause 2
    scene e5s2ke2
    with dissolve
    pause 2
    scene e5s2ke3
    with hpunch
    pause 1
    scene e5s2ke4
    with dissolve
    pause 2
    scene e5s2ke5
    with dissolve
    pause 2
    scene e5s2ke6
    with dissolve
    kira "What were you thinking? What exactly were you trying to prove with Ruby?"
    emerick "I wasn’t trying to prove anything. She got in my way, that’s all. I lost my temper."
    scene e5s2ke7
    with dissolve
    kira "Lost your temper? You nearly sent her to the hospital!"
    kira "Do you have any idea how serious this is?"
    scene e5s2ke8
    with dissolve
    emerick "And why do you care, Kira? Why are you even involved?"
    emerick "You’ve got everything! Status, privilege, the inheritance."
    emerick "So why are you even in this competition? You don’t need it."
    scene e5s2ke9
    with dissolve
    kira "And you think that justifies what you’ve done?"
    kira "That because I was born in a better position, you have the right to act however you want?"
    kira "Emerick, what you’re doing is sabotage. Not just to others, to yourself."
    emerick "Sabotage? I’m fighting for what I deserve, Kira."
    emerick "You’ve had everything handed to you. I have to prove myself at every step."
    scene e5s2ke10
    with dissolve
    kira "And you think this is the way to do it? Going after Ruby or anyone else doesn’t make you stronger."
    kira "It just makes you look like a spoiled brat."
    emerick "A spoiled brat? You talk as if you know everything, as if you’re above all this."
    emerick "Maybe you are, Kira, but I’m not. I have to play to win, no matter what it takes."
    scene e5s2ke11
    with dissolve
    kira "You’re playing to win? No, you’re playing because you’re scared. You don’t want to admit it, but you’re afraid of him."
    scene e5s2ke12
    with dissolve
    emerick "Who him? [name]? You really think I’m afraid of that guy?"
    scene e5s2ke13
    with hpunch
    emerick "He’s nothing. Nothing!"
    scene e5s2ke14
    with hpunch
    ben "Outch!"
    scene e5s2ke11
    with dissolve
    emerick "I’m not afraid of him, and I won’t let anyone suggest otherwise."
    scene e5s2ke10
    with dissolve
    kira "And yet you can’t stop reacting whenever he’s mentioned."
    kira "It’s almost too easy to see how much he gets under your skin. But it doesn’t matter. I’m not here to argue with you."
    emerick "Then why are you here? To lecture me again?"
    scene e5s2ke15
    with dissolve
    kira "No. I’m here to tell you to stay away from Ruby."
    scene e5s2ke16
    with dissolve
    kira "This is the last time you pull something like that. And if you keep this up, Emerick, you’ll be the one out of the game."
    scene black
    with fade
    stop music fadeout 2 
    pause 2


if GraceEsca == True:
    jump gracee5s2
if Traininggabyep5 == True:
    jump gabye5s2
if Evelyncafe == True:
    jump evelyne5s2
else:
    jump e5s3

label gracee5s2:



    play music "musique/IVK0004-PowerfulSportRock-stockmusic-net.mp3" volume 0.2
    pause 2 

    scene e5s2grace4
    with fade
    pause 2
    d "You’re doing great, Grace. Remember, take your time and focus on your footing."
    scene e5s2grace3
    with dissolve
    grace "I’m trying! But it feels like this rock face is never-ending."
    d "You’re doing better than you think. Climbing takes patience and confidence. Keep your weight close to the wall."
    scene e5s2grace1
    with dissolve
    grace "Easier said than done… Okay, I think I’ve got it. Now what?"
    d "See that ledge about two meters up? Just a bit more effort, and we can take a short break."
    scene e5s2grace2
    with dissolve
    grace "All right. I can do this."

    scene black
    with fade
    pause 1 
    scene e5s2grace5
    with fade
    pause 1 
    scene e5s2grace6
    with dissolve
    pause 1 
    scene e5s2grace7
    with dissolve
    grace "Wow… I never realized how much strength this takes."
    scene e5s2grace8
    with dissolve
    d "That’s why it’s so rewarding. When you reach the top, it feels like you’ve conquered the world."
    scene e5s2grace9
    with dissolve
    grace "We made it! Look at that view..."
    scene e5s2grace10
    with dissolve
    d "Pretty amazing, huh? This is why I love climbing. It’s like the rest of the world disappears."
    grace "I can see why you love it. It’s so peaceful up here… just us and the horizon."
    scene e5s2grace11
    with vpunch
    d "You know, Grace… being here makes me wonder, what’s really driving you to try things like this?"
    scene e5s2grace12
    with dissolve
    grace "I guess it’s because I missed out on so much when I was younger."
    scene e5s2grace13
    with dissolve
    grace "My dad was always off on humanitarian missions, and my mom…"
    grace "She was all about grades and achievements. I didn’t really get to explore what I wanted."
    scene e5s2grace14
    with dissolve
    d "So now you’re making up for lost time?"
    scene e5s2grace15
    with hpunch
    grace "Exactly. I’m trying things I never imagined, just to see what fits."
    grace "Climbing a mountain, learning new skills… it’s my way of figuring out who I really am."
    scene e5s2grace16
    with dissolve
    d "That’s really brave. A lot of people wouldn’t even try."
    scene e5s2grace17
    with dissolve
    grace "Well, having someone like you around helps. It’s easier to take risks when you know you’re not alone."


    if graceep4 == True:
        jump sexygracee5s2
    else:
        jump endgracee5s2

    label sexygracee5s2:
        if _in_replay:
            show screen Replayexit
        pause 1 
        scene e5s2grace19 with dissolve:
            xalign 0.0
            linear 5.0 yalign 0.5
            linear 1.0 yalign 0.1
            repeat 1
        grace "Speaking of risks…"
        grace "The view is incredible, but you know what’s even better?"
        d " What’s that?"
        scene e5s2grace20
        with dissolve
        grace "You know, last time was amazing. But I can’t stop thinking about how much I want you again."
        d "Really? Out here in the middle of nature?"
        grace " Why not? No one’s around. Just the wind and the trees. I mean, this is our moment, isn’t it?"
        scene e5s2grace21
        with dissolve
        d "Grace… you’re full of surprises."
        grace "And you love it."
        grace "It’s just us here. No distractions. I want you to see me, just me."
        d "I do. More than you know."
        grace " Then show me."
        scene black
        with fade
        pause 1
        stop movie
        play music "musique/MYO0008-HipHopAndRockCinematicTrailer-stockmusic-net.mp3" volume 0.5
        play movie "images/animation/gracee5s2anim1.webm" volume 0 loop
        show movie
        ""
        grace "Yeah... That's it! So good!"
        d "Grace, you're so tight!"
        grace "We will have to do this more often!"
        d "I'm always happy to please you!"
        grace "Yeah, deeper... Please..."
        grace "That feels so good."
        ""
        stop movie
        scene black with dissolve
        grace "Wait a minute. Take me from behind!"
        play movie "images/animation/gracee5s2anim2.webm" volume 0 loop
        show movie
        ""
        grace "Oh! That angle is even better!"
        grace "Keep going... Please..."
        d "Grace, I won't last long!"
        grace "So, don't!"
        d "Grace..."
        ""
        with hpunch
        with flash
        stop movie
        scene e5s2grace23
        with vpunch
        with flash
        grace "Ohhhhhhhhhhhhh! Yes!!!!!!"
        pause 1
        with hpunch
        with flash
        scene black
        with Dissolve(4)
        scene e5s2grace24
        with fade
        grace "You know… this whole experience, it’s something I never thought I’d do."
        d "And I’m glad you tried. It’s moments like this that remind me why I fell for you."
        grace " Well, you’ve definitely made it memorable."
        $ renpy.notify(_("New Scene Gallery added"))
        $ renpy.end_replay()
        jump endgracee5s2

label endgracee5s2:
    scene e5s2grace18
    with dissolve
    d "Let’s head back down and see what other adventures wait for us."
    grace "I feel like I’ve achieved something amazing. Thanks for showing me the ropes, literally."
    d "No problem. You handled it really well for your first climb."
    grace "Maybe I’ll have to do it again sometime. But now I think it’s time to head back down."
    scene black
    with fade
    stop music fadeout 2
    pause 2

    if Traininggabyep5 == True:
        jump gabye5s2
    if Evelyncafe == True:
        jump evelyne5s2
    else:
        jump e5s3

label gabye5s2:

    play music "musique/ALG0202-EnergyRock-stockmusic-net.mp3" volume 0.2
    scene e5s2training1
    with fade
    pause 2 
    scene e5s2training2
    with dissolve
    pause 2 
    scene e5s2training3
    with dissolve
    d "Ah, there you are, Gabriella. I almost thought I was early."
    scene e5s2training4
    with dissolve
    gaby "You’re on time, [name]. That’s already a good start."
    scene e5s2training5
    with dissolve
    d "You’re always full of surprises, but I’m ready for whatever you’ve planned."
    gaby "Before we start, how are you holding up after that last match?"
    d "I’ve been better, to be honest. My back’s been acting up ever since… that incident with Ruby."
    scene e5s2training6
    with dissolve
    gaby "What incident?"
    d "I… well, she was about to get hurt, and I had to step in. Things got a little… intense."
    scene e5s2training7
    with dissolve
    gaby "You put yourself on the line for her? I didn’t think you had it in you."
    d "I couldn’t just stand there and watch. But now… I’m paying the price."
    gaby "A hero in need of a little recovery, then?"
    d "Something like that."
    scene e5s2training8
    with dissolve
    gaby "I know a place. Small massage studio not far from here. Sports therapy specialists. I learned some tricks myself from them."
    d "Are you’re offering to handle the massage yourself?"
    scene e5s2training9
    with dissolve
    gaby "I think you’d enjoy that a bit too much."
    d "Can’t blame me for trying, can you?"
    scene e5s2training10
    with dissolve
    gaby "Alright, enough chit-chat. Time for some training."
    d "Training for what exactly?"
    gaby "You’ll see. Just be ready to work on those skills."
    d "Okay, but why do I feel like you’re hiding something?"
    scene e5s2training11
    with dissolve
    gaby "If I told you now, it wouldn’t be nearly as fun to watch your reaction."
    play sound "sound/WhooshEpic.mp3" volume 1
    dpense "Wait... what is?"
    play sound "sound/Vooh.wav" volume 1
    scene training3240
    $ renpy.movie_cutscene("images/animation/training3.webm", stop_music=False)
    scene training3240
    with dissolve
    pause 0.5
    scene e5s2training12
    with flash
    d "Hey!"
    mad "Took you long enough to notice me, [name]."
    scene e5s2training13
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s2training14
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s2training15
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    d "Madison? What are you doing here?"
    mad "Gaby said you needed some real training. So… here I am."
    scene e5s2training16
    with dissolve
    d "Oh, you’re on."
    scene e5s2training17
    with dissolve
    gaby "Today’s exercise is simple. I want you to shoot at each other with as much strength as you can handle."
    scene e5s2training18
    with dissolve
    d "What???" with hpunch
    scene e5s2training19
    with dissolve
    mad "Ahah! I’m going to LOVE this!"
    gaby "And remember… you have to return the ball with just as much strength as it comes at you. Simple, right?"
    scene e5s2training20
    with dissolve
    d "Wait, you’re serious?!"
    play sound "sound/whooshtir.wav" volume 1
    scene e5s2training21
    with hpunch
    mad "Look at the ball, [name]!"
    scene e5s2training22
    with dissolve
    d "I wasn’t ready!"
    play sound "sound/whooshtir.wav" volume 1
    scene e5s2training23
    with hpunch
    mad "And now?"
    d "Madison!!!!!"
    scene black
    with Dissolve(2)
    pause 2
    scene e5s2training24
    with dissolve
    d "You’re good, Madison. I’ll give you that."
    mad "You’re not bad yourself. Guess we’ll just have to keep pushing each other."
    scene e5s2training25
    with dissolve
    gaby "That’s the spirit. Now, get some rest. We’ll need you both at your best for the next match."
    d "Thanks, Gaby. And Madison… nice job out there."
    mad "You too, [name]. But next time…"
    mad "Don’t look so terrified when the ball’s flying at your face!"
    stop music fadeout 4
    scene black
    with Dissolve (4)


    $ Training3 = True

    if Evelyncafe == True:
        jump evelyne5s2
    else:
        jump e5s3


label evelyne5s2:

    scene black
    pause 2 

    play music "musique/JOL0106-GetDown-stockmusic-net.mp3" volume 0.2
    scene e5s2evelyn4
    with fade
    pause 2
    scene e5s2evelyn5
    with dissolve
    pause 2
    d "Wow... Fancy place."
    d "She said she’d be waiting inside."
    scene e5s2evelyn6
    with hpunch
    ji "Young man."
    scene e5s2evelyn7
    with dissolve
    d "Hum?"
    scene e5s2evelyn2
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s2evelyn3
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s2evelyn
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    d "Evelyn, good to see you."
    scene e5s2evelyn8
    with dissolve
    evelyn "You’re on time. I was beginning to wonder if you could be both bold and punctual."
    scene e5s2evelyn9
    with dissolve
    d "I aim to impress."
    scene e5s2evelyn10
    with dissolve
    evelyn "Impress? Careful, young man. First impressions only go so far."
    d "Maybe, but it’s honest. That counts for something, doesn’t it?"
    evelyn "Let’s see if you can keep it that way."
    d "I wasn’t even sure you’d actually want to meet after our call."
    scene e5s2evelyn11
    with dissolve
    evelyn "Why not? You surprised me at the Palazio. Mystery and confidence are rare commodities these days."
    d "So I passed the first test?"
    scene e5s2evelyn12
    with dissolve
    evelyn "Passed is a bit ambitious. Let’s say… you managed to stay on the board."
    d "Intrigue over failure? I’ll take that."
    evelyn "Good. But remember… intrigue only works if you don’t try too hard. Balance, darling, is the key."
    d "And what does balance look like to you?"
    scene e5s2evelyn13
    with dissolve
    evelyn "It’s knowing when to press forward… and when to make someone chase you instead."
    evelyn "When to speak, and when to let silence say more than words ever could."
    scene e5s2evelyn14
    with dissolve
    evelyn "And above all… it’s about confidence, not arrogance. Never forget the difference."
    scene e5s2evelyn15
    with dissolve
    evelyn "You have potential, [name]. But I’m not here for empty words. I value action, thoughtfulness… purpose."
    d "Maybe that’s why I came. To show you I’m not just talk."
    scene e5s2evelyn16
    with dissolve
    evelyn "Careful. That sounds suspiciously close to a promise. And promises… they carry weight."
    play sound "sound/Photo.mp3" volume 1
    with flash
    scene e5s2evelyn17
    with dissolve
    evelyn "Before I go, I have something for you."
    d "What’s this?"
    scene e5s2evelyn18
    with dissolve
    evelyn "A key to a different kind of game, [name]. One most people don’t even realize they’re already playing."
    evelyn "This is a badge that can let you enter into the VIP section at Palazio."
    d "A special invite from the woman herself?"
    scene e5s2evelyn19
    with dissolve
    evelyn "Don’t get ahead of yourself. I’m simply… offering a door."
    evelyn "Whether you have the courage to walk through it is another matter entirely."
    d "You’ll see. I don’t plan on wasting opportunities."
    scene e5s2evelyn20
    with dissolve
    evelyn "Good. I look forward to seeing how far you’re willing to go."
    evelyn "But for now… I have to leave you wondering."
    d "I won’t keep you then."
    evelyn "Wise choice. And remember, [name]... when the game starts, take some chances. And don’t disappoint me."
    scene e5s2evelyn21
    with dissolve
    dpense "A different kind of game…? And that VIP section… What the hell am I about to step into?"
    dpense "She’s unlike anyone I’ve met. Confident, mysterious… it feels like she’s testing me, daring me to step up."
    dpense "But I’m not one to back down from a challenge."
    stop music fadeout 2
    scene black
    with fade
    pause 2


jump e5s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
