label e5s4:

    scene black
    with dissolve
    pause 2

    if juliaep5s1 == True:
        play music "musique/DEG0001-ABitRainy-stockmusic-net.mp3" volume 0.2
        scene e5juliahop
        with Dissolve(4)
        pause 1 
        scene e5juliahop3
        with dissolve
        pause 2
        scene e5juliahop2
        with dissolve
        pause 2 
        scene e5juliahop4
        with dissolve
        julia "[name]!"
        scene e5juliahop5
        with dissolve
        d "Julia!"
        d "I'm so sorry... Are you okay?"
        scene e5juliahop6
        with dissolve
        julia "I..."
        julia "I don't even know what I'm supposed to do..."
        julia "I knew it would happen eventually but..."
        scene e5juliahop7
        with dissolve
        julia "Now that it's real, I just... I don't know how to handle it."
        julia "The paperwork, the funeral..."
        julia "How the hell am I supposed to..."
        scene e5juliahop8
        with dissolve
        d "Hey... I'm here."
        d "I'll help you, okay?"
        d "Don't worry. We'll figure this out together."
        d "First, you need to breathe."
        scene e5juliahop9
        with dissolve
        julia "Yeah..."
        julia "But I don’t know how I’m gonna get through this..."
        julia "I don’t even know how much a funeral costs..."
        julia "And I..."
        julia "I..."
        scene e5juliahop10
        with dissolve
        d "I'm right here."
        scene e5juliahop11
        with dissolve
        d "You're not alone."
        scene e5juliahop12
        with dissolve
        julia "Thank you..."
        scene e5juliahop13
        with dissolve
        pause 1 
        scene e5juliahop14
        with dissolve
        ji "Miss Carter?"
        scene e5juliahop15
        with dissolve
        d "Hm?"
        julia "Yes?"
        scene e5juliahop16
        with dissolve
        ji "We’ve got a letter for you. You need to read it alone. It contains sensitive information."
        ji "Just know everything related to your mother has been taken care of."
        scene e5juliahop17
        with dissolve
        julia "Wait... What?"
        julia "But... who did this?"
        julia "Who are you?"
        scene e5juliahop18
        with dissolve
        ji "I'm not allowed to say anything more."
        ji "Just follow what’s written in the letter."
        scene e5juliahop19
        with dissolve
        julia "[name]?"
        julia "What the hell is going on?"
        scene e5juliahop20
        with dissolve
        d "I have no idea..."
        scene e5juliahop21
        with dissolve
        julia "He said I have to read it alone."
        d "Yeah... Alright."
        scene e5juliahop22
        with dissolve
        d "I'll give you some space."
        d "But call me if you need anything, okay?"
        julia "I will... I’m gonna go back and sit with my mom for a bit."
        d "Thanks for calling me, Julia."
        scene e5juliahop23
        $ renpy.movie_cutscene("images/animation/juliakissep5.webm", stop_music=False)
        scene e5juliahop23
        with dissolve
        julia "I wish I could’ve seen you under better circumstances..."
        d "Hey. You’re doing what’s best for her."
        d "And we’ll get through this. Together."
        julia "Thank you..."
        julia "See you tomorrow."
        d "See you."
        scene black
        with Dissolve(4)
        pause 2
        stop music fadeout 2

    scene ep5s1i38
    with dissolve
    pause 1
    play music "musique/MAS0454-Kulikar3-stockmusic-net.mp3"
    if juliaep5s1 == True:
        dpense "Julia..."
        dpense "She held it all together until the very end."
        dpense "And now she has to manage everything on her own."
        dpense "I wish I could do more..."
    else:
        dpense "That guy... Marc."
        dpense "What the hell was that meeting?"
        dpense "Everything he said still echoes in my head."
        dpense "Is this all really just a show? A trap?"


    play sound "sound/Vibration.mp3"
    pause 1
    dpense "Ruby?"
    scene black
    show expression "rubyphone1" as ruby1 with moveinbottom
    ruby "Hey... You okay?"
    d "Yeah... Just trying to process everything."
    show expression "rubyphone2" as ruby1 with dissolve
    ruby "I heard about Julia..."

    if juliaep5s1 == True:
        d "Yeah. I went to see her."
        d "She’s trying to hold it together but... it’s rough."
        d "She lost her mom today."
    else:
        d "...Wait. What about Julia?"
        ruby "Oh. You didn’t know?"
        ruby "Her mom passed away today."
        d "Shit... No, I hadn’t heard."
        d "How is she?"
        ruby "Not good, obviously. She’s trying to keep it together, but... yeah."

    d "Damn..."
    d "That’s a lot to take in."
    show expression "rubyphone3" as ruby1 with dissolve
    ruby "Yeah. Everything’s a mess lately."
    ruby "And with what happened to me... and what happened to you..."
    d "Yeah. I wanted to talk to you about that."
    d "I met someone. His name’s Marc."
    d "He told me some things. Crazy things."
    show expression "rubyphone4" as ruby1 with dissolve
    ruby "Wait. Hold on. This sounds big."
    ruby "Let me get Madison and Grace. We all need to talk."
    show expression "rubyphone6" as ruby1 with dissolve
    ruby "Adding Madison... and Grace..."
    play sound "sound/Vibration.mp3"
    pause 1
    show expression "rubyphone5" as ruby2 at right with moveinright
    stop music fadeout 1
    ji "Palazio Pizza, what can I get ya?"
    play sound "sound/Scratch.mp3" volume 0.2
    d "...Ruby?"
    show expression "rubyphone7" with dissolve
    ruby "Oops! Wrong number!"
    ji "Wait! First-time callers get 20 percent off on pepperoni pizzas!"
    ruby "BYE!"
    hide expression ruby2 with moveoutright
    show expression "rubyphone6" as ruby1 with dissolve
    play music "musique/Aerocity-Stranger.mp3" volume 0.2
    ruby "Okay! Got the real Madison this time."
    show expression "rubyphone8" as ruby2 at right with moveinright
    mad "What’s going on?"
    show expression "rubyphone9" as ruby3 at left with moveinleft
    grace "Wow, that sounds serious."
    show expression "rubyphone10" as ruby with dissolve
    ruby "I wanted to talk with all of you. Because… things are getting out of hand."
    ruby "Grace, you weren’t there, so I’ll explain."
    show expression "rubyphone11" as ruby with dissolve
    ruby "Emerick pushed me. He just lost it. I don’t think he meant for it to go that far, but..."
    ruby "I got shoved into the street. A car almost hit me."
    ruby "[name] pulled me back just in time."
    show expression "rubyphone12" as ruby3 with dissolve
    grace "What?! Are you serious?"
    ruby "Yeah. I'm fine now, but... it was close."
    show expression "rubyphone13" as ruby2 with dissolve
    mad "When I found out, I was fucking furious."
    mad "Emerick’s out of control."
    grace "Why the hell is he still allowed near us?"
    ruby "I don’t know. He just acts like nothing happened."

    pause 1

    show expression "rubyphone14" as ruby2 with dissolve
    mad "And then Julia..."

    if juliaep5s1 == True:
        d "Yeah. I went to see her today."
        d "She’s trying to keep it together but... it’s rough."
        d "Her mom passed away."
        show expression "rubyphone15" as ruby3 with dissolve
        grace "I know... it’s awful."
        show expression "rubyphone16" as ruby with dissolve
        ruby "She doesn’t talk about it much, but you can tell she’s crushed."
    else:
        d "I didn’t see her, but I heard what happened..."
        d "That’s... that’s really heavy."
        show expression "rubyphone15" as ruby3 with dissolve
        grace "Yeah. Her mom passed away today."
        show expression "rubyphone16" as ruby with dissolve
        ruby "She’s holding it all in. Like always."

    pause 1

    d "And on top of that, I met someone today. A guy named Marc."
    show expression "rubyphone17" as ruby2 with dissolve
    mad "Who's that?"
    d "He claims to know everything about the B.E.S.T."
    d "Said this tournament isn’t what we think it is."
    show expression "rubyphone18" as ruby with dissolve
    ruby "You mean it’s not just about winning the house?"
    d "Exactly. According to him, we’re part of a larger system. Something planned."
    d "We’ve been picked. Tested. Watched."
    show expression "rubyphone19" as ruby3 with dissolve
    grace "What the hell..."
    show expression "rubyphone20" as ruby2 with dissolve
    mad "I knew this whole thing felt rigged."
    ruby "What else did he say?"
    d "Not much. But he said I'd start to understand soon..."
    d "...that the game... has already started."
    show expression "rubyphone21" as ruby with dissolve
    ruby "This is way more than we signed up for..."
    show expression "rubyphone12" as ruby3 with dissolve
    grace "Wait, what do you mean we've been watched? Since when?"
    d "I don’t know. He said it’s been going on for a while."
    show expression "rubyphone13" as ruby2 with dissolve
    mad "So, we’re what? Lab rats in an experiment?"
    d "I don’t think it’s that simple..."
    show expression "rubyphone10" as ruby with dissolve
    ruby "Then what is it? A test? A trap?"
    d "Honestly? I don’t have the full picture yet."
    show expression "rubyphone19" as ruby3 with dissolve
    grace "Did he say who’s behind it?"
    d "No. Just that it’s part of something much bigger. That we were chosen."
    show expression "rubyphone8" as ruby2 with dissolve
    mad "Chosen for what exactly? To compete? To fight? To lose everything?"
    show expression "rubyphone11" as ruby with dissolve
    ruby "I knew something was off from the beginning, but this…"
    grace "You said he knows everything? Then why didn’t he tell you more?"
    d "He said I wasn’t ready yet. That I’d understand soon."
    show expression "rubyphone22" as ruby2 with dissolve
    mad "Ugh. That’s so damn cryptic."
    ruby "Sounds like the start of a cult recruitment pitch..."
    show expression "rubyphone12" as ruby3 with dissolve
    grace "Or the plot of a really messed up game show."
    d "He said we were all part of something... deeper than just winning."
    show expression "rubyphone16" as ruby with dissolve
    ruby "Well, that’s comforting. Totally reassuring."
    show expression "rubyphone8" as ruby2 with dissolve
    mad "So what do we do? Just keep pretending nothing’s happening?"
    show expression "rubyphone19" as ruby3 with dissolve
    grace "We need more information. We can't fight something we don’t even understand."
    d "Tomorrow, I’ll try to figure out more. Talk to him again if I can."
    show expression "rubyphone16" as ruby with dissolve
    ruby "Just... be careful, okay?"
    show expression "rubyphone17" as ruby2 with dissolve
    mad "Yeah. We don’t know what we’re dealing with."
    show expression "rubyphone9" as ruby3 with dissolve
    grace "And if it really is bigger than the tournament… we’re going to need each other."
    show expression "rubyphone2" as ruby with dissolve
    ruby "We already do."
    pause 1
    show expression "rubyphone8" as ruby2 with dissolve
    mad "Alright... we should probably get some rest."
    mad "We’ve got classes tomorrow, and probably more crazy shit to deal with."
    show expression "rubyphone12" as ruby3 with dissolve
    grace "Yeah... My head’s spinning."
    show expression "rubyphone2" as ruby with dissolve
    ruby "Let’s sleep on it. We’ll talk more tomorrow."
    mad "Night, everyone."
    hide expression "rubyphone20" as ruby2 with moveoutright
    grace "Goodnight."
    hide expression "rubyphone9" as ruby3 with moveoutleft
    stop music fadeout 3
    pause 1
    show expression "rubyphone3" as ruby with dissolve
    play music "musique/Meydan-Changes.mp3" volume 0.2
    ruby "Hey... uh, before I hang up completely..."
    pause 1

    $ rubyPath = False
    $ gracePath = False
    $ juliaPath = False
    $ madiPath = False

    ruby "Can I ask you something weird?"
    d "Of course."
    show expression "rubyphone11" as ruby with dissolve
    ruby "Would it be okay if I came over tonight?"
    ruby "I just... don’t want to be alone after everything today."
    ruby "Emerick, the tournament stuff, Marc’s speech..."
    ruby "It’s just... too much. My head won’t stop spinning."

    if graceep4 == True:
        $ gracePath = True
    if JuliaHopital == True:
        $ juliaPath = True
    if madicarsex == True:
        $ madiPath = True

    if gracePath + juliaPath + madiPath >= 1:
        show expression "rubyphone16" as ruby with dissolve
        ruby "And I know I’m not the only one you’re close to."
        ruby "I’m not trying to mess with that, or step on anyone’s toes."
        show expression "rubyphone3" as ruby with dissolve
        ruby "But tonight... I don’t want to feel like I’m always second to someone else."
        ruby "I’m not asking for anything big."
        ruby "Just... let me feel safe, just for one night."
        d "Ruby..."
        ruby "Please. I’m tired of pretending I’m fine when I’m not."

    pause 1

    if persistent.patch_enabled == True:
        $ TEMP1 = e5s4c1
    else:
        $ TEMP1 = ""

    menu:
        "Yeah, come over.[TEMP1!t]":
            $ rubyPath = True
            d "Yeah... come over. You don’t have to go through this alone."
            hide expression ruby
            show expression "rubyphone1" as ruby
            ruby "Thanks..."
            ruby "I really needed to hear that tonight."
        "I don’t think that would be right...":
            if gracePath == True:
                d "I’d like to say yes, but... I’m trying to stay true to Grace."
                d "She deserves that."
                hide expression ruby
                show expression "rubyphone2" as ruby
                ruby "...Yeah. She does."
                ruby "Thanks for being honest."
            elif juliaPath == True:
                d "You matter to me, Ruby. Really."
                d "But I’m with Julia now, and I want to stay true to that."
                hide expression ruby
                show expression "rubyphone2" as ruby
                ruby "That’s... good of you."
                ruby "She's lucky."
            elif madiPath == True:
                d "Madison and I have something... and I don’t want to mess it up."
                hide expression ruby
                show expression "rubyphone2" as ruby
                ruby "Then I won’t make things harder."
                ruby "I’ll be okay. I just needed to ask."
            else:
                d "I’m not sure it’s a good idea tonight..."
                d "I don’t want to blur things between us."
                hide expression ruby
                show expression "rubyphone2" as ruby
                ruby "Fair enough."
                ruby "Thanks for being real with me."
                d "Always. Get some rest, okay?"

    scene black with Dissolve(4)

    if rubyPath == True:
        scene ep5s1i38
        with dissolve
        pause 1
        d "Guess I’ve got a few minutes before she gets here."
    else:
        d "She understood... Still, I hope she’s okay tonight."
        scene ep5s1i38
        with dissolve
        pause 1
        d "I should probably check my phone."

    if GraceEsca == True and graceep4 == True:

        play sound "sound/vibration.mp3"
        pause 1

        dpense "A message from Grace?"

        $ phone.menu = False
        $ phone.group_chat.group_chat("grace1").add_character(["grace", "d"])
        phone discussion "grace1":
            time year 2023 month 9 day 10 hour 22 minute 30
            "grace" "Hey... Just wanted to say good night :)"
            "grace" "Today was amazing. I'm still smiling from that climb. 💕"
            "grace" "Here’s my favorite photo of us from earlier!"
            image "grace" "phone/assets/graceesca1.webp"
        phone end discussion

        dpense "She looks really happy here..."
        dpense "And honestly... so do I."
        dpense "It’s a great memory. Just the two of us, no pressure..."
        dpense "Should be great on my OnlyStan..."

        menu:
            "Yeah, she looks amazing. Let people see that.":
                $ addOnlystanPost(_("Climbing Morning ;)"), _("Best view with best girl!"), 1, "phone/assets/graceesca1.webp", "grace_1")
                d "Beautiful picture."
                d "We looks strong, confident, and radiant."
            "No, I’ll keep it for myself.":
                d "This one's just for us."
                d "Not everything has to be out there."


        play sound "sound/vibration.mp3"
        pause 1

        $ phone.menu = False
        $ phone.group_chat.group_chat("grace1").add_character(["grace", "d"])
        phone discussion "grace1":
            time year 2023 month 9 day 10 hour 22 minute 32
            "grace" "Oh, and this one..."
            "grace" "Don't you dare post it 😉"
            image "grace" "phone/assets/graceesca2.png"
            "grace" "Good night, [name]. Sleep tight. 💤💗"
        phone end discussion

        dpense "Damn... She's full of surprises."
        $ wallpapers.append("phone/assets/graceesca2.jpg")
        $ renpy.notify (_("A wallpaper has been added"))

    $ chagabymass = False
    $ gabymass = False

    if charlottewing == True and Training3 == True:

        play sound "sound/vibration.mp3"
        pause 1

        dpense "Charlotte?"

        $ phone.menu = False
        $ phone.group_chat.group_chat("cha1").add_character(["cha", "d"])
        phone discussion "cha1":
            time year 2023 month 9 day 10 hour 22 minute 35
            "cha" "Hey, handsome. Got any plans at 9 a.m. tomorrow?"
            "d" "Hmm...No, why?"
            "cha" "Because you should come by the massage parlor."
            "cha" "No questions. Just trust me 😏"
            "cha" "Let’s just say... you won’t be disappointed."
            pause   

        dpense "Now I’m really curious..."

        phone discussion "cha1":
            "d" "Alright, I’ll be there."
            "cha" "Good boy 😘"
            "cha" "Sleep tight. You’re gonna need your energy."

        phone end discussion

        play sound "sound/vibration.mp3"
        pause 1

        d "Another message?"

        $ phone.menu = False
        $ phone.group_chat.group_chat("cha1").add_character(["cha", "d"])
        phone discussion "cha1":
            time year 2023 month 9 day 10 hour 22 minute 37
            image "cha" "phone/assets/chawp2.webp"

        phone end discussion

        dpense "...Whoa."
        dpense "Okay, that’s... definitely not what I expected before bed."
        dpense "What is she planning?"

        $ chagabymass = True
        $ wallpapers.append("phone/assets/chawp2.png")
        $ renpy.notify (_("A wallpaper has been added"))

        pause 1

    if Training3 == True:

        play sound "sound/vibration.mp3"
        pause 1

        dpense "Gabriella?"

        $ phone.menu = False
        $ phone.group_chat.group_chat("gaby1").add_character(["gaby", "d"])
        phone discussion "gaby1":
            time year 2023 month 9 day 10 hour 22 minute 40
            "gaby" "Hello [name]. I booked a recovery massage for you tomorrow at 9:30."
            "gaby" "A proper massage will ease the tension you've built up."
            "gaby" "A professional will take care of it. Just show up rested."
            "d" "Wait… not you?"
            "gaby" "I thought you’d prefer someone with qualified hands."
            "d" "Not sure anyone’s hands would beat yours..."
            "gaby" "Flattering... and dangerous."
            "gaby" "Now rest. Tomorrow will be... instructive."
            "d" "You’re not making it easy to sleep, you know."
            "gaby" "Good night, [name]."
            "d" "Good night, Gabriella..."

        phone end discussion
        $ gabymass = True
        dpense "Why do I feel like that massage won’t go the way I expect?"

    pause 1

    $ bluephoneep5 = False
    $ blueep5 = False

    if blueep4 == True:
        $ bluephoneep5 = True
        $ globalnotif += 1
        $ appnotif += 1

    $ addOnlystanPost(_("Long day of squats, sweat, and stretches... Time to give these legs a break. Good night, team. 💤🍑"), _("Rest mode: activated 😴"), 2, "phone/assets/fannyrest.png", "fanny_squats", _("Nighty night, muscle queen. May your dreams be less sore than your glutes."))

    $ addOnlystanComment(_("Wait, you did legs today *and* you’re still standing? Teach me your ways. 😩"), 6, "fanny_squats")
    $ addOnlystanComment(_("Pretty sure your legs just bench-pressed my willpower."), 10, "fanny_squats")
    $ addOnlystanComment(_("Sweet dreams, Fanny. Hope tomorrow’s workout is just lifting spoons to your mouth. 🥣😅"), 7, "fanny_squats")
    $ addOnlystanComment(_("You work hard AND say good night like a goddess? That’s just unfair."), 11, "fanny_squats")
    $ addOnlystanComment(_("Brb going to the gym so I can sleep like Fanny tonight."), 5, "fanny_squats")
    $ addOnlystanComment(_("You inspire me... but my couch says no."), 9, "fanny_squats")



    if existsPost("julia_1"):
        $ addOnlystanComment(_("She looks so happy with you! Glad she had you by her side today.."), 2, "julia_1")

    if existsPost("grace_1"):
        $ addOnlystanComment(_("Nice climb. Thought you’d need Grace to carry you up."), 2, "grace_1")


    show screen telephone()

label Choixtelep5s4:

    if globalnotif>0:
        show screen telephonenotif()
    if globalnotif==0:
        hide screen telephonenotif

    menu:
        "Pass":
            $ globalnotif = 0
            $ appnotif = 0
            jump fine5s4

label bluephoneep5:
    $ phone.menu = False
    phone discussion "sofia1":
        time year 2023 month 9 day 10 hour 22 minute 45
        "d" "Sofia..."
        "d" "Just wanted to check in on you."
        "d" "It’s been a wild day. You okay?"
        "sofia" "Mmm... you thinking about me in bed, or just being sweet? 😉"
        "d" "Can’t it be both?"
        "sofia" "Flirt."
        "sofia" "I’m okay. Tired... but I'm glad you messaged me."
        "d" "I wish I could be with you right now."
        "sofia" "Maybe next time I won’t let you leave so easily."
        "d" "Looking forward to it."
        "sofia" "Sweet dreams, [name]. Don’t do anything I wouldn’t dream about."
        "d" "Good night, Sofia."
        image "sofia" "phone/assets/bluemess.webp"

    phone end discussion

    $ wallpapers.append("phone/assets/bluemess.png")
    $ renpy.notify (_("A wallpaper has been added"))
    pause 1
    dpense "Damn... Even her kisses are flirty."
    $ blueep5 = True
    $ bluephonep5intro = False
    $ globalnotif -= 1
    $ appnotif -= 1
    jump Choixtelep5s4

label fine5s4:
    hide screen telephone
    hide screen telephonenotif
    dpense "Elise..."
    dpense "Still no answer."
    dpense "You usually text back right away."
    dpense "I hope everything’s okay."
    dpense "..."
    dpense "I’ll just send a message. Maybe she’ll see it later."
    dpense "Hey. Just checking in. Hope you’re okay. Let me know if you need anything."
    dpense "I hate not knowing... Elise, where are you?"

    scene black with Dissolve(2)

    if rubyPath == True:
        stop music fadeout 2
        pause 2
        scene rubyfins41
        with dissolve
        play music "musique/LE06-EmotionalHipHop-Jacome.mp3" volume 0.2 fadein 2
        pause 1
        ruby "Hey..."
        scene rubyfins42
        play sound "sound/Photo.mp3" volume 1
        with flash
        pause 0.5
        scene rubyfins43
        play sound "sound/Photo.mp3" volume 1
        with flash
        pause 0.5
        scene rubyfins44
        play sound "sound/Photo.mp3" volume 1
        with flash
        pause 2
        scene rubyfins45
        with dissolve
        d "Hey. Come in."
        scene rubyfins46
        with dissolve
        d "You're..."
        scene rubyfins47
        with dissolve
        d "Beautiful."
        scene rubyfins48
        with dissolve
        ruby "Thank you..."
        scene rubyfins49
        with hpunch
        ruby "...again for letting me come over."
        scene rubyfins410
        with dissolve
        ruby "I know it’s late. I just didn’t want to be alone."
        scene rubyfins411
        with dissolve
        d "You’re not alone tonight."
        scene rubyfins412
        with dissolve
        ruby "It's been a lot... Emerick, the tournament, Marc..."
        ruby "I don’t even know where I stand anymore."
        d "Right here. With me."
        scene rubyfins413
        with dissolve
        ruby "Careful... You keep talking like that, I might fall for you."
        d "Maybe that's what you need."
        ruby "Maybe."
        scene black with Dissolve(2)
        pause 1 
        scene rubyfins414
        with dissolve
        pause 1 
        scene rubyfins415
        with dissolve
        pause 1 
        scene rubyfins416
        with dissolve
        pause 1 
        scene rubyfins417
        with dissolve
        ruby "Can you come close? Like... really close?"
        scene rubyfins418
        with dissolve
        d "As close as you want."
        pause 1
        scene rubyfins419
        with dissolve
        ruby "This feels... safe."
        if gracePath or juliaPath or madiPath:
            ruby "Even if you’re close to someone else... tonight, you made space for me."
            ruby "That means a lot."
            d "I see you, Ruby. I always have."
        pause 1 
        scene rubyfins420
        with dissolve
        ruby "You smell good..."
        ruby "That’s dangerous when I’m this vulnerable."
        d "Then I’ll try not to take advantage..."
        ruby "I trust you."
        pause 1
        scene rubyfins421
        with dissolve
        ruby "I feel... something changing. Between us."
        d "You’re not the only one."
        ruby "Thank you for being here."
        scene rubyfins422
        with dissolve
        ruby "Good night, [name]..."
        d "Good night, Ruby."
        scene black with Dissolve(2)
        pause 1 
        dpense "She fell asleep fast..."
        dpense "She looks so peaceful now. So... soft."
        dpense "Her shoulder's bare... the blanket slipped down a bit."
        scene rubyfins423
        with dissolve
        dpense "My hand’s resting on her side…"
        dpense "Without thinking, my hand slides… just a little..."
        scene black
        $ renpy.movie_cutscene("images/animation/rubydoigts.webm", stop_music=False)
        scene black
        pause 1
        scene rubyfins424
        with dissolve
        dpense "Her breast."
        dpense "Barely. The warmth of her skin under my fingers."
        scene rubyfins425
        $ renpy.movie_cutscene("images/animation/rubyrespi.webm", stop_music=False)
        scene rubyfins425
        with dissolve
        dpense "She doesn’t move. Just breathes... slow. Calm."
        scene rubyfins426
        with dissolve
        dpense "She’s here, in my arms."
        dpense "Trusting me with everything."
        scene rubyfins427
        with dissolve
        dpense "Her heartbeat... it’s fast now."
        dpense "Did I wake her?"
        scene rubyfins428
        with vpunch
        ruby "Don’t move..."
        pause 1
        dpense "She’s awake."
        dpense "And she’s letting it happen."
        pause 2
        dpense "And now... I don’t think I can go back."
        pause 2
        scene black with Dissolve(4)
        pause 2
        jump e5s5


    if rubyPath == False:

        scene chambre_nuit
        with fade
        scene rubyfins429
        with dissolve
        d "I hope Ruby's okay..."
        d "She sounded really shaken up."
        if gracePath + juliaPath + madiPath >= 2:
            d "It’s just... hard."
            d "No matter how much I care, I can’t be everywhere at once."
            d "And sometimes, trying to protect everyone means letting someone down."
        elif gracePath or juliaPath or madiPath:
            d "I made my choice."
            d "It doesn’t mean I don’t care about her... but I need to be honest with myself."
        else:
            d "She asked for comfort and I turned her down..."
            d "I just hope she understands why."
        d "This whole thing... the B.E.S.T, Emerick, Marc..."
        d "It’s like everything is falling apart and coming together at the same time."
        scene rubyfins430
        with dissolve
        d "And tomorrow probably won’t be any calmer."
        d "One step at a time..."

        scene black with Dissolve(4)
        stop music fadeout 2
        pause 1

        jump e5s5
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
