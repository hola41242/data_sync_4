label e5s3:

    pause 2 
    stop music fadeout 2
    scene black
    with dissolve

    phone discussion "ji1":
        time year 2023 month 9 day 10 hour 21 minute 00
        "ji" "Come to 21st Upper Street in an hour."
        "d" "Huh? Why?"
        "ji" "Stop asking questions and just do it."
        "d" "And if I don’t want to?"
    phone end discussion

    dpense "And... no response..."
    dpense "Well... I think I have no choice."
    dpense "Maybe I’ll finally get some answers to all of this..."

    scene black
    with dissolve
    pause 2
    play music "musique/MYO0005-ScienceAndTechnology-stockmusic-net.mp3" volume 0.2
    scene marce5s3i1
    with fade
    pause 1 
    dpense "This building is scary."
    scene marce5s3i2
    with dissolve
    dpense "What’s this…?"
    play sound "sound/Cinematic Impact.mp3" volume 1
    pause 0.5
    scene marce5s3i3
    with vpunch
    ji "Welcome, [name]."
    pause 1
    play sound "sound/whooshpetit.wav" volume 1
    scene marce5s3i4
    with dissolve
    ji "You can sit here."
    d "May I have your name?"
    ji "You don't need my name, but… if you insist, you can call me Marc."
    d "Okay…"
    scene marce5s3i5
    with dissolve
    marc "So... [name]. I’m sure you have a lot of questions and are waiting for answers."
    marc "But let me be clear. I’m not here to answer them. Not directly."
    d "What? Then why am I here?"
    marc "Because you need to understand where you’re standing… and because some people vouched for you to receive a little help."
    d "Help? Why would I need help?"
    marc "Again with the useless questions."
    scene marce5s3i6
    with dissolve
    marc "You’re not from here. You don’t know anyone. You’ve been thrown into a competition that could change your life…"
    marc "And you’re asking me why you’d need help?"
    d "I…"
    marc "Don’t waste your breath. Listen carefully instead."
    marc "Someone thought you deserved a chance to understand the bigger picture before you lose yourself in it."
    scene marce5s3i7
    with dissolve
    marc "Tell me, [name]… what do you know about the B.E.S.T?"

    menu:
        "It’s a competition":
            d "It’s a competition between students to get a good position at Orushi Corp."
            marc "Wrong."
            d "Huh?"
            marc "That’s what they told you. But that’s not the real purpose at all."
            d "Then what is it?"
            marc "You’re starting to ask better questions."
            jump bestexplanation
        "It’s a lottery":

            d "It’s a lottery. 100 students randomly chosen to compete for one position."
            marc "There’s no such thing as randomness, [name]."
            d "What do you mean?"
            marc "You’re starting to understand. Keep going."
            jump bestexplanation
        "It’s entertainment":

            d "It’s just entertainment for some rich guy who wants to watch people fight for his amusement."
            marc "Not far from the truth… but you’re still missing the point."
            marc "Orushi isn’t the real audience here."
            d "Then who is?"
            marc "Ask the right questions, and I’ll explain."
            jump bestexplanation

label bestexplanation:
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i8
    with dissolve
    marc "Do you remember the gladiators of the Roman Empire?"
    d "Hmm… yeah."
    marc "Great arenas, roaring crowds, men fighting beasts or each other to the death. Spectacle at its finest."
    marc "But tell me… who paid for all of that?"
    d "The Emperor?"
    marc "No. His wealth wasn’t endless, despite what people liked to believe."
    d "Then… the Empire?"
    marc "With the cost of constant wars? Hardly. You’re still not seeing it."
    dpense "What is he getting at…?"
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i9
    with dissolve
    marc "It was the wealthy families, the merchants, the powerful elites. They financed the games, not out of charity… but to keep control."
    marc "A hungry, angry population is dangerous. But give them bread… and a circus, and they’ll forget their misery."
    marc "Heroes to cheer for. Blood to quench their frustrations. Dreams of glory to distract them from their own chains."
    marc "And now, look around you. What is the B.E.S.T if not the modern-day arena?"
    marc "Throughout history, people sensed this hidden hand at work."
    marc "But since they couldn’t see it, they gave it names..."
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i11
    with dissolve
    marc "Legends. Myths. Conspiracies."
    marc "The Illuminati. The Freemasons. The Templars."
    marc "And today? The Bilderberg Group, the Deep State, the so-called global elites."
    marc "For centuries, it was enough to control information. To decide what truths were told… and which were buried."
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i10
    with dissolve
    marc "But times have changed. Information moves too fast now."
    marc "One rumor, one scandal, one viral video… and entire nations can burn before we even have time to react."
    marc "Take a recent example... Do you really think it was a coincidence that reality TV exploded right when the last major economic crisis hit?"
    marc "Millions of people were losing their jobs, their homes, their futures..."
    marc "And what did they find waiting for them every night?"
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i12
    with dissolve
    marc "Shows about overnight fame, easy money, and lives of luxury completely out of reach."
    marc "Keep them dreaming. Keep them distracted. While their real lives were falling apart, they were too busy watching others pretend to live perfectly."
    marc "And when the screens in their living rooms weren’t enough... we slipped the circus right into their pockets."
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i13
    with dissolve
    marc "Social media took over. Endless scrolling, endless outrage, endless dopamine hits."
    marc "Endless outrage to keep them distracted, while real decisions about their lives happened in secret."
    marc "Bread and circuses, [name]. That’s all it takes. Smaller screens. Same game."
    marc "Control isn’t about chains anymore. It’s about what holds their attention. And whoever controls that... controls everything."
    marc "But this time, it’s even more effective. Why CONTROL information when you can BECOME the information?"
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i14
    with dissolve
    marc "In a world where news moves faster than truth, what better way to shape reality than by making your game the center of it all?"
    marc "While people should be worrying about their jobs, their freedom, their futures…"
    marc "What do they talk about instead? YOU. Your victories. Your failures. Your scandals. Your life has become the news."
    marc "Heroes and villains, love stories and betrayals… all perfectly packaged for a world desperate for distraction."
    marc "And the best part? This time, it’s all real. No scripts. No lies. Just you… living the story they all want to consume."
    marc "You don’t just play the game, [name]. You ARE the game."
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i15
    with dissolve
    dpense "This… this can’t be real… My life… a show for the whole world?"
    d "Why me? Why any of us? What makes us so special?"
    play sound "sound/tirnormal.wav" volume 1
    scene marce5s3i16
    with dissolve
    marc "Ah… the most predictable question of all."
    marc "Do you really believe in coincidence, [name]?"
    marc "Every participant was chosen for a reason. Not for who they are… but for what they represent."
    d "So what’s my role in all this? Why am I here?"
    scene marce5s3i6
    with dissolve
    marc "You’re the unknown. The wild card. The variable that doesn’t fit the equation."
    marc "You have no legacy, no famous name, no hidden strings pulling you forward."
    marc "You’re the one who shouldn’t be here… and yet, here you are."
    marc "And that makes you dangerous."
    scene marce5s3i16
    with dissolve
    marc "You carry something rare, something uncontrollable: HOPE."
    marc "For every nameless face in the shadows, for every forgotten soul who’s told they’ll never matter… you’re the proof they might be wrong."
    marc "You’re the impossible dream."
    marc "The one who could win..."
    marc "...when everything was designed for you to fail."

    $ graceexplanation = True
    $ madiexplanation = True
    $ rubyexplanation = True
    $ juliaexplanation = True
    $ twinsexplanation = True
    $ kiraexplanation = True

label chooseexplanation:
    scene marce5s3i16
    with dissolve
    menu:
        "Grace?" if graceexplanation == True:
            d "And Grace? Why was she chosen?"
            scene marce5s3igrace
            with dissolve
            marc "Grace is the perfect image of a life already written before it even began."
            marc "Daughter of the Dean, educated, polished… her path was set from birth."
            marc "Marry well, strengthen family alliances, live a life of quiet obedience."
            marc "But deep down, she’s the face of every girl in a gilded cage, dreaming of breaking free."
            marc "To the world, she’s the symbol of silent rebellion against a destiny imposed by blood and duty."
            $ graceexplanation = False
            jump chooseexplanation

        "Madison?" if madiexplanation == True:
            d "What about Madison?"
            scene marce5s3imadison
            with dissolve
            marc "Madison is a paradox. A rebel born into power, an heiress who refuses to bow to her own legacy."
            marc "She carries the weight of her family’s name, yet she fights every day to prove she’s more than that."
            marc "And her daughter… her greatest weakness and her greatest strength."
            marc "She embodies every woman struggling to do it all, mother, competitor, leader."
            marc "While the world watches and judges."
            $ madiexplanation = False
            jump chooseexplanation

        "Ruby?" if rubyexplanation == True:
            d "And Ruby? Why is she part of this?"
            scene marce5s3iruby
            with dissolve
            marc "Ruby is pure chaos and charm."
            marc "Clever, adventurous, always chasing the next thrill without fear."
            marc "She’s the bright spark in a world of shadows, the innocent adventurer who doesn’t even realize the weight of the story she carries."
            marc "And sometimes, [name]… it’s the ones who seem the most carefree that stand on the biggest secrets."
            marc "When her truths surface… the world will be watching."
            $ rubyexplanation = False
            jump chooseexplanation
        "More...":

            jump chooseexplanation2

label chooseexplanation2:

    menu:
        "Julia?" if juliaexplanation == True:
            d "And Julia?"
            scene marce5s3ijulia
            with dissolve
            marc "Julia is the forgotten one. The outsider."
            marc "The girl who’s had nothing handed to her and fights for every inch she gains."
            marc "She’s the hope of the overlooked, the symbol of the silent workers who serve the powerful but dream of breaking free."
            marc "But remember this, [name]... sometimes those who rise from nothing have deeper roots than even they realize."
            marc "And when those roots surface… they can shake the very foundations of this world."
            $ juliaexplanation = False
            jump chooseexplanation

        "The Twins?" if twinsexplanation == True:
            d "And the twins? Why are they here?"
            scene marce5s3itwins
            with dissolve
            marc "Ah… Sofia and Elisabeth. Two bodies, one bond, but two completely different destinies."
            marc "Sofia… she’s like a bird just discovering the sky. Carefree, full of curiosity, chasing every horizon without fear."
            marc "She lives for the thrill of freedom, untouched by the weight of consequences."
            marc "She’s the face of innocence and wonder… and people can’t help but follow where she flies."
            marc "Elisabeth is the opposite. Calculating. Introspective. She doesn’t wander aimlessly, she studies, she plans, and she waits for the perfect moment to strike."
            marc "She’s power hidden behind a smile, a lioness in velvet gloves. She doesn’t chase prey… she makes sure the prey comes to her."
            marc "Together, they force the world to ask the oldest question of all: do you chase freedom… or claim power?"
            $ twinsexplanation = False
            jump chooseexplanation

        "Why Kira?" if kiraexplanation == True:
            d "And Kira?"
            scene marce5s3ikira
            with dissolve
            marc "Kira doesn’t pretend. She doesn’t hide behind innocence or restraint."
            marc "She knows exactly who she is and what she’s capable of."
            marc "Where others hesitate, she acts. Where others follow rules, she rewrites them."
            marc "She is power in its purest form."
            marc "Not inherited, not given… CLAIMED through sheer will."
            marc "Some admire her. Others fear her. But no one ignores her."
            marc "When Kira enters the room, everyone knows… the game has already begun."
            $ kiraexplanation = False
            jump chooseexplanation
        "Enough. I don’t want to hear more.":

            d "Stop… I don’t want to hear more of this."
            marc "Whether you want to hear it or not doesn’t change the reality, [name]."
            marc "You’re already part of the show. The only question left is… HOW will you play it?"
            jump endexplanation

label endexplanation:

    scene marce5s3i15
    with dissolve
    marc "One last thing, [name]."
    marc "The difference between a player… and a piece on the board…"
    marc "Is knowing when you’re being moved… and when it’s your turn to make a move."
    marc "Most people live their whole lives without ever realizing which one they are."
    marc "Don’t make the same mistake."
    scene marce5s3ifin
    with dissolve
    pause 4
    scene black
    with fade
    pause 1
    scene marce5s3ifin2
    with dissolve
    dpense "I left that place with more questions than answers… but one thing was certain."
    dpense "Nothing about this was a game anymore."
    scene marce5s3ifin3
    with dissolve
    dpense "And somehow… I was already playing."
    stop music fadeout 2 
    pause 2

if juliaep5s1 == True:

    play sound "sound/vibration.mp3" volume 1
    dpense "Oh? A call from Julia?"
    scene marce5s3ifin4
    with dissolve
    d "Julia? Are you all right?"
    julia "[name]..."
    pause 1
    julia "It's my mother..."
    pause 1
    julia "It's..."
    pause 1
    julia "It's over..."

scene black
play sound "sound/vooh.wav" volume 1
pause 2

jump e5s4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
