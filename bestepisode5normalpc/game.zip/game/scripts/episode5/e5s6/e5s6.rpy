label e5s6:


    scene black
    with fade
    pause 2 
    scene e5trial1
    with fade
    play music "<from 0 to 98>musique/cinematiquetense.mp3" volume 0.2 loop fadein 2
    d "What..."
    scene e5trial2
    with dissolve
    d "Is..."
    scene e5trial3
    with dissolve
    d "This place?"
    pause 1 
    scene e5trial4
    with dissolve
    d "Seems the last podium available."
    scene e5trial5
    with dissolve
    pause 1 
    scene e5trial6
    with dissolve
    pause 1.0
    play sound "sound/WhooshEpic.mp3" volume 1
    pause 0.2
    scene e5trial7
    with vpunch
    orushi "My dear contestants..."
    orushi "Twenty of you remain."
    orushi "Twenty lives. Twenty paths. Twenty intertwined stories."
    orushi "But today... only a handful will move on."
    scene e5trial8
    with dissolve
    orushi "The place you have chosen sealed your fate."
    orushi "Each place correspond to a box."
    scene e5trial9
    with dissolve
    orushi "Some of these boxes contain a selection token."
    scene e5trial10
    with dissolve
    orushi "Others are empty."
    scene e5trial11
    with dissolve
    orushi "I won’t tell you how many tokens there are."
    orushi "What I offer you is a choice. Just one."
    scene e5trial12
    with dissolve
    orushi "Each of you will have the opportunity to secretly look inside a box."
    orushi "Through the tablet in your podium."
    orushi "...any box except your own."
    scene e5trial13
    with dissolve
    orushi "You may do this only once."
    orushi "Then, each of you will make a decision:"
    orushi "Keep your box and trust your luck,"
    orushi "or swap boxes with another player."
    scene e5trial14
    with dissolve
    orushi "But remember..."
    orushi "A box that's been swapped loses its certainty."
    scene e5trial15
    with dissolve
    orushi "And a box that’s kept... might be nothing but a mirage."
    scene e5trial16
    with dissolve
    orushi "Think carefully. Because this isn’t just a selection test..."
    orushi "It’s a reflection of everything you’ve learned since arriving here."
    scene e5trial17
    with dissolve
    dpense "I have to choose a box to check... but not mine."

    jump e5s6_observation

label e5s6_observation:
    scene e5trial18
    with dissolve
    dpense "Everyone’s staring at their podium... not really sure what to do with it."
    scene e5trial19
    with dissolve
    dpense "Nobody knows how many tokens there are."
    scene e5trial20
    with dissolve
    dpense "Looks like they’re all trying to figure out some hidden rule behind all this."
    scene e5trial21
    with dissolve
    mad "So... are we supposed to look at a box to help us decide?"
    scene e5trial22
    with dissolve
    s "Or maybe it’s just to mess with our heads. Could be a total trap..."
    scene e5trial23
    with dissolve
    grace "I don’t like this. Too vague. Feels like we’re being played."
    scene e5trial24
    with dissolve
    dpense "Ruby’s not saying anything."
    dpense "She’s just watching. As always."
    scene e5trial25
    with dissolve
    ruby "It’s all about perception. Not a logic puzzle this time."
    ruby "The real question isn’t what we see. It’s what everyone else thinks they saw."
    dpense "She’s right. But I can tell she’s thinking deeper than that..."

    if isEnabledEducationSpecialization:

        scene e5trial26
        with dissolve
        ruby "Have you picked a box to check yet?"
        d "Not yet. I wanna gather the most useful info."
        ruby "Same. If we combine what we see with what others do, maybe we can spot a pattern."
        scene e5trial27
        with dissolve
        d "Like behavioral logic? Instinct versus reasoning?"
        ruby "Exactly. It’s not about the box itself. It’s about what they believe is inside... and what they do next."
        scene e5trial28
        with dissolve
        dpense "Now my brain’s kicking into gear. I get what she’s aiming for."
        d "So we team up. Quietly."
        ruby "Quietly."
        d "And the ones we don't know?"
        ruby "We don't know them. We can't rely on their actions because we don't know how they work..."
        ruby "We don't know how many will qualify at the end so..."
        ruby "Better ignore them to keep it simple."
    else:


        scene e5trial26
        with dissolve
        ruby "We have to stay focused. We don’t have much info, but the ones who act too fast... they’re the ones who’ll mess up."
        dpense "She’s got that calm, analytical tone I’ve come to recognize. She’s already got a plan."
        scene e5trial27
        with dissolve
        d "And the ones we don't know?"
        ruby "We don't know them. We can't rely on their actions because we don't know how they work..."
        ruby "We don't know how many will qualify at the end so..."
        ruby "Better ignore them to keep it simple."

    scene e5trial28
    with dissolve
    dpense "Everyone’s watching. Evaluating. Calculating."
    scene e5trial29
    with dissolve
    dpense "Ruby’s deep in thought. Her eyes scan the room."
    scene e5trial30
    with dissolve
    dpense "I catch a hint of a smile on her lips. She’s decoding behaviors. And so am I."
    ruby "What do you think of Steven’s posture?"
    scene e5trial31
    with dissolve
    d "Either he’s afraid of making the wrong call, or he’s waiting for someone else to move first."
    ruby "That’s what I’m thinking too..."
    scene e5trial32
    with hpunch
    emerick "Are you fucking kidding me?!"
    emerick "They’ve been whispering for five minutes and no one says a thing?!"
    emerick "This is a goddamn test and you’re letting these two cook up some little romantic plan or whatever?!"
    scene e5trial33
    with dissolve
    ruby "You’re the one yelling, Emerick. Scared of losing or what?"
    emerick "At least I’m not cheating! I’m playing SOLO. Like we’re supposed to!"
    dpense "He’s losing it, but deep down I think he’s mostly losing control."
    scene e5trial34
    with dissolve
    orushi "Enough."
    orushi "Player Emerick, rest assured: I hear and see everything."
    orushi "And trust me on this: I’ll know exactly who deserves to move forward."
    orushi "I never forbade candidates from talking to each other."
    orushi "What’s forbidden is sharing information about the content of the boxes: the ones they opened or the ones they checked."
    scene e5trial35
    with dissolve
    orushi "But talking strategy, impressions, or behavior?"
    orushi "Not only is it allowed... it’s revealing."
    scene e5trial36
    with dissolve
    orushi "And I’ll remind you: this is an individual challenge."
    orushi "You can talk as much as you like, but don’t expect to be saved together."
    orushi "Some will speak, others will lie. And sometimes... everyone loses."
    scene e5trial37
    with dissolve
    stop music fadeout 2
    orushi "Since you seem so eager to set the tone, Emerick..."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial38
    with vpunch
    orushi "You’ll go first."
    play music "<from 0 to 123>musique/suspense-tension-background-music-302978.mp3" volume 0.2 loop
    emerick "Finally."
    scene e5trial39
    with dissolve
    emerick "I’ll check..."
    emerick "Ruby's box."
    dpense "He’s provoking her."
    scene e5trial40
    with dissolve
    pause 2
    emerick "Mhhhh. Fascinating."
    dpense "He’s deliberately leaving it vague. He just can’t help himself."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial41
    with dissolve
    orushi "Player Madison. Your move."
    scene e5trial42
    with dissolve
    mad "Alright, here I go."
    dpense "I can feel the tension in her."
    ruby "She’s on edge."
    scene e5trial43
    with dissolve
    pause 1
    mad "I’ll... check a box. Steven’s one."
    scene black
    with fade
    pause 1
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial44
    with dissolve
    orushi "Player Steven. Your turn."
    s "Madison's one."
    d "He’s going to check her box?"
    ruby "It’s a form of retaliation. Depending on what she does with her box, he wants to cross-check."
    ruby "He’s got the advantage of choosing after her."
    scene e5trial45
    with dissolve
    dpense "No words. No glance."
    s "That’s all I need."
    ruby "He’s bluffing. Or he’s confident in his read."
    d "Or maybe he just wants to mess with Madison’s head."
    pause 1
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial46
    with pushleft
    orushi "Player Sofia. Your turn."
    scene e5trial47
    with dissolve
    dpense "Blue is calm. No visible stress."
    scene e5trial48
    with dissolve
    dpense "She looks at me..."
    ruby "Oh."
    d "She’s gonna... check my box?"
    scene e5trial47
    with dissolve
    dpense "She doesn’t speak. But for half a second, her eyes meet mine."


    if blueep5Path:
        scene e5trial49
        with dissolve
        dpense "She gives me a smile. Subtle. Faint. But it’s there."
        ruby "You think that’s a message?"
        d "No idea. She’s always hard to read."
        ruby "Or maybe she wants you to get it without her saying anything."

    pause 1
    scene e5trial50
    with dissolve
    dpense "She stays calm... That's strange."
    pause 1 
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial51
    with pushleft
    orushi "Player Hector. Your move."
    hec "Alright... guess I gotta play the game."
    scene e5trial52
    with dissolve
    pause 1 
    scene e5trial53
    with hpunch
    hec "Julia's one."
    scene e5trial54
    with dissolve
    dpense "Julia doesn’t flinch."
    pause 1
    scene black
    with fade
    scene e5trial55
    with dissolve
    pause 2
    play sound "sound/whooshtir.wav" volume 0.5
    pause 0.2
    scene e5trial56
    with vpunch
    orushi "Player Kira. Your turn."
    dpense "Her face, as always, is unreadable."
    scene e5trial57
    with dissolve
    dpense "She doesn’t look at anyone."
    kira "Ben's one."
    ruby "Classic. Easy target."
    d "You think she’s playing it safe?"
    ruby "Or she knows exactly what she’s doing."
    scene e5trial58
    with dissolve
    dpense "Not a hint of emotion on her face."
    pause 1 
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial59
    with pushleft
    orushi "Player Mac. Your move."
    dpense "Mac glances around for a second, looking spaced out."
    scene e5trial60
    with dissolve
    mac "Alright… let’s keep it simple."
    mac "Ben's one!"
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial61
    with pushleft
    orushi "Player Ben. Your move."
    dpense "Ben looks at Mac, then grins like an idiot."
    scene e5trial62
    with dissolve
    ben "Same deal, bro."
    ruby "Useless action."
    d "Zero brains, fake alliance."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial63
    with pushleft
    orushi "Player Elizabeth. Your turn."
    scene e5trial64
    with dissolve
    dpense "Red stands without a word. Still with that calm, icy demeanor... but everything about her feels calculated."
    scene e5trial65
    with dissolve
    pause 1
    if RedPathe5:
        scene e5trial66
        with dissolve
        dpense "She slowly turns her head toward Hector. Her choice surprises more than a few."
        beth "I’ll check Hector’s box."
        ruby "Hector? She's attacking her own group?"
        d "That’s risky..."
        ruby "Or brilliant. Hitting one of Emerick’s pawns to weaken the structure without picking a direct fight."
        scene e5trial67
        with dissolve
        ruby "What I don’t get is… why?"
        dpense "Is it... For me?"
    else:

        scene e5trial66
        with dissolve
        dpense "She stares at Grace for a long time... almost like she’s looking down on her."
        pause 1 
        beth "I’ll take a look at Grace’s box."
        ruby "She’s targeting Grace..."
        dpense "Red never shows her cards. She plays solo, her way. And sometimes, that’s all it takes."

    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial68
    with dissolve
    orushi "Player Julia. Your move."
    scene e5trial69
    with dissolve
    dpense "Julia rises slowly. Her eyes scan the room like she’s trying to read everyone’s thoughts."
    pause 1
    julia "I’ll check Ben’s box."
    scene e5trial70
    with dissolve
    ruby "Interesting."
    d "You expected her to pick Ben?"
    ruby "Since Ben looked at Mac, she might be tracking a chain. Getting a wider read than the others."
    dpense "Hum..."
    pause 1
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial71
    with dissolve
    orushi "Player Ruby. Your turn."
    scene e5trial72
    with dissolve
    dpense "Ruby stays still for a moment. Like she’s calculating one last variable before moving."
    d "You already know who you’re picking?"
    scene e5trial73
    with dissolve
    ruby "Almost. Just want to cross-check something."
    d "You’re thinking about Kira?"
    ruby "She looked at Ben. The safest possible choice in the room."
    d "You want to understand why she picked him?"
    scene e5trial74
    with dissolve
    ruby "Maybe. When it’s Kira… even simple moves can be part of something deeper."
    scene e5trial75
    with dissolve
    dpense "She stands without a word."
    dpense "She studies it for a long moment."
    dpense "She doesn’t show a thing, but I know she’s locking that data in her mind."
    scene e5trial73
    with dissolve
    ruby "Alright."
    dpense "One word. Neutral tone. But I can tell she just found the piece she was missing."
    scene black
    with fade
    pause 1 
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial76
    with dissolve
    orushi "Player [name]. Your move."
    scene e5trial77
    with dissolve
    dpense "It’s my turn."
    scene e5trial78
    with dissolve
    dpense "Just one box to check. And not my own."
    dpense "I need to make the right call."
    scene black
    with fade
    pause 1

    $ chosenbox = ""

    if isEnabledEducationSpecialization:
        ruby "You know what we’re looking for. Behavior, connections, cross-checks. Pick with your head, not your heart."
        d "Don’t worry. I learned the lesson."

    call screen choixep5s61()

label observebox:

    scene black
    with dissolve
    pause 1
    scene e5trial77
    with dissolve
    dpense "I've chosen [chosenbox]’s box."
    dpense "Let's see what's inside..."
    scene black
    with Dissolve(1)
    if chosenbox in ["Madison", "Grace", "Emerick", "Sofia", "Hector", "Ben", "Elizabeth", "Julia", "Ruby"]:
        scene token with Dissolve(3)
        pause 2 
        scene black with Dissolve(2)
        pause 1
    else:
        show text _ ("NOTHING...") at truecenter
        with fade
        pause 2 
        hide text
        with fade
        pause 1
    scene e5trial78
    with fade
    dpense "I’ve got what I need. For now."
    pause 1 
    orushi "Grace. Your turn."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial79
    with dissolve
    pause 2 
    scene e5trial80
    with dissolve
    ruby "She won’t waste time."
    scene e5trial81
    with dissolve
    grace "Mac's one."
    pause 1 
    scene e5trial82
    with dissolve
    d "She seems... cold."
    stop music fadeout 2
    pause 1 
    play sound "sound/whooshtir.wav" volume 0.5
    pause 0.2
    scene e5trial7
    with vpunch
    orushi "Contestants…"
    orushi "You’ve all had time to observe. To analyze."
    scene e5trial12
    with dissolve
    orushi "Now it’s time to make your decision."
    orushi "Each of you will take a turn."
    orushi "When your turn comes, you have two options:"
    scene e5trial14
    with dissolve
    orushi "Either keep the box in front of you..."
    scene e5trial15
    with dissolve
    orushi "Or swap two visible boxes."
    orushi "But be mindful of this:"
    scene e5trial16
    with dissolve
    orushi "Once a player swaps their box with someone else’s, that box becomes untouchable for the next round."
    orushi "In other words… you can’t take a box that someone just took in the previous turn."
    orushi "Nor can you take back your own box after a swap."
    scene e5trial12
    with dissolve
    orushi "Think carefully. Appearances are often deceiving..."
    orushi "And sometimes, a good decision can be ruined by a single hesitation."
    orushi "Player Emerick. Your turn."
    scene e5trial38
    with dissolve
    play music "musique/thriller-cinema-trailer-high-tension-253965.mp3" volume 0.2
    emerick "Alright… I won’t beat around the bush."
    emerick "Let’s see if that calm of yours hides anything worthwhile."
    scene e5trial39
    with dissolve
    emerick "I will take Ruby's one"
    dpense "Ruby doesn’t flinch. She accepts the trade without showing a single emotion."
    dpense "But I can feel something locking into place in her mind. She’s already analyzing."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial41
    with dissolve
    orushi "Player Madison. Your move."
    dpense "She’s not trembling."
    ruby "She’s running on instinct. But she knows all eyes are on her."
    dpense "She glances at Steven, then at her own podium."
    scene e5trial43
    with dissolve
    mad "I’m keeping mine."
    dpense "It’s a bold choice. Almost a challenge. Like she’s proving she doesn’t need anyone."
    ruby "Proud, impulsive… but not reckless. She’s trying to keep control at all costs."
    ruby "But that also means she didn’t like what she saw in Steven’s box."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial44
    with dissolve
    orushi "Player Steven. Your move."
    dpense "Steven, as confident as ever."
    dpense "He stares at his own box for a second… then turns his head toward Madison."
    d "You think he’s gonna…?"
    ruby "He’s seen her box. He knows exactly what’s inside."
    scene e5trial45
    with dissolve
    s "Sorry, Madison."
    scene e5trial83
    with dissolve
    mad "What?!"
    s "That’s the game."
    mad "Damn it..."
    dpense "She clenches her jaw. But she takes it."
    scene e5trial77
    with dissolve
    d "You think he’s bluffing?"
    ruby "No. He’s playing based on what he saw."
    d "She looked at his box, right?"
    ruby "Exactly. And after that, she decided to keep hers."
    ruby "So Steven must’ve seen a token inside."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial50
    with dissolve
    orushi "Player Sofia. Your turn."
    scene e5trial48
    with dissolve
    dpense "Her gaze briefly scans the room, then locks straight ahead."

    if blueep5Path:

        dpense "She looks at me for a second."
        scene e5trial47
        with dissolve
        sofia "I’m keeping mine..."
        dpense "Her tone is soft. Almost intimate."
        dpense "Not a command, not a plea. A statement. Simple and direct."
        scene e5trial49
        with dissolve
        ruby "She’s sending a message. That’s clear."
        d "She wants me to figure out what she saw. Or what she thinks she saw."
    else:


        scene e5trial47
        with dissolve
        dpense "She pauses for a second, uncertain."
        dpense "No words. No glance my way. Nothing."
        dpense "She places a hand on her podium, closes her eyes for a moment..."
        sofia "I’m keeping mine..."
        ruby "She’s keeping hers."
        scene e5trial78
        with dissolve
        d "But she saw my box..."
        ruby "That might be part of her strategy."

    scene e5trial77
    with dissolve
    dpense "Silence settles again, a little heavier now."
    scene e5trial73
    with dissolve
    dpense "Ruby narrows her eyes. She’s thinking. Connecting dots."
    ruby "So…"
    ruby "Emerick swapped his box with mine. Confident move."
    ruby "Madison looked at Steven’s. Then kept hers."
    ruby "Steven saw Madison’s. And swapped."
    ruby "Blue checked your box... and chose to keep hers."
    ruby "And now, it’s Hector."
    scene e5trial75
    with dissolve
    dpense "Ruby takes a small breath, like she’s recalibrating everything."
    ruby "He looked into Julia’s box. He knows what’s in it."
    ruby "He has three options:"
    ruby "Either Julia has a token, and he goes for it."
    ruby "Or she doesn’t, and he thinks he’s better off keeping his."
    ruby "Or… he believes one of the boxes already swapped is now more valuable."
    scene e5trial72
    with dissolve
    d "Like the one Steven took from Madison."
    ruby "Exactly. He might think it had a token, and Steven sniffed it out."
    ruby "In that case, if he trades with Steven, he’d get Madison’s old box."
    ruby "And the token inside. If there was one."
    scene e5trial77
    with dissolve
    dpense "But would he dare do that?"
    ruby "It’s Hector. Taking big risks doesn’t scare him."
    scene e5trial51
    with dissolve
    dpense "I look at Hector. It’s his turn."
    orushi "Player Hector. Make your decision."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial52
    with dissolve
    dpense "He glances at Steven, then Julia, then me…"
    dpense "But his gaze keeps coming back to Julia."
    ruby "Makes sense."
    d "You think he’s going for her box?"
    ruby "He already looked inside. He knows what’s in there."
    ruby "And I doubt he’d ever go after Steven. Julia’s the obvious move."
    scene e5trial53
    with dissolve
    hec "No need for math or plans. I’m just taking the box I want."
    hec "Julia's one."
    dpense "He's clearly pleased with himself."
    scene e5trial73
    with dissolve
    ruby "Straightforward. Classic Hector."
    d "You think he saw a token?"
    ruby "If he’s not bluffing, then yeah."
    scene e5trial69
    with dissolve
    dpense "Julia doesn’t react. But I see the slightest clench in her jaw."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial57
    with dissolve
    orushi "Player Kira. Your turn."
    scene e5trial58
    with dissolve
    dpense "She avoids eye contact with anyone."
    dpense "Not a word. Just a direct, precise movement."
    d "You think she’s going for Ben?"
    ruby "She checked him. If she thinks he has a token, she won’t hesitate."
    ruby "But with Kira, there’s no telling until she acts."
    scene e5trial57
    with dissolve
    kira "Ben..."
    dpense "Without hesitation, she swaps her box with his."
    scene e5trial61
    with dissolve
    ben "Uh… okay?"
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial59
    with hpunch
    orushi "Player Mac. Proceed."
    scene e5trial60
    with dissolve
    dpense "He looks around, then locks eyes on Ben with a sly grin."
    mac "Hope you won’t hate me for this, buddy… I’m taking your box!"
    dpense "He takes Ben's one too ?"
    scene e5trial74
    with dissolve
    ruby "He screwed up."
    d "What?"
    ruby "He looked in Ben’s box earlier."
    d "Yeah… so?"
    scene e5trial73
    with dissolve
    ruby "Kira swapped it. The box he saw is in front of her now."
    d "So he just grabbed Kira’s box instead…"
    ruby "Exactly. And he didn’t even notice the swap."
    dpense "I see Ruby shaking her head, visibly disappointed."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial61
    with dissolve
    orushi "Player Ben. You’re up."
    dpense "Ben jumps up, way too enthusiastic."
    scene e5trial62
    with dissolve
    ben "Well then, I’m keeping yours!"
    dpense "He points at the box in front of him."
    dpense "He chuckles like it’s some kind of inside joke, but no one’s laughing."
    scene e5trial72
    with dissolve
    ruby "That's bananas."
    d "So he kept Mac’s box."
    ruby "Yeah. But since Mac might’ve swapped it just to mess with his buddy..."
    ruby "We have no clue what’s actually inside it."
    dpense "I can see Ruby mentally crossing off their names."
    scene e5trial73
    with dissolve
    ruby "Two wasted turns. And neither of them realizes it."
    ruby "Only Kira holds the key to this ridiculous mess."
    ruby "Either she made a smart move knowing both of them would screw up..."
    ruby "Or she just risked everything, hoping one of them would be stupid."
    ruby "But at this point, we can’t tell..."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial64
    with dissolve
    orushi "Player Elizabeth, make your choice."
    if RedPathe5:
        scene e5trial66
        with dissolve
        beth "I’ll trade my box with Hector’s."
        ruby "She’s going after Hector. I didn’t expect that."
        d "You think she wants to shut him down?"
        ruby "Could be. He took Julia’s box after checking it out."
        scene e5trial65
        with dissolve
        ruby "But it’s surprising… she’s betraying her own group, isn’t she?"
        d "Or maybe she’s just protecting herself for what’s coming..."
    else:

        scene e5trial66
        with dissolve
        beth "I’ll trade my box with Grace’s."
        ruby "She’s going after Grace. A direct hit."
        d "You think she saw something in her box?"
        ruby "She did check her in the first round."
        scene e5trial65
        with dissolve
        ruby "Or… she could be bluffing and just trying to throw off our team."
        d "That’d be risky."
        ruby "Exactly. Which makes it a potential diversion."

    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial69
    with hpunch
    orushi "Player Julia. Your move."
    scene e5trial68
    with dissolve
    dpense "Julia takes a slow breath, eyes calm but focused."
    ruby "She checked Ben’s box at the start. But too much has changed since then."
    ruby "We don’t really know what Kira had in mind, knowing three people had seen Ben’s box..."
    scene e5trial70
    with dissolve
    ruby "But if there was a token in there... she should go get it from Kira now."
    ruby "We’re missing pieces. But she’ll have to decide anyway."
    scene e5trial69
    with dissolve
    dpense "She glances meaningfully at Steven."
    ruby "He took Madison’s box."
    ruby "Risky move, but it makes sense. Hector had seen Julia’s box."
    d "But since she can’t take back her own box..."
    scene e5trial70
    with dissolve
    ruby "She can’t get back what Hector took from her..."
    julia "Steven's one..."
    d "You think she sniffed out a good move?"
    ruby "She’s playing with what she’s got. Like the rest of us."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial71
    with dissolve
    orushi "Player Ruby. Your move."
    scene e5trial73
    with dissolve
    pause 1 
    scene e5trial72
    with dissolve
    dpense "Ruby stays silent as all eyes turn to her."
    scene e5trial75
    with dissolve
    dpense "She stares at her box for a moment, but her eyes drift. She’s thinking."
    ruby "Hold on."
    stop music fadeout 1
    scene e5trial74
    with dissolve
    dpense "She lifts her head toward Orushi."
    ruby "I… I’d like to ask a question."
    scene e5trial16
    with dissolve
    orushi "I’m listening."
    play music "musique/tense-suspense-background-music-364864.mp3" volume 0.2 loop
    ruby "You said we could trade two boxes between players as long as they’re visible, right?"
    scene e5trial35
    with dissolve
    orushi "Excellent question, Miss."
    orushi "The rules only forbid taking a box that was traded in the previous turn or manipulating your own box more than once."
    orushi "But you may propose two other players trade boxes as long as it doesn’t break those conditions."
    d "Huh?"
    ruby "Very well. So, if I want to trade two other players’ boxes, I can?"
    scene e5trial36
    with dissolve
    orushi "Clever..."
    orushi "You may request it, and the swap will be executed accordingly."
    d "You’re really going to do this?"
    scene e5trial74
    with dissolve
    ruby "Very well. Then I’m making the request officially."
    ruby "I want to trade Hector’s box… with Madison’s."
    scene e5trial84
    with hpunch
    mad "Ruby...?"
    ruby "I don’t know what’s in my box."
    ruby "But considering how little faith I have in Emerick, I can’t put my odds on this specific box."
    ruby "Steven took Madison’s box. But giving them back their original boxes would go against the rules, I suppose?"
    scene e5trial16
    with dissolve
    orushi "Correct."
    ruby "If the token was in Kira’s box... Julia would’ve gone for it, since she saw Ben’s box in the first round."
    ruby "Hector snatched Julia’s box the same way."
    ruby "And with Elizabeth, he’s one of the few who currently holds a box most likely to contain a token."
    ruby "So if I do this, I have the best chance of saving Madison."
    scene e5trial74
    with dissolve
    dpense "Ruby takes a deep breath."
    scene e5trial75
    with dissolve
    ruby "I can’t just sit back and do nothing."
    ruby "And I’m ready to lose for it."
    scene e5trial36
    with dissolve
    orushi "Your request is… unconventional."
    orushi "But it complies with the rules. Approved."
    scene e5trial73
    with dissolve
    ruby "I want to exchange Hector and Madison's boxes."
    scene e5trial85
    with dissolve
    mad "But... Ruby... You..."
    scene e5trial86
    with hpunch
    emerick "This is completely absurd."
    emerick "Now she's just making up rules!"
    scene e5trial34
    with dissolve
    orushi "Player Emerick, you are not authorized to judge the rules of this game."
    scene e5trial75
    with dissolve
    ruby "There."
    ruby "Now at least she has a chance."
    dpense "She gave everything… for Madison."
    ruby "I've done everything I could."
    ruby "Now it’s all about luck."
    stop music fadeout 4
    pause 2
    play sound "sound/whooshtir.wav" volume 0.5
    play music "musique/KaiEngel-TheRun.mp3" volume 0.2 
    scene e5trial78
    with dissolve
    orushi "Your turn, [name]."
    scene e5trial77
    with dissolve
    ruby "Listen... from what I’ve seen, Emerick may have taken a huge risk right from the start."
    d "You mean... he was bluffing?"
    ruby "It’s possible. He stayed way too calm, too confident. And he traded with me immediately."
    d "So what do you think?"
    scene e5trial79
    with dissolve
    ruby "I can’t say for sure, but he’s the only one no one’s gone after. That says a lot."
    ruby "The others are afraid and won’t challenge him."
    ruby "And I have no idea what was originally in my box or his."
    scene e5trial78
    with dissolve
    d "And if I just keep mine?"
    ruby "You still have your original box. It’s your call. But remember, some choices can change everything."
    scene e5trial77
    with dissolve
    dpense "I look up at Orushi. It’s my turn."
    orushi "[name]?"
    scene e5trial76
    with dissolve
    dpense "All eyes are on me. The tension is tangible."
    dpense "I can’t pick Hector’s or Madison’s boxes since they were just moved."
    dpense "Do I exchange my box or should I keep it?"

    if persistent.patch_enabled == True:
        $ TEMP1 = e5s4c3
    else:
        $ TEMP1 = ""

    $ herofinalbox = ""

    menu:
        "Exchange":
            dpense "I will exchange with someone..."
            dpense "But the question is... With who?"
            pause 1 
            call screen choixep5s62()
        "Keep my box[TEMP1!t]":

            $ herofinalbox = "hero"
            dpense "I’ll take the risk. I believe in it."
            d "I keep mine."
            jump revealtrial
label herochosenbox:

    d "I will take [herofinalbox]'s one."
    if herofinalbox in ["Ruby", "Kira", "Julia", "Grace", "Elizabeth", "Sofia"]:
        $ charobj = CharacterBio.findCharacterByName(herofinalbox)
        if charobj.hearts > 0:
            $ charobj.hearts -= 1
            $ renpy.notify(_("She will remember that."))

    if herofinalbox == "Emerick" and blueep5:
        scene e5trial87
        with dissolve
        sofia "You... You really think that was a good idea?"
        dpense "Her look pierces me. Not anger...just wounded disbelief."
        sofia "You could have trusted me."
        dpense "Did I make a mistake?"

label revealtrial:
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial80
    with dissolve
    orushi "Very well. Grace? Your turn."
    scene e5trial81
    with dissolve
    dpense "She says nothing. Just a focused look at her box."
    grace "I'll keep mine."
    dpense "No doubt about it. She’s confident."
    dpense "Final round complete."
    scene e5trial7
    with hpunch
    orushi "Very well."
    orushi "You have all had the opportunity to check. To act. To betray."
    scene e5trial12
    with dissolve
    orushi "Every move has been noted. Every hesitation revealing."
    orushi "But now, the time for strategy is over."
    orushi "What’s inside your boxes will determine what comes next."
    scene e5trial13
    with dissolve
    orushi "Remember: only those with a token will proceed to the next trial."
    scene e5trial15
    with dissolve
    orushi "And for the others… the journey ends here."
    dpense "A heavy silence falls over the room."
    scene e5trial77
    with dissolve
    dpense "Everyone stares at their box. Some with confidence, others with poorly hidden anxiety."
    orushi "We will open them. One by one."
    stop music fadeout 3
    orushi "Player Emerick. We will begin with you."
    play music "musique/thriller-cinema-trailer-high-tension-253965.mp3" volume 0.2 loop
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial39
    with dissolve
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial88
    with dissolve
    orushi "Token confirmed."

    if herofinalbox != "Emerick" or (herofinalbox == "Emerick" and chosenbox == "Ruby"):

        ruby "He really had a token. I wasn’t wrong..."
        scene e5trial89
        with dissolve
        emerick "Of course I had a token."
        emerick "And you were smart not to get involved in my business."
        emerick "Maybe you deserve to move on."
        scene e5trial35
        with dissolve
        orushi "Bluffing can be a powerful weapon..."
        orushi "But true skill lies in not falling for the trap."
    else:


        scene e5trial90
        with dissolve
        ruby "No… no no no…"
        ruby "I was wrong…"
        d "Ruby..."
        ruby "I thought he was bluffing…"
        scene e5trial91
        with dissolve
        ruby "He took my box because he knew it was empty…"
        ruby "And he did everything to make sure you'd want to take it back…"
        ruby "It was all a trap. And I walked right into it."
        ruby "I made you lose your token…"
        d "You didn’t make me lose anything, Ruby. I made the choice."
        scene e5trial92
        with dissolve
        emerick "Too late for apologies, lovebirds."
        emerick "You played, and you lost."
        emerick "While you were busy suspecting me, I took your place."
        if [chosenbox] == "Emerick":
            scene e5trial93
            with dissolve
            emerick "You really thought I cared about my token?"
            emerick "All I wanted was to get you."
            emerick "I knew you wouldn’t touch Ruby’s box on principle!"
            emerick "And you took the bait. Pathetic."
        scene e5trial35
        with dissolve
        orushi "A rare move indeed. Putting one’s own victory at risk just to take down an opponent. Risky. Yet effective."
        ruby "..."
        orushi "The art of manipulation, skillfully applied."
        orushi "When one focuses too much on the intent, one forgets the consequence."
        orushi "And there are still more revelations to come..."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial94
    with dissolve
    orushi "Player Madison. Your turn."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial95
    with dissolve
    orushi "Token confirmed."
    scene e5trial96
    with dissolve
    mad "Thank you, Ruby..."
    mad "I don't know how to thank you..."
    scene e5trial97
    with dissolve
    ruby "She's safe..."
    d "You saved her, Ruby."
    ruby "It's the least I could do."
    scene e5trial36
    with dissolve
    orushi "Strategy can lead to a good choice, even if it's not your strategy."
    orushi "Now… let us continue."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial99
    with dissolve
    orushi "Player Steven. Let’s see what’s in your box..."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial98
    with dissolve
    orushi "Token confirmed."
    scene e5trial100
    with dissolve
    s "Obviously."
    s "There’s a reason I’m the captain."
    d "Steven had a positional advantage."
    orushi "Strategy, composure, or pure instinct… Ultimately, it’s a point for you, Steven."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial101
    with dissolve
    orushi "Player Sofia. Your turn."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial102
    with dissolve
    orushi "Token confirmed."

    if blueep5 == True:
        scene e5trial103
        with dissolve
        sofia "I... I have s..."
        scene e5trial104
        with dissolve
        orushi "Shhh..."
    else:

        sofia "Phew... At least that’s done."

    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial105
    with dissolve
    orushi "Player Hector. Your turn."
    pause 3 
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial106
    with dissolve
    orushi "Box is empty."
    hec "What?!" with hpunch
    scene e5trial107
    with dissolve
    hec "But I played by the rules!"
    hec "How can it be empty?!"
    scene e5trial108
    with dissolve
    hec "Wait... It’s Ruby! You set me up!"
    hec "When you swapped my box and gave it to Madison!"
    ruby "I did what I had to do."
    hec "You think you get to decide who deserves to stay?!"
    scene e5trial109
    with dissolve
    hec "This whole game is bullshit!"
    hec "You're all hypocrites!"
    scene e5trial110
    with dissolve
    orushi "The decision is final."
    hec "Go fuck yourselves."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial111
    with dissolve
    orushi "Player Kira. Let’s see what’s in your box."
    scene e5trial112
    with dissolve
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial113
    with dissolve
    orushi "Token confirmed."
    scene e5trial114
    with dissolve
    kira "Perfect."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial115
    with dissolve
    orushi "Player Mac. Let’s now see what your box holds."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5
    scene e5trial116
    with dissolve
    orushi "…No token."
    mac "What?!"
    scene e5trial117
    with dissolve
    ben "Nice one, man… I told you it was the other one."
    mac "No, we got our wires crossed! I thought you were taking Red’s!"
    ruby "There you go. Two half-brains don't add up to a whole one."
    orushi "It seems that an alliance without thought is destined to fail."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial118
    with dissolve
    orushi "Player Ben. Time to reveal what you're holding."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
    scene e5trial120
    with dissolve
    orushi "…Your box is empty."
    ben "Seriously?!"
    scene e5trial119
    with dissolve
    mac "You took Kira’s, you idiot…"
    ben "No! It was yours, not Kira’s!"
    scene e5trial121
    with dissolve
    beth "We should give them a token out of pity."
    scene e5trial122
    with dissolve
    orushi "Inattention. Confusion. No matter what you call it, the result is always the same."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial123
    with dissolve
    orushi "Player Elizabeth. Your turn."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
    scene e5trial124
    with dissolve
    orushi "Qualified."

    if RedPathe5 == True:

        beth "Obviously."
        ruby "You checked Hector at the start. Did you figure out what was going on?"
        scene e5trial125
        with dissolve
        beth "I quickly saw there was a problem in our group. So I corrected it."
        dpense "She turned on her own team. Cold. Calculated."
        emerick "Traitor."
        beth "Let’s just say I prefer to bet on intelligence rather than arrogance."
    else:


        beth "Obviously."
        ruby "You had checked Grace..."
        scene e5trial125
        with dissolve
        beth "Yes. Always bet on red."
        dpense "Still just as self-centered. But effective."

    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial126
    with dissolve
    orushi "Player Julia. It's your turn."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
    scene e5trial127
    with dissolve
    orushi "…There is a token inside your box."
    scene e5trial128
    with dissolve
    ruby "You checked Ben, right?"
    scene e5trial129
    with dissolve
    julia "Yes."
    ruby "Then why didn’t you go after Kira?"
    julia "..."
    scene e5trial130
    with dissolve
    dpense "Something’s off here..."
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial131
    with dissolve
    orushi "Player Ruby. Your turn."
    pause 3 
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
    scene e5trial132
    with dissolve
    orushi "You're qualified."
    scene e5trial133
    with dissolve
    ruby "..."
    dpense "She seems frozen… like she expected the worst."
    mad "You did it!"
    scene e5trial134
    with dissolve
    ruby "I… I did?"
    d "Yeah. You had Emerick’s box, right?"
    ruby "He’s the one who took mine… But I kept his. And I never knew if…"
    ruby "When I helped Madison, I just accepted my fate. Thought it wouldn't be me."
    scene e5trial135
    with dissolve
    mad "You crushed it, Ruby."
    ruby "I can’t believe it..."
    ruby "I actually managed to…"
    scene e5trial35
    with dissolve
    orushi "A selfless player, and a perceptive one."
    stop music fadeout 3
    orushi "But even the best choices sometimes rely on a bit of luck."
    scene black with Dissolve(3)
    play sound "sound/whooshtir.wav" volume 0.5
    play music "<from 68 to 98>musique/cinematiquetense.mp3" volume 0.2 noloop
    scene e5trial76
    with dissolve
    orushi "Player [name]. Your turn."
    pause 1 
    dpense "Here we are."
    scene e5trial78
    with dissolve
    dpense "I hope I don't have made a mistake."
    dpense "They're all looking at me..."
    $ BlueSacrifice = False
    scene e5trial48
    with flash
    pause 0.5
    scene e5trial66
    with flash
    pause 0.5
    scene e5trial82
    with flash
    pause 0.5
    scene e5trial84
    with flash
    pause 0.5
    scene e5trial90
    with flash
    pause 1
    scene black with Dissolve(2)
    dpense "I can't fail now..."
    pause 5
    stop music fadeout 2
    pause 2
    if herofinalbox == "hero":
        scene e5trial136
        with dissolve
        play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
        play music "<from 98 to 130>musique/cinematiquetense.mp3" volume 0.2
        orushi "…There is a token in your box."
        scene e5trial139
        with dissolve
        d "Yes!"
        ruby "You did it!"
        orushi "Sometimes, the smartest play… is to not play too much."
        jump e5s6_reveal_grace

    elif herofinalbox == "Ben" or herofinalbox == "Mac":
        scene e5trial137
        with dissolve
        play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
        orushi "…Your box is empty."
        pause 2 
        play music "musique/suspense-background-01-254637.mp3" volume 0.2
        scene e5trial138
        with dissolve
        d "Shit..."
        scene e5trial140
        with dissolve
        ruby "You... Why did you trade it with him?"
        d "I thought maybe Mac or Ben had better odds..."

        if blueep5Path:

            scene e5trial141
            with dissolve
            sofia "No...!"
            scene e5trial142
            with vpunch
            sofia "NO!"
            sofia "I won’t let him go like that!"
            orushi "Hmm?"
            scene e5trial143
            with dissolve
            sofia "I have a Sacrifice option written on my token."
            orushi "..."
            scene e5trial144
            with dissolve
            orushi "I was expecting this. This token was given to only one player."
            orushi "The Sacrifice token. It can be used once, to give your spot to another eliminated player."
            orushi "It is a final act. Is that truly your wish?"
            scene e5trial145
            with dissolve
            sofia "Please… I want you to stay with me."
            d "Sofia..."
            d "Do you realize what that means?"
            sofia "Yes. But I don’t care about being the best if it means being alone."
            scene e5trial146
            with dissolve
            orushi "..."
            orushi "Player Sofia, you’ve shown a rare kind of devotion."
            orushi "This game isn’t just about intelligence or strategy."
            orushi "It’s also a test of what you’re willing to sacrifice for others."
            scene e5trial147
            with dissolve
            orushi "Today, you’ve shown that you’re not tempted by rewards…"
            orushi "But instead that you wish to uplift and help those around you."
            orushi "You are immediately qualified and immunity is your reward for this act."
            ruby "Wow."
            $ BlueSacrifice = True
            $ Achievement.add(achievement_sacrifice)
            $ achievement.grant("sacrifice")
            $ achievement.sync()
            orushi "But there is always a counterpart."
            orushi "I will explain it to you later."
            orushi "[name]..."
            pause 1
            play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
            scene e5trial148
            with dissolve
            orushi "You continue."
            pause 1 
            scene e5trial149
            with dissolve
            dpense "I'm still here because of her."
            dpense "And it could’ve cost her everything."
            jump e5s6_reveal_grace
        else:

            scene e5trial147
            with dissolve
            orushi "You are eliminated."
            stop music fadeout 2
            jump gameovere5


    elif herofinalbox == "Emerick" and chosenbox != "Ruby":
        scene e5trial137
        with dissolve
        play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
        orushi "…Your box is empty."
        pause 2 
        play music "musique/suspense-background-01-254637.mp3" volume 0.2
        scene e5trial138
        with dissolve
        d "Fuck..."
        ruby "I... I was wrong…"
        scene e5trial140
        with dissolve
        ruby "I thought he was bluffing, but he picked a box without a token on purpose to trap you."
        ruby "I made you lose…"
        d "You couldn’t have known…"
        emerick "You don’t win this game by following your heart."
        emerick "You have to think one move ahead."

        if blueep5Path:

            scene e5trial141
            with dissolve
            sofia "No...!"
            scene e5trial142
            with vpunch
            sofia "NO!"
            sofia "I won’t let him go like that!"
            orushi "Hmm?"
            scene e5trial143
            with dissolve
            sofia "I have a Sacrifice option written on my token."
            orushi "..."
            scene e5trial144
            with dissolve
            orushi "I was expecting this. This token was given to only one player."
            orushi "The Sacrifice token. It can be used once, to give your spot to another eliminated player."
            orushi "It is a final act. Is that truly your wish?"
            scene e5trial145
            with dissolve
            sofia "Please… I want you to stay with me."
            d "Sofia..."
            d "Do you realize what that means?"
            sofia "Yes. But I don’t care about being the best if it means being alone."
            scene e5trial146
            with dissolve
            orushi "..."
            orushi "Player Sofia, you’ve shown a rare kind of devotion."
            orushi "This game isn’t just about intelligence or strategy."
            orushi "It’s also a test of what you’re willing to sacrifice for others."
            scene e5trial147
            with dissolve
            orushi "Today, you’ve shown that you’re not tempted by rewards…"
            orushi "But instead that you wish to uplift and help those around you."
            orushi "You are immediately qualified and immunity is your reward for this act."
            ruby "Wow."
            $ BlueSacrifice = True
            $ Achievement.add(achievement_sacrifice)
            $ achievement.grant("sacrifice")
            $ achievement.sync()
            orushi "But there is always a counterpart."
            orushi "I will explain it to you later."
            orushi "[name]..."
            pause 1
            play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
            scene e5trial148
            with dissolve
            orushi "You continue."
            pause 1 
            scene e5trial149
            with dissolve
            dpense "I'm still here because of her."
            dpense "And it could’ve cost her everything."
            jump e5s6_reveal_grace
        else:

            scene e5trial147
            with dissolve
            orushi "You are eliminated."
            stop music fadeout 2
            jump gameovere5
    else:

        scene e5trial136
        with dissolve
        play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
        play music "<from 98 to 130>musique/cinematiquetense.mp3" volume 0.2
        orushi "…There is a token in your box."
        scene e5trial139
        with dissolve
        d "Phew... it worked."
        ruby "Well done!"
        orushi "Your choice was the right one. You move on to the next stage."
        jump e5s6_reveal_grace

label e5s6_reveal_grace:
    pause 1 
    play sound "sound/whooshtir.wav" volume 0.5
    scene e5trial150
    with dissolve
    orushi "Last box to reveal… Player Grace."
    dpense "She stands tall, eyes focused..."
    pause 3
    play sound "sound/awesome-kick-drum-41824.mp3" volume 0.5 
    scene e5trial151
    with dissolve
    orushi "…There is a token in your box."
    scene e5trial152
    with dissolve
    grace "I... I did it?!"
    ruby "Yes! Nice one!"
    mad "I knew she’d pull through."
    scene e5trial153
    with dissolve
    dpense "The last one to qualify… thank god."
    stop music fadeout 5
    orushi "The trial is now over."
    orushi "All tokens have been revealed."
    orushi "It is time to conclude… and to speak of what comes next."
    play sound "sound/whooshtir.wav" volume 0.5
    play music "musique/MAK0079-TheHero39sQuest-stockmusic-net.mp3" volume 0.2
    scene e5trial154
    with flash
    d "What comes next?"

    jump e5final
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
