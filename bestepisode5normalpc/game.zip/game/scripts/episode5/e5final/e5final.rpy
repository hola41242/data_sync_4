label e5final:

    scene black
    with fade
    pause 1
    scene ep5final1
    with dissolve
    orushi "Ten of you obtained a token."
    orushi "Here are the ten players qualified for the next stage of the B.E.S.T.:"
    scene ep5final2
    with dissolve
    orushi "Madison, Julia, Grace, Ruby, Sofia, Elizabeth, Kira, Steven, Emerick... and [name]."
    scene ep5final3
    with dissolve
    dpense "We did it. Ten still standing. Ten for the real fight."
    scene ep5final4
    with dissolve
    orushi "Interesting."
    pause 0.5
    scene ep5final5
    with dissolve
    orushi "Very interesting, indeed."
    pause 0.5
    scene ep5final6
    with dissolve
    orushi "I must admit, some of you have shown... unexpected potential."
    orushi "You’ve been through trials. Fought each other. Sometimes betrayed each other."
    orushi "You’ve run, jumped, solved, fought. You’ve seduced, bluffed, endured."
    scene ep5final7
    with dissolve
    orushi "But above all... you all believed it had meaning."
    stop music fadeout 2
    scene ep5final8
    with hpunch
    mad "What do you mean?"
    play music "<from 0 to 16>musique/sinister-overture-166489.mp3" volume 0.2 noloop
    orushi "What you just experienced... was merely a warm-up."
    pause 0.5
    scene ep5final9
    with dissolve
    orushi "This was just a pre-selection."
    orushi "A test run, a shadow tournament, a series of qualifiers for... something much greater."
    scene ep5final10
    with dissolve
    beth "Tch. I figured as much..."
    scene ep5final11
    with dissolve
    orushi "What you’ve faced here... was just a prelude."
    scene ep5final12
    with dissolve
    orushi "A closed tournament. Local. Hidden from the outside world."
    pause 1
    orushi "But the real B.E.S.T..."
    play sound "sound/voom.wav" volume 1
    scene ep5final13
    with dissolve
    pause 1
    stop music fadeout 1
    play music "<from 16.5 to 34>musique/sinister-overture-166489.mp3" volume 0.2 noloop fadein 1
    orushi "...is a global competition."
    scene black
    play movie "images/animation/terrebest-1.webm" volume 0 noloop  
    show movie with dissolve
    orushi "Broadcast live. In every country, around the world..."
    orushi "...where every move you make will shape how the world sees you."
    dpense "The whole world...?"
    stop movie
    scene ep5final14
    with dissolve
    ruby "No way... Is this some kind of joke?"
    orushi "Oh, no. I never joke."
    pause 0.5
    scene ep5final15
    with dissolve
    orushi "You think you're done? You’ve only just begun."
    stop music fadeout 2
    pause 1
    play music "<from 35>musique/sinister-overture-166489.mp3" volume 0.2 noloop
    scene ep5final16
    with dissolve
    orushi "Very soon, your names, your faces, your flaws, your ambitions..."
    orushi "...will be brought to light."
    orushi "And who you truly are… will be judged by the entire world."
    scene ep5final17
    with dissolve
    orushi "Teams from around the globe. Handpicked. Trained for months."
    orushi "Some failed. Others are ready. You... have passed the first gate."
    scene ep5final18
    with dissolve
    grace "Why us? Why all of this?"
    orushi "What you went through wasn't a game. It was a filter. A revelation."
    orushi "The B.E.S.T isn't a competition for children. It's a catalyst."
    play sound "sound/Cinematic Impact.mp3" volume 0.5
    scene ep5final19
    with dissolve
    orushi "Prepare yourselves."
    orushi "The stage is growing."
    scene ep5final20
    with dissolve
    orushi "The game... is changing scale."
    stop music fadeout 2
    scene black with Dissolve(2)
    pause 2 
    play music "musique/Z252-PreparationAndExecution-Ames.mp3" volume 0.5

    scene ep5final23
    with flash
    orushi "Teams from all around the world..."
    scene ep5final22
    with flash
    orushi "Are coming here to face you."
    scene ep5final21
    with flash
    orushi "And the first one has just arrived from the airport!"
    scene ep5final26
    with flash
    beth "Seriously?"
    scene ep5final25
    with flash
    mad "Who are..."
    scene ep5final24
    with flash
    grace "New opponents?"
    scene ep5final27
    with flash
    d "Wait..."
    scene ep5final28
    with flash
    d "What..."
    scene ep5final29
    with flash
    d "The..."
    scene ep5final30
    with flash
    d "Fuck???"
    scene ep5final31 with hpunch
    with flash
    d "Elise...?!"
    $ Achievement.add(achievement_endep5)
    $ achievement.grant("endep5")
    $ achievement.sync()
    pause 2
    scene black with Dissolve(4)

    play sound "sound/Long swoosh.wav" volume 0.5

    show text "TO BE CONTINUED..." at truecenter
    with Dissolve(2.0)
    pause 3
    hide text
    with Dissolve(2.0)
    stop music fadeout 5
    pause 3



    play movie "images/animation/best2trailer.webm" volume 0.2 noloop
    show movie
    pause 12 
    hide movie

    show screen best2wishlist()
    with Dissolve(2.0)


    pause 5
    $ persistent.trailerseen = True
    menu:
        "Continue":
            hide screen best2wishlist
            with Dissolve(2.0)
            pause 1
            pass

    pause 2
    with fade
    show text _ ("SAVE NOW") at truecenter
    "Please save your game here..."
    stop music fadeout 2.0
    pause 3
    with dissolve
    hide text
    pause 1
    scene black
    with fade
    pause 1
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" 
    pause 1.25
    scene coming
    with zoomout
    pause 4
    scene black
    with fade
    pause 0.5
    scene comingep54
    with fade
    orushi "It's not finished!"
    pause 2
    scene black
    with fade
    pause 0.5
    scene comingep53
    with fade
    mad "I will go into Orushi's tower and I will find what's going on!!!"
    pause 2
    scene comingep55
    with fade
    pause 0.5
    orushi "This trial will tell us who will be the new captain of the team!"
    pause 2
    scene black
    with fade
    pause 0.5
    scene ep6preview
    with fade
    orushi "Get ready for the finals!"
    scene ep6preview2
    with dissolve
    pause 5
    stop music fadeout 5
    scene black
    with fade
    pause 5
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
