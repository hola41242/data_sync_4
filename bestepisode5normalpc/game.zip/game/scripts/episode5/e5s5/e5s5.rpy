label e5s5:
    $ CharlottePath = False
    $ postBlueSelfie = False
    $ GabyPath = True
    $ rubyProtect = False

    if rubyPath == True:
        scene rubyfins431
        with dissolve
        dpense "Ruby’s still asleep..."
        dpense "She looks peaceful. Almost like all the chaos melted away overnight."
        dpense "Her blanket slipped..."
        dpense "Her breast is exposed, barely covered by the edge of her nightgown."
        dpense "Just the rise and fall of her breath, soft and warm."

        if persistent.patch_enabled == True:
            $ TEMP1 = e5s4c21
            $ TEMP2 = e5s4c22
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""

        menu:
            "Gently pull her gown back into place.[TEMP1!t]":
                call buddy_increased from _call_buddy_increased_26
                $ rubyProtect = True
                scene rubyfins433
                with dissolve
                dpense "I reach out and gently fix her gown."
                dpense "She stirs a little, but doesn’t wake up."
                scene rubyfins432
                with dissolve
                dpense "She deserves that dignity. That comfort."
                dpense "I won’t be another source of pressure in her life."
            "Leave it as it is...[TEMP2!t]":
                call temperament_increased from _call_temperament_increased_25
                $ rubyProtect = False
                dpense "I let it be."
                dpense "She’s beautiful like this... but more than that, she trusts me."
                dpense "And that means something."
                dpense "This moment is hers."

        pause 1
        scene rubyfins434
        with dissolve
        dpense "Time to get moving."
        scene black with Dissolve(4)
        stop music fadeout 2
    else:

        scene rubyfins429
        with dissolve
        dpense "Morning already..."
        dpense "Hard to believe everything that happened yesterday was real."
        dpense "Marc, Julia, Ruby... it’s all spinning in my head."

    $ blueep5Path = False


    if blueep5 == True:
        play sound "sound/vibration.mp3"
        pause 1
        dpense "A message from Sofia?"

        $ phone.menu = False
        $ phone.group_chat.group_chat("sofia1").add_character(["sofia", "d"])
        phone discussion "sofia1":
            time year 2023 month 9 day 11 hour 8 minute 27
            "sofia" "Morning, troublemaker. 😘"
            "sofia" "Wanna help me pick out a new bag today?"
            "sofia" "Meet me at 11? You’ll get bonus kisses."
            "d" "You drive a hard bargain."
            "sofia" "Only fair. You drive me crazy."
        phone end discussion

        $ blueep5Path = True
    stop music fadeout 2
    if chagabymass:
        dpense "Let's see what Charlotte was planning..."
        jump e5s5_massage_chagaby

    elif gabymass:
        dpense "Let’s see what kind of ‘recovery massage’ Gabriella booked for me..."
        play music "musique/ENM0078-ShadesInstrumental-stockmusic-net.mp3" volume 0.2
        jump e5s5_massage_gaby_main

    elif blueep5:
        dpense "Blue’s waiting for me at the mall..."
        jump e5s5_blue
    else:

        dpense "I guess I’ve got the morning to myself."
        jump e5s5_prep_match


label e5s5_massage_chagaby:

    if _in_replay:
        show screen Replayexit
    scene black
    with fade
    pause 2
    scene e5gabycha1
    with Dissolve(2.0)
    play music "musique/ENM0078-ShadesInstrumental-stockmusic-net.mp3" volume 0.2
    scene e5gabycha2
    $ renpy.movie_cutscene("images/animation/gabycha1.webm", stop_music=False)
    scene e5gabycha2
    ji "Ah, you must be [name]. Welcome. Charlotte said you'd be coming. Room 2. Here’s your towel. They're inside."
    pause 1 
    scene e5gabycha3
    with Dissolve(2.0)
    scene e5gabycha4
    $ renpy.movie_cutscene("images/animation/gabycha2.webm", stop_music=False)
    scene e5gabycha4
    dpense "Room 2...? 'They'...? She really planned something. I need to change before going in..."
    pause 1
    scene e5gabycha5
    with dissolve
    dpense "Okay... Gabriella's already on the table."
    scene e5gabycha6
    with dissolve
    dpense "And Charlotte too..."
    scene e5gabycha7
    with dissolve
    pause 2 
    scene e5gabycha8
    with dissolve
    dpense "She’s staring right at me... telling me not to speak."
    scene e5gabycha9
    with dissolve
    gaby "Mmm... finally. My back is killing me."
    gaby "This place always books up fast, but Charlotte made sure we got in early."
    scene e5gabycha10
    with dissolve
    cha "Of course. I take care of what matters."
    dpense "Wait… she wants me to massage her?"
    scene e5gabycha11
    with dissolve
    dpense "Her face is buried in that table... she has no idea it’s me."
    cha "Be a dear and help with her shoulders, will you?"
    scene e5gabycha12
    with dissolve
    pause 2 
    scene e5gabycha13
    with dissolve
    dpense "Wait… What is Charlotte doing?"
    scene e5gabycha14
    with dissolve
    dpense "No way. She wouldn’t..."
    scene e5gabycha15
    with vpunch
    gaby "Oh... That pressure’s just right..."
    scene e5gabycha16
    with vpunch
    gaby "Stronger than usual today. Did they switch staff again?"
    dpense "I can’t react. Just keep massaging."
    scene e5gabycha17
    with hpunch
    stop music fadeout 1
    dpense "What the..."
    scene black
    with fade
    pause 1
    stop movie
    play music "musique/ARS0038-BackToLife-stockmusic-net.mp3" volume 0.2 fadein 1
    play movie "images/animation/chablowanim.webm" volume 0 loop 
    with dissolve
    show movie
    ""
    dpense "She has no limits..."
    dpense "Or maybe it's just a game to her?"
    dpense "And Gabriella..."
    pause 1 
    stop movie
    scene e5gabycha18
    with dissolve
    gaby "Right there... mmh... that knot’s been bothering me all week."
    cha "He’s hitting all the right spots, isn’t he?"
    scene e5gabycha19
    with dissolve
    gaby "Ugh... yes. I don’t know what he's doing, but it's working."
    gaby "I'm closing my eyes and imagining who that could be..."
    scene e5gabycha20
    with dissolve
    cha "Takes a special kind of intuition... some people just know where to press."
    cha "But I'm sure you can imagine your student!"
    gaby "Charlotte!"
    scene e5gabycha21
    with dissolve
    dpense "This is insane..."
    dpense "She’s talking while Charlotte..."
    scene e5gabycha22
    with dissolve
    gaby "Deeper, just a little... yes... that’s it..."
    gaby "I might melt if you keep that up."
    scene e5gabycha23
    with dissolve
    cha "Don’t tempt him, Gaby."
    scene e5gabycha24
    with dissolve
    gaby "Tempt? I’m just saying how I feel!"
    dpense "She has no idea... and Charlotte’s not stopping."
    scene e5gabycha25
    with dissolve
    gaby "Seriously, I need this every week."
    gaby "Whoever this is, they deserve a raise."
    play movie "images/animation/chablowanim2.webm" volume 0 loop 
    with dissolve
    show movie
    dpense "Stay focused. Don’t..."
    cha "Relieve the pressure."
    d "Is she talking to me or...?"
    scene e5gabycha26
    stop movie
    gaby "Ahhh..."
    scene e5gabycha27
    with dissolve
    gaby "[name]..."
    dpense "What???" with hpunch
    dpense "Did she just say my name?"
    dpense "I can't..."
    scene e5gabycha25
    with flash
    with hpunch
    dpense "Fuuuuuckkkk!"
    scene e5gabycha28
    pause 1
    with flash
    with hpunch
    scene e5gabycha29
    with dissolve
    pause 1
    with vpunch
    with flash
    scene e5gabycha30
    with dissolve
    pause 2
    scene black
    with fade
    stop music fadeout 1
    pause 1
    play music "musique/ENM0078-ShadesInstrumental-stockmusic-net.mp3" volume 0.2
    scene e5gabycha31
    with fade
    cha "Mmm. I’m all set for the day now."
    dpense "She drained me..."
    scene e5gabycha4
    with dissolve
    gaby "You’re already done?"
    cha "Yup. And looks like you are too, Gaby."
    gaby "Ugh... I could stay like this forever."
    dpense "She still doesn’t know..."
    scene e5gabycha32
    with fade
    cha "Come on, [name]. Let the lady enjoy her afterglow."
    scene e5gabycha33
    with fade
    cha "You did good."
    d "You too."
    dpense "That was... a lot."
    dpense "Charlotte planned every second of that. And Gabriella..."
    dpense "She still has no clue."
    dpense "What even was that?"
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    $ Achievement.add(achievement_milfy)
    $ achievement.grant("milfy")
    $ achievement.sync()
    $ CharlottePath = True
    scene black
    with fade
    pause 2

    jump e5s5_massage_gaby_main

label e5s5_massage_gaby_main:

    if ('chagabymass' in vars() or 'chagabymass' in globals()) and chagabymass == True:
        ji "Oh, you're back already? That was quick. Room 3 is ready for you again."
        dpense "She remembers me from earlier... Good thing she doesn't ask questions."
    else:
        "Receptionist" "Hello! You must be [name], right? Your session is ready. Room 3, please."

    if _in_replay:
        show screen Replayexit
    scene e5gabymass1
    with fade
    dpense "Oh. It's cozy."
    scene e5gabymass2
    with dissolve
    dpense "Not bad... I'm curious who will massage me..."
    gaby "There you are. Right on time."
    dpense "Hmm?"
    scene e5gabymass3
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5gabymass4
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5gabymass6
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 2
    scene e5gabymass5
    with dissolve
    pause 0.2
    d "I didn’t expect you here, to be honest."
    scene e5gabymass7
    with dissolve
    gaby "You’ve got an important match coming. I want you in top shape."
    d "Fair enough."
    dpense "She’s so calm… like this is just another day at work."
    gaby "Lie down on your back. We’ll focus on your legs."
    scene e5gabymass8
    with dissolve
    if ('chagabymass' in vars() or 'chagabymass' in globals()) and chagabymass == True:
        dpense "It’s crazy… She has no idea it was me earlier."
        dpense "And now she’s going to massage me like nothing happened."
    pause 1
    scene e5gabymass9
    with dissolve
    gaby "Tell me if the pressure’s too much."
    d "It’s perfect. Firm, but smooth."
    dpense "Her hands are confident. Precise. She knows exactly what she’s doing."
    scene e5gabymass10
    with dissolve
    gaby "Your quads are tight. I can feel a lot of built-up tension."
    d "Makes sense. I’ve been pushing hard lately… and thinking a lot."
    gaby "Thinking?"
    d "About the match. About staying focused."
    scene e5gabymass11
    with dissolve
    gaby "Keep that mindset. You need to be sharp."
    dpense "She’s trying to stay professional. But she feels the tension."
    gaby "I’m moving up on your thighs. Let me know if it gets too sensitive."
    d "You mean physically, or emotionally?"
    scene e5gabymass12
    with dissolve
    gaby "Physically. Let’s not make this complicated."
    dpense "Got her. She’s hesitating now."
    gaby "You’re very warm. Muscles are reacting well."
    d "Maybe it’s just your touch."
    scene e5gabymass13
    with dissolve
    gaby "...Let’s keep this professional, okay?"
    d "Of course. Just saying… you’ve got magic fingers."
    dpense "Her cheeks are red now. She’s flustered."
    gaby "Hips next. Try to breathe and relax."
    scene e5gabymass14
    with dissolve
    d "Kinda hard to relax with you standing that close."
    gaby "Would you prefer someone else?"
    d "Not even close."
    gaby "...[name]. This isn’t just recovery anymore."
    d "Maybe not. But it feels right."
    scene e5gabymass16
    with dissolve
    gaby "I’m your coach. I’m older. This isn’t supposed to happen."
    d "Then why are your hands still on me?"
    scene e5gabymass17
    with dissolve
    gaby "I..."
    d "Tell me to stop. I will."
    scene e5gabymass18
    with dissolve
    pause 1
    gaby "...No."
    dpense "Her guard’s breaking. Just a little more..."
    dpense "Her voice is barely a whisper. But her hands… they haven’t moved away."
    gaby "I shouldn’t be doing this…"
    scene e5gabymass19
    with dissolve
    d "Then tell me to get my hands off you."
    gaby "..."
    dpense "She doesn’t say a word."
    scene e5gabymass20
    $ renpy.movie_cutscene("images/animation/gabymassanim1.webm", stop_music=False)

    scene e5gabymass20
    with dissolve
    d "You’re tense too, you know. All this pressure… it’s not just on the field."
    gaby "That’s not the same thing."
    d "Isn’t it? You’re always giving. Always in control. Maybe you deserve to let go for once."
    scene e5gabymass21
    with dissolve

    dpense "Her breath caught for a second. She felt that."
    gaby "You're my student…"
    d "And you're a beautiful woman, Gabriella, who's touching me like she wants to forget the rules for just a moment."
    scene e5gabymass22
    with dissolve
    gaby "...Just a moment."
    dpense "She’s trembling. Not from fear. From anticipation."
    scene e5gabymass23
    with dissolve
    gaby "I'm going to focus on your inner thighs now."
    dpense "Her voice is low. Controlled. But her fingers are slower... more lingering."
    d "Mmh… Let me help you..."
    scene e5gabymass24
    with hpunch
    gaby "[name]!"
    d "Don't worry, I'll stay professional!"
    scene e5gabymass25
    with dissolve
    gaby "But..."
    scene e5gabymass26
    with dissolve
    dpense "She’s trying to regain control."
    scene e5gabymass27
    with dissolve
    dpense "But her fingers are tracing patterns… way too soft to be professional."

    d "Let me help… you're doing so much already."
    scene e5gabymass28
    with dissolve
    gaby "[name]…"
    d "Shh. Just feel it."
    scene e5gabymass29
    with dissolve

    dpense "Her body tensed. But she didn't move away."
    play movie "images/animation/gabymassanim2.webm" volume 0 loop 
    with dissolve
    show movie
    ""
    gaby "Ah..."
    gaby "Humpff..."
    gaby "This isn’t..."
    gaby "Why I came here…"
    stop movie
    play movie "images/animation/gabymassanim3.webm" volume 0 loop 
    with dissolve
    show movie
    d "Then why are your hands still on me?"
    gaby "Because…"
    gaby "I can't stop."
    stop music fadeout 2
    ""
    scene black with Dissolve (2)

    stop music fadeout 1
    scene black
    stop movie
    scene black
    play music "musique/NVA0352-RelaxingSpaHipHop-stockmusic-net.mp3" fadein 1 volume 0.2
    play movie "images/animation/gabyhandanim.webm" volume 0 loop 
    with dissolve
    show movie
    dpense "She’s not avoiding anything anymore."
    d "See? You're amazing at this. You make me melt under your touch."
    gaby "You're making it impossible to stay professional…"

    d "Maybe I don’t want you to."
    gaby "...If anyone found out..."
    d "No one will. It’s just us. Just this moment."
    gaby "Then..."
    gaby "Don’t stop..."
    dpense "Her hand moves slowly up and down… God, it feels too good."
    d "You’re incredible… so soft…"
    gaby "And you’re… so hard… it’s insane…"

    dpense "I press my fingers inside her, slowly. She arches her back, gasping."
    gaby "[name]... that’s... ah..."

    dpense "Her grip tightens… she’s stroking me and now..."
    d "...Oh shit..."
    dpense "Her other hand is gently cupping my balls."
    d "Gabriella…"
    stop movie
    scene e5gabymass30
    with dissolve
    gaby "Does that feel good? You like it when I play with you like that?"
    scene e5gabymass31
    with dissolve
    d "I can’t... I mean... Yeah. I love it. Don’t stop…"
    scene e5gabymass29
    with dissolve
    dpense "Her body’s melting against mine. Her hips are rocking with my fingers."
    scene e5gaby35
    with vpunch
    gaby "You’re making me crazy… I can’t think… I just want..."
    dpense "She’s losing herself. And I’m barely holding on."
    d "Say it. What do you want?"
    gaby "...More... You. All of you… just..."
    scene e5gaby36
    with vpunch
    dpense "She’s grinding into my hand, moaning my name..."
    gaby "[name]... don’t stop, don’t you dare stop..."
    scene e5gaby37
    dpense "Her voice is breaking… she’s close. And so am I."
    d "Together… okay?"
    gaby "Yes… yes..."
    scene e5gaby34
    $ renpy.movie_cutscene("images/animation/gabyfinanim.webm", stop_music=False)
    scene e5gaby34
    with flash
    with hpunch
    gaby "[name]!"
    with flash
    with hpunch
    d "Gabriella!"
    scene e5gaby38
    with dissolve
    with flash
    with hpunch
    pause 1
    with flash
    with vpunch
    scene e5gaby39
    with vpunch
    gaby "Oh my god... oh my..."
    with flash
    with hpunch
    scene e5gaby40
    with hpunch
    gaby "...What did we just do?"
    d "We let go. Just for a moment."
    scene e5gaby41
    with dissolve
    gaby "I… I can’t believe this happened. I’m your coach. I’m supposed to guide you, not..."
    d "You didn’t do anything wrong. You were just… human."
    scene e5gaby42
    with dissolve
    gaby "This can’t happen again."
    d "..."
    gaby "I need to go."
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    $ GabyPath = True
    scene e5gaby43
    with dissolve
    dpense "She’s gone. Just like that."
    dpense "I don’t know what’s going through her mind, but I know exactly what’s going through mine."
    dpense "That was… unforgettable."
    dpense "But what does it even mean, now?"
    scene black
    with Dissolve(3)
    if blueep5:
        dpense "Blue’s waiting for me..."
        pause 1 
        stop music fadeout 2 
        scene black with Dissolve(3)
        pause 1
        jump e5s5_blue
    else:

        dpense "I guess I’ve got the morning to myself."
        pause 1 
        stop music fadeout 2 
        scene black with Dissolve(3)
        pause 1
        jump e5s5_prep_match

label e5s5_blue:
    pause 2.0
    play music "musique/ALM0187-RomanticLoveStory-stockmusic-net.mp3" volume 0.2
    scene bluee5s53
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene bluee5s54
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene bluee5s55
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 2
    scene bluee5s52
    with dissolve
    pause 1 
    scene bluee5s51
    with dissolve
    sofia "Hey you!"
    scene bluee5s56
    with dissolve
    d "Sofia."
    scene bluee5s57
    with dissolve
    d "You look stunning today."
    scene bluee5s58
    with dissolve
    sofia "So do you. Slept well?"
    d "Let’s say I’ve had worse nights."
    scene bluee5s59
    with dissolve
    sofia "Perfect. I need your masculine eye to help me choose a bag."
    sofia "And maybe… a little more if you behave."
    scene bluee5s510
    with dissolve
    d "Bribery first thing in the morning?"
    sofia "Call it charm, Mr. Fashion Consultant."
    scene bluee5s511
    with dissolve
    d "By the way, I ran into someone recently. His name's Marc."
    sofia "Marc? Doesn’t ring a bell."
    d "He seemed to know a lot about the B.E.S.T... and about us."
    scene bluee5s512
    with dissolve
    sofia "Wait, what? How’s that possible?"
    d "No idea. He said some weird stuff, like he had access to everything. And he warned me."
    scene bluee5s513
    with dissolve
    sofia "Okay, now I’m creeped out."
    sofia "You think he’s some kind of spy? A former contestant?"
    scene bluee5s514
    with dissolve
    d "I don’t know. But he was too calm. Too confident."
    d "I just wanted to tell you. Just in case."
    scene bluee5s515
    with dissolve
    sofia "Thanks... I like that you tell me these things. I promise I’ll stay alert."
    sofia "Maybe I will ask my sister. If someone can have something about him, it's her."
    sofia "She can do this for us."
    scene bluee5s516
    with dissolve
    d "Us... Do you ever think about what this really means?"
    d "You and me. In the middle of this competition. The other girls, the stakes... everyone watching us."
    scene bluee5s517
    with dissolve
    sofia "I mostly think that I really like you."
    sofia "And that it’s too special to keep hidden just because of a game."
    d "But it’s not just a game. Some of them would do anything to win. If we go public, we become a target."
    scene bluee5s518
    with dissolve
    sofia "Maybe. But if we’re too scared to love, then we’ve already lost, haven’t we?"
    d "I just... I don’t want you getting hurt because of me. Or for them to use this against us."
    scene bluee5s519
    with dissolve
    sofia "You overthink, [name]. But..."
    scene bluee5s520
    with dissolve
    sofia "That’s one of the reasons I feel safe with you."


    d "Wanna take a selfie? Just for us."
    sofia "I'd love that."
    pause 0.5
    scene bluee5s5os
    with dissolve
    play sound "sound/Photo.mp3" volume 1
    with flash

    d "There. A perfect shot of a power couple."



    if ('kiraosinvite' in vars() or 'kiraosinvite' in globals()) and kiraosinvite:

        d "Do you think I should post it? Make it... kind of official?"
        scene bluee5s521
        with dissolve
        sofia "Hmm... you mean like, ‘Hey world, she’s mine’?"
        d "I mean... are we ready for that? Showing it to everyone, right when people are watching our every move?"
        sofia "I say we stop hiding and start living. If it feels real, let it be real."

        menu:
            "Post the selfie on OnlyStan":
                $ postBlueSelfie = True
                $ addOnlystanPost(_("My new universe ;)"), _("Discovering each other!"), 1, "phone/assets/bluee5s5os.webp", "blue_1")
                d "Done. Might be a small move, but it means a lot."
                scene bluee5s522
                with dissolve
                sofia "Wow... okay. It’s out there now."
                sofia "You’re gonna get some jealous comments."
                d "Let them. I only care about one opinion."
                d "Yours."
                sofia "Charmer."
            "Don’t post it":

                $ postBlueSelfie = False
                scene bluee5s522
                with dissolve
                d "No... not yet. Let’s keep this just for us for now."
                sofia "Okay. As long as it’s real, that’s enough for me."
                sofia "But one day, you better show the world what you’ve got."
                d "Deal. But YOU better just show me what you've got!"
                scene bluee5s523
                with dissolve
                sofia "You means that butt???"
                scene bluee5s524
                with dissolve
                d "Exactly!"
                sofia "Ahah!"
    else:

        scene bluee5s522
        with dissolve
        d "Let’s keep this one between us. I like having this moment just for us."
        sofia "Me too. It makes it even more special."

    scene bluee5s525
    with dissolve
    pause 1
    play sound "sound/vibration.mp3"
    pause 1
    scene bluee5s526
    with dissolve
    d "Hmm? A message from Grace."

    play sound "sound/vibration.mp3"
    pause 0.5
    sofia "And one from my sister."

    $ phone.menu = False
    $ phone.group_chat.group_chat("grace1").add_character(["grace", "d"])
    phone discussion "grace1":
        time year 2023 month 9 day 11 hour 9 minute 58
        "grace" "Where are you?! It's time!!"
        "grace" "Everyone needs to be at the stadium!"
    phone end discussion


    d "Time to go."
    scene bluee5s526
    with dissolve
    sofia "I guess we’ll shop for that bag another time."
    scene bluee5s528
    with dissolve
    d "Next time, we don’t let anything get in the way."
    sofia "Deal. Now go win this thing."
    d "Oh you want to win?"
    scene bluee5s527
    with dissolve
    sofia "Me? No! I don't care!"
    sofia "But I will help you."
    d "Huh?"
    sofia "If I can..."
    stop music fadeout 2
    scene black with Dissolve(4)
    pause 1 
    jump e5s6


label e5s5_prep_match:
    play sound "sound/vibration.mp3"
    pause 1

    d "Hmm? A message from Grace."
    $ phone.menu = False
    $ phone.group_chat.group_chat("grace1").add_character(["grace", "d"])
    phone discussion "grace1":
        time year 2023 month 9 day 11 hour 9 minute 58
        "grace" "Where are you?! It's time!!"
        "grace" "Everyone needs to be at the stadium!"
    phone end discussion
    d "Time to go."
    scene black with Dissolve(4)
    pause 1 
    jump e5s6
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
