label e5intro:

    init -999 python:
        if "math" in store.__dict__:
            if isinstance(store.math, type(__import__("math"))):
                del store.math

    python hide:
        def delete_app(name, key=None):
            d = phone.application.get_app_dict(key)
            
            for i in range(phone.config.applications_pages):
                for row in d[i]:
                    for app in tuple(row):
                        if hasattr(app, "name") and app.name == name:
                            row.remove(app)
                            return True
            return False


        try:
            delete_app("skill_tree")
        except:
            pass  

    $ juliaphonep4inter = False
    $ rubyphonep4inter = False







    $ Episode4 = False
    $ Episode5 = True


    $ onlystanPostsInScript = []
    $ onlystanCommentsInScript = []
    $ onlystanV2 = True


    $ addOnlystanPost(_("Hello! My name is Fanny and I am new here. Tell me what you like in the comments ;)"), _("Hi everyone :)!"), 2, "phone/assets/fanny.png", "fanny_1", _("Very beautiful! I'm very happy to meet you there 😊"))
    $ addOnlystanPost("", _("Beach day! 🌴🏖️"), 2, "phone/assets/fannyplaya.jpg", "fanny_2", _("Take me with you next time 😂! I love your outfit btw"))
    $ addOnlystanPost("", _("Preparing for a party with my best friend 💕"), 2, "phone/assets/fannyprepa.jpg", "fanny_3", _("A party? Count me in! Just tell me where and when, I’ll bring the good vibes 🎉!"))


    $ addOnlystanComment(_("Pretty girl 🤤"), 3, "fanny_1")
    $ addOnlystanComment(_("Hey ! I love your body... Would you like to get to know each other 😉?"), 4, "fanny_1")
    $ addOnlystanComment(_("My D is still so hard seeing you 🥵🥵"), 3, "fanny_2")
    $ addOnlystanComment(_("I am so honoured to breath the same air as you 🥵😍"), 4, "fanny_3")
    $ addOnlystanComment(_("I'm bending over backwards just to comment here 😉"), 5, "fanny_1")
    $ addOnlystanComment(_("You look like someone who needs a hug 🥰"), 6, "fanny_1")
    $ addOnlystanComment(_("Ben, you're always bending over for attention 🤦‍♀️"), 6, "fanny_1")
    $ addOnlystanComment(_("Anita, don’t be so mean! Everyone deserves a little flexibility 😏"), 7, "fanny_1")
    $ addOnlystanComment(_("Wow, this is small talk at its finest 😏"), 7, "fanny_2")
    $ addOnlystanComment(_("This beach photo is making waves 🌊!"), 8, "fanny_2")
    $ addOnlystanComment(_("This beach photo is making waves 🌊!"), 8, "fanny_2")
    $ addOnlystanComment(_("Hugh, you're just fishing for compliments again 🎣"), 12, "fanny_2")
    $ addOnlystanComment(_("Seymour, let him enjoy the tide, it's not every day we get such views 😎"), 9, "fanny_2")
    $ addOnlystanComment(_("Party with friends? Save me a spot next time! 🎉"), 11, "fanny_3")
    $ addOnlystanComment(_("Willie, you weren't invited last time for a reason... 😒"), 10, "fanny_3")
    $ addOnlystanComment(_("Ivana, don't be salty, we all know Willie likes to party hard 😉"), 6, "fanny_3")
    $ addOnlystanComment(_("Anita, you're the life of the party, admit it ❤️!"), 5, "fanny_3")
    $ addOnlystanComment(_("Hard to resist such beauty 😏🔥"), 11, "fanny_1")
    $ addOnlystanComment(_("Always here to have your back ❤️"), 9, "fanny_2")
    $ addOnlystanComment(_("Cheeky post! Keep them coming 😜"), 12, "fanny_2")
    $ addOnlystanComment(_("This made me tinkle with laughter 💦"), 10, "fanny_3")

    if onlystanPosts[0].commentSent:
        $ onlystanPostsInScript[0].sendMCComment()

    if onlystanPosts[1].commentSent:
        $ onlystanPostsInScript[1].sendMCComment()

    if onlystanPosts[2].commentSent:
        $ onlystanPostsInScript[2].sendMCComment()

    if ('KiraPalazioShot' in vars() or 'KiraPalazioShot' in globals()) and KiraPalazioShot:
        $ addOnlystanPost(_("A great night with good company!"), _("Look who we found tonight!"), 2, "phone/assets/polep412.webp", "palazio_with_mc", _("Awesome night! Let's do this again anytime!😊"))
    else:


        $ addOnlystanPost(_("A great night with my BF!"), _("Partying together!"), 2, "phone/assets/miratest2.jpg", "palazio_without_mc", _("Oh! I missed this? Next time I will be there!"))



    play music "musique/Aerocity-Stranger.mp3" volume 0.2 fadein 2
    scene black
    with fade
    pause 2
    scene e5intro1
    with fade
    ji "Thanks again for watching Ruby tonight, Carmen. It’s such a relief knowing she’s here with you."
    carmen "Of course! Don’t worry about a thing. We’ll have a good time."
    ji "Thanks so much. See you later!"
    scene black
    with fade
    pause 1 
    scene e5intro2
    with fade
    pause 1 
    scene e5intro3
    with dissolve
    pause 2 
    scene e5intro4
    with dissolve
    pause 2 
    scene e5intro5
    with dissolve
    ruby "What do you want to be when you grow up?"
    scene e5intro6
    with dissolve
    mad "Me? I’m gonna be a queen! I’ll have a huge castle, and everyone will do what I say."
    ruby "Wow! What about me? What would I do in your castle?"
    scene e5intro7
    with dissolve
    mad "You’d be my bodyguard! Like in the movies! You’d be super tough, and you’d keep me safe."
    scene e5intro8
    with dissolve
    ruby "Yeah! I’ll be so strong, and no one will mess with you!"
    mad "Right. And that way, we’ll always be together."
    ruby "Okay! I’ll always protect you."
    scene black
    with fade
    pause 1

    scene e5intro9
    with fade
    pause 2 
    scene black
    with fade
    pause 1
    scene e5intro10
    with fade
    pause 2 
    scene black
    with fade
    pause 1 
    scene e5intro11
    with fade
    pause 2 
    carmen "Officer?"
    ji "Ms. Forrester, I’m really sorry to come by so late, but I have some bad news."
    ji "It’s about Mr. and Mrs. Suyin. They were in a car accident."
    scene e5intro12
    with dissolve
    ji "A truck came out of nowhere and hit their car. Emergency crews arrived quickly, but... it was too late. They didn’t survive."
    carmen "Both of them? Are you sure there’s no chance?"
    ji "I’m so sorry. No, there were no survivors."
    scene e5intro13
    with dissolve
    carmen "And Ruby? What happens to her now? She’s just a little girl…"
    ji "Social services will be notified. They’ll get in touch with the nearest family members to arrange for her care."
    carmen "I see. But in the meantime, she’s here. She knows this place, she feels safe here."
    scene e5intro14
    with dissolve
    carmen "Could I keep her with me until everything is sorted out? I just want to make sure she’s okay."
    ji "That sounds reasonable. But you’ll need to coordinate with the authorities soon to make it official."
    carmen "Of course. I’ll do everything properly. I just want her to feel safe and protected."
    ji "Alright. I’ll let you know as soon as I have more information."
    scene e5intro15
    with dissolve
    mad "Remember what I said? I’ll always be here for you. We’ll be okay."
    scene black
    with fade
    pause 1
    mad "Later, when we’re all grown up, things will be better. You’ll see."
    pause 2
    stop music fadeout 2 
    play sound "sound/WhooshEpic.mp3" volume 2 
    show text _ ("EPISODE 5") at truecenter
    with dissolve

    pause 2 
    hide text with dissolve
    pause 1
    show text _ ("ORIGINS") at truecenter
    with dissolve
    pause 2 
    hide text with dissolve
    pause 2

    jump e5s1
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
