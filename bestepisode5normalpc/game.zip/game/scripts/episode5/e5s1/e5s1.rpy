label e5s1:
    $ JuliaPathe5 = False
    $ RedPathe5 = False
    play sound "sound/coeur.wav" volume 0.2
    $ Traininggabyep5 = False
    scene finep416
    with fade
    pause 1
    scene ep5s1i1
    $ renpy.movie_cutscene("images/animation/ep5s1anim1.webm", stop_music=False)
    scene ep5s1i1
    with dissolve
    stop sound
    pause 0.5 
    play music "musique/MYO0031-ActionSportsEnergeticRockTrailer-stockmusic-net.mp3" volume 0.2
    scene ep5s1i2 with flash
    pause 0.5
    scene ep5s1i3
    $ renpy.movie_cutscene("images/animation/ep5s1anim2.webm", stop_music=False)
    scene ep5s1i3
    with dissolve
    d "RUBYYYYYYYYYYYYYY!"
    scene ep5s1i4
    with flash
    pause 1
    scene ep5s1i5
    with hpunch
    pause 1
    scene ep5s1i6
    with hpunch
    pause 1
    scene ep5s1i7
    with hpunch
    ruby "AHHHHH!"
    scene ep5s1i8
    with hpunch
    ruby "OUCH!"
    scene ep5s1i9
    with dissolve
    pause 1
    scene ep5s1i10
    with dissolve
    ruby "What? What just happened?!"
    d "Are you okay?"
    ruby "Uh... Yeah, I think so"
    d "You were about to get hit by that car. I had to do something."
    scene ep5s1i11
    with dissolve
    ruby "You… did you risk your life for me?"
    d "I couldn’t just stand there and watch you get hurt."
    scene ep5s1i12
    with dissolve
    ruby "I don’t understand… you came out of nowhere. It was like time stopped."
    d "I wasn’t going to let anything happen to you."
    ruby "But… you could have been hurt. Why would you take that kind of risk?"
    d "Because I care about you, Ruby."
    scene ep5s1i13
    with dissolve
    ruby "…"
    scene ep5s1i14
    with hpunch
    d "Wait... Where is Emerick?"
    ruby "I don't know..."
    d "Bastard..."
    d "Come on, let me walk you back to your room. I’ll make sure you’re safe."
    ruby "Thank you."
    stop music fadeout 2
    scene black
    with fade
    pause 2
    scene ep5s1i15
    with fade
    emerick "You missed them!!!"
    scene ep5s1i16
    with dissolve
    hec "I couldn't shoot her!"
    scene ep5s1i17
    with dissolve
    emerick "Fucking frenchy..."
    scene black
    with fade
    pause 2
    play music "musique/MAS0427-ItWasLoveYesterday-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep5s1i18
    with fade
    ruby "Thank you for walking me back. I just… I can’t shake what happened. I was so close to..."
    d "Hey, hey… breathe. You’re safe now. That’s all that matters."
    scene ep5s1i19
    with dissolve
    ruby "But what if I hadn’t been? If you hadn’t gotten to me in time…"
    d "Don’t think about that. I was there. I saw what was happening, and I wasn’t going to let you get hurt."
    scene ep5s1i20
    with dissolve
    ruby "You always seem to know exactly when I need you. How do you… how do you do that?"
    scene ep5s1i21
    with dissolve
    d "It’s not about knowing. It’s just…"
    scene ep5s1i22
    with dissolve
    d "I care about you, Ruby. I couldn’t stand by and watch something happen to you."
    with hpunch
    d "Outch!"
    scene ep5s1i23
    with dissolve
    ruby "Are you in pain?"
    d "Just a little bruise on my back. Don't worry. That's nothing."
    d "You're important to me. I'm glad you're safe now."
    scene ep5s1i24
    with dissolve
    ruby "You don’t know what that means to me. Really. I…"
    play sound "sound/Scratch.mp3"
    stop music
    scene ep5s1i25
    with hpunch
    mad "What happened?!"
    scene ep5s1i26
    with dissolve
    ruby "Madison!"
    play music "musique/Nomyn-Fragments.mp3" volume 0.2 fadein 1
    scene ep5s1i27
    with hpunch
    mad "What the hell did you do? What happened to her?!"
    ruby "Stop it! He didn’t do anything to me."
    scene ep5s1i28
    with dissolve
    mad "Then why are you like this? I can see you're all shaken up"
    ruby "It was Emerick. He pushed me into the road… and [name] saved me."
    ruby "If he hadn’t been there…"
    scene ep5s1i29
    with dissolve
    mad "Emerick? Are you serious? That piece of shit!"
    mad "I can’t believe him. Every damn time, he finds a way to mess with us, to hurt the people I care about."
    ruby "Madison, calm down. It’s over now..."
    scene ep5s1i30
    with dissolve
    mad "No, it’s not over. I’m sick of him thinking he can do whatever he wants."
    mad "Sick of him pushing us around like we’re nothing."
    d "I know you’re angry, Madison, but let’s take a second..."
    scene ep5s1i31
    with hpunch
    mad "A second to what? To let him keep walking all over us? No. Not anymore."
    mad "I’m not letting him hurt anyone else."
    ruby "Madi, you don’t have to..."
    scene ep5s1i32
    with dissolve
    mad "No. I’ll find a way. I’ll go to the Orushi Tower if I have to. I’ll dig up something on him, anything to make him pay."
    scene ep5s1i33
    with dissolve
    mad "I’m just… I’m so glad you’re okay. When I saw your message, I thought…"
    mad "I can’t lose you, Ruby. I just can’t."
    scene ep5s1i34
    with dissolve
    ruby "You’re not going to lose me. I’m here. I’m okay, thanks to him."
    mad "[name]... Thank you so much. For saving her."
    scene ep5s1i35
    with dissolve
    d "I couldn't watch her get hurt."
    d "I’ll give you two some space. Let me know if you need anything."
    ruby "Thanks again. For everything."
    mad "Yeah. Thank you."
    scene black
    with fade
    pause 2


    scene ep5s1i36
    with fade
    d "What the hell just happened back there?"
    d "Emerick... He’s gone too far this time. Pushing Ruby into the road…"
    d "It makes me sick just thinking about it."
    d "And Madison... she was furious, and I get it."
    d "She cares about Ruby just as much as I do. I need to help her deal with him."
    d "Emerick can’t get away with this."
    d "But that… that moment…"
    scene ep5s1i37
    with dissolve
    d "When I saw Ruby in danger, something happened to me. I felt this surge…"
    d "It was like every part of me lit up, moving faster than I ever thought I could."
    d "My mind was completely clear with no hesitations, no doubts."
    d "It felt… like I wasn’t entirely myself. Like I tapped into something I didn’t even know was there."
    d "But whatever it was, it helped me save her."
    d "And that’s what matters right now."
    d "Ruby… I don’t think I ever realized just how much I’ve come to care about her."
    d "Before, she was just someone I knew, someone who was always around. But now… it feels different."
    d "Like I’m really starting to see her for who she is."
    d "Strong, kind, someone I can trust. She’s becoming more than just a familiar face."
    d "She’s becoming…"
    stop music fadeout 2
    play sound "sound/vibration.mp3"
    with hpunch
    scene ep5s1i38
    with dissolve
    d "Hum?"

    play music "musique/NovaNoma-Gaia.mp3" volume 0.2 fadein 2

    if graceep4:
        $ phone.menu = False
        $ phone.group_chat.group_chat("grace1").add_character(["grace", "d"])
        phone discussion "grace1":
            time year 2023 month 9 day 9 hour 20 minute 00
            "grace" "Hey you!"
            "d" "Hey, babe."
            "grace" "What are you doing tomorrow morning?"
            "d" "Not sure yet. Why? You planning something?"
            "grace" "I remember you saying you’d done some climbing before, right?"
            "d" "Yeah, I have. Thinking of trying it too?"
            "grace" "Mmhmm. I found this amazing climbing spot. I thought it might be fun for us to go together."
            "d" "Climbing with you? That sounds pretty good."
            "grace" "So, what do you say?"
            menu:
                "Sure, let’s do it.":
                    $ GraceEsca = True
                    "d" "Alright, I’m in. What time?"
                    "grace" "How about 7 a.m.? I’ll have everything ready for us."
                    "d" "Sounds perfect. Looking forward to spending the morning with you."
                    "grace" "Same here. Miss you."
                    "d" "Miss you too, Grace."
                "Sorry, I’m not free.":
                    $ GraceEsca = False
                    "d" "Sorry, babe, I’ve got something tomorrow morning."
                    "grace" "Oh… okay. Another time then?"
                    "d" "Of course. Let’s plan it soon."
        phone end discussion
    else:

        $ phone.menu = False
        $ phone.group_chat.group_chat("grace1").add_character(["grace", "d"])
        phone discussion "grace1":
            time year 2023 month 9 day 9 hour 20 minute 00
            "grace" "Hey there!"
            "d" "Hey Grace."
            "grace" "I was wondering if you’d like to come climbing with me tomorrow morning."
            "d" "Climbing? I haven’t done that in a while."
            "grace" "Didn’t you mention you’ve done some climbing before?"
            "d" "Yeah, I’ve gone a few times. What’s up?"
            "grace" "There’s a great spot I’ve been wanting to check out, and I thought we could give it a try together."
            "d" "Sounds interesting. Where is it?"
            "grace" "It’ll be a nice change of pace, and I could use the company."
            "grace" "What do you think?"
            menu:
                "Sure, I’m in.":
                    $ GraceEsca = True
                    "d" "Sure, I’d like that. When should we meet?"
                    "grace" "7 a.m. I’ll have everything ready."
                    "d" "Got it, see you then."
                    "grace" "See you!"
                "I don’t think I can.":
                    $ GraceEsca = False
                    "d" "I’m not available tomorrow, sorry."
                    "grace" "No worries. Maybe next time."
                    "d" "Sounds good."
        phone end discussion

    d "It will be fun!"
    pause 1 


    if gabimusee:
        play sound "sound/vibration.mp3"
        d "Again?"

        $ phone.menu = False
        $ phone.group_chat.group_chat("gaby1").add_character(["gaby", "d"])
        phone discussion "gaby1":
            time year 2023 month 9 day 9 hour 20 minute 05
            "gaby" "Good evening, [name]."
            "d" "Good evening, Gabriella."
            "gaby" "I’ve been reviewing your performance on the field, and I believe there are areas we could refine before the final match."
            "d" "Ah, so you’re saying I need more practice?"
            "gaby" "I’m saying you have potential, and I’d like to help you make the most of it."
            "d" "So, you want to give me a private training session?"
            "gaby" "If you’re available tomorrow afternoon, I can show you a few techniques that might give you an edge."
            "d" "Just the two of us? That sounds… intense."
            "gaby" "It’s strictly for your development as a player, [name]."
            "d" "Oh, I wouldn’t dream of it being anything else."
            "gaby" "I’m glad we’re on the same page. So, what do you say?"
            menu:
                "Sounds good, I’ll be there.":
                    $ Traininggabyep5 = True
                    "d" "Sure, I’ll come by. What time should I meet you?"
                    "gaby" "Let’s start at 2 p.m. sharp. Don’t be late."
                    "d" "Wouldn’t miss it for the world."
                "Sorry, I’m busy tomorrow.":
                    $ Traininggabyep5 = False
                    "d" "Sorry, I have other plans tomorrow evening."
                    "gaby" "That’s unfortunate. I suppose we’ll have to work with what we have."
                    "d" "Next time, professor."
        phone end discussion

    $ Evelyncafe = False

    if ('evelyn_contact' in vars() or 'evelyn_contact' in globals()) and evelyn_contact == True:
        d "I have that mysterious woman from the Palazio to contact..."
        call phone_discussion_evelyn from _call_phone_discussion_evelyn

    d "Let's take a look at my phone before the night..."

    $ redep5s1 = False
    $ juliaep5s1 = False

    if JuliaHopital == True:
        d "I could send a message to Julia and invite her to go drink something..."
        $ juliaphonep5intro = True
        $ globalnotif += 1
        $ appnotif += 1
    if redep4 == True:
        d "Red is maybe available..."
        $ redphonep5intro = True
        $ globalnotif += 1
        $ appnotif += 1









    if ('KiraPalazioShot' in vars() or 'KiraPalazioShot' in globals()) and KiraPalazioShot:
        $ addOnlystanComment(_("Damn, dude, you hit the jackpot! 🎉"), 5, "palazio_with_mc")
        $ addOnlystanComment(_("Seriously, this is like every guy’s dream. Well played! 😉"), 6, "palazio_with_mc")
        $ addOnlystanComment(_("How do you even get this lucky? I need some tips. 😏"), 7, "palazio_with_mc")
        $ addOnlystanComment(_("Bro, I’d trade my left shoe to be in your place. 🥲"), 8, "palazio_with_mc")
        $ addOnlystanComment(_("Lucky guy… some guys have all the luck! 👏"), 9, "palazio_with_mc")
    else:
        $ addOnlystanComment(_("Damn, dude, you hit the jackpot! 🎉"), 5, "palazio_without_mc")
        $ addOnlystanComment(_("Seriously, this is like every guy’s dream. Well played! 😉"), 6, "palazio_without_mc")
        $ addOnlystanComment(_("How do you even get this lucky? I need some tips. 😏"), 7, "palazio_without_mc")
        $ addOnlystanComment(_("Bro, I’d trade my left shoe to be in your place. 🥲"), 8, "palazio_without_mc")
        $ addOnlystanComment(_("Lucky guy… some guys have all the luck! 👏"), 9, "palazio_without_mc")



    $ addOnlystanPost(_("Just finished an intense core workout! Can’t wait to hear what you think. 💪🔥"), _("Core Power! 💥"), 2, "phone/assets/fannyonly4.jpg", "fanny_core_power", _("Looking strong, Fanny! I might need a few tips to keep up. 💪"))

    $ addOnlystanComment(_("I tried this workout, and now I can’t walk up the stairs. 😅"), 12, "fanny_core_power")
    $ addOnlystanComment(_("Maybe you should start with sitting on a couch first. 🤷"), 5, "fanny_core_power")
    $ addOnlystanComment(_("Oh, so now you’re a fitness expert, Ben? Let’s see you touch your toes. 😏"), 4, "fanny_core_power")
    $ addOnlystanComment(_("Guys, it’s not about touching toes, it’s about reaching for the snacks on the top shelf. 🥨"), 9, "fanny_core_power")
    $ addOnlystanComment(_("Pat’s got a point. The real workout starts when the bag of chips is just out of reach. 💪"), 8, "fanny_core_power")
    $ addOnlystanComment(_("Fanny, I need a video on the snack-reach drill. That’s my fitness level. 😂"), 11, "fanny_core_power")








show screen telephone()

label Choixtelep5s1:

    if globalnotif>0:
        show screen telephonenotif()
    if globalnotif==0:
        hide screen telephonenotif

    menu:
        "Pass":
            $ globalnotif = 0
            $ appnotif = 0
            jump fine5s1

label fine5s1:
    hide screen telephone
    hide screen telephonenotif
    d "Just have to wait..."
    stop music fadeout 2
    pause 1 
    scene black
    with fade
    pause 1 
    if redep5s1 == True:
        jump redep5s1
    if juliaep5s1 == True:
        jump juliaep5s1
    jump e5s2

label juliaphonep5intro:
    $ phone.menu = False
    phone discussion "julia1":
        time year 2023 month 9 day 9 hour 20 minute 15
        "d" "Hey! What are you doing tonight?"
        "julia" "I finish work in an hour."
        "d" "Oh? Still working?"
        "julia" "Yep! But I'm available after."
        "julia" "What do you have in mind?"
        "d" "You could show me a pub you like?"
        "julia" "Okay! Got one not far from my work!"
        "julia" "I’ll text you the address. 21:30 ok?"
        "d" "Cool, see you there."

    phone end discussion
    pause 1
    d "Perfect timing to have some quality time with her."
    $ juliaep5s1 = True
    $ juliaphonep5intro = False
    $ globalnotif -= 1
    $ appnotif -= 1
    jump Choixtelep5s1

label redphonep5intro:
    $ phone.menu = False
    phone discussion "red":
        time year 2023 month 9 day 9 hour 20 minute 20
        "d" "Hey! What are you doing tonight?"
        "beth" "Nothing. Why?"
        "d" "Wanna come to my room?"
        "beth" "What for?"
        "d" "Play Scrabble with me?"
        "beth" "Are you serious?"
        "d" "Come on! Having a hard time with Emerick and I could use some advice..."
        "beth" "You should have opened with that!"
        "beth" "I'll be there in 10 minutes."
        "d" "Oh okay. Perfect."

    phone end discussion

    "Next time: talk about Emerick directly..."

    pause 1
    $ redep5s1 = True
    $ redphonep5intro = False
    $ globalnotif -= 1
    $ appnotif -= 1
    jump Choixtelep5s1

label redep5s1:

    if _in_replay:
        show screen Replayexit
    pause 1
    play music "musique/MAS0454-Kulikar3-stockmusic-net.mp3" volume 0.2 fadein 2
    pause 1
    scene e5s1red1
    with fade
    pause 2
    scene e5s1red2
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s1red3
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s1red4
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene e5s1red5
    with dissolve
    beth "So this is where you’ve been hiding after playing the hero?"
    dpense "Beth. Always quick with the jabs."
    d "Not hiding. Just resting, that’s all."
    beth "Oh, sure. A noble knight always needs to catch his breath after saving a damsel in distress."
    d "If you’re just here to mock me, you can leave."
    scene e5s1red6
    with dissolve
    beth "Why leave when I can enjoy the show?"
    d "So that’s your idea of compassion?"
    beth "Compassion is for the weak. You need someone to remind you how to play the game without falling into the simplest traps."
    d "And what are you? Some master strategist? An expert in power games?"
    scene e5s1red7
    with dissolve
    beth "I am certainly better than you."
    beth "So, what really happened out there?"
    d "Emerick shoved Ruby into the street. If I hadn’t stepped in…"
    scene e5s1red8
    with dissolve
    beth "Of course you jumped in to save her. But Emerick never acts without reason."
    beth "Do you really think your little heroic act will be enough? Emerick’s not going to let this go, you know."
    dpense "She seems to know him more than I thought."
    d "What do you mean?"
    scene e5s1red9
    with dissolve
    beth "Emerick knows something like that could backfire on him. So if he acted, he had a plan."
    beth "The question is: why now?"
    d "I don’t know. I didn’t think about it. I just wanted Ruby out of danger."
    beth "And that’s exactly what he was counting on: an impulsive reaction."
    beth "You don’t get it, do you? Emerick’s not just some troublemaker. He’s calculated."
    beth "During the track championship, he falsified records, bribed officials, even pressured other competitors."
    beth "Anything to secure the win. And now, you’ve made yourself his new target."
    dpense "Falsifying records? Bribing officials? This guy will stop at nothing."
    dpense "So this is what I’m up against? A guy who’s playing a game I don’t even know the rules to..."
    d "And now he’s targeting me? Why? I’m nobody."
    beth "Not yet. But you’re something new, unexpected. And Emerick hates surprises."
    beth "You’re an unknown variable in his little plan."
    beth "That’s why he’s going to do everything he can to make you predictable, to put you in situations where he controls all the pieces."
    dpense "Predictable… So that’s his goal. He wants me to react exactly as he expects."
    d "So if I understand correctly, I have to do the opposite of what he expects."
    beth "Not just that. You have to surprise him. Do something he hasn’t anticipated. That’s how you’ll throw him off."
    scene e5s1red10
    with dissolve
    d "Why would he do that? He had nothing to gain tonight."
    beth "That’s the problem. He never does anything without a reason. Everything he does has a purpose."
    beth "And now, he knows you’re impulsive. You’re just another piece he can manipulate."
    dpense "A pawn? If that’s true, then I’m already behind."
    d "What am I supposed to do, then?"
    beth "Open your eyes. Watch his patterns. Emerick loves provoking people, making them react."
    beth "If you want to stand up to him, you need to understand his moves before he makes them."
    beth "And most importantly, stop charging in headfirst. That’s exactly what he wants."
    beth "Next time, think before you act. Take a step back and ask yourself: what does he gain by making you move?"
    d "So what do I do if I see he’s planning something again?"
    beth "Once you understand how he works, you can catch him off guard with something he won’t see coming."
    scene e5s1red11
    with dissolve
    beth "You’re frustrating to watch sometimes. You don’t even realize your own potential."
    d "And yet, it’s by being frustrating that I’m still here, holding my ground against you."
    scene e5s1red12
    with dissolve
    beth "Holding your ground? You’re barely putting up a fight. But it’s cute to see you try."
    d "Maybe that’s because I let you think you have the upper hand."
    scene e5s1red13
    with dissolve
    beth "Really? If that’s the case, prove it. Show me you can surprise me."
    d "And what if I said I’m ready to surprise you right now?"
    scene e5s1red14
    with dissolve
    beth "Then stop talking. Do it."
    scene e5s1red15
    with dissolve

    d "If I play by your rules… what do I get in return?"
    beth "You're never going to surprise me if you play by the rules."
    beth "You should ask what you’re risking instead of what you’re gaining. "
    d "And what if I’m willing to take that risk?"
    beth "Then take the risk. Do you always wait to be told what to do?"
    scene e5s1red16
    with vpunch
    d "Then let me show you I can."
    beth "That’s what I’m waiting for."
    d "I can do much more than talk."
    beth "Oh, I don’t doubt that. But that doesn’t mean I’ll make it easy for you."
    scene e5s1red17
    with vpunch
    d "I’m not looking for easy."
    beth "Good. Because you won’t get anything for free. If you want something, you’ll have to earn it."
    d "And what do I have to do to earn it?"
    scene e5s1red18
    with dissolve
    beth "First, show me you can keep your cool under pressure. Then prove you can keep up, wherever I lead you."
    d "Wherever you lead?"
    beth "Exactly. And remember, I expect nothing less than your best."
    scene e5s1red19
    with dissolve
    beth "You really think you’re ready to do whatever it takes to surprise me?"
    scene e5s1red20
    with dissolve
    d "Yes. And I’ll prove it."
    scene e5s1red21
    with dissolve
    beth "Hmm… interesting. But thinking you can is one thing. Doing it is another."
    scene e5s1red22
    with dissolve
    d "Then give me a chance."
    scene e5s1red23
    with dissolve
    beth "And what if you fail? Are you ready to pay the price?"
    d "I won’t fail."
    scene e5s1red24
    with dissolve
    beth "Really? You sound so confident. But I can see a flicker of doubt. Right there."
    scene e5s1red25
    with vpunch
    d "Look closer. I’m not hesitating."
    scene e5s1red26
    with dissolve
    beth "That’s what we’ll find out."
    scene e5s1red27
    with vpunch
    beth "You really thought you could surprise me? Look at you now... completely at my mercy."
    d "Maybe this is exactly where I wanted to be."
    beth "That's hardly a surprise."
    scene e5s1red28
    with hpunch
    beth "I'm in control here. The rhythm, the intensity... and you'll follow."
    d "Okay."
    beth "Not 'okay.' Yes, madame. Say it."
    d "Yes madame."
    scene redep5lewd1
    with dissolve
    beth "Good. Now show me."
    beth "You say you're ready to take risks. But words aren't enough. Say it differently."
    d "I'm ready."
    beth "Wrong, say it properly."
    d "Yes madame."
    scene redep5lewd2
    with vpunch
    beth "Good. Now prove it."
    stop music fadeout 2
    pause 1 
    scene black
    with fade
    pause 1 
    play music "musique/ENM0078-ShadesInstrumental-stockmusic-net.mp3" volume 0.2
    play movie "images/animation/redanim1ep5.webm" loop
    show movie
    ""
    beth "Not bad... but you can do better."
    d "I'll show you I can handle this."
    beth "I'm giving you a chance. Don't waste it."
    ""
    stop movie
    with dissolve
    scene black
    with dissolve
    pause 0.5
    scene redendep5s1i1
    with dissolve
    pause 1 
    scene redendep5s1i3
    with dissolve
    pause 1 
    scene redendep5s1i2
    with dissolve
    beth "Stay with me. Right now."
    with flash
    with hpunch
    scene redendep5s1i5
    pause 1
    with flash
    with hpunch
    scene redendep5s1i4
    with dissolve
    pause 1
    with vpunch
    with flash
    scene redendep5s1i6
    with dissolve
    beth "Not bad... for a start."
    scene redendep5s1i7
    with dissolve
    pause 1 
    scene redendep5s1i8
    with hpunch
    pause 2
    scene black
    with fade
    pause 1
    scene redendep5s1i9
    with dissolve
    pause 1 
    scene redendep5s1i10
    with dissolve
    pause 1
    beth "Remember what I said: nothing is ever guaranteed. Not with me."
    scene redendep5s1i11
    with dissolve
    pause 1 
    d "She's playing a different game... and I still don't know if I'm winning or losing."
    stop music fadeout 2
    scene black
    with fade
    pause 2
    $ RedPathe5 = True
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    $ CharacterBio.findCharacterByName("Elizabeth").hearts += 1
    if juliaep5s1 == True:
        jump juliaep5s1
    else:
        jump e5s2

label juliaep5s1:

    play music "musique/MAS0625-Reignite-stockmusic-net.mp3" volume 0.2 fadein 2
    scene juliae5s1i2
    with fade
    pause 2
    scene juliae5s1i1
    with dissolve
    pause 2 
    scene juliae5s1i3
    with dissolve
    pause 2 
    scene juliae5s1i4
    with dissolve
    pause 2 
    scene juliae5s1i5
    with dissolve
    d "Hey, Julia! I hope I didn’t keep you waiting."
    julia "Not at all. I just got here myself. Have a seat."
    scene juliae5s1i6
    with dissolve
    d "Thanks. This place is nice. I’ve walked past it a few times but never went in."
    julia "I come here now and then. It’s cozy, not too loud, and they have great beers. Plus, it’s close to work."
    d "Perfect. So, what’s good here?"
    scene juliae5s1i7
    with dissolve
    julia "Well, I suggest the house draught!"
    d "Okay I trust you. I’ll give it a shot."
    scene black
    with fade
    pause 1 
    scene juliae5s1i8
    with dissolve

    julia "So, what’s new with you? Any more crazy stories I should know about?"
    d "Well, something happened earlier that’s been on my mind."
    scene juliae5s1i9
    with dissolve
    julia "Oh? What’s going on?"
    d "It’s about Emerick. He pushed Ruby into the street. It was a close call."
    julia "Ruby? She’s okay, right?"
    d "Yeah, she’s okay now. But it really made me realize just how far he’ll go."
    scene juliae5s1i10
    with dissolve
    julia "That’s horrible. I can’t believe someone would go that far."
    scene juliae5s1i9
    with dissolve
    julia "What about you? Are you okay after all that?"
    d "I’m fine. It just… got me thinking about how to handle him next time."
    julia "You shouldn’t have to deal with someone like that alone. Maybe we can figure something out together."
    scene black
    with fade
    pause 1 
    scene juliae5s1i11
    with fade
    julia "So, we’ve talked a bit about my work. But what about you?"
    d "What about me?"
    julia "Well, I’ve been curious. You’re still a bit of a mystery to me."
    julia "What’s your family like? I feel like I don’t know much about where you come from."

    if persistent.patch_enabled == True:
        $ TEMP1 = e5s1j1c1
        $ TEMP2 = e5s1j1c2
        $ TEMP3 = e5s1j1c3
        $ TEMP4 = e5s1j1c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "I come from a military family.[TEMP1!t]":
            call sport_increased from _call_sport_increased_21
            scene juliae5s1i12
            with dissolve
            d "My family’s mostly military. Discipline, training, and never backing down. Those were the lessons growing up."
            julia "That must have been tough. Always living up to those expectations."
            d "It wasn’t always easy, but it definitely taught me how to handle challenges."
        "I come from a family of teachers.[TEMP2!t]":

            call education_increased from _call_education_increased_17
            scene juliae5s1i12
            with dissolve
            d "Teachers. Education was everything in my house. They valued learning and always encouraged me to ask questions."
            julia "That’s impressive. It must have been nice having people who believed in your potential."
            d "It had its moments, but the pressure to perform was real."
        "My family has always been my friends.[TEMP3!t]":

            call buddy_increased from _call_buddy_increased_23
            scene juliae5s1i12
            with dissolve
            d "I don’t really think of family in the traditional sense. My friends have always been my real family."
            julia "I get that. Sometimes the people you choose are the ones who matter most."
            d "Exactly. They’ve always had my back."
        "I’m self-made. My family never helped me much.[TEMP4!t]":

            call temperament_increased from _call_temperament_increased_22
            scene juliae5s1i12
            with dissolve
            d "I’ve had to figure out things on my own. My family didn’t give me much of a head start, so I’ve had to rely on myself."
            julia "That must have been hard, but it sounds like it made you strong."
            d "It did. I’m grateful for the lessons I’ve learned along the way."

    scene juliae5s1i11
    with dissolve
    julia "It’s interesting learning more about you. I feel like I’m starting to understand you better."
    d "Well, I guess I’m not such a mystery anymore."
    julia "Maybe not, but you’re still pretty intriguing."
    d "I could say the same about you."
    julia "I guess we’ll just have to keep learning about each other, one conversation at a time."
    scene juliae5s1i13
    with dissolve
    julia "You really think we can win it all? The tournament, the house… everything?"
    d "It’s possible. Winning isn’t just about skill. It’s about how we grow together as a team."
    d "And I feel like every match we’ve played has brought us closer."
    julia "I guess that’s true. You can really see how much everyone’s improved over time."
    julia "That house… it sounds almost too good to be true, doesn’t it? Like a dream we can’t quite reach."
    d "Maybe. But it’s the kind of dream that pushes us to be better. Sometimes it’s not just about the prize."
    d "It’s about how it shapes us along the way."
    scene juliae5s1i14
    with dissolve
    julia "And if we do win, living together in a place like that… it’d be strange at first, wouldn’t it?"

    if persistent.patch_enabled == True:
        $ TEMP1 = e5s1j2c1
        $ TEMP2 = e5s1j2c2
        $ TEMP3 = e5s1j2c3
        $ TEMP4 = e5s1j2c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "We’ll adjust and make it work.[TEMP1!t]":
            call buddy_increased from _call_buddy_increased_24
            scene juliae5s1i15
            with dissolve
            d "At first, it might be an adjustment. But I think it’ll teach us how to handle challenges and work through them together."
            julia "It’s comforting to hear that. It makes me feel more confident about the whole idea."
        "It’ll be a chance to grow.[TEMP2!t]":
            call education_increased from _call_education_increased_18
            scene juliae5s1i15
            with dissolve
            d "It’ll be an opportunity to learn from each other. We’ll be living under the same roof, sharing ideas and experiences."
            julia "I like the sound of that. We could all grow in ways we didn’t expect."
        "We’ll have a dedicated training base.[TEMP3!t]":
            call sport_increased from _call_sport_increased_22
            scene juliae5s1i15
            with dissolve
            d "It’ll be like having a personal training facility. We’ll have everything we need to stay sharp and prepared."
            julia "You’re always thinking about performance, huh? But you’re right. It’d be a huge advantage."
        "Living together will bring us closer.[TEMP4!t]":
            call temperament_increased from _call_temperament_increased_23
            scene juliae5s1i15
            with dissolve
            d "It’ll be fun. We’ll have our ups and downs, but I think it’ll bring us closer than ever."
            julia "Yeah, I can see that. It might be chaotic at times, but also really special."


    if kiraosinvite == True:
        scene juliae5s1i17
        with dissolve
        d "Hey, Julia, can I ask you something a bit random?"
        julia "Sure. What’s on your mind?"
        d "I, uh… just started an OnlyStan page. And since you’re here, I thought it’d be cool if we took a quick photo together. You know, to kick things off."
        scene juliae5s1i18
        with dissolve
        julia "Your first photo? Didn’t expect you to be the OnlyStan type. What’s your page even about?"
        d "Honestly, I made it mostly out of curiosity. Fanny and Kira are on it, and I thought I’d see what it’s all about."
        d "But I figured, why not use it for my own stuff? Something more casual."
        scene juliae5s1i19
        with dissolve
        julia "So, no content yet? This would be your very first post?"
        d "Yeah. I mean, I’m still figuring it out, but a photo with you would be a great start. Something simple, no pressure."
        scene juliae5s1i20
        with dissolve
        julia "Sure, why not?"
        scene juliae5s1i21
        with dissolve
        d "Let’s make it a good one."
        scene juliae5s1i22
        with hpunch
        play sound "sound/Photo.mp3"
        with flash
        d "Wow!"
        dpense "Perfect. That’s going to look great on my page."
        julia "Well, you’re off to a strong start. Think you’ll keep it going?"
        d "We’ll see. Who knows? Maybe you’ll start one too."
        scene juliae5s1i21
        with dissolve
        julia "Not so fast. Let’s see if yours is even worth following first."

        $ addOnlystanPost(_("My first post made with a new friend ;)"), _("A good evening in good company:)!"), 1, "phone/assets/juliamcos1.jpg", "julia_1")
        scene black
        with fade
        pause 1

    scene juliae5s1i16
    with dissolve
    julia "It's already late. I have to go."
    d "Let me come with you. I don't want you running into any trouble."
    julia "Okay. Thank you."
    scene juliae5s1i23
    with dissolve
    pause 2
    stop music fadeout 2
    scene black
    with fade
    pause 2
    play music "musique/MAS0427-ItWasLoveYesterday-stockmusic-net.mp3" volume 0.2 fadein 2
    scene juliae5s1i24
    with fade
    pause 1 
    scene juliae5s1i25
    with dissolve
    julia "Thanks for walking me home. It’s been a long time since I had a night like this."

    if persistent.patch_enabled == True:
        $ TEMP1 = e5s1j2c1
        $ TEMP2 = e5s1j2c2
        $ TEMP3 = e5s1j2c3
        $ TEMP4 = e5s1j2c4
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
        $ TEMP3 = ""
        $ TEMP4 = ""

    menu:
        "It was great spending time with you.[TEMP1!t]":
            call buddy_increased from _call_buddy_increased_25
            d "It was great spending time with you. I hope we can do this again soon."
            julia "Me too. I feel more relaxed now, thanks to you."
        "I feel like I know you better now.[TEMP2!t]":
            call education_increased from _call_education_increased_19
            d "It was great talking. I feel like I understand you better now."
            julia "That’s sweet. I learned a lot about you tonight, too."
        "I’m looking forward to the next match.[TEMP3!t]":
            call sport_increased from _call_sport_increased_23
            d "I’m looking forward to the next match. It’ll be great knowing we’re working toward something this big together."
            julia "It’s reassuring knowing you’re so focused. I’ll try to keep up!"
        "It’s nice to feel at ease with you.[TEMP4!t]":
            call temperament_increased from _call_temperament_increased_24
            d "It’s been a while since I’ve felt this at ease. I’m really glad we did this."
            julia "Me too. I feel the same."


    scene juliae5s1i26
    with dissolve
    pause 1 
    scene juliaanim1pre1
    with dissolve
    pause 1 
    scene juliaanim1pre2
    $ renpy.movie_cutscene("images/animation/animjulia1e5s1a.webm", stop_music=False)
    scene juliaanim1pre2
    with dissolve
    pause 1 
    scene juliaanim1pre3
    with dissolve
    pause 1 
    scene juliaanim1pre4
    $ renpy.movie_cutscene("images/animation/animjulia2e5s1.webm", stop_music=False)
    scene juliaanim1pre4
    with dissolve
    pause 1 
    scene juliae5s1i27
    with hpunch
    pause 2
    scene juliae5s1i28
    with dissolve
    d "This feels right..."
    julia "Yeah... Not a stolen one this time."
    scene juliae5s1i29
    with dissolve
    d "Goodnight, Julia."
    $ CharacterBio.findCharacterByName("Julia").hearts += 1
    scene juliae5s1i30
    with dissolve
    julia "Goodnight, [name]."
    $ JuliaPathe5 = True
    stop music fadeout 2
    scene black
    with fade
    pause 2

    jump e5s2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
