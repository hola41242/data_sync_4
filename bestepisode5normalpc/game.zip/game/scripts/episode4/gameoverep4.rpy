label gameoverep4:
    scene gameover
    with fade
    orushi "Unfortunately, you didn't succeed in passing all the trials, [name]..."
    orushi "It's disappointing..."
    orushi "Well, next time... Try to make some better choices!"
    $ Achievement.add(achievement_gameover)
    $ achievement.grant("gameover")
    $ achievement.sync()
    "Fshhhhhhhhhh!!!!"
    scene black
    with fade
    pause 1

    "Same player shoots again!"

    $ Rank = originalrank
    jump preepreuveep4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
