label rubypown:
    scene expression MastermindPlace.currentPlace.img with dissolve
    ruby "Oh, is this a mastermind puzzle?!"
    ruby "I love these! Let me do it!"
    dpense "She cracks the mastermind in two seconds flat..."
    jump masterepreuveep4

label masterepreuveep4:



    pause 1

    if g_time < 900:
        "You finished first, your B.E.S.T rank will be updated accordingly."
        $ Rank = Rank / 2
        jump resultatep4

    if g_time > 900:
        if g_time < 1000:
            "Your team finished in second place, your B.E.S.T rank will be updated accordingly."
            $ Rank = (Rank / 2) + 2
            jump resultatep4

        if g_time < 1201:
            "Your team finished in 5th place, your B.E.S.T rank will be updated accordingly."
            $ Rank = int(Rank - 1)
            if grace_fin == True:
                if Rank > 20:
                    $ Rank = 20
            jump resultatep4

        if g_time < 2000:
            "Your team finished in 14th place, your B.E.S.T rank will be updated accordingly."
            $ Rank = int(Rank + 5)
            if grace_fin == True:
                if Rank > 20:
                    $ Rank = 20
            jump resultatep4

        if g_time > 1999:
            "Time is up! your B.E.S.T rank will be updated."
            $ Rank = int(Rank + 10)
            if grace_fin == True:
                if Rank > 20:
                    $ Rank = 20
            jump resultatep4

label emericktrialep4:

    $ emerick_win = True

    "Announcement to all participants:"
    "The first duo to win the challenge is:"
    "Emerick's team."
    dpense "Damn it... Him again..."


    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())

label gracefintrialep4:
    $ grace_fin = True
    "Buzz buzz"
    grace "I got a message from my mom."
    d "Really?"
    grace "Yeah. She just gave me the code."
    grace "Let's go to the auditorium."
    d "Okay."
    grace "Here we are!"
    dpense "It's a bit of cheating, but oh well..."
    dpense "I guess Mrs. Drew is willing to do anything to make sure her daughter succeeds."
    jump masterepreuveep4

label callmap:



    call screen mastermind_map

label rienDansCettePiece:
    scene expression MastermindPlace.currentPlace.img with None
    "Looks like there's nothing here."
    $ roomAlertSeen = True
    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())

label rienDansCetObjet:
    scene expression MastermindPlace.currentPlace.img with None
    d "I didn't find anything."
    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())

label plusRienDansCetObjet:
    scene expression MastermindPlace.currentPlace.img with None
    d "There's nothing left to find here..."
    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())

transform animatedFoundBall:
    xalign 0.5
    yalign 0.5
    linear 0.3 zoom 2.0
    linear 0.7 zoom 2.7
    linear 0.7 zoom 1.7
    repeat

label trouveUnObjet:
    scene expression MastermindPlace.currentPlace.img with None
    d "Oh, I found something!"
    $ ballImgName = "phone/assets/mastermind_best/mastermindballs/mastermindwhiteball" + str(currentFoundObject.linkedNumber) + ".png"
    show expression ballImgName at animatedFoundBall
    d "The number I found is [currentFoundObject.linkedNumber]"
    hide expression ballImgName
    if areFound3Hints() and bonus_hint:
        play sound "sound/vibration.mp3"
        "buzz buzz" with hpunch
        julia "Oh, I got a message from Ruby."
        julia "She found a number we don't have! It's [str(getNotFoundObject().linkedNumber)]!"
        julia "All that's left is to go back to the auditorium."
        python:
            for elt in mastermindRandomObjects:
                elt.find()
    "There is nothing else to find here"
    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())



label changerPiece:
    scene expression MastermindPlace.currentPlace.img with dissolve

    if (MastermindPlace.currentPlace.chosenRandomObjectHere() == False) and MastermindPlace.currentPlace.id != mastermindPlaces[4].id:
        "There is nothing to find here"
    elif MastermindPlace.currentPlace.id != mastermindPlaces[4].id and MastermindPlace.currentPlace.chosenRandomObjectHere().isFound:
        "There is nothing else to find here"
    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
