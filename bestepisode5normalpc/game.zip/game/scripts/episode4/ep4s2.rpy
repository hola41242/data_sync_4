label ep4s2:
    scene black
    with fade
    pause 2
    play music "musique/MAS4685-Feel-GoodCinematicHope-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep3s1r4
    with dissolve

    dpense "Well..."
    dpense "Another day in the books."
    dpense "Check my phone real quick before I go to sleep."
    dpense "Gotta stay sharp for tomorrow."
    dpense "Still no news from Elise."
    dpense "That's unusual..."
    dpense "Hope she's doing okay..."


    python:
        for elt in onlystanComments:
            if elt.isMCComment:
                for eltPosts in onlystanPosts:
                    if eltPosts.id == elt.postID:
                        eltPosts.commentSent = True


    $ gracephonep4inter = False
    $ bluephonep4inter = False


    if Gracepath == True:
        $ gracephonep4inter = True
        $ globalnotif += 1
        $ appnotif += 1


    if bluelove == True:
        $ bluephonep4inter = True
        $ globalnotif += 1
        $ appnotif += 1





    show screen telephone()
    jump roommcep4

label roommcep4:
    if globalnotif>0:
        show screen telephonenotif()
    if globalnotif==0:
        hide screen telephonenotif
    menu:
        "Pass":

            $ gracephonep4inter = False
            $ bluephonep4inter = False
            $ globalnotif = 0
            $ appnotif = 0
            hide screen telephone
            hide screen telephonenotif
            pause 1 
            if kiraosinvite == True:

                play sound "sound/vibration.mp3" volume 1
                with hpunch
                d "Hmm?"
                call phone_discussion_kira from _call_phone_discussion_kira
            scene black
            with fade
            stop music fadeout 2
            pause 3
            $ rubytelpretrial = True
            jump ep4s3i

label gracephonep4inter:
    $ phone.menu = False
    phone discussion "grace1":
        time year 2023 month 9 day 6 hour 22 minute 00
        "d" "Hey, still awake?"
        "grace" "For you? Always. :)"
        "d" "I couldn't end the day without talking to you."
        "grace" "You're such a sweetheart. I missed you today."
        "d" "I missed you too. Feels like something was missing all day."
        "grace" "Same here. But hearing from you now makes up for it."
        "d" "Good. I was worried I might’ve been the only one feeling like that."
        "grace" "Never. You’re stuck with me now, remember?"
        "d" "Wouldn’t want it any other way."
        "grace" "Me neither."
        "d" "Alright, I’ll let you get some rest now. Sweet dreams, my girl."
        "grace" "Sweet dreams, my guy. Sleep well. <3"
    phone end discussion
    pause 1
    $ globalnotif -= 1
    $ appnotif -= 1
    $ gracephonep4inter = False
    jump roommcep4

label bluephonep4inter:
    $ phone.menu = False
    phone discussion "sofia1":
        time year 2023 month 9 day 6 hour 22 minute 05
        "d" "Hey, Sofia. Missed me today?"
        "sofia" "Maybe... Or maybe I was just busy thinking about last night. ;) "
        "d" "Oh? The part where you couldn’t keep your balance?"
        "sofia" "Please. You’re the one who couldn’t resist. That bathroom got... steamy fast."
        "d" "Can you blame me? You’re hard to resist."
        "sofia" "Good answer. Let’s just say I’ve been replaying that moment in my head all day."
        "d" "Now I’m replaying it too. Thanks for that."
        "sofia" "You're welcome. But let’s switch gears before this conversation gets too hot."
        "sofia" "I have a surprise for you!"
        "d" "What? What kind of surprise?"
        image "sofia" "phone/assets/newblue.png"
        "d" "WoW! It fits you so well!"
        "sofia" "Ahah! Thank you!"
        "sofia" "My sister knows about us, you know."
        "d" "Wait, Elisabeth? How?"
        "sofia" "She has her ways. Plus, she knows there’s an event tomorrow."
        "sofia" "She’s convinced it’ll be an elimination round."
        "d" "Elisabeth always has the inside scoop, doesn’t she?"
        "sofia" "Of course. She loves to be in control. Don’t let her intimidate you tomorrow, okay?"
        "d" "You worried about me?"
        "sofia" "Maybe. But I know you’ll handle it. Just don’t let her play her games with you."
        "d" "Got it. Thanks for the heads-up, Sofia."
        "sofia" "Don’t thank me yet. I might need another... Private moment to stay motivated. You know, like last night."
        "d" "Careful, or I might call your bluff."
        "sofia" "Bluff? Who said I was bluffing? Goodnight, [name]. Sweet dreams. ;) "
        "d" "Goodnight, Sofia. Don’t dream too much about me."
        $ wallpapers.append("phone/assets/newblue.webp")
        $ renpy.notify (_("A wallpaper has been added"))
    phone end discussion
    pause 1
    $ globalnotif -= 1
    $ appnotif -= 1
    $ bluephonep4inter = False
    dpense "I hope she'll be okay tonight..."
    jump roommcep4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
