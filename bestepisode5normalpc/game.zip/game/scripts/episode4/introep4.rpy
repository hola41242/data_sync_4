label introep4:

    $ Episode4 = True
    if madidiner == True and madipath == False:
        $ Redpath = True
    if rubytrial == True:
        $ chosen = "Ruby"
    if juliatrial == True:
        $ chosen = "Julia"
    if gracetrial == True:
        $ chosen = "Grace"
    if madtrial == True:
        $ chosen = "Madison"




    stop music fadeout 2
    pause 2
    scene black
    play sound "sound/tirlong.wav" volume 1
    show introep41 at top
    with dissolve
    play music "musique/Keys_of_Moon_-_The_Success.mp3" volume 0.2 fadein 2
    pause 7
    ruby "Hey! Hi there!"
    ruby "As the competition heats up and only 40 participants remain, let's look back on the incredible journey of our hero: [name]!"
    show introep41 at topleft
    with move

    show i51i4 behind introep41 with dissolve:
        xsize 1400
        ysize 800
        xalign 0.95
        yalign 0.1
    ruby "It's been a wild ride so far, hasn't it? From the first obstacle course, where [name] and [chosen] showed true grit, to acing the second challenge with a score of [score] out of 10!"
    ruby "Quite impressive work, [name]! You've done well to be one of the remaining forty competitors, in [Rank] place."
    show introep42 at topleft
    with dissolve
    if Redpath and bethfk == True and Refusek == False:
        show j22i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "Oh, and let's not forget that moment with Red in the locker room... Sparks were flying! Those two definitely have a connection."
    if madipath:
        show finmad8i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "And who could forget the steamy shower scene with Madison? Things are getting interesting there..."
    if bluelove:
        show free21blue4i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "There is Blue... Exploring new depths together, huh? Those moments were unforgettable."
    if Gracepath:
        show gracefinep312i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "And Grace... What a night that was. It ended on such a high note with her."
    show ep3s4r8i4 behind introep42 with dissolve:
        xsize 1400
        ysize 800
        xalign 0.95
        yalign 0.1
    ruby "But now, the stakes are higher than ever. The next challenge is just around the corner, and it's against none other than Steven's team!"
    ruby "I don't know about you, but I'm on the edge of my seat just thinking about it! This match is going to be epic!"
    ruby "But before we get there, our hero has some important decisions to make. What will he do next?"

    if gabimusee:
        show ep3s3r17i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "Will he spend some quality time with Gabriella at the museum, perhaps finding inspiration among the art?"
    if JuliaHopital:
        show free23julia21i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "Will he be by Julia's side at the hospital, supporting her as she visits her mother in this tough time?"
    if madidiner:
        show ep3s2br15i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "Maybe will he join Madison for dinner with her father. That could be an interesting evening, to say the least."
    else:
        show ep3s4r13i4 behind introep42 with dissolve:
            xsize 1400
            ysize 800
            xalign 0.95
            yalign 0.1
        ruby "Perhaps he'll focus on preparing for the next challenge, sharpening his skills for what's to come."

    ruby "With the competition speeding up and all these relationships to manage, I can't help but wonder how [name] will handle everything. The pressure is mounting, and every decision counts."
    show endorushiep3i4 behind introep42 with dissolve:
        xsize 1400
        ysize 800
        xalign 0.95
        yalign 0.1
    ruby "I really hope [name] can rise to the occasion in the next challenge Orushi has prepared for us. It's not going to be easy, but if anyone can do it, it's him!"
    ruby "I'm so excited to see how this all plays out! The anticipation is killing me! But for now, I'll leave you to it. Good luck!"
    stop music fadeout 1
    scene black
    with dissolve
    pause 2
    play sound "sound/WhooshEpic.mp3" volume 2 
    show text _ ("EPISODE 4") at truecenter
    with dissolve
    pause 2 
    hide text with dissolve
    pause 1
    show text _ ("ACCELERATION") at truecenter
    with dissolve
    pause 2 
    hide text with dissolve
    pause 2
    hide text with dissolve
    pause 2
    play music "musique/MAS4685-Feel-GoodCinematicHope-stockmusic-net.mp3" volume 0.2 fadein 2
    scene animmcep4
    with fade
    pause 0.5 
    scene mcopen4
    $ renpy.movie_cutscene("images/animation/mcopen4.webm", stop_music=False)
    scene mcopen4
    with dissolve
    $ madicarsex = False
    $ gracephonep4intro = False
    $ juliaphonep4intro = False
    $ rubyphonep4inter = False
    $ juliaphonep4inter = False
    $ globalnotif = 0
    $ appnotif = 0
    $ onlystanNotif = 0
    $ kiraosinvite = False
    $ KiraPalazio = False
    if kiradiscuss20 == False:
        $ kiraosinvite = True

    $ phoneTheme = "#8cb5ef"


    play sound "sound/vibration.mp3" volume 1
    "Update of your phone version..."
    "Notifications have been enabled..."
    "New apps has been installed..."


    $ characterBios= []
    $ init_bios()

    if Episode4 == True:
        if ('Redpath' in vars() or 'Redpath' in globals()) and Redpath == True:
            $ CharacterBio.findCharacterByName("Elizabeth").hearts = 1
        if ('bluelove' in vars() or 'bluelove' in globals()) and bluelove == True:
            $ CharacterBio.findCharacterByName("Sofia").hearts = 4
        if ('Gracepath' in vars() or 'Gracepath' in globals()) and Gracepath == True:
            $ CharacterBio.findCharacterByName("Grace").hearts = 4
        if ('JuliaHopital' in vars() or 'JuliaHopital' in globals()) and JuliaHopital == True:
            $ CharacterBio.findCharacterByName("Julia").hearts = 2
        if ('CharlottePath' in vars() or 'CharlottePath' in globals()) and CharlottePath == True:
            $ CharacterBio.findCharacterByName("Charlotte").hearts = 2
        if ('madipath' in vars() or 'madipath' in globals()) and madipath == True:
            $ CharacterBio.findCharacterByName("Madison").hearts = 2

    if Gracepath == True:
        $ gracephonep4intro = True
        $ globalnotif += 1
        $ appnotif += 1

    if JuliaHopital == True:
        $ juliaphonep4intro = True
        $ globalnotif += 1
        $ appnotif += 1

    if gabimusee == True:
        $ gabyphonep4intro = True
        $ globalnotif += 1
        $ appnotif += 1









    python:

        for elt in onlystanPosts:
            if elt.image == "phone/assets/polep412.webp" or elt.image == "phone/assets/miratest2.jpg":
                onlystanPosts.remove(elt)

        onlystanPosts = [x for x in onlystanPosts if x.id <= 3]


        for elt in onlystanPosts:
            elt.commentSent = False
        onlystanComments = [x for x in onlystanComments if not x.isMCComment]
        for index, elt in enumerate(onlystanComments):
            if elt.isMCComment:
                del onlystanComments[index]

    $ renpy.retain_after_load()





    if kiraosinvite == True:
        $ onlystanNotif = 1
        "You have received an invitation to install OnlyStan."
        "Do you want to install it?"
        if persistent.patch_enabled == True:
            $ TEMP1 = ep4007
        else:
            $ TEMP1 = ""

        menu:
            "Yes[TEMP1!t]":
                $ kiraosinvite = True
                "Application installed, please check your information..."
                d "Hmm, must be Kira..."
                "Enter a username :"
                $ nickname = renpy.input(_('Your Username?') or 'Dorian')
                $ nickname = nickname.strip()


                d "Okay, let's check this application."
            "No":

                $ kiraosinvite = False
                d "Don't want to have more things on my phone."

    show screen telephone()


label Choixtelintroep4:

    if globalnotif>0:
        show screen telephonenotif()
    if globalnotif==0:
        hide screen telephonenotif

    menu:
        "Pass":










            $ gracephonep4intro = False
            $ juliaphonep4intro = False
            $ gabyphonep4intro = False
            $ globalnotif = 0
            $ appnotif = 0
            jump finintroep4

label finintroep4:

    hide screen telephone
    hide screen telephonenotif

    pause 1
    scene black
    with dissolve

    pause 2

    $ JuliaHint = False
    $ GabyHeat = False
    $ MadiDef = False

    if JuliaHopital == True:
        stop music fadeout 2
        jump ep4s1a
    if gabimusee == True:
        stop music fadeout 2
        jump ep4s1b
    if madidiner == True:
        stop music fadeout 2
        jump ep4s1c
    else:
        stop music fadeout 2
        jump ep4s1d

label gracephonep4intro:
    $ phone.menu = False
    phone discussion "grace1":
        time year 2023 month 9 day 6 hour 10 minute 00
        "d" "Awake?"
        "grace" "Yeah, bit of a headache but I'm fine."
        "d" "'I had fun at the party, thanks for bringing me."
        "grace" "I had fun too! It was over too soon."
        "d" "You don't regret how it ended?"
        "grace" "Regret? Are you insane? It was marvelous."
        "grace" "It was the best night of my life!"
        "grace" "You actually make time for me, listen to what I say..."
        "grace" "I never felt so respected by a man..."
        "grace" "My man?"
        "d" "Your man."
        image "grace" "phone/assets/gracephonekiss.webp"
        "grace" "Have to go. See you later!"
        "d" "See ya!"    
    phone end discussion
    pause 1
    $ gracephonep4intro = False
    $ globalnotif -= 1
    $ appnotif -= 1
    $ wallpapers.append("phone/assets/gracephonekiss.png")
    $ renpy.notify (_("A wallpaper has been added"))
    jump Choixtelintroep4

label juliaphonep4intro:
    $ phone.menu = False
    phone discussion "julia1":
        time year 2023 month 9 day 6 hour 10 minute 00
        "d" "Hey! Do you still want me to come with you to the hospital?"
        "julia" "If you don't mind..."
        "d" "No, no, not at all."
        "julia" "Great! I'm heading there soon."
        "julia" "Should we meet out front?"
        "d" "Alright! See you in a bit!"
        "julia" "See you soon!"

    phone end discussion
    pause 1
    $ juliaphonep4intro = False
    $ globalnotif -= 1
    $ appnotif -= 1
    jump Choixtelintroep4

label gabyphonep4intro:
    $ phone.group_chat.group_chat("gaby1").add_character(["gaby", "d"])
    $ phone.menu = False
    phone discussion "gaby1":
        time year 2023 month 9 day 6 hour 10 minute 00
        "d" "Awake and ready to meet up with you!"
        "gaby" "What part of 'only in case of emergency' do you not understand?"
        "d" "Hey, it was just so you wouldn’t worry."
        "gaby" "I wasn't worried."
        "d" "I'm not gonna miss our date either!"
        "gaby" "It's not a date!"
        "d" "Yeah, yeah!"
        "gaby" "Just be on time."
        "d" "Yes, ma'am!"
    phone end discussion
    pause 1
    $ gabyphonep4intro = False
    $ globalnotif -= 1
    $ appnotif -= 1
    jump Choixtelintroep4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
