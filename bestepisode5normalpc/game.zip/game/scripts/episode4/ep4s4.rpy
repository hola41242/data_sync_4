label ep4s4:

    $ config.rollback_enabled = True

label resultatep4:
    scene black
    with fade
    $ in_mini_game = False
    call saving (True) from _call_saving
    $ Madisonrank1 = False

    show aprestablet_text _ ("Your new rank is :")
    with fade
    pause 2

    if notrialep4 == True:
        $ Rank = 20

    if Rank%2 == 0:
        $ Rank = Rank
    else:
        $ Rank = int(Rank-0.5)

    if Rank < 1:
        $ Rank = 1

    if Rank > 40:
        $ Rank = 40

    if chosentrial == "Madison":
        if Rank == 1:
            $ Madisonrank1 = True
            $ Rank = 2
        else:
            $ Madisonrank1 = True
            $ Rank = Rank

    $ Rank = int(Rank)

    hide aprestablet_text
    with fade
    pause 1
    show aprestablet_text "[Rank]" with fade
    pause 3
    hide aprestablet_text
    with fade
    stop music fadeout 2
    pause 2

    if Rank > 20:
        jump gameoverep4
    else:
        jump postepreuvep4

label postepreuvep4:
    $ config.rollback_enabled = True
    $ renpy.block_rollback()
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" volume 0.2
    if Rank == 1:
        $ Achievement.add(achievement_best)
        $ achievement.grant("best")
        $ achievement.sync()
        scene postepreuveep4r1
        with vpunch
        d "Yeah!!!! I did it! I'm the B.E.S.T!"
        scene postepreuveep4r2
        with dissolve
        ruby "Haha! I knew it! I was right to believe in you from the start!"
        ruby "My instincts never fail me!"
        scene postepreuveep4r3
        with dissolve
        d "Thanks, Ruby!"
        scene postepreuveep4r4
        with dissolve
        grace "Congratulations!"
        mad "Yeah. Congrats."
        d "Don't make that face, Madison! You'll have your chance in the next challenges!"
        scene postepreuveep4r5
        with dissolve
        mad "Oh, you bet I will."
        mad "I'm not letting anyone else take that spot from me!"
        d "You'll have to beat me first!"
        scene postepreuveep4r6
        with dissolve
        mad "Humpfff..."
        scene postepreuveep4r7
        with dissolve
        julia "Don't worry. She's just a bit of a sore loser, but she'll get over it."
        ruby "Yeah, and I think deep down, she's actually happy!"
        d "What do you mean?"
        ruby "Well, you beat Emerick! And nothing makes her happier than seeing him taken down."
        jump finpart1ep4

    if Rank > 1:
        if emerick_win and Madisonrank1 == False:
            scene postepreuveep4r8
            with vpunch
            emerick "Come on, who's the best?"
            scene postepreuveep4r6
            with dissolve
            mad "Damn it! Always showing off, aren't you?"
            ruby "Well, to be fair, he is pretty strong."
            scene postepreuveep4r9
            with hpunch
            mad "Ruby! You're supposed to be on my side!" with hpunch
            ruby "I'm just saying! No need to punch me!"
            mad "Ugh, whatever. Next time, I'll crush him!"
            d "Looking forward to it!"
            jump finpart1ep4

        if Madisonrank1 == True and emerick_win == False:
            $ Achievement.add(achievement_madibest)
            $ achievement.grant("madibest")
            $ achievement.sync()
            scene postepreuveep4r10
            with dissolve
            pause 2 
            scene postepreuveep4r11
            with vpunch
            mad "Finally!" with hpunch
            ruby "What?"
            mad "I'm number one!"
            mad "Haha!"
            scene postepreuveep4r12
            with dissolve
            mad "I'm so happy!"
            d "Congrats!"
            mad "Thanks!"
            scene postepreuveep4r13
            with dissolve
            mad "That jerk must be devastated to have lost his crown!"
            ruby "Now you just have to keep it!"
            mad "Oh, I plan to!"
            scene postepreuveep4r14
            with dissolve
            dpense "Hmm... There's gonna be a problem though."
            dpense "I'll have to win at some point."
            scene postepreuveep4r15
            with dissolve
            dpense "When that day comes, Madison, we'll be rivals."
            scene black
            with fade
            pause 1
            jump finpart1ep4

label finpart1ep4:
    if bonus_places == True:
        scene postepreuveep4r16
        with dissolve
        sofia "We've made it!"
        d "Ahah yeah!"
    scene postepreuveep4r17
    with dissolve
    julia "Well done everybody!"
    grace "Anyway, you all fought really hard! We're all still in the race."
    grace "And now there are only 20 of us left!"
    scene postepreuveep4r18
    with dissolve
    ruby "The end is near!"
    julia "This wore me out. I'm going to get some rest."
    ruby "Yeah, same here. And we still have tomorrow's match."
    $ graceep4 = False
    $ blueep4 = False
    $ redep4 = False
    $ Redphone = False

    if bluelove == True:
        scene postepreuveep4r16
        with dissolve
        sofia "Do you want to come over tonight?"
        d "Where?"
        sofia "My place."
        scene postepreuveep4r20
        with dissolve
        d "Oh? Uh..."
        if persistent.patch_enabled == True:
            $ TEMP1 = ep4008
        else:
            $ TEMP1 = ""

        menu:
            "Of course![TEMP1!t]":
                scene postepreuveep4r21
                with dissolve
                d "Yes, absolutely!"
                sofia "Great! Come by around 8 PM."
                sofia "Uh... Do you know where we live?"
                d "In Madison's neighborhood, right?"
                sofia "Yeah, just behind it."
                d "I’ll find it."
                sofia "Send me a message when you're nearby, and I’ll come get you."
                scene postepreuveep4r22
                with dissolve
                d "And your sister?"
                sofia "What about her?"
                d "Well... Won't she say something?"
                sofia "She has nothing to say."
                sofia "And honestly, I think she’ll be happy that you’re with me."
                d "Why’s that?"
                scene postepreuveep4r23
                with dissolve
                sofia "Even though we’re different, we’re still twins!"
                sofia "So, we’re... connected!"
                sofia "Which means I think she wants what’s best for me."
                scene postepreuveep4r24
                with dissolve
                sofia "And with you..."
                sofia "I feel good."
                sofia "You know, Elisabeth might not say it, but she does care about me."
                d "Really? She doesn’t show it much."
                sofia "Yeah, she’s not the type to express it openly, but I can feel it. Twin connection, you know?"
                d "Must be nice to have that."
                scene postepreuveep4r25
                with dissolve
                sofia "It is. And right now, I feel like you’re part of that connection too."
                mad "*clears throat* Hum! Hum!" with vpunch
                dpense "Oh..."
                scene postepreuveep4r21
                with dissolve
                d "Alright then, it’s settled. 8 PM at your place!"
                sofia "Perfect!"
                $ blueep4 = True
            "I’ve got other things to do.":
                scene postepreuveep4r19
                with dissolve
                d "Sorry, but I’ve already got plans this afternoon."
                d "And with tomorrow’s match, I think I should stay in top shape."
                sofia "Oh? Alright..."
                sofia "Well, see you later then?"
                d "Yeah."
                pause 1

    if bonus_objects == True:
        scene postepreuveep4r26
        with dissolve
        beth "Well done, Frenchie."
        d "You weren’t too bad yourself."
        d "But I still wonder where you get all your info..."
        d "You seem to know everything before anyone else."
        scene postepreuveep4r27
        with dissolve
        beth "Oh, that’s simple."
        beth "I have compromising stuff on one of the Orushi staff members."
        beth "So either he gives me the intel he has on the challenges they’re setting up..."
        beth "Or I show his wife what he’s been up to with Emerick’s mom."
        scene postepreuveep4r28
        with dissolve
        d "Emerick’s mom?"
        beth "Yeah. She tends to go out a lot and let loose when she’s in good company."
        d "Uh... Does he know?"
        beth "Who? Emerick?"
        d "Yeah."
        scene postepreuveep4r13
        with dissolve
        beth "Nah. The guy can’t see past his own nose."
        beth "We’re not expecting him to notice anything around him."
        d "But isn’t he your ally?"
        beth "Emerick? An ally?"
        beth "He’s a lapdog."
        beth "I keep him around and let him do his little tricks to keep the Orushi on my side."
        scene postepreuveep4r29
        with dissolve
        d "Oh? And Kira?"
        beth "Nah... That’s a whole different level. We avoid crossing paths."
        dpense "Interesting..."
        beth "Anyway. Here’s my number so we can communicate more easily."
        $ renpy.notify (_("NEW CONTACT ADDED"))
        $ Redphone = True
        scene postepreuveep4r30
        with dissolve
        d "Wow! The great Elisabeth is giving me her number!"
        d "Should I feel honored?"
        beth "Don’t make me regret it, [name]."
        d "Okay, I’m just kidding."
        beth "Text me tonight."
        d "Uh... If you want."
        $ redep4 = True
        scene postepreuveep4r22
        with dissolve
        pause 1 

    if Gracepath == True:
        scene postepreuveep4r31
        with dissolve
        grace "Do you want to hang out with me this afternoon?"
        grace "I'll be home alone until my mom gets back."

        if persistent.patch_enabled == True:
            $ TEMP1 = ep4006
        else:
            $ TEMP1 = ""

        menu:
            "Of course![TEMP1!t]":
                scene postepreuveep4r32
                with dissolve
                d "Yeah, sure!"
                grace "Great! Let's walk together!"
                $ graceep4 = True
            "No, thanks.":
                scene postepreuveep4r33
                with dissolve
                d "I think I'll go train a bit for tomorrow."
                grace "Yeah, I understand."
                grace "I'll see you tomorrow then."
                d "Perfect."

    scene postepreuveep4r34
    with dissolve
    d "Alright, see you tomorrow, girls!"
    ruby "See you tomorrow!"
    julia "See you!"
    scene black
    with fade
    pause 2
    if graceep4 == True:
        jump ep4p2s1
    if blueep4 == True:
        jump ep4p2s2
    if KiraPalazio == True:
        jump ep4p2s2bis
    else:
        jump ep4p2s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
