label ep4p2s2bis:

    $ KiraPalazioShot = False
    $ evelyn_contact = False
    $ chatextmass = False
    stop music fadeout 2
    pause 2 
    play music "musique/JOL0106-GetDown-stockmusic-net.mp3" volume 0.5 loop
    scene black
    with fade
    scene kiraep45
    with fade
    pause 1
    scene kiraep44
    with fade
    pause 1
    scene kiraep41
    with fade
    pause 1
    play sound "sound/Photo.mp3" volume 1
    with flash
    scene kiraep42
    with fade
    pause 1 
    play sound "sound/Photo.mp3" volume 1
    with flash
    scene kiraep43
    with fade
    pause 1
    play sound "sound/Photo.mp3" volume 1
    with flash
    scene kiraep46
    with fade
    pause 1
    scene kiraep47
    with fade
    pause 1
    kira "Ah, there you are! Took you long enough."
    scene kiraep48
    with dissolve
    d "I was busy... and besides, you're the one who invited me, right?"
    kira "Exactly, and I'm glad you came. Enjoy the night!"
    d "You seem pretty hyped tonight. Got anything special planned?"
    scene kiraep49
    with dissolve
    kira "Nothing crazy, just a fun night with friends. I like seeing how people loosen up after a few drinks. Always entertaining."
    d "I can imagine. So, do you have a game plan for the night, or just going with the flow?"
    kira "A bit of both. I’ll check on Fanny, make sure she's putting on a good show, and grab some shots for OnlyStan. It pays well, you know?"
    d "Yeah, seems to be a goldmine..."
    scene kiraep50
    with dissolve
    kira "Who knows? Right now, it's easy money."
    d "Sounds like you’ve got this all figured out. Ever thought of making something legit?"
    kira "What’s legit, really? If it pays, it works. Unlike you, I don’t need to break a sweat to get results."
    d "Says the girl working her phone like a full-time job."
    scene kiraep51
    with dissolve
    kira "Touché. But let’s be honest, between studying and running a business, who’s got the real power here?"
    d "Guess we’ll see after I win the B.E.S.T."
    kira "Oh? Confidence? I like that. Don’t mess it up."
    scene kiraep52
    with dissolve
    kira "Go have fun, but don’t forget the big game tomorrow."
    scene black
    with fade
    pause 1

    $ gabychaep4 = False
    if gabimusee == True:
        $ gabychaep4 = True
    $ evelynep4 = False
    if Temperament >=8:
        $ evelynep4 = True
    $ kirafannypalazioep4 = True

    call screen choixep4p2()


label palazio_gabriella_charlotte:
    if persistent.patch_enabled:
        if persistent.rufus10 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))

    scene black
    with fade
    pause 1
    if persistent.rufus10 == False:
        scene gabycha4 with fade
        show screen chat10() with dissolve
    else:
        scene gabycha4
        with fade
    dpense "Oh? Gabriella?"
    hide screen chat10 
    scene gabychaep41
    with dissolve
    dpense "And... Charlotte?"
    scene gabycha2
    with dissolve
    cha "Lately, I’ve been kinda intrigued by the idea of dating a younger guy."
    dpense "Interesting... Will eavesdrop a little."
    scene gabycha3
    with dissolve
    gaby "Oh? You mean... someone barely old enough to order a drink?"
    cha "Yeah..."
    scene gabycha5
    with dissolve
    gaby "Oh, interesting. And that would be a first for you, huh?"
    cha "Completely. Never even crossed my mind before. You?"
    gaby "Same here, but honestly, I’m starting to see the appeal."
    scene gabycha6
    with dissolve
    cha "They’ve got this fresh energy, you know? It’s kinda exciting."
    dpense "Are they talking about me?"
    scene gabycha7
    with dissolve
    gaby "Yeah, and there’s something spontaneous about them. Something... unpredictable. That can be refreshing."
    cha "Exactly. He’s gotta have a bit of maturity, too. No babysitting."
    scene gabycha8
    with dissolve
    gaby "And he should be smart. If he’s just cute but dull, it won’t work."
    cha "Oh, totally. But imagine someone with energy and wit? That’s rare."
    gaby "And who knows how to keep up. Some guys like to talk a big game but..."
    scene gabycha9
    with dissolve
    cha "End up falling asleep right after? Been there."
    gaby "I want someone who actually listens, you know?"
    cha "Oh, you mean a guy who doesn’t just nod along but actually engages? That’s basically a unicorn."
    scene gabycha10
    with dissolve
    gaby "Exactly! A guy who knows when to be bold but also when to hold back."
    cha "Mmm, now that would be something worth exploring..."
    scene gabycha11
    with dissolve
    dpense "It was an interesting discussion. I have to stay in touch with them."
    dpense "Didn't know they know each other."
    dpense "Could be interesting..."
    scene black
    with fade
    pause 1
    call education_increased from _call_education_increased_16
    if CharlottePath == True:
        $ chatextmass = True
    $ gabychaep4 = False

    if gabychaep4 == False and evelynep4 == False and kirafannypalazioep4 == False:
        jump ep4p2s3
    else:
        call screen choixep4p2()




label palazio_dancefloor:

    scene palazio_dancefloor
    call temperament_increased from _call_temperament_increased_21
    scene black
    with fade
    pause 1
    scene evelynep41
    with fade
    dpense "Wow! Who's that woman?"
    scene evelynep42
    with dissolve
    pause 2 
    scene evelynep43
    with dissolve
    pause 1 
    scene evelynep44
    with dissolve
    d "You dance well. Hard not to notice."
    ji "Oh? Is that your opening line? Bold."
    d "I like to think of it more as an observation than a pickup line."
    ji "Hmm... So should I be thanking you?"
    scene evelynep45
    with dissolve
    d "Only if you really mean it."
    ji "I like men who know how to talk. Tell me, aren't you a little young for me?"
    d "Maybe, but age is just a matter of perspective, isn’t it?"
    scene evelynep46
    with dissolve
    ji "I love a young man with confidence. But just being bold won’t be enough."
    d "Then what else do I need?"
    ji "Mystery. Control. And, most importantly, knowing when to stop chasing."
    scene evelynep47
    with dissolve
    ji "Text me... if you think you can keep up. And I'm Evelyn by the way."
    dpense "She is mysterious... It's intriguing."
    dpense "I like that!"
    $ renpy.notify (_("NEW CONTACT ADDED"))
    $ evelyn_contact = True
    $ evelynep4 = False
    scene black
    with fade
    pause 1

    if gabychaep4 == False and evelynep4 == False and kirafannypalazioep4 == False:
        jump ep4p2s3
    else:
        call screen choixep4p2()




label palazio_kira_fanny:
    scene palazio_vip
    call buddy_increased from _call_buddy_increased_22
    scene black
    with fade
    pause 1 
    scene polep41
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 2
    scene polep42
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 2
    scene polep43
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 2 
    scene polep44
    with dissolve
    pause 1 
    scene polep45
    with dissolve
    d "So, this is your big project tonight?"
    scene polep46
    with dissolve
    kira "What can I say? Money doesn’t make itself."
    d "And here I thought you were just enjoying the show."
    kira "Oh, I am, but I'm also making sure that every angle makes Fanny look worth every cent."
    scene polep47
    with dissolve
    d "Hum... I see."
    d "Wait..."
    scene polep48
    with dissolve
    d "She's not wearing any panties?" with hpunch
    kira "Ahah! No! It titillates the guys to think about it so I focus on her butt!"
    d "You're lucky there aren't many people in there."
    scene polep49
    with dissolve
    kira "Yeah, it's early. That's why we came here now."
    d " What do you mean?"
    kira "We can work without drunken idiots bothering us."
    play sound "sound/Photo.mp3" volume 1
    with flash
    scene polep410
    with dissolve
    d "You’re really putting in the work."
    kira "You sound surprised. I don’t half-ass things. If I do it, I do it right."
    scene polep411
    with dissolve
    d "Remind me never to underestimate you."
    kira "Smart choice!"
    kira "Come here! Let's take a selfie together"
    kira "Fanny! Come here! Double kiss!"
    scene polep412
    with hpunch
    pause 2
    play sound "sound/Photo.mp3" volume 1
    with flash
    kira "Check your OnlyStan's later."
    scene polep413
    with dissolve
    d "She really listens to you."
    kira "Of course she does."
    kira "She knows where her money comes from!"
    kira "Guys pays top dollar for her, and Fanny doesn’t even have to lift a finger."
    kira "I'm even beginning to use AI to create short clips... I'll show you!"
    d "And nobody complains?"
    scene polep414
    with dissolve
    kira "Why would they? They’re getting exactly what they want, even if it’s not ‘real.’ Win-win."
    kira "You know, fake content is way more profitable than the real thing. It’s not a scam, it’s just adapting to the market."
    d "And what about you? Running this little empire from behind the scenes... you ever think of getting on stage yourself?"
    scene polep415
    with dissolve
    kira "Me? Never. I’m an Orushi. I have a reputation to uphold. Performing? Not my thing."
    kira "Anyway, enjoy yourself, but don’t forget that you have a match tomorrow. Let’s see if you’re as good on the field as you are with the ladies."
    scene polep416
    with dissolve
    dpense "She's right. The match..."
    scene black
    with fade
    pause 2

    $ KiraPalazioShot = True
    $ kirafannypalazioep4 = False

    if gabychaep4 == False and evelynep4 == False and kirafannypalazioep4 == False:
        stop music fadeout 2
        pause 2
        jump ep4p2s3
    else:
        call screen choixep4p2()

label rufusg10:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img10"):
        show img10
        hide img10
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus10 = True
    hide screen chat10
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
