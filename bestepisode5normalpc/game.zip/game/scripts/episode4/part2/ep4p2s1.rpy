label ep4p2s1:

    scene black
    with fade
    pause 2 
    if _in_replay:
        show screen Replayexit
    scene graceep41
    with fade
    pause 1
    play music "musique/ALM0063-EternalLove-stockmusic-net.mp3" volume 0.2
    grace "I’ve been looking forward to us spending a little time together."
    d "I get it. So, what’s on your mind today?"
    scene graceep42
    with dissolve
    grace "Come on, I’ve got an idea you might like. Follow me."
    scene graceep43
    with dissolve
    pause 1 
    scene black
    with fade
    pause 1

    scene graceep44
    with fade
    grace "Here’s my room. You probably remember it... but this time, I have a surprise."
    scene graceep45
    with vpunch
    d "A surprise? Now I’m curious."
    scene graceep46
    with dissolve
    grace "Alright, get ready! I hope you like jacuzzis because mine is going to make you forget all your worries. Nothing beats warm water and good company!"
    d "A jacuzzi? Seriously? That’s an amazing idea."
    grace "Give me a second, I’ll grab some swimsuits."
    dpense "Oh no... I didn’t think to bring a swimsuit. What am I going to do if she asks?"
    scene black
    with fade
    pause 1 
    grace "Tell me what you think about this one."
    scene gracemaillot1 with fade:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    dpense "Wow... She really knows how to draw attention. That swimsuit looks amazing on her, but I can tell she’s enjoying testing my reactions."
    d "It’s... very elegant."
    dpense "Not sure if 'elegant' is the word she was hoping for. She knows exactly what she’s doing."
    grace "Really? Wait, I’ve got another one."
    scene black
    with fade
    pause 1
    dpense "And here she goes again... She’s having way too much fun messing with me."
    scene maillotrouge with fade:
        yalign 0.9
        linear 7.0 yalign 0.025
        repeat 1
    d "This one is stunning too. You have great taste."
    dpense "How am I supposed to stay focused? She looks incredible in all of them."
    scene graceep47
    with dissolve
    grace "Hmm... Are you sure it’s the swimsuit that’s impressing you?"
    dpense "She has that teasing smile... She knows exactly what she’s doing and how to throw me off balance."
    d "That’s what I should say, but you’re making it hard."

    scene graceep48
    with dissolve
    grace "Go into the jacuzzi, I'm coming in two seconds."
    scene black
    with fade
    pause 2
    scene hubep41
    with fade
    pause 2
    scene hubep42
    with dissolve
    pause 2 
    scene hubep43
    with dissolve
    dpense "No swimsuit... Oh well, I’ll improvise. I’ll get in first, maybe she won’t notice."
    scene hubep44
    with dissolve
    d "Wow... This is even better than I imagined."
    dpense "The water is perfect. Soothing, warm..."
    scene hubep45
    with dissolve
    grace "Ready! See? I didn’t take too long."
    scene hubep46
    with dissolve
    dpense "She’s incredible. That swimsuit... she knows exactly how to draw attention."
    if persistent.patch_enabled:
        if persistent.rufus14 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
    scene hubep47
    with vpunch
    pause 2 
    scene hubep48
    with dissolve
    pause 2 
    scene hubep49
    with dissolve
    pause 2
    scene black
    with fade
    pause 1
    scene hubep410
    with vpunch
    pause 2 
    scene hubep411
    with dissolve
    grace "Wait a second... Are you... naked?!"
    dpense "Oh no..."
    d "Uh, yeah. Sorry, I didn’t have a swimsuit. I thought it’d be less awkward this way."
    scene hubep412
    with dissolve
    grace "Less awkward?"
    scene hubep413
    with dissolve
    grace "Well, at least you really know how to improvise, don’t you?"
    dpense "Her laugh is so natural and genuine. She turns what could’ve been an awkward moment into something light and fun. She’s amazing."
    scene hubep414
    with dissolve
    grace "I guess this makes things... interesting. Alright, I’ll pretend I don’t see anything."
    d "Thank you for your... understanding."
    if persistent.rufus14 == False:
        scene hubep415 with dissolve
        show screen chat14() with dissolve
    else:
        scene hubep415
        with dissolve
    grace "So... Tell me, what’s on your mind right now?"
    d "Mostly you and your... body."
    hide screen chat14
    scene hubep416
    with dissolve
    dpense "She’s the perfect mix of warmth and energy. Every detail of this moment is etched into my memory: the warmth of the water, her smile that lights up everything, and that look in her eyes that says she could stay here forever."
    grace "You know... It feels like the whole world doesn’t exist anymore. Just you, me, and this warm water."
    scene hubep417
    with dissolve
    grace "It’s rare to feel this... good. With you, I can truly be myself."
    d "It’s because of you. You make everything special."
    scene hubep418
    with dissolve
    grace "The water’s hot... but not as much as you right now."
    dpense "Her back against my chest, her wet skin brushing against mine... It’s like my entire body reacts to her closeness."
    scene hubep419
    with dissolve
    grace "You know, I think it’s cute that you’re embarrassed. It shows you’re vulnerable, and that’s rare in guys."
    dpense "Cute? That’s one way to put it... but at least she doesn’t seem uncomfortable."
    scene hubep418
    with dissolve
    grace "You can touch me you know... I love the feeling of your hands on my skin..."
    d "Grace..."
    scene hubep420
    with dissolve
    dpense "She knows exactly what she’s doing. My heart is pounding so hard she must hear it."
    dpense "Every move she makes, every word she whispers... she has me completely under her spell."
    grace "Shh... No need for words."
    scene hubep422
    with dissolve
    grace "I wanted to tell you... this really means a lot to me. You, us... everything we share."
    grace "Sometimes I feel like I overthink everything, but with you, everything feels so simple."
    d "You’re incredible, Grace. I don’t know how I got so lucky."
    scene hubep423
    with dissolve
    grace "It’s not luck... it’s you."
    scene hubep425
    with dissolve
    grace "You're so... Hard..."
    grace "I love that feeling..."
    scene hubep426
    with dissolve
    grace "I... It makes me... horny..."
    d "Grace, you're making difficult for me to resist..."
    grace "So... Don't..."
    grace "Take me [name], let me feel your desire."
    scene hubep424
    with dissolve
    pause 2
    scene hubep421
    with dissolve
    pause 2
    scene hubep427
    with dissolve
    grace "How about we continue this somewhere a bit more... comfortable?"
    pause 1 
    scene black
    with fade
    pause 2
    scene hubep428
    with fade
    pause 2
    scene hubep429
    with dissolve
    pause 2
    scene hubep430
    with dissolve
    pause 2
    scene hubep431
    with dissolve
    grace "Come closer. Let me show you how much you mean to me."
    grace "I... I want to try something, but... I’m not sure about it."
    scene hubep432
    with dissolve
    d "Grace, you can tell me anything."
    scene hubep433
    with dissolve
    grace "It’s just that... I’ve never really done this before. I don’t want to disappoint you."
    scene hubep434
    with dissolve
    d "Hey, look at me. You don’t have anything to prove. All that matters is that we share this moment together."
    scene hubep435
    with dissolve
    grace "You’re really... You know exactly what to say. Thank you."
    grace "I want this moment to be special... just for the two of us."
    d "Grace... I..."
    scene hubep436
    with dissolve
    dpense "No need to finish my sentence. She knows. She understands."
    pause 1
    scene hubep437
    with dissolve
    pause 1
    scene hubep438
    with dissolve
    pause 1
    scene hubep437
    with dissolve
    pause 1
    scene hubep438
    with dissolve
    pause 1
    scene hubep437
    with dissolve
    dpense "She's doing it with all her heart."
    scene hubep439
    with dissolve
    pause 0.5 
    scene hubep440
    with dissolve
    pause 0.5 
    scene hubep439
    with dissolve
    dpense "I can feel she's not a pro but she's doing it for me"
    scene hubep441
    with dissolve
    grace "That's... different from what I've seen in the movies"
    d "Oh? You watch porn?"
    scene hubep442
    with dissolve
    grace "No... Well yes, but it was for educational purpose!"
    d "Educational?"
    grace "Yeah... I needed advices on how to do it well so..."
    d "You should have asked Kira!"
    scene hubep443
    with dissolve
    grace "That's not a bad idea!"
    dpense "I can feel her tense now... I have to make something."
    scene hubep444
    with dissolve
    d "Come here, you don't need to please me like this."
    grace "Are you sure that..."
    d "Shhh!"
    scene hubep445
    with dissolve
    grace "You’re incredible... You make me feel so... alive."
    scene hubep446
    with dissolve
    dpense "I want her to know how special she is. I want this moment to be etched into our hearts forever."
    scene hubep447
    with dissolve
    d "Grace... you’re everything to me. And I’ll do everything I can to make you happy."

    scene hubep448
    with hpunch
    pause 2.0 
    scene black
    with fade
    pause 1

    scene gracesexep43
    with fade
    grace "Be gentle... That's the first time..."
    d "I will just put the tip for now..."
    scene gracesexep41
    with dissolve
    grace "Okay..."
    pause 1
    scene gracesexep42
    with dissolve
    d "Is it okay?"
    scene gracesexep44
    with dissolve
    grace "Yeah... You can continue..."
    pause 1
    grace "Oh my god... You're so... big!"
    scene gracesexep45
    with hpunch
    grace "I can feel it through my... Ohhhhhhhhhhhhh!"
    d "Grace? Are you okay?"
    scene gracesexep46
    with dissolve
    grace "Okay? It's marvelous!!!"
    grace "My god, you've reached my womb! It was almost overwhelming!"
    grace "I want more!!!"
    d "You mean?"
    grace "Yes [name]! Do it!"
    stop music fadeout 1 
    scene black
    with fade
    scene black
    pause 0.5
    play music "musique/AIE0550-YouAreTheOneINeed-stockmusic-net.mp3" volume 0.2 fadein 2
    play movie "images/animation/gracesexep4anim.webm" loop
    show movie
    ""
    dpense "Here we are, together, in this suspended moment."
    dpense "Every heartbeat, every breath in sync. This is true happiness."
    grace "That's amazing! Please don't stop!"
    dpense "Every moment with her is a mix of intense emotions."
    dpense "Her gestures are soft yet filled with passion."
    grace "Deeper! I want to feel you fill me completely!"
    dpense "She's giving herself to me entirely, and I want to do the same for her."
    grace "I... I’m so happy to be with you..."
    dpense "Her breath, her whispers... everything about her seems to synchronize with me."
    dpense "It’s as if we’ve become one."
    stop movie
    scene black
    with dissolve
    pause 0.5
    scene black

    pause 1
    scene gracesexep47
    with fade
    pause 2 
    scene gracesexep48
    with dissolve
    grace "[name] I think I'm coming..."
    d "That's it, Grace! Let the pleasure come. I want you to really feel it."
    scene gracesexep49
    with vpunch
    grace "[name]! I can't stop it!"
    grace "That's so..."
    with flash
    with hpunch
    pause 0.5
    with flash
    with hpunch
    scene gracesexep50
    with dissolve
    grace "Goooooooooooooooood!"
    with vpunch
    with flash
    dpense "I can't hold myself... Her body, her climax..."
    dpense "I'm going to come too!"
    d "Grace!! I..."
    scene gracesexep45
    with hpunch
    grace "Oh my god! I can feel it throbbing in me!"
    grace "Harder!"
    grace "I want you to fill me up!"
    d "Grace! I..."
    grace "Ahhhhhhhhhhhhhhhh!"
    with flash
    with hpunch
    scene gracesexep52
    with flash
    with hpunch
    grace "YEEEEEEEEEEEEEEEESSSSSSSSSSSSSSSS!"
    grace "It's so goooooooooood!"
    with flash
    with hpunch
    scene gracesexep51
    with flash
    with hpunch
    scene gracesexep50
    with dissolve
    grace "I'm coming again! Ahhh, ahhhh, unhhhhh"
    grace "I can't breath I can't...."
    scene gracesexep51
    with flash
    with hpunch
    grace "Ohhhhhhhhhhhh"
    stop music fadeout 2
    scene black
    with fade
    pause 2 

    play music "musique/MAS0427-ItWasLoveYesterday-stockmusic-net.mp3" volume 0.2 fadein 2

    scene gracesexep53
    with fade
    pause 0.5
    grace "That was... perfect. Thank you for this moment."
    dpense "Seeing her so at peace fills me with happiness. I want to give her so much more than just this moment."
    d "Grace... you’re incredible. You make everything special."
    grace "Thank you for this... first time..."
    grace "You made it unforgettable..."
    d "I hope it didn't hurt you..."
    scene gracesexep54
    with dissolve
    grace "Hurt me??? Is this a joke?"
    grace "Next time, I want you to go harder! I needed more!"
    d "Ahaha! You're incredible!"
    grace "That's what you like in me, no?"
    d "Sure!"
    scene gracesexep55
    with vpunch
    pause 2
    grace "Well... my mom will be back any minute now. We should get dressed."
    $ renpy.end_replay()

    scene black
    with fade
    pause 2
    scene finep4drew1
    with fade
    drew "So, you’re still here, [name]? I suppose you’ve had a pleasant day."
    scene finep4drew2
    with dissolve
    dpense "Mrs. Drew... Always impressive and a bit intimidating. But today, there’s something different in her gaze... almost like a challenge."
    d "Yes, Mrs. Drew. Grace invited me to spend some time here."
    scene finep4drew3
    with dissolve
    drew "I can see that. She seems particularly happy these days. Could that be your influence?"
    dpense "Her tone is flattering, but her eyes seem to analyze every word. She exudes an aura that blends control and seduction."
    d "Grace is incredible. She deserves all the happiness in the world."
    drew "Charming, but remember, I’m Grace’s mother, and also your dean."
    scene finep4drew4
    with dissolve
    drew "As long as you’re winning and doing things right, I don’t see a problem."
    dpense "Her words are flattering, but they’re also a warning. She’s testing my nerves, my confidence, and my intentions."
    drew "Don’t let your guard down. You seem promising, but the real challenges are just beginning. Trust me, I’ll be watching."
    scene finep4drew5
    with dissolve
    dpense "She’s fascinating, alluring, but dangerous. Her smile hides intentions I can’t decipher. I want to understand her, but I'm afraid getting burned."
    drew "Good luck, [name], and have a good night."

    scene black
    with fade
    dpense "An unforgettable evening, on many levels. Grace... and Mrs. Drew. Things are getting more and more complicated."
    stop music fadeout 2
    pause 2
    if blueep4 == True:
        jump ep4p2s2
    if KiraPalazio == True:
        jump ep4p2s2bis
    jump ep4p2s3


label rufusg14:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img14"):
        show img14
        hide img14
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus14 = True
    hide screen chat14
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
