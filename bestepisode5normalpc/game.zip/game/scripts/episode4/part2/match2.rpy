label match2:

    $ chevilleMC = False
    $ mcheromatch2 = 0

    scene black
    pause 2 
    play music "musique/ALG0202-EnergyRock-stockmusic-net.mp3" volume 0.5
    scene footep41
    with fade
    orushi "Welcome to this semi-final. Today, you're playing for more than just a win."
    scene footep44
    with dissolve
    orushi "The match will be played in 3 points. A new rule: each team will have a goalkeeper."
    scene footep45
    with dissolve
    orushi "Don't forget, the team that wins the final will get the house as the ultimate reward."
    orushi "Give it all you've got. May the best team win!"
    scene footep46
    with dissolve
    d "A goalkeeper?"
    scene footep47
    with dissolve
    grace "Don't worry! I'll take the goalie position!"
    d "Oh? Alright."
    scene footep42
    with dissolve
    dpense "They're already there."
    scene footep43
    $ renpy.movie_cutscene("images/animation/footep43.webm", stop_music=False)
    scene footep43
    pause 1 
    scene footep48
    with dissolve
    s "You really think you have a chance?"
    s "This will be over quickly."
    scene footep49
    with dissolve
    hec "Don't worry, Steven. They'll bite the dust before they have a chance to get started."
    scene footep410
    with dissolve
    mad "Don't get too cocky, Steven. Anything can happen."
    scene footep411
    with dissolve
    ruby "We're one match away from the final. There's no way we're giving up now."
    scene footep412
    with dissolve
    julia "Stay focused!"
    scene footep413
    with dissolve
    gaby "You're not here by accident! Show them why you deserve this spot."
    scene footep414
    with dissolve
    dpense "Even Gaby is there to encourage her girls."
    orushi "All teams in position."
    scene footep415
    pause 1
    scene black
    with fade
    scene footep416
    pause 1
    scene black
    with fade
    scene footep417
    pause 1
    scene black
    with fade
    scene footep418
    pause 1 
    scene black
    with fade
    orushi "Team B, the kick off is yours."

    if Redpath:
        scene footepautres1
        with fade
        emerick "Look at the frenchie, he already thinks he's in the final."
        beth "And if he is, maybe it's because he's capable. Unlike some others, he works hard to be here."
        emerick "You're defending this kid? Are you kidding?"
        scene footepautres2
        with dissolve
        beth "I never joke. Maybe you should take a page out of his book."
        scene footepautres4
        with dissolve
        kira "Maybe we should focus on the match instead of wasting time talking."
        emerick "We'll see what you say when he's laying on the ground."
        scene black
        with fade

    elif blueep4:
        scene footepautres1
        with fade
        emerick "Look at the frenchie, he already thinks he's in the final."
        sofia "He's tougher than he looks. I think he could surprise you."
        emerick "Are you serious? This kid's going to get crushed."
        scene footepautres3
        with dissolve
        sofia "Maybe. But anything can happen in a match."
        emerick "That's cute, Sofia. Are you planning to be his cheerleader too?"
        scene footepautres4
        with dissolve
        kira "You're both exhausting. The match is about to start, so watch and learn."
        scene black
        with fade

    stop music fadeout 2
    scene footep420
    with fade
    s "Watch closely, I'm going to finish this right from the start."
    play music "musique/MYO0008-HipHopAndRockCinematicTrailer-stockmusic-net.mp3" volume 0.25
    scene footep419
    with hpunch
    dpense "What is he doing?"
    scene footep421
    with dissolve
    dpense "Wait... is he?!"
    scene footep422
    with hpunch
    gaby "Watch out!"
    mad "What?!"
    scene footep421
    with vpunch
    pause 0.5 
    scene footep423
    $ renpy.movie_cutscene("images/animation/footep423.webm", stop_music=False)
    scene footep423

    play sound "sound/whooshtir.wav" volume 2
    pause 0.5 
    scene footep424
    with hpunch
    pause 0.5 
    scene footep425
    with hpunch
    pause 0.5 
    scene footep426
    with dissolve
    d "What the???"
    scene footep427
    with dissolve
    play sound "sound/tirlong.wav" volume 2
    pause 0.5 
    scene footep428
    with hpunch
    pause 1
    scene footep429
    with dissolve
    pause 0.5 
    scene footep430
    with dissolve
    pause 0.5 
    play sound "sound/WhooshEpic.mp3" volume 2
    scene footep431
    with hpunch
    pause 1
    scene footep432
    with dissolve
    pause 0.5 
    grace "I... I didn't see it coming. It was too fast."
    scene footep433
    with dissolve
    s "I warned you. That was fast, wasn't it?"
    scene black
    with fade

    scene footepautres5
    with dissolve
    emerick "This is what I call a perfect start. They don't stand a chance."
    sofia "This is just the beginning."

    scene footep434
    with dissolve
    mad "There's no way we're letting ourselves get humiliated like this."
    ruby "It's just one point. We can still come back."
    julia "Breathe. We'll get back on track."
    scene footep435
    with dissolve
    dpense "1-0... From the very first engagement. We can still come back, but we need to wake up."
    scene footep436
    with dissolve
    d "Don't worry Grace, that's not your fault."
    mad "It’s okay, Grace. You’ll get the next one."
    ruby "Yeah, we’ve got your back!"
    scene footep437
    with dissolve
    gaby "Don’t let it get to you. Regroup and play smart."
    ruby "Let’s go!"
    dpense "Play smart she says."
    scene footep438
    with dissolve

    if isEnabledEducationSpecialization:
        $ renpy.notify (_("EDUCATION ACTIVATED"))
        dpense "Their team is based on several key points."
        scene footep438
        with fade
        dpense "Steven radiates pure strength and will probably try to score the most goals with power."
        scene footep439
        with fade
        dpense "Hector is aggressive, his job is to recover the ball with a heavy press."
        scene footep440
        with fade
        dpense "Mac is imposing but relatively agile, making him an excellent goalie, difficult to find an angle to shoot."
        scene footep441
        with fade
        dpense "Ben is quite agile and fast. I doubt he has much power."
        scene footep442
        with fade
        dpense "The last one seems pretty harmless. Probably one of the backups."
        call education_increased from _call_education_increased_15
    else:

        dpense "Their team seems pretty strong..."

    stop music fadeout 2

    scene black
    with dissolve
    pause 1
    play music "musique/MYO0031-ActionSportsEnergeticRockTrailer-stockmusic-net.mp3" volume 0.5
    scene footep444
    with dissolve
    pause 1
    scene footep445
    with dissolve
    ruby "Let's go!"
    scene footep446
    with dissolve
    pause 1 
    scene footep447
    with dissolve
    s "Hey, give it to me!"
    ruby "Catch it if you can!"
    scene rubyroulette1
    with dissolve
    pause 0.5
    scene rubyroulette2
    $ renpy.movie_cutscene("images/animation/rouletteruby.webm", stop_music=False)
    scene rubyroulette2
    with dissolve
    pause 0.5
    scene rubyroulette3
    with dissolve
    pause 1
    scene footep451
    with dissolve
    dpense "She will try to pass to Madison"
    scene footep449
    with dissolve
    pause 1 
    scene footep452
    with dissolve
    dpense "Hector will try to intercept, but Madison should outrun him."
    scene footep452

    if isEnabledTemperamentSpecialization:
        $ renpy.notify (_("TEMPERAMENT ACTIVATED"))
        dpense "I’ll block him!"
        scene footep453
        with hpunch
        hec "Get out of the way, white knight!"
        d "You gotta get past me if you want the ball."
        scene footep454
        with dissolve
        pause 1
        call temperament_increased from _call_temperament_increased_20
    else:
        scene footep455
        with hpunch
        dpense "He’s not quick enough."
        mad "Did you eat too much last night or what? You’re a bit slow!"

    scene footep456
    with dissolve
    mad "Julia, it’s yours!"
    scene footep457
    with dissolve
    pause 1
    scene footep458
    with hpunch
    julia "I’ve got it!"
    scene footep459
    with dissolve
    dpense "Julia is advancing, but Ben is going to intercept her! She's going to lose the ball!"
    scene footep460
    with dissolve
    julia "Here! Make the difference."
    scene footep461
    with vpunch
    d "Thanks Julia!"
    scene footep462
    with dissolve
    dpense "This is my chance... I’ll take the shot. I'll show them!"
    scene footep463
    with dissolve
    dpense "Damn, Mac takes up so much space!"
    scene footep464
    with vpunch
    dpense "Positioning my feet"
    scene footep465
    with hpunch
    dpense "And shoot!"
    pause 0.5
    play sound "sound/whooshpetit.wav" volume 2
    scene footep466
    with dissolve
    pause 1 
    scene footep467
    pause 1 
    play sound "sound/Whoosh.mp3" volume 2
    pause 0.25
    scene footep468
    with hpunch
    pause 1
    scene footep469
    with dissolve
    mac "Too weak..."
    stop music fadeout 2
    mad "You rushed it!"
    play music "<from 54>musique/MYO0031-ActionSportsEnergeticRockTrailer-stockmusic-net.mp3" fadein 2 volume 0.5
    scene footep470
    with dissolve
    ruby "It’s okay, you’ll get it!"
    scene footep471
    with dissolve
    dpense "Now they have possession. I need to make up for that..."
    scene black
    with fade

    $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
    scene foot70
    with vpunch
    pause 1 
    scene footep472
    with dissolve
    pause 1 
    scene footep473
    with hpunch
    d "Nice, Ruby!"
    scene footep474
    with hpunch
    dpense "Ruby sends a precise header to Julia."
    scene footep475
    with dissolve
    dpense "But Julia is surrounded."
    scene footep476
    with dissolve
    dpense "She prepares to shoot..."
    mad "Come on, Julia, do it!" with hpunch
    scene footep477
    with dissolve
    pause 1
    scene footep478
    play sound "sound/voom.wav" volume 2
    $ renpy.movie_cutscene("images/animation/juliashootep4.webm", stop_music=False)
    scene footep478
    with dissolve
    pause 0.5
    scene footep479
    with hpunch
    pause 0.5

    if Training2 == True:
        dpense "Julia feints a powerful shot..."
        scene footep480
        with dissolve
        dpense "Mac block the right, but the ball goes the other way!"
        scene footep481
        with dissolve
        dpense "I need to take advantage of this!"
        scene black
        with fade
        with flash
        scene ep3s4r14w
        with vpunch
        dpense "Kira's lifted shot!"
        with flash
        scene black
        pause 0.5 
        scene footep482
        with hpunch
        pause 1
        scene footep483
        with dissolve
        d "This time..."
        scene footep484
        with dissolve
        d "It goes in!"
        play sound "sound/WhooshEpic.mp3" volume 2
        scene footep487
        with hpunch
        pause 1

        scene footepautres6
        with hpunch
        kira "Hey, that’s my shot!"
        pause 0.5

        scene footep485
        with hpunch
        pause 1
        scene footep486
        play sound "sound/voom.wav"
        $ renpy.movie_cutscene("images/animation/liftedshot.webm", stop_music=False)
        scene footep486
        with dissolve
        pause 1
        scene footep488
        with dissolve
        pause 0.5 
        scene footep489
        with dissolve
        mad "Goal!"
        scene footep490
        with dissolve
        julia "Well done, [name]!"
        ruby "Bravo!"
        $ mcheromatch2 = mcheromatch2 + 1
        stop music fadeout 2
        scene black
        with fade
    else:


        dpense "It isn't powerful enough."
        scene footep491
        $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
        scene footep491
        with dissolve
        ruby "Not so fast!"
        dpense "What is she doing?"
        scene footep492
        with dissolve
        ruby "IIIIIIIIIIII....KEIIIIIIIII!"
        d "Seriously???"
        scene footep493
        with dissolve
        pause 1 
        scene footep494
        with dissolve
        ruby "I always dreamed to say these words ahah!"
        mad "What is this goal?!"
        julia "Ruby, you’re unbelievable!"
        ruby "All that matters is we scored, right?"
        dpense "1-1. Ruby turned a critical situation into an incredible moment."
        stop music fadeout 2
        scene black
        with fade

    scene footep495
    with dissolve
    play music "<from 30>musique/KaiEngel-TheRun.mp3" fadein 5 volume 0.5
    hec "What’s this circus?!"
    s "We’ll crush them. No luck next time."
    scene footep496
    with dissolve
    gaby "That was unexpected, but effective. Keep it up and don’t let up."
    dpense "The match is back on, but we need to keep this energy."

    scene footepautres7
    with dissolve
    emerick "Seriously?!"
    beth "There’s no need to panic."
    sofia "That was well played. They’re better than I thought."
    kira "Interesting..."
    emerick "Shut up, Kira. This isn’t the time for fantasies."
    if beth == True:
        scene footepautres8
        with dissolve
        beth "Come on [name], show us what you can do."
    if sofia == True:
        scene footepautres9
        with dissolve
        sofia "Stay focused [name]."

    scene footep418
    with dissolve
    dpense "Steven's team seems destabilized after our equalizer."
    gaby "Nice reaction, but don’t let the pressure off. They’ll come back stronger."
    scene footep497
    with dissolve
    ruby "It’s just the beginning, we shook them up good."
    mad "We have to keep this going. Don’t let them take control again."
    scene black
    with fade

    scene footep498
    with hpunch
    pause 0.5 
    scene footep499
    with dissolve
    pause 0.5
    scene footep500
    dpense "It's now or never!"
    scene footep501
    with hpunch
    dpense "I manage to recover the ball."
    scene footep502
    with dissolve
    pause 1.0
    scene footep503
    with dissolve
    dpense "Just have to get past this guy and..."
    scene footep495
    hec "Talan! Now!" with hpunch
    dpense "Hmm?"
    scene footep504
    with hpunch
    dpense "What the???"
    mad "Behind you!!!" with hpunch
    scene footep505
    with hpunch
    julia "You will hurt him!"
    scene footep506
    with dissolve
    pause 1

    if isEnabledSportSpecialization:
        $ renpy.notify (_("SPORT ACTIVATED"))
        scene footep507
        with vpunch
        dpense "Missed! Bastard..."
        scene footep508
        with vpunch
        hec "Ouch!"
        scene footep509
        hec "Get out of my way! Idiot!"
        dpense "This guy..."
        scene footep510
        with dissolve
        dpense "Julia is running..."
        dpense "I will pass to her..."
        stop music fadeout 2
        scene footep511
        with dissolve
        pause 1
        play music "musique/ALG0222-UpbeatEnergeticRock-stockmusic-net(1).mp3" volume 0.5 fadeout 2
        call sport_increased from _call_sport_increased_20
        jump matchep4second
    else:

        with flash
        scene footep512
        with hpunch
        with flash
        $ chevilleMC = True
        scene footep512
        with dissolve
        pause 0.5 
        scene footep513
        with vpunch
        d "Aoutch!"
        mad "What the heck?"
        ruby "There’s a foul there!"
        scene footep514
        with dissolve
        with vpunch
        pause 1
        scene footep515
        with dissolve
        dpense "And Steven who takes the ball as nothings happened"
        scene footep516
        s "And this is the second one!"
        scene footep423
        with dissolve
        play sound "sound/tirlong.wav" volume 2
        pause 0.20
        scene footep424
        with hpunch
        pause 0.5 
        scene footep425
        with hpunch
        pause 0.5 
        d "Grace!!!"
        with flash
        scene footep517
        with dissolve
        pause 0.1
        scene footep518
        play sound "sound/voom.wav" volume 2
        $ renpy.movie_cutscene("images/animation/stevenshot2.webm", stop_music=False)
        scene footep518
        with dissolve
        pause 0.5
        scene footep519
        grace "I... I touched it..."
        ruby "It’s not over, we can still come back."
        gaby "Stay focused. There’s still time. Keep your heads cool."
        scene footep436
        with dissolve
        dpense "2-1... We need to react right away. This match is not over."

        scene footepautres5
        with dissolve
        emerick "Yes! This is what I wanted to see. Just as planned."
        kira "I like this dynamic."
        emerick "Stop talking, Kira. This kid needs to learn who he’s dealing with."
        sofia "Don’t underestimate [name]."
        stop music fadeout 2

        scene black
        with fade
        pause 1
        scene footep444
        with dissolve
        pause 1 
        play music "musique/ALG0222-UpbeatEnergeticRock-stockmusic-net(1).mp3" volume 0.5 fadeout 2
        scene footep521
        with dissolve
        jump matchep4second

label matchep4second:
    pause 1
    scene footep520
    with hpunch
    pause 1
    scene footep522
    with dissolve
    dpense "Julia dribbles quickly toward the goal"
    scene footep523
    with dissolve
    pause 1
    if Training == True:
        scene footep524
        with dissolve
        pause 1 
        scene footep525
        with hpunch
        pause 1
        scene footep526
        mac "You're back Frenchie!"
        mac "You think you have a chance with your weak shots?"
        scene footep527
        dpense "I’m in a good spot to shoot, but this time, I'll follow Gabriella’s advice."
        scene black
        with fade
        with flash
        scene e3s1b13w
        with vpunch
        d "Any last advice for the upcoming match?"
        gaby "Oh? Hmm... Play with the bar."
        with flash
        scene black
        with fade
        dpense "Not sure of what I am doing..."
        scene footep464
        with dissolve
        pause 0.5
        scene footep465
        with vpunch
        pause 0.5
        scene footep528
        with vpunch
        mac "Too high!"
        scene footep529
        with hpunch
        dpense "Okay!"
        scene footep530
        with dissolve
        dpense "And now?"
        scene footep531
        with vpunch
        mad "[name]! Duck!"
        scene footep532
        with dissolve
        d "What???"
        scene footep533
        $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
        scene footep533
        with dissolve
        pause 1 
        scene foot70
        with hpunch
        pause 0.5 
        scene footep534
        with dissolve
        pause 1
        scene footep535
        $ renpy.movie_cutscene("images/animation/saltomadi.webm", stop_music=False)
        scene footep535
        with dissolve
        dpense "I feel like I'm watching a bird fly."
        dpense "She’s... doing a bicycle kick? Seriously?"
        scene footep536
        with vpunch
        mad "And that’s in your face!"
        scene footep537
        with vpunch
        pause 0.1
        scene footep538
        $ renpy.movie_cutscene("images/animation/madisalto2.webm", stop_music=False)
        scene footep538
        with dissolve
        d "It’s in! What a shot!"
        ruby "Incredible, Madison!"
        scene footep539
        with dissolve
        d "Wow! What was that shot?"
        mad "I don’t know. I just improvised!"
        scene footep540
        with dissolve
        hec "This match just got crazy!"
        scene footep541
        with dissolve
        s "We’re going to have to tighten up. This isn’t over."
        scene footep414
        with dissolve
        gaby "Well played. Don’t let up on the pressure. Keep it up."
        $ mcheromatch2 = mcheromatch2 + 1
    else:


        scene footep542
        with dissolve
        dpense "Julia keeps the ball, dribbling with incredible agility."
        scene footep543
        with vpunch
        pause 1 
        scene footep544
        with dissolve
        pause 1
        scene footep545
        with hpunch
        pause 1
        scene footep546
        with dissolve
        dpense "The girls are unstoppable!"
        scene footep547
        with dissolve
        pause 1
        scene footep548
        with hpunch
        dpense "Ruby will shoot!"
        play sound "sound/Whoosh.mp3" volume 2
        scene footep549
        with dissolve
        dpense "Wait! She missed it???"
        scene foot70
        $ renpy.movie_cutscene("images/animation/foot3.webm", stop_music=False)
        scene foot70
        with vpunch
        pause 0.5
        scene footep550
        with dissolve
        pause 0.5
        scene footep551
        with hpunch
        play sound "sound/Vooh.wav" volume 2
        pause 0.5
        scene footep552
        with dissolve
        pause 0.5
        scene footep553
        with dissolve
        julia "It’s in!"
        ruby "We made it! What a play!"
        scene footep554
        with dissolve
        mad "Haha! Well played, Ruby!"
        scene footep540
        with dissolve
        hec "They scored again... this can’t be happening."
        scene footep541
        with dissolve
        s "We’ll crush them, no doubt."
        scene footep414
        with dissolve
        gaby "Better. Keep it up and don’t let up."

    if chevilleMC:
        dpense "2-2. The match is back on, but we need to keep this energy."
    else:
        dpense "2-1. We have to finish now."

    scene footepautres7
    with dissolve
    emerick "No way!"
    kira "Their game is getting smoother. This match isn’t over."

    scene black
    with fade
    pause 0.5 

    scene footep497
    with fade
    ruby "Let’s keep going, don’t let them breathe!"
    scene footep555
    with dissolve
    pause 1
    scene footep556
    with hpunch
    dpense "The other team tries everything and advances in block."
    dpense "They’re closing in on the goal."
    scene footep557
    with dissolve
    d "Grace, get ready!"
    scene footep558
    with dissolve
    pause 1
    scene footep559
    with dissolve
    pause 1
    scene footep560
    with dissolve
    pause 1
    scene footep561
    with dissolve
    pause 1
    play sound "sound/whooshpetit.wav" volume 2
    scene footep562
    with hpunch
    pause 0.5
    scene footep563
    with dissolve

    if isEnabledBuddySpecialization:
        $ renpy.notify (_("BUDDY ACTIVATED"))
        dpense "They're doing a cross shot!"
        scene footep564
        with dissolve
        dpense "Grace is going to be beaten!"
        scene footep565
        with dissolve
        pause 0.5 
        play sound "sound/tirnormal.wav" volume 2
        scene footep566
        with hpunch
        pause 0.5
        scene footep567
        with hpunch
        pause 0.5
        scene black
        with fade
        pause 1 
        play sound "sound/whooshtir.wav" volume 2
        scene footep568
        with vpunch
        d "Damn!"
        scene footep569
        with vpunch
        d "Aoutch!"
        scene footep570
        with vpunch
        grace "Are you okay?"
        d "Yeah, I'm fine. Gotta keep playing either way."
        grace "Thank you [name]! You saved us..."
        d "It’s not over."
        $ mcheromatch2 = mcheromatch2 + 1
        call buddy_increased from _call_buddy_increased_21
    else:
        dpense "They shoot a cross shot!"
        scene footep564
        with dissolve
        d "Grace!!!"
        scene footep565
        with dissolve
        pause 0.5 
        play sound "sound/tirnormal.wav" volume 2
        scene footep566
        with hpunch
        pause 0.5
        scene footep567
        with hpunch
        pause 0.5
        scene black
        with fade
        pause 0.5 
        play sound "sound/whooshtir.wav" volume 2
        scene footep571
        with vpunch
        d "What a graceful save!"
        scene footep572
        with dissolve
        grace "Thanks!"
        scene footep573
        with hpunch
        grace "Let’s go!"

    stop music fadeout 1
    scene footep574
    with dissolve
    play music "musique/Jens_East_-_Daybreak_feat_Henk.mp3" fadeout 2 volume 0.5
    dpense "Ruby receive the ball and charges toward the opposing side."
    scene footep575
    with dissolve
    dpense "Julia and Madison follows her."
    scene footep576
    with dissolve
    pause 0.5
    scene footep577
    with dissolve
    ruby "Madison, to you!"
    scene footep578
    with hpunch
    pause 1
    scene footep579
    with dissolve
    dpense "Madison got the ball but that guy is marking her."
    scene footep580
    with dissolve
    dpense "She passes to Julia."
    scene footep581
    with hpunch
    pause 1 
    scene footep582
    with vpunch
    ruby "Hey!"
    d "Julia!"
    scene footep585
    with vpunch
    dpense "She's using a heel pass even as she's falling..."
    scene footep586
    with dissolve
    dpense "Well done Julia!"
    scene footep587
    with vpunch
    julia "Ooof!"
    dpense "Madison isn't open..."
    scene footep588
    with dissolve
    dpense "Ruby either..."
    scene footep589
    with dissolve
    ruby "It’s yours, watch out for Mac!" with hpunch
    scene footep590
    with dissolve
    dpense "It's all on me now. I need to get ready to make this shot now."
    scene footep422
    with dissolve
    gaby "This is it, you know what to do."
    scene footep591
    with vpunch
    dpense "I position myself, my heart races. This is it. No hesitation."
    scene footep483
    with dissolve
    dpense "Position my foot..."
    scene footep484
    with dissolve
    dpense "Put my weight forward..."
    dpense "Hector shouts something, but I can't hear him anymore. Focus."
    dpense "Breathe..."
    mad "Come on, you can do it, focus!"
    ruby "I know you can score, go for it!"
    julia "It’s all you now, everyone’s counting on you."
    dpense "Grace, Ruby, Madison, Julia... They're all watching. I can't fail them."
    scene footep592
    with vpunch
    d "This time, it’s THE ONE!"
    scene footep593
    $ renpy.movie_cutscene("images/animation/heroshot.webm", stop_music=False)
    scene footep593
    with dissolve
    scene black
    with fade
    pause 0.5
    scene footep594
    with fade
    scene black
    with fade
    scene footep595
    with fade
    hec "No... This isn't possible!"
    scene footep596
    with dissolve
    julia "He made it!"
    scene footep597
    with dissolve
    dpense "It’s the winning goal. We won!"
    scene footep598
    with dissolve
    d "I did it!"
    d "Haha!"


    scene footepautres10
    with dissolve
    emerick "Damn it!"
    kira "The final’s going to be fun!"
    beth "Hmm..."
    scene black
    with fade

    scene footep599
    with vpunch
    ruby "You're the best Cortex!"
    d "Can't do nothing without you Minus!"
    mad "We gave it all, and it paid off. We deserve this final."
    dpense "The girls congratulate each other, smiles light up their faces. It’s a well-earned victory."
    if mcheromatch2 > 1:
        orushi "Man of the match : [name]!"
        $ Achievement.add(achievement_motm)
        $ achievement.grant("motm")
        $ achievement.sync()
    ruby "[name]! Can you meet up with me after?"
    d "Sure! Just give me time to shower and change and I'll be right out!"
    stop music fadeout 2
    scene black
    with fade
    pause 3
    jump ep4p2s4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
