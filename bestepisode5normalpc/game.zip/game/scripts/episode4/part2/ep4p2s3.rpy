label ep4p2s3:

    $ charlottewing = False

    $ buddy_unlocked = False
    $ buddy_activated = False
    $ temp_unlocked = False
    $ temp_activated = False
    $ sport_unlocked = False
    $ sport_activated = False
    $ educ_unlocked = False
    $ educ_activated = False







    $ firstTimeSkillTree = True

    $ firstTimeUnlockedTemperamentSpecialization = True
    $ firstTimeUnlockedSportSpecialization = True
    $ firstTimeUnlockedEducationSpecialization = True
    $ firstTimeUnlockedBuddySpecialization = True






    $ isEnabledTemperamentSpecialization = False
    $ isEnabledSportSpecialization = False
    $ isEnabledEducationSpecialization = False
    $ isEnabledBuddySpecialization = False




    python:
        for elt in onlystanPosts:
            if elt.id == 4:
                onlystanPosts.remove(elt)

        onlystanPosts = [x for x in onlystanPosts if x.id <= 3]

    if ('KiraPalazioShot' in vars() or 'KiraPalazioShot' in globals()) and KiraPalazioShot:
        $ onlystanPosts.append(OnlystanPost(_("A great night with good company!"), _("Look who we found tonight!"), 2, "phone/assets/polep412.webp", _("Awesome night! Let's do this again anytime!😊"), False))
    else:
        $ onlystanPosts.append(OnlystanPost(_("A great night with my BF!"), _("Partying together!"), 2, "phone/assets/miratest2.jpg", _("Oh! I missed this? Next time I will be there!"), False))


    play music "musique/MAS4685-Feel-GoodCinematicHope-stockmusic-net.mp3" volume 0.2 fadein 2
    scene interep41
    with fade
    dpense "Alright... Tomorrow’s the match."
    dpense "I’ll need to step up against Steven’s team."
    dpense "And Hector... he’ll probably be looking for trouble."
    dpense "Pfff..."
    scene interep42
    with dissolve
    $ globalnotif += 1
    $ appnotif += 1
    $ rubyphonep4inter = True
    if JuliaHopital:
        $ globalnotif += 1
        $ appnotif += 1
        $ juliaphonep4inter = True
    if redep4 == True:
        dpense "Red asked me to send her a message."
        dpense "Let’s get it done... At least it’ll be out of the way."
        call phone_discussion_beth from _call_phone_discussion_beth
        $ CharacterBio.findCharacterByName("Elizabeth").hearts = 2
        dpense "Well, that’s something, I guess."
    if graceep4 == True:
        dpense "What an afternoon with Grace..."
        dpense "Her warmth, her laughter... and that moment in the jacuzzi. Unforgettable."
    if blueep4 == True:
        dpense "The evening at Sofia’s place was incredible."
        dpense "She’s opening up to me completely, while Red stays back, always on guard."


    show screen telephone()
    label roommcep42:
    if globalnotif>0:
        show screen telephonenotif()
    if globalnotif==0:
        hide screen telephonenotif
    menu:
        "Pass":


            $ globalnotif = 0
            $ appnotif = 0
            $ juliaphonep4inter = False
            $ rubyphonep4inter = False
            hide screen telephone
            hide screen telephonenotif
            pause 1 
            play sound "sound/vibration.mp3" volume 1
            d "Humm?"
            $ phone.menu = False
            phone discussion "ji1":
                time year 2023 month 9 day 7 hour 23 minute 15
                "ji" "You're doing great [name]."
                "d" "What do you want from me?"
                "ji" "Just listen to me."
                "ji" "Play for you."
                "d" "What does that mean?"
                "ji" "Time will come."
                "d" "Come on! This is cryptic!"
                "ji" "Once we meet, remember this."
                "d" "remember what?"
            phone end discussion
            dpense "AND... no response..."
            dpense "Alright, time to get some sleep... even if my head is still all over the place."
            if ('chatextmass' in vars() or 'chatextmass' in globals()) and chatextmass:
                play sound "sound/vibration.mp3" volume 1
                d "Again? What's this?"
                "Charlotte is requesting to add you to her contacts..."
                "Do you want to add her?"
                menu:
                    "Yes":
                        $ renpy.notify (_("NEW CONTACT ADDED"))
                        d "What does she want from me?"
                        call phone_discussion_cha from _call_phone_discussion_cha
                        d "I didn't get any of that..."
                        $ charlottewing = True
                    "No":

                        d "I have enough people to deal with..."

            dpense "Let’s hope tonight brings me some rest... Or maybe just more weird dreams, as usual."
            stop music fadeout 2
            scene black
            with fade
            pause 2
            jump reverobotchat

label rubyphonep4inter:
    $ phone.menu = False
    phone discussion "ruby2":
        time year 2023 month 9 day 7 hour 23 minute 05
        "d" "Hey, ready for tomorrow?"
        "ruby" "Of course! You?"
        "d" "I’m a little nervous. Steven’s team is tough, and I don’t want to let everyone down."
        "ruby" "Don’t even think about that! They’re strong, sure, but so are we."
        "ruby" "Plus, we’ve got Madison! And you! You’re our secret weapon."
        "d" "Secret weapon, huh? No pressure there."
        "ruby" "Hey, if anyone can handle it, it’s you. You’ve got this."
        "d" "Thanks, Ruby. I’ll do my best."
        "ruby" "I know you will. Just focus on the game, not the scoreboard. We’ll handle the rest."
        if cinema == True:
            "ruby" "Hum... Can I ask you something?"
            "d" "Sure!"
            "ruby" "Tomorrow, after the match..."
            "ruby" "Would you like to come to the cinema with me?"
            "d" "Yes! It would be a pleasure!"
            "ruby" "Great!"
            "ruby" "Thank you so much!!!"
            "d" "I promised to you."
            "d" "Alright. I’ll try to get some sleep. See you tomorrow!"
            "ruby" "You better bring your A-game tomorrow, because we’re taking them down. Good night!"
        else:
            "d" "Alright. I’ll try to get some sleep. See you tomorrow!"
            "ruby" "You better bring your A-game tomorrow, because we’re taking them down. Good night!"
    phone end discussion
    pause 1
    $ globalnotif -= 1
    $ appnotif -= 1
    $ rubyphonep4inter = False
    jump roommcep42

label juliaphonep4inter:
    $ phone.menu = False
    phone discussion "julia1":
        time year 2023 month 9 day 7 hour 23 minute 10
        "d" "Hey, remember earlier at the hospital? I found something weird in my pocket: '1410'."
        "julia" "What? That’s random."
        "d" "I have no idea where it came from. That’s why I’m asking you."
        "julia" "I… don’t think it rings a bell. Maybe it’s a date? 14/10? Or a time? 14:10?"
        "d" "No, it’s just '1410'. Plain and simple."
        "julia" "Hmm… That’s strange. Do you think someone might have slipped it into your pocket?"
        "d" "Honestly, I don’t know. Maybe. It’s weird though."
        "julia" "Yeah… With everything going on today, I didn’t even notice."
        "julia" "But this is kind of unsettling."
        "d" "I’ll let you know if I figure it out."
        "julia" "Please do. Good night!"
        "d" "Good night, Julia."
    phone end discussion
    pause 1
    $ globalnotif -= 1
    $ appnotif -= 1
    $ juliaphonep4inter = False
    jump roommcep42

label reverobotchat:
    scene black
    with fade
    pause 2 
    play music "musique/Aerocity-Stranger.mp3" volume 0.5
    with flash
    scene prepinterep41
    with fade
    dpense "Everything feels... strange. I’m not sure where I am, but it feels oddly familiar, like a memory I can’t quite grasp."
    scene prepinterep42
    with dissolve
    d "What is this place?"
    scene prepinterep43
    with hpunch
    "You’ve come far, but there’s more ahead."
    dpense "Who’s there?"
    scene prepinterep44
    with dissolve
    "Your choices shape the path. The outcome is never fixed."
    with flash
    scene black
    pause 1 
    with flash
    scene prepinterep45
    with vpunch
    dpense "Where am I?"
    dpense "There’s a mechanical hum in the air."
    scene prepinterep46
    with flash
    dpense "What's this?"
    scene prepinterep47
    with flash
    pause 0.5
    scene prepinterep48
    with hpunch
    dpense "A... robocat?"
    scene prepinterep49
    with hpunch
    d "Mr. Rufus? Is that you?"
    "Profile activated."
    dpense "What? What does that mean?"

    scene prepinterep50
    with hpunch
    "Analyze."
    scene prepinterep51
    with hpunch
    "Adapt."
    scene prepinterep52
    with hpunch
    "Act."
    with flash
    scene black
    pause 0.5
    d "What are you talking about? Adapt to what?"
    "The pieces are in motion. You are one of them."
    d "Pieces? Motion? What does any of this mean?"
    "The time has come. Wake up... and remember."
    "PROFILE ACTIVATED."
    scene prepinterep53
    with fade
    play sound "sound/vibration.mp3" volume 1
    dpense "That dream... It felt so vivid. The robot cat, the voice... What does 'Profile activated' even mean?"
    play sound "sound/vibration.mp3"
    pause 0.5
    "PROFILE ACTIVATED" with hpunch
    d "What???"
    scene prepinterep54
    with dissolve
    d "Is this my phone?"
    scene prepinterep55
    with dissolve
    pause 2


    scene black
    show expression "phone/assets/arbre_talents/skill_tree_enabled_screen.png" at center with dissolve
    pause
    hide expression "phone/assets/arbre_talents/skill_tree_enabled_screen.png"
    $ skillTreeUnlocked = True
    call screen phone_skilltree()
    stop music fadeout 2 
    jump match2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
