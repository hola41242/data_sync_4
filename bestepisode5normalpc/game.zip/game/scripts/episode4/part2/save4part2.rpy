label save4part2:
    pause 2
    with fade
    show text _ ("SAVE NOW") at truecenter
    "Please save your game here..."
    stop music fadeout 2.0
    pause 3
    with dissolve
    hide text
    pause 1
    scene black
    with fade
    pause 1
    jump e5intro
    play music "musique/MaxKoMusic-OdeToTheWinners.mp3" 
    pause 1.25
    scene coming
    with zoomout
    pause 4
    scene black
    with fade
    pause 0.5
    scene comingep51
    with fade
    pause 2
    scene comingep52
    with fade
    "All my condolences."
    pause 2
    scene black
    with fade
    pause 0.5
    scene comingep54
    with fade
    orushi "Due to the recent events I think it's time for the showdowns!"
    pause 2
    scene black
    with fade
    pause 0.5
    scene comingep53
    with fade
    mad "I will go into Orushi's tower and I will find what's going on!!!"
    pause 2
    scene black
    with fade
    pause 0.5
    orushi "First showdown will be [name]..."
    pause 2
    scene comingep55
    with fade
    orushi "versus Grace!"
    scene comingep56
    with dissolve
    pause 5
    stop music fadeout 5
    scene black
    with fade
    pause 5
    jump e5intro
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
