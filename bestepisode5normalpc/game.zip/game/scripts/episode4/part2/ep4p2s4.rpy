label ep4p2s4:

    scene black
    with fade
    play music "musique/TBI02-Daydream-Teichert.mp3" volume 0.5
    pause 2
    scene finep41
    with fade
    pause 2 
    scene finep42
    with dissolve
    pause 2
    scene finep43
    with dissolve
    ruby "I still can't believe we won! That match was intense."
    scene finep44
    with dissolve
    d "Yeah, but the final’s gonna be even tougher. We have to stay sharp."
    scene finep45
    with dissolve
    ruby "Pfft, with me around? We got this!"
    stop music fadeout 3
    pause 3
    play music "<from 20>musique/KaiEngel-TheRun.mp3" volume 0.5 fadein 2
    scene black
    with fade
    pause 2
    scene finep46
    with fade
    pause 2
    scene finep47
    with fade
    pause 2 
    scene finep48
    with fade
    pause 2
    scene black
    with fade
    pause 2
    scene finep49
    with hpunch
    pause 2
    scene finep410
    with dissolve
    emerick "You again? Don't you ever get tired of being in my way?" with hpunch
    d "Maybe you should stop walking into me then."
    emerick "You think you're untouchable just because of your wins? News flash, you're nothing."
    scene finep411
    with dissolve
    ruby "Emerick, this is pointless. Just let it go."
    emerick "Stay out of this, Ruby."
    ruby "I’m serious. This is childish."
    scene finep412
    with hpunch
    pause 2
    d "You missed."
    scene finep413
    with hpunch
    ruby "Both of you, stop!"
    scene finep414
    with hpunch
    emerick "Get away!"
    stop music fadeout 2
    ruby "Ahhhh!" with hpunch
    play music "<from 68>musique/KaiEngel-TheRun.mp3" volume 0.5 fadein 2
    pause 0.5 
    scene finep415
    with dissolve
    pause 2 
    play sound "sound/Vooh.wav" volume 1
    scene finep416
    with flash
    with vpunch
    pause 2 
    scene black
    with fade
    pause 1
    scene finruby1
    with fade
    play sound "sound/coeur.wav" volume 1
    pause 1
    scene black
    with fade
    scene finruby2
    with fade
    pause 1
    scene black
    with fade
    scene finruby3
    with fade
    pause 1
    scene black
    with fade
    scene finruby4
    with fade
    stop sound
    pause 3
    d "RUBY!!!!!!!!!!" with hpunch
    pause 1
    scene black
    with fade
    $ Achievement.add(achievement_endep4)
    $ achievement.grant("endep4")
    $ achievement.sync()
    play sound "sound/cinematic impact.mp3" volume 1
    pause 2

    if persistent.rufusgame > 15:
        $ persistent.rufusgame = 15


    jump e5intro
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
