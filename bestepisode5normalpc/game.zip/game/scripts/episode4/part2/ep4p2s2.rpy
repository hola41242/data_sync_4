label ep4p2s2:
    if _in_replay:
        show screen Replayexit 
    scene black
    with fade
    pause 1
    play music "musique/ALM0187-RomanticLoveStory-stockmusic-net.mp3" volume 0.2
    scene ep4p2s2r1
    with dissolve
    dpense "This is where Sofia asked me to meet her. She shouldn’t be long now."
    scene ep4p2s2r2
    with dissolve
    pause 2 
    scene ep4p2s2r3
    with dissolve
    sofia "Ah, there you are! I saw you wandering the neighborhood like a lost detective."
    dpense "She seems to be in a good mood. Good, I was feeling a little nervous."
    d "Just soaking up the atmosphere."
    scene ep4p2s2r4
    with dissolve
    scene ep4p2s2r5
    $ renpy.movie_cutscene("images/animation/blueep4.webm", stop_music=False)
    scene ep4p2s2r5
    pause 1 
    sofia "If you continue like that, I won't let you go."
    d "Would you really stop me?"
    scene ep4p2s2r6
    with hpunch
    pause 2 
    scene ep4p2s2r7
    with dissolve
    pause 2
    scene ep4p2s2r8
    with dissolve
    sofia "Come on, follow me. My house is just over there."
    d "Are your parents home tonight?"
    sofia "No, as usual, they’re away on business. But don’t worry, Elizabeth and I can handle things."
    scene ep4p2s2r9
    with dissolve
    dpense "Traveling so much... It must be strange growing up without seeing them often."
    d "It must be quiet without your parents around."
    scene ep4p2s2r10
    with dissolve
    sofia "Too quiet, sometimes, but it's been like this most of our lives. We did ask our parents to let us live in the guest house..."
    scene ep4p2s2r11
    with dissolve
    pause 2
    scene ep4p2s2r12
    with dissolve
    pause 2
    sofia "Elizabeth, look who’s here."
    scene ep4p2s2r13
    with dissolve
    beth "I see. You managed to convince him to come along."
    scene ep4p2s2r14
    with dissolve
    d "Good evening, Elizabeth."
    scene ep4p2s2r15
    with dissolve
    beth "Good evening. I’m cooking dinner, so no fooling around while I’m in the kitchen."
    dpense "She’s straight to the point. As always."
    scene ep4p2s2r16
    with dissolve
    sofia "She acts like the boss, but she’s happy you’re here."
    scene ep4p2s2r17
    with dissolve
    sofia "Sit down, let’s chat for a bit. So, this competition... What do you think?"
    d "It’s intense."
    scene ep4p2s2r18
    with dissolve
    sofia "Yeah, everybody is on edge."
    sofia "Emerick is unbearable. He thinks he can do whatever he wants."
    scene ep4p2s2r19
    with dissolve
    beth "He’s annoying, but he knows how to play his cards."
    dpense "Elizabeth always seems to have a plan. She never says anything without a reason."
    scene ep4p2s2r20
    with dissolve
    sofia "Grace’s girls, on the other hand, they’re interesting. Ruby has a unique temperament. Julia is sweet. Grace is charming, and Madison is... complicated."
    beth "Aren’t you idealizing them a bit? They all have their flaws."
    d "And what about you, Elizabeth? What do you think of the group?"
    scene ep4p2s2r21
    with dissolve
    beth "I prefer to observe. I need all the facts before making any alliances."
    dpense "Alliances? Now that’s an interesting word. She sees this competition as a chess game."
    d "And who do you see as potential allies, then?"
    scene ep4p2s2r22
    with dissolve
    beth "Those who think before they act. Those who understand that every move matters."
    dpense "She’s trying to size me up... But I’m not going to show my hand so easily."
    d "I guess that means you’re observing my choices too?"
    scene ep4p2s2r23
    with dissolve
    beth "Everyone’s observing everyone. The real question is: what are you observing?"
    dpense "She’s turning the situation around. She’s impressive, but I’m not going to let her shake me."
    d "I’d say I’m mostly observing what others are hiding."
    beth "Interesting. Maybe you’re not so naive after all."
    scene black
    with fade
    pause 1.0
    scene ep4p2s2r24
    with dissolve
    sofia "That was amazing! Thank you Beth!"
    d "Yeah, it was delicious."
    beth "I know. You're welcome."
    scene ep4p2s2r25
    with dissolve
    sofia "Elizabeth and I are different, but we complement each other."
    d "It shows. You have a unique dynamic."
    scene ep4p2s2r26
    with dissolve
    beth "Unique, yes. And sometimes exhausting."
    d "Does it bother you when people call you 'Red' and 'Blue'?"
    sofia "Honestly, it’s fine, but it always brings us back to constant comparisons."
    scene ep4p2s2r27
    with dissolve
    beth "It’s tiring. We’re individuals, not colors."
    sofia "You know why I accept it? Even if I’m 'Blue', at least I’m not invisible. It was worse before."
    beth "To me, they’re just labels. If people think 'Red' defines me, that’s their problem, not mine."
    dpense "They must have carried this weight for a long time. These kinds of nicknames don’t define who they are."
    scene ep4p2s2r28
    with dissolve
    sofia "That’s also why I changed my style recently. New haircut, new clothes... It helps me stand out."
    beth "Or distance yourself."
    sofia "Not at all! I’m evolving, Elizabeth. It has nothing to do with you."
    dpense "It seems like this topic strikes a sensitive chord between them."
    scene ep4p2s2r29
    with dissolve
    beth "When you look in the mirror, maybe you see someone different, but I still see my sister. You don’t need to change."
    scene ep4p2s2r30
    with dissolve
    sofia "It’s not a transformation. It’s... self-expression."
    dpense "Their bond is strong, but their differences are starting to show. Is it because of me? Or just the passage of time?"
    scene ep4p2s2r31
    with dissolve
    sofia "Enough about Beth and I. You’re here as my guest now."
    sofia "I wonder if you really see me as I am, or if you’re putting me in a box too."
    scene ep4p2s2r32
    with dissolve
    d "I see you as the girl who cares too much about what I think."
    sofia "Ah, so you’re admitting it. You don’t think much."
    scene ep4p2s2r33
    with dissolve
    beth "Don't worry about it Sofia. If someone hurts you, they’ll have to deal with me."
    beth "I protect my sister, but I also know how to recognize when someone can be useful."
    d "Should I take that as a threat or an opportunity?"
    scene ep4p2s2r34
    with hpunch
    beth "Both. It depends on you. If you think I'll let my guard down because of our bond, you’re wrong."
    scene ep4p2s2r35
    with dissolve
    sofia "Okay! Come, I want to show you my room."
    stop music fadeout 2
    scene black
    with fade
    pause 2
    play music "musique/ALM0063-EternalLove-stockmusic-net.mp3" volume 0.2
    scene blueep4cham1
    with fade
    sofia "Make yourself comfortable."
    scene blueep4cham2
    with vpunch
    d "It’s cozy in here."
    scene blueep4cham3
    with dissolve
    sofia "Thank you. I wanted this moment with you."
    dpense "She seems sincere. She wants to talk about something important."
    scene blueep4cham4
    with dissolve
    d "What do you want to talk about?"
    sofia "About me. About what people say about me."
    sofia "You know, people think I’m shallow, but it’s just a facade."
    sofia "With Elizabeth being so strong and independent, I had to stand out in a different way."
    dpense "That explains why she seeks to assert herself through her own choices."
    scene blueep4cham5
    with dissolve
    sofia "Being 'Blue' was better than being nobody."
    sofia "Sometimes, I feel like Elizabeth has always been the star, and I was just her shadow."
    sofia "Honestly, all of that is meaningless. I tried to change myself to fit other peoples' perception of me, and it never worked."
    d "What exactly do you mean?"
    sofia "I mean my reputation, what people think of me..."
    scene blueep4cham6
    with dissolve
    sofia "You like my tits hum?"
    d "Yeah! I love touching your soft skin and playing with your nipples."
    sofia "I see that!"
    scene blueep4cham5
    with dissolve
    sofia "So, my reputation, that’s not who I am."
    sofia "I stayed with boys just to show I could be different, but it never meant anything."
    sofia "Only once did I have a real relationship. And it was... disappointing."
    dpense "She’s really opening up. I never would have guessed she had this side of her."
    scene blueep4cham7
    with dissolve
    sofia "With you, it’s different. I feel... normal. Not judged. Not compared. Loved for who I am."
    d "You deserve to be loved for yourself, Sofia. You’re amazing just as you are."
    scene blueep4cham8
    with hpunch
    sofia "Sometimes, I wonder if I deserve someone who truly accepts me. It’s silly, isn’t it?"
    d "Not at all. Everyone has doubts, but if someone doesn’t see your worth, they’re the silly one."
    sofia "I could almost believe you’re a romantic."
    sofia "Thank you... because of you, I feel like I’ve found someone who sees beyond the surface."
    dpense "These moments with her are precious. She’s so much deeper than the rumors about her."
    scene blueep4cham9
    with hpunch
    sofia "Enough serious talk! Did you know I changed my room’s decor just for you?"
    d "Oh yeah? What was it like before?"
    if persistent.patch_enabled:
        if persistent.rufus11 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
    sofia "Unicorn posters and heart-shaped string lights."
    dpense "She’s joking, but the idea is adorable."
    d "I’m sure it would have had its charm."
    scene blueep4cham10
    with dissolve
    sofia "Honestly, I should’ve kept the unicorns. It would’ve impressed you."
    d "Definitely, I’m easily impressed."
    if persistent.rufus11 == False:
        scene blueep4cham11 with dissolve
        show screen chat11() with dissolve
    else:
        scene blueep4cham11
        with dissolve
    sofia "My sister is downstairs so..."
    sofia "We can't make too much noise."
    sofia "But I have an idea."
    d "I think I will like it."
    sofia "I'm sure you will!"
    hide screen chat11
    stop music fadeout 2
    scene blueep4cham12
    with dissolve
    sofia "I think my little friend here is asleep."
    sofia "I will wake him. Now, take your clothes off."
    scene black
    with fade
    pause 1 
    scene blueep4cham13
    with dissolve
    sofia "That's better!"
    scene black
    with fade
    pause 1
    play music "musique/Lyvo-Home.mp3" volume 0.5
    play movie "images/animation/bluep4job.webm" volume 0 noloop
    show movie with fade
    ""
    pause 5
    d "Sofia... you're... unreal..."
    scene bluejob2
    stop movie
    with dissolve
    sofia "Hushhh. Don't make any noise..."
    d "Yeah."
    scene bluejob3
    with dissolve
    sofia "My sister could hear us."
    d "But..."
    scene bluejob4
    with vpunch
    sofia "Hmmmm Hmmm..."
    d "I won't last long..."
    scene bluejob1
    with dissolve
    pause 1 
    play movie "images/animation/bluejobbouclelente.webm" loop
    show movie
    d "Sofia..."
    sofia "Don't worry..."
    d "I will..."
    sofia "I know... You're twitching!"
    scene bluejob1
    with hpunch
    stop movie
    play movie "images/animation/bluejobbouclerapide.webm" loop
    show movie
    d "I..."
    sofia "Do it..."
    d "In your mouth?"
    sofia "Hmm hmm!"
    stop movie
    with flash
    with hpunch
    scene bluejob4
    with vpunch
    with flash
    with hpunch
    scene bluejob5
    with vpunch
    with flash
    sofia "Hmmmm..."
    with flash
    with hpunch
    scene bluejob6
    with dissolve
    sofia "It tastes like pineapple!"
    d "Ahah... Unbelievable!"
    sofia "Get dressed and head downstairs before Elizabeth comes to check on us. She might grill you more than the dinner!"
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    scene black
    with fade
    stop music fadeout 2
    pause 2  
    play music "musique/Meydan-Changes.mp3" fadeout 2 volume 0.5
    scene blueep4fin1
    with fade
    pause 2 
    scene blueep4fin2
    with dissolve
    beth "Hey, you. If you ever hurt my sister, you’ll have to deal with me."
    dpense "Note to self: never cross Elizabeth."
    d "I understand. Are you keeping an eye on me in the competition too?"
    beth "Of course. Every move you make matters. If you’re smart, you’ll understand that our rivalry doesn’t rule out opportunities."
    d "Opportunities?"
    scene blueep4fin3
    with dissolve
    beth "Maybe. As long as you know your place. Don’t get the wrong idea. If you think your connection with Sofia gives you an advantage, you’ve already lost."
    dpense "She’s formidable. An opponent, but also a potential ally if I play my cards right."
    beth "In this game, allies aren’t friends. They’re leverage. So think carefully: will you be leverage for Sofia..."
    beth "Or for me?"
    scene blueep4fin4
    with dissolve
    beth "If you really want to stay in my sister’s life, you’d better prove you’re better than the rest."
    d "And if I can’t?"
    beth "Then you won’t have to worry about what I think, because you won’t be around."
    scene blueep4fin5
    with dissolve
    d "I guess I should stay on my toes."
    beth "And for good reason. Good night."
    scene blueep4fin6
    with dissolve
    beth "Remember, I’m watching. Whether it’s for her... or against you."
    stop music fadeout 2
    scene black
    with fade
    pause 2
    if KiraPalazio == True:
        jump ep4p2s2bis
    else:
        jump ep4p2s3

label rufusg11:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img11"):
        show img11
        hide img11
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus11 = True
    hide screen chat11
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
