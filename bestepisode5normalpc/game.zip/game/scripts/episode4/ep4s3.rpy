label ep4s3i:

    if rubytelpretrial == False:
        hide screen telephone
        hide screen telephonenotif
        jump ep4s3
    else:


        $ appnotif = 1
        $ globalnotif = 1

        d "I will send a message to Ruby to see where they are."

        call screen telephone
        show screen telephonenotif()


label ep4s3:



    play music "musique/MAM0001-TheTrip-stockmusic-net.mp3" volume 0.2 fadein 2
    pause 1
    scene arriveeuniv1
    with fade
    d "Alright, time to kick off the day!"

    scene arriveeuniv2
    with dissolve
    pause 2 
    scene arriveeuniv3
    with dissolve
    d "Oh, hey there! Didn't expect to see you."
    if persistent.patch_enabled == True:
        $ TEMP1 = ep4005
    else:
        $ TEMP1 = ""


    menu:
        "Pet the cat[TEMP1!t]":
            scene arriveeuniv4
            with dissolve
            d "If you're hanging around here... your owner can't be far, right?"
            scene arriveeuniv5
            with dissolve
            rufus "Prrrrrrrr!"
            d "You're a good one, huh?"
            $ Achievement.add(achievement_pet)
            $ achievement.grant("pet")
            $ achievement.sync()
            scene arriveeuniv6
            with dissolve
            pause 2
            scene black
            with fade
            pause 1
        "Don't":
            d "Ugh, I can't stand cats!"
            scene arriveeuniv7
            with hpunch
            rufus "Hsssss!"
            d "Yeah, yeah, hiss all you want."
            scene black
            with fade
            pause 1


    scene arriveeuniv9
    with dissolve
    pause 1
    d "Wow!"
    scene arriveeuniv8
    with dissolve
    pause 1


    if Redpath:
        scene arriveeuniv10
        with dissolve
        beth "Follow me."
        d "Oh... Okay..."
        scene arriveeuniv11
        with dissolve
        beth "There's going to be a challenge in a few minutes."
        beth "I already know what we need to do."
        beth "And I know where the items we need to find are."
        scene arriveeuniv12
        with dissolve
        beth "You’ll need to pick your partner for today."
        beth "Choose me."
        d "Oh... Uh..."
        jump drewappelep4

    if bluelove:
        scene arriveeuniv10
        with dissolve
        beth "I know about you and my sister."
        d "Oh... Okay..."
        scene arriveeuniv11
        with dissolve
        beth "You better not..."
        scene arriveeuniv13
        with dissolve
        sofia "Leave him alone!"
        beth "Sofia!"
        beth "Oh, screw this. Figure it out yourselves."
        scene arriveeuniv14
        with dissolve
        sofia "I followed my sister last night to see what she was up to."
        sofia "I know where she went poking around."
        scene arriveeuniv15
        with dissolve
        sofia "Want to team up for the challenge?"
        d "Oh... Uh..."
        jump drewappelep4

    scene arriveeuniv16
    with dissolve
    d "Hey everyone!"
    scene arriveeuniv17
    with dissolve
    d "Are we ready for the day?"
    scene arriveeuniv18
    with dissolve
    ruby "Ready? I’m *so* excited!"
    d "Hmm... Ruby..."
    ruby "Yeah?"
    scene arriveeuniv19
    with hpunch
    d "Tifa? Seriously?"
    ruby "Hey! She’s a fighter, and I’m feeling like a fighter today!"
    scene arriveeuniv201080 with Fade(0.1, 0.0, 0.5, color="#fff")
    with hpunch
    ruby "Shush!"
    d "Alright... More like Yuffie then."
    scene arriveeuniv21
    with dissolve
    ruby "Grace told me there’s going to be a new challenge today. It’s going to be epic!"
    d "Seriously?"
    scene arriveeuniv22
    with dissolve
    grace "Yes. My mom was up at the crack of dawn getting everything ready."
    d "That sounds intense."
    scene arriveeuniv23
    with dissolve
    mad "And my parents seemed to know something was up too."
    d "What do you mean by that?"

label drewappelep4:
    scene arrivorushi1
    with vpunch
    drew "Attention, all B.E.S.T participants!"
    drew "Please make your way to the auditorium immediately!"
    d "Guess it’s showtime…"
    stop music fadeout 1
    scene black
    with fade
    pause 1
    play music "musique/MYO0005-ScienceAndTechnology-stockmusic-net.mp3" volume 0.2 fadein 2
    scene arrivorushi2
    with dissolve
    drew "Dear participants."
    drew "You started this journey as one hundred. Now, only forty of you remain."
    drew "And today, the stakes are getting even higher."
    scene arrivorushi3
    with dissolve
    drew "It is my great pleasure..."
    drew "And distinct honor to introduce you..."
    scene arrivorushi4
    with dissolve
    drew "Hummm..."
    scene arrivorushi5
    with dissolve
    drew "Mr. Orushi from Orushi Corp.!"
    scene arrivorushi6
    with dissolve
    orushi "Thank you, Mrs. Drew."
    scene arrivorushi7
    with dissolve
    rufus "Meowwwwww..."
    scene arrivorushi8
    with dissolve
    scene arrivorushi9
    $ renpy.movie_cutscene("images/animation/orushipres.webm", stop_music=False)
    scene arrivorushi9
    with dissolve
    orushi "And thank you all for such a warm welcome."
    orushi "Students..."
    scene arrivorushi10
    with dissolve
    orushi "I am thrilled to be part of this extraordinary competition with you."
    orushi "Today marks a major turning point, as only half of you will advance after this challenge."
    scene arrivorushi11
    with dissolve
    orushi "We’ve tested your athletic abilities in the first challenge."
    orushi "And your general knowledge in the second."
    scene arrivorushi12
    with dissolve
    orushi "Now, we will test your understanding of the world around you."
    orushi "Today’s challenge is an orienteering race."
    orushi "It’s a timed event, and your ranking will depend entirely on how fast you complete it."
    scene arrivorushi13
    with hpunch
    orushi "In short: the faster you finish, the higher your rank."
    orushi "Give it everything you’ve got, and above all... Be the B.E.S.T!"
    scene arrivorushi14
    with dissolve
    orushi "Now, I’ll let you Mrs. Drew go over the rules."
    mad "If I win this, I'm first!"
    ruby "Really?"
    mad "Yeah I'm just behind Emerick... I have to win"
    dpense "Humm..."
    scene arrivorushi15
    with dissolve
    drew "Thank you, Mr. Orushi."
    drew "Here’s how it works."
    scene arrivorushi16
    with dissolve
    drew "In just a moment, you will all receive an invitation on your phones"
    play sound "sound/vibration.mp3" volume 1 
    with hpunch
    pause 1
    scene xpep41
    with dissolve
    drew "Accept the invitation, and it will install the B.E.S.T app. This app will be essential for the competition moving forward."
    d "Are they even allowed to do this?"
    ruby "You can refuse if you want, but you can't participate without it."
    d "Guess I don’t have much of a choice."
    drew "The challenge is simple: it’s an orienteering race."
    scene xpep42
    with dissolve
    drew "On your screen, you’ll see a map of various locations you can visit."
    drew "Hints for each location will be listed in the ‘Hints’ section."
    drew "Keep in mind: every movement between locations will cost you time."
    drew "At each good location, you’ll need to find an object with a number on it."
    drew "Your goal is to collect four numbers."
    drew "Once you have all four, return to the auditorium to connect to the app."
    drew "If you’ve collected the correct numbers, a new section of the app will unlock."
    drew "Complete this section to finalize your ranking."
    drew "Here’s the twist: this challenge is a team event."
    drew "You must choose a partner to complete the challenge with."
    drew "Choose wisely."
    drew "Each person has their strengths and weaknesses, and your partner choice will have a significant impact on your results."
    drew "This decision could make or break your performance."
    drew "Take your time, pick your partner, and launch the app."
    drew "Good luck!"
    d "Alright then… let’s do this!"

    $ renpy.take_screenshot()
    $ renpy.save("9-2", "PRETRIAL2")
    "A save has been made in slot 9-2 to backup."



    stop music fadeout 2.0
    scene black
    with fade
    pause 1
    play music "musique/MAK0079-TheHero39sQuest-stockmusic-net.mp3" volume 0.2 fadein 2

label preepreuveep4:


    $ bonus_objects = False
    $ bonus_speed = False
    $ bonus_hint = False
    $ bonus_master = False
    $ bonus_mother = False
    $ bonus_places = False
    $ RubyFinish = False
    $ g_time = 0
    $ em_time = 0
    $ grace_time = 0
    $ emerick_win = False
    $ grace_fin = False

    call screen choixfilleep4()

label redtrialep4:
    scene redversus
    with fade
    $ chosentrial = "Elizabeth"
    $ bonus_objects = True
    beth "Okay, you explore and I will show you where the hidden things are."
    d "Right. Let's go!"
    jump epreuveep4

label maditrialep4:
    scene madiversus
    with fade
    $ chosentrial = "Madison"
    $ bonus_speed = True
    d "Right. Let's go!"
    jump epreuveep4

label juliatrialep4:
    scene juliaversus
    with fade
    $ chosentrial = "Julia"
    $ bonus_hint = True
    d "Right. Let's go!"
    jump epreuveep4

label rubytrialep4:
    scene rubyversus
    with fade
    $ chosentrial = "Ruby"
    $ bonus_master = True
    d "Right. Let's go!"
    jump epreuveep4

label gracetrialep4:
    scene graceversus
    with fade
    $ chosentrial = "Grace"
    $ bonus_mother = True
    d "Right. Let's go!"
    jump epreuveep4

label bluetrialep4:
    scene blueversus
    with fade
    $ chosentrial = "Sofia"
    $ bonus_places = True
    sofia "I will show you where I have seen my sister yesterday!"
    d "Right. Let's go!"
    jump epreuveep4

label rubytelpretrial:
    $ phone.menu = False
    phone discussion "ruby2":
        time year 2023 month 9 day 7 hour 10 minute 00
        "d" "Hey, where are you?"
        "ruby" "In the hall!"
        "d" "Okay coming!"
    phone end discussion
    pause 1
    $ globalnotif -= 1
    $ appnotif -= 1
    $ rubytelpretrial = False
    jump ep4s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
