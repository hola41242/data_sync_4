label ep4s1a:

    pause 1 
    play music "musique/NovaNoma-Gaia.mp3" volume 0.2
    scene e4s1a1
    with fade
    julia "Thanks for coming with me today, [name]."
    scene e4s1a2
    with dissolve
    julia "I really needed it."
    scene e4s1a3
    with dissolve
    d "Hey, no worries. That’s what I’m here for."
    scene e4s1a4
    with dissolve
    d "I told you, I’ve got your back whenever you need me."
    julia "Yeah, I know. But thanks anyway."
    scene e4s1a5
    with hpunch
    d "Wow!"
    julia "What?"
    scene e4s1a6
    with dissolve
    d "No, no... nothing..."
    scene e4s1a7
    with dissolve
    julia "Alright, let’s go in."
    d "Do you want me to wait out here?"
    julia "No, I want you to come with me."
    julia "She's not really there anymore..."
    scene black
    with dissolve
    pause 2
    scene e4s1a8
    with dissolve
    julia "Mom..."
    pause 1 
    scene e4s1a9
    with dissolve
    d "What exactly happened to her?"
    julia "She got breast cancer when she was pretty young."
    julia "It spread to her skin, all over her shoulder and…"
    scene e4s1a10
    with dissolve
    julia "Well, everywhere really."
    julia "Little by little, the tumors spread all over her body… And eventually, it reached her brain."
    scene e4s1a11
    with dissolve
    julia "That’s when they had to put her into a medically induced coma… To stop the pain."
    d "Oh..."
    d "That must’ve been really hard for both of you."
    scene e4s1a12
    with dissolve
    julia "It was hard. Seeing my mom lose her hair while mine was growing in... I had no idea how to take care of it. Not your normal childhood, for sure."
    julia "After a while, she started losing her mind. Having these delusions, like hallucinations from the treatments and the cancer hitting her brain…"
    scene e4s1a13
    with dissolve
    julia "She wasn’t herself anymore. She’d yell at me, saying stuff about my sister… I don’t even have one."
    d "That's awful. Do you have to worry about getting it one day?"
    scene e4s1a14
    with dissolve
    julia "Unfortunately, it’s genetic..."
    julia "I’ve been tested, and thankfully I don't have the markers for it."
    scene e4s1a15
    with dissolve
    julia "But it often skips a generation, so there's always a chance my kids could get it..."
    scene e4s1a16
    with dissolve
    d "I see... That’s got to be a lot to deal with."
    julia "It is, but I just take things one step at a time."
    scene e4s1a17
    with dissolve
    d "I don’t even know what to say..."
    julia "Don’t worry, I’m not asking you to get it or feel sorry for me."
    scene e4s1a18
    with dissolve
    julia "Just you being here with me today means a lot."
    d "Do you come visit her often?"
    julia "I try to come every couple of days."
    scene e4s1a19
    with dissolve
    julia "But between work and school, sometimes I just can’t."
    julia "And the treatments cost a lot..."
    scene e4s1a20
    with dissolve
    julia "But the doctors say… She doesn’t have much time left."
    julia "Mom..."
    scene e4s1a21
    with dissolve
    pause 2
    scene black
    with dissolve
    pause 2
    if persistent.patch_enabled:
        if persistent.rufus15 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
    scene hopitalout
    with fade
    pause 2
    if persistent.rufus15 == False:
        scene e4s1a22 with dissolve
        show screen chat15() with dissolve
    else:
        scene e4s1a22
        with dissolve
    d "So, what are you doing with the rest of your afternoon?"
    julia "Well, I’m gonna chill first. My back’s still hurting a little."
    hide screen chat15
    scene e4s1a23
    with dissolve
    julia "Then I’ve got some classes to catch up on, and my apartment’s a mess..."
    julia "What about you?"

    if gabimusee == True:
        d "I’m meeting up with Gabriella at the museum."
        scene e4s1a25
        with dissolve
        julia "Ohhh yeah, your big date with Ruby’s milf!"
        d "Haha, yeah… I mean, it’s not really a date, but it’s a chance to get to know her better."
        julia "You’ll see, she’s kinda mysterious, but she’s a good person."
        scene e4s1a24
        with dissolve
        julia "She’s our trainer, and she’s super tough."
        julia "Just… Don’t piss her off, you know?"
        d "I’ll do my best to keep things chill!"

    if madidiner == True:
        d "I’ve got dinner with Madison."
        scene e4s1a26
        with dissolve
        julia "Madison? Oh, wow..."
        d "Yeah, I’m going to her place to have dinner with her family."
        scene e4s1a27
        with dissolve
        julia "Oh, wow… Watch out, you’re stepping into big territory there."
        d "What do you mean?"
        julia "Madison’s a Forrester."
        julia "They’re like, the third most influential family in the city after the Orushis."
        julia "So yeah, everything’s about perfection with them."
        julia "Dress nice."
        scene e4s1a28
        with dissolve
        d "Uh… Okay. I’ve still got the suit I wore yesterday. Guess I’ll wear that."
        julia "Yeah, you’ll want to if you want to make a good impression."
        d "Thanks for the tip..."
        julia "No problem!"

    d "I’ve gotta train for the next match, and I should study a bit too..."
    scene e4s1a29
    with dissolve
    julia "Yeah, don’t skip on the training or schoolwork."
    scene e4s1a30
    with dissolve
    stop music fadeout 2
    julia "Well, I’ll leave you here. Thanks again for everything."
    d "Oh, don’t mention it!"
    play music "musique/ALM0187-RomanticLoveStory-stockmusic-net.mp3" volume 0.2 fadein 2

    scene e4s1a31
    with dissolve
    pause 2
    scene e4s1a32
    $ renpy.movie_cutscene("images/animation/juliakiss.webm", stop_music=False)
    scene e4s1a32
    with dissolve
    pause 2
    scene e4s1a33
    with hpunch
    julia "Oh?"
    d "Sorry... in France we kiss both cheeks."
    julia "No, it’s me… I… Uh..."
    scene e4s1a34
    with dissolve
    julia "Well, looks like you stole my first kiss..."
    d "Oh..."
    scene e4s1a35
    with dissolve
    julia "Oh, don’t make that face! I just wasn’t expecting it, that’s all!"
    scene e4s1a36
    with dissolve
    d "Want to try again? This time you’ll be ready for it!"
    julia "Hmm… Maybe later, who knows?"
    scene e4s1a37
    with dissolve
    julia "Alright, see you later!"
    d "See you."
    scene e4s1a38
    with dissolve
    dpense "Julia... There's something so touching about her."
    dpense "Despite everything she’s going through with her mom, she’s so strong. But in moments like these, I can see her vulnerability."
    dpense "That mix of strength and fragility… It’s hard not to feel drawn to her."
    dpense "And that kiss… Well, accidental or not, it was unexpected."
    dpense "Her laughter after it, the way she brushed it off with ease. She’s got a way of making even awkward moments feel natural."
    scene e4s1a39
    with dissolve
    dpense "Did I really just steal her first kiss?"
    dpense "I wonder what this means for us…"
    $ CharacterBio.findCharacterByName("Julia").hearts = 3
    stop music fadeout 1
    pause 1

    $ JuliaHint = True
    scene e4s1a40
    with vpunch
    play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20 fadein 1
    dpense "Wait... What's this in my pocket?"
    dpense "Did someone slip this in without me noticing?"

    scene e4s1a41
    with dissolve
    pause 1
    show text _ ("Take care of her: 1410") at truecenter
    pause 5
    hide text
    scene e4s1a42
    with dissolve
    dpense "1410? What does that mean?"
    dpense "And who left this note? Is this about Julia?"
    scene black
    with fade
    stop music fadeout 2
    pause 2


    if gabimusee == True:
        jump ep4s1b
    if madidiner == True:
        jump ep4s1c
    else:
        jump ep4s2

label rufusg15:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img15"):
        show img15
        hide img15
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus15 = True
    hide screen chat15
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
