label ep4s1c:
    $ CharacterBio.findCharacterByName("Ted").unlock()
    $ CharacterBio.findCharacterByName("Cassie").unlock()
    $ CharacterBio.findCharacterByName("Charles").unlock()
    $ CharacterBio.findCharacterByName("Carmen").unlock()
    scene black with fade
    pause 2
    play music "musique/Aerocity-Stranger.mp3" volume 0.2 fadein 2 
    scene ep4s1c1
    with dissolve
    d "She asked me to wait for her at the corner..."
    pause 2
    scene ep4s1c2
    with dissolve
    d "Hmm... That should be her now."
    scene ep4s1c3
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene ep4s1c4
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene ep4s1c5
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 2
    scene ep4s1c6
    with dissolve
    pause 0.2
    scene ep4s1c7
    $ renpy.movie_cutscene("images/animation/carmadi.webm", stop_music=False)
    scene ep4s1c7
    with dissolve
    pause 0.2
    scene ep4s1c8
    with dissolve
    if GabyHeat == True:
        mad "Are you kidding me? Do you even know what time it is?"
        d "Sorry, I had an appointment with Gabriella and..."
        mad "I don't care!" with hpunch
        mad "Sometimes, I feel like you do this on purpose!"
        $ CharacterBio.findCharacterByName("Madison").hearts = 1
        d "No, but..."
    mad "Are you ready? Shall we go?" with hpunch
    d "Yeah, let's go."
    scene ep4s1c9
    with dissolve
    dpense "She seems nervous... well, more than usual..."
    scene ep4s1c10
    with dissolve
    d "Is everything okay? You seem a little... tense."
    mad "My parents aren't easy to impress. Especially my dad."
    d "What do you mean by impress?"
    scene ep4s1c11
    with dissolve
    mad "Let's just say he's demanding. Too demanding."
    mad "Tonight, it'd be best if you didn’t talk too much, especially about sensitive topics."
    mad "And whatever you do, don’t contradict him. Even if you disagree."
    d "Got it, I'll stay quiet."
    mad "Thanks... I appreciate it."
    scene ep4s1c10
    with dissolve
    pause 1 
    scene black
    with fade
    pause 1
    scene ep4s1c12
    with dissolve
    pause 1 
    scene ep4s1c13
    with dissolve
    pause 1
    scene ep4s1cmaison1
    with dissolve
    pause 1
    scene ep4s1cmaison2
    with dissolve
    mad "We're here."
    scene ep4s1cmaison3
    with dissolve
    pause 1 
    scene ep4s1cmaison4
    with dissolve
    pause 1
    scene ep4s1cmaison5
    with dissolve
    cassie "Mommy!"
    mad "Hey, sweetie."
    scene ep4s1cmaison6
    with dissolve
    mad "It's almost time for bed, isn't it?"
    scene ep4s1cmaison7
    with dissolve
    cassie "Yeah, but I wanted to give you a hug first!"
    scene ep4s1cmaison8
    with dissolve
    pause 1
    scene ep4s1cmaison9
    with dissolve
    dpense "Funny face..."
    pause 1
    scene ep4s1cmaison10
    with vpunch
    cassie "It's my Mr. Kitty!"
    d "Oh?"
    scene ep4s1cmaison11
    with dissolve
    menu:
        "Boo!":
            d "Boo!"
            scene ep4s1cmaison12
            with hpunch
            cassie "Mommy!"
            mad "What an idiot!"
        "Hello?":
            d "Hmm... Hello?"
            scene ep4s1cmaison13
            with hpunch
            cassie "Mommy!"
            mad "Don't be afraid Cassie! He doesn't bite!"
    scene ep4s1cmaison14
    with dissolve
    mad "She's shy..."
    stop music fadeout 1
    scene ep4s1cmaison15
    with hpunch
    ted "Finally showed up, huh?"
    play music "musique/PhilippWeigl-SubdivisionOfTheMasses.mp3" volume 0.2 fadein 2 
    scene ep4s1cmaison16
    with dissolve
    mad "And you? Still here doing nothing as usual."
    ted "I'm here to help, unlike some people."
    scene ep4s1cmaison17
    with hpunch
    charles "He's right, Madison. Your brother is sacrificing himself to take care of your daughter while you're off with your classes and football."
    scene ep4s1cmaison18
    with dissolve
    mad "I'm working hard to succeed, Dad."
    scene ep4s1cmaison19
    with dissolve
    charles "Succeed? You call this success? Look at where you are."
    charles "Look at the Da Fonseca twins, Elizabeth and Sofia, and even Emerick! They’re always ahead of you."
    mad "I'm doing my best, Dad."
    scene ep4s1cmaison20
    with dissolve
    charles "Your best isn't good enough. You're a Forrester!"
    scene ep4s1cmaison21
    with dissolve
    charles "Our family should be the most powerful in this town, and you're not even close."
    scene ep4s1cmaison22
    with dissolve
    charles "Meanwhile, your brother is here, sacrificing for you so you can chase after results that aren’t even worthy of our name."
    scene ep4s1cmaison23
    with hpunch
    mad "He's not sacrificing anything! He's just staying home cause he knows you will just give him your empire!"
    mad "What has he done?! He hasn't applied for university or a job, nothing!"
    scene ep4s1cmaison24
    with dissolve
    charles "Madison, look at yourself. You're a disappointment compared to what I expect from you."
    charles "And your brother is holding this family together, unappreciated. You're not even close to where you should be."
    mad "You think I don’t feel it? The weight of being a Forrester, the expectations, the constant judgment?"
    mad "You’ll never understand me. I'm doing everything I can, and it’s never enough for you."
    scene ep4s1cmaison25
    with dissolve
    mad "I will go change and put Cassie to bed... [name], you can sit here until I come back."
    scene ep4s1cmaison26
    with dissolve
    d "Oh? Okay..."
    scene ep4s1cmaison27
    with dissolve
    dpense "Wow, the tension here is unreal."
    dpense "With a father like that and a brother constantly stirring things up, no wonder Madison's always on edge."
    dpense "How can I possibly help her in a situation like this?"
    scene ep4s1cmaison28
    with dissolve
    pause 1 
    scene ep4s1cmaison29
    with dissolve
    pause 1 
    scene ep4s1cmaison30
    with dissolve
    pause 1
    ji "Nice to meet you... [name]?"
    scene ep4s1cmaison31
    with dissolve
    d "Oh?"
    scene ep4s1cmaison32
    with vpunch
    d "Yeah, that's me. It's a pleasure to meet you..."
    d "You must be Madison's... Sister?"
    scene ep4s1cmaison33
    with dissolve
    ji "Oh oh oh! What a charmer! Unfortunately no..."
    scene ep4s1cmaison34
    with dissolve
    carmen "I'm her mother... But you can call me Carmen."
    scene ep4s1cmaison35
    with dissolve
    pause 1 
    scene ep4s1cmaison36
    with dissolve
    carmen "He even has good manners... intriguing."
    scene ep4s1cmaison37
    with dissolve
    carmen "Dinner will be ready in a few minutes."
    scene ep4s1cmaison38
    with dissolve
    pause 1 
    scene ep4s1cmaison39
    with dissolve
    pause 1 
    scene ep4s1cmaison40
    with dissolve
    charles "So, tell me, [name]. Where are you from, exactly? What family do you come from?"
    dpense "Why do I feel like this question is going to end badly..."
    scene ep4s1cmaison41
    with dissolve
    d "Uh... I'm from a regular family. Nothing... remarkable."
    scene ep4s1cmaison42
    with dissolve
    charles "Regular, huh?"
    charles "And what do you do? Any skills, big plans?"
    scene ep4s1cmaison43
    with dissolve
    d "I’m still figuring things out... I don't have any concrete plans yet."
    charles "Still figuring things out, huh?"
    charles "No remarkable background, no solid plans, and yet you’re with my daughter?"
    scene ep4s1cmaison44
    with hpunch
    mad "Dad, this isn’t the time."
    scene ep4s1cmaison45
    with dissolve
    d "?"
    scene ep4s1cmaison46
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene ep4s1cmaison47
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    scene ep4s1cmaison48
    play sound "sound/Photo.mp3" volume 1
    with flash
    pause 0.5
    charles "Madison, you don’t associate with people without a future."
    scene ep4s1cmaison49
    with dissolve
    charles "We’re Forresters, and we don’t lower ourselves to that level."
    mad "This is ridiculous. He’s here with me, and that should be enough."
    scene ep4s1cmaison50
    with dissolve
    charles "No, it’s not. My daughter will not be hanging around a nobody."
    scene ep4s1cmaison51
    with dissolve
    dpense "I knew this would go badly..."
    charles "See? This is exactly what I’ve been saying."
    charles "She’s hanging around with people who have no ambition, and that’s why she’s always falling behind the others."
    charles "Tell me, [name], am I not right?"
    scene ep4s1cmaison52
    with dissolve
    pause 1 
    if persistent.patch_enabled == True:
        $ TEMP1 = ep4003
        $ TEMP2 = ep4004
    else:
        $ TEMP1 = ""
        $ TEMP2 = ""
    menu:
        "Agree with him[TEMP1!t]":

            call buddy_increased from _call_buddy_increased_20
            scene ep4s1cmaison53
            with dissolve
            d "Maybe..."
            dpense "She told me to stay agreeable, but I hate saying this."
            scene ep4s1cmaison55
            with dissolve
            mad "Thank you for dinner, but I can't stay in this atmosphere."
            mad "I’ve had enough. We’re leaving."
            scene ep4s1cmaison62
            with dissolve
            mad "Sorry Mom, but I'm not dealing with this tonight!"
            carmen "But... I already made the chicken!"
            scene ep4s1cmaison63
            with dissolve
            carmen "Charles!"
            charles "What?"
            scene ep4s1cmaison64
            with dissolve
            pause 2
            scene black
            with fade
            pause 2
            jump end_dinner_departure
        "Stand up to the father[TEMP2!t]":

            call temperament_increased from _call_temperament_increased_19
            scene ep4s1cmaison54
            with dissolve
            d "No. You're wrong."
            d "Madison works incredibly hard. She balances her studies, football, and takes care of her daughter."
            d "She’s a strong woman, and she deserves much more respect."
            scene ep4s1cmaison56
            with dissolve
            mad "What are you..."
            d "You don’t see all that she does to succeed, and everything she sacrifices."
            scene ep4s1cmaison57
            with dissolve
            d "She gives her all, and it’s not fair to put her down like this."
            if persistent.patch_enabled:
                if persistent.rufus13 == False:
                    $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
            scene ep4s1cmaison58
            with dissolve
            pause 1 
            scene ep4s1cmaison59
            with dissolve
            pause 0.5 
            scene ep4s1cmaison60
            with hpunch
            charles "How dare you speak to me like that in my own house?!"
            if persistent.rufus13 == False:
                scene ep4s1cmaison61 with dissolve
                show screen chat13() with dissolve
            else:
                scene ep4s1cmaison61
                with dissolve
            carmen "Honey, please, this isn’t the time to get angry. They’re young..."
            charles "Enough! I don’t want to hear it. You two, get out. Now!" with hpunch
            hide screen chat13
            scene ep4s1cmaison55
            with dissolve
            mad "Yeah, yeah. We’re leaving."
            scene ep4s1cmaison62
            with dissolve
            mad "Sorry Mom, but I'm not dealing with this tonight!"
            carmen "But... I already made the chicken!"
            scene ep4s1cmaison63
            with dissolve
            carmen "Charles!"
            charles "What?"
            scene ep4s1cmaison64
            with dissolve
            pause 2
            scene black
            with fade
            pause 2
            jump end_dinner_exclusion

label end_dinner_departure:

    scene finmaisonmad1
    with fade
    d "We should have had some chicken first! No?"
    scene finmaisonmad2
    with dissolve
    d "Or at least a doggy-bag?"
    mad "Just... Get in the car"
    stop music fadeout 2
    scene black
    with fade
    pause 2 
    play music "musique/Nomyn-Fragments.mp3" volume 0.2 fadein 2
    scene madifins1c1
    with dissolve
    mad "Thanks for coming tonight. I know it wasn’t easy."
    d "It’s alright. I'm just sorry things went that way."
    mad "You did what I asked. That’s all I could expect."
    dpense "Why does it feel like something’s unresolved? Like there’s so much left unsaid between us..."
    scene madifins1c2
    with dissolve
    d "Are you... fine?"
    mad "I’m fine. Just... Tired."
    dpense "Tired... Is that really all it is?"
    dpense "..."
    d "Your mother is young no?"
    d "I mean... Your father seems well more aged than her?"
    scene madifins1c4
    with dissolve
    mad "Yeah. They met at a hotel where my mom was working to pay her tuition. She was eighteen."
    mad "They started dating and she got pregnant."
    mad "To avoid scandals... and because my mom is beautiful, my dad married her."
    mad "That's why he reproached me for having a child young."
    mad "He didn't want me to make the same mistakes that him and my mom did..."
    d "Oh. I understand..."
    mad "We’re here."
    scene madifins1c5
    with dissolve
    d "Madison... about tonight"
    mad "Don’t. It’s over. Let’s just forget it."
    mad "Thanks for understanding. Good night."
    d "Good night, Madison."
    d "You know you don’t have to carry everything on your own, right?"
    mad "I know."
    mad "Go inside."
    scene madifins1c6
    with dissolve
    dpense "There’s something more. I can feel it. But why won’t she let me in?"
    stop music fadeout 2
    scene black
    with fade
    pause 1
    jump ep4s2

label end_dinner_exclusion:

    scene finmaisonmad1
    with fade
    d "We should have had some chicken first! No?"
    scene finmaisonmad2
    with dissolve
    d "Or at least a doggy-bag?"
    scene finmaisonmad3
    with dissolve
    mad "I can’t believe him! My father is unbelievable!"
    scene finmaisonmad3
    with dissolve
    d "Madison, I’m sorry, I just thought..."
    scene finmaisonmad4
    with hpunch
    mad "You thought what?! I told you not to confront him! Why can't you ever just listen to me?"
    scene finmaisonmad5
    with dissolve
    mad "You always have to do things your way, don’t you? Why don't you ever listen?"
    scene finmaisonmad6
    with dissolve
    mad "Why do you always go against what I say?"
    scene finmaisonmad7
    with dissolve
    stop music fadeout 2
    mad "Why... Why do you always...?"
    if GabyHeat == True:
        $ CharacterBio.findCharacterByName("Madison").hearts = 2
    else:
        $ CharacterBio.findCharacterByName("Madison").hearts = 3
    if madipath == False:
        scene finmaisonmad8
        with dissolve
        mad "You... With Red..."
        $ Achievement.add(achievement_missopportunity)
        $ achievement.grant("missopportunity")
        $ achievement.sync()
        mad "Just...jump in the car."
        stop music fadeout 2
        scene black
        with fade
        pause 1 
        dpense "Why does it feel like something’s unresolved? Like there’s so much left unsaid between us..."
        play music "musique/Nomyn-Fragments.mp3" volume 0.2 fadein 2
        scene madifins1c1
        with dissolve
        d "Are you... fine?"
        scene madifins1c2
        with dissolve
        mad "I’m fine. Just... Tired."
        dpense "Tired... Is that really all it is?"
        dpense "..."
        d "Your mother is young no?"
        d "I mean... Your father seems well more aged than her?"
        scene madifins1c4
        with dissolve
        mad "Yeah. They met at a hotel where my mom was working to pay her tuition. She was eighteen."
        mad "They started dating and she got pregnant."
        mad "To avoid scandals... and because my mom is beautiful, my dad married her."
        mad "That's why he reproached me for having a child young."
        mad "He didn't want me to make the same mistakes that him and my mom did..."
        d "Oh. I understand..."
        mad "We’re here."
        scene madifins1c5
        with dissolve
        d "Madison... about tonight..."
        mad "Don’t. It’s over. Let’s just forget it."
        mad "Thanks for understanding. Good night."
        d "Good night, Madison."
        d "You know you don’t have to carry everything on your own, right?"
        mad "I know."
        mad "Go inside."
        scene madifins1c6
        with dissolve
        pause 2
        stop music fadeout 2 
        scene black
        with fade
        pause 1
        jump ep4s2

label madicarep4:
    if _in_replay:
        show screen Replayexit 
    play music "musique/AIE0550-YouAreTheOneINeed-stockmusic-net.mp3" volume 0.2 fadein 2   
    scene prekiss1
    with dissolve
    mad "Why are you..."
    scene prekiss2
    $ renpy.movie_cutscene("images/animation/prekiss.webm", stop_music=False)
    scene prekiss2
    with dissolve
    pause 1 
    scene prekiss3
    with dissolve
    mad "Why do you make everything so complicated?"
    scene madikissep41
    with flash
    with hpunch
    pause 1
    scene madikissep42
    $ renpy.movie_cutscene("images/animation/madikissep4.webm", stop_music=False)
    scene madikissep42
    with dissolve
    pause 1
    scene madikissep43
    with dissolve
    pause 1
    mad "Let’s go."
    scene madikissep44
    d "Hum... Where?"
    mad "You'll see."
    scene black
    with fade
    pause 2
    if persistent.patch_enabled:
        if persistent.rufus12 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
    scene madifinep4s1
    with dissolve
    d "Where are we going?"
    scene madifinep4s2
    with dissolve
    pause 2
    scene madifinep4s3
    with dissolve
    dpense "What is she doing?"
    dpense "We are... nowhere..."
    scene madifinep4s4
    with dissolve
    d "So? Where are..."
    if persistent.rufus12 == False:
        scene madifinep4s5 with dissolve
        show screen chat12() with dissolve
    else:
        scene madifinep4s5
        with dissolve
    mad "For once in your life just shut up and do what you're told." with hpunch
    hide screen chat12
    scene madifinep4s6
    with dissolve
    dpense "Is this for real?"
    dpense "I can't even think straight right now..."
    scene madipreviewep42
    with dissolve
    dpense "She needs affection."
    dpense "She needs love."
    scene madifinep4s7
    with dissolve
    dpense "She needs..."
    dpense "Me."
    play movie "images/animation/madisex1ep4.webm" loop
    show movie with fade
    mad "Ahhhh..."
    dpense "I will give you everything Madison."
    mad "More...."
    dpense "You will be treated like a queen, like you should be."
    mad "Stronger!"
    mad "Ahh... Like that... Just like that..."
    mad "Ahhh... Ahhh...Ahhh"
    scene madipreviewep4
    stop movie
    with flash
    scene madipreviewep4
    with vpunch
    with flash
    mad "FUUCCCCCCCCCCCCCKKKKK"
    stop music fadeout 1
    pause 1
    mad "Wait... Let me turn around..."
    d "You are so gorgeous."
    play music  "<from 10>musique/ALG0012-AtmosphericRock-stockmusic-net.mp3" volume 0.2 fadein 2 
    play movie "images/animation/madicarsex.webm" volume 0 loop
    show movie with fade
    ""
    scene madisex4fin
    stop movie
    with flash
    scene madisex4fin
    with dissolve
    with flash
    dpense "If love was a temple..."
    dpense "You would be my religion!"
    d "Did you...?"
    scene madisex5fin
    with dissolve
    mad "Yes... And you?"
    d "Hum... No, but I'm close."
    mad "Okay... Let me do it."
    scene madisex6fin
    with hpunch
    mad "[name]..."
    d "Madison..."
    scene madisex7fin
    with dissolve
    mad "I..."
    scene madisex8fin
    with dissolve
    mad "HUMMMMMMM."
    scene madisex7fin
    with dissolve
    pause 0.3
    scene madisex8fin
    with dissolve
    pause 0.3
    scene madisex7fin
    with dissolve
    pause 1
    scene madisex9fin
    with dissolve
    d "Madison, I..."
    scene madisex10fin
    with vpunch
    mad "Do it! DO IT!"
    mad "AHHHH!"
    d "Madi... I... AAAAHHH!"
    mad "I want to feel..."
    with flash
    with vpunch
    with flash
    with vpunch
    scene madisex11fin
    with flash
    with vpunch
    with flash
    with vpunch
    mad "YOUUUUUUUU!"
    scene madisex12fin
    with dissolve
    mad "I..."
    mad "You're incredible!"
    d "Why?"
    scene madisex9fin
    with dissolve
    mad "Everytime I try to put some barriers with you..."
    mad "And you..."
    pause 1
    mad "Thank you."
    d "You're welcome."
    stop music fadeout 2
    scene black
    with fade
    $ madicarsex = True
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()

label carmadi:
    play music "musique/Nomyn-Fragments.mp3" volume 0.2 fadein 2
    scene black
    with fade
    pause 2 
    scene madifins1c1
    with dissolve
    dpense "And she's silent again..."
    d "Madison, talk to me. You can’t keep doing this. What’s really going on?"
    mad "I’m a Forrester. You and I... We can't do this. We're not supposed to."
    d "What does that even mean? You keep pushing me away, but why?"
    scene madifins1c2
    with dissolve
    mad "I have responsibilities, a name to uphold. You... You don't fit into that. You never will."
    d "Madison, that’s not fair."
    scene madifins1c3
    with dissolve
    mad "Life isn’t fair. Especially for people like me."
    mad "We can’t keep doing this."
    mad "This has to stop."
    dpense "Forrester... Is that really what’s keeping us apart? Or is she just afraid?"
    dpense "I have to change the subject to let her calm down."
    d "Your mother is young no?"
    d "I mean... Your father seems well more aged than her?"
    scene madifins1c4
    with dissolve
    mad "Yeah. They met in a hotel while mom was studying, she was 18."
    mad "They begins a relation and she falls pregnant."
    mad "To avoid scandals... And cause mom is beautiful, he married her."
    mad "That's why he reproach me to have a child early."
    mad "He wanted me to not make the same mistakes that he and her have done..."
    d "Oh... I understand..."
    mad "We're here. Get out."
    scene madifins1c5
    with dissolve
    d "Madison, you know I'm here for you."
    d "You're not alone."
    mad "I know."
    scene madifins1c6
    with dissolve
    dpense "And she's gone."
    dpense "What is she so afraid of?"
    dpense "I won't give up."
    stop music fadeout 2
    scene black
    with fade
    pause 1
    jump ep4s2

label rufusg13:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img13"):
        show img13
        hide img13
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus13 = True
    hide screen chat13
    return

label rufusg12:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img12"):
        show img12
        hide img12
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus12 = True
    hide screen chat12
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
