label save4part1:
    pause 2
    with fade
    stop music fadeout 2.0
    with fade
    show text _ ("SAVE NOW") at truecenter
    "Please save your game here..."
    pause 3
    with dissolve
    hide text
    pause 1

    if graceep4 == True:
        jump ep4p2s1
    if blueep4 == True:
        jump ep4p2s2
    if KiraPalazio == True:
        jump ep4p2s2bis
    else:
        jump ep4p2s3
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
