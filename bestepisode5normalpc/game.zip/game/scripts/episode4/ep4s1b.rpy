label ep4s1b:
    scene black
    pause 1
    play music "musique/MAS4697-LIghtCuriousDramedy-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep4s1b1
    with dissolve
    pause 1 
    scene ep4s1b2
    with dissolve
    pause 1
    "That damn elevator... They really need to replace it." with hpunch
    scene ep4s1b3
    with dissolve
    dpense "Someone’s clearly not having a good day."
    scene ep4s1b4
    with dissolve
    pause 2 
    scene ep4s1b5
    with dissolve
    pause 2 
    scene ep4s1b6
    with dissolve
    pause 2
    scene ep4s1b7
    with dissolve
    pause 2 
    scene ep4s1b8
    with dissolve
    d "I'm here..."
    scene ep4s1b9
    with dissolve
    pause 2
    scene ep4s1b10
    with dissolve
    gaby "Right on time!"
    scene ep4s1b11
    with dissolve
    dpense "She's as sexy as she is strict."
    scene ep4s1b12
    with dissolve
    dpense "Her cleavage..."
    gaby "It's fascinating."
    d "It is..."
    pause 2
    play sound "sound/Scratch.mp3"
    scene ep4s1b13
    with hpunch
    d "Sorry, what?"
    gaby "It’s fascinating to see how ancient civilizations laid the foundations for everything we have today."
    scene ep4s1b14
    with dissolve
    d "Oh! Hum... Yeah!"
    gaby "Even though time has passed, their influence is still here. We may be modern, but our roots are old, deeply embedded in history."
    scene ep4s1b15
    with dissolve
    d "So, we’re like updated versions of the ancient world? Like high-tech tablets based on clay tablets?"
    gaby "That’s one way to put it, but... It’s a little more complex than that."
    dpense "Note to myself: don’t compare ancient civilizations to iPads in front of a professor."
    scene ep4s1b16
    with dissolve
    gaby "What’s important to recognize is that old doesn’t necessarily mean outdated."
    gaby "In fact, what’s ancient is often more stable, more reliable than something new."
    scene ep4s1b17
    with dissolve
    d "So, you’re saying old things have more value than new?"
    d "Like a classic car versus a shiny new one?"
    scene ep4s1b18
    with dissolve
    gaby "Let’s just say, there’s wisdom in experience that you can’t get from something young and untested."
    dpense "Experience, huh? Yeah, she’s got that. I wonder if she realizes how quickly this conversation could... take a turn."
    scene ep4s1b19
    with dissolve
    d "I guess new things are exciting, but they wouldn’t exist without the old, right?"
    d "You could say they complement each other... kinda like a couple."
    scene ep4s1b20
    with dissolve
    gaby "Uh... I was talking about civilizations, but... Yes, that’s an apt comparison."
    dpense "Apt? Almost got an ‘A+’ on that one."
    scene black
    with dissolve
    pause 1 
    scene ep4s1b21
    with fade
    gaby "Take this sculpture, for example. It represents the traditions and values of a bygone era."
    gaby "But those values, even though they’ve evolved, are still present in our society."
    gaby "We’ve adapted them, but their roots are still there. It’s like... Like a foundation from which our society was built on."
    d "Solid foundation. Like you. I mean, not like you-you, but... You know what I mean."
    scene ep4s1b22
    with dissolve
    gaby "Yes, I think I understand."
    dpense "Nice work, [name], you just compared a woman to foundation. If I get away with this, I deserve a medal."
    scene ep4s1b23
    with dissolve
    gaby "These civilizations understood that balancing the old with the new was crucial."
    gaby "It’s not about replacing everything, but evolving while keeping what’s valuable from the past."
    d "So, to evolve, you need to respect the old while embracing the new? That... Makes sense."
    d "What if we did that with, well... Everything?"
    scene ep4s1b24
    with dissolve
    gaby "What do you mean by that?"
    d "I mean, you know, relationships, dynamics. It’s not that different, right?"
    d "Respecting experience and learning from what’s new."
    scene ep4s1b25
    with dissolve
    gaby "Um... I suppose."
    dpense "Bingo. She’s thinking about it. Come on, Gabriella, give me a little smile."
    gaby "What I’m saying is, these civilizations knew that harmony came from understanding their roots, but also being open to new ideas."
    d "Like us, right? An old civilization and a new generation... Exploring new ideas together."
    scene ep4s1b26
    with dissolve
    gaby "That’s... One way to see it, yes."
    dpense "I think she’s starting to come around."
    scene ep4s1b27
    with dissolve
    gaby "There’s more to see upstairs. The next part of the exhibition focuses on how modern life connects back to those ancient foundations."
    $ CharacterBio.findCharacterByName("Gabriella").hearts = 2
    if madidiner == True:
        d "That sounds great, but... I have a dinner planned tonight. I’m supposed to meet Madison."
        scene ep4s1b28
        with dissolve
        gaby "Oh, I didn’t realize you had plans."
        dpense "She doesn’t show it, but I can tell she’s a bit disappointed."
        d "Yeah, I almost forgot about it... I promised I’d be there."

        if persistent.patch_enabled == True:
            $ TEMP1 = ep4001
            $ TEMP2 = ep4002
        else:
            $ TEMP1 = ""
            $ TEMP2 = ""

        menu:
            "Go to the dinner with Madison[TEMP1!t]":
                dpense "I really can’t stay. I made a promise."
                d "Gabriella, I’m really sorry, but I have to go. I can’t stay."
                gaby "Oh... I understand. Dinner plans are important."
                dpense "I can feel her disappointment, but she’s trying to hide it."
                d "I’ll make it up to you, I promise."
                gaby "It’s okay. Go, don’t keep her waiting."
                scene ep4s1b30
                with dissolve
                dpense "I can’t shake the feeling that I’m missing something important by leaving."
                scene ep4s1b31
                with dissolve
                stop music fadeout 2
                pause 1
                jump ep4s1c
            "Stay with Gabriella[TEMP2!t]":

                dpense "Dinner can wait. I’m not ready to leave her yet."
                d "You know what? The dinner can wait."
                scene ep4s1b29
                with dissolve
                gaby "Really? I’m glad."
                dpense "There’s something in her smile that makes it impossible for me to leave now."
                gaby "Alright, let’s head upstairs then."
                jump ep4elevator
    else:

        jump ep4elevator

label ep4elevator:
    if _in_replay:
        show screen Replayexit
    scene black
    with dissolve
    stop music fadeout 2
    pause 1 
    scene ep4s1basc1
    with dissolve
    gaby "We will take the elevator over there to access the second floor."
    scene ep4s1basc1
    with dissolve
    pause 1 
    play sound "sound/ElevatorDoorOpen.mp3" volume 1
    scene ep4s1basc2
    with dissolve
    pause 1
    scene ep4s1basc3
    with dissolve
    pause 1
    scene ep4s1basc4
    with dissolve
    pause 1
    play sound "sound/ElevatorButton.mp3" volume 1
    scene ep4s1basc5
    with dissolve
    pause 2
    scene ep4s1basc6
    with dissolve
    pause 1
    $ GabyHeat = True
    scene black
    with flash
    play sound "sound/PowerDown_BW.mp3" volume 1
    scene ep4s1basc7
    with dissolve
    pause 3
    scene ep4s1basc8
    with dissolve
    gaby "What... What just happened?"
    scene ep4s1basc9
    with dissolve
    d "I think the elevator stopped."
    dpense "Of course, it had to happen now."
    play music "musique/MAS4697-LIghtCuriousDramedy-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep4s1basc10
    with dissolve
    gaby "Is it stuck? What do we do?"
    d "Let’s try calling for help. We’ll get out of here."
    scene ep4s1basc11
    with dissolve
    d "Hello? Is anyone out there? The elevator’s stuck!"
    "We’ve already called the repairman... But he’s not answering. You might be stuck for a while."
    dpense "Great... Trapped in an elevator. Just me and Gabriella. Could be worse... Could definitely be worse."
    gaby "How long do you think we’ll be stuck?"
    "Hard to say. You’ll have to be patient."
    if madidiner == True:
        dpense "Couldn't be worse timing. I'm definitely missing dinner with Madison now..."
    scene ep4s1basc12
    with dissolve
    if madidiner == True:
        d "I should let Madison know I’ll be late."
    dpense "No signal... isn't that just perfect... "
    dpense "So, I guess it's just me and Gaby now, no distractions."
    scene ep4s1basc13
    with dissolve
    gaby "I guess we’re stuck for a while..."
    dpense "Just the two of us, stuck together. Could be interesting."
    scene black
    with fade
    pause 1 
    scene ep4s1basc14
    with dissolve
    pause 0.5
    scene ep4s1basc15
    with dissolve
    pause 0.5 
    scene ep4s1basc16
    with dissolve
    pause 1
    scene ep4s1basc17
    with dissolve
    pause 1
    scene black
    with fade
    pause 1 
    scene ep4s1basc18
    with dissolve
    gaby "It’s getting warm in here. Is it just me?"
    d "No, it’s definitely warmer. Probably because there’s no ventilation."
    scene ep4s1basc19
    with dissolve
    d "Maybe we should... Loosen up a bit. You know, so we don’t overheat."
    scene ep4s1basc20
    with dissolve
    gaby "What? I... No, that’s not necessary."
    d "Look, it’s just the two of us. No one’s going to see."
    scene ep4s1basc21
    with dissolve
    dpense "She’s hesitating, but I can see she’s thinking about it."
    dpense "The heat is making it harder to resist."
    scene ep4s1basc22
    with dissolve
    gaby "I don’t know... It doesn’t feel right."
    dpense "Come on, Gabriella, you’re already sweating. Let it go."
    scene ep4s1basc23
    with dissolve
    d "Trust me, you’ll feel better. I’m going for it."
    stop music fadeout 1
    dpense "I am going to take off my shirt. It’s too hot to care about anything else."
    play music "musique/MYO0008-HipHopAndRockCinematicTrailer-stockmusic-net.mp3" volume 0.2 fadein 2
    scene ep4s1basc24
    with dissolve
    pause 1
    scene ep4s1basc25
    with dissolve
    pause 2
    scene ep4s1basc26
    with dissolve
    pause 1 
    scene ep4s1basc27
    with dissolve
    gaby "I guess... It is."
    scene ep4s1basc28
    with dissolve
    dpense "She's actually taking her jacket off?! Her movements are slow, hesitant..."
    dpense "But she’s doing it. And now I can’t stop looking."
    scene ep4s1basc29
    with dissolve
    pause 1 
    scene ep4s1basc30
    $ renpy.movie_cutscene("images/animation/animasc.webm", stop_music=False)
    scene ep4s1basc30
    with dissolve
    dpense "The way her blouse clings to her skin, that thin layer of fabric, all that hidden beauty, plain to see."
    dpense "Her curves, her body... I can't keep my eyes off of her."
    scene ep4basc31
    with dissolve
    dpense "That blouse hugs her frame perfectly. I can see every line, every curve..."
    scene ep4basc32
    with dissolve
    dpense "Nothing else exists in this moment but her."
    scene ep4basc33
    with dissolve
    gaby "This...This wasn’t how I imagined today going."
    d "Me neither, but I’m not complaining."
    dpense "She’s standing there, just a few feet away. The distance feels smaller, the air between us thick with heat and... Something else."
    scene ep4basc34
    with dissolve
    dpense "She's so close now. Her skin, her body... just out of reach."
    dpense "My heart's racing, and from the way she’s glancing at me... I hope she feels it too."
    gaby "I think... We’re getting a little too close."
    scene ep4basc35
    with dissolve
    dpense "Too close? Is there even such a thing as too close right now?"
    d "Maybe... but sometimes, these things just happen naturally, don’t they?"
    scene ep4basc36
    with dissolve
    dpense "It looks like she wants to say something, but she's not talking."
    dpense "Does she want this too? She's standing right next to me. This tension is driving me wild."
    scene ep4basc37
    with dissolve
    gaby "This is... Wrong, but..."
    dpense "She's looking away, but she's still so close. She might want this as bad as I do."
    scene ep4basc38
    with dissolve
    d "But it feels right, doesn’t it?"
    scene ep4basc39
    with dissolve
    dpense "Her hand is right there. I want to reach, to take it. Closing that last bit of space between us."
    dpense "Her breath is shallow, her chest rising and falling faster. She’s still right here. She must want this too."
    gaby "We shouldn’t..."
    d "Maybe... but do you really want to stop?"
    scene ep4basc40
    with dissolve
    dpense "Still silent, still right in front of me."
    dpense "It’s like we’re frozen, waiting for the inevitable."
    stop music
    play sound "sound/Scratch.mp3"
    scene black
    with flash
    scene ep4basc41
    with dissolve
    play sound "sound/ElevatorRepart.mp3"
    "The repairman’s here! Sorry for the delay. Two minutes and you'll be free."
    scene ep4basc42
    with dissolve
    gaby "Oh! Uh... Thank you!"
    dpense "We were... We almost... What just happened?"
    $ renpy.notify(_("New Scene Gallery added"))
    $ renpy.end_replay()
    scene black
    with fade
    pause 1

    scene ep4basc43
    with fade
    "You’re good to go now."
    d "Right... Thanks."
    stop sound
    scene black
    with fade
    play music "musique/NovaNoma-Gaia.mp3" volume 0.2 fadein 2
    dpense "Finally, we're out of that elevator. She's still looking away though. We almost...."
    scene ep4s1bfin1
    with dissolve
    dpense "I got signal again on my phone, good."
    if madidiner == True:
        d "I should check my messages."
        pause 1
        mad "Where are you?" with hpunch
        mad "You're late!" with hpunch
        mad "Are you seriously ignoring me?" with hpunch
        mad "You better have a good reason for this!" with hpunch
        mad "You're unbelievable." with hpunch
        dpense "Great. Madison is furious. This is going to be fun to explain."
        scene ep4s1bfin2
        with dissolve
        gaby "Everything okay?"
        d "Yeah... Just some messages I need to deal with."
    scene ep4s1bfin2
    with dissolve
    dpense "I can’t stop thinking about what almost happened back there... and what might have happened if we hadn’t been interrupted."
    scene ep4s1bfin3
    with dissolve
    gaby "Well, I guess this is where we part ways..."
    dpense "She's acting casual, but she can't fool me. I know she's thinking about what happened too."
    d "Yeah, I guess so... I’ll see you around?"
    scene ep4s1bfin4
    with dissolve
    gaby "Yes... See you."
    dpense "She's still smiling, but she seems tense, and guarded. We came so close back there... too close maybe."
    gaby "Take care, [name]."
    d "You too, Gabriella."
    scene ep4s1bend1
    dpense "I wonder if things will be different the next time we meet."
    scene ep4s1bend2
    with dissolve
    if madidiner == True:
        dpense "The day's not over yet, and I still have Madison to deal with. I just hope I can salvage what’s left of the evening."
        pause 1
        stop music fadeout 2
        scene black
        with fade
        pause 2
        jump ep4s1c
    pause 1
    stop music fadeout 2
    scene black
    with fade
    pause 2
    jump ep4s2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
