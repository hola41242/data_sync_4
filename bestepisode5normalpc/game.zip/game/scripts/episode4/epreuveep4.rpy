

label epreuveep4:

    $ originalrank = Rank

    $ notrialep4 = False
    pause 1
    "Do you want to skip the trial ? ( Please note that you will have the minimum score to continue the story.)"
    menu:
        "No":
            pass
        "Skip the trial":
            $ notrialep4 = True
            scene black
            with fade
            pause 1
            jump resultatep4

    $ in_mini_game = True
    call saving (False) from _call_saving_1

    python:
        mastermindRandomPlaces = []
        mastermindRandomObjects = []
        correctNumbers = []
        currentHints = []
        chosenNumbers = [0, 0, 0, 0]
        currentFoundObject = None
        hintBalls = [False, False, False, False]
        for index, elt in enumerate(mastermindObjects):
            mastermindObjects[index].isFound = False
    image aprestrialep4_text = ParameterizedText(size = +100,xalign=0.5, yalign=0.7, outlines = [ (2, "#291897d8") ])

    $ config.rollback_enabled = False
    $ renpy.block_rollback()

    image aprestrialep4_text = ParameterizedText(size = +100,xalign=0.5, yalign=0.7, outlines = [ (2, "#291897d8") ])

    $ initMastermind()
    $ renpy.retain_after_load()


    $ MastermindPlace.currentPlace = mastermindPlaces[4]
    scene expression MastermindPlace.currentPlace.img
    call screen mastermind_room(MastermindPlace.currentPlace, MastermindPlace.currentPlace.getObjects())

    jump masterepreuveep4
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
