label ep4s1d:
    scene black
    pause 1
    show text _ ("After some training and some homework...") at truecenter
    call sport_increased from _call_sport_increased_19
    with dissolve
    pause 2 
    call education_increased from _call_education_increased_14
    hide text with dissolve
    pause 1
    play music "musique/MYO0017-PositivePopRock4-stockmusic-net.mp3" volume 0.2
    scene ep4s1d1
    with fade
    "I am Malenia, blade of Miquella..."
    scene ep4s1d2
    with fade
    "I am Malenia, blade of Miquella..."
    d "Yeah, yeah, yeah..."
    scene ep4s1d3
    with fade
    "I am Malenia, blade of Miquella..."
    scene ep4s1d4
    with fade
    "I am..."
    scene ep4s1d5
    with vpunch
    d "Fuck off!"
    scene ep4s1d6
    with dissolve
    dpense "I need something to calm down..."
    dpense "I should go see what Ruby's doing."
    scene black
    with fade
    pause 1
    scene rubyep4s1d1
    with dissolve
    pause 2
    scene rubyep4s1d2
    with dissolve
    pause 2
    scene rubyep4s1d3
    with vpunch
    ruby "No! No! No!"
    ruby "Argh!!!"
    scene rubyep4s1d4
    with hpunch
    ruby "So you're the type that gets on mic and tries to lecture me."
    ruby "You're the most useless person we have on our team!"
    scene rubyep4s1d5
    with hpunch
    ruby "I never seen anybody rage quite as hard as you!"
    ruby "Maybe you should go back to playing Team Fortress 2!"
    scene rubyep4s1d6
    with vpunch
    ruby "Raaaaaah"
    ruby "And if you like Mercy so much, why don't you just marry her?"
    scene rubyep4s1d7
    with dissolve
    dpense "Okay... Not the right timing..."
    dpense "I'll just leave her be."
    stop music fadeout 2
    scene black
    with dissolve
    jump ep4s2
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
