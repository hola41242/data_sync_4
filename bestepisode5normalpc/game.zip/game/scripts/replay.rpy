


screen Replayexit():
    zorder 100
    imagebutton auto "images/replay/exit_%s.png" action EndReplay() yalign .99 xalign .99






screen replay_gallery():
    tag menu

    use game_menu(_("Replayer")):
        frame:
            yoffset -50
            bottom_margin 20
            background "gui/frame2.png"

            align (0.0, 0.0)
            $ start = replay_page * 9
            $ end = min(start + 9 - 1, len(Replay_items) - 1)


            vpgrid:
                cols 3
                spacing 10
                xfill True
                yfill True


                for i in range(start, end + 1):
                    if renpy.seen_label(Replay_items[i].replay):
                        imagebutton idle Replay_items[i].thumbs:
                            style "replay_button"
                            action Replay(Replay_items[i].replay)
                            xalign 0.5
                            yalign 0.5

                    else:
                        vbox xalign 0.5 yalign 0.5:
                            add "gallery0"


                for i in range(end - start + 1, 9):
                    null


            vpgrid:
                cols 3
                spacing 10
                xfill True
                yfill True
                for i in range(start, end + 1):
                    if renpy.seen_label(Replay_items[i].replay):
                        hbox:
                            spacing maxthumbx - 10
                            xalign 0.1
                            yalign 1.04


                            text Replay_items[i].name
                    else:
                        hbox:
                            spacing maxthumbx - 10
                            xalign 0.1
                            yalign 1.04
                            text Replay_items[i].name

                for i in range(end - start + 1, 9):
                    null


            if replay_page > 0:
                textbutton "{color=#fff}Previous{/color}":
                    action SetVariable("replay_page", replay_page - 1)
                    xalign 0.01
                    yalign 0.99
                    yoffset 90
                    background "#000"
            if (replay_page + 1) * 9 < len(Replay_items):
                textbutton "{color=#fff}Next{/color}":
                    action SetVariable("replay_page", replay_page + 1)
                    xalign 0.98
                    yalign 0.99
                    yoffset 90
                    background "#000"







style replay_button:
    hover_background "images/replay/hover.png"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
