
label aeroport:
    scene black
    with fade
    stop music fadeout 2
    pause 2
    play music "musique/Nomyn-Fragments.mp3" volume 0.1
    pause 1
    show text _ ("A NEW LIFE....") at truecenter
    with dissolve
    pause 3
    scene black
    with fade
    $ renpy.movie_cutscene("images/animation/arrivee.webm", stop_music=False)
    with fade
    scene hero1
    with fade
    pause 1
    dpense "Ahh fresh air. A new country, new culture, new people..."
    $ result = None
    if not persistent.rufus1:
        scene hero2 with dissolve
        show screen chat1 with dissolve     
        $ result = renpy.call_screen("rufustuto")

        if result == "goto_rufustuto":

            call rufustuto from _call_rufustuto
        elif result == "found_cat":
            hide screen chat1               
            call rufusg1 from _call_rufusg1
    else:
        scene hero2 with dissolve
    dpense "I'm the last one. They're all gone."
    hide screen chat1
    scene hero3
    with dissolve
    pause 1
    dpense "Welcome to America!"
    scene hero4
    with dissolve
    with hpunch
    "ALL YOU HAD TO DO IS TAKE CARE OF HER WHILE I'M GONE!"
    scene hero5
    with dissolve
    mad "Are you telling me that you haven't noticed her struggling with her pacifier?"
    mad "Just listen to me, my idiot brother! I will be there in a few minutes. Just keep her calm."
    d "TAXI !" with hpunch
    scene hero6
    with dissolve
    pause 1
    scene hero7
    with dissolve
    mad "That's mine!"
    scene hero8
    with dissolve
    d "I don't think so."
    scene hero9
    with dissolve
    mad "I need it more than you!"

    if Grope == True:

        mad "You think I will let a pervert like you, who groped my teammate, take this cab?!"
        d "What did she tell you?"
        mad "I have no time for this. I'm leaving, you can hail a different cab!"
        scene hero10
        with dissolve
        pause 1
        dpense "I'm not going to let her take my taxi like that!"
        scene hero11
        with dissolve
        d "I'm coming too! Driver, take us to the Academy!"
        scene hero12
        with dissolve
        mad "Is this a joke? Do you really think you can just share the ride with me?"
        scene hero13
        with dissolve
        d "I don't think so, I know so. I don't know you and I hailed this cab. So stop with your attitude or get out of this taxi. Or, you can just relax and we can share the ride."
        mad "Ohh..."
        d "Good? Good. We are sharing the ride. Just deal with it."
        mad "What a gentleman..."
        scene black
        with fade
        stop music fadeout 2
        pause 2               
        play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
        pause 5
        scene hero14
        with fade
        pause 1
        scene hero15
        with dissolve
        pause 2
        "Is this the last one Mrs. Drew?"
        drew "Yes Mr. Orushi. It's the guy from France. As you requested."
        orushi "Perfect, Mrs. Drew. He's already in the claws of the tigress, I see."
        scene hero16
        with dissolve
        orushi "And how are the others?"
        drew "They're back at home or on campus for the night. Their luggage has been kept as you requested."
        orushi "Finally. We have the 100 competitors."
        orushi "Tomorrow , the B.E.S.T game will begin!"
        scene hero17
        with dissolve
        orushi "You hear that Mr. Rufus?"
        pause 1
        "RrrrrrrrrrrrrrrrrrRRRrrrrr..."
        scene hero19
        with dissolve
        orushi "Let the show begin!"
        $ Achievement.add(achievement_prologue)
        $ achievement.grant("prologue")
        $ achievement.sync()
        scene hero18
        with dissolve
        pause 2
        scene black
        with fade
        stop music fadeout 2.0
        jump e1s1
    else:




        mad "Listen, be a good boy and go hail another taxi."
        d "But... I called it!"
        mad "And?"
        d "And?!"
        scene hero10
        with dissolve
        dpense "What can I do in this situation?"
        d "Listen, I called this taxi, but I can see you’re going through a hard time and in a hurry, why don’t we just share?"
        scene hero11
        with dissolve
        mad "What?"
        d "We can share the taxi..."
        scene hero13
        with dissolve
        mad "I don't share."
        d "I’ll even pay since I would have to pay for my ride anyway and I don’t feel like waiting."
        mad "Sure, I guess. Thanks."
        d "Now, try to relax and take a deep breath. You can't just yell at anyone like that..."
        scene black
        with fade
        stop music fadeout 2.0
        with fade
        play music "musique/Cjbeards-FireAndThunderprobleme.mp3" volume 0.20
        pause 5
        scene hero14
        with fade
        pause 1
        scene hero15
        with dissolve
        pause 2
        "Is this the last one, Mrs. Drew?"
        drew "Yes, Mr. Orushi. It's the guy from France. As you requested."
        orushi "Perfect, Mrs. Drew! He's already in the claws of the tigress, I see."
        scene hero16
        with dissolve
        orushi "And how are the others ?"
        drew "They're back at home or on campus for the night. Their luggage has been kept as you requested."
        orushi "Finally. We have the 100 competitors."
        orushi "Tomorrow , the B.E.S.T game will begin!"
        scene hero17
        with dissolve
        orushi "You hear that Mr. Rufus ?"
        pause 1
        "RrrrrrrrrrrrrrrrrrRRRrrrrr..."
        scene hero19
        with dissolve
        orushi "Let the show begin !"
        $ Achievement.add(achievement_prologue)
        $ achievement.grant("prologue")
        $ achievement.sync()
        scene hero18
        with dissolve
        pause 2
        scene black
        with fade
        stop music fadeout 2.0

    jump e1s1

label rufusg1:
    $ persistent.rufusgame +=1
    if not renpy.seen_image("img1"):
        show img1
        hide img1
    $ renpy.notify (_("You've found a RUFUS !"))
    $ persistent.rufus1 = True
    hide screen chat1
    return







label rufustuto:

    "Some cats are hidden in the renders during the game, find them to unlock some extras renders in the gallery."
    "With the Walkthrough-mod, you can see a notification when a cat is hidden in the next renders. Open your eyes!"
    if persistent.patch_enabled:
        if persistent.rufus1 == False:
            $ renpy.notify (_("Rrrrrrrrrrrrrrrrr..."))
    return
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
