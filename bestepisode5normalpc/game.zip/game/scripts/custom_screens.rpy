













































































































transform fadein:
    alpha 0.0
    linear 0.3 alpha 1.0

init python:
    def get_stat_phrase(b, e, s, t):
        stats = {"Buddy": b, "Education": e, "Sport": s, "Temperament": t}
        top_stat = max(stats, key=stats.get)
        return {
            "Buddy": _("You're everyone's best friend!"),
            "Education": _("Knowledge is your power!"),
            "Sport": _("You’re a true champion!"),
            "Temperament": _("You lead the way!"),
        }[top_stat]

default stats_ui_open = False

screen gameUI():
    if not stats_ui_open:
        imagebutton:
            idle "gui/hudbest/icon_trophy.png"
            hover "gui/hudbest/icon_trophy_hover.png"
            xalign 0.98
            yalign 0.02
            action ToggleVariable("stats_ui_open")

    if stats_ui_open:
        use stats_hud()

screen stats_hud():

    fixed:
        at fadein

        xalign 0.99
        yalign 0.015
        xanchor 1.0
        xsize 380
        ysize 360


        add "gui/hudbest/panel_background.png" xpos 0 ypos 0:
            ysize 440


        imagebutton:
            idle Frame("gui/hudbest/icon_trophy.png", 0, 0, tile=False)
            hover Frame("gui/hudbest/icon_trophy_hover.png", 0, 0, tile=False)
            xsize 70
            ysize 70
            action ToggleVariable("stats_ui_open")


        text "B.E.S.T":
            xpos 140
            ypos 30
            size 35
            color "#ffffff"
            font "gui/Genos-Bold.ttf"


        vbox:
            xpos 50
            ypos 80
            spacing 2

            for icon, label, value in [
                ("icon_buddy.png", "Buddy", Buddy),
                ("icon_education.png", "Education", Education),
                ("icon_sport.png", "Sport", Sport),
                ("icon_temperament.png", "Temperament", Temperament)
            ]:
                hbox:
                    spacing 10
                    yalign 0.5


                    add "gui/hudbest/[icon]":
                        xsize 60
                        ysize 60


                    vbox:
                        spacing 2
                        text label:
                            size 22
                            color "#FFFFFF"
                            font "gui/Genos-Bold.ttf"
                        bar:
                            value value
                            range 15
                            xsize 200
                            ysize 20
                            left_bar Frame("gui/hudbest/bar_fill.png", 0, 0)
                            right_bar Frame("gui/hudbest/bar_empty.png", 0, 0)
                            thumb None
                            xalign 0.0
                        yalign 0.5


                    text "[value]":
                        size 22
                        color "#FFFFFF"
                        yalign 0.5


        $ final_phrase = get_stat_phrase(Buddy, Education, Sport, Temperament)
        text final_phrase:
            xalign 0.5
            ypos 350
            size 20
            italic True
            color "#00DFFF"
            font "gui/lobster.ttf"


screen screen_language():

    imagemap:
        ground "images/UI/language.png"
        hover "images/UI/language.png"

        imagebutton:
            idle "images/UI/french_idle.png"
            hover "images/UI/french_hover.png"
            xalign 0.40
            yalign 0.5
            action Language("french"),Return()
        text "Français":
            xalign 0.41
            yalign 0.62

        imagebutton:
            idle "images/UI/english_idle.png"
            hover "images/UI/english_hover.png"
            xalign 0.20
            yalign 0.5
            action Language(None),Return()
        text "English":
            xalign 0.23
            yalign 0.62

        imagebutton:
            idle "images/UI/spain_idle.png"
            hover "images/UI/spain_hover.png"
            xalign 0.60
            yalign 0.5
            action Language("spanish"),Return()
        text "Espanol (LATAM )":
            xalign 0.60
            yalign 0.62

        imagebutton:
            idle "images/UI/russian_idle.png"
            hover "images/UI/russian_hover.png"
            xalign 0.20
            yalign 0.8
            action Language("russian"),Return()
        text "Russian":
            xalign 0.23
            yalign 0.88

        imagebutton:
            idle "images/UI/italy_idle.png"
            hover "images/UI/italy_hover.png"
            xalign 0.80
            yalign 0.5
            action Language("italian"),Return()
        text "Italiano":
            xalign 0.77
            yalign 0.62











        imagebutton:
            idle "images/UI/schinese_idle.png"
            hover "images/UI/schinese_hover.png"
            xalign 0.40
            yalign 0.8
            action Language("schinese"),Return()
        text "Simp. Chinese":
            xalign 0.40
            yalign 0.88

        imagebutton:
            idle "images/UI/tchinese_idle.png"
            hover "images/UI/tchinese_hover.png"
            xalign 0.60
            yalign 0.8
            action Language("tchinese"),Return()
        text "Trad. Chinese":
            xalign 0.60
            yalign 0.88

        imagebutton:
            idle "images/UI/portuguese_idle.png"
            hover "images/UI/portuguese_hover.png"
            xalign 0.80
            yalign 0.8
            action Language("portuguese"),Return()
        text "Portuguese (Brasil)":
            xalign 0.80
            yalign 0.88












screen gameUIBEST():
    if not stats_ui_open:
        imagebutton:
            idle "gui/hudbest/icon_trophy.png"
            hover "gui/hudbest/icon_trophy_hover.png"
            xalign 0.98
            yalign 0.02
            action ToggleVariable("stats_ui_open")

    if stats_ui_open:
        use stats_hud2()


screen stats_hud2():
    fixed:
        at fadein

        xalign 0.99
        yalign 0.015
        xanchor 1.0
        xsize 380
        ysize 360


        add "gui/hudbest/panel_background.png" xpos 0 ypos 0:
            ysize 440


        imagebutton:
            idle Frame("gui/hudbest/icon_trophy.png", 0, 0, tile=False)
            hover Frame("gui/hudbest/icon_trophy_hover.png", 0, 0, tile=False)
            xsize 70
            ysize 70
            action ToggleVariable("stats_ui_open")

        text "B.E.S.T RANK : [Rank]":
            xalign 0.65
            ypos 40
            size 35
            color "#ffffff"
            font "gui/Genos-Bold.ttf"


        vbox:
            xpos 50
            ypos 90
            spacing 1

            for icon, label, value in [
                ("icon_buddy.png", "Buddy", Buddy),
                ("icon_education.png", "Education", Education),
                ("icon_sport.png", "Sport", Sport),
                ("icon_temperament.png", "Temperament", Temperament)
            ]:
                hbox:
                    spacing 10
                    yalign 0.5


                    add "gui/hudbest/[icon]":
                        xsize 60
                        ysize 60


                    vbox:
                        spacing 2
                        text label:
                            size 22
                            color "#FFFFFF"
                            font "gui/Genos-Bold.ttf"
                        bar:
                            value value
                            range 15
                            xsize 200
                            ysize 20
                            left_bar Frame("gui/hudbest/bar_fill.png", 0, 0)
                            right_bar Frame("gui/hudbest/bar_empty.png", 0, 0)
                            thumb None
                            xalign 0.0
                        yalign 0.5


                    text "[value]":
                        size 22
                        color "#FFFFFF"
                        yalign 0.5


        $ final_phrase = get_stat_phrase(Buddy, Education, Sport, Temperament)
        text final_phrase:
            xalign 0.5
            ypos 350
            size 20
            italic True
            color "#00DFFF"
            font "gui/lobster.ttf"

screen STEAMWISH():

    imagebutton:
        xalign 0.80
        yalign 0.70
        idle "steam.png"
        hover "steam_hover.png"
        action OpenURL("https://store.steampowered.com/widget/2404390/")


screen PHONECALL():
    imagemap:
        ground "phone/assets/background.png"
        xalign 0.5
        yalign 0.5

screen choixfille1():
    vbox:


        hbox:
            imagebutton auto "gui/button/choixgrace1_%s.webp" action Jump("graceamphi")
            imagebutton auto "gui/button/choixjulia1_%s.webp" action Jump("juliaamphi")
            if persistent.patch_enabled:
                imagebutton auto "gui/button/choice_%s.webp" action Jump("madisonamphi")
            else:
                imagebutton auto "gui/button/choixmadison1_%s.webp" action Jump("madisonamphi")
            imagebutton auto "gui/button/choixruby1_%s.webp" action Jump("rubyamphi")

screen choixfille2():
    vbox:
        hbox:
            imagebutton auto "gui/button/choixgrace2_%s.webp" action Jump("gracechoix2")
            imagebutton auto "gui/button/choixjulia2_%s.webp" action Jump("juliachoix2")
            imagebutton auto "gui/button/choixmadison2_%s.webp" action Jump("madisonchoix2")
            imagebutton auto "gui/button/choixruby2_%s.webp" action Jump("rubychoix2")


transform chat:
    on idle:
        alpha 0.3
    on hover:
        alpha 0.8

screen chat1():

    imagebutton at chat:
        xalign 0.01
        yalign 0.54
        idle "chat.png"
        hover "chat.png"
        action [ Hide("chat1"), Return("found_cat") ]

screen chat2():

    imagebutton at chat:
        xalign 0.01
        yalign 0.99
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg2")

screen chat3():

    imagebutton at chat:
        xalign 0.10
        yalign 0.25
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg3")

screen chat4():

    imagebutton at chat:
        xalign 0.27
        yalign 0.45
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg4")

screen chat5():

    imagebutton at chat:
        xalign 0.97
        yalign 0.60
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg5")

screen chat6():

    imagebutton at chat:
        xalign 0.86
        yalign 0.83
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg6")

screen chat7():

    imagebutton at chat:
        xalign 0.62
        yalign 0.80
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg7")

screen chat8():

    imagebutton at chat:
        xalign 0.01
        yalign 0.54
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg8")

screen chat9():

    imagebutton at chat:
        xalign 0.30
        yalign 0.25
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg9")

screen chat10():

    imagebutton at chat:
        xalign 0.02
        yalign 0.5
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg10")

screen chat11():

    imagebutton at chat:
        xalign 0.22
        yalign 0.25
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg11")

screen chat12():

    imagebutton at chat:
        xalign 0.17
        yalign 0.16
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg12")

screen chat13():

    imagebutton at chat:
        xalign 0.89
        yalign 0.41
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg13")

screen chat14():

    imagebutton at chat:
        xalign 0.64
        yalign 0.01
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg14")

screen chat15():

    imagebutton at chat:
        xalign 0.80
        yalign 0.9
        idle "chat.png"
        hover "chat.png"
        action Call("rufusg15")

transform point:
    on idle:
        alpha 1
    on hover:
        alpha 0.8

screen point():

    imagebutton at point:
        xalign 0.725
        yalign 0.21
        idle "point.png"
        hover "point.png"
        action Call("point")

screen galleries():
    tag menu
    vbox:
        hbox:
            imagebutton auto "gui/button/scenes_%s.webp" action ShowMenu("replay_gallery")
            imagebutton auto "gui/button/extras_%s.webp" action ShowMenu("gallery")

screen choixep3s2():
    vbox:
        hbox:
            if madipath == True:
                imagebutton auto "gui/button/madigym_%s.webp" action Jump("ep3s2b")
            else:
                imagebutton auto "gui/button/madigym_%s.webp"
            if cinema == True:
                imagebutton auto "gui/button/rubychambre_%s.webp" action Jump("ep3s2a")
            else:
                imagebutton auto "gui/button/rubychambre_%s.webp"
            if Gracepath == True:
                imagebutton auto "gui/button/gracechambre_%s.webp" action Jump("ep3s2c")
            else:
                imagebutton auto "gui/button/gracechambre_%s.webp"
        hbox:
            imagebutton auto "gui/button/PASS_%s.webp" action Jump("ep3s3")

screen pass():
    vbox:
        xalign 0.2
        yalign 0.9
        imagebutton auto "pass_%s.png" action Jump("passeepreuve")

screen bonuseduc():
    vbox:
        xalign 0.05
        yalign 0.7
        add "bonuseduc.png"
        if question_number==3:
            text _("Look at the numbers backwards")
        if question_number==8:
            text _("Don't click on the image")
        if question_number==9:
            text _("The answer is in the question")

screen choixep3s4():
    vbox:
        hbox:
            imagebutton auto "gui/button/train2_%s.webp" action Jump("Training2")
            imagebutton auto "gui/button/chambreep3_%s.webp" action Jump("Chambreep3")

screen telephone():
    imagebutton:
        xalign 1.0
        yalign 0.0
        xoffset -30
        yoffset 30
        idle "phone/assets/telephonebase.png"
        hover "phone/assets/telephonebasehover.png"
        action PhoneMenu("phone")


screen telephonenotif():
    add "phone/assets/phonenotificationicon.png":
        xalign 1.0
        yalign 0.0
        xoffset -105
        yoffset 30

screen appnotif():
    add "phone/assets/phonenotificationicon.png":
        xalign 0.5
        yalign 0.0
        xoffset -105
        yoffset 30

screen free20main():

    vbox:
        hbox:
            imagebutton auto "gui/button/free20/1st_%s.jpg" action Jump("free201st")
            imagebutton auto "gui/button/free20/garden_%s.jpg" action Jump("free20garden")
        hbox:
            imagemap:
                ground "gui/button/free20/free20persos.jpg"
                hover "gui/button/free20/free20persoshover.jpg"

                if madigracediscuss20 == True:
                    hotspot (22,47,606,754) action Jump("gracemadison20")
                if juliadiscuss20 == True:
                    hotspot (668,249,436,600) action Jump("julia20")
                hotspot (1211,200,317,600) action Jump("ruby20")



        hbox:
            imagebutton auto "gui/button/free20/poker_%s.jpg" action Jump("free20poker")
    use free20_hud(current_location="free20main")

screen free20garden():
    vbox:
        hbox:
            imagebutton auto "gui/button/free20/living_%s.jpg" action Jump("free20main")
        hbox:
            imagemap:
                ground "gui/button/free20/gardenfree20.jpg"
                hover "gui/button/free20/gardenfree20hover.jpg"

                if BlueRelation == True:
                    if bluediscuss20 == True:
                        hotspot (41,276,300,438) action Jump("blue20")
                    else:
                        pass
                if debilesdiscuss20 == True:
                    hotspot (1072,229,278,427) action Jump("debiles20")
    use free20_hud(current_location="free20garden")



screen free20poker():
    vbox:
        hbox:
            imagebutton auto "gui/button/free20/living_%s.jpg" action Jump("free20main")
        hbox:
            imagemap:
                ground "gui/button/free20/free20poker.jpg"
                hover "gui/button/free20/free20poker_hover.jpg"

                if invitepoker == True:
                    hotspot (276,269,428,697) action Jump("emerick20")
                if reddiscuss20 == True:
                    if invitepoker == False:
                        hotspot (1308,90,460,815) action Jump("red20")
    use free20_hud(current_location="free20poker")


screen free201st():
    vbox:
        hbox:
            imagebutton auto "gui/button/free20/living_%s.jpg" action Jump("free20main")
        hbox:
            imagemap:
                ground "gui/button/free20/free201st_idle.jpg"
                hover "gui/button/free20/free201st_hover.jpg"

                if kiradiscuss20 == True:
                    hotspot (929,97,747,507) action Jump("kira20")
                if kiradiscuss20 == False:
                    if enterpoker == False:
                        if invitepoker == False:
                            if Training2 == True:
                                hotspot (929,97,747,507) action Jump("kira20poker")
                if bluebath20 == True:
                    hotspot (102,230,223,496) action Jump("bluebath21")
    use free20_hud(current_location="free201st")

screen choixfilleep4():

    vbox:
        spacing 20
        text _("Please choose your teammate...") at center
        hbox:

            if Redpath == True:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/redep4_%s.webp" action Jump("redtrialep4")
                    if persistent.patch_enabled:
                        hbox:
                            spacing 20
                            text ""
                            text _("    Bonus: Objects")
                            text ""
            else:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/redep4_%s.webp"

            if madipath == True:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/madiep4_%s.webp" action Jump("maditrialep4")
                    if persistent.patch_enabled:
                        hbox:
                            spacing 20
                            text ""
                            text _("    Bonus: Speed")
                            text ""
            else:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/madiep4_%s.webp"

            if JuliaHopital == True:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/juliaep4_%s.webp" action Jump("juliatrialep4")
                    if persistent.patch_enabled:
                        hbox:
                            spacing 20
                            text ""
                            text _("    Bonus: Hint")
                            text ""
            else:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/juliaep4_%s.webp"

            vbox:
                xsize 320
                spacing 20
                imagebutton auto "gui/button/rubyep4_%s.webp" action Jump("rubytrialep4")
                if persistent.patch_enabled:
                    hbox:
                        spacing 20
                        text ""
                        text _("    Bonus: Brain")
                        text ""

            if Gracepath == True:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/graceep4_%s.webp" action Jump("gracetrialep4")
                    if persistent.patch_enabled:
                        hbox:
                            spacing 20
                            text ""
                            text _("    Bonus: Mother")
                            text ""
            else:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/graceep4_%s.webp"

            if bluelove == True:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/blueep4_%s.webp" action Jump("bluetrialep4")
                    if persistent.patch_enabled:
                        hbox:
                            spacing 20
                            text ""
                            text _("    Bonus: Places")
                            text ""
            else:
                vbox:
                    xsize 320
                    spacing 20
                    imagebutton auto "gui/button/blueep4_%s.webp"

screen telephoneep4():

    $ phone.menu = False
    imagebutton:
        xalign 0.5
        yalign 0.85
        idle "phone/assets/telephonebase.png"
        hover "phone/assets/telephonebasehover.png"
        action PhoneMenu("phone_best")



screen choixep4p2():

    vbox:
        hbox:
            if gabychaep4 == True:
                imagebutton auto "gui/button/gabicha_%s.webp" action Jump("palazio_gabriella_charlotte")
            else:
                imagebutton auto "gui/button/gabicha_%s.webp"
            if evelynep4 == True:
                imagebutton auto "gui/button/evelynpres_%s.webp" action Jump("palazio_dancefloor")
            else:
                imagebutton auto "gui/button/evelynpres_%s.webp"
            if kirafannypalazioep4 == True:
                imagebutton auto "gui/button/kirashot_%s.webp" action Jump("palazio_kira_fanny")
            else:
                imagebutton auto "gui/button/kirashot_%s.webp"

screen rufustuto():
    imagebutton auto "gui/Next_%s.png":
        xsize 50
        xalign 0.01
        yalign 0.62
        action [ Hide("rufustuto"), Return("goto_rufustuto") ]


screen tooltip(message):
    frame:
        background "#000000CC"
        padding (10, 5)
        xalign 0.0
        yalign 0.0
        at mousepos
        text "[message]" size 14 color "#FFFFFF"

transform mousepos:
    on show:
        xpos mouse.x + 20
        ypos mouse.y + 20

screen best2wishlist:
    vbox:
        xalign 0.5
        yalign 0.2
        spacing 35
        add "images/BEST2.jpg":
            xsize 1000
            ysize 600

        text _("Follow ELISE and OUR HERO in the next level of the competition!") at truecenter

        imagebutton:
            xalign 0.99
            idle ("gui/steam_buy_sm3.png")
            hover ("gui/steam_buy_sm4.png")
            action Function(steam_buy2)

screen choixep5s61():
    modal True tag box_selection


    vbox:
        spacing 0
        align (0.5, 0.5)

        hbox:
            spacing 0
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5grace320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Grace"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5emerick320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Emerick"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5madi320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Madison"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5steven320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Steven"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5blue320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Sofia"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5hector320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Hector"), Jump("observebox")]

        hbox:
            spacing 0
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5red320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Elizabeth"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5mac320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Mac"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5kira320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Kira"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5ben320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Ben"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5julia320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Julia"), Jump("observebox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5ruby320_%s.jpg" at hover_zoom action [SetVariable("chosenbox", "Ruby"), Jump("observebox")]

transform hover_zoom:
    on hover:
        linear 0.1 zoom 1.01
    on idle:
        linear 0.1 zoom 1.0

screen choixep5s62():
    modal True tag box_selection


    vbox:
        spacing 0
        align (0.5, 0.5)

        hbox:
            spacing 0
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5grace320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Grace"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5emerick320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Emerick"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5madi320_%s.jpg" at hover_zoom action [None]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5steven320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Steven"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5blue320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Sofia"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5hector320_%s.jpg" at hover_zoom action [None]

        hbox:
            spacing 0
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5red320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Elizabeth"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5mac320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Mac"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5kira320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Kira"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5ben320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Ben"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5julia320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Julia"), Jump("herochosenbox")]
            fixed:
                xsize 320
                ysize 540
                imagebutton auto "images/episode5/e5s6/trialchoix/trial5ruby320_%s.jpg" at hover_zoom action [SetVariable("herofinalbox", "Ruby"), Jump("herochosenbox")]
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
