
init python:

    maxnumx = 3
    maxnumy = 3
    maxthumbx = config.screen_width / (maxnumx + 1)
    maxthumby = config.screen_height / (maxnumy + 1)
    maxperpage = maxnumx * maxnumy
    gallery_page = 0
    closeup_page = 0


    class GalleryItem:
        def __init__(self, name, images, thumb, locked="lockedthumb"):
            self.name = name
            self.images = images
            self.thumb = thumb
            self.locked = locked
            self.refresh_lock()
        
        def num_images(self):
            return len(self.images)
        
        def refresh_lock(self):
            self.num_unlocked = 0
            lockme = False
            for img in self.images:
                if not renpy.seen_image(img):
                    lockme = True
                else:
                    self.num_unlocked += 1
            self.is_locked = lockme

    gallery_items = []
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Taxi Drive{/color}"), ["img1"], "thumb1"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Red is Dead{/color}"), ["img2"], "thumb2"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Bed is Red{/color}"), ["img3"], "thumb3"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Kitty{/color}"), ["img4"], "thumb4"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Dirty{/color}"), ["img5"], "thumb5"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Yummy{/color}"), ["img6"], "thumb6"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Ice-Cream{/color}"), ["img7"], "thumb7"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}MotorButt{/color}"), ["img8"], "thumb8"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Mystery{/color}"), ["img9"], "thumb9"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Temple{/color}"), ["img10"], "thumb10"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Bed is Blue{/color}"), ["img11"], "thumb11"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Shooting{/color}"), ["img12"], "thumb12"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Mother{/color}"), ["img13"], "thumb13"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Peace{/color}"), ["img14"], "thumb14"))
    gallery_items.append(GalleryItem(_("{color=#ffffffff}Witch{/color}"), ["img15"], "thumb15"))




image gray = "#2779c5"




image lockedthumb = ("images/gallery/thumbs/tgallery0.jpg")


image img1 = ("images/gallery/special1.webp")
image img2 = ("images/gallery/special2.webp")
image img3 = ("images/gallery/special3.webp")
image img4 = ("images/gallery/special4.webp")
image img5 = ("images/gallery/special5.webp")
image img6 = ("images/gallery/special6.webp")
image img7 = ("images/gallery/special7.webp")
image img8 = ("images/gallery/special8.webp")
image img9 = ("images/gallery/special9.webp")
image img10 = ("images/gallery/special10.webp")
image img11 = ("images/gallery/special11.webp")
image img12 = ("images/gallery/special12.webp")
image img13 = ("images/gallery/special13.webp")
image img14 = ("images/gallery/special14.webp")
image img15 = ("images/gallery/special15.webp")


image thumb1 = ("images/gallery/thumbs/special1384.webp")
image thumb2 = ("images/gallery/thumbs/special2384.webp")
image thumb3 = ("images/gallery/thumbs/special3384.webp")
image thumb4 = ("images/gallery/thumbs/special4384.webp")
image thumb5 = ("images/gallery/thumbs/special5384.webp")
image thumb6 = ("images/gallery/thumbs/special6384.webp")
image thumb7 = ("images/gallery/thumbs/special7384.webp")
image thumb8 = ("images/gallery/thumbs/special8384.webp")
image thumb9 = ("images/gallery/thumbs/special9384.webp")
image thumb10 = ("images/gallery/thumbs/special10384.webp")
image thumb11 = ("images/gallery/thumbs/special11384.webp")
image thumb12 = ("images/gallery/thumbs/special12384.webp")
image thumb13 = ("images/gallery/thumbs/special13384.webp")
image thumb14 = ("images/gallery/thumbs/special14384.webp")
image thumb15 = ("images/gallery/thumbs/special15384.webp")
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
