python early:


    class Achievement(NoRollback):
        def __init__(self, name='', image='', message='', **kwargs):
            self.name = name
            if image == '':
                
                self.image = Transform('gui/trophy_icon.png', fit='contain')
            else:
                self.image = Transform(image, fit='contain')
            self.message = message
        
        
        def __eq__(self, value):
            """
            Since we are using a persistent list we need to do an equality
            check.

            Below we are simply checking 'self.name == value.name, self.message == value.message'
            """
            return all((self.name == value.name, self.message == value.message))
        
        def add(trophy):
            """
            Add/Grant Trophies/Achievements to the list.

            As a standard python expression  ::  Achievement.add( <trophy> )
            As a screen action  ::  Function( Achievement.add, <trophy> )
            """
            if not achievement.has(trophy.name):
                achievement.grant(trophy.name)
                store.achievement_notification_list.append(trophy)
            
            if trophy not in persistent.my_achievements:
                
                persistent.my_achievements.insert(0, trophy)
        
        def purge(self):
            """
            This will clear the achievements AND persistent list.

            As a standard python expression  ::  achievements.purge()
            As a screen action  ::  Function( achievements.purge )
            """
            achievement.clear_all()
            persistent.my_achievements.clear()




default persistent.my_achievements = []
default achievements = Achievement()

init python:

    achievement.steam_position = "bottom right"
    config.steam_appid = 2404390 

    achievement_name = {

        
        

        
        
        

        
        "welcome": [_("You have entered the B.E.S.T Game"), _("Start the game"), 'gui/trophy_icon.png', None],

        
        
        
        
        

        "groper": [_("What an ass!"), _("Grope Julia"), 'gui/trophy_icon.png', 'hidden'],
        "redneck": [_("Cotton Eye Joe !"), _("Don't touch Julia"), 'gui/trophy_icon.png', 'hidden'],
        "hero": [_("Catch them all!"), _("Catch Grace"), 'gui/trophy_icon.png', 'hidden'],
        "redhead": [_("Life in redhead !"), _("You've put Grace on her bed"), 'gui/trophy_icon.png', 'hidden'],
        "prologue": [_("Show must go on !"), _("Finish the Prologue"), 'gui/trophy_icon.png', 'hidden'],
        "friend": [_("Pinky and the Braid!"), _("Play the Minus and Cortex game"), 'gui/trophy_icon.png', 'hidden'],
        "win": [_("You are the winner!"), _("Finish First with Madison ?"), 'gui/trophy_icon.png', 'hidden'],
        "reward": [_("You deserve it!"), _("Accept the reward"), 'gui/trophy_icon.png', 'hidden'],
        "specialreward": [_("You're not first meh!"), _("Accept the Special Reward"), 'gui/trophy_icon.png', 'hidden'],
        "episode1": [_("First !!!"), _("Finish the First Episode"), 'gui/trophy_icon.png', 'hidden'],
        "wow": [_("Outstanding!"), _("Get all achievements."), 'gui/trophy_icon.png', 'platinum'],
        "victory": [_("Victory !!!"), _("Win versus Grace"), 'gui/trophy_icon.png', 'hidden'],
        "cheater": [_("Cheater !!!"), _("Cheat versus Grace"), 'gui/trophy_icon.png', 'hidden'],
        "defeat": [_("Day of Defeat !!!"), _("You let Grace win... Right ?"), 'gui/trophy_icon.png', 'hidden'],
        "evolve": [_("Evolution !!!"), _("From Squirtle to Squirter"), 'gui/trophy_icon.png', 'hidden'],
        "rubydesolation": [_("Her hero!!!"), _("You're Ruby's Hero..."), 'gui/trophy_icon.png', 'hidden'],
        "hattrick": [_("Hat Trick !!!"), _("All for Madison !"), 'gui/trophy_icon.png', 'hidden'],
        "haremvibe": [_("Harem Vibes!!!"), _("Women likes you..."), 'gui/trophy_icon.png', 'hidden'],
        "firstkiss": [_("First Kiss!!!"), _("Grace for ever !"), 'gui/trophy_icon.png', 'hidden'],
        "onetime": [_("Of course!!!"), _("Madison..."), 'gui/trophy_icon.png', 'hidden'],
        "episode2": [_("Just the Beginning!"), _("Finish the Second Episode"), 'gui/trophy_icon.png', 'hidden'],
        "gameover": [_("You tried..."), _("Meh..."), 'gui/trophy_icon.png', 'hidden'],
        "quizzpro": [_("You're a genius!!!"), _("But unknown..."), 'gui/trophy_icon.png', 'hidden'],
        "milf": [_("Milfs are life!!!"), _("Better with experience..."), 'gui/trophy_icon.png', 'hidden'],
        "virgin": [_("Like a virgin!"), _("Touch for the very first time..."), 'gui/trophy_icon.png', 'hidden'],
        "heartbreaker": [_("You switched!"), _("From Blue to Red..."), 'gui/trophy_icon.png', 'hidden'],
        "episode3": [_("Road to Victory!"), _("Finish the Third Episode"), 'gui/trophy_icon.png', 'hidden'],
        "pet": [_("Pet's Friend"), _("Mewww..."), 'gui/trophy_icon.png', 'hidden'],
        "missopportunity": [_("Opportunity Missed"), _("You were on the right track..."), 'gui/trophy_icon.png', 'hidden'],
        "best": [_("You're the BEST!"), _("A Star is born..."), 'gui/trophy_icon.png', 'hidden'],
        "madibest": [_("Madison is the BEST!"), _("Ally or enemy???"), 'gui/trophy_icon.png', 'hidden'],
        "motm": [_("Man of the match!"), _("Play it like Beckham!"), 'gui/trophy_icon.png', 'hidden'],
        "endep4": [_("You finished Episode 4!"), _("RUBYYYYYYYY!"), 'gui/trophy_icon.png', 'hidden'],
        "milfy": [_("Milfy City!"), _("You like it with experience"), 'gui/trophy_icon.png', 'hidden'],
        "sacrifice": [_("Sacrifice!"), _("She won't let you go..."), 'gui/trophy_icon.png', 'hidden'],
        "endep5": [_("You finished Episode 5!"), _("Elise?"), 'gui/trophy_icon.png', 'hidden'],

        

    }



    for k, v in achievement_name.items():
        achievement.register(v[0])





default achievement_welcome = Achievement(name=achievement_name['welcome'][0], message=achievement_name['welcome'][1], image=achievement_name['welcome'][2])
default achievement_groper = Achievement(name=achievement_name['groper'][0], message=achievement_name['groper'][1], image=achievement_name['groper'][2])
default achievement_redneck = Achievement(name=achievement_name['redneck'][0], message=achievement_name['redneck'][1], image=achievement_name['redneck'][2])
default achievement_hero = Achievement(name=achievement_name['hero'][0], message=achievement_name['hero'][1], image=achievement_name['hero'][2])
default achievement_redhead = Achievement(name=achievement_name['redhead'][0], message=achievement_name['redhead'][1], image=achievement_name['redhead'][2])
default achievement_prologue = Achievement(name=achievement_name['prologue'][0], message=achievement_name['prologue'][1], image=achievement_name['prologue'][2])
default achievement_friend = Achievement(name=achievement_name['friend'][0], message=achievement_name['friend'][1], image=achievement_name['friend'][2])
default achievement_win = Achievement(name=achievement_name['win'][0], message=achievement_name['win'][1], image=achievement_name['win'][2])
default achievement_reward = Achievement(name=achievement_name['reward'][0], message=achievement_name['reward'][1], image=achievement_name['reward'][2])
default achievement_specialreward = Achievement(name=achievement_name['specialreward'][0], message=achievement_name['specialreward'][1], image=achievement_name['specialreward'][2])
default achievement_episode1 = Achievement(name=achievement_name['episode1'][0], message=achievement_name['episode1'][1], image=achievement_name['episode1'][2])
default achievement_platinum = Achievement(name=achievement_name['wow'][0], message=achievement_name['wow'][1], image=achievement_name['wow'][2])
default achievement_victory = Achievement(name=achievement_name['victory'][0], message=achievement_name['victory'][1], image=achievement_name['victory'][2])
default achievement_cheater = Achievement(name=achievement_name['cheater'][0], message=achievement_name['cheater'][1], image=achievement_name['cheater'][2])
default achievement_defeat = Achievement(name=achievement_name['defeat'][0], message=achievement_name['defeat'][1], image=achievement_name['defeat'][2])
default achievement_evolve = Achievement(name=achievement_name['evolve'][0], message=achievement_name['evolve'][1], image=achievement_name['evolve'][2])
default achievement_rubydesolation = Achievement(name=achievement_name['rubydesolation'][0], message=achievement_name['rubydesolation'][1], image=achievement_name['rubydesolation'][2])
default achievement_hattrick = Achievement(name=achievement_name['hattrick'][0], message=achievement_name['hattrick'][1], image=achievement_name['hattrick'][2])
default achievement_haremvibe = Achievement(name=achievement_name['haremvibe'][0], message=achievement_name['haremvibe'][1], image=achievement_name['haremvibe'][2])
default achievement_firstkiss = Achievement(name=achievement_name['firstkiss'][0], message=achievement_name['firstkiss'][1], image=achievement_name['firstkiss'][2])
default achievement_onetime = Achievement(name=achievement_name['onetime'][0], message=achievement_name['onetime'][1], image=achievement_name['onetime'][2])
default achievement_episode2 = Achievement(name=achievement_name['episode2'][0], message=achievement_name['episode2'][1], image=achievement_name['episode2'][2])
default achievement_gameover = Achievement(name=achievement_name['gameover'][0], message=achievement_name['gameover'][1], image=achievement_name['gameover'][2])
default achievement_quizzpro = Achievement(name=achievement_name['quizzpro'][0], message=achievement_name['quizzpro'][1], image=achievement_name['quizzpro'][2])
default achievement_milf = Achievement(name=achievement_name['milf'][0], message=achievement_name['milf'][1], image=achievement_name['milf'][2])
default achievement_virgin = Achievement(name=achievement_name['virgin'][0], message=achievement_name['virgin'][1], image=achievement_name['virgin'][2])
default achievement_heartbreaker = Achievement(name=achievement_name['heartbreaker'][0], message=achievement_name['heartbreaker'][1], image=achievement_name['heartbreaker'][2])
default achievement_episode3 = Achievement(name=achievement_name['episode3'][0], message=achievement_name['episode3'][1], image=achievement_name['episode3'][2])
default achievement_pet = Achievement(name=achievement_name['pet'][0], message=achievement_name['pet'][1], image=achievement_name['pet'][2])
default achievement_missopportunity = Achievement(name=achievement_name['missopportunity'][0], message=achievement_name['missopportunity'][1], image=achievement_name['missopportunity'][2])
default achievement_best = Achievement(name=achievement_name['best'][0], message=achievement_name['best'][1], image=achievement_name['best'][2])
default achievement_madibest = Achievement(name=achievement_name['madibest'][0], message=achievement_name['madibest'][1], image=achievement_name['madibest'][2])
default achievement_motm = Achievement(name=achievement_name['motm'][0], message=achievement_name['motm'][1], image=achievement_name['motm'][2])
default achievement_endep4 = Achievement(name=achievement_name['endep4'][0], message=achievement_name['endep4'][1], image=achievement_name['endep4'][2])
default achievement_milfy = Achievement(name=achievement_name['milfy'][0], message=achievement_name['milfy'][1], image=achievement_name['milfy'][2])
default achievement_sacrifice = Achievement(name=achievement_name['sacrifice'][0], message=achievement_name['sacrifice'][1], image=achievement_name['sacrifice'][2])
default achievement_endep5 = Achievement(name=achievement_name['endep5'][0], message=achievement_name['endep5'][1], image=achievement_name['endep5'][2])
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
